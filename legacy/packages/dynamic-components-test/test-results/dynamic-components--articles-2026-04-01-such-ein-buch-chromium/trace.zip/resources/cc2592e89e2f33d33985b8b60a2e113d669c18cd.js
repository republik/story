(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_0znwu~r._.js","static/chunks/node_modules_@sanity_014ykv-._.js","static/chunks/node_modules_rxjs_dist_esm5_internal_0e3j19g._.js","static/chunks/node_modules_@sanity_ui_dist_0~jmjfv._.js","static/chunks/node_modules_@sanity_icons_dist_index_0c_qw0b.js","static/chunks/0ldt_motion-dom_dist_es_002-hz5._.js","static/chunks/0ldt_framer-motion_dist_es_11.xpsj._.js","static/chunks/node_modules_@sanity_visual-editing_dist_0pr66tk._.js","static/chunks/00nx_valibot_dist_index_mjs_11r2~-u._.js","static/chunks/node_modules_0r-8-lb._.js","static/chunks/_0pv4rwu._.js"],
    source: "dynamic"
});
