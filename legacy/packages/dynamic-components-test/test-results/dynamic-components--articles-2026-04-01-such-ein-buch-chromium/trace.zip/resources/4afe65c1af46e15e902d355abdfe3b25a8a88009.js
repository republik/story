;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="3ce5132f-8b6d-8c00-4311-a4215eb409d5")}catch(e){}}();
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@sanity/ui/dist/_chunks-es/refractor.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_0c4vkpm._.js",
  "static/chunks/node_modules_@sanity_ui_dist__chunks-es_refractor_mjs_0zrrd-.._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@sanity/ui/dist/_chunks-es/refractor.mjs [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/@sanity/visual-editing/dist/_chunks-es/LoaderComlink.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_@sanity_visual-editing_dist__chunks-es_LoaderComlink_0m-wj0j.js",
  "static/chunks/node_modules_@sanity_visual-editing_dist__chunks-es_LoaderComlink_0zrrd-..js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@sanity/visual-editing/dist/_chunks-es/LoaderComlink.js [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/next-sanity/dist/SanityLive.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_@sanity_015bv41._.js",
  "static/chunks/node_modules_0tg4fkl._.js",
  "static/chunks/node_modules_next-sanity_dist_SanityLive_0zrrd-..js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/next-sanity/dist/SanityLive.js [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/next-sanity/dist/VisualEditing.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_next-sanity_dist_VisualEditing_0aq9s3d.js",
  "static/chunks/node_modules_next-sanity_dist_VisualEditing_0zrrd-..js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/next-sanity/dist/VisualEditing.js [app-client] (ecmascript)");
    });
});
}),
]);

//# debugId=3ce5132f-8b6d-8c00-4311-a4215eb409d5