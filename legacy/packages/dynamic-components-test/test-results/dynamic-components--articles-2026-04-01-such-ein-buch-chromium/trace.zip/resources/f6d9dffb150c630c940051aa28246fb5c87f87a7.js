;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="b203e564-0f3a-6467-60e7-d10b2a0d548d")}catch(e){}}();
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/next/dist/compiled/react/cjs/react-compiler-runtime.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * @license React
 * react-compiler-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ "use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    var ReactSharedInternals = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)").__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
    exports.c = function(size) {
        var dispatcher = ReactSharedInternals.H;
        null === dispatcher && console.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.");
        return dispatcher.useMemoCache(size);
    };
}();
}),
"[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ 'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/cjs/react-compiler-runtime.development.js [app-client] (ecmascript)");
}
}),
"[project]/node_modules/next/dist/shared/lib/lazy-dynamic/dynamic-bailout-to-csr.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "BailoutToCSR", {
    enumerable: true,
    get: function() {
        return BailoutToCSR;
    }
});
const _bailouttocsr = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/lazy-dynamic/bailout-to-csr.js [app-client] (ecmascript)");
function BailoutToCSR({ reason, children }) {
    if (typeof window === 'undefined') {
        throw Object.defineProperty(new _bailouttocsr.BailoutToCSRError(reason), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
        });
    }
    return children;
}
}),
"[project]/node_modules/next/dist/shared/lib/lazy-dynamic/preload-chunks.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "PreloadChunks", {
    enumerable: true,
    get: function() {
        return PreloadChunks;
    }
});
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _reactdom = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
const _workasyncstorageexternal = __turbopack_context__.r("[project]/node_modules/next/dist/server/app-render/work-async-storage.external.js [app-client] (ecmascript)");
const _encodeuripath = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/encode-uri-path.js [app-client] (ecmascript)");
const _deploymentid = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/deployment-id.js [app-client] (ecmascript)");
function PreloadChunks({ moduleIds }) {
    // Early return in client compilation and only load requestStore on server side
    if (typeof window !== 'undefined') {
        return null;
    }
    const workStore = _workasyncstorageexternal.workAsyncStorage.getStore();
    if (workStore === undefined) {
        return null;
    }
    const allFiles = [];
    // Search the current dynamic call unique key id in react loadable manifest,
    // and find the corresponding CSS files to preload
    if (workStore.reactLoadableManifest && moduleIds) {
        const manifest = workStore.reactLoadableManifest;
        for (const key of moduleIds){
            if (!manifest[key]) continue;
            const chunks = manifest[key].files;
            allFiles.push(...chunks);
        }
    }
    if (allFiles.length === 0) {
        return null;
    }
    const query = (0, _deploymentid.getAssetTokenQuery)();
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(_jsxruntime.Fragment, {
        children: allFiles.map((chunk)=>{
            const href = `${workStore.assetPrefix}/_next/${(0, _encodeuripath.encodeURIPath)(chunk)}${query}`;
            const isCss = chunk.endsWith('.css');
            // If it's stylesheet we use `precedence` o help hoist with React Float.
            // For stylesheets we actually need to render the CSS because nothing else is going to do it so it needs to be part of the component tree.
            // The `preload` for stylesheet is not optional.
            if (isCss) {
                return /*#__PURE__*/ (0, _jsxruntime.jsx)("link", {
                    // @ts-ignore
                    precedence: "dynamic",
                    href: href,
                    rel: "stylesheet",
                    as: "style",
                    nonce: workStore.nonce
                }, chunk);
            } else {
                // If it's script we use ReactDOM.preload to preload the resources
                (0, _reactdom.preload)(href, {
                    as: 'script',
                    fetchPriority: 'low',
                    nonce: workStore.nonce
                });
                return null;
            }
        })
    });
}
}),
"[project]/node_modules/next/dist/shared/lib/lazy-dynamic/loadable.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _dynamicbailouttocsr = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/lazy-dynamic/dynamic-bailout-to-csr.js [app-client] (ecmascript)");
const _preloadchunks = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/lazy-dynamic/preload-chunks.js [app-client] (ecmascript)");
// Normalize loader to return the module as form { default: Component } for `React.lazy`.
// Also for backward compatible since next/dynamic allows to resolve a component directly with loader
// Client component reference proxy need to be converted to a module.
function convertModule(mod) {
    // Check "default" prop before accessing it, as it could be client reference proxy that could break it reference.
    // Cases:
    // mod: { default: Component }
    // mod: Component
    // mod: { default: proxy(Component) }
    // mod: proxy(Component)
    const hasDefault = mod && 'default' in mod;
    return {
        default: hasDefault ? mod.default : mod
    };
}
const defaultOptions = {
    loader: ()=>Promise.resolve(convertModule(()=>null)),
    loading: null,
    ssr: true
};
function Loadable(options) {
    const opts = {
        ...defaultOptions,
        ...options
    };
    const Lazy = /*#__PURE__*/ (0, _react.lazy)(()=>opts.loader().then(convertModule));
    const Loading = opts.loading;
    function LoadableComponent(props) {
        const fallbackElement = Loading ? /*#__PURE__*/ (0, _jsxruntime.jsx)(Loading, {
            isLoading: true,
            pastDelay: true,
            error: null
        }) : null;
        // If it's non-SSR or provided a loading component, wrap it in a suspense boundary
        const hasSuspenseBoundary = !opts.ssr || !!opts.loading;
        const Wrap = hasSuspenseBoundary ? _react.Suspense : _react.Fragment;
        const wrapProps = hasSuspenseBoundary ? {
            fallback: fallbackElement
        } : {};
        const children = opts.ssr ? /*#__PURE__*/ (0, _jsxruntime.jsxs)(_jsxruntime.Fragment, {
            children: [
                typeof window === 'undefined' ? /*#__PURE__*/ (0, _jsxruntime.jsx)(_preloadchunks.PreloadChunks, {
                    moduleIds: opts.modules
                }) : null,
                /*#__PURE__*/ (0, _jsxruntime.jsx)(Lazy, {
                    ...props
                })
            ]
        }) : /*#__PURE__*/ (0, _jsxruntime.jsx)(_dynamicbailouttocsr.BailoutToCSR, {
            reason: "next/dynamic",
            children: /*#__PURE__*/ (0, _jsxruntime.jsx)(Lazy, {
                ...props
            })
        });
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(Wrap, {
            ...wrapProps,
            children: children
        });
    }
    LoadableComponent.displayName = 'LoadableComponent';
    return LoadableComponent;
}
const _default = Loadable;
}),
"[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return dynamic;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/node_modules/next/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _loadable = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/lazy-dynamic/loadable.js [app-client] (ecmascript)"));
function dynamic(dynamicOptions, options) {
    const loadableOptions = {};
    if (typeof dynamicOptions === 'function') {
        loadableOptions.loader = dynamicOptions;
    }
    const mergedOptions = {
        ...loadableOptions,
        ...options
    };
    return (0, _loadable.default)({
        ...mergedOptions,
        modules: mergedOptions.loadableGenerated?.modules
    });
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/@sanity/comlink/node_modules/uuid/dist/native.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const randomUUID = typeof crypto !== 'undefined' && crypto.randomUUID && crypto.randomUUID.bind(crypto);
const __TURBOPACK__default__export__ = {
    randomUUID
};
}),
"[project]/node_modules/@sanity/comlink/node_modules/uuid/dist/rng.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>rng
]);
let getRandomValues;
const rnds8 = new Uint8Array(16);
function rng() {
    if (!getRandomValues) {
        if (typeof crypto === 'undefined' || !crypto.getRandomValues) {
            throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
        }
        getRandomValues = crypto.getRandomValues.bind(crypto);
    }
    return getRandomValues(rnds8);
}
}),
"[project]/node_modules/@sanity/comlink/node_modules/uuid/dist/regex.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const __TURBOPACK__default__export__ = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/i;
}),
"[project]/node_modules/@sanity/comlink/node_modules/uuid/dist/validate.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$regex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/uuid/dist/regex.js [app-client] (ecmascript)");
;
function validate(uuid) {
    return typeof uuid === 'string' && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$regex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].test(uuid);
}
const __TURBOPACK__default__export__ = validate;
}),
"[project]/node_modules/@sanity/comlink/node_modules/uuid/dist/stringify.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "unsafeStringify",
    ()=>unsafeStringify
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$validate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/uuid/dist/validate.js [app-client] (ecmascript)");
;
const byteToHex = [];
for(let i = 0; i < 256; ++i){
    byteToHex.push((i + 0x100).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
    return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}
function stringify(arr, offset = 0) {
    const uuid = unsafeStringify(arr, offset);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$validate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(uuid)) {
        throw TypeError('Stringified UUID is invalid');
    }
    return uuid;
}
const __TURBOPACK__default__export__ = stringify;
}),
"[project]/node_modules/@sanity/comlink/node_modules/uuid/dist/v4.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$native$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/uuid/dist/native.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$rng$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/uuid/dist/rng.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/uuid/dist/stringify.js [app-client] (ecmascript)");
;
;
;
function _v4(options, buf, offset) {
    options = options || {};
    const rnds = options.random ?? options.rng?.() ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$rng$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    if (rnds.length < 16) {
        throw new Error('Random bytes length must be >= 16');
    }
    rnds[6] = rnds[6] & 0x0f | 0x40;
    rnds[8] = rnds[8] & 0x3f | 0x80;
    if (buf) {
        offset = offset || 0;
        if (offset < 0 || offset + 16 > buf.length) {
            throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
        }
        for(let i = 0; i < 16; ++i){
            buf[offset + i] = rnds[i];
        }
        return buf;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unsafeStringify"])(rnds);
}
function v4(options, buf, offset) {
    if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$native$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].randomUUID && !buf && !options) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$native$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].randomUUID();
    }
    return _v4(options, buf, offset);
}
const __TURBOPACK__default__export__ = v4;
}),
"[project]/node_modules/@sanity/comlink/node_modules/uuid/dist/v4.js [app-client] (ecmascript) <export default as v4>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "v4",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/uuid/dist/v4.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@sanity/uuid/node_modules/uuid/dist/esm-browser/rng.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>rng
]);
// Unique ID creation requires a high quality random # generator. In the browser we therefore
// require the crypto API and do not support built-in fallback to lower quality random number
// generators (like Math.random()).
var getRandomValues;
var rnds8 = new Uint8Array(16);
function rng() {
    // lazy load so that environments that need to polyfill have a chance to do so
    if (!getRandomValues) {
        // getRandomValues needs to be invoked in a context where "this" is a Crypto implementation. Also,
        // find the complete implementation of crypto (msCrypto) on IE11.
        getRandomValues = typeof crypto !== 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || typeof msCrypto !== 'undefined' && typeof msCrypto.getRandomValues === 'function' && msCrypto.getRandomValues.bind(msCrypto);
        if (!getRandomValues) {
            throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
        }
    }
    return getRandomValues(rnds8);
}
}),
"[project]/node_modules/@sanity/uuid/node_modules/uuid/dist/esm-browser/regex.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const __TURBOPACK__default__export__ = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;
}),
"[project]/node_modules/@sanity/uuid/node_modules/uuid/dist/esm-browser/validate.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$uuid$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$regex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/uuid/node_modules/uuid/dist/esm-browser/regex.js [app-client] (ecmascript)");
;
function validate(uuid) {
    return typeof uuid === 'string' && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$uuid$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$regex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].test(uuid);
}
const __TURBOPACK__default__export__ = validate;
}),
"[project]/node_modules/@sanity/uuid/node_modules/uuid/dist/esm-browser/stringify.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$uuid$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$validate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/uuid/node_modules/uuid/dist/esm-browser/validate.js [app-client] (ecmascript)");
;
/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */ var byteToHex = [];
for(var i = 0; i < 256; ++i){
    byteToHex.push((i + 0x100).toString(16).substr(1));
}
function stringify(arr) {
    var offset = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
    // Note: Be careful editing this code!  It's been tuned for performance
    // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
    var uuid = (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase(); // Consistency check for valid UUID.  If this throws, it's likely due to one
    // of the following:
    // - One or more input array values don't map to a hex octet (leading to
    // "undefined" in the uuid)
    // - Invalid input values for the RFC `version` or `variant` fields
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$uuid$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$validate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(uuid)) {
        throw TypeError('Stringified UUID is invalid');
    }
    return uuid;
}
const __TURBOPACK__default__export__ = stringify;
}),
"[project]/node_modules/@sanity/uuid/node_modules/uuid/dist/esm-browser/v4.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$uuid$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$rng$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/uuid/node_modules/uuid/dist/esm-browser/rng.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$uuid$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/uuid/node_modules/uuid/dist/esm-browser/stringify.js [app-client] (ecmascript)");
;
;
function v4(options, buf, offset) {
    options = options || {};
    var rnds = options.random || (options.rng || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$uuid$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$rng$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`
    rnds[6] = rnds[6] & 0x0f | 0x40;
    rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided
    if (buf) {
        offset = offset || 0;
        for(var i = 0; i < 16; ++i){
            buf[offset + i] = rnds[i];
        }
        return buf;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$uuid$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(rnds);
}
const __TURBOPACK__default__export__ = v4;
}),
"[project]/node_modules/@sanity/uuid/node_modules/uuid/dist/esm-browser/v4.js [app-client] (ecmascript) <export default as v4>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "v4",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$uuid$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$uuid$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/uuid/node_modules/uuid/dist/esm-browser/v4.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@sanity/uuid/node_modules/uuid/dist/esm-browser/v4.js [app-client] (ecmascript) <export default as v4> <export v4 as uuid>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "uuid",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$uuid$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$uuid$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/uuid/node_modules/uuid/dist/esm-browser/v4.js [app-client] (ecmascript) <export default as v4>");
}),
"[project]/node_modules/@sanity/comlink/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DOMAIN",
    ()=>DOMAIN,
    "FETCH_TIMEOUT_DEFAULT",
    ()=>FETCH_TIMEOUT_DEFAULT,
    "HANDSHAKE_INTERVAL",
    ()=>HANDSHAKE_INTERVAL,
    "HANDSHAKE_MSG_TYPES",
    ()=>HANDSHAKE_MSG_TYPES,
    "HEARTBEAT_INTERVAL",
    ()=>HEARTBEAT_INTERVAL,
    "INTERNAL_MSG_TYPES",
    ()=>INTERNAL_MSG_TYPES,
    "MSG_DISCONNECT",
    ()=>MSG_DISCONNECT,
    "MSG_HANDSHAKE_ACK",
    ()=>MSG_HANDSHAKE_ACK,
    "MSG_HANDSHAKE_SYN",
    ()=>MSG_HANDSHAKE_SYN,
    "MSG_HANDSHAKE_SYN_ACK",
    ()=>MSG_HANDSHAKE_SYN_ACK,
    "MSG_HEARTBEAT",
    ()=>MSG_HEARTBEAT,
    "MSG_RESPONSE",
    ()=>MSG_RESPONSE,
    "RESPONSE_TIMEOUT_DEFAULT",
    ()=>RESPONSE_TIMEOUT_DEFAULT,
    "createConnection",
    ()=>createConnection,
    "createConnectionMachine",
    ()=>createConnectionMachine,
    "createController",
    ()=>createController,
    "createListenLogic",
    ()=>createListenLogic,
    "createNode",
    ()=>createNode,
    "createNodeMachine",
    ()=>createNodeMachine,
    "createRequestMachine",
    ()=>createRequestMachine
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/uuid/dist/v4.js [app-client] (ecmascript) <export default as v4>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$actors$2f$dist$2f$xstate$2d$actors$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/xstate/actors/dist/xstate-actors.development.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/xstate/dist/xstate.development.esm.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__s__as__sendTo$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/xstate/dist/log-3e4dba89.development.esm.js [app-client] (ecmascript) <export s as sendTo>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$4f7ce317$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/xstate/dist/assign-4f7ce317.development.esm.js [app-client] (ecmascript) <export a as assign>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c__as__createActor$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/xstate/dist/raise-b724c245.development.esm.js [app-client] (ecmascript) <export c as createActor>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__e__as__enqueueActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/xstate/dist/log-3e4dba89.development.esm.js [app-client] (ecmascript) <export e as enqueueActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__r__as__raise$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/xstate/dist/raise-b724c245.development.esm.js [app-client] (ecmascript) <export r as raise>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__emit$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/xstate/dist/log-3e4dba89.development.esm.js [app-client] (ecmascript) <export a as emit>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__s__as__stopChild$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/node_modules/xstate/dist/raise-b724c245.development.esm.js [app-client] (ecmascript) <export s as stopChild>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$observable$2f$defer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/observable/defer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$observable$2f$fromEvent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/observable/fromEvent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$map$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/operators/map.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$util$2f$pipe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/util/pipe.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$filter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/operators/filter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$bufferCount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/operators/bufferCount.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$concatMap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/operators/concatMap.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$take$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/operators/take.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$observable$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/observable/empty.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$takeUntil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/operators/takeUntil.js [app-client] (ecmascript)");
;
;
;
const listenInputFromContext = (config)=>({ context })=>{
        const { count, include, exclude, responseType = "message.received" } = config;
        return {
            count,
            domain: context.domain,
            from: context.connectTo,
            include: include ? Array.isArray(include) ? include : [
                include
            ] : [],
            exclude: exclude ? Array.isArray(exclude) ? exclude : [
                exclude
            ] : [],
            responseType,
            target: context.target,
            to: context.name
        };
    }, listenFilter = (input)=>(event)=>{
        const { data } = event;
        return (input.include.length ? input.include.includes(data.type) : !0) && (input.exclude.length ? !input.exclude.includes(data.type) : !0) && data.domain === input.domain && data.from === input.from && data.to === input.to && (!input.target || event.source === input.target);
    }, eventToMessage = (type)=>(event)=>({
            type,
            message: event
        }), messageEvents$ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$observable$2f$defer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defer"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$observable$2f$fromEvent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromEvent"])(window, "message")), createListenLogic = (compatMap)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$actors$2f$dist$2f$xstate$2d$actors$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromEventObservable"])(({ input })=>messageEvents$.pipe(compatMap ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$map$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(compatMap) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$util$2f$pipe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pipe"])(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$filter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filter"])(listenFilter(input)), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$map$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(eventToMessage(input.responseType)), input.count ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$util$2f$pipe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pipe"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$bufferCount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bufferCount"])(input.count), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$concatMap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["concatMap"])((arr)=>arr), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$take$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["take"])(input.count)) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$util$2f$pipe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pipe"])())), DOMAIN = "sanity/comlink", RESPONSE_TIMEOUT_DEFAULT = 3e3, FETCH_TIMEOUT_DEFAULT = 1e4, HEARTBEAT_INTERVAL = 1e3, HANDSHAKE_INTERVAL = 500, MSG_RESPONSE = "comlink/response", MSG_HEARTBEAT = "comlink/heartbeat", MSG_DISCONNECT = "comlink/disconnect", MSG_HANDSHAKE_SYN = "comlink/handshake/syn", MSG_HANDSHAKE_SYN_ACK = "comlink/handshake/syn-ack", MSG_HANDSHAKE_ACK = "comlink/handshake/ack", HANDSHAKE_MSG_TYPES = [
    MSG_HANDSHAKE_SYN,
    MSG_HANDSHAKE_SYN_ACK,
    MSG_HANDSHAKE_ACK
], INTERNAL_MSG_TYPES = [
    MSG_RESPONSE,
    MSG_DISCONNECT,
    MSG_HEARTBEAT,
    ...HANDSHAKE_MSG_TYPES
], throwOnEvent = (message)=>(source)=>source.pipe((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$take$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["take"])(1), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$map$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"])(()=>{
            throw new Error(message);
        })), createRequestMachine = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["setup"])({
        types: {},
        actors: {
            listen: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$actors$2f$dist$2f$xstate$2d$actors$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromEventObservable"])(({ input })=>{
                const abortSignal$ = input.signal ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$observable$2f$fromEvent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromEvent"])(input.signal, "abort").pipe(throwOnEvent(`Request ${input.requestId} aborted`)) : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$observable$2f$empty$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY"], messageFilter = (event)=>event.data?.type === MSG_RESPONSE && event.data?.responseTo === input.requestId && !!event.source && input.sources.has(event.source);
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$observable$2f$fromEvent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromEvent"])(window, "message").pipe((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$filter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filter"])(messageFilter), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$take$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["take"])(input.sources.size), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$takeUntil$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["takeUntil"])(abortSignal$));
            })
        },
        actions: {
            "send message": ({ context }, params)=>{
                const { sources, targetOrigin } = context, { message } = params;
                sources.forEach((source)=>{
                    source.postMessage(message, {
                        targetOrigin
                    });
                });
            },
            "on success": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__s__as__sendTo$3e$__["sendTo"])(({ context })=>context.parentRef, ({ context, self })=>(context.response && context.resolvable?.resolve(context.response), {
                    type: "request.success",
                    requestId: self.id,
                    response: context.response,
                    responseTo: context.responseTo
                })),
            "on fail": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__s__as__sendTo$3e$__["sendTo"])(({ context })=>context.parentRef, ({ context, self })=>(context.suppressWarnings || console.warn(`[@sanity/comlink] Received no response to message '${context.type}' on client '${context.from}' (ID: '${context.id}').`), context.resolvable?.reject(new Error("No response received")), {
                    type: "request.failed",
                    requestId: self.id
                })),
            "on abort": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__s__as__sendTo$3e$__["sendTo"])(({ context })=>context.parentRef, ({ context, self })=>(context.resolvable?.reject(new Error("Request aborted")), {
                    type: "request.aborted",
                    requestId: self.id
                }))
        },
        guards: {
            expectsResponse: ({ context })=>context.expectResponse
        },
        delays: {
            initialTimeout: 0,
            responseTimeout: ({ context })=>context.responseTimeout ?? RESPONSE_TIMEOUT_DEFAULT
        }
    }).createMachine({
        /** @xstate-layout N4IgpgJg5mDOIC5QAoC2BDAxgCwJYDswBKAOlwgBswBiAD1gBd0GwT0AzFgJ2QNwdzoKAFVyowAewCuDItTRY8hUuSoBtAAwBdRKAAOE2P1wT8ukLUQBGAEwBWEgBYAnK+eOAzB7sB2DzY8rABoQAE9rDQc3V0cNTw8fAA4NHwBfVJCFHAJiElgwfAgCKGpNHSQQAyMBU3NLBDsrDxI7DTaAjQA2OOcNDxDwhHsNJx9Ou0TOq2cJxP9HdMyMbOU8gqL8ErUrcv1DY1qK+sbm1vaPLp6+gcRnGydo9wDGycWQLKVc9AB3dGNN6jiWCwdAwMrmKoHMxHRCJRKOEiJHwuZKBZwXKzBMKIGyYkhtAkXOweTqOHw2RJvD45Ug-P4CAH0JgsNicMA8LhwAz4fKicTSWTyZafWm-f5QcEVSE1aGgepwhFIlF9aYYrGDC4+JzEppjGzOUkeGbpDIgfASCBwczU5QQ-YyuqIAC0nRuCBd+IJXu9KSpwppZEoYDt1RMsosiEcNjdVjiJEeGisiSTHkcVgWpptuXyhWKIahjqGzi1BqRJINnVcdkcbuTLS9VYC8ISfsUAbp4vzDphCHJIyjBvJNlxNmRNexQ3sJGH43GPj8jWJrZWuXYfyoEC7YcLsbrgRsjkcvkmdgNbopVhIPhVfnsh8ClMz-tWsCkmEwcHgUvt257u8v+6Hse4xnhOdZnImVidPqCRNB4JqpEAA */ context: ({ input })=>({
                channelId: input.channelId,
                data: input.data,
                domain: input.domain,
                expectResponse: input.expectResponse ?? !1,
                from: input.from,
                id: `msg-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])()}`,
                parentRef: input.parentRef,
                resolvable: input.resolvable,
                response: null,
                responseTimeout: input.responseTimeout,
                responseTo: input.responseTo,
                signal: input.signal,
                sources: input.sources instanceof Set ? input.sources : /* @__PURE__ */ new Set([
                    input.sources
                ]),
                suppressWarnings: input.suppressWarnings,
                targetOrigin: input.targetOrigin,
                to: input.to,
                type: input.type
            }),
        initial: "idle",
        on: {
            abort: ".aborted"
        },
        states: {
            idle: {
                after: {
                    initialTimeout: [
                        {
                            target: "sending"
                        }
                    ]
                }
            },
            sending: {
                entry: {
                    type: "send message",
                    params: ({ context })=>{
                        const { channelId, data, domain, from, id, responseTo, to, type } = context;
                        return {
                            message: {
                                channelId,
                                data,
                                domain,
                                from,
                                id,
                                to,
                                type,
                                responseTo
                            }
                        };
                    }
                },
                always: [
                    {
                        guard: "expectsResponse",
                        target: "awaiting"
                    },
                    "success"
                ]
            },
            awaiting: {
                invoke: {
                    id: "listen for response",
                    src: "listen",
                    input: ({ context })=>({
                            requestId: context.id,
                            sources: context.sources,
                            signal: context.signal
                        }),
                    onError: "aborted"
                },
                after: {
                    responseTimeout: "failed"
                },
                on: {
                    message: {
                        actions: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$4f7ce317$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
                            response: ({ event })=>event.data.data,
                            responseTo: ({ event })=>event.data.responseTo
                        }),
                        target: "success"
                    }
                }
            },
            failed: {
                type: "final",
                entry: "on fail"
            },
            success: {
                type: "final",
                entry: "on success"
            },
            aborted: {
                type: "final",
                entry: "on abort"
            }
        },
        output: ({ context, self })=>({
                requestId: self.id,
                response: context.response,
                responseTo: context.responseTo
            })
    }), sendBackAtInterval = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$actors$2f$dist$2f$xstate$2d$actors$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromCallback"])(({ sendBack, input })=>{
    const send = ()=>{
        sendBack(input.event);
    };
    input.immediate && send();
    const interval = setInterval(send, input.interval);
    return ()=>{
        clearInterval(interval);
    };
}), createConnectionMachine = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["setup"])({
        types: {},
        actors: {
            requestMachine: createRequestMachine(),
            listen: createListenLogic(),
            sendBackAtInterval
        },
        actions: {
            "buffer message": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__e__as__enqueueActions$3e$__["enqueueActions"])(({ enqueue })=>{
                enqueue.assign({
                    buffer: ({ event, context })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "post"), [
                            ...context.buffer,
                            event.data
                        ])
                }), enqueue.emit(({ event })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "post"), {
                        type: "buffer.added",
                        message: event.data
                    }));
            }),
            "create request": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$4f7ce317$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
                requests: ({ context, event, self, spawn })=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "request");
                    const requests = (Array.isArray(event.data) ? event.data : [
                        event.data
                    ]).map((request)=>{
                        const id = `req-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])()}`;
                        return spawn("requestMachine", {
                            id,
                            input: {
                                channelId: context.channelId,
                                data: request.data,
                                domain: context.domain,
                                expectResponse: request.expectResponse,
                                from: context.name,
                                parentRef: self,
                                responseTo: request.responseTo,
                                sources: context.target,
                                targetOrigin: context.targetOrigin,
                                to: context.connectTo,
                                type: request.type
                            }
                        });
                    });
                    return [
                        ...context.requests,
                        ...requests
                    ];
                }
            }),
            "emit received message": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__e__as__enqueueActions$3e$__["enqueueActions"])(({ enqueue })=>{
                enqueue.emit(({ event })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "message.received"), {
                        type: "message",
                        message: event.message.data
                    }));
            }),
            "emit status": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__emit$3e$__["emit"])((_, params)=>({
                    type: "status",
                    status: params.status
                })),
            "post message": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__r__as__raise$3e$__["raise"])(({ event })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "post"), {
                    type: "request",
                    data: {
                        data: event.data.data,
                        expectResponse: !0,
                        type: event.data.type
                    }
                })),
            "remove request": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__e__as__enqueueActions$3e$__["enqueueActions"])(({ context, enqueue, event })=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, [
                    "request.success",
                    "request.failed",
                    "request.aborted"
                ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__s__as__stopChild$3e$__["stopChild"])(event.requestId), enqueue.assign({
                    requests: context.requests.filter(({ id })=>id !== event.requestId)
                });
            }),
            respond: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__r__as__raise$3e$__["raise"])(({ event })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "response"), {
                    type: "request",
                    data: {
                        data: event.data,
                        type: MSG_RESPONSE,
                        responseTo: event.respondTo
                    }
                })),
            "send handshake ack": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__r__as__raise$3e$__["raise"])({
                type: "request",
                data: {
                    type: MSG_HANDSHAKE_ACK
                }
            }),
            "send disconnect": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__r__as__raise$3e$__["raise"])(()=>({
                    type: "request",
                    data: {
                        type: MSG_DISCONNECT
                    }
                })),
            "send handshake syn": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__r__as__raise$3e$__["raise"])({
                type: "request",
                data: {
                    type: MSG_HANDSHAKE_SYN
                }
            }),
            "send pending messages": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__e__as__enqueueActions$3e$__["enqueueActions"])(({ enqueue })=>{
                enqueue.raise(({ context })=>({
                        type: "request",
                        data: context.buffer.map(({ data, type })=>({
                                data,
                                type
                            }))
                    })), enqueue.emit(({ context })=>({
                        type: "buffer.flushed",
                        messages: context.buffer
                    })), enqueue.assign({
                    buffer: []
                });
            }),
            "set target": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$4f7ce317$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
                target: ({ event })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "target.set"), event.target)
            })
        },
        guards: {
            "has target": ({ context })=>!!context.target,
            "should send heartbeats": ({ context })=>context.heartbeat
        }
    }).createMachine({
        /** @xstate-layout N4IgpgJg5mDOIC5QGMAWBDAdpsAbAxAC7oBOMhAdLGIQNoAMAuoqAA4D2sAloV+5ixAAPRAHZRAJgoAWABz0ArHICMy2QGZZCgJwAaEAE9EE+tIrb6ANgkLl46fTuj1AXxf60WHARJgAjgCucJSwAcjIcLAMzEggHNy8-IIiCKLS2hQS6qb2yurisrL6RgjK9LIyCuqq0g7WstZuHhjYePi+gcEUAGboXLiQ0YLxPHwCsSmiCgoykpayDtqS6trqxYjKEk0gnq24FFwQA-jI-DjIdEzDnKNJExuOZpZ12eq29OrSCuupypYUojUaTKCnm5Wk2123gORzA+HilxibBuiXGoBSGnUAIU4gU9FWamUtR+lmUM1EllBEkslMUEnpkJa0JaEFgGAA1lxMFB8LADJghrERqjkhtshk3mTtNo5OpqpYfqCKhTptoqpY1WUtu4dky8BQWWz0Jzue1-EFYIjrgkxqLSupqRRPpoPqJtLI0hIioZENJJE7NnJ8ZYHVk1YyvPrDRyuTyEYLkTa7uixVlMh81KGFhS1j6EPkZlpVjTphr8mkI3sDVhWTHTQBbSLoGAUXwRLgAN0GVyFKNt91KimUFEKXvKC2s9R+6X+jipnzJeSqEJ1UKjNaNJp5EC4sFOrQuCbifeTwg2cgoym0RPxDtqkj0eaB9Ao8zSolMEivZVcq71+33c5CEgeFOCtXskzRM8EDxKRpmkSw3QJbQsmpH5tHmV8JHSbJpDsakV2aSMALOMALhAjoLXAxNbiglI-SxWw1Vw0QNDw0Qfg9KQ7EJSxHHxApK2hQCyOAiAzVgDhMGoI9hX7FMEHSF8cWkelpHURCbBsb481xAEgT9BQJCmWQsiE-URPI8TG1gWBmzAVsyLATtuyRY9ILtWoKmlL82Kqd0tAVJ91LMHFZDKIkVlkNVZHMkiDzE-Adz3UjDx7GiRQHCKnheD53k+HSSkDDIwpBVTqQwuKKEssSDTAUhCAAI3qyg0DIrd8Fkk86MQUMnVM+RynoegTDJH48hGp0vR-FDRqqKqasgOqGua9AQjATAd1NSiul6fpXOtWi7Wy19cslD4vnG7IX3oVjVDUVYEJQqrksW8SdstLqPKy0wKgG1RhtMWogqKhoMjkWp6XxUyFBe3c3tAz70vco6fq+V8PTkGUFzdQqNnELEM2yClrwwzQ4ZShKQJqr7UYU98AS0W9pT4z5pHG0yXwMkNNTyGk3B1TB2AgOBBDXXBDsyhSFG9EovQqN5i1JeRcKqw4Bkl+ToMx8x0j+EaqQ9XMSkBURMgMkEwQWKro2NWNNdPFJAzN0lJGM4slDxhBEJfXyplBd03wW1KxIdnrBxBh4JAyW75C8rJpmDqmIGWkgmpasPjqUcaHooMLHA0uU1UkJOgKW1B6rT1bWor5At0zgcTAkK7hrz1irB0D8cW0UvRPLyv07WqgNq2qAG+l9SnXUz0UOXD5xuMs3Y4+DVJBX7UiKrV6Q8gcfoJO54rFefLLqfJYX1WKYNLxL4NO1NwgA */ id: "connection",
        context: ({ input })=>({
                id: input.id || `${input.name}-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])()}`,
                buffer: [],
                channelId: `chn-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])()}`,
                connectTo: input.connectTo,
                domain: input.domain ?? DOMAIN,
                heartbeat: input.heartbeat ?? !1,
                name: input.name,
                requests: [],
                target: input.target,
                targetOrigin: input.targetOrigin
            }),
        on: {
            "target.set": {
                actions: "set target"
            },
            "request.success": {
                actions: "remove request"
            },
            "request.failed": {
                actions: "remove request"
            }
        },
        initial: "idle",
        states: {
            idle: {
                entry: [
                    {
                        type: "emit status",
                        params: {
                            status: "idle"
                        }
                    }
                ],
                on: {
                    connect: {
                        target: "handshaking",
                        guard: "has target"
                    },
                    post: {
                        actions: "buffer message"
                    }
                }
            },
            handshaking: {
                id: "handshaking",
                entry: [
                    {
                        type: "emit status",
                        params: {
                            status: "handshaking"
                        }
                    }
                ],
                invoke: [
                    {
                        id: "send syn",
                        src: "sendBackAtInterval",
                        input: ()=>({
                                event: {
                                    type: "syn"
                                },
                                interval: HANDSHAKE_INTERVAL,
                                immediate: !0
                            })
                    },
                    {
                        id: "listen for handshake",
                        src: "listen",
                        input: (input)=>listenInputFromContext({
                                include: MSG_HANDSHAKE_SYN_ACK,
                                count: 1
                            })(input)
                    }
                ],
                on: {
                    syn: {
                        actions: "send handshake syn"
                    },
                    request: {
                        actions: "create request"
                    },
                    post: {
                        actions: "buffer message"
                    },
                    "message.received": {
                        target: "connected"
                    },
                    disconnect: {
                        target: "disconnected"
                    }
                },
                exit: "send handshake ack"
            },
            connected: {
                entry: [
                    "send pending messages",
                    {
                        type: "emit status",
                        params: {
                            status: "connected"
                        }
                    }
                ],
                invoke: {
                    id: "listen for messages",
                    src: "listen",
                    input: listenInputFromContext({
                        exclude: [
                            MSG_RESPONSE,
                            MSG_HEARTBEAT
                        ]
                    })
                },
                on: {
                    post: {
                        actions: "post message"
                    },
                    request: {
                        actions: "create request"
                    },
                    response: {
                        actions: "respond"
                    },
                    "message.received": {
                        actions: "emit received message"
                    },
                    disconnect: {
                        target: "disconnected"
                    }
                },
                initial: "heartbeat",
                states: {
                    heartbeat: {
                        initial: "checking",
                        states: {
                            checking: {
                                always: {
                                    guard: "should send heartbeats",
                                    target: "sending"
                                }
                            },
                            sending: {
                                on: {
                                    "request.failed": {
                                        target: "#handshaking"
                                    }
                                },
                                invoke: {
                                    id: "send heartbeat",
                                    src: "sendBackAtInterval",
                                    input: ()=>({
                                            event: {
                                                type: "post",
                                                data: {
                                                    type: MSG_HEARTBEAT,
                                                    data: void 0
                                                }
                                            },
                                            interval: 2e3,
                                            immediate: !1
                                        })
                                }
                            }
                        }
                    }
                }
            },
            disconnected: {
                id: "disconnected",
                entry: [
                    "send disconnect",
                    {
                        type: "emit status",
                        params: {
                            status: "disconnected"
                        }
                    }
                ],
                on: {
                    request: {
                        actions: "create request"
                    },
                    post: {
                        actions: "buffer message"
                    },
                    connect: {
                        target: "handshaking",
                        guard: "has target"
                    }
                }
            }
        }
    }), createConnection = (input, machine = createConnectionMachine())=>{
    const id = input.id || `${input.name}-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])()}`, actor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c__as__createActor$3e$__["createActor"])(machine, {
        input: {
            ...input,
            id
        }
    }), eventHandlers = /* @__PURE__ */ new Map(), unhandledMessages = /* @__PURE__ */ new Map(), on = (type, handler, options)=>{
        const handlers = eventHandlers.get(type) || /* @__PURE__ */ new Set();
        eventHandlers.has(type) || eventHandlers.set(type, handlers), handlers.add(handler);
        const unhandledMessagesForType = unhandledMessages.get(type);
        if (unhandledMessagesForType) {
            const replayCount = options?.replay ?? 1;
            Array.from(unhandledMessagesForType).slice(-replayCount).forEach(async ({ data, id: id2 })=>{
                const response = await handler(data);
                response && actor.send({
                    type: "response",
                    respondTo: id2,
                    data: response
                });
            }), unhandledMessages.delete(type);
        }
        return ()=>{
            handlers.delete(handler);
        };
    }, connect = ()=>{
        actor.send({
            type: "connect"
        });
    }, disconnect = ()=>{
        actor.send({
            type: "disconnect"
        });
    }, onStatus = (handler, filter2)=>{
        const subscription = actor.on("status", (event)=>{
            filter2 && event.status !== filter2 || handler(event.status);
        });
        return ()=>subscription.unsubscribe();
    }, setTarget = (target)=>{
        actor.send({
            type: "target.set",
            target
        });
    }, post = (type, data)=>{
        const _data = {
            type,
            data
        };
        actor.send({
            type: "post",
            data: _data
        });
    };
    actor.on("message", async ({ message })=>{
        const handlers = eventHandlers.get(message.type);
        if (handlers) {
            handlers.forEach(async (handler)=>{
                const response = await handler(message.data);
                response && actor.send({
                    type: "response",
                    respondTo: message.id,
                    data: response
                });
            });
            return;
        }
        const unhandledMessagesForType = unhandledMessages.get(message.type);
        unhandledMessagesForType ? unhandledMessagesForType.add(message) : unhandledMessages.set(message.type, /* @__PURE__ */ new Set([
            message
        ]));
    });
    const stop = ()=>{
        actor.stop();
    }, start = ()=>(actor.start(), stop);
    return {
        actor,
        connect,
        disconnect,
        id,
        name: input.name,
        machine,
        on,
        onStatus,
        post,
        setTarget,
        start,
        stop,
        get target () {
            return actor.getSnapshot().context.target;
        }
    };
}, cleanupConnection = (connection)=>{
    connection.disconnect(), setTimeout(()=>{
        connection.stop();
    }, 0);
}, noop = ()=>{}, createController = (input)=>{
    const { targetOrigin } = input, targets = /* @__PURE__ */ new Set(), channels = /* @__PURE__ */ new Set();
    return {
        addTarget: (target)=>{
            if (targets.has(target)) return noop;
            if (!targets.size || !channels.size) return targets.add(target), channels.forEach((channel)=>{
                channel.connections.forEach((connection)=>{
                    connection.setTarget(target), connection.connect();
                });
            }), ()=>{
                targets.delete(target), channels.forEach((channel)=>{
                    channel.connections.forEach((connection)=>{
                        connection.target === target && connection.disconnect();
                    });
                });
            };
            targets.add(target);
            const targetConnections = /* @__PURE__ */ new Set();
            return channels.forEach((channel)=>{
                const connection = createConnection({
                    ...channel.input,
                    target,
                    targetOrigin
                }, channel.machine);
                targetConnections.add(connection), channel.connections.add(connection), channel.subscribers.forEach(({ type, handler, unsubscribers })=>{
                    unsubscribers.push(connection.on(type, handler));
                }), channel.internalEventSubscribers.forEach(({ type, handler, unsubscribers })=>{
                    const subscription = connection.actor.on(type, handler);
                    unsubscribers.push(()=>subscription.unsubscribe());
                }), channel.statusSubscribers.forEach(({ handler, unsubscribers })=>{
                    unsubscribers.push(connection.onStatus((status)=>handler({
                            connection: connection.id,
                            status
                        })));
                }), connection.start(), connection.connect();
            }), ()=>{
                targets.delete(target), targetConnections.forEach((connection)=>{
                    cleanupConnection(connection), channels.forEach((channel)=>{
                        channel.connections.delete(connection);
                    });
                });
            };
        },
        createChannel: (input2, machine = createConnectionMachine())=>{
            const channel = {
                connections: /* @__PURE__ */ new Set(),
                input: input2,
                internalEventSubscribers: /* @__PURE__ */ new Set(),
                machine,
                statusSubscribers: /* @__PURE__ */ new Set(),
                subscribers: /* @__PURE__ */ new Set()
            };
            channels.add(channel);
            const { connections, internalEventSubscribers, statusSubscribers, subscribers } = channel;
            if (targets.size) targets.forEach((target)=>{
                const connection = createConnection({
                    ...input2,
                    target,
                    targetOrigin
                }, machine);
                connections.add(connection);
            });
            else {
                const connection = createConnection({
                    ...input2,
                    targetOrigin
                }, machine);
                connections.add(connection);
            }
            const post = (...params)=>{
                const [type, data] = params;
                connections.forEach((connection)=>{
                    connection.post(type, data);
                });
            }, on = (type, handler)=>{
                const unsubscribers = [];
                connections.forEach((connection)=>{
                    unsubscribers.push(connection.on(type, handler));
                });
                const subscriber = {
                    type,
                    handler,
                    unsubscribers
                };
                return subscribers.add(subscriber), ()=>{
                    unsubscribers.forEach((unsub)=>unsub()), subscribers.delete(subscriber);
                };
            }, onInternalEvent = (type, handler)=>{
                const unsubscribers = [];
                connections.forEach((connection)=>{
                    const subscription = connection.actor.on(type, handler);
                    unsubscribers.push(()=>subscription.unsubscribe());
                });
                const subscriber = {
                    type,
                    handler,
                    unsubscribers
                };
                return internalEventSubscribers.add(subscriber), ()=>{
                    unsubscribers.forEach((unsub)=>unsub()), internalEventSubscribers.delete(subscriber);
                };
            }, onStatus = (handler)=>{
                const unsubscribers = [];
                connections.forEach((connection)=>{
                    unsubscribers.push(connection.onStatus((status)=>handler({
                            connection: connection.id,
                            status
                        })));
                });
                const subscriber = {
                    handler,
                    unsubscribers
                };
                return statusSubscribers.add(subscriber), ()=>{
                    unsubscribers.forEach((unsub)=>unsub()), statusSubscribers.delete(subscriber);
                };
            }, stop = ()=>{
                const connections2 = channel.connections;
                connections2.forEach(cleanupConnection), connections2.clear(), channels.delete(channel);
            };
            return {
                on,
                onInternalEvent,
                onStatus,
                post,
                start: ()=>(connections.forEach((connection)=>{
                        connection.start(), connection.connect();
                    }), stop),
                stop
            };
        },
        destroy: ()=>{
            channels.forEach(({ connections })=>{
                connections.forEach(cleanupConnection), connections.clear();
            }), channels.clear(), targets.clear();
        }
    };
};
function createPromiseWithResolvers() {
    if (typeof Promise.withResolvers == "function") return Promise.withResolvers();
    let resolve, reject;
    return {
        promise: new Promise((res, rej)=>{
            resolve = res, reject = rej;
        }),
        resolve,
        reject
    };
}
const createNodeMachine = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["setup"])({
        types: {},
        actors: {
            requestMachine: createRequestMachine(),
            listen: createListenLogic()
        },
        actions: {
            "buffer handshake": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$4f7ce317$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
                handshakeBuffer: ({ event, context })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "message.received"), [
                        ...context.handshakeBuffer,
                        event
                    ])
            }),
            "buffer message": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__e__as__enqueueActions$3e$__["enqueueActions"])(({ enqueue })=>{
                enqueue.assign({
                    buffer: ({ event, context })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "post"), [
                            ...context.buffer,
                            {
                                data: event.data,
                                resolvable: event.resolvable,
                                options: event.options
                            }
                        ])
                }), enqueue.emit(({ event })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "post"), {
                        type: "buffer.added",
                        message: event.data
                    }));
            }),
            "create request": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$4f7ce317$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
                requests: ({ context, event, self, spawn })=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "request");
                    const requests = (Array.isArray(event.data) ? event.data : [
                        event.data
                    ]).map((request)=>{
                        const id = `req-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$uuid$2f$dist$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])()}`;
                        return spawn("requestMachine", {
                            id,
                            input: {
                                channelId: context.channelId,
                                data: request.data,
                                domain: context.domain,
                                expectResponse: request.expectResponse,
                                from: context.name,
                                parentRef: self,
                                resolvable: request.resolvable,
                                responseTimeout: request.options?.responseTimeout,
                                responseTo: request.responseTo,
                                signal: request.options?.signal,
                                sources: context.target,
                                suppressWarnings: request.options?.suppressWarnings,
                                targetOrigin: context.targetOrigin,
                                to: context.connectTo,
                                type: request.type
                            }
                        });
                    });
                    return [
                        ...context.requests,
                        ...requests
                    ];
                }
            }),
            "emit heartbeat": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__emit$3e$__["emit"])(()=>({
                    type: "heartbeat"
                })),
            "emit received message": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__e__as__enqueueActions$3e$__["enqueueActions"])(({ enqueue })=>{
                enqueue.emit(({ event })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "message.received"), {
                        type: "message",
                        message: event.message.data
                    }));
            }),
            "emit status": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__emit$3e$__["emit"])((_, params)=>({
                    type: "status",
                    status: params.status
                })),
            "post message": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__r__as__raise$3e$__["raise"])(({ event })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "post"), {
                    type: "request",
                    data: {
                        data: event.data.data,
                        expectResponse: !!event.resolvable,
                        type: event.data.type,
                        resolvable: event.resolvable,
                        options: event.options
                    }
                })),
            "process pending handshakes": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__e__as__enqueueActions$3e$__["enqueueActions"])(({ context, enqueue })=>{
                context.handshakeBuffer.forEach((event)=>enqueue.raise(event)), enqueue.assign({
                    handshakeBuffer: []
                });
            }),
            "remove request": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__e__as__enqueueActions$3e$__["enqueueActions"])(({ context, enqueue, event })=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, [
                    "request.success",
                    "request.failed",
                    "request.aborted"
                ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__s__as__stopChild$3e$__["stopChild"])(event.requestId), enqueue.assign({
                    requests: context.requests.filter(({ id })=>id !== event.requestId)
                });
            }),
            "send response": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__r__as__raise$3e$__["raise"])(({ event })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, [
                    "message.received",
                    "heartbeat.received"
                ]), {
                    type: "request",
                    data: {
                        type: MSG_RESPONSE,
                        responseTo: event.message.data.id,
                        data: void 0
                    }
                })),
            "send handshake syn ack": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__r__as__raise$3e$__["raise"])({
                type: "request",
                data: {
                    type: MSG_HANDSHAKE_SYN_ACK
                }
            }),
            "send pending messages": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$3e4dba89$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__e__as__enqueueActions$3e$__["enqueueActions"])(({ enqueue })=>{
                enqueue.raise(({ context })=>({
                        type: "request",
                        data: context.buffer.map(({ data, resolvable, options })=>({
                                data: data.data,
                                type: data.type,
                                expectResponse: !!resolvable,
                                resolvable,
                                options
                            }))
                    })), enqueue.emit(({ context })=>({
                        type: "buffer.flushed",
                        messages: context.buffer.map(({ data })=>data)
                    })), enqueue.assign({
                    buffer: []
                });
            }),
            "set connection config": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$4f7ce317$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
                channelId: ({ event })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "handshake.syn"), event.message.data.channelId),
                target: ({ event })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "handshake.syn"), event.message.source || void 0),
                targetOrigin: ({ event })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "handshake.syn"), event.message.origin)
            })
        },
        guards: {
            hasSource: ({ context })=>context.target !== null
        }
    }).createMachine({
        /** @xstate-layout N4IgpgJg5mDOIC5QDsD2EwGIBOYCOArnAC4B0sBAxpXLANoAMAuoqAA6qwCWxXqyrEAA9EAVgYAWUgEYJDUQA4JAZmUSJC0coDsAGhABPRNIYLSErdOkBOAGzbx227YUBfV-rQYc+IrDIAZgCGXAA2kIwsSCAc3Lz8giIIoiakqgBMDKbp2tYS0srp+kYI0ununuhgpFwQ4ZgQ-NVcyABuqADW1V7NdWAILe2UQfHIkZGCsTx8AtFJ6aKipAzWOtrpC7Z5BUWGiNoK6aS26RLW2tLaqkqqFSA9NX2YALa0QTCkuDRcrRHMk5xpgk5ogJLZSNZIVDoVCFLZiohbIVSLkXLZRHZDgxbHcHrV6rFiBNolNRolEVJbCsdGUzsoyhiEcllOC1DowelVmVrOUPPcqqQABZBZAQWDCjotKANJo1NqdboC4Wi8VBSXIKADeXDUbjf4kwFkkEILbg8RZMHKOzWKzKJkHJa086Xa4qZS4pUisUSqU+QgkYnsQ0zcnJaRLDbpZwKNQSBYspm2MEyC5KTnaDSSd18h7K71q32EwMxYPA0BJFLKY5yZxIrKSURM0RnFHSBTrQqQ9babQejBCr2q9XSiBcWCUfjIMCUIn6oNxEPGtTWFFR0RUy7iGzt+3Ip0XURXVZKPvVCfIKczyB+vyzqLzoGzcuIG0MGTyCztjRtjaJjbHVMNAUTdu1PUhz0vYhryLOcSwXMthBfK0ZGsLQGBZekCi0Jso1IdI23WG04zOE4wIg6coIgBox3Imdi1JRdnxNOxSHNSQkWtW0mTjMxMQ7fDzgcbNKn7WjKJeN4Pi+MAfj+e84MfUMFHbZZwxOHZNDyO09gQOQjmAhZJCM9IMjIycKOvQUwCCbBiAAI2sshpNkiB6NLJ9EIQBQbWOdJlMhYCUjbJkchXGsFmsJQMVsWl3BzKp4GiHoAXgjykgAWmkZZ6xy3LZF2EobCy6xsQWJQ42kE4FjA-EwBSxTjSRUhDgqkzgO2BxdykU4AvXFQ-KjMC8yHKV6qNJi6WOdcypcZsXGxe0JG0XySKjM5lKsMyLwsiAxsYzylDfONznUEqrmi+1ThkHqXDONbULi1wgA */ id: "node",
        context: ({ input })=>({
                buffer: [],
                channelId: null,
                connectTo: input.connectTo,
                domain: input.domain ?? DOMAIN,
                handshakeBuffer: [],
                name: input.name,
                requests: [],
                target: void 0,
                targetOrigin: null
            }),
        // Always listen for handshake syn messages. The channel could have
        // disconnected without being able to notify the node, and so need to
        // re-establish the connection.
        invoke: {
            id: "listen for handshake syn",
            src: "listen",
            input: listenInputFromContext({
                include: MSG_HANDSHAKE_SYN,
                responseType: "handshake.syn"
            })
        },
        on: {
            "request.success": {
                actions: "remove request"
            },
            "request.failed": {
                actions: "remove request"
            },
            "request.aborted": {
                actions: "remove request"
            },
            "handshake.syn": {
                actions: "set connection config",
                target: ".handshaking"
            }
        },
        initial: "idle",
        states: {
            idle: {
                entry: [
                    {
                        type: "emit status",
                        params: {
                            status: "idle"
                        }
                    }
                ],
                on: {
                    post: {
                        actions: "buffer message"
                    }
                }
            },
            handshaking: {
                guard: "hasSource",
                entry: [
                    "send handshake syn ack",
                    {
                        type: "emit status",
                        params: {
                            status: "handshaking"
                        }
                    }
                ],
                invoke: [
                    {
                        id: "listen for handshake ack",
                        src: "listen",
                        input: listenInputFromContext({
                            include: MSG_HANDSHAKE_ACK,
                            count: 1,
                            // Override the default `message.received` responseType to prevent
                            // buffering the ack message. We transition to the connected state
                            // using onDone instead of listening to this event using `on`
                            responseType: "handshake.complete"
                        }),
                        onDone: "connected"
                    },
                    {
                        id: "listen for disconnect",
                        src: "listen",
                        input: listenInputFromContext({
                            include: MSG_DISCONNECT,
                            count: 1,
                            responseType: "disconnect"
                        })
                    },
                    {
                        id: "listen for messages",
                        src: "listen",
                        input: listenInputFromContext({
                            exclude: [
                                MSG_DISCONNECT,
                                MSG_HANDSHAKE_SYN,
                                MSG_HANDSHAKE_ACK,
                                MSG_HEARTBEAT,
                                MSG_RESPONSE
                            ]
                        })
                    }
                ],
                on: {
                    request: {
                        actions: "create request"
                    },
                    post: {
                        actions: "buffer message"
                    },
                    "message.received": {
                        actions: "buffer handshake"
                    },
                    disconnect: {
                        target: "idle"
                    }
                }
            },
            connected: {
                entry: [
                    "process pending handshakes",
                    "send pending messages",
                    {
                        type: "emit status",
                        params: {
                            status: "connected"
                        }
                    }
                ],
                invoke: [
                    {
                        id: "listen for messages",
                        src: "listen",
                        input: listenInputFromContext({
                            exclude: [
                                MSG_DISCONNECT,
                                MSG_HANDSHAKE_SYN,
                                MSG_HANDSHAKE_ACK,
                                MSG_HEARTBEAT,
                                MSG_RESPONSE
                            ]
                        })
                    },
                    {
                        id: "listen for heartbeat",
                        src: "listen",
                        input: listenInputFromContext({
                            include: MSG_HEARTBEAT,
                            responseType: "heartbeat.received"
                        })
                    },
                    {
                        id: "listen for disconnect",
                        src: "listen",
                        input: listenInputFromContext({
                            include: MSG_DISCONNECT,
                            count: 1,
                            responseType: "disconnect"
                        })
                    }
                ],
                on: {
                    request: {
                        actions: "create request"
                    },
                    post: {
                        actions: "post message"
                    },
                    disconnect: {
                        target: "idle"
                    },
                    "message.received": {
                        actions: [
                            "send response",
                            "emit received message"
                        ]
                    },
                    "heartbeat.received": {
                        actions: [
                            "send response",
                            "emit heartbeat"
                        ]
                    }
                }
            }
        }
    }), createNode = (input, machine = createNodeMachine())=>{
    const actor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$b724c245$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c__as__createActor$3e$__["createActor"])(machine, {
        input
    }), eventHandlers = /* @__PURE__ */ new Map(), unhandledMessages = /* @__PURE__ */ new Map(), on = (type, handler, options)=>{
        const handlers = eventHandlers.get(type) || /* @__PURE__ */ new Set();
        eventHandlers.has(type) || eventHandlers.set(type, handlers), handlers.add(handler);
        const unhandledMessagesForType = unhandledMessages.get(type);
        if (unhandledMessagesForType) {
            const replayCount = options?.replay ?? 1;
            Array.from(unhandledMessagesForType).slice(-replayCount).forEach(({ data })=>handler(data)), unhandledMessages.delete(type);
        }
        return ()=>{
            handlers.delete(handler);
        };
    };
    let cachedStatus;
    const onStatus = (handler, filter2)=>{
        const subscription = actor.on("status", (event)=>{
            cachedStatus = event.status, !(filter2 && event.status !== filter2) && handler(event.status);
        });
        return cachedStatus && handler(cachedStatus), ()=>subscription.unsubscribe();
    }, post = (type, data)=>{
        const _data = {
            type,
            data
        };
        actor.send({
            type: "post",
            data: _data
        });
    }, fetch = (type, data, options)=>{
        const { responseTimeout = FETCH_TIMEOUT_DEFAULT, signal, suppressWarnings } = options || {}, resolvable = createPromiseWithResolvers(), _data = {
            type,
            data
        };
        return actor.send({
            type: "post",
            data: _data,
            resolvable,
            options: {
                responseTimeout,
                signal,
                suppressWarnings
            }
        }), resolvable.promise;
    };
    actor.on("message", ({ message })=>{
        const handlers = eventHandlers.get(message.type);
        if (handlers) {
            handlers.forEach((handler)=>handler(message.data));
            return;
        }
        const unhandledMessagesForType = unhandledMessages.get(message.type);
        unhandledMessagesForType ? unhandledMessagesForType.add(message) : unhandledMessages.set(message.type, /* @__PURE__ */ new Set([
            message
        ]));
    });
    const stop = ()=>{
        actor.stop();
    };
    return {
        actor,
        fetch,
        machine,
        on,
        onStatus,
        post,
        start: ()=>(actor.start(), stop),
        stop
    };
};
;
}),
"[project]/node_modules/@sanity/presentation-comlink/dist/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createCompatibilityActors",
    ()=>createCompatibilityActors,
    "isMaybePresentation",
    ()=>isMaybePresentation,
    "isMaybePreviewIframe",
    ()=>isMaybePreviewIframe,
    "isMaybePreviewWindow",
    ()=>isMaybePreviewWindow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/comlink/dist/index.js [app-client] (ecmascript)");
;
;
const channelsToComlinkMap = {
    "handshake/syn": __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MSG_HANDSHAKE_SYN"],
    "handshake/syn-ack": __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MSG_HANDSHAKE_SYN_ACK"],
    "handshake/ack": __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MSG_HANDSHAKE_ACK"],
    "channel/response": __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MSG_RESPONSE"],
    "channel/heartbeat": __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MSG_HEARTBEAT"],
    "channel/disconnect": __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MSG_DISCONNECT"],
    "overlay/focus": "visual-editing/focus",
    "overlay/navigate": "visual-editing/navigate",
    "overlay/toggle": "visual-editing/toggle",
    "presentation/toggleOverlay": "presentation/toggle-overlay"
}, comlinkToChannelsMap = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MSG_HANDSHAKE_SYN"]]: "handshake/syn",
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MSG_HANDSHAKE_SYN_ACK"]]: "handshake/syn-ack",
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MSG_HANDSHAKE_ACK"]]: "handshake/ack",
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MSG_RESPONSE"]]: "channel/response",
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MSG_HEARTBEAT"]]: "channel/heartbeat",
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MSG_DISCONNECT"]]: "channel/disconnect",
    "visual-editing/focus": "overlay/focus",
    "visual-editing/navigate": "overlay/navigate",
    "visual-editing/toggle": "overlay/toggle",
    "presentation/toggle-overlay": "presentation/toggleOverlay"
}, convertToComlinkEvent = (event)=>{
    const { data } = event;
    return data && typeof data == "object" && "domain" in data && "type" in data && "from" in data && "to" in data && (data.domain === "sanity/channels" && (data.domain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DOMAIN"]), data.to === "overlays" && (data.to = "visual-editing"), data.from === "overlays" && (data.from = "visual-editing"), data.channelId = data.connectionId, delete data.connectionId, data.type = channelsToComlinkMap[data.type] ?? data.type), event;
}, convertToChannelsMessage = (comlinkMessage)=>{
    const { channelId, ...rest } = comlinkMessage, message = {
        ...rest,
        connectionId: channelId
    };
    return message.domain === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DOMAIN"] && (message.domain = "sanity/channels"), message.to === "visual-editing" && (message.to = "overlays"), message.from === "visual-editing" && (message.from = "overlays"), message.type = comlinkToChannelsMap[message.type] ?? message.type, message.type === "channel/response" && message.responseTo && !message.data && (message.data = {
        responseTo: message.responseTo
    }), (message.type === "handshake/syn" || message.type === "handshake/syn-ack" || message.type === "handshake/ack") && (message.data = {
        id: message.connectionId
    }), message;
}, sendAsChannelsMessage = ({ context }, params)=>{
    const { sources, targetOrigin } = context, message = convertToChannelsMessage(params.message);
    sources.forEach((source)=>{
        source.postMessage(message, {
            targetOrigin
        });
    });
}, createCompatibilityActors = ()=>({
        listen: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createListenLogic"])(convertToComlinkEvent),
        requestMachine: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$comlink$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRequestMachine"])().provide({
            actions: {
                "send message": sendAsChannelsMessage
            }
        })
    });
function isMaybePreviewIframe() {
    return window.self !== window.top;
}
function isMaybePreviewWindow() {
    return !!window.opener;
}
function isMaybePresentation() {
    return isMaybePreviewIframe() || isMaybePreviewWindow();
}
;
}),
"[project]/node_modules/@sanity/client/dist/_chunks-es/isRecord.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isRecord",
    ()=>isRecord
]);
function isRecord(value) {
    return typeof value == "object" && value !== null && !Array.isArray(value);
}
;
}),
"[project]/node_modules/@sanity/client/dist/_chunks-es/resolveEditInfo.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DRAFTS_FOLDER",
    ()=>DRAFTS_FOLDER,
    "VERSION_FOLDER",
    ()=>VERSION_FOLDER,
    "createEditUrl",
    ()=>createEditUrl,
    "get",
    ()=>get,
    "getDraftId",
    ()=>getDraftId,
    "getPublishedId",
    ()=>getPublishedId,
    "getVersionFromId",
    ()=>getVersionFromId,
    "getVersionId",
    ()=>getVersionId,
    "isDraftId",
    ()=>isDraftId,
    "isPublishedId",
    ()=>isPublishedId,
    "isVersionId",
    ()=>isVersionId,
    "jsonPath",
    ()=>jsonPath,
    "jsonPathToStudioPath",
    ()=>jsonPathToStudioPath,
    "parseJsonPath",
    ()=>parseJsonPath,
    "reKeySegment",
    ()=>reKeySegment,
    "resolveEditInfo",
    ()=>resolveEditInfo,
    "resolveMapping",
    ()=>resolveMapping,
    "resolveStudioBaseRoute",
    ()=>resolveStudioBaseRoute,
    "studioPath",
    ()=>studioPath,
    "studioPathToJsonPath",
    ()=>studioPathToJsonPath,
    "toString",
    ()=>toString,
    "walkMap",
    ()=>walkMap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$isRecord$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/client/dist/_chunks-es/isRecord.js [app-client] (ecmascript)");
;
const rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g, reKeySegment = /_key\s*==\s*['"](.*)['"]/, reIndexTuple = /^\d*:\d*$/;
function isIndexSegment(segment) {
    return typeof segment == "number" || typeof segment == "string" && /^\[\d+\]$/.test(segment);
}
function isKeySegment(segment) {
    return typeof segment == "string" ? reKeySegment.test(segment.trim()) : typeof segment == "object" && "_key" in segment;
}
function isIndexTuple(segment) {
    if (typeof segment == "string" && reIndexTuple.test(segment)) return !0;
    if (!Array.isArray(segment) || segment.length !== 2) return !1;
    const [from, to] = segment;
    return (typeof from == "number" || from === "") && (typeof to == "number" || to === "");
}
function get(obj, path, defaultVal) {
    const select = typeof path == "string" ? fromString(path) : path;
    if (!Array.isArray(select)) throw new Error("Path must be an array or a string");
    let acc = obj;
    for(let i = 0; i < select.length; i++){
        const segment = select[i];
        if (isIndexSegment(segment)) {
            if (!Array.isArray(acc)) return defaultVal;
            acc = acc[segment];
        }
        if (isKeySegment(segment)) {
            if (!Array.isArray(acc)) return defaultVal;
            acc = acc.find((item)=>item._key === segment._key);
        }
        if (typeof segment == "string" && (acc = typeof acc == "object" && acc !== null ? acc[segment] : void 0), typeof acc > "u") return defaultVal;
    }
    return acc;
}
function toString(path) {
    if (!Array.isArray(path)) throw new Error("Path is not an array");
    return path.reduce((target, segment, i)=>{
        const segmentType = typeof segment;
        if (segmentType === "number") return `${target}[${segment}]`;
        if (segmentType === "string") return `${target}${i === 0 ? "" : "."}${segment}`;
        if (isKeySegment(segment) && segment._key) return `${target}[_key=="${segment._key}"]`;
        if (Array.isArray(segment)) {
            const [from, to] = segment;
            return `${target}[${from}:${to}]`;
        }
        throw new Error(`Unsupported path segment \`${JSON.stringify(segment)}\``);
    }, "");
}
function fromString(path) {
    if (typeof path != "string") throw new Error("Path is not a string");
    const segments = path.match(rePropName);
    if (!segments) throw new Error("Invalid path string");
    return segments.map(parsePathSegment);
}
function parsePathSegment(segment) {
    return isIndexSegment(segment) ? parseIndexSegment(segment) : isKeySegment(segment) ? parseKeySegment(segment) : isIndexTuple(segment) ? parseIndexTupleSegment(segment) : segment;
}
function parseIndexSegment(segment) {
    return Number(segment.replace(/[^\d]/g, ""));
}
function parseKeySegment(segment) {
    return {
        _key: segment.match(reKeySegment)[1]
    };
}
function parseIndexTupleSegment(segment) {
    const [from, to] = segment.split(":").map((seg)=>seg === "" ? seg : Number(seg));
    return [
        from,
        to
    ];
}
var studioPath = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    fromString,
    get,
    isIndexSegment,
    isIndexTuple,
    isKeySegment,
    reKeySegment,
    toString
});
const DRAFTS_FOLDER = "drafts", VERSION_FOLDER = "versions", PATH_SEPARATOR = ".", DRAFTS_PREFIX = `${DRAFTS_FOLDER}${PATH_SEPARATOR}`, VERSION_PREFIX = `${VERSION_FOLDER}${PATH_SEPARATOR}`;
function isDraftId(id) {
    return id.startsWith(DRAFTS_PREFIX);
}
function isVersionId(id) {
    return id.startsWith(VERSION_PREFIX);
}
function isPublishedId(id) {
    return !isDraftId(id) && !isVersionId(id);
}
function getDraftId(id) {
    if (isVersionId(id)) {
        const publishedId = getPublishedId(id);
        return DRAFTS_PREFIX + publishedId;
    }
    return isDraftId(id) ? id : DRAFTS_PREFIX + id;
}
function getVersionId(id, version) {
    if (version === "drafts" || version === "published") throw new Error('Version can not be "published" or "drafts"');
    return `${VERSION_PREFIX}${version}${PATH_SEPARATOR}${getPublishedId(id)}`;
}
function getVersionFromId(id) {
    if (!isVersionId(id)) return;
    const [_versionPrefix, versionId] = id.split(PATH_SEPARATOR);
    return versionId;
}
function getPublishedId(id) {
    return isVersionId(id) ? id.split(PATH_SEPARATOR).slice(2).join(PATH_SEPARATOR) : isDraftId(id) ? id.slice(DRAFTS_PREFIX.length) : id;
}
const ESCAPE = {
    "\f": "\\f",
    "\n": "\\n",
    "\r": "\\r",
    "	": "\\t",
    "'": "\\'",
    "\\": "\\\\"
}, UNESCAPE = {
    "\\f": "\f",
    "\\n": `
`,
    "\\r": "\r",
    "\\t": "	",
    "\\'": "'",
    "\\\\": "\\"
};
function jsonPath(path) {
    return `$${path.map((segment)=>typeof segment == "string" ? `['${segment.replace(/[\f\n\r\t'\\]/g, (match)=>ESCAPE[match])}']` : typeof segment == "number" ? `[${segment}]` : segment._key !== "" ? `[?(@._key=='${segment._key.replace(/['\\]/g, (match)=>ESCAPE[match])}')]` : `[${segment._index}]`).join("")}`;
}
function jsonPathArray(path) {
    return path.map((segment)=>typeof segment == "string" ? `['${segment.replace(/[\f\n\r\t'\\]/g, (match)=>ESCAPE[match])}']` : typeof segment == "number" ? `[${segment}]` : segment._key !== "" ? `[?(@._key=='${segment._key.replace(/['\\]/g, (match)=>ESCAPE[match])}')]` : `[${segment._index}]`);
}
function parseJsonPath(path) {
    const parsed = [], parseRe = /\['(.*?)'\]|\[(\d+)\]|\[\?\(@\._key=='(.*?)'\)\]/g;
    let match;
    for(; (match = parseRe.exec(path)) !== null;){
        if (match[1] !== void 0) {
            const key = match[1].replace(/\\(\\|f|n|r|t|')/g, (m)=>UNESCAPE[m]);
            parsed.push(key);
            continue;
        }
        if (match[2] !== void 0) {
            parsed.push(parseInt(match[2], 10));
            continue;
        }
        if (match[3] !== void 0) {
            const _key = match[3].replace(/\\(\\')/g, (m)=>UNESCAPE[m]);
            parsed.push({
                _key,
                _index: -1
            });
            continue;
        }
    }
    return parsed;
}
function jsonPathToStudioPath(path) {
    return path.map((segment)=>{
        if (typeof segment == "string" || typeof segment == "number") return segment;
        if (segment._key !== "") return {
            _key: segment._key
        };
        if (segment._index !== -1) return segment._index;
        throw new Error(`invalid segment:${JSON.stringify(segment)}`);
    });
}
function studioPathToJsonPath(path) {
    return (typeof path == "string" ? fromString(path) : path).map((segment)=>{
        if (typeof segment == "string" || typeof segment == "number") return segment;
        if (Array.isArray(segment)) throw new Error(`IndexTuple segments aren't supported:${JSON.stringify(segment)}`);
        if (isContentSourceMapParsedPathKeyedSegment(segment)) return segment;
        if (segment._key) return {
            _key: segment._key,
            _index: -1
        };
        throw new Error(`invalid segment:${JSON.stringify(segment)}`);
    });
}
function isContentSourceMapParsedPathKeyedSegment(segment) {
    return typeof segment == "object" && "_key" in segment && "_index" in segment;
}
function jsonPathToMappingPath(path) {
    return path.map((segment)=>{
        if (typeof segment == "string" || typeof segment == "number") return segment;
        if (segment._index !== -1) return segment._index;
        throw new Error(`invalid segment:${JSON.stringify(segment)}`);
    });
}
function resolveMapping(resultPath, csm) {
    if (!csm?.mappings) return;
    const resultMappingPath = jsonPath(jsonPathToMappingPath(resultPath));
    if (csm.mappings[resultMappingPath] !== void 0) return {
        mapping: csm.mappings[resultMappingPath],
        matchedPath: resultMappingPath,
        pathSuffix: ""
    };
    const resultMappingPathArray = jsonPathArray(jsonPathToMappingPath(resultPath));
    for(let i = resultMappingPathArray.length - 1; i >= 0; i--){
        const key = `$${resultMappingPathArray.slice(0, i).join("")}`, mappingFound = csm.mappings[key];
        if (mappingFound) {
            const pathSuffix = resultMappingPath.substring(key.length);
            return {
                mapping: mappingFound,
                matchedPath: key,
                pathSuffix
            };
        }
    }
}
function isArray(value) {
    return value !== null && Array.isArray(value);
}
function walkMap(value, mappingFn, path = []) {
    if (isArray(value)) return value.map((v, idx)=>{
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$isRecord$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isRecord"])(v)) {
            const _key = v._key;
            if (typeof _key == "string") return walkMap(v, mappingFn, path.concat({
                _key,
                _index: idx
            }));
        }
        return walkMap(v, mappingFn, path.concat(idx));
    });
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$isRecord$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isRecord"])(value)) {
        if (value._type === "block" || value._type === "span") {
            const result = {
                ...value
            };
            return value._type === "block" ? result.children = walkMap(value.children, mappingFn, path.concat("children")) : value._type === "span" && (result.text = walkMap(value.text, mappingFn, path.concat("text"))), result;
        }
        return Object.fromEntries(Object.entries(value).map(([k, v])=>[
                k,
                walkMap(v, mappingFn, path.concat(k))
            ]));
    }
    return mappingFn(value, path);
}
function createEditUrl(options) {
    const { baseUrl, workspace: _workspace = "default", tool: _tool = "default", id: _id, type, path, projectId, dataset } = options;
    if (!baseUrl) throw new Error("baseUrl is required");
    if (!path) throw new Error("path is required");
    if (!_id) throw new Error("id is required");
    if (baseUrl !== "/" && baseUrl.endsWith("/")) throw new Error("baseUrl must not end with a slash");
    const workspace = _workspace === "default" ? void 0 : _workspace, tool = _tool === "default" ? void 0 : _tool, id = getPublishedId(_id), stringifiedPath = Array.isArray(path) ? toString(jsonPathToStudioPath(path)) : path, searchParams = new URLSearchParams({
        baseUrl,
        id,
        type,
        path: stringifiedPath
    });
    if (workspace && searchParams.set("workspace", workspace), tool && searchParams.set("tool", tool), projectId && searchParams.set("projectId", projectId), dataset && searchParams.set("dataset", dataset), isPublishedId(_id)) searchParams.set("perspective", "published");
    else if (isVersionId(_id)) {
        const versionId = getVersionFromId(_id);
        searchParams.set("perspective", versionId);
    }
    const segments = [
        baseUrl === "/" ? "" : baseUrl
    ];
    workspace && segments.push(workspace);
    const routerParams = [
        "mode=presentation",
        `id=${id}`,
        `type=${type}`,
        `path=${encodeURIComponent(stringifiedPath)}`
    ];
    return tool && routerParams.push(`tool=${tool}`), segments.push("intent", "edit", `${routerParams.join(";")}?${searchParams}`), segments.join("/");
}
function resolveEditInfo(options) {
    const { resultSourceMap: csm, resultPath } = options, { mapping, pathSuffix } = resolveMapping(resultPath, csm) || {};
    if (!mapping || mapping.source.type === "literal" || mapping.source.type === "unknown") return;
    const sourceDoc = csm.documents[mapping.source.document], sourcePath = csm.paths[mapping.source.path];
    if (sourceDoc && sourcePath) {
        const { baseUrl, workspace, tool } = resolveStudioBaseRoute(typeof options.studioUrl == "function" ? options.studioUrl(sourceDoc) : options.studioUrl);
        if (!baseUrl) return;
        const { _id, _type, _projectId, _dataset } = sourceDoc;
        return {
            baseUrl,
            workspace,
            tool,
            id: _id,
            type: _type,
            path: parseJsonPath(sourcePath + pathSuffix),
            projectId: _projectId,
            dataset: _dataset
        };
    }
}
function resolveStudioBaseRoute(studioUrl) {
    let baseUrl = typeof studioUrl == "string" ? studioUrl : studioUrl.baseUrl;
    return baseUrl !== "/" && (baseUrl = baseUrl.replace(/\/$/, "")), typeof studioUrl == "string" ? {
        baseUrl
    } : {
        ...studioUrl,
        baseUrl
    };
}
;
}),
"[project]/node_modules/@sanity/client/dist/_chunks-es/stegaClean.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isRecord",
    ()=>isRecord,
    "stegaClean",
    ()=>stegaClean,
    "vercelStegaCleanAll",
    ()=>vercelStegaCleanAll,
    "y",
    ()=>y
]);
function isRecord(value) {
    return typeof value == "object" && value !== null && !Array.isArray(value);
}
var p = {
    0: 8203,
    1: 8204,
    2: 8205,
    3: 8290,
    4: 8291,
    5: 8288,
    6: 65279,
    7: 8289,
    8: 119155,
    9: 119156,
    a: 119157,
    b: 119158,
    c: 119159,
    d: 119160,
    e: 119161,
    f: 119162
}, l = {
    0: 8203,
    1: 8204,
    2: 8205,
    3: 65279
}, d = {
    0: String.fromCodePoint(l[0]),
    1: String.fromCodePoint(l[1]),
    2: String.fromCodePoint(l[2]),
    3: String.fromCodePoint(l[3])
}, u = new Array(4).fill(String.fromCodePoint(l[0])).join("");
function A(e) {
    let r = JSON.stringify(e), t = new TextEncoder().encode(r), i = "";
    for(let c = 0; c < t.length; c++){
        let n = t[c];
        i += d[n >> 6 & 3] + d[n >> 4 & 3] + d[n >> 2 & 3] + d[n & 3];
    }
    return u + i;
}
function I(e) {
    return !Number.isNaN(Number(e)) || /[a-z]/i.test(e) && !/\d+(?:[-:\/]\d+){2}(?:T\d+(?:[-:\/]\d+){1,2}(\.\d+)?Z?)?/.test(e) ? !1 : !!Date.parse(e);
}
function S(e) {
    try {
        new URL(e, e.startsWith("/") ? "https://acme.com" : void 0);
    } catch  {
        return !1;
    }
    return !0;
}
function y(e, r, t = "auto") {
    return t === !0 || t === "auto" && (I(e) || S(e)) ? e : `${e}${A(r)}`;
}
Object.fromEntries(Object.entries(d).map((e)=>[
        e[1],
        +e[0]
    ]));
Object.fromEntries(Object.entries(p).map((e)=>e.reverse()));
var h = `${Object.values(p).map((e)=>`\\u{${e.toString(16)}}`).join("")}`, x = new RegExp(`[${h}]{4,}`, "gu");
function P(e) {
    var r;
    return {
        cleaned: e.replace(x, ""),
        encoded: ((r = e.match(x)) == null ? void 0 : r[0]) || ""
    };
}
function w(e) {
    return e && JSON.parse(P(JSON.stringify(e)).cleaned);
}
function stegaClean(result) {
    return w(result);
}
const vercelStegaCleanAll = stegaClean;
;
}),
"[project]/node_modules/@sanity/client/dist/_chunks-es/stegaEncodeSourceMap.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "encodeIntoResult",
    ()=>encodeIntoResult,
    "stegaEncodeSourceMap",
    ()=>stegaEncodeSourceMap,
    "stegaEncodeSourceMap$1",
    ()=>stegaEncodeSourceMap$1
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$stegaClean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/client/dist/_chunks-es/stegaClean.js [app-client] (ecmascript)");
;
const reKeySegment = /_key\s*==\s*['"](.*)['"]/;
function isKeySegment(segment) {
    return typeof segment == "string" ? reKeySegment.test(segment.trim()) : typeof segment == "object" && "_key" in segment;
}
function toString(path) {
    if (!Array.isArray(path)) throw new Error("Path is not an array");
    return path.reduce((target, segment, i)=>{
        const segmentType = typeof segment;
        if (segmentType === "number") return `${target}[${segment}]`;
        if (segmentType === "string") return `${target}${i === 0 ? "" : "."}${segment}`;
        if (isKeySegment(segment) && segment._key) return `${target}[_key=="${segment._key}"]`;
        if (Array.isArray(segment)) {
            const [from, to] = segment;
            return `${target}[${from}:${to}]`;
        }
        throw new Error(`Unsupported path segment \`${JSON.stringify(segment)}\``);
    }, "");
}
const ESCAPE = {
    "\f": "\\f",
    "\n": "\\n",
    "\r": "\\r",
    "	": "\\t",
    "'": "\\'",
    "\\": "\\\\"
}, UNESCAPE = {
    "\\f": "\f",
    "\\n": `
`,
    "\\r": "\r",
    "\\t": "	",
    "\\'": "'",
    "\\\\": "\\"
};
function jsonPath(path) {
    return `$${path.map((segment)=>typeof segment == "string" ? `['${segment.replace(/[\f\n\r\t'\\]/g, (match)=>ESCAPE[match])}']` : typeof segment == "number" ? `[${segment}]` : segment._key !== "" ? `[?(@._key=='${segment._key.replace(/['\\]/g, (match)=>ESCAPE[match])}')]` : `[${segment._index}]`).join("")}`;
}
function jsonPathArray(path) {
    return path.map((segment)=>typeof segment == "string" ? `['${segment.replace(/[\f\n\r\t'\\]/g, (match)=>ESCAPE[match])}']` : typeof segment == "number" ? `[${segment}]` : segment._key !== "" ? `[?(@._key=='${segment._key.replace(/['\\]/g, (match)=>ESCAPE[match])}')]` : `[${segment._index}]`);
}
function parseJsonPath(path) {
    const parsed = [], parseRe = /\['(.*?)'\]|\[(\d+)\]|\[\?\(@\._key=='(.*?)'\)\]/g;
    let match;
    for(; (match = parseRe.exec(path)) !== null;){
        if (match[1] !== void 0) {
            const key = match[1].replace(/\\(\\|f|n|r|t|')/g, (m)=>UNESCAPE[m]);
            parsed.push(key);
            continue;
        }
        if (match[2] !== void 0) {
            parsed.push(parseInt(match[2], 10));
            continue;
        }
        if (match[3] !== void 0) {
            const _key = match[3].replace(/\\(\\')/g, (m)=>UNESCAPE[m]);
            parsed.push({
                _key,
                _index: -1
            });
            continue;
        }
    }
    return parsed;
}
function jsonPathToStudioPath(path) {
    return path.map((segment)=>{
        if (typeof segment == "string" || typeof segment == "number") return segment;
        if (segment._key !== "") return {
            _key: segment._key
        };
        if (segment._index !== -1) return segment._index;
        throw new Error(`invalid segment:${JSON.stringify(segment)}`);
    });
}
function jsonPathToMappingPath(path) {
    return path.map((segment)=>{
        if (typeof segment == "string" || typeof segment == "number") return segment;
        if (segment._index !== -1) return segment._index;
        throw new Error(`invalid segment:${JSON.stringify(segment)}`);
    });
}
function resolveMapping(resultPath, csm) {
    if (!csm?.mappings) return;
    const resultMappingPath = jsonPath(jsonPathToMappingPath(resultPath));
    if (csm.mappings[resultMappingPath] !== void 0) return {
        mapping: csm.mappings[resultMappingPath],
        matchedPath: resultMappingPath,
        pathSuffix: ""
    };
    const resultMappingPathArray = jsonPathArray(jsonPathToMappingPath(resultPath));
    for(let i = resultMappingPathArray.length - 1; i >= 0; i--){
        const key = `$${resultMappingPathArray.slice(0, i).join("")}`, mappingFound = csm.mappings[key];
        if (mappingFound) {
            const pathSuffix = resultMappingPath.substring(key.length);
            return {
                mapping: mappingFound,
                matchedPath: key,
                pathSuffix
            };
        }
    }
}
function isArray(value) {
    return value !== null && Array.isArray(value);
}
function walkMap(value, mappingFn, path = []) {
    if (isArray(value)) return value.map((v, idx)=>{
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$stegaClean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isRecord"])(v)) {
            const _key = v._key;
            if (typeof _key == "string") return walkMap(v, mappingFn, path.concat({
                _key,
                _index: idx
            }));
        }
        return walkMap(v, mappingFn, path.concat(idx));
    });
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$stegaClean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isRecord"])(value)) {
        if (value._type === "block" || value._type === "span") {
            const result = {
                ...value
            };
            return value._type === "block" ? result.children = walkMap(value.children, mappingFn, path.concat("children")) : value._type === "span" && (result.text = walkMap(value.text, mappingFn, path.concat("text"))), result;
        }
        return Object.fromEntries(Object.entries(value).map(([k, v])=>[
                k,
                walkMap(v, mappingFn, path.concat(k))
            ]));
    }
    return mappingFn(value, path);
}
function encodeIntoResult(result, csm, encoder) {
    return walkMap(result, (value, path)=>{
        if (typeof value != "string") return value;
        const resolveMappingResult = resolveMapping(path, csm);
        if (!resolveMappingResult) return value;
        const { mapping, matchedPath } = resolveMappingResult;
        if (mapping.type !== "value" || mapping.source.type !== "documentValue") return value;
        const sourceDocument = csm.documents[mapping.source.document], sourcePath = csm.paths[mapping.source.path], matchPathSegments = parseJsonPath(matchedPath), fullSourceSegments = parseJsonPath(sourcePath).concat(path.slice(matchPathSegments.length));
        return encoder({
            sourcePath: fullSourceSegments,
            sourceDocument,
            resultPath: path,
            value
        });
    });
}
const DRAFTS_FOLDER = "drafts", VERSION_FOLDER = "versions", PATH_SEPARATOR = ".", DRAFTS_PREFIX = `${DRAFTS_FOLDER}${PATH_SEPARATOR}`, VERSION_PREFIX = `${VERSION_FOLDER}${PATH_SEPARATOR}`;
function isDraftId(id) {
    return id.startsWith(DRAFTS_PREFIX);
}
function isVersionId(id) {
    return id.startsWith(VERSION_PREFIX);
}
function isPublishedId(id) {
    return !isDraftId(id) && !isVersionId(id);
}
function getVersionFromId(id) {
    if (!isVersionId(id)) return;
    const [_versionPrefix, versionId] = id.split(PATH_SEPARATOR);
    return versionId;
}
function getPublishedId(id) {
    return isVersionId(id) ? id.split(PATH_SEPARATOR).slice(2).join(PATH_SEPARATOR) : isDraftId(id) ? id.slice(DRAFTS_PREFIX.length) : id;
}
function createEditUrl(options) {
    const { baseUrl, workspace: _workspace = "default", tool: _tool = "default", id: _id, type, path, projectId, dataset } = options;
    if (!baseUrl) throw new Error("baseUrl is required");
    if (!path) throw new Error("path is required");
    if (!_id) throw new Error("id is required");
    if (baseUrl !== "/" && baseUrl.endsWith("/")) throw new Error("baseUrl must not end with a slash");
    const workspace = _workspace === "default" ? void 0 : _workspace, tool = _tool === "default" ? void 0 : _tool, id = getPublishedId(_id), stringifiedPath = Array.isArray(path) ? toString(jsonPathToStudioPath(path)) : path, searchParams = new URLSearchParams({
        baseUrl,
        id,
        type,
        path: stringifiedPath
    });
    if (workspace && searchParams.set("workspace", workspace), tool && searchParams.set("tool", tool), projectId && searchParams.set("projectId", projectId), dataset && searchParams.set("dataset", dataset), isPublishedId(_id)) searchParams.set("perspective", "published");
    else if (isVersionId(_id)) {
        const versionId = getVersionFromId(_id);
        searchParams.set("perspective", versionId);
    }
    const segments = [
        baseUrl === "/" ? "" : baseUrl
    ];
    workspace && segments.push(workspace);
    const routerParams = [
        "mode=presentation",
        `id=${id}`,
        `type=${type}`,
        `path=${encodeURIComponent(stringifiedPath)}`
    ];
    return tool && routerParams.push(`tool=${tool}`), segments.push("intent", "edit", `${routerParams.join(";")}?${searchParams}`), segments.join("/");
}
function resolveStudioBaseRoute(studioUrl) {
    let baseUrl = typeof studioUrl == "string" ? studioUrl : studioUrl.baseUrl;
    return baseUrl !== "/" && (baseUrl = baseUrl.replace(/\/$/, "")), typeof studioUrl == "string" ? {
        baseUrl
    } : {
        ...studioUrl,
        baseUrl
    };
}
const filterDefault = ({ sourcePath, resultPath, value })=>{
    if (isValidDate(value) || isValidURL(value)) return !1;
    const endPath = sourcePath.at(-1);
    return !(sourcePath.at(-2) === "slug" && endPath === "current" || typeof endPath == "string" && (endPath.startsWith("_") || endPath.endsWith("Id")) || sourcePath.some((path)=>path === "meta" || path === "metadata" || path === "openGraph" || path === "seo") || hasTypeLike(sourcePath) || hasTypeLike(resultPath) || typeof endPath == "string" && denylist.has(endPath));
}, denylist = /* @__PURE__ */ new Set([
    "color",
    "colour",
    "currency",
    "email",
    "format",
    "gid",
    "hex",
    "href",
    "hsl",
    "hsla",
    "icon",
    "id",
    "index",
    "key",
    "language",
    "layout",
    "link",
    "linkAction",
    "locale",
    "lqip",
    "page",
    "path",
    "ref",
    "rgb",
    "rgba",
    "route",
    "secret",
    "slug",
    "status",
    "tag",
    "template",
    "theme",
    "type",
    "textTheme",
    "unit",
    "url",
    "username",
    "variant",
    "website"
]);
function isValidDate(dateString) {
    return /^\d{4}-\d{2}-\d{2}/.test(dateString) ? !!Date.parse(dateString) : !1;
}
const allowedProtocols = /* @__PURE__ */ new Set([
    "app:",
    "data:",
    "discord:",
    "file:",
    "ftp:",
    "ftps:",
    "geo:",
    "http:",
    "https:",
    "imap:",
    "javascript:",
    "magnet:",
    "mailto:",
    "maps:",
    "ms-excel:",
    "ms-powerpoint:",
    "ms-word:",
    "slack:",
    "sms:",
    "spotify:",
    "steam:",
    "teams:",
    "tel:",
    "vscode:",
    "zoom:"
]);
function isValidURL(url) {
    try {
        const { protocol } = new URL(url, url.startsWith("/") ? "https://acme.com" : void 0);
        return allowedProtocols.has(protocol) || protocol.startsWith("web+");
    } catch  {
        return !1;
    }
}
function hasTypeLike(path) {
    return path.some((segment)=>typeof segment == "string" && segment.match(/type/i) !== null);
}
const TRUNCATE_LENGTH = 20;
function stegaEncodeSourceMap(result, resultSourceMap, config) {
    const { filter, logger, enabled } = config;
    if (!enabled) {
        const msg = "config.enabled must be true, don't call this function otherwise";
        throw logger?.error?.(`[@sanity/client]: ${msg}`, {
            result,
            resultSourceMap,
            config
        }), new TypeError(msg);
    }
    if (!resultSourceMap) return logger?.error?.("[@sanity/client]: Missing Content Source Map from response body", {
        result,
        resultSourceMap,
        config
    }), result;
    if (!config.studioUrl) {
        const msg = "config.studioUrl must be defined";
        throw logger?.error?.(`[@sanity/client]: ${msg}`, {
            result,
            resultSourceMap,
            config
        }), new TypeError(msg);
    }
    const report = {
        encoded: [],
        skipped: []
    }, resultWithStega = encodeIntoResult(result, resultSourceMap, ({ sourcePath, sourceDocument, resultPath, value })=>{
        if ((typeof filter == "function" ? filter({
            sourcePath,
            resultPath,
            filterDefault,
            sourceDocument,
            value
        }) : filterDefault({
            sourcePath,
            resultPath,
            value
        })) === !1) return logger && report.skipped.push({
            path: prettyPathForLogging(sourcePath),
            value: `${value.slice(0, TRUNCATE_LENGTH)}${value.length > TRUNCATE_LENGTH ? "..." : ""}`,
            length: value.length
        }), value;
        logger && report.encoded.push({
            path: prettyPathForLogging(sourcePath),
            value: `${value.slice(0, TRUNCATE_LENGTH)}${value.length > TRUNCATE_LENGTH ? "..." : ""}`,
            length: value.length
        });
        const { baseUrl, workspace, tool } = resolveStudioBaseRoute(typeof config.studioUrl == "function" ? config.studioUrl(sourceDocument) : config.studioUrl);
        if (!baseUrl) return value;
        const { _id: id, _type: type, _projectId: projectId, _dataset: dataset } = sourceDocument;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$stegaClean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["y"])(value, {
            origin: "sanity.io",
            href: createEditUrl({
                baseUrl,
                workspace,
                tool,
                id,
                type,
                path: sourcePath,
                ...!config.omitCrossDatasetReferenceData && {
                    dataset,
                    projectId
                }
            })
        }, // We use custom logic to determine if we should skip encoding
        !1);
    });
    if (logger) {
        const isSkipping = report.skipped.length, isEncoding = report.encoded.length;
        if ((isSkipping || isEncoding) && ((logger?.groupCollapsed || logger.log)?.("[@sanity/client]: Encoding source map into result"), logger.log?.(`[@sanity/client]: Paths encoded: ${report.encoded.length}, skipped: ${report.skipped.length}`)), report.encoded.length > 0 && (logger?.log?.("[@sanity/client]: Table of encoded paths"), (logger?.table || logger.log)?.(report.encoded)), report.skipped.length > 0) {
            const skipped = /* @__PURE__ */ new Set();
            for (const { path } of report.skipped)skipped.add(path.replace(reKeySegment, "0").replace(/\[\d+\]/g, "[]"));
            logger?.log?.("[@sanity/client]: List of skipped paths", [
                ...skipped.values()
            ]);
        }
        (isSkipping || isEncoding) && logger?.groupEnd?.();
    }
    return resultWithStega;
}
function prettyPathForLogging(path) {
    return toString(jsonPathToStudioPath(path));
}
var stegaEncodeSourceMap$1 = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    stegaEncodeSourceMap
});
;
}),
"[project]/node_modules/@sanity/color/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "COLOR_HUES",
    ()=>COLOR_HUES,
    "COLOR_TINTS",
    ()=>COLOR_TINTS,
    "black",
    ()=>black,
    "blue",
    ()=>blue,
    "buildTints",
    ()=>buildTints,
    "color",
    ()=>color,
    "config",
    ()=>config,
    "cyan",
    ()=>cyan,
    "darken",
    ()=>darken,
    "gray",
    ()=>gray,
    "green",
    ()=>green,
    "hexToRgb",
    ()=>hexToRgb,
    "hslToRgb",
    ()=>hslToRgb,
    "hues",
    ()=>hues,
    "limit",
    ()=>limit,
    "magenta",
    ()=>magenta,
    "orange",
    ()=>orange,
    "purple",
    ()=>purple,
    "red",
    ()=>red,
    "rgbToHex",
    ()=>rgbToHex,
    "rgbToHsl",
    ()=>rgbToHsl,
    "screen",
    ()=>screen,
    "white",
    ()=>white,
    "yellow",
    ()=>yellow
]);
const COLOR_HUES = [
    "gray",
    "blue",
    "purple",
    "magenta",
    "red",
    "orange",
    "yellow",
    "green",
    "cyan"
], COLOR_TINTS = [
    "50",
    "100",
    "200",
    "300",
    "400",
    "500",
    "600",
    "700",
    "800",
    "900",
    "950"
];
function hslToRgb(hsl) {
    const h = hsl[0], s = hsl[1] / 100, l = hsl[2] / 100, k = (n)=>(n + h / 30) % 12, a = s * Math.min(l, 1 - l), f = (n)=>l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    return [
        255 * f(0),
        255 * f(8),
        255 * f(4)
    ];
}
function rgbToHex([r, g, b]) {
    const _r = Math.round(r), _g = Math.round(g), _b = Math.round(b);
    return "#" + ((1 << 24) + (_r << 16) + (_g << 8) + _b).toString(16).slice(1);
}
function buildTints(options) {
    const { hueKey, color: color2 } = options;
    return COLOR_TINTS.reduce((acc, tintKey)=>{
        const tint = Number(tintKey), rgb = hslToRgb(color2.tints[tintKey].hsl), hex = rgbToHex([
            Math.round(rgb[0]),
            Math.round(rgb[1]),
            Math.round(rgb[2])
        ]);
        return acc[tintKey] = {
            title: `${hueKey.slice(0, 1).toUpperCase()}${hueKey.slice(1)} ${tint}`,
            hex
        }, acc;
    }, {});
}
const black = {
    title: "Black",
    hex: "#0d0e12"
}, white = {
    title: "White",
    hex: "#ffffff"
}, gray = {
    50: {
        title: "Gray 50",
        hex: "#f6f6f8"
    },
    100: {
        title: "Gray 100",
        hex: "#eeeef1"
    },
    200: {
        title: "Gray 200",
        hex: "#e3e4e8"
    },
    300: {
        title: "Gray 300",
        hex: "#bbbdc9"
    },
    400: {
        title: "Gray 400",
        hex: "#9499ad"
    },
    500: {
        title: "Gray 500",
        hex: "#727892"
    },
    600: {
        title: "Gray 600",
        hex: "#515870"
    },
    700: {
        title: "Gray 700",
        hex: "#383d51"
    },
    800: {
        title: "Gray 800",
        hex: "#252837"
    },
    900: {
        title: "Gray 900",
        hex: "#1b1d27"
    },
    950: {
        title: "Gray 950",
        hex: "#13141b"
    }
}, blue = {
    50: {
        title: "Blue 50",
        hex: "#f5f8ff"
    },
    100: {
        title: "Blue 100",
        hex: "#e5edff"
    },
    200: {
        title: "Blue 200",
        hex: "#dbe5ff"
    },
    300: {
        title: "Blue 300",
        hex: "#a8bfff"
    },
    400: {
        title: "Blue 400",
        hex: "#7595ff"
    },
    500: {
        title: "Blue 500",
        hex: "#556bfc"
    },
    600: {
        title: "Blue 600",
        hex: "#4043e7"
    },
    700: {
        title: "Blue 700",
        hex: "#2927aa"
    },
    800: {
        title: "Blue 800",
        hex: "#192457"
    },
    900: {
        title: "Blue 900",
        hex: "#161a41"
    },
    950: {
        title: "Blue 950",
        hex: "#101228"
    }
}, purple = {
    50: {
        title: "Purple 50",
        hex: "#f8f5ff"
    },
    100: {
        title: "Purple 100",
        hex: "#f1ebff"
    },
    200: {
        title: "Purple 200",
        hex: "#ece1fe"
    },
    300: {
        title: "Purple 300",
        hex: "#ccb1fc"
    },
    400: {
        title: "Purple 400",
        hex: "#b087f7"
    },
    500: {
        title: "Purple 500",
        hex: "#8f57ef"
    },
    600: {
        title: "Purple 600",
        hex: "#721fe5"
    },
    700: {
        title: "Purple 700",
        hex: "#4c1a9e"
    },
    800: {
        title: "Purple 800",
        hex: "#2f1862"
    },
    900: {
        title: "Purple 900",
        hex: "#23173f"
    },
    950: {
        title: "Purple 950",
        hex: "#181128"
    }
}, magenta = {
    50: {
        title: "Magenta 50",
        hex: "#fef6f9"
    },
    100: {
        title: "Magenta 100",
        hex: "#fde8ef"
    },
    200: {
        title: "Magenta 200",
        hex: "#fcdee9"
    },
    300: {
        title: "Magenta 300",
        hex: "#f7abc5"
    },
    400: {
        title: "Magenta 400",
        hex: "#f0709b"
    },
    500: {
        title: "Magenta 500",
        hex: "#e72767"
    },
    600: {
        title: "Magenta 600",
        hex: "#b11651"
    },
    700: {
        title: "Magenta 700",
        hex: "#7c1342"
    },
    800: {
        title: "Magenta 800",
        hex: "#4b1130"
    },
    900: {
        title: "Magenta 900",
        hex: "#341325"
    },
    950: {
        title: "Magenta 950",
        hex: "#1f0f14"
    }
}, red = {
    50: {
        title: "Red 50",
        hex: "#fff6f5"
    },
    100: {
        title: "Red 100",
        hex: "#ffe7e5"
    },
    200: {
        title: "Red 200",
        hex: "#ffdedc"
    },
    300: {
        title: "Red 300",
        hex: "#fdada5"
    },
    400: {
        title: "Red 400",
        hex: "#f77769"
    },
    500: {
        title: "Red 500",
        hex: "#ef4434"
    },
    600: {
        title: "Red 600",
        hex: "#cc2819"
    },
    700: {
        title: "Red 700",
        hex: "#8b2018"
    },
    800: {
        title: "Red 800",
        hex: "#4d1714"
    },
    900: {
        title: "Red 900",
        hex: "#321615"
    },
    950: {
        title: "Red 950",
        hex: "#1e1011"
    }
}, orange = {
    50: {
        title: "Orange 50",
        hex: "#fff7f0"
    },
    100: {
        title: "Orange 100",
        hex: "#ffeadb"
    },
    200: {
        title: "Orange 200",
        hex: "#ffddc7"
    },
    300: {
        title: "Orange 300",
        hex: "#ffb685"
    },
    400: {
        title: "Orange 400",
        hex: "#ff8e42"
    },
    500: {
        title: "Orange 500",
        hex: "#fa6400"
    },
    600: {
        title: "Orange 600",
        hex: "#b14802"
    },
    700: {
        title: "Orange 700",
        hex: "#7c3404"
    },
    800: {
        title: "Orange 800",
        hex: "#461e07"
    },
    900: {
        title: "Orange 900",
        hex: "#32160b"
    },
    950: {
        title: "Orange 950",
        hex: "#21120d"
    }
}, yellow = {
    50: {
        title: "Yellow 50",
        hex: "#fefae1"
    },
    100: {
        title: "Yellow 100",
        hex: "#fcf3bb"
    },
    200: {
        title: "Yellow 200",
        hex: "#f9e994"
    },
    300: {
        title: "Yellow 300",
        hex: "#f7d455"
    },
    400: {
        title: "Yellow 400",
        hex: "#f9bc15"
    },
    500: {
        title: "Yellow 500",
        hex: "#d28a04"
    },
    600: {
        title: "Yellow 600",
        hex: "#965908"
    },
    700: {
        title: "Yellow 700",
        hex: "#653a0b"
    },
    800: {
        title: "Yellow 800",
        hex: "#3b220c"
    },
    900: {
        title: "Yellow 900",
        hex: "#271a11"
    },
    950: {
        title: "Yellow 950",
        hex: "#181410"
    }
}, green = {
    50: {
        title: "Green 50",
        hex: "#e7fef5"
    },
    100: {
        title: "Green 100",
        hex: "#c5fce8"
    },
    200: {
        title: "Green 200",
        hex: "#a9f9dc"
    },
    300: {
        title: "Green 300",
        hex: "#59f3ba"
    },
    400: {
        title: "Green 400",
        hex: "#0ff0a1"
    },
    500: {
        title: "Green 500",
        hex: "#04b97a"
    },
    600: {
        title: "Green 600",
        hex: "#01794f"
    },
    700: {
        title: "Green 700",
        hex: "#015133"
    },
    800: {
        title: "Green 800",
        hex: "#023120"
    },
    900: {
        title: "Green 900",
        hex: "#06231a"
    },
    950: {
        title: "Green 950",
        hex: "#071715"
    }
}, cyan = {
    50: {
        title: "Cyan 50",
        hex: "#e7fefe"
    },
    100: {
        title: "Cyan 100",
        hex: "#c5fcfc"
    },
    200: {
        title: "Cyan 200",
        hex: "#96f8f8"
    },
    300: {
        title: "Cyan 300",
        hex: "#62efef"
    },
    400: {
        title: "Cyan 400",
        hex: "#18e2e2"
    },
    500: {
        title: "Cyan 500",
        hex: "#04b8be"
    },
    600: {
        title: "Cyan 600",
        hex: "#037782"
    },
    700: {
        title: "Cyan 700",
        hex: "#024950"
    },
    800: {
        title: "Cyan 800",
        hex: "#042f34"
    },
    900: {
        title: "Cyan 900",
        hex: "#072227"
    },
    950: {
        title: "Cyan 950",
        hex: "#0d181c"
    }
}, hues = {
    gray,
    blue,
    purple,
    magenta,
    red,
    orange,
    yellow,
    green,
    cyan
}, color = {
    black,
    white,
    ...hues
}, config = {
    black: {
        title: "Black",
        hsl: [
            225,
            16,
            6
        ]
    },
    white: {
        title: "White",
        hsl: [
            0,
            0,
            100
        ]
    },
    gray: {
        title: "Gray",
        tints: {
            50: {
                title: "Gray 50",
                hsl: [
                    240,
                    12,
                    97
                ]
            },
            100: {
                title: "Gray 100",
                hsl: [
                    240,
                    10,
                    94
                ]
            },
            200: {
                title: "Gray 200",
                hsl: [
                    231,
                    10,
                    90
                ]
            },
            300: {
                title: "Gray 300",
                hsl: [
                    232,
                    11,
                    76
                ]
            },
            400: {
                title: "Gray 400",
                hsl: [
                    228,
                    13,
                    63
                ]
            },
            500: {
                title: "Gray 500",
                hsl: [
                    229,
                    13,
                    51
                ]
            },
            600: {
                title: "Gray 600",
                hsl: [
                    228,
                    16,
                    38
                ]
            },
            700: {
                title: "Gray 700",
                hsl: [
                    229,
                    18,
                    27
                ]
            },
            800: {
                title: "Gray 800",
                hsl: [
                    229,
                    19,
                    18
                ]
            },
            900: {
                title: "Gray 900",
                hsl: [
                    228,
                    19,
                    13
                ]
            },
            950: {
                title: "Gray 950",
                hsl: [
                    233,
                    17,
                    9
                ]
            }
        }
    },
    blue: {
        title: "Blue",
        tints: {
            50: {
                title: "Blue 50",
                hsl: [
                    222,
                    100,
                    98
                ]
            },
            100: {
                title: "Blue 100",
                hsl: [
                    222,
                    100,
                    95
                ]
            },
            200: {
                title: "Blue 200",
                hsl: [
                    223,
                    100,
                    93
                ]
            },
            300: {
                title: "Blue 300",
                hsl: [
                    224,
                    100,
                    83
                ]
            },
            400: {
                title: "Blue 400",
                hsl: [
                    226,
                    100,
                    73
                ]
            },
            500: {
                title: "Blue 500",
                hsl: [
                    232,
                    96,
                    66
                ]
            },
            600: {
                title: "Blue 600",
                hsl: [
                    239,
                    78,
                    58
                ]
            },
            700: {
                title: "Blue 700",
                hsl: [
                    241,
                    63,
                    41
                ]
            },
            800: {
                title: "Blue 800",
                hsl: [
                    230,
                    55,
                    22
                ]
            },
            900: {
                title: "Blue 900",
                hsl: [
                    234,
                    49,
                    17
                ]
            },
            950: {
                title: "Blue 950",
                hsl: [
                    235,
                    43,
                    11
                ]
            }
        }
    },
    purple: {
        title: "Purple",
        tints: {
            50: {
                title: "Purple 50",
                hsl: [
                    260,
                    95,
                    98
                ]
            },
            100: {
                title: "Purple 100",
                hsl: [
                    260,
                    98,
                    96
                ]
            },
            200: {
                title: "Purple 200",
                hsl: [
                    263,
                    96,
                    94
                ]
            },
            300: {
                title: "Purple 300",
                hsl: [
                    262,
                    92,
                    84
                ]
            },
            400: {
                title: "Purple 400",
                hsl: [
                    262,
                    88,
                    75
                ]
            },
            500: {
                title: "Purple 500",
                hsl: [
                    262,
                    83,
                    64
                ]
            },
            600: {
                title: "Purple 600",
                hsl: [
                    265,
                    79,
                    51
                ]
            },
            700: {
                title: "Purple 700",
                hsl: [
                    263,
                    72,
                    36
                ]
            },
            800: {
                title: "Purple 800",
                hsl: [
                    258,
                    60,
                    24
                ]
            },
            900: {
                title: "Purple 900",
                hsl: [
                    257,
                    46,
                    17
                ]
            },
            950: {
                title: "Purple 950",
                hsl: [
                    260,
                    41,
                    11
                ]
            }
        }
    },
    magenta: {
        title: "Magenta",
        tints: {
            50: {
                title: "Magenta 50",
                hsl: [
                    340,
                    82,
                    98
                ]
            },
            100: {
                title: "Magenta 100",
                hsl: [
                    339,
                    83,
                    95
                ]
            },
            200: {
                title: "Magenta 200",
                hsl: [
                    339,
                    83,
                    93
                ]
            },
            300: {
                title: "Magenta 300",
                hsl: [
                    340,
                    82,
                    82
                ]
            },
            400: {
                title: "Magenta 400",
                hsl: [
                    340,
                    81,
                    69
                ]
            },
            500: {
                title: "Magenta 500",
                hsl: [
                    340,
                    80,
                    53
                ]
            },
            600: {
                title: "Magenta 600",
                hsl: [
                    337,
                    78,
                    39
                ]
            },
            700: {
                title: "Magenta 700",
                hsl: [
                    333,
                    73,
                    28
                ]
            },
            800: {
                title: "Magenta 800",
                hsl: [
                    328,
                    63,
                    18
                ]
            },
            900: {
                title: "Magenta 900",
                hsl: [
                    327,
                    46,
                    14
                ]
            },
            950: {
                title: "Magenta 950",
                hsl: [
                    341,
                    35,
                    9
                ]
            }
        }
    },
    red: {
        title: "Red",
        tints: {
            50: {
                title: "Red 50",
                hsl: [
                    5,
                    100,
                    98
                ]
            },
            100: {
                title: "Red 100",
                hsl: [
                    4,
                    100,
                    95
                ]
            },
            200: {
                title: "Red 200",
                hsl: [
                    4,
                    98,
                    93
                ]
            },
            300: {
                title: "Red 300",
                hsl: [
                    5,
                    95,
                    82
                ]
            },
            400: {
                title: "Red 400",
                hsl: [
                    6,
                    90,
                    69
                ]
            },
            500: {
                title: "Red 500",
                hsl: [
                    5,
                    85,
                    57
                ]
            },
            600: {
                title: "Red 600",
                hsl: [
                    5,
                    78,
                    45
                ]
            },
            700: {
                title: "Red 700",
                hsl: [
                    4,
                    70,
                    32
                ]
            },
            800: {
                title: "Red 800",
                hsl: [
                    3,
                    58,
                    19
                ]
            },
            900: {
                title: "Red 900",
                hsl: [
                    2,
                    41,
                    14
                ]
            },
            950: {
                title: "Red 950",
                hsl: [
                    356,
                    30,
                    9
                ]
            }
        }
    },
    orange: {
        title: "Orange",
        tints: {
            50: {
                title: "Orange 50",
                hsl: [
                    28,
                    100,
                    97
                ]
            },
            100: {
                title: "Orange 100",
                hsl: [
                    25,
                    100,
                    93
                ]
            },
            200: {
                title: "Orange 200",
                hsl: [
                    24,
                    100,
                    89
                ]
            },
            300: {
                title: "Orange 300",
                hsl: [
                    24,
                    100,
                    76
                ]
            },
            400: {
                title: "Orange 400",
                hsl: [
                    24,
                    100,
                    63
                ]
            },
            500: {
                title: "Orange 500",
                hsl: [
                    24,
                    100,
                    49
                ]
            },
            600: {
                title: "Orange 600",
                hsl: [
                    24,
                    98,
                    35
                ]
            },
            700: {
                title: "Orange 700",
                hsl: [
                    24,
                    94,
                    25
                ]
            },
            800: {
                title: "Orange 800",
                hsl: [
                    22,
                    82,
                    15
                ]
            },
            900: {
                title: "Orange 900",
                hsl: [
                    17,
                    65,
                    12
                ]
            },
            950: {
                title: "Orange 950",
                hsl: [
                    14,
                    43,
                    9
                ]
            }
        }
    },
    yellow: {
        title: "Yellow",
        tints: {
            50: {
                title: "Yellow 50",
                hsl: [
                    51,
                    94,
                    94
                ]
            },
            100: {
                title: "Yellow 100",
                hsl: [
                    52,
                    91,
                    86
                ]
            },
            200: {
                title: "Yellow 200",
                hsl: [
                    50,
                    90,
                    78
                ]
            },
            300: {
                title: "Yellow 300",
                hsl: [
                    47,
                    91,
                    65
                ]
            },
            400: {
                title: "Yellow 400",
                hsl: [
                    44,
                    95,
                    53
                ]
            },
            500: {
                title: "Yellow 500",
                hsl: [
                    39,
                    96,
                    42
                ]
            },
            600: {
                title: "Yellow 600",
                hsl: [
                    34,
                    90,
                    31
                ]
            },
            700: {
                title: "Yellow 700",
                hsl: [
                    31,
                    80,
                    22
                ]
            },
            800: {
                title: "Yellow 800",
                hsl: [
                    28,
                    66,
                    14
                ]
            },
            900: {
                title: "Yellow 900",
                hsl: [
                    24,
                    40,
                    11
                ]
            },
            950: {
                title: "Yellow 950",
                hsl: [
                    24,
                    20,
                    8
                ]
            }
        }
    },
    green: {
        title: "Green",
        tints: {
            50: {
                title: "Green 50",
                hsl: [
                    157,
                    89,
                    95
                ]
            },
            100: {
                title: "Green 100",
                hsl: [
                    158,
                    89,
                    88
                ]
            },
            200: {
                title: "Green 200",
                hsl: [
                    158,
                    87,
                    82
                ]
            },
            300: {
                title: "Green 300",
                hsl: [
                    158,
                    86,
                    65
                ]
            },
            400: {
                title: "Green 400",
                hsl: [
                    159,
                    88,
                    50
                ]
            },
            500: {
                title: "Green 500",
                hsl: [
                    159,
                    96,
                    37
                ]
            },
            600: {
                title: "Green 600",
                hsl: [
                    159,
                    98,
                    24
                ]
            },
            700: {
                title: "Green 700",
                hsl: [
                    158,
                    98,
                    16
                ]
            },
            800: {
                title: "Green 800",
                hsl: [
                    158,
                    91,
                    10
                ]
            },
            900: {
                title: "Green 900",
                hsl: [
                    162,
                    72,
                    8
                ]
            },
            950: {
                title: "Green 950",
                hsl: [
                    172,
                    51,
                    6
                ]
            }
        }
    },
    cyan: {
        title: "Cyan",
        tints: {
            50: {
                title: "Cyan 50",
                hsl: [
                    180,
                    92,
                    95
                ]
            },
            100: {
                title: "Cyan 100",
                hsl: [
                    180,
                    91,
                    88
                ]
            },
            200: {
                title: "Cyan 200",
                hsl: [
                    180,
                    87,
                    78
                ]
            },
            300: {
                title: "Cyan 300",
                hsl: [
                    180,
                    81,
                    66
                ]
            },
            400: {
                title: "Cyan 400",
                hsl: [
                    180,
                    81,
                    49
                ]
            },
            500: {
                title: "Cyan 500",
                hsl: [
                    182,
                    96,
                    38
                ]
            },
            600: {
                title: "Cyan 600",
                hsl: [
                    185,
                    96,
                    26
                ]
            },
            700: {
                title: "Cyan 700",
                hsl: [
                    185,
                    95,
                    16
                ]
            },
            800: {
                title: "Cyan 800",
                hsl: [
                    187,
                    86,
                    11
                ]
            },
            900: {
                title: "Cyan 900",
                hsl: [
                    188,
                    68,
                    9
                ]
            },
            950: {
                title: "Cyan 950",
                hsl: [
                    196,
                    37,
                    8
                ]
            }
        }
    }
};
function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    if (!result) throw new Error("input is not valid hex");
    return [
        parseInt(result[1], 16),
        parseInt(result[2], 16),
        parseInt(result[3], 16)
    ];
}
function rgbToHsl([r, g, b]) {
    r /= 255, g /= 255, b /= 255;
    const cmin = Math.min(r, g, b), cmax = Math.max(r, g, b), delta = cmax - cmin;
    let h = 0, s = 0, l = 0;
    return delta == 0 ? h = 0 : cmax == r ? h = (g - b) / delta % 6 : cmax == g ? h = (b - r) / delta + 2 : h = (r - g) / delta + 4, h = Math.round(h * 60), h < 0 && (h += 360), l = (cmax + cmin) / 2, s = delta == 0 ? 0 : delta / (1 - Math.abs(2 * l - 1)), s = +(s * 100).toFixed(0), l = +(l * 100).toFixed(0), [
        h,
        s,
        l
    ];
}
function clamp(num) {
    return Math.max(Math.min(num, 255), 0);
}
function darkenChannel(backdrop, source) {
    return Math.min(backdrop, source);
}
function darken(b, s) {
    return [
        Math.round(clamp(darkenChannel(b[0] / 255, s[0] / 255) * 255)),
        Math.round(clamp(darkenChannel(b[1] / 255, s[1] / 255) * 255)),
        Math.round(clamp(darkenChannel(b[2] / 255, s[2] / 255) * 255))
    ];
}
function interpolate(min, max, val) {
    const size = max - min;
    return min + size * val;
}
function limit(darkest, lightest, source) {
    const r = Math.round(interpolate(darkest[0], lightest[0], source[0] / 255)), g = Math.round(interpolate(darkest[1], lightest[1], source[1] / 255)), b = Math.round(interpolate(darkest[2], lightest[2], source[2] / 255));
    return [
        r,
        g,
        b
    ];
}
function screenChannel(backdrop, source) {
    return backdrop + source - backdrop * source;
}
function screen(b, s) {
    return [
        Math.round(clamp(screenChannel(b[0] / 255, s[0] / 255) * 255)),
        Math.round(clamp(screenChannel(b[1] / 255, s[1] / 255) * 255)),
        Math.round(clamp(screenChannel(b[2] / 255, s[2] / 255) * 255))
    ];
}
;
}),
"[project]/node_modules/@sanity/ui/node_modules/react-compiler-runtime/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @lightSyntaxTransform
 * @noflow
 * @nolint
 * @preventMunge
 * @preserve-invariant-messages
 */ var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toESM = (mod, isNodeMode, target)=>(target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(// If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
        value: mod,
        enumerable: true
    }) : target, mod));
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
// src/index.ts
var index_exports = {};
__export(index_exports, {
    $dispatcherGuard: ()=>$dispatcherGuard,
    $makeReadOnly: ()=>$makeReadOnly,
    $reset: ()=>$reset,
    $structuralCheck: ()=>$structuralCheck,
    c: ()=>c,
    clearRenderCounterRegistry: ()=>clearRenderCounterRegistry,
    renderCounterRegistry: ()=>renderCounterRegistry,
    useRenderCounter: ()=>useRenderCounter
});
module.exports = __toCommonJS(index_exports);
var React = __toESM(__turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var { useRef, useEffect, isValidElement } = React;
var _a;
var ReactSecretInternals = //@ts-ignore
(_a = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE) != null ? _a : React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
var $empty = Symbol.for("react.memo_cache_sentinel");
var _a2;
var c = // @ts-expect-error
typeof ((_a2 = React.__COMPILER_RUNTIME) == null ? void 0 : _a2.c) === "function" ? // @ts-expect-error
React.__COMPILER_RUNTIME.c : function c2(size) {
    return React.useMemo({
        "c2.useMemo": ()=>{
            const $ = new Array(size);
            for(let ii = 0; ii < size; ii++){
                $[ii] = $empty;
            }
            $[$empty] = true;
            return $;
        }
    }["c2.useMemo"], []);
};
var LazyGuardDispatcher = {};
[
    "readContext",
    "useCallback",
    "useContext",
    "useEffect",
    "useImperativeHandle",
    "useInsertionEffect",
    "useLayoutEffect",
    "useMemo",
    "useReducer",
    "useRef",
    "useState",
    "useDebugValue",
    "useDeferredValue",
    "useTransition",
    "useMutableSource",
    "useSyncExternalStore",
    "useId",
    "unstable_isNewReconciler",
    "getCacheSignal",
    "getCacheForType",
    "useCacheRefresh"
].forEach((name)=>{
    LazyGuardDispatcher[name] = ()=>{
        throw new Error(`[React] Unexpected React hook call (${name}) from a React compiled function. Check that all hooks are called directly and named according to convention ('use[A-Z]') `);
    };
});
var originalDispatcher = null;
LazyGuardDispatcher["useMemoCache"] = (count)=>{
    if (originalDispatcher == null) {
        throw new Error("React Compiler internal invariant violation: unexpected null dispatcher");
    } else {
        return originalDispatcher.useMemoCache(count);
    }
};
function setCurrent(newDispatcher) {
    ReactSecretInternals.ReactCurrentDispatcher.current = newDispatcher;
    return ReactSecretInternals.ReactCurrentDispatcher.current;
}
var guardFrames = [];
function $dispatcherGuard(kind) {
    const curr = ReactSecretInternals.ReactCurrentDispatcher.current;
    if (kind === 0 /* PushGuardContext */ ) {
        guardFrames.push(curr);
        if (guardFrames.length === 1) {
            originalDispatcher = curr;
        }
        if (curr === LazyGuardDispatcher) {
            throw new Error(`[React] Unexpected call to custom hook or component from a React compiled function. Check that (1) all hooks are called directly and named according to convention ('use[A-Z]') and (2) components are returned as JSX instead of being directly invoked.`);
        }
        setCurrent(LazyGuardDispatcher);
    } else if (kind === 1 /* PopGuardContext */ ) {
        const lastFrame = guardFrames.pop();
        if (lastFrame == null) {
            throw new Error("React Compiler internal error: unexpected null in guard stack");
        }
        if (guardFrames.length === 0) {
            originalDispatcher = null;
        }
        setCurrent(lastFrame);
    } else if (kind === 2 /* PushExpectHook */ ) {
        guardFrames.push(curr);
        setCurrent(originalDispatcher);
    } else if (kind === 3 /* PopExpectHook */ ) {
        const lastFrame = guardFrames.pop();
        if (lastFrame == null) {
            throw new Error("React Compiler internal error: unexpected null in guard stack");
        }
        setCurrent(lastFrame);
    } else {
        throw new Error("React Compiler internal error: unreachable block" + kind);
    }
}
function $reset($) {
    for(let ii = 0; ii < $.length; ii++){
        $[ii] = $empty;
    }
}
function $makeReadOnly() {
    throw new Error("TODO: implement $makeReadOnly in react-compiler-runtime");
}
var renderCounterRegistry = /* @__PURE__ */ new Map();
function clearRenderCounterRegistry() {
    for (const counters of renderCounterRegistry.values()){
        counters.forEach((counter)=>{
            counter.count = 0;
        });
    }
}
function registerRenderCounter(name, val) {
    let counters = renderCounterRegistry.get(name);
    if (counters == null) {
        counters = /* @__PURE__ */ new Set();
        renderCounterRegistry.set(name, counters);
    }
    counters.add(val);
}
function removeRenderCounter(name, val) {
    const counters = renderCounterRegistry.get(name);
    if (counters == null) {
        return;
    }
    counters.delete(val);
}
function useRenderCounter(name) {
    const val = useRef(null);
    if (val.current != null) {
        val.current.count += 1;
    }
    useEffect({
        "useRenderCounter.useEffect": ()=>{
            if (val.current == null) {
                const counter = {
                    count: 0
                };
                registerRenderCounter(name, counter);
                val.current = counter;
            }
            return ({
                "useRenderCounter.useEffect": ()=>{
                    if (val.current !== null) {
                        removeRenderCounter(name, val.current);
                    }
                }
            })["useRenderCounter.useEffect"];
        }
    }["useRenderCounter.useEffect"]);
}
var seenErrors = /* @__PURE__ */ new Set();
function $structuralCheck(oldValue, newValue, variableName, fnName, kind, loc) {
    function error(l, r, path, depth) {
        const str = `${fnName}:${loc} [${kind}] ${variableName}${path} changed from ${l} to ${r} at depth ${depth}`;
        if (seenErrors.has(str)) {
            return;
        }
        seenErrors.add(str);
        console.error(str);
    }
    const depthLimit = 2;
    function recur(oldValue2, newValue2, path, depth) {
        if (depth > depthLimit) {
            return;
        } else if (oldValue2 === newValue2) {
            return;
        } else if (typeof oldValue2 !== typeof newValue2) {
            error(`type ${typeof oldValue2}`, `type ${typeof newValue2}`, path, depth);
        } else if (typeof oldValue2 === "object") {
            const oldArray = Array.isArray(oldValue2);
            const newArray = Array.isArray(newValue2);
            if (oldValue2 === null && newValue2 !== null) {
                error("null", `type ${typeof newValue2}`, path, depth);
            } else if (newValue2 === null) {
                error(`type ${typeof oldValue2}`, "null", path, depth);
            } else if (oldValue2 instanceof Map) {
                if (!(newValue2 instanceof Map)) {
                    error(`Map instance`, `other value`, path, depth);
                } else if (oldValue2.size !== newValue2.size) {
                    error(`Map instance with size ${oldValue2.size}`, `Map instance with size ${newValue2.size}`, path, depth);
                } else {
                    for (const [k, v] of oldValue2){
                        if (!newValue2.has(k)) {
                            error(`Map instance with key ${k}`, `Map instance without key ${k}`, path, depth);
                        } else {
                            recur(v, newValue2.get(k), `${path}.get(${k})`, depth + 1);
                        }
                    }
                }
            } else if (newValue2 instanceof Map) {
                error("other value", `Map instance`, path, depth);
            } else if (oldValue2 instanceof Set) {
                if (!(newValue2 instanceof Set)) {
                    error(`Set instance`, `other value`, path, depth);
                } else if (oldValue2.size !== newValue2.size) {
                    error(`Set instance with size ${oldValue2.size}`, `Set instance with size ${newValue2.size}`, path, depth);
                } else {
                    for (const v of newValue2){
                        if (!oldValue2.has(v)) {
                            error(`Set instance without element ${v}`, `Set instance with element ${v}`, path, depth);
                        }
                    }
                }
            } else if (newValue2 instanceof Set) {
                error("other value", `Set instance`, path, depth);
            } else if (oldArray || newArray) {
                if (oldArray !== newArray) {
                    error(`type ${oldArray ? "array" : "object"}`, `type ${newArray ? "array" : "object"}`, path, depth);
                } else if (oldValue2.length !== newValue2.length) {
                    error(`array with length ${oldValue2.length}`, `array with length ${newValue2.length}`, path, depth);
                } else {
                    for(let ii = 0; ii < oldValue2.length; ii++){
                        recur(oldValue2[ii], newValue2[ii], `${path}[${ii}]`, depth + 1);
                    }
                }
            } else if (isValidElement(oldValue2) || isValidElement(newValue2)) {
                if (isValidElement(oldValue2) !== isValidElement(newValue2)) {
                    error(`type ${isValidElement(oldValue2) ? "React element" : "object"}`, `type ${isValidElement(newValue2) ? "React element" : "object"}`, path, depth);
                } else if (oldValue2.type !== newValue2.type) {
                    error(`React element of type ${oldValue2.type}`, `React element of type ${newValue2.type}`, path, depth);
                } else {
                    recur(oldValue2.props, newValue2.props, `[props of ${path}]`, depth + 1);
                }
            } else {
                for(const key in newValue2){
                    if (!(key in oldValue2)) {
                        error(`object without key ${key}`, `object with key ${key}`, path, depth);
                    }
                }
                for(const key in oldValue2){
                    if (!(key in newValue2)) {
                        error(`object with key ${key}`, `object without key ${key}`, path, depth);
                    } else {
                        recur(oldValue2[key], newValue2[key], `${path}.${key}`, depth + 1);
                    }
                }
            }
        } else if (typeof oldValue2 === "function") {
            return;
        } else if (isNaN(oldValue2) || isNaN(newValue2)) {
            if (isNaN(oldValue2) !== isNaN(newValue2)) {
                error(`${isNaN(oldValue2) ? "NaN" : "non-NaN value"}`, `${isNaN(newValue2) ? "NaN" : "non-NaN value"}`, path, depth);
            }
        } else if (oldValue2 !== newValue2) {
            error(oldValue2, newValue2, path, depth);
        }
    }
    recur(oldValue, newValue, "", 0);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    $dispatcherGuard,
    $makeReadOnly,
    $reset,
    $structuralCheck,
    c,
    clearRenderCounterRegistry,
    renderCounterRegistry,
    useRenderCounter
});
}),
"[project]/node_modules/@emotion/is-prop-valid/node_modules/@emotion/memoize/dist/emotion-memoize.esm.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>memoize
]);
function memoize(fn) {
    var cache = Object.create(null);
    return function(arg) {
        if (cache[arg] === undefined) cache[arg] = fn(arg);
        return cache[arg];
    };
}
;
}),
"[project]/node_modules/@emotion/is-prop-valid/dist/emotion-is-prop-valid.esm.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>isPropValid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$emotion$2f$is$2d$prop$2d$valid$2f$node_modules$2f40$emotion$2f$memoize$2f$dist$2f$emotion$2d$memoize$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@emotion/is-prop-valid/node_modules/@emotion/memoize/dist/emotion-memoize.esm.js [app-client] (ecmascript)");
;
// eslint-disable-next-line no-undef
var reactPropsRegex = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|disableRemotePlayback|download|draggable|encType|enterKeyHint|fetchpriority|fetchPriority|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|popover|popoverTarget|popoverTargetAction|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/; // https://esbench.com/bench/5bfee68a4cd7e6009ef61d23
var isPropValid = /* #__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$emotion$2f$is$2d$prop$2d$valid$2f$node_modules$2f40$emotion$2f$memoize$2f$dist$2f$emotion$2d$memoize$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(function(prop) {
    return reactPropsRegex.test(prop) || prop.charCodeAt(0) === 111 && prop.charCodeAt(1) === 110 && prop.charCodeAt(2) < 91;
});
;
}),
"[project]/node_modules/stylis/src/Enum.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CHARSET",
    ()=>CHARSET,
    "COMMENT",
    ()=>COMMENT,
    "COUNTER_STYLE",
    ()=>COUNTER_STYLE,
    "DECLARATION",
    ()=>DECLARATION,
    "DOCUMENT",
    ()=>DOCUMENT,
    "FONT_FACE",
    ()=>FONT_FACE,
    "FONT_FEATURE_VALUES",
    ()=>FONT_FEATURE_VALUES,
    "IMPORT",
    ()=>IMPORT,
    "KEYFRAMES",
    ()=>KEYFRAMES,
    "LAYER",
    ()=>LAYER,
    "MEDIA",
    ()=>MEDIA,
    "MOZ",
    ()=>MOZ,
    "MS",
    ()=>MS,
    "NAMESPACE",
    ()=>NAMESPACE,
    "PAGE",
    ()=>PAGE,
    "RULESET",
    ()=>RULESET,
    "SCOPE",
    ()=>SCOPE,
    "SUPPORTS",
    ()=>SUPPORTS,
    "VIEWPORT",
    ()=>VIEWPORT,
    "WEBKIT",
    ()=>WEBKIT
]);
var MS = '-ms-';
var MOZ = '-moz-';
var WEBKIT = '-webkit-';
var COMMENT = 'comm';
var RULESET = 'rule';
var DECLARATION = 'decl';
var PAGE = '@page';
var MEDIA = '@media';
var IMPORT = '@import';
var CHARSET = '@charset';
var VIEWPORT = '@viewport';
var SUPPORTS = '@supports';
var DOCUMENT = '@document';
var NAMESPACE = '@namespace';
var KEYFRAMES = '@keyframes';
var FONT_FACE = '@font-face';
var COUNTER_STYLE = '@counter-style';
var FONT_FEATURE_VALUES = '@font-feature-values';
var LAYER = '@layer';
var SCOPE = '@scope';
}),
"[project]/node_modules/stylis/src/Utility.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @param {number}
 * @return {number}
 */ __turbopack_context__.s([
    "abs",
    ()=>abs,
    "append",
    ()=>append,
    "assign",
    ()=>assign,
    "charat",
    ()=>charat,
    "combine",
    ()=>combine,
    "filter",
    ()=>filter,
    "from",
    ()=>from,
    "hash",
    ()=>hash,
    "indexof",
    ()=>indexof,
    "match",
    ()=>match,
    "replace",
    ()=>replace,
    "sizeof",
    ()=>sizeof,
    "strlen",
    ()=>strlen,
    "substr",
    ()=>substr,
    "trim",
    ()=>trim
]);
var abs = Math.abs;
var from = String.fromCharCode;
var assign = Object.assign;
function hash(value, length) {
    return charat(value, 0) ^ 45 ? (((length << 2 ^ charat(value, 0)) << 2 ^ charat(value, 1)) << 2 ^ charat(value, 2)) << 2 ^ charat(value, 3) : 0;
}
function trim(value) {
    return value.trim();
}
function match(value, pattern) {
    return (value = pattern.exec(value)) ? value[0] : value;
}
function replace(value, pattern, replacement) {
    return value.replace(pattern, replacement);
}
function indexof(value, search, position) {
    return value.indexOf(search, position);
}
function charat(value, index) {
    return value.charCodeAt(index) | 0;
}
function substr(value, begin, end) {
    return value.slice(begin, end);
}
function strlen(value) {
    return value.length;
}
function sizeof(value) {
    return value.length;
}
function append(value, array) {
    return array.push(value), value;
}
function combine(array, callback) {
    return array.map(callback).join('');
}
function filter(array, pattern) {
    return array.filter(function(value) {
        return !match(value, pattern);
    });
}
}),
"[project]/node_modules/stylis/src/Tokenizer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "alloc",
    ()=>alloc,
    "caret",
    ()=>caret,
    "char",
    ()=>char,
    "character",
    ()=>character,
    "characters",
    ()=>characters,
    "column",
    ()=>column,
    "commenter",
    ()=>commenter,
    "copy",
    ()=>copy,
    "dealloc",
    ()=>dealloc,
    "delimit",
    ()=>delimit,
    "delimiter",
    ()=>delimiter,
    "escaping",
    ()=>escaping,
    "identifier",
    ()=>identifier,
    "length",
    ()=>length,
    "lift",
    ()=>lift,
    "line",
    ()=>line,
    "next",
    ()=>next,
    "node",
    ()=>node,
    "peek",
    ()=>peek,
    "position",
    ()=>position,
    "prev",
    ()=>prev,
    "slice",
    ()=>slice,
    "token",
    ()=>token,
    "tokenize",
    ()=>tokenize,
    "tokenizer",
    ()=>tokenizer,
    "whitespace",
    ()=>whitespace
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Utility.js [app-client] (ecmascript)");
;
var line = 1;
var column = 1;
var length = 0;
var position = 0;
var character = 0;
var characters = '';
function node(value, root, parent, type, props, children, length, siblings) {
    return {
        value: value,
        root: root,
        parent: parent,
        type: type,
        props: props,
        children: children,
        line: line,
        column: column,
        length: length,
        return: '',
        siblings: siblings
    };
}
function copy(root, props) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assign"])(node('', null, null, '', null, null, 0, root.siblings), root, {
        length: -root.length
    }, props);
}
function lift(root) {
    while(root.root)root = copy(root.root, {
        children: [
            root
        ]
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["append"])(root, root.siblings);
}
function char() {
    return character;
}
function prev() {
    character = position > 0 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(characters, --position) : 0;
    if (column--, character === 10) column = 1, line--;
    return character;
}
function next() {
    character = position < length ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(characters, position++) : 0;
    if (column++, character === 10) column = 1, line++;
    return character;
}
function peek() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(characters, position);
}
function caret() {
    return position;
}
function slice(begin, end) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["substr"])(characters, begin, end);
}
function token(type) {
    switch(type){
        // \0 \t \n \r \s whitespace token
        case 0:
        case 9:
        case 10:
        case 13:
        case 32:
            return 5;
        // ! + , / > @ ~ isolate token
        case 33:
        case 43:
        case 44:
        case 47:
        case 62:
        case 64:
        case 126:
        // ; { } breakpoint token
        case 59:
        case 123:
        case 125:
            return 4;
        // : accompanied token
        case 58:
            return 3;
        // " ' ( [ opening delimit token
        case 34:
        case 39:
        case 40:
        case 91:
            return 2;
        // ) ] closing delimit token
        case 41:
        case 93:
            return 1;
    }
    return 0;
}
function alloc(value) {
    return line = column = 1, length = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strlen"])(characters = value), position = 0, [];
}
function dealloc(value) {
    return characters = '', value;
}
function delimit(type) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trim"])(slice(position - 1, delimiter(type === 91 ? type + 2 : type === 40 ? type + 1 : type)));
}
function tokenize(value) {
    return dealloc(tokenizer(alloc(value)));
}
function whitespace(type) {
    while(character = peek())if (character < 33) next();
    else break;
    return token(type) > 2 || token(character) > 3 ? '' : ' ';
}
function tokenizer(children) {
    while(next())switch(token(character)){
        case 0:
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["append"])(identifier(position - 1), children);
            break;
        case 2:
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["append"])(delimit(character), children);
            break;
        default:
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["append"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["from"])(character), children);
    }
    return children;
}
function escaping(index, count) {
    while(--count && next())// not 0-9 A-F a-f
    if (character < 48 || character > 102 || character > 57 && character < 65 || character > 70 && character < 97) break;
    return slice(index, caret() + (count < 6 && peek() == 32 && next() == 32));
}
function delimiter(type) {
    while(next())switch(character){
        // ] ) " '
        case type:
            return position;
        // " '
        case 34:
        case 39:
            if (type !== 34 && type !== 39) delimiter(character);
            break;
        // (
        case 40:
            if (type === 41) delimiter(type);
            break;
        // \
        case 92:
            next();
            break;
    }
    return position;
}
function commenter(type, index) {
    while(next())// //
    if (type + character === 47 + 10) break;
    else if (type + character === 42 + 42 && peek() === 47) break;
    return '/*' + slice(index, position - 1) + '*' + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["from"])(type === 47 ? type : next());
}
function identifier(index) {
    while(!token(peek()))next();
    return slice(index, position);
}
}),
"[project]/node_modules/stylis/src/Serializer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "serialize",
    ()=>serialize,
    "stringify",
    ()=>stringify
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Enum.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Utility.js [app-client] (ecmascript)");
;
;
function serialize(children, callback) {
    var output = '';
    for(var i = 0; i < children.length; i++)output += callback(children[i], i, children, callback) || '';
    return output;
}
function stringify(element, index, children, callback) {
    switch(element.type){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LAYER"]:
            if (element.children.length) break;
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IMPORT"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NAMESPACE"]:
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DECLARATION"]:
            return element.return = element.return || element.value;
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMENT"]:
            return '';
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEYFRAMES"]:
            return element.return = element.value + '{' + serialize(element.children, callback) + '}';
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RULESET"]:
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strlen"])(element.value = element.props.join(','))) return '';
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strlen"])(children = serialize(element.children, callback)) ? element.return = element.value + '{' + children + '}' : '';
}
}),
"[project]/node_modules/stylis/src/Prefixer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "prefix",
    ()=>prefix
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Enum.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Utility.js [app-client] (ecmascript)");
;
;
function prefix(value, length, children) {
    switch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hash"])(value, length)){
        // color-adjust
        case 5103:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + 'print-' + value + value;
        // animation, animation-(delay|direction|duration|fill-mode|iteration-count|name|play-state|timing-function)
        case 5737:
        case 4201:
        case 3177:
        case 3433:
        case 1641:
        case 4457:
        case 2921:
        // text-decoration, filter, clip-path, backface-visibility, column, box-decoration-break
        case 5572:
        case 6356:
        case 5844:
        case 3191:
        case 6645:
        case 3005:
        // background-clip, columns, column-(count|fill|gap|rule|rule-color|rule-style|rule-width|span|width)
        case 4215:
        case 6389:
        case 5109:
        case 5365:
        case 5621:
        case 3829:
        // mask, mask-image, mask-(mode|clip|size), mask-(repeat|origin), mask-position
        case 6391:
        case 5879:
        case 5623:
        case 6135:
        case 4599:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value + value;
        // mask-composite
        case 4855:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value.replace('add', 'source-over').replace('substract', 'source-out').replace('intersect', 'source-in').replace('exclude', 'xor') + value;
        // tab-size
        case 4789:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MOZ"] + value + value;
        // appearance, user-select, transform, hyphens, text-size-adjust
        case 5349:
        case 4246:
        case 4810:
        case 6968:
        case 2756:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MOZ"] + value + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + value + value;
        // writing-mode
        case 5936:
            switch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(value, length + 11)){
                // vertical-l(r)
                case 114:
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /[svh]\w+-[tblr]{2}/, 'tb') + value;
                // vertical-r(l)
                case 108:
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /[svh]\w+-[tblr]{2}/, 'tb-rl') + value;
                // horizontal(-)tb
                case 45:
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /[svh]\w+-[tblr]{2}/, 'lr') + value;
            }
        // flex, flex-direction, scroll-snap-type, writing-mode
        case 6828:
        case 4268:
        case 2903:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + value + value;
        // order
        case 6165:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + 'flex-' + value + value;
        // align-items
        case 5187:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /(\w+).+(:[^]+)/, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + 'box-$1$2' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + 'flex-$1$2') + value;
        // align-self
        case 5443:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + 'flex-item-' + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /flex-|-self/g, '') + (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(value, /flex-|baseline/) ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + 'grid-row-' + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /flex-|-self/g, '') : '') + value;
        // align-content
        case 4675:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + 'flex-line-pack' + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /align-content|flex-|-self/g, '') + value;
        // flex-shrink
        case 5548:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, 'shrink', 'negative') + value;
        // flex-basis
        case 5292:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, 'basis', 'preferred-size') + value;
        // flex-grow
        case 6060:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + 'box-' + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, '-grow', '') + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, 'grow', 'positive') + value;
        // transition
        case 4554:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /([^-])(transform)/g, '$1' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + '$2') + value;
        // cursor
        case 6187:
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /(zoom-|grab)/, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + '$1'), /(image-set)/, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + '$1'), value, '') + value;
        // background, background-image
        case 5495:
        case 3959:
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /(image-set\([^]*)/, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + '$1' + '$`$1');
        // justify-content
        case 4968:
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /(.+:)(flex-)?(.*)/, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + 'box-pack:$3' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + 'flex-pack:$3'), /space-between/, 'justify') + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + value + value;
        // justify-self
        case 4200:
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(value, /flex-|baseline/)) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + 'grid-column-align' + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["substr"])(value, length) + value;
            break;
        // grid-template-(columns|rows)
        case 2592:
        case 3360:
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, 'template-', '') + value;
        // grid-(row|column)-start
        case 4384:
        case 3616:
            if (children && children.some(function(element, index) {
                return length = index, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(element.props, /grid-\w+-end/);
            })) {
                return ~(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["indexof"])(value + (children = children[length].value), 'span', 0) ? value : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, '-start', '') + value + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + 'grid-row-span:' + (~(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["indexof"])(children, 'span', 0) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(children, /\d+/) : +(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(children, /\d+/) - +(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(value, /\d+/)) + ';';
            }
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, '-start', '') + value;
        // grid-(row|column)-end
        case 4896:
        case 4128:
            return children && children.some(function(element) {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(element.props, /grid-\w+-start/);
            }) ? value : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, '-end', '-span'), 'span ', '') + value;
        // (margin|padding)-inline-(start|end)
        case 4095:
        case 3583:
        case 4068:
        case 2532:
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /(.+)-inline(.+)/, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + '$1$2') + value;
        // (min|max)?(width|height|inline-size|block-size)
        case 8116:
        case 7059:
        case 5753:
        case 5535:
        case 5445:
        case 5701:
        case 4933:
        case 4677:
        case 5533:
        case 5789:
        case 5021:
        case 4765:
            // stretch, max-content, min-content, fill-available
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strlen"])(value) - 1 - length > 6) switch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(value, length + 1)){
                // (m)ax-content, (m)in-content
                case 109:
                    // -
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(value, length + 4) !== 45) break;
                // (f)ill-available, (f)it-content
                case 102:
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /(.+:)(.+)-([^]+)/, '$1' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + '$2-$3' + '$1' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MOZ"] + ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(value, length + 3) == 108 ? '$3' : '$2-$3')) + value;
                // (s)tretch
                case 115:
                    return ~(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["indexof"])(value, 'stretch', 0) ? prefix((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, 'stretch', 'fill-available'), length, children) + value : value;
            }
            break;
        // grid-(column|row)
        case 5152:
        case 5920:
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /(.+?):(\d+)(\s*\/\s*(span)?\s*(\d+))?(.*)/, function(_, a, b, c, d, e, f) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + a + ':' + b + f + (c ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + a + '-span:' + (d ? e : +e - +b) + f : '') + value;
            });
        // position: sticky
        case 4949:
            // stick(y)?
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(value, length + 6) === 121) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, ':', ':' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"]) + value;
            break;
        // display: (flex|inline-flex|grid|inline-grid)
        case 6444:
            switch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(value, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(value, 14) === 45 ? 18 : 11)){
                // (inline-)?fle(x)
                case 120:
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /(.+:)([^;\s!]+)(;|(\s+)?!.+)?/, '$1' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(value, 14) === 45 ? 'inline-' : '') + 'box$3' + '$1' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + '$2$3' + '$1' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + '$2box$3') + value;
                // (inline-)?gri(d)
                case 100:
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, ':', ':' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"]) + value;
            }
            break;
        // scroll-margin, scroll-margin-(top|right|bottom|left)
        case 5719:
        case 2647:
        case 2135:
        case 3927:
        case 2391:
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, 'scroll-', 'scroll-snap-') + value;
    }
    return value;
}
}),
"[project]/node_modules/stylis/src/Middleware.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "middleware",
    ()=>middleware,
    "namespace",
    ()=>namespace,
    "prefixer",
    ()=>prefixer,
    "rulesheet",
    ()=>rulesheet
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Enum.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Utility.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Tokenizer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Serializer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Serializer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Prefixer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Prefixer.js [app-client] (ecmascript)");
;
;
;
;
;
function middleware(collection) {
    var length = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sizeof"])(collection);
    return function(element, index, children, callback) {
        var output = '';
        for(var i = 0; i < length; i++)output += collection[i](element, index, children, callback) || '';
        return output;
    };
}
function rulesheet(callback) {
    return function(element) {
        if (!element.root) {
            if (element = element.return) callback(element);
        }
    };
}
function prefixer(element, index, children, callback) {
    if (element.length > -1) {
        if (!element.return) switch(element.type){
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DECLARATION"]:
                element.return = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Prefixer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prefix"])(element.value, element.length, children);
                return;
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KEYFRAMES"]:
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Serializer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serialize"])([
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["copy"])(element, {
                        value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(element.value, '@', '@' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"])
                    })
                ], callback);
            case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RULESET"]:
                if (element.length) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combine"])(children = element.props, function(value) {
                    switch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["match"])(value, callback = /(::plac\w+|:read-\w+)/)){
                        // :read-(only|write)
                        case ':read-only':
                        case ':read-write':
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lift"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["copy"])(element, {
                                props: [
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /:(read-\w+)/, ':' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MOZ"] + '$1')
                                ]
                            }));
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lift"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["copy"])(element, {
                                props: [
                                    value
                                ]
                            }));
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assign"])(element, {
                                props: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filter"])(children, callback)
                            });
                            break;
                        // :placeholder
                        case '::placeholder':
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lift"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["copy"])(element, {
                                props: [
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /:(plac\w+)/, ':' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WEBKIT"] + 'input-$1')
                                ]
                            }));
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lift"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["copy"])(element, {
                                props: [
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /:(plac\w+)/, ':' + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MOZ"] + '$1')
                                ]
                            }));
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lift"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["copy"])(element, {
                                props: [
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(value, /:(plac\w+)/, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MS"] + 'input-$1')
                                ]
                            }));
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lift"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["copy"])(element, {
                                props: [
                                    value
                                ]
                            }));
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assign"])(element, {
                                props: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filter"])(children, callback)
                            });
                            break;
                    }
                    return '';
                });
        }
    }
}
function namespace(element) {
    switch(element.type){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RULESET"]:
            element.props = element.props.map(function(value) {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["combine"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tokenize"])(value), function(value, index, children) {
                    switch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(value, 0)){
                        // \f
                        case 12:
                            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["substr"])(value, 1, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strlen"])(value));
                        // \0 ( + > ~
                        case 0:
                        case 40:
                        case 43:
                        case 62:
                        case 126:
                            return value;
                        // :
                        case 58:
                            if (children[++index] === 'global') children[index] = '', children[++index] = '\f' + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["substr"])(children[index], index = 1, -1);
                        // \s
                        case 32:
                            return index === 1 ? '' : value;
                        default:
                            switch(index){
                                case 0:
                                    element = value;
                                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sizeof"])(children) > 1 ? '' : value;
                                case index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sizeof"])(children) - 1:
                                case 2:
                                    return index === 2 ? value + element + element : value + element;
                                default:
                                    return value;
                            }
                    }
                });
            });
    }
}
}),
"[project]/node_modules/stylis/src/Parser.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "comment",
    ()=>comment,
    "compile",
    ()=>compile,
    "declaration",
    ()=>declaration,
    "parse",
    ()=>parse,
    "ruleset",
    ()=>ruleset
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Enum.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Utility.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Tokenizer.js [app-client] (ecmascript)");
;
;
;
function compile(value) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dealloc"])(parse('', null, null, null, [
        ''
    ], value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["alloc"])(value), 0, [
        0
    ], value));
}
function parse(value, root, parent, rule, rules, rulesets, pseudo, points, declarations) {
    var index = 0;
    var offset = 0;
    var length = pseudo;
    var atrule = 0;
    var property = 0;
    var previous = 0;
    var variable = 1;
    var scanning = 1;
    var ampersand = 1;
    var character = 0;
    var type = '';
    var props = rules;
    var children = rulesets;
    var reference = rule;
    var characters = type;
    while(scanning)switch(previous = character, character = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["next"])()){
        // (
        case 40:
            if (previous != 108 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(characters, length - 1) == 58) {
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["indexof"])(characters += (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["delimit"])(character), '&', '&\f'), '&\f', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(index ? points[index - 1] : 0)) != -1) ampersand = -1;
                break;
            }
        // " ' [
        case 34:
        case 39:
        case 91:
            characters += (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["delimit"])(character);
            break;
        // \t \n \r \s
        case 9:
        case 10:
        case 13:
        case 32:
            characters += (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["whitespace"])(previous);
            break;
        // \
        case 92:
            characters += (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["escaping"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["caret"])() - 1, 7);
            continue;
        // /
        case 47:
            switch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["peek"])()){
                case 42:
                case 47:
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["append"])(comment((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["commenter"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["next"])(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["caret"])()), root, parent, declarations), declarations);
                    if (((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["token"])(previous || 1) == 5 || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["token"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["peek"])() || 1) == 5) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strlen"])(characters) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["substr"])(characters, -1, void 0) !== ' ') characters += ' ';
                    break;
                default:
                    characters += '/';
            }
            break;
        // {
        case 123 * variable:
            points[index++] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strlen"])(characters) * ampersand;
        // } ; \0
        case 125 * variable:
        case 59:
        case 0:
            switch(character){
                // \0 }
                case 0:
                case 125:
                    scanning = 0;
                // ;
                case 59 + offset:
                    if (ampersand == -1) characters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(characters, /\f/g, '');
                    if (property > 0 && ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strlen"])(characters) - length || variable === 0 && previous === 47)) (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["append"])(property > 32 ? declaration(characters + ';', rule, parent, length - 1, declarations) : declaration((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(characters, ' ', '') + ';', rule, parent, length - 2, declarations), declarations);
                    break;
                // @ ;
                case 59:
                    characters += ';';
                // { rule/at-rule
                default:
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["append"])(reference = ruleset(characters, root, parent, index, offset, rules, points, type, props = [], children = [], length, rulesets), rulesets);
                    if (character === 123) if (offset === 0) parse(characters, root, reference, reference, props, rulesets, length, points, children);
                    else {
                        switch(atrule){
                            // c(ontainer)
                            case 99:
                                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(characters, 3) === 110) break;
                            // l(ayer)
                            case 108:
                                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["charat"])(characters, 2) === 97) break;
                            default:
                                offset = 0;
                            // d(ocument) m(edia) s(upports)
                            case 100:
                            case 109:
                            case 115:
                        }
                        if (offset) parse(value, reference, reference, rule && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["append"])(ruleset(value, reference, reference, 0, 0, rules, points, type, rules, props = [], length, children), children), rules, children, length, points, rule ? props : children);
                        else parse(characters, reference, reference, reference, [
                            ''
                        ], children, 0, points, children);
                    }
            }
            index = offset = property = 0, variable = ampersand = 1, type = characters = '', length = pseudo;
            break;
        // :
        case 58:
            length = 1 + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strlen"])(characters), property = previous;
        default:
            if (variable < 1) {
                if (character == 123) --variable;
                else if (character == 125 && variable++ == 0 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prev"])() == 125) continue;
            }
            switch(characters += (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["from"])(character), character * variable){
                // &
                case 38:
                    ampersand = offset > 0 ? 1 : (characters += '\f', -1);
                    break;
                // ,
                case 44:
                    points[index++] = ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strlen"])(characters) - 1) * ampersand, ampersand = 1;
                    break;
                // @
                case 64:
                    // -
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["peek"])() === 45) characters += (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["delimit"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["next"])());
                    atrule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["peek"])(), offset = length = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strlen"])(type = characters += (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["identifier"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["caret"])())), character++;
                    break;
                // -
                case 45:
                    if (previous === 45 && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["strlen"])(characters) == 2) variable = 0;
            }
    }
    return rulesets;
}
function ruleset(value, root, parent, index, offset, rules, points, type, props, children, length, siblings) {
    var post = offset - 1;
    var rule = offset === 0 ? rules : [
        ''
    ];
    var size = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sizeof"])(rule);
    for(var i = 0, j = 0, k = 0; i < index; ++i)for(var x = 0, y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["substr"])(value, post + 1, post = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(j = points[i])), z = value; x < size; ++x)if (z = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trim"])(j > 0 ? rule[x] + ' ' + y : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replace"])(y, /&\f/g, rule[x]))) props[k++] = z;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["node"])(value, root, parent, offset === 0 ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RULESET"] : type, props, children, length, siblings);
}
function comment(value, root, parent, siblings) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["node"])(value, root, parent, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COMMENT"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["from"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["char"])()), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["substr"])(value, 2, -2), 0, siblings);
}
function declaration(value, root, parent, length, siblings) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Tokenizer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["node"])(value, root, parent, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DECLARATION"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["substr"])(value, 0, length), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Utility$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["substr"])(value, length + 1, -1), length, siblings);
}
}),
"[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ServerStyleSheet",
    ()=>At,
    "StyleSheetConsumer",
    ()=>Qe,
    "StyleSheetContext",
    ()=>Ke,
    "StyleSheetManager",
    ()=>et,
    "ThemeConsumer",
    ()=>nt,
    "ThemeContext",
    ()=>tt,
    "ThemeProvider",
    ()=>st,
    "__PRIVATE__",
    ()=>Pt,
    "createGlobalStyle",
    ()=>vt,
    "createTheme",
    ()=>wt,
    "css",
    ()=>pt,
    "default",
    ()=>yt,
    "isStyledComponent",
    ()=>ie,
    "keyframes",
    ()=>Ot,
    "styled",
    ()=>yt,
    "stylisPluginRSC",
    ()=>Tt,
    "useTheme",
    ()=>ot,
    "version",
    ()=>u,
    "withTheme",
    ()=>Et
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$emotion$2f$is$2d$prop$2d$valid$2f$dist$2f$emotion$2d$is$2d$prop$2d$valid$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@emotion/is-prop-valid/dist/emotion-is-prop-valid.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Enum.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Middleware$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Middleware.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Serializer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Serializer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Parser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/stylis/src/Parser.js [app-client] (ecmascript)");
;
;
;
;
var r, i;
const c = "undefined" != typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] && void 0 !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env && (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.REACT_APP_SC_ATTR || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.SC_ATTR) || "data-styled", a = "active", l = "data-styled-version", u = "6.4.1", h = "/*!sc*/\n", d = "undefined" != typeof window && "undefined" != typeof document;
function p(e) {
    if ("undefined" != typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] && void 0 !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env) {
        const t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env[e];
        if (void 0 !== t && "" !== t) return "false" !== t;
    }
}
const f = Boolean("boolean" == typeof SC_DISABLE_SPEEDY ? SC_DISABLE_SPEEDY : null !== (i = null !== (r = p("REACT_APP_SC_DISABLE_SPEEDY")) && void 0 !== r ? r : p("SC_DISABLE_SPEEDY")) && void 0 !== i ? i : "undefined" == typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] || void 0 === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env || "production" !== ("TURBOPACK compile-time value", "development")), m = "sc-keyframes-", y = {}, g = ("TURBOPACK compile-time truthy", 1) ? {
    1: "Cannot create styled-component for component: %s.\n\n",
    2: "Can't collect styles once you've consumed a `ServerStyleSheet`'s styles! `ServerStyleSheet` is a one off instance for each server-side render cycle.\n\n- Are you trying to reuse it across renders?\n- Are you accidentally calling collectStyles twice?\n\n",
    3: "Streaming SSR is only supported in a Node.js environment; Please do not try to call this method in the browser.\n\n",
    4: "The `StyleSheetManager` expects a valid target or sheet prop!\n\n- Does this error occur on the client and is your target falsy?\n- Does this error occur on the server and is the sheet falsy?\n\n",
    5: "The clone method cannot be used on the client!\n\n- Are you running in a client-like environment on the server?\n- Are you trying to run SSR on the client?\n\n",
    6: "Trying to insert a new style tag, but the given Node is unmounted!\n\n- Are you using a custom target that isn't mounted?\n- Does your document not have a valid head element?\n- Have you accidentally removed a style tag manually?\n\n",
    7: 'ThemeProvider: Please return an object from your "theme" prop function, e.g.\n\n```js\ntheme={() => ({})}\n```\n\n',
    8: 'ThemeProvider: Please make your "theme" prop an object.\n\n',
    9: "Missing document `<head>`\n\n",
    10: "Cannot find a StyleSheet instance. Usually this happens if there are multiple copies of styled-components loaded at once. Check out this issue for how to troubleshoot and fix the common cases where this situation can happen: https://github.com/styled-components/styled-components/issues/1941#issuecomment-417862021\n\n",
    11: "_This error was replaced with a dev-time warning, it will be deleted for v4 final._ [createGlobalStyle] received children which will not be rendered. Please use the component without passing children elements.\n\n",
    12: "It seems you are interpolating a keyframe declaration (%s) into an untagged string. Please wrap your string in the css\\`\\` helper which ensures the styles are injected correctly. See https://styled-components.com/docs/api#css\n\n",
    13: "%s is not a styled component and cannot be referred to via component selector. See https://styled-components.com/docs/advanced#referring-to-other-components for more details.\n\n",
    14: 'ThemeProvider: "theme" prop is required.\n\n',
    15: "A stylis plugin has been supplied that is not named. We need a name for each plugin to be able to prevent styling collisions between different stylis configurations within the same app. Before you pass your plugin to `<StyleSheetManager stylisPlugins={[]}>`, please make sure each plugin is uniquely-named, e.g.\n\n```js\nObject.defineProperty(importedPlugin, 'name', { value: 'some-unique-name' });\n```\n\n",
    16: "Reached the limit of how many styled components may be created at group %s.\nYou may only create up to 1,073,741,824 components. If you're creating components dynamically,\nas for instance in your render method then you may be running into this limitation.\n\n",
    17: "CSSStyleSheet could not be found on HTMLStyleElement.\nHas styled-components' style tag been unmounted or altered by another script?\n\n",
    18: "Accessing `useTheme` hook outside of a `<ThemeProvider>` element.\n\n```jsx\nimport { useTheme } from 'styled-components';\nexport function StyledCompoent({ children }) {\n  const theme = useTheme();\n  return <div style={{ width: theme.sizes.full }}>{children}</div>;\n}\n\nimport { StyledComponent } from './StyledComponent';\nimport { theme } from './theme';\nexport function App() {\n  return (\n    <ThemeProvider theme={theme}>\n      <StyledComponent />\n    </ThemeProvider>\n  );\n}\n```\n\nIf you need access to the theme in an uncertain composition scenario, `React.useContext(ThemeContext)` will not emit an error if there is no `ThemeProvider` ancestor.\n"
} : "TURBOPACK unreachable";
function v(e, ...t) {
    return ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : new Error((function(...e) {
        let t = e[0];
        const n = [];
        for(let t = 1, o = e.length; t < o; t += 1)n.push(e[t]);
        return n.forEach((e)=>{
            t = t.replace(/%[a-z]/, e);
        }), t;
    })(g[e], ...t).trim());
}
const S = 1 << 30;
let b = new Map, w = new Map, N = 1;
const C = (e)=>{
    if (b.has(e)) return b.get(e);
    for(; w.has(N);)N++;
    const t = N++;
    if ("production" !== ("TURBOPACK compile-time value", "development") && ((0 | t) < 0 || t > S)) throw v(16, `${t}`);
    return b.set(e, t), w.set(t, e), t;
}, O = (e)=>w.get(e), E = (e, t)=>{
    N = t + 1, b.set(e, t), w.set(t, e);
}, A = /invalid hook call/i, P = new Set, _ = (e, n)=>{
    if ("TURBOPACK compile-time truthy", 1) {
        const o = `The component ${e}${n ? ` with the id of "${n}"` : ""} has been created dynamically.\nYou may see this warning because you've called styled inside another component.\nTo resolve this only create new StyledComponents outside of any render method and function component.\nSee https://styled-components.com/docs/basics#define-styled-components-outside-of-the-render-method for more info.\n`, s = console.error;
        try {
            let e = !0;
            console.error = (t, ...n)=>{
                A.test(t) ? (e = !1, P.delete(o)) : s(t, ...n);
            }, "function" == typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null), e && !P.has(o) && (console.warn(o), P.add(o));
        } catch (e) {
            A.test(e.message) && P.delete(o);
        } finally{
            console.error = s;
        }
    }
}, I = Object.freeze([]), $ = Object.freeze({});
function R(e, t, n = $) {
    return e.theme !== n.theme && e.theme || t || n.theme;
}
const j = /[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g, x = /(^-|-$)/g;
function T(e) {
    return e.replace(j, "-").replace(x, "");
}
const k = /(a)(d)/gi, D = (e)=>String.fromCharCode(e + (e > 25 ? 39 : 97));
function V(e) {
    let t, n = "";
    for(t = Math.abs(e); t > 52; t = t / 52 | 0)n = D(t % 52) + n;
    return (D(t % 52) + n).replace(k, "$1-$2");
}
const M = 5381, G = (e, t)=>{
    let n = t.length;
    for(; n;)e = 33 * e ^ t.charCodeAt(--n);
    return e;
}, F = (e)=>G(M, e);
function z(e) {
    return V(F(e) >>> 0);
}
function W(e) {
    return "production" !== ("TURBOPACK compile-time value", "development") && "string" == typeof e && e || e.displayName || e.name || "Component";
}
function L(e) {
    return "string" == typeof e && ("production" === ("TURBOPACK compile-time value", "development") || e.charAt(0) === e.charAt(0).toLowerCase());
}
function B(e) {
    return L(e) ? `styled.${e}` : `Styled(${W(e)})`;
}
const q = Symbol.for("react.memo"), H = Symbol.for("react.forward_ref"), Y = {
    contextType: !0,
    defaultProps: !0,
    displayName: !0,
    getDerivedStateFromError: !0,
    getDerivedStateFromProps: !0,
    propTypes: !0,
    type: !0
}, U = {
    name: !0,
    length: !0,
    prototype: !0,
    caller: !0,
    callee: !0,
    arguments: !0,
    arity: !0
}, J = {
    $$typeof: !0,
    compare: !0,
    defaultProps: !0,
    displayName: !0,
    propTypes: !0,
    type: !0
}, X = {
    [H]: {
        $$typeof: !0,
        render: !0,
        defaultProps: !0,
        displayName: !0,
        propTypes: !0
    },
    [q]: J
};
function K(e) {
    return ("type" in (t = e) && t.type.$$typeof) === q ? J : "$$typeof" in e ? X[e.$$typeof] : Y;
    //TURBOPACK unreachable
    ;
    var t;
}
const Q = Object.defineProperty, Z = Object.getOwnPropertyNames, ee = Object.getOwnPropertySymbols, te = Object.getOwnPropertyDescriptor, ne = Object.getPrototypeOf, oe = Object.prototype;
function se(e, t, n) {
    if ("string" != typeof t) {
        const o = ne(t);
        o && o !== oe && se(e, o, n);
        const s = Z(t).concat(ee(t)), r = K(e), i = K(t);
        for(let o = 0; o < s.length; ++o){
            const c = s[o];
            if (!(c in U || n && n[c] || i && c in i || r && c in r)) {
                const n = te(t, c);
                try {
                    Q(e, c, n);
                } catch (e) {}
            }
        }
    }
    return e;
}
function re(e) {
    return "function" == typeof e;
}
function ie(e) {
    return "object" == typeof e && "styledComponentId" in e;
}
function ce(e, t) {
    return e && t ? e + " " + t : e || t || "";
}
function ae(e, t) {
    return e.join(t || "");
}
function le(e) {
    return null !== e && "object" == typeof e && e.constructor.name === Object.name && !("props" in e && e.$$typeof);
}
function ue(e, t, n = !1) {
    if (!n && !le(e) && !Array.isArray(e)) return t;
    if (Array.isArray(t)) for(let n = 0; n < t.length; n++)e[n] = ue(e[n], t[n]);
    else if (le(t)) for(const n in t)e[n] = ue(e[n], t[n]);
    return e;
}
function he(e, t) {
    Object.defineProperty(e, "toString", {
        value: t
    });
}
const de = class {
    constructor(e){
        this.groupSizes = new Uint32Array(512), this.length = 512, this.tag = e, this._cGroup = 0, this._cIndex = 0;
    }
    indexOfGroup(e) {
        if (e === this._cGroup) return this._cIndex;
        let t = this._cIndex;
        if (e > this._cGroup) for(let n = this._cGroup; n < e; n++)t += this.groupSizes[n];
        else for(let n = this._cGroup - 1; n >= e; n--)t -= this.groupSizes[n];
        return this._cGroup = e, this._cIndex = t, t;
    }
    insertRules(e, t) {
        if (e >= this.groupSizes.length) {
            const t = this.groupSizes, n = t.length;
            let o = n;
            for(; e >= o;)if (o <<= 1, o < 0) throw v(16, `${e}`);
            this.groupSizes = new Uint32Array(o), this.groupSizes.set(t), this.length = o;
            for(let e = n; e < o; e++)this.groupSizes[e] = 0;
        }
        let n = this.indexOfGroup(e + 1), o = 0;
        for(let s = 0, r = t.length; s < r; s++)this.tag.insertRule(n, t[s]) && (this.groupSizes[e]++, n++, o++);
        o > 0 && this._cGroup > e && (this._cIndex += o);
    }
    clearGroup(e) {
        if (e < this.length) {
            const t = this.groupSizes[e], n = this.indexOfGroup(e), o = n + t;
            this.groupSizes[e] = 0;
            for(let e = n; e < o; e++)this.tag.deleteRule(n);
            t > 0 && this._cGroup > e && (this._cIndex -= t);
        }
    }
    getGroup(e) {
        let t = "";
        if (e >= this.length || 0 === this.groupSizes[e]) return t;
        const n = this.groupSizes[e], o = this.indexOfGroup(e), s = o + n;
        for(let e = o; e < s; e++)t += this.tag.getRule(e) + h;
        return t;
    }
}, pe = `style[${c}][${l}="${u}"]`, fe = new RegExp(`^${c}\\.g(\\d+)\\[id="([\\w\\d-]+)"\\].*?"([^"]*)`), me = (e)=>"undefined" != typeof ShadowRoot && e instanceof ShadowRoot || "host" in e && 11 === e.nodeType, ye = (e)=>{
    if (!e) return document;
    if (me(e)) return e;
    if ("getRootNode" in e) {
        const t = e.getRootNode();
        if (me(t)) return t;
    }
    return document;
}, ge = (e, t, n)=>{
    const o = n.split(",");
    let s;
    for(let n = 0, r = o.length; n < r; n++)(s = o[n]) && e.registerName(t, s);
}, ve = (e, t)=>{
    var n;
    const o = (null !== (n = t.textContent) && void 0 !== n ? n : "").split(h), s = [];
    for(let t = 0, n = o.length; t < n; t++){
        const n = o[t].trim();
        if (!n) continue;
        const r = n.match(fe);
        if (r) {
            const t = 0 | parseInt(r[1], 10), n = r[2];
            0 !== t && (E(n, t), ge(e, n, r[3]), e.getTag().insertRules(t, s)), s.length = 0;
        } else s.push(n);
    }
}, Se = (e)=>{
    const t = ye(e.options.target).querySelectorAll(pe);
    for(let n = 0, o = t.length; n < o; n++){
        const o = t[n];
        o && o.getAttribute(c) !== a && (ve(e, o), o.parentNode && o.parentNode.removeChild(o));
    }
};
let be = !1;
function we() {
    if (!1 !== be) return be;
    if ("undefined" != typeof document) {
        const e = document.head.querySelector('meta[property="csp-nonce"]');
        if (e) return be = e.nonce || e.getAttribute("content") || void 0;
        const t = document.head.querySelector('meta[name="sc-nonce"]');
        if (t) return be = t.getAttribute("content") || void 0;
    }
    return be = "undefined" != typeof __webpack_nonce__ ? __webpack_nonce__ : void 0;
}
const Ne = (e, t)=>{
    const n = document.head, o = e || n, s = document.createElement("style"), r = ((e)=>{
        const t = Array.from(e.querySelectorAll(`style[${c}]`));
        return t[t.length - 1];
    })(o), i = void 0 !== r ? r.nextSibling : null;
    s.setAttribute(c, a), s.setAttribute(l, u);
    const h = t || we();
    return h && s.setAttribute("nonce", h), o.insertBefore(s, i), s;
}, Ce = class {
    constructor(e, t){
        this.element = Ne(e, t), this.element.appendChild(document.createTextNode("")), this.sheet = ((e)=>{
            var t;
            if (e.sheet) return e.sheet;
            const n = null !== (t = e.getRootNode().styleSheets) && void 0 !== t ? t : document.styleSheets;
            for(let t = 0, o = n.length; t < o; t++){
                const o = n[t];
                if (o.ownerNode === e) return o;
            }
            throw v(17);
        })(this.element), this.length = 0;
    }
    insertRule(e, t) {
        try {
            return this.sheet.insertRule(t, e), this.length++, !0;
        } catch (e) {
            return !1;
        }
    }
    deleteRule(e) {
        this.sheet.deleteRule(e), this.length--;
    }
    getRule(e) {
        const t = this.sheet.cssRules[e];
        return t && t.cssText ? t.cssText : "";
    }
}, Oe = class {
    constructor(e, t){
        this.element = Ne(e, t), this.nodes = this.element.childNodes, this.length = 0;
    }
    insertRule(e, t) {
        if (e <= this.length && e >= 0) {
            const n = document.createTextNode(t);
            return this.element.insertBefore(n, this.nodes[e] || null), this.length++, !0;
        }
        return !1;
    }
    deleteRule(e) {
        this.element.removeChild(this.nodes[e]), this.length--;
    }
    getRule(e) {
        return e < this.length ? this.nodes[e].textContent : "";
    }
};
let Ee = d;
const Ae = {
    isServer: !d,
    useCSSOMInjection: !f
};
class Pe {
    static registerId(e) {
        return C(e);
    }
    constructor(e = $, t = {}, n){
        this.options = Object.assign(Object.assign({}, Ae), e), this.gs = t, this.keyframeIds = new Set, this.names = new Map(n), this.server = !!e.isServer, !this.server && d && Ee && (Ee = !1, Se(this)), he(this, ()=>((e)=>{
                const t = e.getTag(), { length: n } = t;
                let o = "";
                for(let s = 0; s < n; s++){
                    const n = O(s);
                    if (void 0 === n) continue;
                    const r = e.names.get(n);
                    if (void 0 === r || !r.size) continue;
                    const i = t.getGroup(s);
                    if (0 === i.length) continue;
                    const a = c + ".g" + s + '[id="' + n + '"]';
                    let l = "";
                    for (const e of r)e.length > 0 && (l += e + ",");
                    o += i + a + '{content:"' + l + '"}' + h;
                }
                return o;
            })(this));
    }
    rehydrate() {
        !this.server && d && Se(this);
    }
    reconstructWithOptions(e, t = !0) {
        const n = new Pe(Object.assign(Object.assign({}, this.options), e), this.gs, t && this.names || void 0);
        return n.keyframeIds = new Set(this.keyframeIds), !this.server && d && e.target !== this.options.target && ye(this.options.target) !== ye(e.target) && Se(n), n;
    }
    allocateGSInstance(e) {
        return this.gs[e] = (this.gs[e] || 0) + 1;
    }
    getTag() {
        return this.tag || (this.tag = (e = (({ useCSSOMInjection: e, target: t, nonce: n })=>e ? new Ce(t, n) : new Oe(t, n))(this.options), new de(e)));
        //TURBOPACK unreachable
        ;
        var e;
    }
    hasNameForId(e, t) {
        var n, o;
        return null !== (o = null === (n = this.names.get(e)) || void 0 === n ? void 0 : n.has(t)) && void 0 !== o && o;
    }
    registerName(e, t) {
        C(e), e.startsWith(m) && this.keyframeIds.add(e);
        const n = this.names.get(e);
        n ? n.add(t) : this.names.set(e, new Set([
            t
        ]));
    }
    insertRules(e, t, n) {
        this.registerName(e, t), this.getTag().insertRules(C(e), n);
    }
    clearNames(e) {
        this.names.has(e) && this.names.get(e).clear();
    }
    clearRules(e) {
        this.getTag().clearGroup(C(e)), this.clearNames(e);
    }
    clearTag() {
        this.tag = void 0;
    }
}
const _e = new WeakSet, Ie = {
    animationIterationCount: 1,
    aspectRatio: 1,
    borderImageOutset: 1,
    borderImageSlice: 1,
    borderImageWidth: 1,
    columnCount: 1,
    columns: 1,
    flex: 1,
    flexGrow: 1,
    flexShrink: 1,
    gridRow: 1,
    gridRowEnd: 1,
    gridRowSpan: 1,
    gridRowStart: 1,
    gridColumn: 1,
    gridColumnEnd: 1,
    gridColumnSpan: 1,
    gridColumnStart: 1,
    fontWeight: 1,
    lineHeight: 1,
    opacity: 1,
    order: 1,
    orphans: 1,
    scale: 1,
    tabSize: 1,
    widows: 1,
    zIndex: 1,
    zoom: 1,
    WebkitLineClamp: 1,
    fillOpacity: 1,
    floodOpacity: 1,
    stopOpacity: 1,
    strokeDasharray: 1,
    strokeDashoffset: 1,
    strokeMiterlimit: 1,
    strokeOpacity: 1,
    strokeWidth: 1
};
function $e(e, t) {
    return null == t || "boolean" == typeof t || "" === t ? "" : "number" != typeof t || 0 === t || e in Ie || e.startsWith("--") ? String(t).trim() : t + "px";
}
const Re = 47;
function je(e) {
    if (45 === e.charCodeAt(0) && 45 === e.charCodeAt(1)) return e;
    let t = "";
    for(let n = 0; n < e.length; n++){
        const o = e.charCodeAt(n);
        t += o >= 65 && o <= 90 ? "-" + String.fromCharCode(o + 32) : e[n];
    }
    return t.startsWith("ms-") ? "-" + t : t;
}
const xe = Symbol.for("sc-keyframes");
function Te(e) {
    return "object" == typeof e && null !== e && xe in e;
}
function ke(e) {
    return re(e) && !(e.prototype && e.prototype.isReactComponent);
}
const De = (e)=>null == e || !1 === e || "" === e, Ve = Symbol.for("react.client.reference");
function Me(e) {
    return e.$$typeof === Ve;
}
function Ge(e) {
    const t = e.$$id, n = (t && t.includes("#") ? t.split("#").pop() : t) || e.name || "unknown";
    console.warn(`Interpolating a client component (${n}) as a selector is not supported in server components. The component selector pattern requires access to the component's internal class name, which is not available across the server/client boundary. Use a plain CSS class selector instead.`);
}
function Fe(e, t) {
    for(const n in e){
        const o = e[n];
        e.hasOwnProperty(n) && !De(o) && (Array.isArray(o) && _e.has(o) || re(o) ? t.push(je(n) + ":", o, ";") : le(o) ? (t.push(n + " {"), Fe(o, t), t.push("}")) : t.push(je(n) + ": " + $e(n, o) + ";"));
    }
}
function ze(e, t, n, o, s = []) {
    if (De(e)) return s;
    const r = typeof e;
    if ("string" === r) return s.push(e), s;
    if ("function" === r) {
        if (Me(e)) return "production" !== ("TURBOPACK compile-time value", "development") && Ge(e), s;
        if (ke(e) && t) {
            const r = e(t);
            return "production" === ("TURBOPACK compile-time value", "development") || "object" != typeof r || Array.isArray(r) || Te(r) || le(r) || null === r || console.error(`${W(e)} is not a styled component and cannot be referred to via component selector. See https://styled-components.com/docs/advanced#referring-to-other-components for more details.`), ze(r, t, n, o, s);
        }
        return s.push(e), s;
    }
    if (Array.isArray(e)) {
        for(let r = 0; r < e.length; r++)ze(e[r], t, n, o, s);
        return s;
    }
    return ie(e) ? (s.push(`.${e.styledComponentId}`), s) : Te(e) ? (n ? (e.inject(n, o), s.push(e.getName(o))) : s.push(e), s) : Me(e) ? ("production" !== ("TURBOPACK compile-time value", "development") && Ge(e), s) : le(e) ? (Fe(e, s), s) : (s.push(e.toString()), s);
}
const We = F(u);
class Le {
    constructor(e, t, n){
        this.rules = e, this.componentId = t, this.baseHash = G(We, t), this.baseStyle = n, Pe.registerId(t);
    }
    generateAndInjectStyles(e, t, n) {
        let o = this.baseStyle ? this.baseStyle.generateAndInjectStyles(e, t, n) : "";
        {
            let s = "";
            for(let o = 0; o < this.rules.length; o++){
                const r = this.rules[o];
                if ("string" == typeof r) s += r;
                else if (r) if (ke(r)) {
                    const o = r(e);
                    "string" == typeof o ? s += o : null != o && !1 !== o && ("production" === ("TURBOPACK compile-time value", "development") || "object" != typeof o || Array.isArray(o) || Te(o) || le(o) || console.error(`${W(r)} is not a styled component and cannot be referred to via component selector. See https://styled-components.com/docs/advanced#referring-to-other-components for more details.`), s += ae(ze(o, e, t, n)));
                } else s += ae(ze(r, e, t, n));
            }
            if (s) {
                this.dynamicNameCache || (this.dynamicNameCache = new Map);
                const e = n.hash ? n.hash + s : s;
                let r = this.dynamicNameCache.get(e);
                if (!r) {
                    if (r = V(G(G(this.baseHash, n.hash), s) >>> 0), this.dynamicNameCache.size >= 200) {
                        const e = this.dynamicNameCache.keys().next().value;
                        void 0 !== e && this.dynamicNameCache.delete(e);
                    }
                    this.dynamicNameCache.set(e, r);
                }
                if (!t.hasNameForId(this.componentId, r)) {
                    const e = n(s, "." + r, void 0, this.componentId);
                    t.insertRules(this.componentId, r, e);
                }
                o = ce(o, r);
            }
        }
        return o;
    }
}
const Be = /&/g;
function qe(e, t) {
    let n = 0;
    for(; --t >= 0 && 92 === e.charCodeAt(t);)n++;
    return !(1 & ~n);
}
function He(e) {
    const t = e.length;
    let n = "", o = 0, s = 0, r = 0, i = !1, c = !1;
    for(let a = 0; a < t; a++){
        const l = e.charCodeAt(a);
        if (0 !== r || i || l !== Re || 42 !== e.charCodeAt(a + 1)) if (i) 42 === l && e.charCodeAt(a + 1) === Re && (i = !1, a++);
        else if (34 !== l && 39 !== l || qe(e, a)) {
            if (0 === r) if (123 === l) s++;
            else if (125 === l) {
                if (s--, s < 0) {
                    c = !0;
                    let n = a + 1;
                    for(; n < t;){
                        const t = e.charCodeAt(n);
                        if (59 === t || 10 === t) break;
                        n++;
                    }
                    n < t && 59 === e.charCodeAt(n) && n++, s = 0, a = n - 1, o = n;
                    continue;
                }
                0 === s && (n += e.substring(o, a + 1), o = a + 1);
            } else 59 === l && 0 === s && (n += e.substring(o, a + 1), o = a + 1);
        } else 0 === r ? r = l : r === l && (r = 0);
        else i = !0, a++;
    }
    return c || 0 !== s || 0 !== r ? (o < t && 0 === s && 0 === r && (n += e.substring(o)), n) : e;
}
function Ye(e, t) {
    const n = t + " ", o = "," + n;
    for(let s = 0; s < e.length; s++){
        const r = e[s];
        if ("rule" === r.type) {
            r.value = (n + r.value).replaceAll(",", o);
            const e = r.props, t = [];
            for(let o = 0; o < e.length; o++)t[o] = n + e[o];
            r.props = t;
        }
        Array.isArray(r.children) && "@keyframes" !== r.type && Ye(r.children, t);
    }
    return e;
}
function Ue({ options: e = $, plugins: t = I } = $) {
    let n, s, r;
    const i = (e, t, o)=>o.startsWith(s) && o.endsWith(s) && o.replaceAll(s, "").length > 0 ? `.${n}` : e, c = t.slice();
    c.push((e)=>{
        e.type === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RULESET"] && e.value.includes("&") && (r || (r = new RegExp(`\\${s}\\b`, "g")), e.props[0] = e.props[0].replace(Be, s).replace(r, i));
    }), e.prefix && c.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Middleware$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prefixer"]), c.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Serializer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"]);
    let a = [];
    const l = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Middleware$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["middleware"](c.concat(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Middleware$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rulesheet"]((e)=>a.push(e)))), u = (t, i = "", c = "", u = "&")=>{
        n = u, s = i, r = void 0;
        const h = function(e) {
            const t = -1 !== e.indexOf("//"), n = -1 !== e.indexOf("}");
            if (!t && !n) return e;
            if (!t) return He(e);
            const o = e.length;
            let s = "", r = 0, i = 0, c = 0, a = 0, l = 0, u = !1;
            for(; i < o;){
                const t = e.charCodeAt(i);
                if (34 !== t && 39 !== t || qe(e, i)) if (0 === c) if (t === Re && i + 1 < o && 42 === e.charCodeAt(i + 1)) {
                    for(i += 2; i + 1 < o && (42 !== e.charCodeAt(i) || e.charCodeAt(i + 1) !== Re);)i++;
                    i += 2;
                } else if (40 !== t) if (41 !== t) if (a > 0) i++;
                else if (42 === t && i + 1 < o && e.charCodeAt(i + 1) === Re) s += e.substring(r, i), i += 2, r = i, u = !0;
                else if (t === Re && i + 1 < o && e.charCodeAt(i + 1) === Re) {
                    for(s += e.substring(r, i); i < o && 10 !== e.charCodeAt(i);)i++;
                    r = i, u = !0;
                } else 123 === t ? l++ : 125 === t && l--, i++;
                else a > 0 && a--, i++;
                else a++, i++;
                else i++;
                else 0 === c ? c = t : c === t && (c = 0), i++;
            }
            return u ? (r < o && (s += e.substring(r)), 0 === l ? s : He(s)) : 0 === l ? e : He(e);
        }(t);
        let d = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Parser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compile"](c || i ? c + " " + i + " { " + h + " }" : h);
        return e.namespace && (d = Ye(d, e.namespace)), a = [], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Serializer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["serialize"](d, l), a;
    }, h = e;
    let d = M;
    for(let e = 0; e < t.length; e++)t[e].name || v(15), d = G(d, t[e].name);
    return (null == h ? void 0 : h.namespace) && (d = G(d, h.namespace)), (null == h ? void 0 : h.prefix) && (d = G(d, "p")), u.hash = d !== M ? d.toString() : "", u;
}
const Je = new Pe, Xe = Ue(), Ke = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext({
    shouldForwardProp: void 0,
    styleSheet: Je,
    stylis: Xe,
    stylisPlugins: void 0
}), Qe = Ke.Consumer;
function Ze() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(Ke);
}
function et(e) {
    var n;
    const o = Ze(), { styleSheet: s } = o, r = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "et.useMemo[r]": ()=>{
            let t = s;
            return e.sheet ? t = e.sheet : e.target ? t = t.reconstructWithOptions(void 0 !== e.nonce ? {
                target: e.target,
                nonce: e.nonce
            } : {
                target: e.target
            }, !1) : void 0 !== e.nonce && (t = t.reconstructWithOptions({
                nonce: e.nonce
            })), e.disableCSSOMInjection && (t = t.reconstructWithOptions({
                useCSSOMInjection: !1
            })), t;
        }
    }["et.useMemo[r]"], [
        e.disableCSSOMInjection,
        e.nonce,
        e.sheet,
        e.target,
        s
    ]), i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "et.useMemo[i]": ()=>{
            var t;
            return void 0 === e.stylisPlugins && void 0 === e.namespace && void 0 === e.enableVendorPrefixes ? o.stylis : Ue({
                options: {
                    namespace: e.namespace,
                    prefix: e.enableVendorPrefixes
                },
                plugins: null !== (t = e.stylisPlugins) && void 0 !== t ? t : o.stylisPlugins
            });
        }
    }["et.useMemo[i]"], [
        e.enableVendorPrefixes,
        e.namespace,
        e.stylisPlugins,
        o.stylis,
        o.stylisPlugins
    ]), c = "shouldForwardProp" in e ? e.shouldForwardProp : o.shouldForwardProp, a = null !== (n = e.stylisPlugins) && void 0 !== n ? n : o.stylisPlugins, l = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "et.useMemo[l]": ()=>({
                shouldForwardProp: c,
                styleSheet: r,
                stylis: i,
                stylisPlugins: a
            })
    }["et.useMemo[l]"], [
        c,
        r,
        i,
        a
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Ke.Provider, {
        value: l
    }, e.children);
}
const tt = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext(void 0), nt = tt.Consumer;
function ot() {
    const e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(tt);
    if (!e) throw v(18);
    return e;
}
function st(e) {
    const n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(tt), o = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "st.useMemo[o]": ()=>({
                "st.useMemo[o]": function(e, t) {
                    if (!e) throw v(14);
                    if (re(e)) {
                        const n = e(t);
                        if ("production" !== ("TURBOPACK compile-time value", "development") && (null === n || Array.isArray(n) || "object" != typeof n)) throw v(7);
                        return n;
                    }
                    if (Array.isArray(e) || "object" != typeof e) throw v(8);
                    return t ? Object.assign(Object.assign({}, t), e) : e;
                }
            })["st.useMemo[o]"](e.theme, n)
    }["st.useMemo[o]"], [
        e.theme,
        n
    ]);
    return e.children ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(tt.Provider, {
        value: o
    }, e.children) : null;
}
const rt = Object.prototype.hasOwnProperty, it = {};
function ct(e, t) {
    const n = "string" != typeof e ? "sc" : T(e);
    it[n] = (it[n] || 0) + 1;
    const o = n + "-" + z(u + n + it[n]);
    return t ? t + "-" + o : o;
}
let at;
function lt(o, s, r) {
    const i = ie(o), c = o, a = !L(o), { attrs: l = I, componentId: u = ct(s.displayName, s.parentComponentId), displayName: h = B(o) } = s, d = s.displayName && s.componentId ? T(s.displayName) + "-" + s.componentId : s.componentId || u, p = i && c.attrs ? c.attrs.concat(l).filter(Boolean) : l;
    let { shouldForwardProp: f } = s;
    if (i && c.shouldForwardProp) {
        const e = c.shouldForwardProp;
        if (s.shouldForwardProp) {
            const t = s.shouldForwardProp;
            f = (n, o)=>e(n, o) && t(n, o);
        } else f = e;
    }
    const m = new Le(r, d, i ? c.componentStyle : void 0);
    function y(o, s) {
        return function(o, s, r) {
            const { attrs: i, componentStyle: c, defaultProps: a, foldedComponentIds: l, styledComponentId: u, target: h } = o, d = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(tt), p = Ze(), f = o.shouldForwardProp || p.shouldForwardProp;
            "production" !== ("TURBOPACK compile-time value", "development") && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useDebugValue && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useDebugValue(u);
            const m = R(s, d, a) || $;
            let y, g;
            {
                const e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null), n = e.current;
                if (null !== n && n[1] === m && n[2] === p.styleSheet && n[3] === p.stylis && n[7] === c && function(e, t, n) {
                    const o = e, s = t;
                    let r = 0;
                    for(const e in s)if (rt.call(s, e) && (r++, o[e] !== s[e])) return !1;
                    return r === n;
                }(n[0], s, n[4])) y = n[5], g = n[6];
                else {
                    y = function(e, t, n) {
                        const o = Object.assign(Object.assign({}, t), {
                            className: void 0,
                            theme: n
                        }), s = e.length > 1;
                        for(let n = 0; n < e.length; n++){
                            const r = e[n], i = re(r) ? r(s ? Object.assign({}, o) : o) : r;
                            for(const e in i)"className" === e ? o.className = ce(o.className, i[e]) : "style" === e ? o.style = Object.assign(Object.assign({}, o.style), i[e]) : e in t && void 0 === t[e] || (o[e] = i[e]);
                        }
                        return "className" in t && "string" == typeof t.className && (o.className = ce(o.className, t.className)), o;
                    }(i, s, m), g = function(e, n, o, s) {
                        const r = e.generateAndInjectStyles(n, o, s);
                        return "production" !== ("TURBOPACK compile-time value", "development") && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useDebugValue && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useDebugValue(r), r;
                    }(c, y, p.styleSheet, p.stylis);
                    let n = 0;
                    for(const e in s)rt.call(s, e) && n++;
                    e.current = [
                        s,
                        m,
                        p.styleSheet,
                        p.stylis,
                        n,
                        y,
                        g,
                        c
                    ];
                }
            }
            "production" !== ("TURBOPACK compile-time value", "development") && o.warnTooManyClasses && o.warnTooManyClasses(g);
            const v = y.as || h, S = function(t, n, o, s) {
                const r = {};
                for(const i in t)void 0 === t[i] || "$" === i[0] || "as" === i || "theme" === i && t.theme === o || ("forwardedAs" === i ? r.as = t.forwardedAs : s && !s(i, n) || (r[i] = t[i], s || "development" !== ("TURBOPACK compile-time value", "development") || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$emotion$2f$is$2d$prop$2d$valid$2f$dist$2f$emotion$2d$is$2d$prop$2d$valid$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(i) || (at || (at = new Set)).has(i) || !L(n) || n.includes("-") || (at.add(i), console.warn(`styled-components: it looks like an unknown prop "${i}" is being sent through to the DOM, which will likely trigger a React console error. If you would like automatic filtering of unknown props, you can opt-into that behavior via \`<StyleSheetManager shouldForwardProp={...}>\` (connect an API like \`@emotion/is-prop-valid\`) or consider using transient props (\`$\` prefix for automatic filtering.)`))));
                return r;
            }(y, v, m, f);
            let b = ce(l, u);
            return g && (b += " " + g), y.className && (b += " " + y.className), S[L(v) && v.includes("-") ? "class" : "className"] = b, r && (S.ref = r), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(v, S);
        }(g, o, s);
    }
    y.displayName = h;
    let g = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(y);
    return g.attrs = p, g.componentStyle = m, g.displayName = h, g.shouldForwardProp = f, g.foldedComponentIds = i ? ce(c.foldedComponentIds, c.styledComponentId) : "", g.styledComponentId = d, g.target = i ? c.target : o, Object.defineProperty(g, "defaultProps", {
        get () {
            return this._foldedDefaultProps;
        },
        set (e) {
            this._foldedDefaultProps = i ? function(e, ...t) {
                for (const n of t)ue(e, n, !0);
                return e;
            }({}, c.defaultProps, e) : e;
        }
    }), "production" !== ("TURBOPACK compile-time value", "development") && (_(h, d), g.warnTooManyClasses = ((e, t)=>{
        let n = {}, o = !1;
        return (s)=>{
            !o && (n[s] = !0, Object.keys(n).length >= 200) && (console.warn(`Over 200 classes were generated for component ${e}${t ? ` with the id of "${t}"` : ""}.\nConsider using the attrs method, together with a style object for frequently changed styles.\nExample:\n  const Component = styled.div.attrs(props => ({\n    style: {\n      background: props.background,\n    },\n  }))\`width: 100%;\`\n\n  <Component />`), o = !0, n = {});
        };
    })(h, d)), he(g, ()=>`.${g.styledComponentId}`), a && se(g, o, {
        attrs: !0,
        componentStyle: !0,
        displayName: !0,
        foldedComponentIds: !0,
        shouldForwardProp: !0,
        styledComponentId: !0,
        target: !0
    }), g;
}
var ut = new Set([
    "a",
    "abbr",
    "address",
    "area",
    "article",
    "aside",
    "audio",
    "b",
    "bdi",
    "bdo",
    "blockquote",
    "body",
    "button",
    "br",
    "canvas",
    "caption",
    "cite",
    "code",
    "col",
    "colgroup",
    "data",
    "datalist",
    "dd",
    "del",
    "details",
    "dfn",
    "dialog",
    "div",
    "dl",
    "dt",
    "em",
    "embed",
    "fieldset",
    "figcaption",
    "figure",
    "footer",
    "form",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "header",
    "hgroup",
    "hr",
    "html",
    "i",
    "iframe",
    "img",
    "input",
    "ins",
    "kbd",
    "label",
    "legend",
    "li",
    "main",
    "map",
    "mark",
    "menu",
    "meter",
    "nav",
    "object",
    "ol",
    "optgroup",
    "option",
    "output",
    "p",
    "picture",
    "pre",
    "progress",
    "q",
    "rp",
    "rt",
    "ruby",
    "s",
    "samp",
    "search",
    "section",
    "select",
    "slot",
    "small",
    "span",
    "strong",
    "sub",
    "summary",
    "sup",
    "table",
    "tbody",
    "td",
    "template",
    "textarea",
    "tfoot",
    "th",
    "thead",
    "time",
    "tr",
    "u",
    "ul",
    "var",
    "video",
    "wbr",
    "circle",
    "clipPath",
    "defs",
    "ellipse",
    "feBlend",
    "feColorMatrix",
    "feComponentTransfer",
    "feComposite",
    "feConvolveMatrix",
    "feDiffuseLighting",
    "feDisplacementMap",
    "feDistantLight",
    "feDropShadow",
    "feFlood",
    "feFuncA",
    "feFuncB",
    "feFuncG",
    "feFuncR",
    "feGaussianBlur",
    "feImage",
    "feMerge",
    "feMergeNode",
    "feMorphology",
    "feOffset",
    "fePointLight",
    "feSpecularLighting",
    "feSpotLight",
    "feTile",
    "feTurbulence",
    "filter",
    "foreignObject",
    "g",
    "image",
    "line",
    "linearGradient",
    "marker",
    "mask",
    "path",
    "pattern",
    "polygon",
    "polyline",
    "radialGradient",
    "rect",
    "stop",
    "svg",
    "switch",
    "symbol",
    "text",
    "textPath",
    "tspan",
    "use"
]);
function ht(e, t) {
    const n = [
        e[0]
    ];
    for(let o = 0, s = t.length; o < s; o += 1)n.push(t[o], e[o + 1]);
    return n;
}
const dt = (e)=>(_e.add(e), e);
function pt(e, ...t) {
    if (re(e) || le(e)) return dt(ze(ht(I, [
        e,
        ...t
    ])));
    const n = e;
    return 0 === t.length && 1 === n.length && "string" == typeof n[0] ? ze(n) : dt(ze(ht(n, t)));
}
function ft(e, t, n = $) {
    if (!t) throw v(1, t);
    const o = (o, ...s)=>e(t, n, pt(o, ...s));
    return o.attrs = (o)=>ft(e, t, Object.assign(Object.assign({}, n), {
            attrs: Array.prototype.concat(n.attrs, o).filter(Boolean)
        })), o.withConfig = (o)=>ft(e, t, Object.assign(Object.assign({}, n), o)), o;
}
const mt = (e)=>ft(lt, e), yt = mt;
ut.forEach((e)=>{
    yt[e] = mt(e);
});
class gt {
    constructor(e, t){
        this.instanceRules = new Map, this.rules = e, this.componentId = t, this.isStatic = function(e) {
            for(let t = 0; t < e.length; t += 1){
                const n = e[t];
                if (re(n) && !ie(n)) return !1;
            }
            return !0;
        }(e), Pe.registerId(this.componentId);
    }
    removeStyles(e, t) {
        this.instanceRules.delete(e), this.rebuildGroup(t);
    }
    renderStyles(e, t, n, o) {
        const s = this.componentId;
        if (this.isStatic) {
            if (n.hasNameForId(s, s + e)) this.instanceRules.has(e) || this.computeRules(e, t, n, o);
            else {
                const r = this.computeRules(e, t, n, o);
                n.insertRules(s, r.name, r.rules);
            }
            return;
        }
        const r = this.instanceRules.get(e);
        if (this.computeRules(e, t, n, o), !n.server && r) {
            const t = r.rules, n = this.instanceRules.get(e).rules;
            if (t.length === n.length) {
                let e = !0;
                for(let o = 0; o < t.length; o++)if (t[o] !== n[o]) {
                    e = !1;
                    break;
                }
                if (e) return;
            }
        }
        this.rebuildGroup(n);
    }
    computeRules(e, t, n, o) {
        const s = ae(ze(this.rules, t, n, o)), r = {
            name: this.componentId + e,
            rules: o(s, "")
        };
        return this.instanceRules.set(e, r), r;
    }
    rebuildGroup(e) {
        const t = this.componentId;
        e.clearRules(t);
        for (const n of this.instanceRules.values())e.insertRules(t, n.name, n.rules);
    }
}
function vt(e, ...n) {
    const o = pt(e, ...n), s = `sc-global-${z(JSON.stringify(o))}`, r = new gt(o, s);
    "production" !== ("TURBOPACK compile-time value", "development") && _(s);
    const i = (e)=>{
        const n = Ze(), i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(tt);
        let a;
        {
            const e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(null);
            null === e.current && (e.current = n.styleSheet.allocateGSInstance(s)), a = e.current;
        }
        "production" !== ("TURBOPACK compile-time value", "development") && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Children.count(e.children) && console.warn(`The global style component ${s} was given child JSX. createGlobalStyle does not render children.`), "production" !== ("TURBOPACK compile-time value", "development") && o.some((e)=>"string" == typeof e && -1 !== e.indexOf("@import")) && console.warn("Please do not use @import CSS syntax in createGlobalStyle at this time, as the CSSOM APIs we use in production do not handle it well. Instead, we recommend using a library such as react-helmet to inject a typical <link> meta tag to the stylesheet, or simply embedding it manually in your index.html <head> section for a simpler app."), n.styleSheet.server && c(a, e, n.styleSheet, i, n.stylis);
        {
            const o = r.isStatic ? [
                a,
                n.styleSheet,
                r
            ] : [
                a,
                e,
                n.styleSheet,
                i,
                n.stylis,
                r
            ], l = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(r);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useLayoutEffect({
                "vt.i.useLayoutEffect": ()=>{
                    n.styleSheet.server || (l.current !== r && (n.styleSheet.clearRules(s), l.current = r), c(a, e, n.styleSheet, i, n.stylis));
                }
            }["vt.i.useLayoutEffect"], o), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useLayoutEffect({
                "vt.i.useLayoutEffect": ()=>({
                        "vt.i.useLayoutEffect": ()=>{
                            n.styleSheet.server || r.removeStyles(a, n.styleSheet);
                        }
                    })["vt.i.useLayoutEffect"]
            }["vt.i.useLayoutEffect"], [
                a,
                n.styleSheet,
                r
            ]);
        }
        return n.styleSheet.server && r.instanceRules.delete(a), null;
    };
    function c(e, t, n, o, s) {
        if (r.isStatic) r.renderStyles(e, y, n, s);
        else {
            const c = Object.assign(Object.assign({}, t), {
                theme: R(t, o, i.defaultProps)
            });
            r.renderStyles(e, c, n, s);
        }
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(i);
}
function St(e, t, n, o, s) {
    for(const r in e){
        const i = e[r], c = s ? s + "-" + r : r;
        if ("object" == typeof i && null !== i) {
            const e = {};
            St(i, t, e, o, c), n[r] = e;
        } else n[r] = o(c, i, r);
    }
}
function bt(e, t, n, o) {
    let s = "";
    for(const r in e){
        const i = e[r], c = t[r], a = o ? o + "-" + r : r;
        "object" == typeof i && null !== i ? "object" == typeof c && null !== c && (s += bt(i, c, n, a)) : void 0 !== c && "function" != typeof c && (s += "--" + n + a + ":" + c + ";");
    }
    return s;
}
function wt(e, t) {
    var n, o;
    const s = (null !== (n = null == t ? void 0 : t.prefix) && void 0 !== n ? n : "sc") + "-", r = null !== (o = null == t ? void 0 : t.selector) && void 0 !== o ? o : ":root", i = function(e, t) {
        const n = {};
        return St(e, t, n, (e)=>"--" + t + e), n;
    }(e, s), c = function(e, t) {
        const n = {};
        return St(e, t, n, (e, n)=>{
            if ("TURBOPACK compile-time truthy", 1) {
                const t = String(n);
                let o = 0;
                for(let e = 0; e < t.length && (40 === t.charCodeAt(e) ? o++ : 41 === t.charCodeAt(e) && o--, !(o < 0)); e++);
                0 !== o && console.warn(`createTheme: value "${t}" at "${e}" contains unbalanced parentheses and may break the var() fallback`);
            }
            return "var(--" + t + e + ", " + n + ")";
        }), n;
    }(e, s), a = vt`
    ${r} {
      ${(t)=>bt(e, t.theme, s)}
    }
  `;
    return Object.assign(c, {
        GlobalStyle: a,
        raw: e,
        vars: i,
        resolve (t) {
            if (!d) throw new Error("createTheme.resolve() is client-only");
            const n = null != t ? t : document.documentElement;
            return function(e, t, n) {
                const o = {};
                return St(e, t, o, (e, o)=>n.getPropertyValue("--" + t + e).trim() || o), o;
            }(e, s, getComputedStyle(n));
        }
    });
}
var Nt;
class Ct {
    constructor(e, t){
        this[Nt] = !0, this.inject = (e, t = Xe)=>{
            const n = this.getName(t);
            if (!e.hasNameForId(this.id, n)) {
                const o = t(this.rules, n, "@keyframes");
                e.insertRules(this.id, n, o);
            }
        }, this.name = e, this.id = m + e, this.rules = t, C(this.id), he(this, ()=>{
            throw v(12, String(this.name));
        });
    }
    getName(e = Xe) {
        return e.hash ? this.name + V(+e.hash >>> 0) : this.name;
    }
}
function Ot(e, ...t) {
    "production" !== ("TURBOPACK compile-time value", "development") && "undefined" != typeof navigator && "ReactNative" === navigator.product && console.warn("`keyframes` cannot be used on ReactNative, only on the web. To do animation in ReactNative please use Animated.");
    const n = ae(pt(e, ...t)), o = z(n);
    return new Ct(o, n);
}
function Et(e) {
    const n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef((n, o)=>{
        const s = R(n, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(tt), e.defaultProps);
        return "production" !== ("TURBOPACK compile-time value", "development") && void 0 === s && console.warn(`[withTheme] You are not using a ThemeProvider nor passing a theme prop or a theme in defaultProps in component class "${W(e)}"`), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(e, Object.assign(Object.assign({}, n), {
            theme: s,
            ref: o
        }));
    });
    return n.displayName = `WithTheme(${W(e)})`, se(n, e);
}
Nt = xe;
class At {
    constructor({ nonce: e } = {}){
        this._emitSheetCSS = ()=>{
            const e = this.instance.toString();
            if (!e) return "";
            const t = this.instance.options.nonce || we();
            return `<style ${ae([
                t && `nonce="${t}"`,
                `${c}="true"`,
                `${l}="${u}"`
            ].filter(Boolean), " ")}>${e}</style>`;
        }, this.getStyleTags = ()=>{
            if (this.sealed) throw v(2);
            return this._emitSheetCSS();
        }, this.getStyleElement = ()=>{
            if (this.sealed) throw v(2);
            const e = this.instance.toString();
            if (!e) return [];
            const n = {
                [c]: "",
                [l]: u,
                dangerouslySetInnerHTML: {
                    __html: e
                }
            }, o = this.instance.options.nonce || we();
            return o && (n.nonce = o), [
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("style", Object.assign({}, n, {
                    key: "sc-0-0"
                }))
            ];
        }, this.seal = ()=>{
            this.sealed = !0;
        }, this.instance = new Pe({
            isServer: !0,
            nonce: e
        }), this.sealed = !1;
    }
    collectStyles(e) {
        if (this.sealed) throw v(2);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(et, {
            sheet: this.instance
        }, e);
    }
    interleaveWithNodeStream(e) {
        throw v(3);
    }
}
const Pt = {
    StyleSheet: Pe,
    mainSheet: Je
};
"production" !== ("TURBOPACK compile-time value", "development") && "undefined" != typeof navigator && "ReactNative" === navigator.product && console.warn("It looks like you've imported 'styled-components' on React Native.\nPerhaps you're looking to import 'styled-components/native'?\nRead more about this at https://styled-components.com/docs/basics#react-native");
const _t = `__sc-${c}__`;
"production" !== ("TURBOPACK compile-time value", "development") && "test" !== ("TURBOPACK compile-time value", "development") && "undefined" != typeof window && (window[_t] || (window[_t] = 0), 1 === window[_t] && console.warn("It looks like there are several instances of 'styled-components' initialized in this application. This may cause dynamic styles to not render properly, errors during the rehydration process, a missing theme prop, and makes your application bigger without good reason.\n\nSee https://styled-components.com/docs/faqs#why-am-i-getting-a-warning-about-several-instances-of-module-on-the-page for more info."), window[_t] += 1);
const It = /:(?:(first)-child|(last)-child|(only)-child|(nth-child)\(([^()]+)\)|(nth-last-child)\(([^()]+)\))/g, $t = `:not(style[${c}])`, Rt = `style[${c}]`;
function jt(e) {
    return -1 === e.indexOf("-child") ? e : (It.lastIndex = 0, e.replace(It, (e, t, n, o, s, r, i, c)=>t ? `:nth-child(1 of ${$t})` : n ? `:nth-last-child(1 of ${$t})` : o ? `:nth-child(1 of ${$t}):nth-last-child(1 of ${$t})` : s ? -1 !== r.indexOf(" of ") ? e : `:nth-child(${r} of ${$t})` : -1 !== c.indexOf(" of ") ? e : `:nth-last-child(${c} of ${$t})`));
}
function xt(e, t) {
    if (-1 === e.indexOf("+")) return;
    let n = 0, o = 0;
    for(let s = 0; s < e.length; s++){
        const r = e.charCodeAt(s);
        if (40 === r) n++;
        else if (41 === r) n--;
        else if (91 === r) o++;
        else if (93 === r) o--;
        else if (43 === r && 0 === n && 0 === o && !qe(e, s)) {
            const n = e.substring(0, s), o = e.substring(s + 1);
            t.push(n + "+" + Rt + "+" + o), t.push(n + "+" + Rt + "+" + Rt + "+" + o);
        }
    }
}
function Tt(e) {
    if (e.type === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$stylis$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RULESET"]) {
        const t = e.props, n = [];
        for(let e = 0; e < t.length; e++){
            const o = jt(t[e]);
            n.push(o), xt(o, n);
        }
        e.props = n;
    }
}
;
}),
"[project]/node_modules/react-is/cjs/react-is.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * @license React
 * react-is.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ "use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function typeOf(object) {
        if ("object" === typeof object && null !== object) {
            var $$typeof = object.$$typeof;
            switch($$typeof){
                case REACT_ELEMENT_TYPE:
                    switch(object = object.type, object){
                        case REACT_FRAGMENT_TYPE:
                        case REACT_PROFILER_TYPE:
                        case REACT_STRICT_MODE_TYPE:
                        case REACT_SUSPENSE_TYPE:
                        case REACT_SUSPENSE_LIST_TYPE:
                        case REACT_VIEW_TRANSITION_TYPE:
                            return object;
                        default:
                            switch(object = object && object.$$typeof, object){
                                case REACT_CONTEXT_TYPE:
                                case REACT_FORWARD_REF_TYPE:
                                case REACT_LAZY_TYPE:
                                case REACT_MEMO_TYPE:
                                    return object;
                                case REACT_CONSUMER_TYPE:
                                    return object;
                                default:
                                    return $$typeof;
                            }
                    }
                case REACT_PORTAL_TYPE:
                    return $$typeof;
            }
        }
    }
    var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference");
    exports.ContextConsumer = REACT_CONSUMER_TYPE;
    exports.ContextProvider = REACT_CONTEXT_TYPE;
    exports.Element = REACT_ELEMENT_TYPE;
    exports.ForwardRef = REACT_FORWARD_REF_TYPE;
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.Lazy = REACT_LAZY_TYPE;
    exports.Memo = REACT_MEMO_TYPE;
    exports.Portal = REACT_PORTAL_TYPE;
    exports.Profiler = REACT_PROFILER_TYPE;
    exports.StrictMode = REACT_STRICT_MODE_TYPE;
    exports.Suspense = REACT_SUSPENSE_TYPE;
    exports.SuspenseList = REACT_SUSPENSE_LIST_TYPE;
    exports.isContextConsumer = function(object) {
        return typeOf(object) === REACT_CONSUMER_TYPE;
    };
    exports.isContextProvider = function(object) {
        return typeOf(object) === REACT_CONTEXT_TYPE;
    };
    exports.isElement = function(object) {
        return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    };
    exports.isForwardRef = function(object) {
        return typeOf(object) === REACT_FORWARD_REF_TYPE;
    };
    exports.isFragment = function(object) {
        return typeOf(object) === REACT_FRAGMENT_TYPE;
    };
    exports.isLazy = function(object) {
        return typeOf(object) === REACT_LAZY_TYPE;
    };
    exports.isMemo = function(object) {
        return typeOf(object) === REACT_MEMO_TYPE;
    };
    exports.isPortal = function(object) {
        return typeOf(object) === REACT_PORTAL_TYPE;
    };
    exports.isProfiler = function(object) {
        return typeOf(object) === REACT_PROFILER_TYPE;
    };
    exports.isStrictMode = function(object) {
        return typeOf(object) === REACT_STRICT_MODE_TYPE;
    };
    exports.isSuspense = function(object) {
        return typeOf(object) === REACT_SUSPENSE_TYPE;
    };
    exports.isSuspenseList = function(object) {
        return typeOf(object) === REACT_SUSPENSE_LIST_TYPE;
    };
    exports.isValidElementType = function(type) {
        return "string" === typeof type || "function" === typeof type || type === REACT_FRAGMENT_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || "object" === typeof type && null !== type && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_CONSUMER_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_CLIENT_REFERENCE || void 0 !== type.getModuleId) ? !0 : !1;
    };
    exports.typeOf = typeOf;
}();
}),
"[project]/node_modules/react-is/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/react-is/cjs/react-is.development.js [app-client] (ecmascript)");
}
}),
"[project]/node_modules/@sanity/ui/node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "alignments",
    ()=>alignments,
    "clamp",
    ()=>clamp,
    "createCoords",
    ()=>createCoords,
    "evaluate",
    ()=>evaluate,
    "expandPaddingObject",
    ()=>expandPaddingObject,
    "floor",
    ()=>floor,
    "getAlignment",
    ()=>getAlignment,
    "getAlignmentAxis",
    ()=>getAlignmentAxis,
    "getAlignmentSides",
    ()=>getAlignmentSides,
    "getAxisLength",
    ()=>getAxisLength,
    "getExpandedPlacements",
    ()=>getExpandedPlacements,
    "getOppositeAlignmentPlacement",
    ()=>getOppositeAlignmentPlacement,
    "getOppositeAxis",
    ()=>getOppositeAxis,
    "getOppositeAxisPlacements",
    ()=>getOppositeAxisPlacements,
    "getOppositePlacement",
    ()=>getOppositePlacement,
    "getPaddingObject",
    ()=>getPaddingObject,
    "getSide",
    ()=>getSide,
    "getSideAxis",
    ()=>getSideAxis,
    "max",
    ()=>max,
    "min",
    ()=>min,
    "placements",
    ()=>placements,
    "rectToClientRect",
    ()=>rectToClientRect,
    "round",
    ()=>round,
    "sides",
    ()=>sides
]);
/**
 * Custom positioning reference element.
 * @see https://floating-ui.com/docs/virtual-elements
 */ const sides = [
    'top',
    'right',
    'bottom',
    'left'
];
const alignments = [
    'start',
    'end'
];
const placements = /*#__PURE__*/ sides.reduce((acc, side)=>acc.concat(side, side + "-" + alignments[0], side + "-" + alignments[1]), []);
const min = Math.min;
const max = Math.max;
const round = Math.round;
const floor = Math.floor;
const createCoords = (v)=>({
        x: v,
        y: v
    });
const oppositeSideMap = {
    left: 'right',
    right: 'left',
    bottom: 'top',
    top: 'bottom'
};
function clamp(start, value, end) {
    return max(start, min(value, end));
}
function evaluate(value, param) {
    return typeof value === 'function' ? value(param) : value;
}
function getSide(placement) {
    return placement.split('-')[0];
}
function getAlignment(placement) {
    return placement.split('-')[1];
}
function getOppositeAxis(axis) {
    return axis === 'x' ? 'y' : 'x';
}
function getAxisLength(axis) {
    return axis === 'y' ? 'height' : 'width';
}
function getSideAxis(placement) {
    const firstChar = placement[0];
    return firstChar === 't' || firstChar === 'b' ? 'y' : 'x';
}
function getAlignmentAxis(placement) {
    return getOppositeAxis(getSideAxis(placement));
}
function getAlignmentSides(placement, rects, rtl) {
    if (rtl === void 0) {
        rtl = false;
    }
    const alignment = getAlignment(placement);
    const alignmentAxis = getAlignmentAxis(placement);
    const length = getAxisLength(alignmentAxis);
    let mainAlignmentSide = alignmentAxis === 'x' ? alignment === (rtl ? 'end' : 'start') ? 'right' : 'left' : alignment === 'start' ? 'bottom' : 'top';
    if (rects.reference[length] > rects.floating[length]) {
        mainAlignmentSide = getOppositePlacement(mainAlignmentSide);
    }
    return [
        mainAlignmentSide,
        getOppositePlacement(mainAlignmentSide)
    ];
}
function getExpandedPlacements(placement) {
    const oppositePlacement = getOppositePlacement(placement);
    return [
        getOppositeAlignmentPlacement(placement),
        oppositePlacement,
        getOppositeAlignmentPlacement(oppositePlacement)
    ];
}
function getOppositeAlignmentPlacement(placement) {
    return placement.includes('start') ? placement.replace('start', 'end') : placement.replace('end', 'start');
}
const lrPlacement = [
    'left',
    'right'
];
const rlPlacement = [
    'right',
    'left'
];
const tbPlacement = [
    'top',
    'bottom'
];
const btPlacement = [
    'bottom',
    'top'
];
function getSideList(side, isStart, rtl) {
    switch(side){
        case 'top':
        case 'bottom':
            if (rtl) return isStart ? rlPlacement : lrPlacement;
            return isStart ? lrPlacement : rlPlacement;
        case 'left':
        case 'right':
            return isStart ? tbPlacement : btPlacement;
        default:
            return [];
    }
}
function getOppositeAxisPlacements(placement, flipAlignment, direction, rtl) {
    const alignment = getAlignment(placement);
    let list = getSideList(getSide(placement), direction === 'start', rtl);
    if (alignment) {
        list = list.map((side)=>side + "-" + alignment);
        if (flipAlignment) {
            list = list.concat(list.map(getOppositeAlignmentPlacement));
        }
    }
    return list;
}
function getOppositePlacement(placement) {
    const side = getSide(placement);
    return oppositeSideMap[side] + placement.slice(side.length);
}
function expandPaddingObject(padding) {
    return {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
        ...padding
    };
}
function getPaddingObject(padding) {
    return typeof padding !== 'number' ? expandPaddingObject(padding) : {
        top: padding,
        right: padding,
        bottom: padding,
        left: padding
    };
}
function rectToClientRect(rect) {
    const { x, y, width, height } = rect;
    return {
        width,
        height,
        top: y,
        left: x,
        right: x + width,
        bottom: y + height,
        x,
        y
    };
}
;
}),
"[project]/node_modules/@sanity/ui/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getComputedStyle",
    ()=>getComputedStyle,
    "getContainingBlock",
    ()=>getContainingBlock,
    "getDocumentElement",
    ()=>getDocumentElement,
    "getFrameElement",
    ()=>getFrameElement,
    "getNearestOverflowAncestor",
    ()=>getNearestOverflowAncestor,
    "getNodeName",
    ()=>getNodeName,
    "getNodeScroll",
    ()=>getNodeScroll,
    "getOverflowAncestors",
    ()=>getOverflowAncestors,
    "getParentNode",
    ()=>getParentNode,
    "getWindow",
    ()=>getWindow,
    "isContainingBlock",
    ()=>isContainingBlock,
    "isElement",
    ()=>isElement,
    "isHTMLElement",
    ()=>isHTMLElement,
    "isLastTraversableNode",
    ()=>isLastTraversableNode,
    "isNode",
    ()=>isNode,
    "isOverflowElement",
    ()=>isOverflowElement,
    "isShadowRoot",
    ()=>isShadowRoot,
    "isTableElement",
    ()=>isTableElement,
    "isTopLayer",
    ()=>isTopLayer,
    "isWebKit",
    ()=>isWebKit
]);
function hasWindow() {
    return typeof window !== 'undefined';
}
function getNodeName(node) {
    if (isNode(node)) {
        return (node.nodeName || '').toLowerCase();
    }
    // Mocked nodes in testing environments may not be instances of Node. By
    // returning `#document` an infinite loop won't occur.
    // https://github.com/floating-ui/floating-ui/issues/2317
    return '#document';
}
function getWindow(node) {
    var _node$ownerDocument;
    return (node == null || (_node$ownerDocument = node.ownerDocument) == null ? void 0 : _node$ownerDocument.defaultView) || window;
}
function getDocumentElement(node) {
    var _ref;
    return (_ref = (isNode(node) ? node.ownerDocument : node.document) || window.document) == null ? void 0 : _ref.documentElement;
}
function isNode(value) {
    if (!hasWindow()) {
        return false;
    }
    return value instanceof Node || value instanceof getWindow(value).Node;
}
function isElement(value) {
    if (!hasWindow()) {
        return false;
    }
    return value instanceof Element || value instanceof getWindow(value).Element;
}
function isHTMLElement(value) {
    if (!hasWindow()) {
        return false;
    }
    return value instanceof HTMLElement || value instanceof getWindow(value).HTMLElement;
}
function isShadowRoot(value) {
    if (!hasWindow() || typeof ShadowRoot === 'undefined') {
        return false;
    }
    return value instanceof ShadowRoot || value instanceof getWindow(value).ShadowRoot;
}
function isOverflowElement(element) {
    const { overflow, overflowX, overflowY, display } = getComputedStyle(element);
    return /auto|scroll|overlay|hidden|clip/.test(overflow + overflowY + overflowX) && display !== 'inline' && display !== 'contents';
}
function isTableElement(element) {
    return /^(table|td|th)$/.test(getNodeName(element));
}
function isTopLayer(element) {
    try {
        if (element.matches(':popover-open')) {
            return true;
        }
    } catch (_e) {
    // no-op
    }
    try {
        return element.matches(':modal');
    } catch (_e) {
        return false;
    }
}
const willChangeRe = /transform|translate|scale|rotate|perspective|filter/;
const containRe = /paint|layout|strict|content/;
const isNotNone = (value)=>!!value && value !== 'none';
let isWebKitValue;
function isContainingBlock(elementOrCss) {
    const css = isElement(elementOrCss) ? getComputedStyle(elementOrCss) : elementOrCss;
    // https://developer.mozilla.org/en-US/docs/Web/CSS/Containing_block#identifying_the_containing_block
    // https://drafts.csswg.org/css-transforms-2/#individual-transforms
    return isNotNone(css.transform) || isNotNone(css.translate) || isNotNone(css.scale) || isNotNone(css.rotate) || isNotNone(css.perspective) || !isWebKit() && (isNotNone(css.backdropFilter) || isNotNone(css.filter)) || willChangeRe.test(css.willChange || '') || containRe.test(css.contain || '');
}
function getContainingBlock(element) {
    let currentNode = getParentNode(element);
    while(isHTMLElement(currentNode) && !isLastTraversableNode(currentNode)){
        if (isContainingBlock(currentNode)) {
            return currentNode;
        } else if (isTopLayer(currentNode)) {
            return null;
        }
        currentNode = getParentNode(currentNode);
    }
    return null;
}
function isWebKit() {
    if (isWebKitValue == null) {
        isWebKitValue = typeof CSS !== 'undefined' && CSS.supports && CSS.supports('-webkit-backdrop-filter', 'none');
    }
    return isWebKitValue;
}
function isLastTraversableNode(node) {
    return /^(html|body|#document)$/.test(getNodeName(node));
}
function getComputedStyle(element) {
    return getWindow(element).getComputedStyle(element);
}
function getNodeScroll(element) {
    if (isElement(element)) {
        return {
            scrollLeft: element.scrollLeft,
            scrollTop: element.scrollTop
        };
    }
    return {
        scrollLeft: element.scrollX,
        scrollTop: element.scrollY
    };
}
function getParentNode(node) {
    if (getNodeName(node) === 'html') {
        return node;
    }
    const result = // Step into the shadow DOM of the parent of a slotted node.
    node.assignedSlot || // DOM Element detected.
    node.parentNode || // ShadowRoot detected.
    isShadowRoot(node) && node.host || // Fallback.
    getDocumentElement(node);
    return isShadowRoot(result) ? result.host : result;
}
function getNearestOverflowAncestor(node) {
    const parentNode = getParentNode(node);
    if (isLastTraversableNode(parentNode)) {
        return node.ownerDocument ? node.ownerDocument.body : node.body;
    }
    if (isHTMLElement(parentNode) && isOverflowElement(parentNode)) {
        return parentNode;
    }
    return getNearestOverflowAncestor(parentNode);
}
function getOverflowAncestors(node, list, traverseIframes) {
    var _node$ownerDocument2;
    if (list === void 0) {
        list = [];
    }
    if (traverseIframes === void 0) {
        traverseIframes = true;
    }
    const scrollableAncestor = getNearestOverflowAncestor(node);
    const isBody = scrollableAncestor === ((_node$ownerDocument2 = node.ownerDocument) == null ? void 0 : _node$ownerDocument2.body);
    const win = getWindow(scrollableAncestor);
    if (isBody) {
        const frameElement = getFrameElement(win);
        return list.concat(win, win.visualViewport || [], isOverflowElement(scrollableAncestor) ? scrollableAncestor : [], frameElement && traverseIframes ? getOverflowAncestors(frameElement) : []);
    } else {
        return list.concat(scrollableAncestor, getOverflowAncestors(scrollableAncestor, [], traverseIframes));
    }
}
function getFrameElement(win) {
    return win.parent && Object.getPrototypeOf(win.parent) ? win.frameElement : null;
}
;
}),
"[project]/node_modules/@sanity/ui/node_modules/@floating-ui/core/dist/floating-ui.core.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "arrow",
    ()=>arrow,
    "autoPlacement",
    ()=>autoPlacement,
    "computePosition",
    ()=>computePosition,
    "detectOverflow",
    ()=>detectOverflow,
    "flip",
    ()=>flip,
    "hide",
    ()=>hide,
    "inline",
    ()=>inline,
    "limitShift",
    ()=>limitShift,
    "offset",
    ()=>offset,
    "shift",
    ()=>shift,
    "size",
    ()=>size
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs [app-client] (ecmascript)");
;
;
function computeCoordsFromPlacement(_ref, placement, rtl) {
    let { reference, floating } = _ref;
    const sideAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSideAxis"])(placement);
    const alignmentAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlignmentAxis"])(placement);
    const alignLength = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAxisLength"])(alignmentAxis);
    const side = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSide"])(placement);
    const isVertical = sideAxis === 'y';
    const commonX = reference.x + reference.width / 2 - floating.width / 2;
    const commonY = reference.y + reference.height / 2 - floating.height / 2;
    const commonAlign = reference[alignLength] / 2 - floating[alignLength] / 2;
    let coords;
    switch(side){
        case 'top':
            coords = {
                x: commonX,
                y: reference.y - floating.height
            };
            break;
        case 'bottom':
            coords = {
                x: commonX,
                y: reference.y + reference.height
            };
            break;
        case 'right':
            coords = {
                x: reference.x + reference.width,
                y: commonY
            };
            break;
        case 'left':
            coords = {
                x: reference.x - floating.width,
                y: commonY
            };
            break;
        default:
            coords = {
                x: reference.x,
                y: reference.y
            };
    }
    switch((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlignment"])(placement)){
        case 'start':
            coords[alignmentAxis] -= commonAlign * (rtl && isVertical ? -1 : 1);
            break;
        case 'end':
            coords[alignmentAxis] += commonAlign * (rtl && isVertical ? -1 : 1);
            break;
    }
    return coords;
}
/**
 * Resolves with an object of overflow side offsets that determine how much the
 * element is overflowing a given clipping boundary on each side.
 * - positive = overflowing the boundary by that number of pixels
 * - negative = how many pixels left before it will overflow
 * - 0 = lies flush with the boundary
 * @see https://floating-ui.com/docs/detectOverflow
 */ async function detectOverflow(state, options) {
    var _await$platform$isEle;
    if (options === void 0) {
        options = {};
    }
    const { x, y, platform, rects, elements, strategy } = state;
    const { boundary = 'clippingAncestors', rootBoundary = 'viewport', elementContext = 'floating', altBoundary = false, padding = 0 } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["evaluate"])(options, state);
    const paddingObject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPaddingObject"])(padding);
    const altContext = elementContext === 'floating' ? 'reference' : 'floating';
    const element = elements[altBoundary ? altContext : elementContext];
    const clippingClientRect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rectToClientRect"])(await platform.getClippingRect({
        element: ((_await$platform$isEle = await (platform.isElement == null ? void 0 : platform.isElement(element))) != null ? _await$platform$isEle : true) ? element : element.contextElement || await (platform.getDocumentElement == null ? void 0 : platform.getDocumentElement(elements.floating)),
        boundary,
        rootBoundary,
        strategy
    }));
    const rect = elementContext === 'floating' ? {
        x,
        y,
        width: rects.floating.width,
        height: rects.floating.height
    } : rects.reference;
    const offsetParent = await (platform.getOffsetParent == null ? void 0 : platform.getOffsetParent(elements.floating));
    const offsetScale = await (platform.isElement == null ? void 0 : platform.isElement(offsetParent)) ? await (platform.getScale == null ? void 0 : platform.getScale(offsetParent)) || {
        x: 1,
        y: 1
    } : {
        x: 1,
        y: 1
    };
    const elementClientRect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rectToClientRect"])(platform.convertOffsetParentRelativeRectToViewportRelativeRect ? await platform.convertOffsetParentRelativeRectToViewportRelativeRect({
        elements,
        rect,
        offsetParent,
        strategy
    }) : rect);
    return {
        top: (clippingClientRect.top - elementClientRect.top + paddingObject.top) / offsetScale.y,
        bottom: (elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom) / offsetScale.y,
        left: (clippingClientRect.left - elementClientRect.left + paddingObject.left) / offsetScale.x,
        right: (elementClientRect.right - clippingClientRect.right + paddingObject.right) / offsetScale.x
    };
}
// Maximum number of resets that can occur before bailing to avoid infinite reset loops.
const MAX_RESET_COUNT = 50;
/**
 * Computes the `x` and `y` coordinates that will place the floating element
 * next to a given reference element.
 *
 * This export does not have any `platform` interface logic. You will need to
 * write one for the platform you are using Floating UI with.
 */ const computePosition = async (reference, floating, config)=>{
    const { placement = 'bottom', strategy = 'absolute', middleware = [], platform } = config;
    const platformWithDetectOverflow = platform.detectOverflow ? platform : {
        ...platform,
        detectOverflow
    };
    const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(floating));
    let rects = await platform.getElementRects({
        reference,
        floating,
        strategy
    });
    let { x, y } = computeCoordsFromPlacement(rects, placement, rtl);
    let statefulPlacement = placement;
    let resetCount = 0;
    const middlewareData = {};
    for(let i = 0; i < middleware.length; i++){
        const currentMiddleware = middleware[i];
        if (!currentMiddleware) {
            continue;
        }
        const { name, fn } = currentMiddleware;
        const { x: nextX, y: nextY, data, reset } = await fn({
            x,
            y,
            initialPlacement: placement,
            placement: statefulPlacement,
            strategy,
            middlewareData,
            rects,
            platform: platformWithDetectOverflow,
            elements: {
                reference,
                floating
            }
        });
        x = nextX != null ? nextX : x;
        y = nextY != null ? nextY : y;
        middlewareData[name] = {
            ...middlewareData[name],
            ...data
        };
        if (reset && resetCount < MAX_RESET_COUNT) {
            resetCount++;
            if (typeof reset === 'object') {
                if (reset.placement) {
                    statefulPlacement = reset.placement;
                }
                if (reset.rects) {
                    rects = reset.rects === true ? await platform.getElementRects({
                        reference,
                        floating,
                        strategy
                    }) : reset.rects;
                }
                ({ x, y } = computeCoordsFromPlacement(rects, statefulPlacement, rtl));
            }
            i = -1;
        }
    }
    return {
        x,
        y,
        placement: statefulPlacement,
        strategy,
        middlewareData
    };
};
/**
 * Provides data to position an inner element of the floating element so that it
 * appears centered to the reference element.
 * @see https://floating-ui.com/docs/arrow
 */ const arrow = (options)=>({
        name: 'arrow',
        options,
        async fn (state) {
            const { x, y, placement, rects, platform, elements, middlewareData } = state;
            // Since `element` is required, we don't Partial<> the type.
            const { element, padding = 0 } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["evaluate"])(options, state) || {};
            if (element == null) {
                return {};
            }
            const paddingObject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPaddingObject"])(padding);
            const coords = {
                x,
                y
            };
            const axis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlignmentAxis"])(placement);
            const length = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAxisLength"])(axis);
            const arrowDimensions = await platform.getDimensions(element);
            const isYAxis = axis === 'y';
            const minProp = isYAxis ? 'top' : 'left';
            const maxProp = isYAxis ? 'bottom' : 'right';
            const clientProp = isYAxis ? 'clientHeight' : 'clientWidth';
            const endDiff = rects.reference[length] + rects.reference[axis] - coords[axis] - rects.floating[length];
            const startDiff = coords[axis] - rects.reference[axis];
            const arrowOffsetParent = await (platform.getOffsetParent == null ? void 0 : platform.getOffsetParent(element));
            let clientSize = arrowOffsetParent ? arrowOffsetParent[clientProp] : 0;
            // DOM platform can return `window` as the `offsetParent`.
            if (!clientSize || !await (platform.isElement == null ? void 0 : platform.isElement(arrowOffsetParent))) {
                clientSize = elements.floating[clientProp] || rects.floating[length];
            }
            const centerToReference = endDiff / 2 - startDiff / 2;
            // If the padding is large enough that it causes the arrow to no longer be
            // centered, modify the padding so that it is centered.
            const largestPossiblePadding = clientSize / 2 - arrowDimensions[length] / 2 - 1;
            const minPadding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["min"])(paddingObject[minProp], largestPossiblePadding);
            const maxPadding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["min"])(paddingObject[maxProp], largestPossiblePadding);
            // Make sure the arrow doesn't overflow the floating element if the center
            // point is outside the floating element's bounds.
            const min$1 = minPadding;
            const max = clientSize - arrowDimensions[length] - maxPadding;
            const center = clientSize / 2 - arrowDimensions[length] / 2 + centerToReference;
            const offset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(min$1, center, max);
            // If the reference is small enough that the arrow's padding causes it to
            // to point to nothing for an aligned placement, adjust the offset of the
            // floating element itself. To ensure `shift()` continues to take action,
            // a single reset is performed when this is true.
            const shouldAddOffset = !middlewareData.arrow && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlignment"])(placement) != null && center !== offset && rects.reference[length] / 2 - (center < min$1 ? minPadding : maxPadding) - arrowDimensions[length] / 2 < 0;
            const alignmentOffset = shouldAddOffset ? center < min$1 ? center - min$1 : center - max : 0;
            return {
                [axis]: coords[axis] + alignmentOffset,
                data: {
                    [axis]: offset,
                    centerOffset: center - offset - alignmentOffset,
                    ...shouldAddOffset && {
                        alignmentOffset
                    }
                },
                reset: shouldAddOffset
            };
        }
    });
function getPlacementList(alignment, autoAlignment, allowedPlacements) {
    const allowedPlacementsSortedByAlignment = alignment ? [
        ...allowedPlacements.filter((placement)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlignment"])(placement) === alignment),
        ...allowedPlacements.filter((placement)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlignment"])(placement) !== alignment)
    ] : allowedPlacements.filter((placement)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSide"])(placement) === placement);
    return allowedPlacementsSortedByAlignment.filter((placement)=>{
        if (alignment) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlignment"])(placement) === alignment || (autoAlignment ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOppositeAlignmentPlacement"])(placement) !== placement : false);
        }
        return true;
    });
}
/**
 * Optimizes the visibility of the floating element by choosing the placement
 * that has the most space available automatically, without needing to specify a
 * preferred placement. Alternative to `flip`.
 * @see https://floating-ui.com/docs/autoPlacement
 */ const autoPlacement = function(options) {
    if (options === void 0) {
        options = {};
    }
    return {
        name: 'autoPlacement',
        options,
        async fn (state) {
            var _middlewareData$autoP, _middlewareData$autoP2, _placementsThatFitOnE;
            const { rects, middlewareData, placement, platform, elements } = state;
            const { crossAxis = false, alignment, allowedPlacements = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["placements"], autoAlignment = true, ...detectOverflowOptions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["evaluate"])(options, state);
            const placements$1 = alignment !== undefined || allowedPlacements === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["placements"] ? getPlacementList(alignment || null, autoAlignment, allowedPlacements) : allowedPlacements;
            const overflow = await platform.detectOverflow(state, detectOverflowOptions);
            const currentIndex = ((_middlewareData$autoP = middlewareData.autoPlacement) == null ? void 0 : _middlewareData$autoP.index) || 0;
            const currentPlacement = placements$1[currentIndex];
            if (currentPlacement == null) {
                return {};
            }
            const alignmentSides = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlignmentSides"])(currentPlacement, rects, await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating)));
            // Make `computeCoords` start from the right place.
            if (placement !== currentPlacement) {
                return {
                    reset: {
                        placement: placements$1[0]
                    }
                };
            }
            const currentOverflows = [
                overflow[(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSide"])(currentPlacement)],
                overflow[alignmentSides[0]],
                overflow[alignmentSides[1]]
            ];
            const allOverflows = [
                ...((_middlewareData$autoP2 = middlewareData.autoPlacement) == null ? void 0 : _middlewareData$autoP2.overflows) || [],
                {
                    placement: currentPlacement,
                    overflows: currentOverflows
                }
            ];
            const nextPlacement = placements$1[currentIndex + 1];
            // There are more placements to check.
            if (nextPlacement) {
                return {
                    data: {
                        index: currentIndex + 1,
                        overflows: allOverflows
                    },
                    reset: {
                        placement: nextPlacement
                    }
                };
            }
            const placementsSortedByMostSpace = allOverflows.map((d)=>{
                const alignment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlignment"])(d.placement);
                return [
                    d.placement,
                    alignment && crossAxis ? // Check along the mainAxis and main crossAxis side.
                    d.overflows.slice(0, 2).reduce((acc, v)=>acc + v, 0) : // Check only the mainAxis.
                    d.overflows[0],
                    d.overflows
                ];
            }).sort((a, b)=>a[1] - b[1]);
            const placementsThatFitOnEachSide = placementsSortedByMostSpace.filter((d)=>d[2].slice(0, // Aligned placements should not check their opposite crossAxis
                // side.
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlignment"])(d[0]) ? 2 : 3).every((v)=>v <= 0));
            const resetPlacement = ((_placementsThatFitOnE = placementsThatFitOnEachSide[0]) == null ? void 0 : _placementsThatFitOnE[0]) || placementsSortedByMostSpace[0][0];
            if (resetPlacement !== placement) {
                return {
                    data: {
                        index: currentIndex + 1,
                        overflows: allOverflows
                    },
                    reset: {
                        placement: resetPlacement
                    }
                };
            }
            return {};
        }
    };
};
/**
 * Optimizes the visibility of the floating element by flipping the `placement`
 * in order to keep it in view when the preferred placement(s) will overflow the
 * clipping boundary. Alternative to `autoPlacement`.
 * @see https://floating-ui.com/docs/flip
 */ const flip = function(options) {
    if (options === void 0) {
        options = {};
    }
    return {
        name: 'flip',
        options,
        async fn (state) {
            var _middlewareData$arrow, _middlewareData$flip;
            const { placement, middlewareData, rects, initialPlacement, platform, elements } = state;
            const { mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = true, fallbackPlacements: specifiedFallbackPlacements, fallbackStrategy = 'bestFit', fallbackAxisSideDirection = 'none', flipAlignment = true, ...detectOverflowOptions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["evaluate"])(options, state);
            // If a reset by the arrow was caused due to an alignment offset being
            // added, we should skip any logic now since `flip()` has already done its
            // work.
            // https://github.com/floating-ui/floating-ui/issues/2549#issuecomment-1719601643
            if ((_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) {
                return {};
            }
            const side = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSide"])(placement);
            const initialSideAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSideAxis"])(initialPlacement);
            const isBasePlacement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSide"])(initialPlacement) === initialPlacement;
            const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating));
            const fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipAlignment ? [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOppositePlacement"])(initialPlacement)
            ] : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExpandedPlacements"])(initialPlacement));
            const hasFallbackAxisSideDirection = fallbackAxisSideDirection !== 'none';
            if (!specifiedFallbackPlacements && hasFallbackAxisSideDirection) {
                fallbackPlacements.push(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOppositeAxisPlacements"])(initialPlacement, flipAlignment, fallbackAxisSideDirection, rtl));
            }
            const placements = [
                initialPlacement,
                ...fallbackPlacements
            ];
            const overflow = await platform.detectOverflow(state, detectOverflowOptions);
            const overflows = [];
            let overflowsData = ((_middlewareData$flip = middlewareData.flip) == null ? void 0 : _middlewareData$flip.overflows) || [];
            if (checkMainAxis) {
                overflows.push(overflow[side]);
            }
            if (checkCrossAxis) {
                const sides = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlignmentSides"])(placement, rects, rtl);
                overflows.push(overflow[sides[0]], overflow[sides[1]]);
            }
            overflowsData = [
                ...overflowsData,
                {
                    placement,
                    overflows
                }
            ];
            // One or more sides is overflowing.
            if (!overflows.every((side)=>side <= 0)) {
                var _middlewareData$flip2, _overflowsData$filter;
                const nextIndex = (((_middlewareData$flip2 = middlewareData.flip) == null ? void 0 : _middlewareData$flip2.index) || 0) + 1;
                const nextPlacement = placements[nextIndex];
                if (nextPlacement) {
                    const ignoreCrossAxisOverflow = checkCrossAxis === 'alignment' ? initialSideAxis !== (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSideAxis"])(nextPlacement) : false;
                    if (!ignoreCrossAxisOverflow || // We leave the current main axis only if every placement on that axis
                    // overflows the main axis.
                    overflowsData.every((d)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSideAxis"])(d.placement) === initialSideAxis ? d.overflows[0] > 0 : true)) {
                        // Try next placement and re-run the lifecycle.
                        return {
                            data: {
                                index: nextIndex,
                                overflows: overflowsData
                            },
                            reset: {
                                placement: nextPlacement
                            }
                        };
                    }
                }
                // First, find the candidates that fit on the mainAxis side of overflow,
                // then find the placement that fits the best on the main crossAxis side.
                let resetPlacement = (_overflowsData$filter = overflowsData.filter((d)=>d.overflows[0] <= 0).sort((a, b)=>a.overflows[1] - b.overflows[1])[0]) == null ? void 0 : _overflowsData$filter.placement;
                // Otherwise fallback.
                if (!resetPlacement) {
                    switch(fallbackStrategy){
                        case 'bestFit':
                            {
                                var _overflowsData$filter2;
                                const placement = (_overflowsData$filter2 = overflowsData.filter((d)=>{
                                    if (hasFallbackAxisSideDirection) {
                                        const currentSideAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSideAxis"])(d.placement);
                                        return currentSideAxis === initialSideAxis || // Create a bias to the `y` side axis due to horizontal
                                        // reading directions favoring greater width.
                                        currentSideAxis === 'y';
                                    }
                                    return true;
                                }).map((d)=>[
                                        d.placement,
                                        d.overflows.filter((overflow)=>overflow > 0).reduce((acc, overflow)=>acc + overflow, 0)
                                    ]).sort((a, b)=>a[1] - b[1])[0]) == null ? void 0 : _overflowsData$filter2[0];
                                if (placement) {
                                    resetPlacement = placement;
                                }
                                break;
                            }
                        case 'initialPlacement':
                            resetPlacement = initialPlacement;
                            break;
                    }
                }
                if (placement !== resetPlacement) {
                    return {
                        reset: {
                            placement: resetPlacement
                        }
                    };
                }
            }
            return {};
        }
    };
};
function getSideOffsets(overflow, rect) {
    return {
        top: overflow.top - rect.height,
        right: overflow.right - rect.width,
        bottom: overflow.bottom - rect.height,
        left: overflow.left - rect.width
    };
}
function isAnySideFullyClipped(overflow) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sides"].some((side)=>overflow[side] >= 0);
}
/**
 * Provides data to hide the floating element in applicable situations, such as
 * when it is not in the same clipping context as the reference element.
 * @see https://floating-ui.com/docs/hide
 */ const hide = function(options) {
    if (options === void 0) {
        options = {};
    }
    return {
        name: 'hide',
        options,
        async fn (state) {
            const { rects, platform } = state;
            const { strategy = 'referenceHidden', ...detectOverflowOptions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["evaluate"])(options, state);
            switch(strategy){
                case 'referenceHidden':
                    {
                        const overflow = await platform.detectOverflow(state, {
                            ...detectOverflowOptions,
                            elementContext: 'reference'
                        });
                        const offsets = getSideOffsets(overflow, rects.reference);
                        return {
                            data: {
                                referenceHiddenOffsets: offsets,
                                referenceHidden: isAnySideFullyClipped(offsets)
                            }
                        };
                    }
                case 'escaped':
                    {
                        const overflow = await platform.detectOverflow(state, {
                            ...detectOverflowOptions,
                            altBoundary: true
                        });
                        const offsets = getSideOffsets(overflow, rects.floating);
                        return {
                            data: {
                                escapedOffsets: offsets,
                                escaped: isAnySideFullyClipped(offsets)
                            }
                        };
                    }
                default:
                    {
                        return {};
                    }
            }
        }
    };
};
function getBoundingRect(rects) {
    const minX = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["min"])(...rects.map((rect)=>rect.left));
    const minY = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["min"])(...rects.map((rect)=>rect.top));
    const maxX = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(...rects.map((rect)=>rect.right));
    const maxY = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(...rects.map((rect)=>rect.bottom));
    return {
        x: minX,
        y: minY,
        width: maxX - minX,
        height: maxY - minY
    };
}
function getRectsByLine(rects) {
    const sortedRects = rects.slice().sort((a, b)=>a.y - b.y);
    const groups = [];
    let prevRect = null;
    for(let i = 0; i < sortedRects.length; i++){
        const rect = sortedRects[i];
        if (!prevRect || rect.y - prevRect.y > prevRect.height / 2) {
            groups.push([
                rect
            ]);
        } else {
            groups[groups.length - 1].push(rect);
        }
        prevRect = rect;
    }
    return groups.map((rect)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rectToClientRect"])(getBoundingRect(rect)));
}
/**
 * Provides improved positioning for inline reference elements that can span
 * over multiple lines, such as hyperlinks or range selections.
 * @see https://floating-ui.com/docs/inline
 */ const inline = function(options) {
    if (options === void 0) {
        options = {};
    }
    return {
        name: 'inline',
        options,
        async fn (state) {
            const { placement, elements, rects, platform, strategy } = state;
            // A MouseEvent's client{X,Y} coords can be up to 2 pixels off a
            // ClientRect's bounds, despite the event listener being triggered. A
            // padding of 2 seems to handle this issue.
            const { padding = 2, x, y } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["evaluate"])(options, state);
            const nativeClientRects = Array.from(await (platform.getClientRects == null ? void 0 : platform.getClientRects(elements.reference)) || []);
            const clientRects = getRectsByLine(nativeClientRects);
            const fallback = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rectToClientRect"])(getBoundingRect(nativeClientRects));
            const paddingObject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPaddingObject"])(padding);
            function getBoundingClientRect() {
                // There are two rects and they are disjoined.
                if (clientRects.length === 2 && clientRects[0].left > clientRects[1].right && x != null && y != null) {
                    // Find the first rect in which the point is fully inside.
                    return clientRects.find((rect)=>x > rect.left - paddingObject.left && x < rect.right + paddingObject.right && y > rect.top - paddingObject.top && y < rect.bottom + paddingObject.bottom) || fallback;
                }
                // There are 2 or more connected rects.
                if (clientRects.length >= 2) {
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSideAxis"])(placement) === 'y') {
                        const firstRect = clientRects[0];
                        const lastRect = clientRects[clientRects.length - 1];
                        const isTop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSide"])(placement) === 'top';
                        const top = firstRect.top;
                        const bottom = lastRect.bottom;
                        const left = isTop ? firstRect.left : lastRect.left;
                        const right = isTop ? firstRect.right : lastRect.right;
                        const width = right - left;
                        const height = bottom - top;
                        return {
                            top,
                            bottom,
                            left,
                            right,
                            width,
                            height,
                            x: left,
                            y: top
                        };
                    }
                    const isLeftSide = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSide"])(placement) === 'left';
                    const maxRight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(...clientRects.map((rect)=>rect.right));
                    const minLeft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["min"])(...clientRects.map((rect)=>rect.left));
                    const measureRects = clientRects.filter((rect)=>isLeftSide ? rect.left === minLeft : rect.right === maxRight);
                    const top = measureRects[0].top;
                    const bottom = measureRects[measureRects.length - 1].bottom;
                    const left = minLeft;
                    const right = maxRight;
                    const width = right - left;
                    const height = bottom - top;
                    return {
                        top,
                        bottom,
                        left,
                        right,
                        width,
                        height,
                        x: left,
                        y: top
                    };
                }
                return fallback;
            }
            const resetRects = await platform.getElementRects({
                reference: {
                    getBoundingClientRect
                },
                floating: elements.floating,
                strategy
            });
            if (rects.reference.x !== resetRects.reference.x || rects.reference.y !== resetRects.reference.y || rects.reference.width !== resetRects.reference.width || rects.reference.height !== resetRects.reference.height) {
                return {
                    reset: {
                        rects: resetRects
                    }
                };
            }
            return {};
        }
    };
};
const originSides = /*#__PURE__*/ new Set([
    'left',
    'top'
]);
// For type backwards-compatibility, the `OffsetOptions` type was also
// Derivable.
async function convertValueToCoords(state, options) {
    const { placement, platform, elements } = state;
    const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating));
    const side = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSide"])(placement);
    const alignment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlignment"])(placement);
    const isVertical = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSideAxis"])(placement) === 'y';
    const mainAxisMulti = originSides.has(side) ? -1 : 1;
    const crossAxisMulti = rtl && isVertical ? -1 : 1;
    const rawValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["evaluate"])(options, state);
    // eslint-disable-next-line prefer-const
    let { mainAxis, crossAxis, alignmentAxis } = typeof rawValue === 'number' ? {
        mainAxis: rawValue,
        crossAxis: 0,
        alignmentAxis: null
    } : {
        mainAxis: rawValue.mainAxis || 0,
        crossAxis: rawValue.crossAxis || 0,
        alignmentAxis: rawValue.alignmentAxis
    };
    if (alignment && typeof alignmentAxis === 'number') {
        crossAxis = alignment === 'end' ? alignmentAxis * -1 : alignmentAxis;
    }
    return isVertical ? {
        x: crossAxis * crossAxisMulti,
        y: mainAxis * mainAxisMulti
    } : {
        x: mainAxis * mainAxisMulti,
        y: crossAxis * crossAxisMulti
    };
}
/**
 * Modifies the placement by translating the floating element along the
 * specified axes.
 * A number (shorthand for `mainAxis` or distance), or an axes configuration
 * object may be passed.
 * @see https://floating-ui.com/docs/offset
 */ const offset = function(options) {
    if (options === void 0) {
        options = 0;
    }
    return {
        name: 'offset',
        options,
        async fn (state) {
            var _middlewareData$offse, _middlewareData$arrow;
            const { x, y, placement, middlewareData } = state;
            const diffCoords = await convertValueToCoords(state, options);
            // If the placement is the same and the arrow caused an alignment offset
            // then we don't need to change the positioning coordinates.
            if (placement === ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse.placement) && (_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) {
                return {};
            }
            return {
                x: x + diffCoords.x,
                y: y + diffCoords.y,
                data: {
                    ...diffCoords,
                    placement
                }
            };
        }
    };
};
/**
 * Optimizes the visibility of the floating element by shifting it in order to
 * keep it in view when it will overflow the clipping boundary.
 * @see https://floating-ui.com/docs/shift
 */ const shift = function(options) {
    if (options === void 0) {
        options = {};
    }
    return {
        name: 'shift',
        options,
        async fn (state) {
            const { x, y, placement, platform } = state;
            const { mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = false, limiter = {
                fn: (_ref)=>{
                    let { x, y } = _ref;
                    return {
                        x,
                        y
                    };
                }
            }, ...detectOverflowOptions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["evaluate"])(options, state);
            const coords = {
                x,
                y
            };
            const overflow = await platform.detectOverflow(state, detectOverflowOptions);
            const crossAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSideAxis"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSide"])(placement));
            const mainAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOppositeAxis"])(crossAxis);
            let mainAxisCoord = coords[mainAxis];
            let crossAxisCoord = coords[crossAxis];
            if (checkMainAxis) {
                const minSide = mainAxis === 'y' ? 'top' : 'left';
                const maxSide = mainAxis === 'y' ? 'bottom' : 'right';
                const min = mainAxisCoord + overflow[minSide];
                const max = mainAxisCoord - overflow[maxSide];
                mainAxisCoord = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(min, mainAxisCoord, max);
            }
            if (checkCrossAxis) {
                const minSide = crossAxis === 'y' ? 'top' : 'left';
                const maxSide = crossAxis === 'y' ? 'bottom' : 'right';
                const min = crossAxisCoord + overflow[minSide];
                const max = crossAxisCoord - overflow[maxSide];
                crossAxisCoord = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clamp"])(min, crossAxisCoord, max);
            }
            const limitedCoords = limiter.fn({
                ...state,
                [mainAxis]: mainAxisCoord,
                [crossAxis]: crossAxisCoord
            });
            return {
                ...limitedCoords,
                data: {
                    x: limitedCoords.x - x,
                    y: limitedCoords.y - y,
                    enabled: {
                        [mainAxis]: checkMainAxis,
                        [crossAxis]: checkCrossAxis
                    }
                }
            };
        }
    };
};
/**
 * Built-in `limiter` that will stop `shift()` at a certain point.
 */ const limitShift = function(options) {
    if (options === void 0) {
        options = {};
    }
    return {
        options,
        fn (state) {
            const { x, y, placement, rects, middlewareData } = state;
            const { offset = 0, mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = true } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["evaluate"])(options, state);
            const coords = {
                x,
                y
            };
            const crossAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSideAxis"])(placement);
            const mainAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOppositeAxis"])(crossAxis);
            let mainAxisCoord = coords[mainAxis];
            let crossAxisCoord = coords[crossAxis];
            const rawOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["evaluate"])(offset, state);
            const computedOffset = typeof rawOffset === 'number' ? {
                mainAxis: rawOffset,
                crossAxis: 0
            } : {
                mainAxis: 0,
                crossAxis: 0,
                ...rawOffset
            };
            if (checkMainAxis) {
                const len = mainAxis === 'y' ? 'height' : 'width';
                const limitMin = rects.reference[mainAxis] - rects.floating[len] + computedOffset.mainAxis;
                const limitMax = rects.reference[mainAxis] + rects.reference[len] - computedOffset.mainAxis;
                if (mainAxisCoord < limitMin) {
                    mainAxisCoord = limitMin;
                } else if (mainAxisCoord > limitMax) {
                    mainAxisCoord = limitMax;
                }
            }
            if (checkCrossAxis) {
                var _middlewareData$offse, _middlewareData$offse2;
                const len = mainAxis === 'y' ? 'width' : 'height';
                const isOriginSide = originSides.has((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSide"])(placement));
                const limitMin = rects.reference[crossAxis] - rects.floating[len] + (isOriginSide ? ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse[crossAxis]) || 0 : 0) + (isOriginSide ? 0 : computedOffset.crossAxis);
                const limitMax = rects.reference[crossAxis] + rects.reference[len] + (isOriginSide ? 0 : ((_middlewareData$offse2 = middlewareData.offset) == null ? void 0 : _middlewareData$offse2[crossAxis]) || 0) - (isOriginSide ? computedOffset.crossAxis : 0);
                if (crossAxisCoord < limitMin) {
                    crossAxisCoord = limitMin;
                } else if (crossAxisCoord > limitMax) {
                    crossAxisCoord = limitMax;
                }
            }
            return {
                [mainAxis]: mainAxisCoord,
                [crossAxis]: crossAxisCoord
            };
        }
    };
};
/**
 * Provides data that allows you to change the size of the floating element —
 * for instance, prevent it from overflowing the clipping boundary or match the
 * width of the reference element.
 * @see https://floating-ui.com/docs/size
 */ const size = function(options) {
    if (options === void 0) {
        options = {};
    }
    return {
        name: 'size',
        options,
        async fn (state) {
            var _state$middlewareData, _state$middlewareData2;
            const { placement, rects, platform, elements } = state;
            const { apply = ()=>{}, ...detectOverflowOptions } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["evaluate"])(options, state);
            const overflow = await platform.detectOverflow(state, detectOverflowOptions);
            const side = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSide"])(placement);
            const alignment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAlignment"])(placement);
            const isYAxis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSideAxis"])(placement) === 'y';
            const { width, height } = rects.floating;
            let heightSide;
            let widthSide;
            if (side === 'top' || side === 'bottom') {
                heightSide = side;
                widthSide = alignment === (await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating)) ? 'start' : 'end') ? 'left' : 'right';
            } else {
                widthSide = side;
                heightSide = alignment === 'end' ? 'top' : 'bottom';
            }
            const maximumClippingHeight = height - overflow.top - overflow.bottom;
            const maximumClippingWidth = width - overflow.left - overflow.right;
            const overflowAvailableHeight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["min"])(height - overflow[heightSide], maximumClippingHeight);
            const overflowAvailableWidth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["min"])(width - overflow[widthSide], maximumClippingWidth);
            const noShift = !state.middlewareData.shift;
            let availableHeight = overflowAvailableHeight;
            let availableWidth = overflowAvailableWidth;
            if ((_state$middlewareData = state.middlewareData.shift) != null && _state$middlewareData.enabled.x) {
                availableWidth = maximumClippingWidth;
            }
            if ((_state$middlewareData2 = state.middlewareData.shift) != null && _state$middlewareData2.enabled.y) {
                availableHeight = maximumClippingHeight;
            }
            if (noShift && !alignment) {
                const xMin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(overflow.left, 0);
                const xMax = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(overflow.right, 0);
                const yMin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(overflow.top, 0);
                const yMax = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(overflow.bottom, 0);
                if (isYAxis) {
                    availableWidth = width - 2 * (xMin !== 0 || xMax !== 0 ? xMin + xMax : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(overflow.left, overflow.right));
                } else {
                    availableHeight = height - 2 * (yMin !== 0 || yMax !== 0 ? yMin + yMax : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(overflow.top, overflow.bottom));
                }
            }
            await apply({
                ...state,
                availableWidth,
                availableHeight
            });
            const nextDimensions = await platform.getDimensions(elements.floating);
            if (width !== nextDimensions.width || height !== nextDimensions.height) {
                return {
                    reset: {
                        rects: true
                    }
                };
            }
            return {};
        }
    };
};
;
}),
"[project]/node_modules/@sanity/ui/node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "arrow",
    ()=>arrow,
    "autoPlacement",
    ()=>autoPlacement,
    "autoUpdate",
    ()=>autoUpdate,
    "computePosition",
    ()=>computePosition,
    "detectOverflow",
    ()=>detectOverflow,
    "flip",
    ()=>flip,
    "hide",
    ()=>hide,
    "inline",
    ()=>inline,
    "limitShift",
    ()=>limitShift,
    "offset",
    ()=>offset,
    "platform",
    ()=>platform,
    "shift",
    ()=>shift,
    "size",
    ()=>size
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/@floating-ui/core/dist/floating-ui.core.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript)");
;
;
;
;
function getCssDimensions(element) {
    const css = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getComputedStyle"])(element);
    // In testing environments, the `width` and `height` properties are empty
    // strings for SVG elements, returning NaN. Fallback to `0` in this case.
    let width = parseFloat(css.width) || 0;
    let height = parseFloat(css.height) || 0;
    const hasOffset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(element);
    const offsetWidth = hasOffset ? element.offsetWidth : width;
    const offsetHeight = hasOffset ? element.offsetHeight : height;
    const shouldFallback = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["round"])(width) !== offsetWidth || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["round"])(height) !== offsetHeight;
    if (shouldFallback) {
        width = offsetWidth;
        height = offsetHeight;
    }
    return {
        width,
        height,
        $: shouldFallback
    };
}
function unwrapElement(element) {
    return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(element) ? element.contextElement : element;
}
function getScale(element) {
    const domElement = unwrapElement(element);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(domElement)) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCoords"])(1);
    }
    const rect = domElement.getBoundingClientRect();
    const { width, height, $ } = getCssDimensions(domElement);
    let x = ($ ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["round"])(rect.width) : rect.width) / width;
    let y = ($ ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["round"])(rect.height) : rect.height) / height;
    // 0, NaN, or Infinity should always fallback to 1.
    if (!x || !Number.isFinite(x)) {
        x = 1;
    }
    if (!y || !Number.isFinite(y)) {
        y = 1;
    }
    return {
        x,
        y
    };
}
const noOffsets = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCoords"])(0);
function getVisualOffsets(element) {
    const win = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWindow"])(element);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWebKit"])() || !win.visualViewport) {
        return noOffsets;
    }
    return {
        x: win.visualViewport.offsetLeft,
        y: win.visualViewport.offsetTop
    };
}
function shouldAddVisualOffsets(element, isFixed, floatingOffsetParent) {
    if (isFixed === void 0) {
        isFixed = false;
    }
    if (!floatingOffsetParent || isFixed && floatingOffsetParent !== (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWindow"])(element)) {
        return false;
    }
    return isFixed;
}
function getBoundingClientRect(element, includeScale, isFixedStrategy, offsetParent) {
    if (includeScale === void 0) {
        includeScale = false;
    }
    if (isFixedStrategy === void 0) {
        isFixedStrategy = false;
    }
    const clientRect = element.getBoundingClientRect();
    const domElement = unwrapElement(element);
    let scale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCoords"])(1);
    if (includeScale) {
        if (offsetParent) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(offsetParent)) {
                scale = getScale(offsetParent);
            }
        } else {
            scale = getScale(element);
        }
    }
    const visualOffsets = shouldAddVisualOffsets(domElement, isFixedStrategy, offsetParent) ? getVisualOffsets(domElement) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCoords"])(0);
    let x = (clientRect.left + visualOffsets.x) / scale.x;
    let y = (clientRect.top + visualOffsets.y) / scale.y;
    let width = clientRect.width / scale.x;
    let height = clientRect.height / scale.y;
    if (domElement) {
        const win = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWindow"])(domElement);
        const offsetWin = offsetParent && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(offsetParent) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWindow"])(offsetParent) : offsetParent;
        let currentWin = win;
        let currentIFrame = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFrameElement"])(currentWin);
        while(currentIFrame && offsetParent && offsetWin !== currentWin){
            const iframeScale = getScale(currentIFrame);
            const iframeRect = currentIFrame.getBoundingClientRect();
            const css = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getComputedStyle"])(currentIFrame);
            const left = iframeRect.left + (currentIFrame.clientLeft + parseFloat(css.paddingLeft)) * iframeScale.x;
            const top = iframeRect.top + (currentIFrame.clientTop + parseFloat(css.paddingTop)) * iframeScale.y;
            x *= iframeScale.x;
            y *= iframeScale.y;
            width *= iframeScale.x;
            height *= iframeScale.y;
            x += left;
            y += top;
            currentWin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWindow"])(currentIFrame);
            currentIFrame = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFrameElement"])(currentWin);
        }
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rectToClientRect"])({
        width,
        height,
        x,
        y
    });
}
// If <html> has a CSS width greater than the viewport, then this will be
// incorrect for RTL.
function getWindowScrollBarX(element, rect) {
    const leftScroll = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNodeScroll"])(element).scrollLeft;
    if (!rect) {
        return getBoundingClientRect((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocumentElement"])(element)).left + leftScroll;
    }
    return rect.left + leftScroll;
}
function getHTMLOffset(documentElement, scroll) {
    const htmlRect = documentElement.getBoundingClientRect();
    const x = htmlRect.left + scroll.scrollLeft - getWindowScrollBarX(documentElement, htmlRect);
    const y = htmlRect.top + scroll.scrollTop;
    return {
        x,
        y
    };
}
function convertOffsetParentRelativeRectToViewportRelativeRect(_ref) {
    let { elements, rect, offsetParent, strategy } = _ref;
    const isFixed = strategy === 'fixed';
    const documentElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocumentElement"])(offsetParent);
    const topLayer = elements ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTopLayer"])(elements.floating) : false;
    if (offsetParent === documentElement || topLayer && isFixed) {
        return rect;
    }
    let scroll = {
        scrollLeft: 0,
        scrollTop: 0
    };
    let scale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCoords"])(1);
    const offsets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCoords"])(0);
    const isOffsetParentAnElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(offsetParent);
    if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNodeName"])(offsetParent) !== 'body' || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isOverflowElement"])(documentElement)) {
            scroll = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNodeScroll"])(offsetParent);
        }
        if (isOffsetParentAnElement) {
            const offsetRect = getBoundingClientRect(offsetParent);
            scale = getScale(offsetParent);
            offsets.x = offsetRect.x + offsetParent.clientLeft;
            offsets.y = offsetRect.y + offsetParent.clientTop;
        }
    }
    const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCoords"])(0);
    return {
        width: rect.width * scale.x,
        height: rect.height * scale.y,
        x: rect.x * scale.x - scroll.scrollLeft * scale.x + offsets.x + htmlOffset.x,
        y: rect.y * scale.y - scroll.scrollTop * scale.y + offsets.y + htmlOffset.y
    };
}
function getClientRects(element) {
    return Array.from(element.getClientRects());
}
// Gets the entire size of the scrollable document area, even extending outside
// of the `<html>` and `<body>` rect bounds if horizontally scrollable.
function getDocumentRect(element) {
    const html = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocumentElement"])(element);
    const scroll = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNodeScroll"])(element);
    const body = element.ownerDocument.body;
    const width = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(html.scrollWidth, html.clientWidth, body.scrollWidth, body.clientWidth);
    const height = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(html.scrollHeight, html.clientHeight, body.scrollHeight, body.clientHeight);
    let x = -scroll.scrollLeft + getWindowScrollBarX(element);
    const y = -scroll.scrollTop;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getComputedStyle"])(body).direction === 'rtl') {
        x += (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(html.clientWidth, body.clientWidth) - width;
    }
    return {
        width,
        height,
        x,
        y
    };
}
// Safety check: ensure the scrollbar space is reasonable in case this
// calculation is affected by unusual styles.
// Most scrollbars leave 15-18px of space.
const SCROLLBAR_MAX = 25;
function getViewportRect(element, strategy) {
    const win = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWindow"])(element);
    const html = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocumentElement"])(element);
    const visualViewport = win.visualViewport;
    let width = html.clientWidth;
    let height = html.clientHeight;
    let x = 0;
    let y = 0;
    if (visualViewport) {
        width = visualViewport.width;
        height = visualViewport.height;
        const visualViewportBased = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isWebKit"])();
        if (!visualViewportBased || visualViewportBased && strategy === 'fixed') {
            x = visualViewport.offsetLeft;
            y = visualViewport.offsetTop;
        }
    }
    const windowScrollbarX = getWindowScrollBarX(html);
    // <html> `overflow: hidden` + `scrollbar-gutter: stable` reduces the
    // visual width of the <html> but this is not considered in the size
    // of `html.clientWidth`.
    if (windowScrollbarX <= 0) {
        const doc = html.ownerDocument;
        const body = doc.body;
        const bodyStyles = getComputedStyle(body);
        const bodyMarginInline = doc.compatMode === 'CSS1Compat' ? parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight) || 0 : 0;
        const clippingStableScrollbarWidth = Math.abs(html.clientWidth - body.clientWidth - bodyMarginInline);
        if (clippingStableScrollbarWidth <= SCROLLBAR_MAX) {
            width -= clippingStableScrollbarWidth;
        }
    } else if (windowScrollbarX <= SCROLLBAR_MAX) {
        // If the <body> scrollbar is on the left, the width needs to be extended
        // by the scrollbar amount so there isn't extra space on the right.
        width += windowScrollbarX;
    }
    return {
        width,
        height,
        x,
        y
    };
}
// Returns the inner client rect, subtracting scrollbars if present.
function getInnerBoundingClientRect(element, strategy) {
    const clientRect = getBoundingClientRect(element, true, strategy === 'fixed');
    const top = clientRect.top + element.clientTop;
    const left = clientRect.left + element.clientLeft;
    const scale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(element) ? getScale(element) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCoords"])(1);
    const width = element.clientWidth * scale.x;
    const height = element.clientHeight * scale.y;
    const x = left * scale.x;
    const y = top * scale.y;
    return {
        width,
        height,
        x,
        y
    };
}
function getClientRectFromClippingAncestor(element, clippingAncestor, strategy) {
    let rect;
    if (clippingAncestor === 'viewport') {
        rect = getViewportRect(element, strategy);
    } else if (clippingAncestor === 'document') {
        rect = getDocumentRect((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocumentElement"])(element));
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(clippingAncestor)) {
        rect = getInnerBoundingClientRect(clippingAncestor, strategy);
    } else {
        const visualOffsets = getVisualOffsets(element);
        rect = {
            x: clippingAncestor.x - visualOffsets.x,
            y: clippingAncestor.y - visualOffsets.y,
            width: clippingAncestor.width,
            height: clippingAncestor.height
        };
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rectToClientRect"])(rect);
}
function hasFixedPositionAncestor(element, stopNode) {
    const parentNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getParentNode"])(element);
    if (parentNode === stopNode || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(parentNode) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isLastTraversableNode"])(parentNode)) {
        return false;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getComputedStyle"])(parentNode).position === 'fixed' || hasFixedPositionAncestor(parentNode, stopNode);
}
// A "clipping ancestor" is an `overflow` element with the characteristic of
// clipping (or hiding) child elements. This returns all clipping ancestors
// of the given element up the tree.
function getClippingElementAncestors(element, cache) {
    const cachedResult = cache.get(element);
    if (cachedResult) {
        return cachedResult;
    }
    let result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOverflowAncestors"])(element, [], false).filter((el)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(el) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNodeName"])(el) !== 'body');
    let currentContainingBlockComputedStyle = null;
    const elementIsFixed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getComputedStyle"])(element).position === 'fixed';
    let currentNode = elementIsFixed ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getParentNode"])(element) : element;
    // https://developer.mozilla.org/en-US/docs/Web/CSS/Containing_block#identifying_the_containing_block
    while((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(currentNode) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isLastTraversableNode"])(currentNode)){
        const computedStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getComputedStyle"])(currentNode);
        const currentNodeIsContaining = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isContainingBlock"])(currentNode);
        if (!currentNodeIsContaining && computedStyle.position === 'fixed') {
            currentContainingBlockComputedStyle = null;
        }
        const shouldDropCurrentNode = elementIsFixed ? !currentNodeIsContaining && !currentContainingBlockComputedStyle : !currentNodeIsContaining && computedStyle.position === 'static' && !!currentContainingBlockComputedStyle && (currentContainingBlockComputedStyle.position === 'absolute' || currentContainingBlockComputedStyle.position === 'fixed') || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isOverflowElement"])(currentNode) && !currentNodeIsContaining && hasFixedPositionAncestor(element, currentNode);
        if (shouldDropCurrentNode) {
            // Drop non-containing blocks.
            result = result.filter((ancestor)=>ancestor !== currentNode);
        } else {
            // Record last containing block for next iteration.
            currentContainingBlockComputedStyle = computedStyle;
        }
        currentNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getParentNode"])(currentNode);
    }
    cache.set(element, result);
    return result;
}
// Gets the maximum area that the element is visible in due to any number of
// clipping ancestors.
function getClippingRect(_ref) {
    let { element, boundary, rootBoundary, strategy } = _ref;
    const elementClippingAncestors = boundary === 'clippingAncestors' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTopLayer"])(element) ? [] : getClippingElementAncestors(element, this._c) : [].concat(boundary);
    const clippingAncestors = [
        ...elementClippingAncestors,
        rootBoundary
    ];
    const firstRect = getClientRectFromClippingAncestor(element, clippingAncestors[0], strategy);
    let top = firstRect.top;
    let right = firstRect.right;
    let bottom = firstRect.bottom;
    let left = firstRect.left;
    for(let i = 1; i < clippingAncestors.length; i++){
        const rect = getClientRectFromClippingAncestor(element, clippingAncestors[i], strategy);
        top = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(rect.top, top);
        right = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["min"])(rect.right, right);
        bottom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["min"])(rect.bottom, bottom);
        left = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(rect.left, left);
    }
    return {
        width: right - left,
        height: bottom - top,
        x: left,
        y: top
    };
}
function getDimensions(element) {
    const { width, height } = getCssDimensions(element);
    return {
        width,
        height
    };
}
function getRectRelativeToOffsetParent(element, offsetParent, strategy) {
    const isOffsetParentAnElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(offsetParent);
    const documentElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocumentElement"])(offsetParent);
    const isFixed = strategy === 'fixed';
    const rect = getBoundingClientRect(element, true, isFixed, offsetParent);
    let scroll = {
        scrollLeft: 0,
        scrollTop: 0
    };
    const offsets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCoords"])(0);
    // If the <body> scrollbar appears on the left (e.g. RTL systems). Use
    // Firefox with layout.scrollbar.side = 3 in about:config to test this.
    function setLeftRTLScrollbarOffset() {
        offsets.x = getWindowScrollBarX(documentElement);
    }
    if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNodeName"])(offsetParent) !== 'body' || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isOverflowElement"])(documentElement)) {
            scroll = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNodeScroll"])(offsetParent);
        }
        if (isOffsetParentAnElement) {
            const offsetRect = getBoundingClientRect(offsetParent, true, isFixed, offsetParent);
            offsets.x = offsetRect.x + offsetParent.clientLeft;
            offsets.y = offsetRect.y + offsetParent.clientTop;
        } else if (documentElement) {
            setLeftRTLScrollbarOffset();
        }
    }
    if (isFixed && !isOffsetParentAnElement && documentElement) {
        setLeftRTLScrollbarOffset();
    }
    const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCoords"])(0);
    const x = rect.left + scroll.scrollLeft - offsets.x - htmlOffset.x;
    const y = rect.top + scroll.scrollTop - offsets.y - htmlOffset.y;
    return {
        x,
        y,
        width: rect.width,
        height: rect.height
    };
}
function isStaticPositioned(element) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getComputedStyle"])(element).position === 'static';
}
function getTrueOffsetParent(element, polyfill) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(element) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getComputedStyle"])(element).position === 'fixed') {
        return null;
    }
    if (polyfill) {
        return polyfill(element);
    }
    let rawOffsetParent = element.offsetParent;
    // Firefox returns the <html> element as the offsetParent if it's non-static,
    // while Chrome and Safari return the <body> element. The <body> element must
    // be used to perform the correct calculations even if the <html> element is
    // non-static.
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocumentElement"])(element) === rawOffsetParent) {
        rawOffsetParent = rawOffsetParent.ownerDocument.body;
    }
    return rawOffsetParent;
}
// Gets the closest ancestor positioned element. Handles some edge cases,
// such as table ancestors and cross browser bugs.
function getOffsetParent(element, polyfill) {
    const win = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWindow"])(element);
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTopLayer"])(element)) {
        return win;
    }
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(element)) {
        let svgOffsetParent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getParentNode"])(element);
        while(svgOffsetParent && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isLastTraversableNode"])(svgOffsetParent)){
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(svgOffsetParent) && !isStaticPositioned(svgOffsetParent)) {
                return svgOffsetParent;
            }
            svgOffsetParent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getParentNode"])(svgOffsetParent);
        }
        return win;
    }
    let offsetParent = getTrueOffsetParent(element, polyfill);
    while(offsetParent && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTableElement"])(offsetParent) && isStaticPositioned(offsetParent)){
        offsetParent = getTrueOffsetParent(offsetParent, polyfill);
    }
    if (offsetParent && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isLastTraversableNode"])(offsetParent) && isStaticPositioned(offsetParent) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isContainingBlock"])(offsetParent)) {
        return win;
    }
    return offsetParent || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getContainingBlock"])(element) || win;
}
const getElementRects = async function(data) {
    const getOffsetParentFn = this.getOffsetParent || getOffsetParent;
    const getDimensionsFn = this.getDimensions;
    const floatingDimensions = await getDimensionsFn(data.floating);
    return {
        reference: getRectRelativeToOffsetParent(data.reference, await getOffsetParentFn(data.floating), data.strategy),
        floating: {
            x: 0,
            y: 0,
            width: floatingDimensions.width,
            height: floatingDimensions.height
        }
    };
};
function isRTL(element) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getComputedStyle"])(element).direction === 'rtl';
}
const platform = {
    convertOffsetParentRelativeRectToViewportRelativeRect,
    getDocumentElement: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocumentElement"],
    getClippingRect,
    getOffsetParent,
    getElementRects,
    getClientRects,
    getDimensions,
    getScale,
    isElement: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"],
    isRTL
};
function rectsAreEqual(a, b) {
    return a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;
}
// https://samthor.au/2021/observing-dom/
function observeMove(element, onMove) {
    let io = null;
    let timeoutId;
    const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocumentElement"])(element);
    function cleanup() {
        var _io;
        clearTimeout(timeoutId);
        (_io = io) == null || _io.disconnect();
        io = null;
    }
    function refresh(skip, threshold) {
        if (skip === void 0) {
            skip = false;
        }
        if (threshold === void 0) {
            threshold = 1;
        }
        cleanup();
        const elementRectForRootMargin = element.getBoundingClientRect();
        const { left, top, width, height } = elementRectForRootMargin;
        if (!skip) {
            onMove();
        }
        if (!width || !height) {
            return;
        }
        const insetTop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["floor"])(top);
        const insetRight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["floor"])(root.clientWidth - (left + width));
        const insetBottom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["floor"])(root.clientHeight - (top + height));
        const insetLeft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["floor"])(left);
        const rootMargin = -insetTop + "px " + -insetRight + "px " + -insetBottom + "px " + -insetLeft + "px";
        const options = {
            rootMargin,
            threshold: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["max"])(0, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["min"])(1, threshold)) || 1
        };
        let isFirstUpdate = true;
        function handleObserve(entries) {
            const ratio = entries[0].intersectionRatio;
            if (ratio !== threshold) {
                if (!isFirstUpdate) {
                    return refresh();
                }
                if (!ratio) {
                    // If the reference is clipped, the ratio is 0. Throttle the refresh
                    // to prevent an infinite loop of updates.
                    timeoutId = setTimeout(()=>{
                        refresh(false, 1e-7);
                    }, 1000);
                } else {
                    refresh(false, ratio);
                }
            }
            if (ratio === 1 && !rectsAreEqual(elementRectForRootMargin, element.getBoundingClientRect())) {
                // It's possible that even though the ratio is reported as 1, the
                // element is not actually fully within the IntersectionObserver's root
                // area anymore. This can happen under performance constraints. This may
                // be a bug in the browser's IntersectionObserver implementation. To
                // work around this, we compare the element's bounding rect now with
                // what it was at the time we created the IntersectionObserver. If they
                // are not equal then the element moved, so we refresh.
                refresh();
            }
            isFirstUpdate = false;
        }
        // Older browsers don't support a `document` as the root and will throw an
        // error.
        try {
            io = new IntersectionObserver(handleObserve, {
                ...options,
                // Handle <iframe>s
                root: root.ownerDocument
            });
        } catch (_e) {
            io = new IntersectionObserver(handleObserve, options);
        }
        io.observe(element);
    }
    refresh(true);
    return cleanup;
}
/**
 * Automatically updates the position of the floating element when necessary.
 * Should only be called when the floating element is mounted on the DOM or
 * visible on the screen.
 * @returns cleanup function that should be invoked when the floating element is
 * removed from the DOM or hidden from the screen.
 * @see https://floating-ui.com/docs/autoUpdate
 */ function autoUpdate(reference, floating, update, options) {
    if (options === void 0) {
        options = {};
    }
    const { ancestorScroll = true, ancestorResize = true, elementResize = typeof ResizeObserver === 'function', layoutShift = typeof IntersectionObserver === 'function', animationFrame = false } = options;
    const referenceEl = unwrapElement(reference);
    const ancestors = ancestorScroll || ancestorResize ? [
        ...referenceEl ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOverflowAncestors"])(referenceEl) : [],
        ...floating ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOverflowAncestors"])(floating) : []
    ] : [];
    ancestors.forEach((ancestor)=>{
        ancestorScroll && ancestor.addEventListener('scroll', update, {
            passive: true
        });
        ancestorResize && ancestor.addEventListener('resize', update);
    });
    const cleanupIo = referenceEl && layoutShift ? observeMove(referenceEl, update) : null;
    let reobserveFrame = -1;
    let resizeObserver = null;
    if (elementResize) {
        resizeObserver = new ResizeObserver((_ref)=>{
            let [firstEntry] = _ref;
            if (firstEntry && firstEntry.target === referenceEl && resizeObserver && floating) {
                // Prevent update loops when using the `size` middleware.
                // https://github.com/floating-ui/floating-ui/issues/1740
                resizeObserver.unobserve(floating);
                cancelAnimationFrame(reobserveFrame);
                reobserveFrame = requestAnimationFrame(()=>{
                    var _resizeObserver;
                    (_resizeObserver = resizeObserver) == null || _resizeObserver.observe(floating);
                });
            }
            update();
        });
        if (referenceEl && !animationFrame) {
            resizeObserver.observe(referenceEl);
        }
        if (floating) {
            resizeObserver.observe(floating);
        }
    }
    let frameId;
    let prevRefRect = animationFrame ? getBoundingClientRect(reference) : null;
    if (animationFrame) {
        frameLoop();
    }
    function frameLoop() {
        const nextRefRect = getBoundingClientRect(reference);
        if (prevRefRect && !rectsAreEqual(prevRefRect, nextRefRect)) {
            update();
        }
        prevRefRect = nextRefRect;
        frameId = requestAnimationFrame(frameLoop);
    }
    update();
    return ()=>{
        var _resizeObserver2;
        ancestors.forEach((ancestor)=>{
            ancestorScroll && ancestor.removeEventListener('scroll', update);
            ancestorResize && ancestor.removeEventListener('resize', update);
        });
        cleanupIo == null || cleanupIo();
        (_resizeObserver2 = resizeObserver) == null || _resizeObserver2.disconnect();
        resizeObserver = null;
        if (animationFrame) {
            cancelAnimationFrame(frameId);
        }
    };
}
/**
 * Resolves with an object of overflow side offsets that determine how much the
 * element is overflowing a given clipping boundary on each side.
 * - positive = overflowing the boundary by that number of pixels
 * - negative = how many pixels left before it will overflow
 * - 0 = lies flush with the boundary
 * @see https://floating-ui.com/docs/detectOverflow
 */ const detectOverflow = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["detectOverflow"];
/**
 * Modifies the placement by translating the floating element along the
 * specified axes.
 * A number (shorthand for `mainAxis` or distance), or an axes configuration
 * object may be passed.
 * @see https://floating-ui.com/docs/offset
 */ const offset = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["offset"];
/**
 * Optimizes the visibility of the floating element by choosing the placement
 * that has the most space available automatically, without needing to specify a
 * preferred placement. Alternative to `flip`.
 * @see https://floating-ui.com/docs/autoPlacement
 */ const autoPlacement = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["autoPlacement"];
/**
 * Optimizes the visibility of the floating element by shifting it in order to
 * keep it in view when it will overflow the clipping boundary.
 * @see https://floating-ui.com/docs/shift
 */ const shift = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["shift"];
/**
 * Optimizes the visibility of the floating element by flipping the `placement`
 * in order to keep it in view when the preferred placement(s) will overflow the
 * clipping boundary. Alternative to `autoPlacement`.
 * @see https://floating-ui.com/docs/flip
 */ const flip = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["flip"];
/**
 * Provides data that allows you to change the size of the floating element —
 * for instance, prevent it from overflowing the clipping boundary or match the
 * width of the reference element.
 * @see https://floating-ui.com/docs/size
 */ const size = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["size"];
/**
 * Provides data to hide the floating element in applicable situations, such as
 * when it is not in the same clipping context as the reference element.
 * @see https://floating-ui.com/docs/hide
 */ const hide = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["hide"];
/**
 * Provides data to position an inner element of the floating element so that it
 * appears centered to the reference element.
 * @see https://floating-ui.com/docs/arrow
 */ const arrow = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["arrow"];
/**
 * Provides improved positioning for inline reference elements that can span
 * over multiple lines, such as hyperlinks or range selections.
 * @see https://floating-ui.com/docs/inline
 */ const inline = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["inline"];
/**
 * Built-in `limiter` that will stop `shift()` at a certain point.
 */ const limitShift = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["limitShift"];
/**
 * Computes the `x` and `y` coordinates that will place the floating element
 * next to a given reference element.
 */ const computePosition = (reference, floating, options)=>{
    // This caches the expensive `getClippingElementAncestors` function so that
    // multiple lifecycle resets re-use the same result. It only lives for a
    // single call. If other functions become expensive, we can add them as well.
    const cache = new Map();
    const mergedOptions = {
        platform,
        ...options
    };
    const platformWithCache = {
        ...mergedOptions.platform,
        _c: cache
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["computePosition"])(reference, floating, {
        ...mergedOptions,
        platform: platformWithCache
    });
};
;
}),
"[project]/node_modules/@sanity/ui/node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "arrow",
    ()=>arrow,
    "autoPlacement",
    ()=>autoPlacement,
    "flip",
    ()=>flip,
    "hide",
    ()=>hide,
    "inline",
    ()=>inline,
    "limitShift",
    ()=>limitShift,
    "offset",
    ()=>offset,
    "shift",
    ()=>shift,
    "size",
    ()=>size,
    "useFloating",
    ()=>useFloating
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
;
;
;
;
;
var isClient = typeof document !== 'undefined';
var noop = function noop() {};
var index = isClient ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"] : noop;
// Fork of `fast-deep-equal` that only does the comparisons we need and compares
// functions
function deepEqual(a, b) {
    if (a === b) {
        return true;
    }
    if (typeof a !== typeof b) {
        return false;
    }
    if (typeof a === 'function' && a.toString() === b.toString()) {
        return true;
    }
    let length;
    let i;
    let keys;
    if (a && b && typeof a === 'object') {
        if (Array.isArray(a)) {
            length = a.length;
            if (length !== b.length) return false;
            for(i = length; i-- !== 0;){
                if (!deepEqual(a[i], b[i])) {
                    return false;
                }
            }
            return true;
        }
        keys = Object.keys(a);
        length = keys.length;
        if (length !== Object.keys(b).length) {
            return false;
        }
        for(i = length; i-- !== 0;){
            if (!({}).hasOwnProperty.call(b, keys[i])) {
                return false;
            }
        }
        for(i = length; i-- !== 0;){
            const key = keys[i];
            if (key === '_owner' && a.$$typeof) {
                continue;
            }
            if (!deepEqual(a[key], b[key])) {
                return false;
            }
        }
        return true;
    }
    return a !== a && b !== b;
}
function getDPR(element) {
    if (typeof window === 'undefined') {
        return 1;
    }
    const win = element.ownerDocument.defaultView || window;
    return win.devicePixelRatio || 1;
}
function roundByDPR(element, value) {
    const dpr = getDPR(element);
    return Math.round(value * dpr) / dpr;
}
function useLatestRef(value) {
    const ref = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](value);
    index(()=>{
        ref.current = value;
    });
    return ref;
}
/**
 * Provides data to position a floating element.
 * @see https://floating-ui.com/docs/useFloating
 */ function useFloating(options) {
    if (options === void 0) {
        options = {};
    }
    const { placement = 'bottom', strategy = 'absolute', middleware = [], platform, elements: { reference: externalReference, floating: externalFloating } = {}, transform = true, whileElementsMounted, open } = options;
    const [data, setData] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        x: 0,
        y: 0,
        strategy,
        placement,
        middlewareData: {},
        isPositioned: false
    });
    const [latestMiddleware, setLatestMiddleware] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](middleware);
    if (!deepEqual(latestMiddleware, middleware)) {
        setLatestMiddleware(middleware);
    }
    const [_reference, _setReference] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const [_floating, _setFloating] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const setReference = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "useFloating.useCallback[setReference]": (node)=>{
            if (node !== referenceRef.current) {
                referenceRef.current = node;
                _setReference(node);
            }
        }
    }["useFloating.useCallback[setReference]"], []);
    const setFloating = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "useFloating.useCallback[setFloating]": (node)=>{
            if (node !== floatingRef.current) {
                floatingRef.current = node;
                _setFloating(node);
            }
        }
    }["useFloating.useCallback[setFloating]"], []);
    const referenceEl = externalReference || _reference;
    const floatingEl = externalFloating || _floating;
    const referenceRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const floatingRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const dataRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](data);
    const hasWhileElementsMounted = whileElementsMounted != null;
    const whileElementsMountedRef = useLatestRef(whileElementsMounted);
    const platformRef = useLatestRef(platform);
    const openRef = useLatestRef(open);
    const update = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "useFloating.useCallback[update]": ()=>{
            if (!referenceRef.current || !floatingRef.current) {
                return;
            }
            const config = {
                placement,
                strategy,
                middleware: latestMiddleware
            };
            if (platformRef.current) {
                config.platform = platformRef.current;
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["computePosition"])(referenceRef.current, floatingRef.current, config).then({
                "useFloating.useCallback[update]": (data)=>{
                    const fullData = {
                        ...data,
                        // The floating element's position may be recomputed while it's closed
                        // but still mounted (such as when transitioning out). To ensure
                        // `isPositioned` will be `false` initially on the next open, avoid
                        // setting it to `true` when `open === false` (must be specified).
                        isPositioned: openRef.current !== false
                    };
                    if (isMountedRef.current && !deepEqual(dataRef.current, fullData)) {
                        dataRef.current = fullData;
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flushSync"]({
                            "useFloating.useCallback[update]": ()=>{
                                setData(fullData);
                            }
                        }["useFloating.useCallback[update]"]);
                    }
                }
            }["useFloating.useCallback[update]"]);
        }
    }["useFloating.useCallback[update]"], [
        latestMiddleware,
        placement,
        strategy,
        platformRef,
        openRef
    ]);
    index(()=>{
        if (open === false && dataRef.current.isPositioned) {
            dataRef.current.isPositioned = false;
            setData((data)=>({
                    ...data,
                    isPositioned: false
                }));
        }
    }, [
        open
    ]);
    const isMountedRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    index(()=>{
        isMountedRef.current = true;
        return ()=>{
            isMountedRef.current = false;
        };
    }, []);
    index(()=>{
        if (referenceEl) referenceRef.current = referenceEl;
        if (floatingEl) floatingRef.current = floatingEl;
        if (referenceEl && floatingEl) {
            if (whileElementsMountedRef.current) {
                return whileElementsMountedRef.current(referenceEl, floatingEl, update);
            }
            update();
        }
    }, [
        referenceEl,
        floatingEl,
        update,
        whileElementsMountedRef,
        hasWhileElementsMounted
    ]);
    const refs = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useFloating.useMemo[refs]": ()=>({
                reference: referenceRef,
                floating: floatingRef,
                setReference,
                setFloating
            })
    }["useFloating.useMemo[refs]"], [
        setReference,
        setFloating
    ]);
    const elements = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useFloating.useMemo[elements]": ()=>({
                reference: referenceEl,
                floating: floatingEl
            })
    }["useFloating.useMemo[elements]"], [
        referenceEl,
        floatingEl
    ]);
    const floatingStyles = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useFloating.useMemo[floatingStyles]": ()=>{
            const initialStyles = {
                position: strategy,
                left: 0,
                top: 0
            };
            if (!elements.floating) {
                return initialStyles;
            }
            const x = roundByDPR(elements.floating, data.x);
            const y = roundByDPR(elements.floating, data.y);
            if (transform) {
                return {
                    ...initialStyles,
                    transform: "translate(" + x + "px, " + y + "px)",
                    ...getDPR(elements.floating) >= 1.5 && {
                        willChange: 'transform'
                    }
                };
            }
            return {
                position: strategy,
                left: x,
                top: y
            };
        }
    }["useFloating.useMemo[floatingStyles]"], [
        strategy,
        transform,
        elements.floating,
        data.x,
        data.y
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useFloating.useMemo": ()=>({
                ...data,
                update,
                refs,
                elements,
                floatingStyles
            })
    }["useFloating.useMemo"], [
        data,
        update,
        refs,
        elements,
        floatingStyles
    ]);
}
/**
 * Provides data to position an inner element of the floating element so that it
 * appears centered to the reference element.
 * This wraps the core `arrow` middleware to allow React refs as the element.
 * @see https://floating-ui.com/docs/arrow
 */ const arrow$1 = (options)=>{
    function isRef(value) {
        return ({}).hasOwnProperty.call(value, 'current');
    }
    return {
        name: 'arrow',
        options,
        fn (state) {
            const { element, padding } = typeof options === 'function' ? options(state) : options;
            if (element && isRef(element)) {
                if (element.current != null) {
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["arrow"])({
                        element: element.current,
                        padding
                    }).fn(state);
                }
                return {};
            }
            if (element) {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["arrow"])({
                    element,
                    padding
                }).fn(state);
            }
            return {};
        }
    };
};
/**
 * Modifies the placement by translating the floating element along the
 * specified axes.
 * A number (shorthand for `mainAxis` or distance), or an axes configuration
 * object may be passed.
 * @see https://floating-ui.com/docs/offset
 */ const offset = (options, deps)=>{
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["offset"])(options);
    return {
        name: result.name,
        fn: result.fn,
        options: [
            options,
            deps
        ]
    };
};
/**
 * Optimizes the visibility of the floating element by shifting it in order to
 * keep it in view when it will overflow the clipping boundary.
 * @see https://floating-ui.com/docs/shift
 */ const shift = (options, deps)=>{
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["shift"])(options);
    return {
        name: result.name,
        fn: result.fn,
        options: [
            options,
            deps
        ]
    };
};
/**
 * Built-in `limiter` that will stop `shift()` at a certain point.
 */ const limitShift = (options, deps)=>{
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["limitShift"])(options);
    return {
        fn: result.fn,
        options: [
            options,
            deps
        ]
    };
};
/**
 * Optimizes the visibility of the floating element by flipping the `placement`
 * in order to keep it in view when the preferred placement(s) will overflow the
 * clipping boundary. Alternative to `autoPlacement`.
 * @see https://floating-ui.com/docs/flip
 */ const flip = (options, deps)=>{
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["flip"])(options);
    return {
        name: result.name,
        fn: result.fn,
        options: [
            options,
            deps
        ]
    };
};
/**
 * Provides data that allows you to change the size of the floating element —
 * for instance, prevent it from overflowing the clipping boundary or match the
 * width of the reference element.
 * @see https://floating-ui.com/docs/size
 */ const size = (options, deps)=>{
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["size"])(options);
    return {
        name: result.name,
        fn: result.fn,
        options: [
            options,
            deps
        ]
    };
};
/**
 * Optimizes the visibility of the floating element by choosing the placement
 * that has the most space available automatically, without needing to specify a
 * preferred placement. Alternative to `flip`.
 * @see https://floating-ui.com/docs/autoPlacement
 */ const autoPlacement = (options, deps)=>{
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["autoPlacement"])(options);
    return {
        name: result.name,
        fn: result.fn,
        options: [
            options,
            deps
        ]
    };
};
/**
 * Provides data to hide the floating element in applicable situations, such as
 * when it is not in the same clipping context as the reference element.
 * @see https://floating-ui.com/docs/hide
 */ const hide = (options, deps)=>{
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["hide"])(options);
    return {
        name: result.name,
        fn: result.fn,
        options: [
            options,
            deps
        ]
    };
};
/**
 * Provides improved positioning for inline reference elements that can span
 * over multiple lines, such as hyperlinks or range selections.
 * @see https://floating-ui.com/docs/inline
 */ const inline = (options, deps)=>{
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["inline"])(options);
    return {
        name: result.name,
        fn: result.fn,
        options: [
            options,
            deps
        ]
    };
};
/**
 * Provides data to position an inner element of the floating element so that it
 * appears centered to the reference element.
 * This wraps the core `arrow` middleware to allow React refs as the element.
 * @see https://floating-ui.com/docs/arrow
 */ const arrow = (options, deps)=>{
    const result = arrow$1(options);
    return {
        name: result.name,
        fn: result.fn,
        options: [
            options,
            deps
        ]
    };
};
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/clamp.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clamp",
    ()=>clamp
]);
const clamp = (min, max, v)=>{
    if (v > max) return max;
    if (v < min) return min;
    return v;
};
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/format-error-message.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatErrorMessage",
    ()=>formatErrorMessage
]);
function formatErrorMessage(message, errorCode) {
    return errorCode ? `${message}. For more information and steps for solving, visit https://motion.dev/troubleshooting/${errorCode}` : message;
}
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/errors.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "invariant",
    ()=>invariant,
    "warning",
    ()=>warning
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$format$2d$error$2d$message$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/format-error-message.mjs [app-client] (ecmascript)");
;
let warning = ()=>{};
let invariant = ()=>{};
if (typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] !== "undefined" && ("TURBOPACK compile-time value", "development") !== "production") {
    warning = (check, message, errorCode)=>{
        if (!check && typeof console !== "undefined") {
            console.warn((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$format$2d$error$2d$message$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatErrorMessage"])(message, errorCode));
        }
    };
    invariant = (check, message, errorCode)=>{
        if (!check) {
            throw new Error((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$format$2d$error$2d$message$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatErrorMessage"])(message, errorCode));
        }
    };
}
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/is-numerical-string.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isNumericalString",
    ()=>isNumericalString
]);
/**
 * Check if value is a numerical string, ie a string that is purely a number eg "100" or "-100.1"
 */ const isNumericalString = (v)=>/^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(v);
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/noop.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "noop",
    ()=>noop
]);
/*#__NO_SIDE_EFFECTS__*/ const noop = (any)=>any;
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/global-config.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MotionGlobalConfig",
    ()=>MotionGlobalConfig
]);
const MotionGlobalConfig = {};
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/is-zero-value-string.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isZeroValueString",
    ()=>isZeroValueString
]);
/**
 * Check if the value is a zero value string like "0px" or "0%"
 */ const isZeroValueString = (v)=>/^0[^.\s]+$/u.test(v);
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/warn-once.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hasWarned",
    ()=>hasWarned,
    "warnOnce",
    ()=>warnOnce
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$format$2d$error$2d$message$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/format-error-message.mjs [app-client] (ecmascript)");
;
const warned = new Set();
function hasWarned(message) {
    return warned.has(message);
}
function warnOnce(condition, message, errorCode) {
    if (condition || warned.has(message)) return;
    console.warn((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$format$2d$error$2d$message$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatErrorMessage"])(message, errorCode));
    warned.add(message);
}
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/time-conversion.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "millisecondsToSeconds",
    ()=>millisecondsToSeconds,
    "secondsToMilliseconds",
    ()=>secondsToMilliseconds
]);
/**
 * Converts seconds to milliseconds
 *
 * @param seconds - Time in seconds.
 * @return milliseconds - Converted time in milliseconds.
 */ /*#__NO_SIDE_EFFECTS__*/ const secondsToMilliseconds = (seconds)=>seconds * 1000;
/*#__NO_SIDE_EFFECTS__*/ const millisecondsToSeconds = (milliseconds)=>milliseconds / 1000;
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/array.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addUniqueItem",
    ()=>addUniqueItem,
    "moveItem",
    ()=>moveItem,
    "removeItem",
    ()=>removeItem
]);
function addUniqueItem(arr, item) {
    if (arr.indexOf(item) === -1) arr.push(item);
}
function removeItem(arr, item) {
    const index = arr.indexOf(item);
    if (index > -1) arr.splice(index, 1);
}
// Adapted from array-move
function moveItem([...arr], fromIndex, toIndex) {
    const startIndex = fromIndex < 0 ? arr.length + fromIndex : fromIndex;
    if (startIndex >= 0 && startIndex < arr.length) {
        const endIndex = toIndex < 0 ? arr.length + toIndex : toIndex;
        const [item] = arr.splice(fromIndex, 1);
        arr.splice(endIndex, 0, item);
    }
    return arr;
}
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/subscription-manager.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SubscriptionManager",
    ()=>SubscriptionManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/array.mjs [app-client] (ecmascript)");
;
class SubscriptionManager {
    constructor(){
        this.subscriptions = [];
    }
    add(handler) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addUniqueItem"])(this.subscriptions, handler);
        return ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$array$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeItem"])(this.subscriptions, handler);
    }
    notify(a, b, c) {
        const numSubscriptions = this.subscriptions.length;
        if (!numSubscriptions) return;
        if (numSubscriptions === 1) {
            /**
             * If there's only a single handler we can just call it without invoking a loop.
             */ this.subscriptions[0](a, b, c);
        } else {
            for(let i = 0; i < numSubscriptions; i++){
                /**
                 * Check whether the handler exists before firing as it's possible
                 * the subscriptions were modified during this loop running.
                 */ const handler = this.subscriptions[i];
                handler && handler(a, b, c);
            }
        }
    }
    getSize() {
        return this.subscriptions.length;
    }
    clear() {
        this.subscriptions.length = 0;
    }
}
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/memo.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "memo",
    ()=>memo
]);
/*#__NO_SIDE_EFFECTS__*/ function memo(callback) {
    let result;
    return ()=>{
        if (result === undefined) result = callback();
        return result;
    };
}
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/utils/is-bezier-definition.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isBezierDefinition",
    ()=>isBezierDefinition
]);
const isBezierDefinition = (easing)=>Array.isArray(easing) && typeof easing[0] === "number";
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/velocity-per-second.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "velocityPerSecond",
    ()=>velocityPerSecond
]);
/*
  Convert velocity into velocity per second

  @param [number]: Unit per frame
  @param [number]: Frame duration in ms
*/ function velocityPerSecond(velocity, frameDuration) {
    return frameDuration ? velocity * (1000 / frameDuration) : 0;
}
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/pipe.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "pipe",
    ()=>pipe
]);
/**
 * Pipe
 * Compose other transformers to run linearily
 * pipe(min(20), max(40))
 * @param  {...functions} transformers
 * @return {function}
 */ const combineFunctions = (a, b)=>(v)=>b(a(v));
const pipe = (...transformers)=>transformers.reduce(combineFunctions);
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/cubic-bezier.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cubicBezier",
    ()=>cubicBezier
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$noop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/noop.mjs [app-client] (ecmascript)");
;
/*
  Bezier function generator
  This has been modified from Gaëtan Renaudeau's BezierEasing
  https://github.com/gre/bezier-easing/blob/master/src/index.js
  https://github.com/gre/bezier-easing/blob/master/LICENSE
  
  I've removed the newtonRaphsonIterate algo because in benchmarking it
  wasn't noticeably faster than binarySubdivision, indeed removing it
  usually improved times, depending on the curve.
  I also removed the lookup table, as for the added bundle size and loop we're
  only cutting ~4 or so subdivision iterations. I bumped the max iterations up
  to 12 to compensate and this still tended to be faster for no perceivable
  loss in accuracy.
  Usage
    const easeOut = cubicBezier(.17,.67,.83,.67);
    const x = easeOut(0.5); // returns 0.627...
*/ // Returns x(t) given t, x1, and x2, or y(t) given t, y1, and y2.
const calcBezier = (t, a1, a2)=>(((1.0 - 3.0 * a2 + 3.0 * a1) * t + (3.0 * a2 - 6.0 * a1)) * t + 3.0 * a1) * t;
const subdivisionPrecision = 0.0000001;
const subdivisionMaxIterations = 12;
function binarySubdivide(x, lowerBound, upperBound, mX1, mX2) {
    let currentX;
    let currentT;
    let i = 0;
    do {
        currentT = lowerBound + (upperBound - lowerBound) / 2.0;
        currentX = calcBezier(currentT, mX1, mX2) - x;
        if (currentX > 0.0) {
            upperBound = currentT;
        } else {
            lowerBound = currentT;
        }
    }while (Math.abs(currentX) > subdivisionPrecision && ++i < subdivisionMaxIterations)
    return currentT;
}
function cubicBezier(mX1, mY1, mX2, mY2) {
    // If this is a linear gradient, return linear easing
    if (mX1 === mY1 && mX2 === mY2) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$noop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"];
    const getTForX = (aX)=>binarySubdivide(aX, 0, 1, mX1, mX2);
    // If animation is at start/end, return t without easing
    return (t)=>t === 0 || t === 1 ? t : calcBezier(getTForX(t), mY1, mY2);
}
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/ease.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "easeIn",
    ()=>easeIn,
    "easeInOut",
    ()=>easeInOut,
    "easeOut",
    ()=>easeOut
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/cubic-bezier.mjs [app-client] (ecmascript)");
;
const easeIn = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cubicBezier"])(0.42, 0, 1, 1);
const easeOut = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cubicBezier"])(0, 0, 0.58, 1);
const easeInOut = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cubicBezier"])(0.42, 0, 0.58, 1);
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/utils/is-easing-array.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isEasingArray",
    ()=>isEasingArray
]);
const isEasingArray = (ease)=>{
    return Array.isArray(ease) && typeof ease[0] !== "number";
};
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/modifiers/mirror.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mirrorEasing",
    ()=>mirrorEasing
]);
// Accepts an easing function and returns a new one that outputs mirrored values for
// the second half of the animation. Turns easeIn into easeInOut.
const mirrorEasing = (easing)=>(p)=>p <= 0.5 ? easing(2 * p) / 2 : (2 - easing(2 * (1 - p))) / 2;
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/modifiers/reverse.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "reverseEasing",
    ()=>reverseEasing
]);
// Accepts an easing function and returns a new one that outputs reversed values.
// Turns easeIn into easeOut.
const reverseEasing = (easing)=>(p)=>1 - easing(1 - p);
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/back.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "backIn",
    ()=>backIn,
    "backInOut",
    ()=>backInOut,
    "backOut",
    ()=>backOut
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/cubic-bezier.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$mirror$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/modifiers/mirror.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$reverse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/modifiers/reverse.mjs [app-client] (ecmascript)");
;
;
;
const backOut = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cubicBezier"])(0.33, 1.53, 0.69, 0.99);
const backIn = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$reverse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reverseEasing"])(backOut);
const backInOut = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$mirror$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mirrorEasing"])(backIn);
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/anticipate.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "anticipate",
    ()=>anticipate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$back$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/back.mjs [app-client] (ecmascript)");
;
const anticipate = (p)=>p >= 1 ? 1 : (p *= 2) < 1 ? 0.5 * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$back$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["backIn"])(p) : 0.5 * (2 - Math.pow(2, -10 * (p - 1)));
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/circ.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "circIn",
    ()=>circIn,
    "circInOut",
    ()=>circInOut,
    "circOut",
    ()=>circOut
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$mirror$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/modifiers/mirror.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$reverse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/modifiers/reverse.mjs [app-client] (ecmascript)");
;
;
const circIn = (p)=>1 - Math.sin(Math.acos(p));
const circOut = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$reverse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reverseEasing"])(circIn);
const circInOut = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$modifiers$2f$mirror$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mirrorEasing"])(circIn);
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/utils/map.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "easingDefinitionToFunction",
    ()=>easingDefinitionToFunction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$errors$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/errors.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$noop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/noop.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$anticipate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/anticipate.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$back$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/back.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$circ$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/circ.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/cubic-bezier.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$ease$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/ease.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$utils$2f$is$2d$bezier$2d$definition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/easing/utils/is-bezier-definition.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
const easingLookup = {
    linear: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$noop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"],
    easeIn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$ease$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["easeIn"],
    easeInOut: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$ease$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["easeInOut"],
    easeOut: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$ease$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["easeOut"],
    circIn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$circ$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["circIn"],
    circInOut: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$circ$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["circInOut"],
    circOut: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$circ$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["circOut"],
    backIn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$back$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["backIn"],
    backInOut: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$back$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["backInOut"],
    backOut: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$back$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["backOut"],
    anticipate: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$anticipate$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["anticipate"]
};
const isValidEasing = (easing)=>{
    return typeof easing === "string";
};
const easingDefinitionToFunction = (definition)=>{
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$utils$2f$is$2d$bezier$2d$definition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isBezierDefinition"])(definition)) {
        // If cubic bezier definition, create bezier curve
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$errors$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(definition.length === 4, `Cubic bezier arrays must contain four numerical values.`, "cubic-bezier-length");
        const [x1, y1, x2, y2] = definition;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$easing$2f$cubic$2d$bezier$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cubicBezier"])(x1, y1, x2, y2);
    } else if (isValidEasing(definition)) {
        // Else lookup from table
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$motion$2d$utils$2f$dist$2f$es$2f$errors$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"])(easingLookup[definition] !== undefined, `Invalid easing type '${definition}'`, "invalid-easing-type");
        return easingLookup[definition];
    }
    return definition;
};
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/progress.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "progress",
    ()=>progress
]);
/*
  Progress within given range

  Given a lower limit and an upper limit, we return the progress
  (expressed as a number 0-1) represented by the given value, and
  limit that progress to within 0-1.

  @param [number]: Lower limit
  @param [number]: Upper limit
  @param [number]: Value to find progress within given range
  @return [number]: Progress of value within range as expressed 0-1
*/ /*#__NO_SIDE_EFFECTS__*/ const progress = (from, to, value)=>{
    const toFromDifference = to - from;
    return toFromDifference === 0 ? 1 : (value - from) / toFromDifference;
};
;
}),
"[project]/node_modules/@sanity/ui/node_modules/motion-utils/dist/es/is-object.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isObject",
    ()=>isObject
]);
function isObject(value) {
    return typeof value === "object" && value !== null;
}
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/utils/resizeObservers.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "resizeObservers",
    ()=>resizeObservers
]);
var resizeObservers = [];
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/algorithms/hasActiveObservations.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hasActiveObservations",
    ()=>hasActiveObservations
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$resizeObservers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/resizeObservers.js [app-client] (ecmascript)");
;
var hasActiveObservations = function() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$resizeObservers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resizeObservers"].some(function(ro) {
        return ro.activeTargets.length > 0;
    });
};
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/algorithms/hasSkippedObservations.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "hasSkippedObservations",
    ()=>hasSkippedObservations
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$resizeObservers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/resizeObservers.js [app-client] (ecmascript)");
;
var hasSkippedObservations = function() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$resizeObservers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resizeObservers"].some(function(ro) {
        return ro.skippedTargets.length > 0;
    });
};
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/algorithms/deliverResizeLoopError.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deliverResizeLoopError",
    ()=>deliverResizeLoopError
]);
var msg = 'ResizeObserver loop completed with undelivered notifications.';
var deliverResizeLoopError = function() {
    var event;
    if (typeof ErrorEvent === 'function') {
        event = new ErrorEvent('error', {
            message: msg
        });
    } else {
        event = document.createEvent('Event');
        event.initEvent('error', false, false);
        event.message = msg;
    }
    window.dispatchEvent(event);
};
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/ResizeObserverBoxOptions.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ResizeObserverBoxOptions",
    ()=>ResizeObserverBoxOptions
]);
var ResizeObserverBoxOptions;
(function(ResizeObserverBoxOptions) {
    ResizeObserverBoxOptions["BORDER_BOX"] = "border-box";
    ResizeObserverBoxOptions["CONTENT_BOX"] = "content-box";
    ResizeObserverBoxOptions["DEVICE_PIXEL_CONTENT_BOX"] = "device-pixel-content-box";
})(ResizeObserverBoxOptions || (ResizeObserverBoxOptions = {}));
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/utils/freeze.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "freeze",
    ()=>freeze
]);
var freeze = function(obj) {
    return Object.freeze(obj);
};
}),
"[project]/node_modules/@juggle/resize-observer/lib/ResizeObserverSize.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ResizeObserverSize",
    ()=>ResizeObserverSize
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$freeze$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/freeze.js [app-client] (ecmascript)");
;
var ResizeObserverSize = function() {
    function ResizeObserverSize(inlineSize, blockSize) {
        this.inlineSize = inlineSize;
        this.blockSize = blockSize;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$freeze$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["freeze"])(this);
    }
    return ResizeObserverSize;
}();
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/DOMRectReadOnly.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DOMRectReadOnly",
    ()=>DOMRectReadOnly
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$freeze$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/freeze.js [app-client] (ecmascript)");
;
var DOMRectReadOnly = function() {
    function DOMRectReadOnly(x, y, width, height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.top = this.y;
        this.left = this.x;
        this.bottom = this.top + this.height;
        this.right = this.left + this.width;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$freeze$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["freeze"])(this);
    }
    DOMRectReadOnly.prototype.toJSON = function() {
        var _a = this, x = _a.x, y = _a.y, top = _a.top, right = _a.right, bottom = _a.bottom, left = _a.left, width = _a.width, height = _a.height;
        return {
            x: x,
            y: y,
            top: top,
            right: right,
            bottom: bottom,
            left: left,
            width: width,
            height: height
        };
    };
    DOMRectReadOnly.fromRect = function(rectangle) {
        return new DOMRectReadOnly(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    };
    return DOMRectReadOnly;
}();
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/utils/element.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isElement",
    ()=>isElement,
    "isHidden",
    ()=>isHidden,
    "isReplacedElement",
    ()=>isReplacedElement,
    "isSVG",
    ()=>isSVG
]);
var isSVG = function(target) {
    return target instanceof SVGElement && 'getBBox' in target;
};
var isHidden = function(target) {
    if (isSVG(target)) {
        var _a = target.getBBox(), width = _a.width, height = _a.height;
        return !width && !height;
    }
    var _b = target, offsetWidth = _b.offsetWidth, offsetHeight = _b.offsetHeight;
    return !(offsetWidth || offsetHeight || target.getClientRects().length);
};
var isElement = function(obj) {
    var _a;
    if (obj instanceof Element) {
        return true;
    }
    var scope = (_a = obj === null || obj === void 0 ? void 0 : obj.ownerDocument) === null || _a === void 0 ? void 0 : _a.defaultView;
    return !!(scope && obj instanceof scope.Element);
};
var isReplacedElement = function(target) {
    switch(target.tagName){
        case 'INPUT':
            if (target.type !== 'image') {
                break;
            }
        case 'VIDEO':
        case 'AUDIO':
        case 'EMBED':
        case 'OBJECT':
        case 'CANVAS':
        case 'IFRAME':
        case 'IMG':
            return true;
    }
    return false;
};
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/utils/global.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "global",
    ()=>global
]);
var global = typeof window !== 'undefined' ? window : {};
}),
"[project]/node_modules/@juggle/resize-observer/lib/algorithms/calculateBoxSize.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculateBoxSize",
    ()=>calculateBoxSize,
    "calculateBoxSizes",
    ()=>calculateBoxSizes
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverBoxOptions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/ResizeObserverBoxOptions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverSize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/ResizeObserverSize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$DOMRectReadOnly$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/DOMRectReadOnly.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/element.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$freeze$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/freeze.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$global$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/global.js [app-client] (ecmascript)");
;
;
;
;
;
;
var cache = new WeakMap();
var scrollRegexp = /auto|scroll/;
var verticalRegexp = /^tb|vertical/;
var IE = /msie|trident/i.test(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$global$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["global"].navigator && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$global$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["global"].navigator.userAgent);
var parseDimension = function(pixel) {
    return parseFloat(pixel || '0');
};
var size = function(inlineSize, blockSize, switchSizes) {
    if (inlineSize === void 0) {
        inlineSize = 0;
    }
    if (blockSize === void 0) {
        blockSize = 0;
    }
    if (switchSizes === void 0) {
        switchSizes = false;
    }
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverSize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResizeObserverSize"]((switchSizes ? blockSize : inlineSize) || 0, (switchSizes ? inlineSize : blockSize) || 0);
};
var zeroBoxes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$freeze$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["freeze"])({
    devicePixelContentBoxSize: size(),
    borderBoxSize: size(),
    contentBoxSize: size(),
    contentRect: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$DOMRectReadOnly$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DOMRectReadOnly"](0, 0, 0, 0)
});
var calculateBoxSizes = function(target, forceRecalculation) {
    if (forceRecalculation === void 0) {
        forceRecalculation = false;
    }
    if (cache.has(target) && !forceRecalculation) {
        return cache.get(target);
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHidden"])(target)) {
        cache.set(target, zeroBoxes);
        return zeroBoxes;
    }
    var cs = getComputedStyle(target);
    var svg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSVG"])(target) && target.ownerSVGElement && target.getBBox();
    var removePadding = !IE && cs.boxSizing === 'border-box';
    var switchSizes = verticalRegexp.test(cs.writingMode || '');
    var canScrollVertically = !svg && scrollRegexp.test(cs.overflowY || '');
    var canScrollHorizontally = !svg && scrollRegexp.test(cs.overflowX || '');
    var paddingTop = svg ? 0 : parseDimension(cs.paddingTop);
    var paddingRight = svg ? 0 : parseDimension(cs.paddingRight);
    var paddingBottom = svg ? 0 : parseDimension(cs.paddingBottom);
    var paddingLeft = svg ? 0 : parseDimension(cs.paddingLeft);
    var borderTop = svg ? 0 : parseDimension(cs.borderTopWidth);
    var borderRight = svg ? 0 : parseDimension(cs.borderRightWidth);
    var borderBottom = svg ? 0 : parseDimension(cs.borderBottomWidth);
    var borderLeft = svg ? 0 : parseDimension(cs.borderLeftWidth);
    var horizontalPadding = paddingLeft + paddingRight;
    var verticalPadding = paddingTop + paddingBottom;
    var horizontalBorderArea = borderLeft + borderRight;
    var verticalBorderArea = borderTop + borderBottom;
    var horizontalScrollbarThickness = !canScrollHorizontally ? 0 : target.offsetHeight - verticalBorderArea - target.clientHeight;
    var verticalScrollbarThickness = !canScrollVertically ? 0 : target.offsetWidth - horizontalBorderArea - target.clientWidth;
    var widthReduction = removePadding ? horizontalPadding + horizontalBorderArea : 0;
    var heightReduction = removePadding ? verticalPadding + verticalBorderArea : 0;
    var contentWidth = svg ? svg.width : parseDimension(cs.width) - widthReduction - verticalScrollbarThickness;
    var contentHeight = svg ? svg.height : parseDimension(cs.height) - heightReduction - horizontalScrollbarThickness;
    var borderBoxWidth = contentWidth + horizontalPadding + verticalScrollbarThickness + horizontalBorderArea;
    var borderBoxHeight = contentHeight + verticalPadding + horizontalScrollbarThickness + verticalBorderArea;
    var boxes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$freeze$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["freeze"])({
        devicePixelContentBoxSize: size(Math.round(contentWidth * devicePixelRatio), Math.round(contentHeight * devicePixelRatio), switchSizes),
        borderBoxSize: size(borderBoxWidth, borderBoxHeight, switchSizes),
        contentBoxSize: size(contentWidth, contentHeight, switchSizes),
        contentRect: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$DOMRectReadOnly$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DOMRectReadOnly"](paddingLeft, paddingTop, contentWidth, contentHeight)
    });
    cache.set(target, boxes);
    return boxes;
};
var calculateBoxSize = function(target, observedBox, forceRecalculation) {
    var _a = calculateBoxSizes(target, forceRecalculation), borderBoxSize = _a.borderBoxSize, contentBoxSize = _a.contentBoxSize, devicePixelContentBoxSize = _a.devicePixelContentBoxSize;
    switch(observedBox){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverBoxOptions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResizeObserverBoxOptions"].DEVICE_PIXEL_CONTENT_BOX:
            return devicePixelContentBoxSize;
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverBoxOptions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResizeObserverBoxOptions"].BORDER_BOX:
            return borderBoxSize;
        default:
            return contentBoxSize;
    }
};
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/ResizeObserverEntry.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ResizeObserverEntry",
    ()=>ResizeObserverEntry
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$calculateBoxSize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/algorithms/calculateBoxSize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$freeze$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/freeze.js [app-client] (ecmascript)");
;
;
var ResizeObserverEntry = function() {
    function ResizeObserverEntry(target) {
        var boxes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$calculateBoxSize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateBoxSizes"])(target);
        this.target = target;
        this.contentRect = boxes.contentRect;
        this.borderBoxSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$freeze$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["freeze"])([
            boxes.borderBoxSize
        ]);
        this.contentBoxSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$freeze$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["freeze"])([
            boxes.contentBoxSize
        ]);
        this.devicePixelContentBoxSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$freeze$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["freeze"])([
            boxes.devicePixelContentBoxSize
        ]);
    }
    return ResizeObserverEntry;
}();
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/algorithms/calculateDepthForNode.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculateDepthForNode",
    ()=>calculateDepthForNode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/element.js [app-client] (ecmascript)");
;
var calculateDepthForNode = function(node) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHidden"])(node)) {
        return Infinity;
    }
    var depth = 0;
    var parent = node.parentNode;
    while(parent){
        depth += 1;
        parent = parent.parentNode;
    }
    return depth;
};
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/algorithms/broadcastActiveObservations.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "broadcastActiveObservations",
    ()=>broadcastActiveObservations
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$resizeObservers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/resizeObservers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverEntry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/ResizeObserverEntry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$calculateDepthForNode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/algorithms/calculateDepthForNode.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$calculateBoxSize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/algorithms/calculateBoxSize.js [app-client] (ecmascript)");
;
;
;
;
var broadcastActiveObservations = function() {
    var shallowestDepth = Infinity;
    var callbacks = [];
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$resizeObservers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resizeObservers"].forEach(function processObserver(ro) {
        if (ro.activeTargets.length === 0) {
            return;
        }
        var entries = [];
        ro.activeTargets.forEach(function processTarget(ot) {
            var entry = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverEntry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResizeObserverEntry"](ot.target);
            var targetDepth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$calculateDepthForNode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateDepthForNode"])(ot.target);
            entries.push(entry);
            ot.lastReportedSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$calculateBoxSize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateBoxSize"])(ot.target, ot.observedBox);
            if (targetDepth < shallowestDepth) {
                shallowestDepth = targetDepth;
            }
        });
        callbacks.push(function resizeObserverCallback() {
            ro.callback.call(ro.observer, entries, ro.observer);
        });
        ro.activeTargets.splice(0, ro.activeTargets.length);
    });
    for(var _i = 0, callbacks_1 = callbacks; _i < callbacks_1.length; _i++){
        var callback = callbacks_1[_i];
        callback();
    }
    return shallowestDepth;
};
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/algorithms/gatherActiveObservationsAtDepth.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "gatherActiveObservationsAtDepth",
    ()=>gatherActiveObservationsAtDepth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$resizeObservers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/resizeObservers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$calculateDepthForNode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/algorithms/calculateDepthForNode.js [app-client] (ecmascript)");
;
;
var gatherActiveObservationsAtDepth = function(depth) {
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$resizeObservers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resizeObservers"].forEach(function processObserver(ro) {
        ro.activeTargets.splice(0, ro.activeTargets.length);
        ro.skippedTargets.splice(0, ro.skippedTargets.length);
        ro.observationTargets.forEach(function processTarget(ot) {
            if (ot.isActive()) {
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$calculateDepthForNode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateDepthForNode"])(ot.target) > depth) {
                    ro.activeTargets.push(ot);
                } else {
                    ro.skippedTargets.push(ot);
                }
            }
        });
    });
};
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/utils/process.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "process",
    ()=>process
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$hasActiveObservations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/algorithms/hasActiveObservations.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$hasSkippedObservations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/algorithms/hasSkippedObservations.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$deliverResizeLoopError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/algorithms/deliverResizeLoopError.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$broadcastActiveObservations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/algorithms/broadcastActiveObservations.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$gatherActiveObservationsAtDepth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/algorithms/gatherActiveObservationsAtDepth.js [app-client] (ecmascript)");
;
;
;
;
;
var process = function() {
    var depth = 0;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$gatherActiveObservationsAtDepth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gatherActiveObservationsAtDepth"])(depth);
    while((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$hasActiveObservations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasActiveObservations"])()){
        depth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$broadcastActiveObservations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["broadcastActiveObservations"])();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$gatherActiveObservationsAtDepth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gatherActiveObservationsAtDepth"])(depth);
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$hasSkippedObservations$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasSkippedObservations"])()) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$deliverResizeLoopError$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deliverResizeLoopError"])();
    }
    return depth > 0;
};
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/utils/queueMicroTask.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "queueMicroTask",
    ()=>queueMicroTask
]);
var trigger;
var callbacks = [];
var notify = function() {
    return callbacks.splice(0).forEach(function(cb) {
        return cb();
    });
};
var queueMicroTask = function(callback) {
    if (!trigger) {
        var toggle_1 = 0;
        var el_1 = document.createTextNode('');
        var config = {
            characterData: true
        };
        new MutationObserver(function() {
            return notify();
        }).observe(el_1, config);
        trigger = function() {
            el_1.textContent = "".concat(toggle_1 ? toggle_1-- : toggle_1++);
        };
    }
    callbacks.push(callback);
    trigger();
};
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/utils/queueResizeObserver.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "queueResizeObserver",
    ()=>queueResizeObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$queueMicroTask$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/queueMicroTask.js [app-client] (ecmascript)");
;
var queueResizeObserver = function(cb) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$queueMicroTask$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queueMicroTask"])(function ResizeObserver() {
        requestAnimationFrame(cb);
    });
};
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/utils/scheduler.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "scheduler",
    ()=>scheduler,
    "updateCount",
    ()=>updateCount
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$global$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/global.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$queueResizeObserver$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/queueResizeObserver.js [app-client] (ecmascript)");
;
;
;
var watching = 0;
var isWatching = function() {
    return !!watching;
};
var CATCH_PERIOD = 250;
var observerConfig = {
    attributes: true,
    characterData: true,
    childList: true,
    subtree: true
};
var events = [
    'resize',
    'load',
    'transitionend',
    'animationend',
    'animationstart',
    'animationiteration',
    'keyup',
    'keydown',
    'mouseup',
    'mousedown',
    'mouseover',
    'mouseout',
    'blur',
    'focus'
];
var time = function(timeout) {
    if (timeout === void 0) {
        timeout = 0;
    }
    return Date.now() + timeout;
};
var scheduled = false;
var Scheduler = function() {
    function Scheduler() {
        var _this = this;
        this.stopped = true;
        this.listener = function() {
            return _this.schedule();
        };
    }
    Scheduler.prototype.run = function(timeout) {
        var _this = this;
        if (timeout === void 0) {
            timeout = CATCH_PERIOD;
        }
        if (scheduled) {
            return;
        }
        scheduled = true;
        var until = time(timeout);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$queueResizeObserver$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["queueResizeObserver"])(function() {
            var elementsHaveResized = false;
            try {
                elementsHaveResized = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["process"])();
            } finally{
                scheduled = false;
                timeout = until - time();
                if (!isWatching()) {
                    return;
                }
                if (elementsHaveResized) {
                    _this.run(1000);
                } else if (timeout > 0) {
                    _this.run(timeout);
                } else {
                    _this.start();
                }
            }
        });
    };
    Scheduler.prototype.schedule = function() {
        this.stop();
        this.run();
    };
    Scheduler.prototype.observe = function() {
        var _this = this;
        var cb = function() {
            return _this.observer && _this.observer.observe(document.body, observerConfig);
        };
        document.body ? cb() : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$global$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["global"].addEventListener('DOMContentLoaded', cb);
    };
    Scheduler.prototype.start = function() {
        var _this = this;
        if (this.stopped) {
            this.stopped = false;
            this.observer = new MutationObserver(this.listener);
            this.observe();
            events.forEach(function(name) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$global$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["global"].addEventListener(name, _this.listener, true);
            });
        }
    };
    Scheduler.prototype.stop = function() {
        var _this = this;
        if (!this.stopped) {
            this.observer && this.observer.disconnect();
            events.forEach(function(name) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$global$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["global"].removeEventListener(name, _this.listener, true);
            });
            this.stopped = true;
        }
    };
    return Scheduler;
}();
var scheduler = new Scheduler();
var updateCount = function(n) {
    !watching && n > 0 && scheduler.start();
    watching += n;
    !watching && scheduler.stop();
};
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/ResizeObservation.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ResizeObservation",
    ()=>ResizeObservation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverBoxOptions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/ResizeObserverBoxOptions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$calculateBoxSize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/algorithms/calculateBoxSize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/element.js [app-client] (ecmascript)");
;
;
;
var skipNotifyOnElement = function(target) {
    return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSVG"])(target) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isReplacedElement"])(target) && getComputedStyle(target).display === 'inline';
};
var ResizeObservation = function() {
    function ResizeObservation(target, observedBox) {
        this.target = target;
        this.observedBox = observedBox || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverBoxOptions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResizeObserverBoxOptions"].CONTENT_BOX;
        this.lastReportedSize = {
            inlineSize: 0,
            blockSize: 0
        };
    }
    ResizeObservation.prototype.isActive = function() {
        var size = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$algorithms$2f$calculateBoxSize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["calculateBoxSize"])(this.target, this.observedBox, true);
        if (skipNotifyOnElement(this.target)) {
            this.lastReportedSize = size;
        }
        if (this.lastReportedSize.inlineSize !== size.inlineSize || this.lastReportedSize.blockSize !== size.blockSize) {
            return true;
        }
        return false;
    };
    return ResizeObservation;
}();
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/ResizeObserverDetail.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ResizeObserverDetail",
    ()=>ResizeObserverDetail
]);
var ResizeObserverDetail = function() {
    function ResizeObserverDetail(resizeObserver, callback) {
        this.activeTargets = [];
        this.skippedTargets = [];
        this.observationTargets = [];
        this.observer = resizeObserver;
        this.callback = callback;
    }
    return ResizeObserverDetail;
}();
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/ResizeObserverController.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ResizeObserverController",
    ()=>ResizeObserverController
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$scheduler$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/scheduler.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObservation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/ResizeObservation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverDetail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/ResizeObserverDetail.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$resizeObservers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/resizeObservers.js [app-client] (ecmascript)");
;
;
;
;
var observerMap = new WeakMap();
var getObservationIndex = function(observationTargets, target) {
    for(var i = 0; i < observationTargets.length; i += 1){
        if (observationTargets[i].target === target) {
            return i;
        }
    }
    return -1;
};
var ResizeObserverController = function() {
    function ResizeObserverController() {}
    ResizeObserverController.connect = function(resizeObserver, callback) {
        var detail = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverDetail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResizeObserverDetail"](resizeObserver, callback);
        observerMap.set(resizeObserver, detail);
    };
    ResizeObserverController.observe = function(resizeObserver, target, options) {
        var detail = observerMap.get(resizeObserver);
        var firstObservation = detail.observationTargets.length === 0;
        if (getObservationIndex(detail.observationTargets, target) < 0) {
            firstObservation && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$resizeObservers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resizeObservers"].push(detail);
            detail.observationTargets.push(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObservation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResizeObservation"](target, options && options.box));
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$scheduler$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateCount"])(1);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$scheduler$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["scheduler"].schedule();
        }
    };
    ResizeObserverController.unobserve = function(resizeObserver, target) {
        var detail = observerMap.get(resizeObserver);
        var index = getObservationIndex(detail.observationTargets, target);
        var lastObservation = detail.observationTargets.length === 1;
        if (index >= 0) {
            lastObservation && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$resizeObservers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resizeObservers"].splice(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$resizeObservers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resizeObservers"].indexOf(detail), 1);
            detail.observationTargets.splice(index, 1);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$scheduler$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateCount"])(-1);
        }
    };
    ResizeObserverController.disconnect = function(resizeObserver) {
        var _this = this;
        var detail = observerMap.get(resizeObserver);
        detail.observationTargets.slice().forEach(function(ot) {
            return _this.unobserve(resizeObserver, ot.target);
        });
        detail.activeTargets.splice(0, detail.activeTargets.length);
    };
    return ResizeObserverController;
}();
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/ResizeObserver.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ResizeObserver",
    ()=>ResizeObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverController$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/ResizeObserverController.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/utils/element.js [app-client] (ecmascript)");
;
;
var ResizeObserver = function() {
    function ResizeObserver(callback) {
        if (arguments.length === 0) {
            throw new TypeError("Failed to construct 'ResizeObserver': 1 argument required, but only 0 present.");
        }
        if (typeof callback !== 'function') {
            throw new TypeError("Failed to construct 'ResizeObserver': The callback provided as parameter 1 is not a function.");
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverController$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResizeObserverController"].connect(this, callback);
    }
    ResizeObserver.prototype.observe = function(target, options) {
        if (arguments.length === 0) {
            throw new TypeError("Failed to execute 'observe' on 'ResizeObserver': 1 argument required, but only 0 present.");
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(target)) {
            throw new TypeError("Failed to execute 'observe' on 'ResizeObserver': parameter 1 is not of type 'Element");
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverController$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResizeObserverController"].observe(this, target, options);
    };
    ResizeObserver.prototype.unobserve = function(target) {
        if (arguments.length === 0) {
            throw new TypeError("Failed to execute 'unobserve' on 'ResizeObserver': 1 argument required, but only 0 present.");
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$utils$2f$element$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(target)) {
            throw new TypeError("Failed to execute 'unobserve' on 'ResizeObserver': parameter 1 is not of type 'Element");
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverController$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResizeObserverController"].unobserve(this, target);
    };
    ResizeObserver.prototype.disconnect = function() {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverController$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResizeObserverController"].disconnect(this);
    };
    ResizeObserver.toString = function() {
        return 'function ResizeObserver () { [polyfill code] }';
    };
    return ResizeObserver;
}();
;
}),
"[project]/node_modules/@juggle/resize-observer/lib/exports/resize-observer.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserver$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/ResizeObserver.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverEntry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/ResizeObserverEntry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserverSize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/ResizeObserverSize.js [app-client] (ecmascript)");
;
;
;
}),
"[project]/node_modules/use-effect-event/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useEffectEvent",
    ()=>useEffectEvent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext(!0);
function forbiddenInRender() {
    throw new Error("A function wrapped in useEffectEvent can't be called during rendering.");
}
const isInvalidExecutionContextForEventFunction = "use" in __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] ? ()=>{
    try {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].use(context);
    } catch  {
        return !1;
    }
} : ()=>!1;
function useEffectEvent(fn) {
    const ref = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useRef(forbiddenInRender);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useInsertionEffect({
        "useEffectEvent.useInsertionEffect": ()=>{
            ref.current = fn;
        }
    }["useEffectEvent.useInsertionEffect"], [
        fn
    ]), (...args)=>{
        isInvalidExecutionContextForEventFunction() && forbiddenInRender();
        const latestFn = ref.current;
        return latestFn(...args);
    };
}
;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isObject.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */ function isObject(value) {
    var type = typeof value;
    return value != null && (type == 'object' || type == 'function');
}
module.exports = isObject;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_freeGlobal.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/** Detect free variable `global` from Node.js. */ var freeGlobal = ("TURBOPACK compile-time value", "object") == 'object' && /*TURBOPACK member replacement*/ __turbopack_context__.g && /*TURBOPACK member replacement*/ __turbopack_context__.g.Object === Object && /*TURBOPACK member replacement*/ __turbopack_context__.g;
module.exports = freeGlobal;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_root.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var freeGlobal = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_freeGlobal.js [app-client] (ecmascript)");
/** Detect free variable `self`. */ var freeSelf = typeof self == 'object' && self && self.Object === Object && self;
/** Used as a reference to the global object. */ var root = freeGlobal || freeSelf || Function('return this')();
module.exports = root;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Symbol.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var root = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_root.js [app-client] (ecmascript)");
/** Built-in value references. */ var Symbol = root.Symbol;
module.exports = Symbol;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getRawTag.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var Symbol = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Symbol.js [app-client] (ecmascript)");
/** Used for built-in method references. */ var objectProto = Object.prototype;
/** Used to check objects for own properties. */ var hasOwnProperty = objectProto.hasOwnProperty;
/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */ var nativeObjectToString = objectProto.toString;
/** Built-in value references. */ var symToStringTag = Symbol ? Symbol.toStringTag : undefined;
/**
 * A specialized version of `baseGetTag` which ignores `Symbol.toStringTag` values.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the raw `toStringTag`.
 */ function getRawTag(value) {
    var isOwn = hasOwnProperty.call(value, symToStringTag), tag = value[symToStringTag];
    try {
        value[symToStringTag] = undefined;
        var unmasked = true;
    } catch (e) {}
    var result = nativeObjectToString.call(value);
    if (unmasked) {
        if (isOwn) {
            value[symToStringTag] = tag;
        } else {
            delete value[symToStringTag];
        }
    }
    return result;
}
module.exports = getRawTag;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_objectToString.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/** Used for built-in method references. */ var objectProto = Object.prototype;
/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */ var nativeObjectToString = objectProto.toString;
/**
 * Converts `value` to a string using `Object.prototype.toString`.
 *
 * @private
 * @param {*} value The value to convert.
 * @returns {string} Returns the converted string.
 */ function objectToString(value) {
    return nativeObjectToString.call(value);
}
module.exports = objectToString;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseGetTag.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var Symbol = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Symbol.js [app-client] (ecmascript)"), getRawTag = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getRawTag.js [app-client] (ecmascript)"), objectToString = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_objectToString.js [app-client] (ecmascript)");
/** `Object#toString` result references. */ var nullTag = '[object Null]', undefinedTag = '[object Undefined]';
/** Built-in value references. */ var symToStringTag = Symbol ? Symbol.toStringTag : undefined;
/**
 * The base implementation of `getTag` without fallbacks for buggy environments.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the `toStringTag`.
 */ function baseGetTag(value) {
    if (value == null) {
        return value === undefined ? undefinedTag : nullTag;
    }
    return symToStringTag && symToStringTag in Object(value) ? getRawTag(value) : objectToString(value);
}
module.exports = baseGetTag;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isFunction.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseGetTag = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseGetTag.js [app-client] (ecmascript)"), isObject = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isObject.js [app-client] (ecmascript)");
/** `Object#toString` result references. */ var asyncTag = '[object AsyncFunction]', funcTag = '[object Function]', genTag = '[object GeneratorFunction]', proxyTag = '[object Proxy]';
/**
 * Checks if `value` is classified as a `Function` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a function, else `false`.
 * @example
 *
 * _.isFunction(_);
 * // => true
 *
 * _.isFunction(/abc/);
 * // => false
 */ function isFunction(value) {
    if (!isObject(value)) {
        return false;
    }
    // The use of `Object#toString` avoids issues with the `typeof` operator
    // in Safari 9 which returns 'object' for typed arrays and other constructors.
    var tag = baseGetTag(value);
    return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
}
module.exports = isFunction;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_coreJsData.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var root = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_root.js [app-client] (ecmascript)");
/** Used to detect overreaching core-js shims. */ var coreJsData = root['__core-js_shared__'];
module.exports = coreJsData;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isMasked.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var coreJsData = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_coreJsData.js [app-client] (ecmascript)");
/** Used to detect methods masquerading as native. */ var maskSrcKey = function() {
    var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || '');
    return uid ? 'Symbol(src)_1.' + uid : '';
}();
/**
 * Checks if `func` has its source masked.
 *
 * @private
 * @param {Function} func The function to check.
 * @returns {boolean} Returns `true` if `func` is masked, else `false`.
 */ function isMasked(func) {
    return !!maskSrcKey && maskSrcKey in func;
}
module.exports = isMasked;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_toSource.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/** Used for built-in method references. */ var funcProto = Function.prototype;
/** Used to resolve the decompiled source of functions. */ var funcToString = funcProto.toString;
/**
 * Converts `func` to its source code.
 *
 * @private
 * @param {Function} func The function to convert.
 * @returns {string} Returns the source code.
 */ function toSource(func) {
    if (func != null) {
        try {
            return funcToString.call(func);
        } catch (e) {}
        try {
            return func + '';
        } catch (e) {}
    }
    return '';
}
module.exports = toSource;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIsNative.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var isFunction = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isFunction.js [app-client] (ecmascript)"), isMasked = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isMasked.js [app-client] (ecmascript)"), isObject = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isObject.js [app-client] (ecmascript)"), toSource = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_toSource.js [app-client] (ecmascript)");
/**
 * Used to match `RegExp`
 * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
 */ var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
/** Used to detect host constructors (Safari). */ var reIsHostCtor = /^\[object .+?Constructor\]$/;
/** Used for built-in method references. */ var funcProto = Function.prototype, objectProto = Object.prototype;
/** Used to resolve the decompiled source of functions. */ var funcToString = funcProto.toString;
/** Used to check objects for own properties. */ var hasOwnProperty = objectProto.hasOwnProperty;
/** Used to detect if a method is native. */ var reIsNative = RegExp('^' + funcToString.call(hasOwnProperty).replace(reRegExpChar, '\\$&').replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$');
/**
 * The base implementation of `_.isNative` without bad shim checks.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a native function,
 *  else `false`.
 */ function baseIsNative(value) {
    if (!isObject(value) || isMasked(value)) {
        return false;
    }
    var pattern = isFunction(value) ? reIsNative : reIsHostCtor;
    return pattern.test(toSource(value));
}
module.exports = baseIsNative;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getValue.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Gets the value at `key` of `object`.
 *
 * @private
 * @param {Object} [object] The object to query.
 * @param {string} key The key of the property to get.
 * @returns {*} Returns the property value.
 */ function getValue(object, key) {
    return object == null ? undefined : object[key];
}
module.exports = getValue;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getNative.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseIsNative = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIsNative.js [app-client] (ecmascript)"), getValue = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getValue.js [app-client] (ecmascript)");
/**
 * Gets the native function at `key` of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {string} key The key of the method to get.
 * @returns {*} Returns the function if it's native, else `undefined`.
 */ function getNative(object, key) {
    var value = getValue(object, key);
    return baseIsNative(value) ? value : undefined;
}
module.exports = getNative;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_defineProperty.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var getNative = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getNative.js [app-client] (ecmascript)");
var defineProperty = function() {
    try {
        var func = getNative(Object, 'defineProperty');
        func({}, '', {});
        return func;
    } catch (e) {}
}();
module.exports = defineProperty;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseAssignValue.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var defineProperty = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_defineProperty.js [app-client] (ecmascript)");
/**
 * The base implementation of `assignValue` and `assignMergeValue` without
 * value checks.
 *
 * @private
 * @param {Object} object The object to modify.
 * @param {string} key The key of the property to assign.
 * @param {*} value The value to assign.
 */ function baseAssignValue(object, key, value) {
    if (key == '__proto__' && defineProperty) {
        defineProperty(object, key, {
            'configurable': true,
            'enumerable': true,
            'value': value,
            'writable': true
        });
    } else {
        object[key] = value;
    }
}
module.exports = baseAssignValue;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_arrayAggregator.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * A specialized version of `baseAggregator` for arrays.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} setter The function to set `accumulator` values.
 * @param {Function} iteratee The iteratee to transform keys.
 * @param {Object} accumulator The initial aggregated object.
 * @returns {Function} Returns `accumulator`.
 */ function arrayAggregator(array, setter, iteratee, accumulator) {
    var index = -1, length = array == null ? 0 : array.length;
    while(++index < length){
        var value = array[index];
        setter(accumulator, value, iteratee(value), array);
    }
    return accumulator;
}
module.exports = arrayAggregator;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_createBaseFor.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Creates a base function for methods like `_.forIn` and `_.forOwn`.
 *
 * @private
 * @param {boolean} [fromRight] Specify iterating from right to left.
 * @returns {Function} Returns the new base function.
 */ function createBaseFor(fromRight) {
    return function(object, iteratee, keysFunc) {
        var index = -1, iterable = Object(object), props = keysFunc(object), length = props.length;
        while(length--){
            var key = props[fromRight ? length : ++index];
            if (iteratee(iterable[key], key, iterable) === false) {
                break;
            }
        }
        return object;
    };
}
module.exports = createBaseFor;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseFor.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var createBaseFor = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_createBaseFor.js [app-client] (ecmascript)");
/**
 * The base implementation of `baseForOwn` which iterates over `object`
 * properties returned by `keysFunc` and invokes `iteratee` for each property.
 * Iteratee functions may exit iteration early by explicitly returning `false`.
 *
 * @private
 * @param {Object} object The object to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @param {Function} keysFunc The function to get the keys of `object`.
 * @returns {Object} Returns `object`.
 */ var baseFor = createBaseFor();
module.exports = baseFor;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseTimes.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * The base implementation of `_.times` without support for iteratee shorthands
 * or max array length checks.
 *
 * @private
 * @param {number} n The number of times to invoke `iteratee`.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns the array of results.
 */ function baseTimes(n, iteratee) {
    var index = -1, result = Array(n);
    while(++index < n){
        result[index] = iteratee(index);
    }
    return result;
}
module.exports = baseTimes;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isObjectLike.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */ function isObjectLike(value) {
    return value != null && typeof value == 'object';
}
module.exports = isObjectLike;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIsArguments.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseGetTag = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseGetTag.js [app-client] (ecmascript)"), isObjectLike = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isObjectLike.js [app-client] (ecmascript)");
/** `Object#toString` result references. */ var argsTag = '[object Arguments]';
/**
 * The base implementation of `_.isArguments`.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an `arguments` object,
 */ function baseIsArguments(value) {
    return isObjectLike(value) && baseGetTag(value) == argsTag;
}
module.exports = baseIsArguments;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArguments.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseIsArguments = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIsArguments.js [app-client] (ecmascript)"), isObjectLike = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isObjectLike.js [app-client] (ecmascript)");
/** Used for built-in method references. */ var objectProto = Object.prototype;
/** Used to check objects for own properties. */ var hasOwnProperty = objectProto.hasOwnProperty;
/** Built-in value references. */ var propertyIsEnumerable = objectProto.propertyIsEnumerable;
/**
 * Checks if `value` is likely an `arguments` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an `arguments` object,
 *  else `false`.
 * @example
 *
 * _.isArguments(function() { return arguments; }());
 * // => true
 *
 * _.isArguments([1, 2, 3]);
 * // => false
 */ var isArguments = baseIsArguments(function() {
    return arguments;
}()) ? baseIsArguments : function(value) {
    return isObjectLike(value) && hasOwnProperty.call(value, 'callee') && !propertyIsEnumerable.call(value, 'callee');
};
module.exports = isArguments;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArray.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Checks if `value` is classified as an `Array` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array, else `false`.
 * @example
 *
 * _.isArray([1, 2, 3]);
 * // => true
 *
 * _.isArray(document.body.children);
 * // => false
 *
 * _.isArray('abc');
 * // => false
 *
 * _.isArray(_.noop);
 * // => false
 */ var isArray = Array.isArray;
module.exports = isArray;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/stubFalse.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * This method returns `false`.
 *
 * @static
 * @memberOf _
 * @since 4.13.0
 * @category Util
 * @returns {boolean} Returns `false`.
 * @example
 *
 * _.times(2, _.stubFalse);
 * // => [false, false]
 */ function stubFalse() {
    return false;
}
module.exports = stubFalse;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isBuffer.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var root = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_root.js [app-client] (ecmascript)"), stubFalse = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/stubFalse.js [app-client] (ecmascript)");
/** Detect free variable `exports`. */ var freeExports = ("TURBOPACK compile-time value", "object") == 'object' && exports && !exports.nodeType && exports;
/** Detect free variable `module`. */ var freeModule = freeExports && ("TURBOPACK compile-time value", "object") == 'object' && module && !module.nodeType && module;
/** Detect the popular CommonJS extension `module.exports`. */ var moduleExports = freeModule && freeModule.exports === freeExports;
/** Built-in value references. */ var Buffer = moduleExports ? root.Buffer : undefined;
/* Built-in method references for those with the same name as other `lodash` methods. */ var nativeIsBuffer = Buffer ? Buffer.isBuffer : undefined;
/**
 * Checks if `value` is a buffer.
 *
 * @static
 * @memberOf _
 * @since 4.3.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a buffer, else `false`.
 * @example
 *
 * _.isBuffer(new Buffer(2));
 * // => true
 *
 * _.isBuffer(new Uint8Array(2));
 * // => false
 */ var isBuffer = nativeIsBuffer || stubFalse;
module.exports = isBuffer;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isIndex.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/** Used as references for various `Number` constants. */ var MAX_SAFE_INTEGER = 9007199254740991;
/** Used to detect unsigned integer values. */ var reIsUint = /^(?:0|[1-9]\d*)$/;
/**
 * Checks if `value` is a valid array-like index.
 *
 * @private
 * @param {*} value The value to check.
 * @param {number} [length=MAX_SAFE_INTEGER] The upper bounds of a valid index.
 * @returns {boolean} Returns `true` if `value` is a valid index, else `false`.
 */ function isIndex(value, length) {
    var type = typeof value;
    length = length == null ? MAX_SAFE_INTEGER : length;
    return !!length && (type == 'number' || type != 'symbol' && reIsUint.test(value)) && value > -1 && value % 1 == 0 && value < length;
}
module.exports = isIndex;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isLength.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/** Used as references for various `Number` constants. */ var MAX_SAFE_INTEGER = 9007199254740991;
/**
 * Checks if `value` is a valid array-like length.
 *
 * **Note:** This method is loosely based on
 * [`ToLength`](http://ecma-international.org/ecma-262/7.0/#sec-tolength).
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a valid length, else `false`.
 * @example
 *
 * _.isLength(3);
 * // => true
 *
 * _.isLength(Number.MIN_VALUE);
 * // => false
 *
 * _.isLength(Infinity);
 * // => false
 *
 * _.isLength('3');
 * // => false
 */ function isLength(value) {
    return typeof value == 'number' && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
}
module.exports = isLength;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIsTypedArray.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseGetTag = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseGetTag.js [app-client] (ecmascript)"), isLength = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isLength.js [app-client] (ecmascript)"), isObjectLike = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isObjectLike.js [app-client] (ecmascript)");
/** `Object#toString` result references. */ var argsTag = '[object Arguments]', arrayTag = '[object Array]', boolTag = '[object Boolean]', dateTag = '[object Date]', errorTag = '[object Error]', funcTag = '[object Function]', mapTag = '[object Map]', numberTag = '[object Number]', objectTag = '[object Object]', regexpTag = '[object RegExp]', setTag = '[object Set]', stringTag = '[object String]', weakMapTag = '[object WeakMap]';
var arrayBufferTag = '[object ArrayBuffer]', dataViewTag = '[object DataView]', float32Tag = '[object Float32Array]', float64Tag = '[object Float64Array]', int8Tag = '[object Int8Array]', int16Tag = '[object Int16Array]', int32Tag = '[object Int32Array]', uint8Tag = '[object Uint8Array]', uint8ClampedTag = '[object Uint8ClampedArray]', uint16Tag = '[object Uint16Array]', uint32Tag = '[object Uint32Array]';
/** Used to identify `toStringTag` values of typed arrays. */ var typedArrayTags = {};
typedArrayTags[float32Tag] = typedArrayTags[float64Tag] = typedArrayTags[int8Tag] = typedArrayTags[int16Tag] = typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] = typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] = typedArrayTags[uint32Tag] = true;
typedArrayTags[argsTag] = typedArrayTags[arrayTag] = typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] = typedArrayTags[dataViewTag] = typedArrayTags[dateTag] = typedArrayTags[errorTag] = typedArrayTags[funcTag] = typedArrayTags[mapTag] = typedArrayTags[numberTag] = typedArrayTags[objectTag] = typedArrayTags[regexpTag] = typedArrayTags[setTag] = typedArrayTags[stringTag] = typedArrayTags[weakMapTag] = false;
/**
 * The base implementation of `_.isTypedArray` without Node.js optimizations.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
 */ function baseIsTypedArray(value) {
    return isObjectLike(value) && isLength(value.length) && !!typedArrayTags[baseGetTag(value)];
}
module.exports = baseIsTypedArray;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseUnary.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * The base implementation of `_.unary` without support for storing metadata.
 *
 * @private
 * @param {Function} func The function to cap arguments for.
 * @returns {Function} Returns the new capped function.
 */ function baseUnary(func) {
    return function(value) {
        return func(value);
    };
}
module.exports = baseUnary;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_nodeUtil.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var freeGlobal = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_freeGlobal.js [app-client] (ecmascript)");
/** Detect free variable `exports`. */ var freeExports = ("TURBOPACK compile-time value", "object") == 'object' && exports && !exports.nodeType && exports;
/** Detect free variable `module`. */ var freeModule = freeExports && ("TURBOPACK compile-time value", "object") == 'object' && module && !module.nodeType && module;
/** Detect the popular CommonJS extension `module.exports`. */ var moduleExports = freeModule && freeModule.exports === freeExports;
/** Detect free variable `process` from Node.js. */ var freeProcess = moduleExports && freeGlobal.process;
/** Used to access faster Node.js helpers. */ var nodeUtil = function() {
    try {
        // Use `util.types` for Node.js 10+.
        var types = freeModule && freeModule.require && freeModule.require('util').types;
        if (types) {
            return types;
        }
        // Legacy `process.binding('util')` for Node.js < 10.
        return freeProcess && freeProcess.binding && freeProcess.binding('util');
    } catch (e) {}
}();
module.exports = nodeUtil;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isTypedArray.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseIsTypedArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIsTypedArray.js [app-client] (ecmascript)"), baseUnary = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseUnary.js [app-client] (ecmascript)"), nodeUtil = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_nodeUtil.js [app-client] (ecmascript)");
/* Node.js helper references. */ var nodeIsTypedArray = nodeUtil && nodeUtil.isTypedArray;
/**
 * Checks if `value` is classified as a typed array.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
 * @example
 *
 * _.isTypedArray(new Uint8Array);
 * // => true
 *
 * _.isTypedArray([]);
 * // => false
 */ var isTypedArray = nodeIsTypedArray ? baseUnary(nodeIsTypedArray) : baseIsTypedArray;
module.exports = isTypedArray;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_arrayLikeKeys.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseTimes = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseTimes.js [app-client] (ecmascript)"), isArguments = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArguments.js [app-client] (ecmascript)"), isArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArray.js [app-client] (ecmascript)"), isBuffer = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isBuffer.js [app-client] (ecmascript)"), isIndex = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isIndex.js [app-client] (ecmascript)"), isTypedArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isTypedArray.js [app-client] (ecmascript)");
/** Used for built-in method references. */ var objectProto = Object.prototype;
/** Used to check objects for own properties. */ var hasOwnProperty = objectProto.hasOwnProperty;
/**
 * Creates an array of the enumerable property names of the array-like `value`.
 *
 * @private
 * @param {*} value The value to query.
 * @param {boolean} inherited Specify returning inherited property names.
 * @returns {Array} Returns the array of property names.
 */ function arrayLikeKeys(value, inherited) {
    var isArr = isArray(value), isArg = !isArr && isArguments(value), isBuff = !isArr && !isArg && isBuffer(value), isType = !isArr && !isArg && !isBuff && isTypedArray(value), skipIndexes = isArr || isArg || isBuff || isType, result = skipIndexes ? baseTimes(value.length, String) : [], length = result.length;
    for(var key in value){
        if ((inherited || hasOwnProperty.call(value, key)) && !(skipIndexes && (// Safari 9 has enumerable `arguments.length` in strict mode.
        key == 'length' || isBuff && (key == 'offset' || key == 'parent') || isType && (key == 'buffer' || key == 'byteLength' || key == 'byteOffset') || // Skip index properties.
        isIndex(key, length)))) {
            result.push(key);
        }
    }
    return result;
}
module.exports = arrayLikeKeys;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isPrototype.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/** Used for built-in method references. */ var objectProto = Object.prototype;
/**
 * Checks if `value` is likely a prototype object.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a prototype, else `false`.
 */ function isPrototype(value) {
    var Ctor = value && value.constructor, proto = typeof Ctor == 'function' && Ctor.prototype || objectProto;
    return value === proto;
}
module.exports = isPrototype;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_overArg.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Creates a unary function that invokes `func` with its argument transformed.
 *
 * @private
 * @param {Function} func The function to wrap.
 * @param {Function} transform The argument transform.
 * @returns {Function} Returns the new function.
 */ function overArg(func, transform) {
    return function(arg) {
        return func(transform(arg));
    };
}
module.exports = overArg;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_nativeKeys.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var overArg = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_overArg.js [app-client] (ecmascript)");
/* Built-in method references for those with the same name as other `lodash` methods. */ var nativeKeys = overArg(Object.keys, Object);
module.exports = nativeKeys;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseKeys.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var isPrototype = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isPrototype.js [app-client] (ecmascript)"), nativeKeys = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_nativeKeys.js [app-client] (ecmascript)");
/** Used for built-in method references. */ var objectProto = Object.prototype;
/** Used to check objects for own properties. */ var hasOwnProperty = objectProto.hasOwnProperty;
/**
 * The base implementation of `_.keys` which doesn't treat sparse arrays as dense.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 */ function baseKeys(object) {
    if (!isPrototype(object)) {
        return nativeKeys(object);
    }
    var result = [];
    for(var key in Object(object)){
        if (hasOwnProperty.call(object, key) && key != 'constructor') {
            result.push(key);
        }
    }
    return result;
}
module.exports = baseKeys;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArrayLike.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var isFunction = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isFunction.js [app-client] (ecmascript)"), isLength = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isLength.js [app-client] (ecmascript)");
/**
 * Checks if `value` is array-like. A value is considered array-like if it's
 * not a function and has a `value.length` that's an integer greater than or
 * equal to `0` and less than or equal to `Number.MAX_SAFE_INTEGER`.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is array-like, else `false`.
 * @example
 *
 * _.isArrayLike([1, 2, 3]);
 * // => true
 *
 * _.isArrayLike(document.body.children);
 * // => true
 *
 * _.isArrayLike('abc');
 * // => true
 *
 * _.isArrayLike(_.noop);
 * // => false
 */ function isArrayLike(value) {
    return value != null && isLength(value.length) && !isFunction(value);
}
module.exports = isArrayLike;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/keys.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var arrayLikeKeys = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_arrayLikeKeys.js [app-client] (ecmascript)"), baseKeys = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseKeys.js [app-client] (ecmascript)"), isArrayLike = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArrayLike.js [app-client] (ecmascript)");
/**
 * Creates an array of the own enumerable property names of `object`.
 *
 * **Note:** Non-object values are coerced to objects. See the
 * [ES spec](http://ecma-international.org/ecma-262/7.0/#sec-object.keys)
 * for more details.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Object
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names.
 * @example
 *
 * function Foo() {
 *   this.a = 1;
 *   this.b = 2;
 * }
 *
 * Foo.prototype.c = 3;
 *
 * _.keys(new Foo);
 * // => ['a', 'b'] (iteration order is not guaranteed)
 *
 * _.keys('hi');
 * // => ['0', '1']
 */ function keys(object) {
    return isArrayLike(object) ? arrayLikeKeys(object) : baseKeys(object);
}
module.exports = keys;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseForOwn.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseFor = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseFor.js [app-client] (ecmascript)"), keys = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/keys.js [app-client] (ecmascript)");
/**
 * The base implementation of `_.forOwn` without support for iteratee shorthands.
 *
 * @private
 * @param {Object} object The object to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Object} Returns `object`.
 */ function baseForOwn(object, iteratee) {
    return object && baseFor(object, iteratee, keys);
}
module.exports = baseForOwn;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_createBaseEach.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var isArrayLike = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArrayLike.js [app-client] (ecmascript)");
/**
 * Creates a `baseEach` or `baseEachRight` function.
 *
 * @private
 * @param {Function} eachFunc The function to iterate over a collection.
 * @param {boolean} [fromRight] Specify iterating from right to left.
 * @returns {Function} Returns the new base function.
 */ function createBaseEach(eachFunc, fromRight) {
    return function(collection, iteratee) {
        if (collection == null) {
            return collection;
        }
        if (!isArrayLike(collection)) {
            return eachFunc(collection, iteratee);
        }
        var length = collection.length, index = fromRight ? length : -1, iterable = Object(collection);
        while(fromRight ? index-- : ++index < length){
            if (iteratee(iterable[index], index, iterable) === false) {
                break;
            }
        }
        return collection;
    };
}
module.exports = createBaseEach;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseEach.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseForOwn = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseForOwn.js [app-client] (ecmascript)"), createBaseEach = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_createBaseEach.js [app-client] (ecmascript)");
/**
 * The base implementation of `_.forEach` without support for iteratee shorthands.
 *
 * @private
 * @param {Array|Object} collection The collection to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array|Object} Returns `collection`.
 */ var baseEach = createBaseEach(baseForOwn);
module.exports = baseEach;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseAggregator.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseEach = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseEach.js [app-client] (ecmascript)");
/**
 * Aggregates elements of `collection` on `accumulator` with keys transformed
 * by `iteratee` and values set by `setter`.
 *
 * @private
 * @param {Array|Object} collection The collection to iterate over.
 * @param {Function} setter The function to set `accumulator` values.
 * @param {Function} iteratee The iteratee to transform keys.
 * @param {Object} accumulator The initial aggregated object.
 * @returns {Function} Returns `accumulator`.
 */ function baseAggregator(collection, setter, iteratee, accumulator) {
    baseEach(collection, function(value, key, collection) {
        setter(accumulator, value, iteratee(value), collection);
    });
    return accumulator;
}
module.exports = baseAggregator;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_listCacheClear.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Removes all key-value entries from the list cache.
 *
 * @private
 * @name clear
 * @memberOf ListCache
 */ function listCacheClear() {
    this.__data__ = [];
    this.size = 0;
}
module.exports = listCacheClear;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/eq.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Performs a
 * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
 * comparison between two values to determine if they are equivalent.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 * @example
 *
 * var object = { 'a': 1 };
 * var other = { 'a': 1 };
 *
 * _.eq(object, object);
 * // => true
 *
 * _.eq(object, other);
 * // => false
 *
 * _.eq('a', 'a');
 * // => true
 *
 * _.eq('a', Object('a'));
 * // => false
 *
 * _.eq(NaN, NaN);
 * // => true
 */ function eq(value, other) {
    return value === other || value !== value && other !== other;
}
module.exports = eq;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_assocIndexOf.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var eq = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/eq.js [app-client] (ecmascript)");
/**
 * Gets the index at which the `key` is found in `array` of key-value pairs.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} key The key to search for.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */ function assocIndexOf(array, key) {
    var length = array.length;
    while(length--){
        if (eq(array[length][0], key)) {
            return length;
        }
    }
    return -1;
}
module.exports = assocIndexOf;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_listCacheDelete.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var assocIndexOf = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_assocIndexOf.js [app-client] (ecmascript)");
/** Used for built-in method references. */ var arrayProto = Array.prototype;
/** Built-in value references. */ var splice = arrayProto.splice;
/**
 * Removes `key` and its value from the list cache.
 *
 * @private
 * @name delete
 * @memberOf ListCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */ function listCacheDelete(key) {
    var data = this.__data__, index = assocIndexOf(data, key);
    if (index < 0) {
        return false;
    }
    var lastIndex = data.length - 1;
    if (index == lastIndex) {
        data.pop();
    } else {
        splice.call(data, index, 1);
    }
    --this.size;
    return true;
}
module.exports = listCacheDelete;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_listCacheGet.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var assocIndexOf = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_assocIndexOf.js [app-client] (ecmascript)");
/**
 * Gets the list cache value for `key`.
 *
 * @private
 * @name get
 * @memberOf ListCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */ function listCacheGet(key) {
    var data = this.__data__, index = assocIndexOf(data, key);
    return index < 0 ? undefined : data[index][1];
}
module.exports = listCacheGet;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_listCacheHas.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var assocIndexOf = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_assocIndexOf.js [app-client] (ecmascript)");
/**
 * Checks if a list cache value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf ListCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */ function listCacheHas(key) {
    return assocIndexOf(this.__data__, key) > -1;
}
module.exports = listCacheHas;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_listCacheSet.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var assocIndexOf = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_assocIndexOf.js [app-client] (ecmascript)");
/**
 * Sets the list cache `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf ListCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the list cache instance.
 */ function listCacheSet(key, value) {
    var data = this.__data__, index = assocIndexOf(data, key);
    if (index < 0) {
        ++this.size;
        data.push([
            key,
            value
        ]);
    } else {
        data[index][1] = value;
    }
    return this;
}
module.exports = listCacheSet;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_ListCache.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var listCacheClear = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_listCacheClear.js [app-client] (ecmascript)"), listCacheDelete = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_listCacheDelete.js [app-client] (ecmascript)"), listCacheGet = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_listCacheGet.js [app-client] (ecmascript)"), listCacheHas = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_listCacheHas.js [app-client] (ecmascript)"), listCacheSet = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_listCacheSet.js [app-client] (ecmascript)");
/**
 * Creates an list cache object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */ function ListCache(entries) {
    var index = -1, length = entries == null ? 0 : entries.length;
    this.clear();
    while(++index < length){
        var entry = entries[index];
        this.set(entry[0], entry[1]);
    }
}
// Add methods to `ListCache`.
ListCache.prototype.clear = listCacheClear;
ListCache.prototype['delete'] = listCacheDelete;
ListCache.prototype.get = listCacheGet;
ListCache.prototype.has = listCacheHas;
ListCache.prototype.set = listCacheSet;
module.exports = ListCache;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_stackClear.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var ListCache = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_ListCache.js [app-client] (ecmascript)");
/**
 * Removes all key-value entries from the stack.
 *
 * @private
 * @name clear
 * @memberOf Stack
 */ function stackClear() {
    this.__data__ = new ListCache;
    this.size = 0;
}
module.exports = stackClear;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_stackDelete.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Removes `key` and its value from the stack.
 *
 * @private
 * @name delete
 * @memberOf Stack
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */ function stackDelete(key) {
    var data = this.__data__, result = data['delete'](key);
    this.size = data.size;
    return result;
}
module.exports = stackDelete;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_stackGet.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Gets the stack value for `key`.
 *
 * @private
 * @name get
 * @memberOf Stack
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */ function stackGet(key) {
    return this.__data__.get(key);
}
module.exports = stackGet;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_stackHas.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Checks if a stack value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf Stack
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */ function stackHas(key) {
    return this.__data__.has(key);
}
module.exports = stackHas;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Map.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var getNative = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getNative.js [app-client] (ecmascript)"), root = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_root.js [app-client] (ecmascript)");
/* Built-in method references that are verified to be native. */ var Map = getNative(root, 'Map');
module.exports = Map;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_nativeCreate.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var getNative = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getNative.js [app-client] (ecmascript)");
/* Built-in method references that are verified to be native. */ var nativeCreate = getNative(Object, 'create');
module.exports = nativeCreate;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_hashClear.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var nativeCreate = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_nativeCreate.js [app-client] (ecmascript)");
/**
 * Removes all key-value entries from the hash.
 *
 * @private
 * @name clear
 * @memberOf Hash
 */ function hashClear() {
    this.__data__ = nativeCreate ? nativeCreate(null) : {};
    this.size = 0;
}
module.exports = hashClear;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_hashDelete.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Removes `key` and its value from the hash.
 *
 * @private
 * @name delete
 * @memberOf Hash
 * @param {Object} hash The hash to modify.
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */ function hashDelete(key) {
    var result = this.has(key) && delete this.__data__[key];
    this.size -= result ? 1 : 0;
    return result;
}
module.exports = hashDelete;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_hashGet.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var nativeCreate = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_nativeCreate.js [app-client] (ecmascript)");
/** Used to stand-in for `undefined` hash values. */ var HASH_UNDEFINED = '__lodash_hash_undefined__';
/** Used for built-in method references. */ var objectProto = Object.prototype;
/** Used to check objects for own properties. */ var hasOwnProperty = objectProto.hasOwnProperty;
/**
 * Gets the hash value for `key`.
 *
 * @private
 * @name get
 * @memberOf Hash
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */ function hashGet(key) {
    var data = this.__data__;
    if (nativeCreate) {
        var result = data[key];
        return result === HASH_UNDEFINED ? undefined : result;
    }
    return hasOwnProperty.call(data, key) ? data[key] : undefined;
}
module.exports = hashGet;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_hashHas.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var nativeCreate = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_nativeCreate.js [app-client] (ecmascript)");
/** Used for built-in method references. */ var objectProto = Object.prototype;
/** Used to check objects for own properties. */ var hasOwnProperty = objectProto.hasOwnProperty;
/**
 * Checks if a hash value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf Hash
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */ function hashHas(key) {
    var data = this.__data__;
    return nativeCreate ? data[key] !== undefined : hasOwnProperty.call(data, key);
}
module.exports = hashHas;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_hashSet.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var nativeCreate = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_nativeCreate.js [app-client] (ecmascript)");
/** Used to stand-in for `undefined` hash values. */ var HASH_UNDEFINED = '__lodash_hash_undefined__';
/**
 * Sets the hash `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf Hash
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the hash instance.
 */ function hashSet(key, value) {
    var data = this.__data__;
    this.size += this.has(key) ? 0 : 1;
    data[key] = nativeCreate && value === undefined ? HASH_UNDEFINED : value;
    return this;
}
module.exports = hashSet;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Hash.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var hashClear = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_hashClear.js [app-client] (ecmascript)"), hashDelete = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_hashDelete.js [app-client] (ecmascript)"), hashGet = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_hashGet.js [app-client] (ecmascript)"), hashHas = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_hashHas.js [app-client] (ecmascript)"), hashSet = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_hashSet.js [app-client] (ecmascript)");
/**
 * Creates a hash object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */ function Hash(entries) {
    var index = -1, length = entries == null ? 0 : entries.length;
    this.clear();
    while(++index < length){
        var entry = entries[index];
        this.set(entry[0], entry[1]);
    }
}
// Add methods to `Hash`.
Hash.prototype.clear = hashClear;
Hash.prototype['delete'] = hashDelete;
Hash.prototype.get = hashGet;
Hash.prototype.has = hashHas;
Hash.prototype.set = hashSet;
module.exports = Hash;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_mapCacheClear.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var Hash = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Hash.js [app-client] (ecmascript)"), ListCache = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_ListCache.js [app-client] (ecmascript)"), Map = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Map.js [app-client] (ecmascript)");
/**
 * Removes all key-value entries from the map.
 *
 * @private
 * @name clear
 * @memberOf MapCache
 */ function mapCacheClear() {
    this.size = 0;
    this.__data__ = {
        'hash': new Hash,
        'map': new (Map || ListCache),
        'string': new Hash
    };
}
module.exports = mapCacheClear;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isKeyable.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Checks if `value` is suitable for use as unique object key.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is suitable, else `false`.
 */ function isKeyable(value) {
    var type = typeof value;
    return type == 'string' || type == 'number' || type == 'symbol' || type == 'boolean' ? value !== '__proto__' : value === null;
}
module.exports = isKeyable;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getMapData.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var isKeyable = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isKeyable.js [app-client] (ecmascript)");
/**
 * Gets the data for `map`.
 *
 * @private
 * @param {Object} map The map to query.
 * @param {string} key The reference key.
 * @returns {*} Returns the map data.
 */ function getMapData(map, key) {
    var data = map.__data__;
    return isKeyable(key) ? data[typeof key == 'string' ? 'string' : 'hash'] : data.map;
}
module.exports = getMapData;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_mapCacheDelete.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var getMapData = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getMapData.js [app-client] (ecmascript)");
/**
 * Removes `key` and its value from the map.
 *
 * @private
 * @name delete
 * @memberOf MapCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */ function mapCacheDelete(key) {
    var result = getMapData(this, key)['delete'](key);
    this.size -= result ? 1 : 0;
    return result;
}
module.exports = mapCacheDelete;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_mapCacheGet.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var getMapData = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getMapData.js [app-client] (ecmascript)");
/**
 * Gets the map value for `key`.
 *
 * @private
 * @name get
 * @memberOf MapCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */ function mapCacheGet(key) {
    return getMapData(this, key).get(key);
}
module.exports = mapCacheGet;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_mapCacheHas.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var getMapData = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getMapData.js [app-client] (ecmascript)");
/**
 * Checks if a map value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf MapCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */ function mapCacheHas(key) {
    return getMapData(this, key).has(key);
}
module.exports = mapCacheHas;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_mapCacheSet.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var getMapData = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getMapData.js [app-client] (ecmascript)");
/**
 * Sets the map `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf MapCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the map cache instance.
 */ function mapCacheSet(key, value) {
    var data = getMapData(this, key), size = data.size;
    data.set(key, value);
    this.size += data.size == size ? 0 : 1;
    return this;
}
module.exports = mapCacheSet;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_MapCache.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var mapCacheClear = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_mapCacheClear.js [app-client] (ecmascript)"), mapCacheDelete = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_mapCacheDelete.js [app-client] (ecmascript)"), mapCacheGet = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_mapCacheGet.js [app-client] (ecmascript)"), mapCacheHas = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_mapCacheHas.js [app-client] (ecmascript)"), mapCacheSet = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_mapCacheSet.js [app-client] (ecmascript)");
/**
 * Creates a map cache object to store key-value pairs.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */ function MapCache(entries) {
    var index = -1, length = entries == null ? 0 : entries.length;
    this.clear();
    while(++index < length){
        var entry = entries[index];
        this.set(entry[0], entry[1]);
    }
}
// Add methods to `MapCache`.
MapCache.prototype.clear = mapCacheClear;
MapCache.prototype['delete'] = mapCacheDelete;
MapCache.prototype.get = mapCacheGet;
MapCache.prototype.has = mapCacheHas;
MapCache.prototype.set = mapCacheSet;
module.exports = MapCache;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_stackSet.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var ListCache = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_ListCache.js [app-client] (ecmascript)"), Map = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Map.js [app-client] (ecmascript)"), MapCache = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_MapCache.js [app-client] (ecmascript)");
/** Used as the size to enable large array optimizations. */ var LARGE_ARRAY_SIZE = 200;
/**
 * Sets the stack `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf Stack
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the stack cache instance.
 */ function stackSet(key, value) {
    var data = this.__data__;
    if (data instanceof ListCache) {
        var pairs = data.__data__;
        if (!Map || pairs.length < LARGE_ARRAY_SIZE - 1) {
            pairs.push([
                key,
                value
            ]);
            this.size = ++data.size;
            return this;
        }
        data = this.__data__ = new MapCache(pairs);
    }
    data.set(key, value);
    this.size = data.size;
    return this;
}
module.exports = stackSet;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Stack.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var ListCache = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_ListCache.js [app-client] (ecmascript)"), stackClear = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_stackClear.js [app-client] (ecmascript)"), stackDelete = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_stackDelete.js [app-client] (ecmascript)"), stackGet = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_stackGet.js [app-client] (ecmascript)"), stackHas = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_stackHas.js [app-client] (ecmascript)"), stackSet = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_stackSet.js [app-client] (ecmascript)");
/**
 * Creates a stack cache object to store key-value pairs.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */ function Stack(entries) {
    var data = this.__data__ = new ListCache(entries);
    this.size = data.size;
}
// Add methods to `Stack`.
Stack.prototype.clear = stackClear;
Stack.prototype['delete'] = stackDelete;
Stack.prototype.get = stackGet;
Stack.prototype.has = stackHas;
Stack.prototype.set = stackSet;
module.exports = Stack;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_setCacheAdd.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/** Used to stand-in for `undefined` hash values. */ var HASH_UNDEFINED = '__lodash_hash_undefined__';
/**
 * Adds `value` to the array cache.
 *
 * @private
 * @name add
 * @memberOf SetCache
 * @alias push
 * @param {*} value The value to cache.
 * @returns {Object} Returns the cache instance.
 */ function setCacheAdd(value) {
    this.__data__.set(value, HASH_UNDEFINED);
    return this;
}
module.exports = setCacheAdd;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_setCacheHas.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Checks if `value` is in the array cache.
 *
 * @private
 * @name has
 * @memberOf SetCache
 * @param {*} value The value to search for.
 * @returns {boolean} Returns `true` if `value` is found, else `false`.
 */ function setCacheHas(value) {
    return this.__data__.has(value);
}
module.exports = setCacheHas;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_SetCache.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var MapCache = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_MapCache.js [app-client] (ecmascript)"), setCacheAdd = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_setCacheAdd.js [app-client] (ecmascript)"), setCacheHas = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_setCacheHas.js [app-client] (ecmascript)");
/**
 *
 * Creates an array cache object to store unique values.
 *
 * @private
 * @constructor
 * @param {Array} [values] The values to cache.
 */ function SetCache(values) {
    var index = -1, length = values == null ? 0 : values.length;
    this.__data__ = new MapCache;
    while(++index < length){
        this.add(values[index]);
    }
}
// Add methods to `SetCache`.
SetCache.prototype.add = SetCache.prototype.push = setCacheAdd;
SetCache.prototype.has = setCacheHas;
module.exports = SetCache;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_arraySome.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * A specialized version of `_.some` for arrays without support for iteratee
 * shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} predicate The function invoked per iteration.
 * @returns {boolean} Returns `true` if any element passes the predicate check,
 *  else `false`.
 */ function arraySome(array, predicate) {
    var index = -1, length = array == null ? 0 : array.length;
    while(++index < length){
        if (predicate(array[index], index, array)) {
            return true;
        }
    }
    return false;
}
module.exports = arraySome;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_cacheHas.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Checks if a `cache` value for `key` exists.
 *
 * @private
 * @param {Object} cache The cache to query.
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */ function cacheHas(cache, key) {
    return cache.has(key);
}
module.exports = cacheHas;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_equalArrays.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var SetCache = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_SetCache.js [app-client] (ecmascript)"), arraySome = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_arraySome.js [app-client] (ecmascript)"), cacheHas = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_cacheHas.js [app-client] (ecmascript)");
/** Used to compose bitmasks for value comparisons. */ var COMPARE_PARTIAL_FLAG = 1, COMPARE_UNORDERED_FLAG = 2;
/**
 * A specialized version of `baseIsEqualDeep` for arrays with support for
 * partial deep comparisons.
 *
 * @private
 * @param {Array} array The array to compare.
 * @param {Array} other The other array to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} stack Tracks traversed `array` and `other` objects.
 * @returns {boolean} Returns `true` if the arrays are equivalent, else `false`.
 */ function equalArrays(array, other, bitmask, customizer, equalFunc, stack) {
    var isPartial = bitmask & COMPARE_PARTIAL_FLAG, arrLength = array.length, othLength = other.length;
    if (arrLength != othLength && !(isPartial && othLength > arrLength)) {
        return false;
    }
    // Check that cyclic values are equal.
    var arrStacked = stack.get(array);
    var othStacked = stack.get(other);
    if (arrStacked && othStacked) {
        return arrStacked == other && othStacked == array;
    }
    var index = -1, result = true, seen = bitmask & COMPARE_UNORDERED_FLAG ? new SetCache : undefined;
    stack.set(array, other);
    stack.set(other, array);
    // Ignore non-index properties.
    while(++index < arrLength){
        var arrValue = array[index], othValue = other[index];
        if (customizer) {
            var compared = isPartial ? customizer(othValue, arrValue, index, other, array, stack) : customizer(arrValue, othValue, index, array, other, stack);
        }
        if (compared !== undefined) {
            if (compared) {
                continue;
            }
            result = false;
            break;
        }
        // Recursively compare arrays (susceptible to call stack limits).
        if (seen) {
            if (!arraySome(other, function(othValue, othIndex) {
                if (!cacheHas(seen, othIndex) && (arrValue === othValue || equalFunc(arrValue, othValue, bitmask, customizer, stack))) {
                    return seen.push(othIndex);
                }
            })) {
                result = false;
                break;
            }
        } else if (!(arrValue === othValue || equalFunc(arrValue, othValue, bitmask, customizer, stack))) {
            result = false;
            break;
        }
    }
    stack['delete'](array);
    stack['delete'](other);
    return result;
}
module.exports = equalArrays;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Uint8Array.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var root = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_root.js [app-client] (ecmascript)");
/** Built-in value references. */ var Uint8Array = root.Uint8Array;
module.exports = Uint8Array;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_mapToArray.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Converts `map` to its key-value pairs.
 *
 * @private
 * @param {Object} map The map to convert.
 * @returns {Array} Returns the key-value pairs.
 */ function mapToArray(map) {
    var index = -1, result = Array(map.size);
    map.forEach(function(value, key) {
        result[++index] = [
            key,
            value
        ];
    });
    return result;
}
module.exports = mapToArray;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_setToArray.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Converts `set` to an array of its values.
 *
 * @private
 * @param {Object} set The set to convert.
 * @returns {Array} Returns the values.
 */ function setToArray(set) {
    var index = -1, result = Array(set.size);
    set.forEach(function(value) {
        result[++index] = value;
    });
    return result;
}
module.exports = setToArray;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_equalByTag.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var Symbol = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Symbol.js [app-client] (ecmascript)"), Uint8Array = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Uint8Array.js [app-client] (ecmascript)"), eq = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/eq.js [app-client] (ecmascript)"), equalArrays = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_equalArrays.js [app-client] (ecmascript)"), mapToArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_mapToArray.js [app-client] (ecmascript)"), setToArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_setToArray.js [app-client] (ecmascript)");
/** Used to compose bitmasks for value comparisons. */ var COMPARE_PARTIAL_FLAG = 1, COMPARE_UNORDERED_FLAG = 2;
/** `Object#toString` result references. */ var boolTag = '[object Boolean]', dateTag = '[object Date]', errorTag = '[object Error]', mapTag = '[object Map]', numberTag = '[object Number]', regexpTag = '[object RegExp]', setTag = '[object Set]', stringTag = '[object String]', symbolTag = '[object Symbol]';
var arrayBufferTag = '[object ArrayBuffer]', dataViewTag = '[object DataView]';
/** Used to convert symbols to primitives and strings. */ var symbolProto = Symbol ? Symbol.prototype : undefined, symbolValueOf = symbolProto ? symbolProto.valueOf : undefined;
/**
 * A specialized version of `baseIsEqualDeep` for comparing objects of
 * the same `toStringTag`.
 *
 * **Note:** This function only supports comparing values with tags of
 * `Boolean`, `Date`, `Error`, `Number`, `RegExp`, or `String`.
 *
 * @private
 * @param {Object} object The object to compare.
 * @param {Object} other The other object to compare.
 * @param {string} tag The `toStringTag` of the objects to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} stack Tracks traversed `object` and `other` objects.
 * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
 */ function equalByTag(object, other, tag, bitmask, customizer, equalFunc, stack) {
    switch(tag){
        case dataViewTag:
            if (object.byteLength != other.byteLength || object.byteOffset != other.byteOffset) {
                return false;
            }
            object = object.buffer;
            other = other.buffer;
        case arrayBufferTag:
            if (object.byteLength != other.byteLength || !equalFunc(new Uint8Array(object), new Uint8Array(other))) {
                return false;
            }
            return true;
        case boolTag:
        case dateTag:
        case numberTag:
            // Coerce booleans to `1` or `0` and dates to milliseconds.
            // Invalid dates are coerced to `NaN`.
            return eq(+object, +other);
        case errorTag:
            return object.name == other.name && object.message == other.message;
        case regexpTag:
        case stringTag:
            // Coerce regexes to strings and treat strings, primitives and objects,
            // as equal. See http://www.ecma-international.org/ecma-262/7.0/#sec-regexp.prototype.tostring
            // for more details.
            return object == other + '';
        case mapTag:
            var convert = mapToArray;
        case setTag:
            var isPartial = bitmask & COMPARE_PARTIAL_FLAG;
            convert || (convert = setToArray);
            if (object.size != other.size && !isPartial) {
                return false;
            }
            // Assume cyclic values are equal.
            var stacked = stack.get(object);
            if (stacked) {
                return stacked == other;
            }
            bitmask |= COMPARE_UNORDERED_FLAG;
            // Recursively compare objects (susceptible to call stack limits).
            stack.set(object, other);
            var result = equalArrays(convert(object), convert(other), bitmask, customizer, equalFunc, stack);
            stack['delete'](object);
            return result;
        case symbolTag:
            if (symbolValueOf) {
                return symbolValueOf.call(object) == symbolValueOf.call(other);
            }
    }
    return false;
}
module.exports = equalByTag;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_arrayPush.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Appends the elements of `values` to `array`.
 *
 * @private
 * @param {Array} array The array to modify.
 * @param {Array} values The values to append.
 * @returns {Array} Returns `array`.
 */ function arrayPush(array, values) {
    var index = -1, length = values.length, offset = array.length;
    while(++index < length){
        array[offset + index] = values[index];
    }
    return array;
}
module.exports = arrayPush;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseGetAllKeys.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var arrayPush = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_arrayPush.js [app-client] (ecmascript)"), isArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArray.js [app-client] (ecmascript)");
/**
 * The base implementation of `getAllKeys` and `getAllKeysIn` which uses
 * `keysFunc` and `symbolsFunc` to get the enumerable property names and
 * symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Function} keysFunc The function to get the keys of `object`.
 * @param {Function} symbolsFunc The function to get the symbols of `object`.
 * @returns {Array} Returns the array of property names and symbols.
 */ function baseGetAllKeys(object, keysFunc, symbolsFunc) {
    var result = keysFunc(object);
    return isArray(object) ? result : arrayPush(result, symbolsFunc(object));
}
module.exports = baseGetAllKeys;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_arrayFilter.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * A specialized version of `_.filter` for arrays without support for
 * iteratee shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} predicate The function invoked per iteration.
 * @returns {Array} Returns the new filtered array.
 */ function arrayFilter(array, predicate) {
    var index = -1, length = array == null ? 0 : array.length, resIndex = 0, result = [];
    while(++index < length){
        var value = array[index];
        if (predicate(value, index, array)) {
            result[resIndex++] = value;
        }
    }
    return result;
}
module.exports = arrayFilter;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/stubArray.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * This method returns a new empty array.
 *
 * @static
 * @memberOf _
 * @since 4.13.0
 * @category Util
 * @returns {Array} Returns the new empty array.
 * @example
 *
 * var arrays = _.times(2, _.stubArray);
 *
 * console.log(arrays);
 * // => [[], []]
 *
 * console.log(arrays[0] === arrays[1]);
 * // => false
 */ function stubArray() {
    return [];
}
module.exports = stubArray;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getSymbols.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var arrayFilter = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_arrayFilter.js [app-client] (ecmascript)"), stubArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/stubArray.js [app-client] (ecmascript)");
/** Used for built-in method references. */ var objectProto = Object.prototype;
/** Built-in value references. */ var propertyIsEnumerable = objectProto.propertyIsEnumerable;
/* Built-in method references for those with the same name as other `lodash` methods. */ var nativeGetSymbols = Object.getOwnPropertySymbols;
/**
 * Creates an array of the own enumerable symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of symbols.
 */ var getSymbols = !nativeGetSymbols ? stubArray : function(object) {
    if (object == null) {
        return [];
    }
    object = Object(object);
    return arrayFilter(nativeGetSymbols(object), function(symbol) {
        return propertyIsEnumerable.call(object, symbol);
    });
};
module.exports = getSymbols;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getAllKeys.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseGetAllKeys = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseGetAllKeys.js [app-client] (ecmascript)"), getSymbols = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getSymbols.js [app-client] (ecmascript)"), keys = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/keys.js [app-client] (ecmascript)");
/**
 * Creates an array of own enumerable property names and symbols of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the array of property names and symbols.
 */ function getAllKeys(object) {
    return baseGetAllKeys(object, keys, getSymbols);
}
module.exports = getAllKeys;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_equalObjects.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var getAllKeys = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getAllKeys.js [app-client] (ecmascript)");
/** Used to compose bitmasks for value comparisons. */ var COMPARE_PARTIAL_FLAG = 1;
/** Used for built-in method references. */ var objectProto = Object.prototype;
/** Used to check objects for own properties. */ var hasOwnProperty = objectProto.hasOwnProperty;
/**
 * A specialized version of `baseIsEqualDeep` for objects with support for
 * partial deep comparisons.
 *
 * @private
 * @param {Object} object The object to compare.
 * @param {Object} other The other object to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} stack Tracks traversed `object` and `other` objects.
 * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
 */ function equalObjects(object, other, bitmask, customizer, equalFunc, stack) {
    var isPartial = bitmask & COMPARE_PARTIAL_FLAG, objProps = getAllKeys(object), objLength = objProps.length, othProps = getAllKeys(other), othLength = othProps.length;
    if (objLength != othLength && !isPartial) {
        return false;
    }
    var index = objLength;
    while(index--){
        var key = objProps[index];
        if (!(isPartial ? key in other : hasOwnProperty.call(other, key))) {
            return false;
        }
    }
    // Check that cyclic values are equal.
    var objStacked = stack.get(object);
    var othStacked = stack.get(other);
    if (objStacked && othStacked) {
        return objStacked == other && othStacked == object;
    }
    var result = true;
    stack.set(object, other);
    stack.set(other, object);
    var skipCtor = isPartial;
    while(++index < objLength){
        key = objProps[index];
        var objValue = object[key], othValue = other[key];
        if (customizer) {
            var compared = isPartial ? customizer(othValue, objValue, key, other, object, stack) : customizer(objValue, othValue, key, object, other, stack);
        }
        // Recursively compare objects (susceptible to call stack limits).
        if (!(compared === undefined ? objValue === othValue || equalFunc(objValue, othValue, bitmask, customizer, stack) : compared)) {
            result = false;
            break;
        }
        skipCtor || (skipCtor = key == 'constructor');
    }
    if (result && !skipCtor) {
        var objCtor = object.constructor, othCtor = other.constructor;
        // Non `Object` object instances with different constructors are not equal.
        if (objCtor != othCtor && 'constructor' in object && 'constructor' in other && !(typeof objCtor == 'function' && objCtor instanceof objCtor && typeof othCtor == 'function' && othCtor instanceof othCtor)) {
            result = false;
        }
    }
    stack['delete'](object);
    stack['delete'](other);
    return result;
}
module.exports = equalObjects;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_DataView.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var getNative = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getNative.js [app-client] (ecmascript)"), root = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_root.js [app-client] (ecmascript)");
/* Built-in method references that are verified to be native. */ var DataView = getNative(root, 'DataView');
module.exports = DataView;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Promise.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var getNative = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getNative.js [app-client] (ecmascript)"), root = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_root.js [app-client] (ecmascript)");
/* Built-in method references that are verified to be native. */ var Promise = getNative(root, 'Promise');
module.exports = Promise;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Set.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var getNative = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getNative.js [app-client] (ecmascript)"), root = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_root.js [app-client] (ecmascript)");
/* Built-in method references that are verified to be native. */ var Set = getNative(root, 'Set');
module.exports = Set;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_WeakMap.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var getNative = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getNative.js [app-client] (ecmascript)"), root = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_root.js [app-client] (ecmascript)");
/* Built-in method references that are verified to be native. */ var WeakMap = getNative(root, 'WeakMap');
module.exports = WeakMap;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getTag.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var DataView = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_DataView.js [app-client] (ecmascript)"), Map = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Map.js [app-client] (ecmascript)"), Promise = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Promise.js [app-client] (ecmascript)"), Set = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Set.js [app-client] (ecmascript)"), WeakMap = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_WeakMap.js [app-client] (ecmascript)"), baseGetTag = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseGetTag.js [app-client] (ecmascript)"), toSource = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_toSource.js [app-client] (ecmascript)");
/** `Object#toString` result references. */ var mapTag = '[object Map]', objectTag = '[object Object]', promiseTag = '[object Promise]', setTag = '[object Set]', weakMapTag = '[object WeakMap]';
var dataViewTag = '[object DataView]';
/** Used to detect maps, sets, and weakmaps. */ var dataViewCtorString = toSource(DataView), mapCtorString = toSource(Map), promiseCtorString = toSource(Promise), setCtorString = toSource(Set), weakMapCtorString = toSource(WeakMap);
/**
 * Gets the `toStringTag` of `value`.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the `toStringTag`.
 */ var getTag = baseGetTag;
// Fallback for data views, maps, sets, and weak maps in IE 11 and promises in Node.js < 6.
if (DataView && getTag(new DataView(new ArrayBuffer(1))) != dataViewTag || Map && getTag(new Map) != mapTag || Promise && getTag(Promise.resolve()) != promiseTag || Set && getTag(new Set) != setTag || WeakMap && getTag(new WeakMap) != weakMapTag) {
    getTag = function(value) {
        var result = baseGetTag(value), Ctor = result == objectTag ? value.constructor : undefined, ctorString = Ctor ? toSource(Ctor) : '';
        if (ctorString) {
            switch(ctorString){
                case dataViewCtorString:
                    return dataViewTag;
                case mapCtorString:
                    return mapTag;
                case promiseCtorString:
                    return promiseTag;
                case setCtorString:
                    return setTag;
                case weakMapCtorString:
                    return weakMapTag;
            }
        }
        return result;
    };
}
module.exports = getTag;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIsEqualDeep.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var Stack = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Stack.js [app-client] (ecmascript)"), equalArrays = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_equalArrays.js [app-client] (ecmascript)"), equalByTag = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_equalByTag.js [app-client] (ecmascript)"), equalObjects = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_equalObjects.js [app-client] (ecmascript)"), getTag = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getTag.js [app-client] (ecmascript)"), isArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArray.js [app-client] (ecmascript)"), isBuffer = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isBuffer.js [app-client] (ecmascript)"), isTypedArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isTypedArray.js [app-client] (ecmascript)");
/** Used to compose bitmasks for value comparisons. */ var COMPARE_PARTIAL_FLAG = 1;
/** `Object#toString` result references. */ var argsTag = '[object Arguments]', arrayTag = '[object Array]', objectTag = '[object Object]';
/** Used for built-in method references. */ var objectProto = Object.prototype;
/** Used to check objects for own properties. */ var hasOwnProperty = objectProto.hasOwnProperty;
/**
 * A specialized version of `baseIsEqual` for arrays and objects which performs
 * deep comparisons and tracks traversed objects enabling objects with circular
 * references to be compared.
 *
 * @private
 * @param {Object} object The object to compare.
 * @param {Object} other The other object to compare.
 * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
 * @param {Function} customizer The function to customize comparisons.
 * @param {Function} equalFunc The function to determine equivalents of values.
 * @param {Object} [stack] Tracks traversed `object` and `other` objects.
 * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
 */ function baseIsEqualDeep(object, other, bitmask, customizer, equalFunc, stack) {
    var objIsArr = isArray(object), othIsArr = isArray(other), objTag = objIsArr ? arrayTag : getTag(object), othTag = othIsArr ? arrayTag : getTag(other);
    objTag = objTag == argsTag ? objectTag : objTag;
    othTag = othTag == argsTag ? objectTag : othTag;
    var objIsObj = objTag == objectTag, othIsObj = othTag == objectTag, isSameTag = objTag == othTag;
    if (isSameTag && isBuffer(object)) {
        if (!isBuffer(other)) {
            return false;
        }
        objIsArr = true;
        objIsObj = false;
    }
    if (isSameTag && !objIsObj) {
        stack || (stack = new Stack);
        return objIsArr || isTypedArray(object) ? equalArrays(object, other, bitmask, customizer, equalFunc, stack) : equalByTag(object, other, objTag, bitmask, customizer, equalFunc, stack);
    }
    if (!(bitmask & COMPARE_PARTIAL_FLAG)) {
        var objIsWrapped = objIsObj && hasOwnProperty.call(object, '__wrapped__'), othIsWrapped = othIsObj && hasOwnProperty.call(other, '__wrapped__');
        if (objIsWrapped || othIsWrapped) {
            var objUnwrapped = objIsWrapped ? object.value() : object, othUnwrapped = othIsWrapped ? other.value() : other;
            stack || (stack = new Stack);
            return equalFunc(objUnwrapped, othUnwrapped, bitmask, customizer, stack);
        }
    }
    if (!isSameTag) {
        return false;
    }
    stack || (stack = new Stack);
    return equalObjects(object, other, bitmask, customizer, equalFunc, stack);
}
module.exports = baseIsEqualDeep;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIsEqual.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseIsEqualDeep = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIsEqualDeep.js [app-client] (ecmascript)"), isObjectLike = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isObjectLike.js [app-client] (ecmascript)");
/**
 * The base implementation of `_.isEqual` which supports partial comparisons
 * and tracks traversed objects.
 *
 * @private
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @param {boolean} bitmask The bitmask flags.
 *  1 - Unordered comparison
 *  2 - Partial comparison
 * @param {Function} [customizer] The function to customize comparisons.
 * @param {Object} [stack] Tracks traversed `value` and `other` objects.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 */ function baseIsEqual(value, other, bitmask, customizer, stack) {
    if (value === other) {
        return true;
    }
    if (value == null || other == null || !isObjectLike(value) && !isObjectLike(other)) {
        return value !== value && other !== other;
    }
    return baseIsEqualDeep(value, other, bitmask, customizer, baseIsEqual, stack);
}
module.exports = baseIsEqual;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIsMatch.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var Stack = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Stack.js [app-client] (ecmascript)"), baseIsEqual = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIsEqual.js [app-client] (ecmascript)");
/** Used to compose bitmasks for value comparisons. */ var COMPARE_PARTIAL_FLAG = 1, COMPARE_UNORDERED_FLAG = 2;
/**
 * The base implementation of `_.isMatch` without support for iteratee shorthands.
 *
 * @private
 * @param {Object} object The object to inspect.
 * @param {Object} source The object of property values to match.
 * @param {Array} matchData The property names, values, and compare flags to match.
 * @param {Function} [customizer] The function to customize comparisons.
 * @returns {boolean} Returns `true` if `object` is a match, else `false`.
 */ function baseIsMatch(object, source, matchData, customizer) {
    var index = matchData.length, length = index, noCustomizer = !customizer;
    if (object == null) {
        return !length;
    }
    object = Object(object);
    while(index--){
        var data = matchData[index];
        if (noCustomizer && data[2] ? data[1] !== object[data[0]] : !(data[0] in object)) {
            return false;
        }
    }
    while(++index < length){
        data = matchData[index];
        var key = data[0], objValue = object[key], srcValue = data[1];
        if (noCustomizer && data[2]) {
            if (objValue === undefined && !(key in object)) {
                return false;
            }
        } else {
            var stack = new Stack;
            if (customizer) {
                var result = customizer(objValue, srcValue, key, object, source, stack);
            }
            if (!(result === undefined ? baseIsEqual(srcValue, objValue, COMPARE_PARTIAL_FLAG | COMPARE_UNORDERED_FLAG, customizer, stack) : result)) {
                return false;
            }
        }
    }
    return true;
}
module.exports = baseIsMatch;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isStrictComparable.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var isObject = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isObject.js [app-client] (ecmascript)");
/**
 * Checks if `value` is suitable for strict equality comparisons, i.e. `===`.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` if suitable for strict
 *  equality comparisons, else `false`.
 */ function isStrictComparable(value) {
    return value === value && !isObject(value);
}
module.exports = isStrictComparable;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getMatchData.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var isStrictComparable = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isStrictComparable.js [app-client] (ecmascript)"), keys = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/keys.js [app-client] (ecmascript)");
/**
 * Gets the property names, values, and compare flags of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Array} Returns the match data of `object`.
 */ function getMatchData(object) {
    var result = keys(object), length = result.length;
    while(length--){
        var key = result[length], value = object[key];
        result[length] = [
            key,
            value,
            isStrictComparable(value)
        ];
    }
    return result;
}
module.exports = getMatchData;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_matchesStrictComparable.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * A specialized version of `matchesProperty` for source values suitable
 * for strict equality comparisons, i.e. `===`.
 *
 * @private
 * @param {string} key The key of the property to get.
 * @param {*} srcValue The value to match.
 * @returns {Function} Returns the new spec function.
 */ function matchesStrictComparable(key, srcValue) {
    return function(object) {
        if (object == null) {
            return false;
        }
        return object[key] === srcValue && (srcValue !== undefined || key in Object(object));
    };
}
module.exports = matchesStrictComparable;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseMatches.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseIsMatch = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIsMatch.js [app-client] (ecmascript)"), getMatchData = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_getMatchData.js [app-client] (ecmascript)"), matchesStrictComparable = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_matchesStrictComparable.js [app-client] (ecmascript)");
/**
 * The base implementation of `_.matches` which doesn't clone `source`.
 *
 * @private
 * @param {Object} source The object of property values to match.
 * @returns {Function} Returns the new spec function.
 */ function baseMatches(source) {
    var matchData = getMatchData(source);
    if (matchData.length == 1 && matchData[0][2]) {
        return matchesStrictComparable(matchData[0][0], matchData[0][1]);
    }
    return function(object) {
        return object === source || baseIsMatch(object, source, matchData);
    };
}
module.exports = baseMatches;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isSymbol.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseGetTag = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseGetTag.js [app-client] (ecmascript)"), isObjectLike = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isObjectLike.js [app-client] (ecmascript)");
/** `Object#toString` result references. */ var symbolTag = '[object Symbol]';
/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */ function isSymbol(value) {
    return typeof value == 'symbol' || isObjectLike(value) && baseGetTag(value) == symbolTag;
}
module.exports = isSymbol;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isKey.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var isArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArray.js [app-client] (ecmascript)"), isSymbol = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isSymbol.js [app-client] (ecmascript)");
/** Used to match property names within property paths. */ var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, reIsPlainProp = /^\w*$/;
/**
 * Checks if `value` is a property name and not a property path.
 *
 * @private
 * @param {*} value The value to check.
 * @param {Object} [object] The object to query keys on.
 * @returns {boolean} Returns `true` if `value` is a property name, else `false`.
 */ function isKey(value, object) {
    if (isArray(value)) {
        return false;
    }
    var type = typeof value;
    if (type == 'number' || type == 'symbol' || type == 'boolean' || value == null || isSymbol(value)) {
        return true;
    }
    return reIsPlainProp.test(value) || !reIsDeepProp.test(value) || object != null && value in Object(object);
}
module.exports = isKey;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/memoize.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var MapCache = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_MapCache.js [app-client] (ecmascript)");
/** Error message constants. */ var FUNC_ERROR_TEXT = 'Expected a function';
/**
 * Creates a function that memoizes the result of `func`. If `resolver` is
 * provided, it determines the cache key for storing the result based on the
 * arguments provided to the memoized function. By default, the first argument
 * provided to the memoized function is used as the map cache key. The `func`
 * is invoked with the `this` binding of the memoized function.
 *
 * **Note:** The cache is exposed as the `cache` property on the memoized
 * function. Its creation may be customized by replacing the `_.memoize.Cache`
 * constructor with one whose instances implement the
 * [`Map`](http://ecma-international.org/ecma-262/7.0/#sec-properties-of-the-map-prototype-object)
 * method interface of `clear`, `delete`, `get`, `has`, and `set`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to have its output memoized.
 * @param {Function} [resolver] The function to resolve the cache key.
 * @returns {Function} Returns the new memoized function.
 * @example
 *
 * var object = { 'a': 1, 'b': 2 };
 * var other = { 'c': 3, 'd': 4 };
 *
 * var values = _.memoize(_.values);
 * values(object);
 * // => [1, 2]
 *
 * values(other);
 * // => [3, 4]
 *
 * object.a = 2;
 * values(object);
 * // => [1, 2]
 *
 * // Modify the result cache.
 * values.cache.set(object, ['a', 'b']);
 * values(object);
 * // => ['a', 'b']
 *
 * // Replace `_.memoize.Cache`.
 * _.memoize.Cache = WeakMap;
 */ function memoize(func, resolver) {
    if (typeof func != 'function' || resolver != null && typeof resolver != 'function') {
        throw new TypeError(FUNC_ERROR_TEXT);
    }
    var memoized = function() {
        var args = arguments, key = resolver ? resolver.apply(this, args) : args[0], cache = memoized.cache;
        if (cache.has(key)) {
            return cache.get(key);
        }
        var result = func.apply(this, args);
        memoized.cache = cache.set(key, result) || cache;
        return result;
    };
    memoized.cache = new (memoize.Cache || MapCache);
    return memoized;
}
// Expose `MapCache`.
memoize.Cache = MapCache;
module.exports = memoize;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_memoizeCapped.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var memoize = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/memoize.js [app-client] (ecmascript)");
/** Used as the maximum memoize cache size. */ var MAX_MEMOIZE_SIZE = 500;
/**
 * A specialized version of `_.memoize` which clears the memoized function's
 * cache when it exceeds `MAX_MEMOIZE_SIZE`.
 *
 * @private
 * @param {Function} func The function to have its output memoized.
 * @returns {Function} Returns the new memoized function.
 */ function memoizeCapped(func) {
    var result = memoize(func, function(key) {
        if (cache.size === MAX_MEMOIZE_SIZE) {
            cache.clear();
        }
        return key;
    });
    var cache = result.cache;
    return result;
}
module.exports = memoizeCapped;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_stringToPath.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var memoizeCapped = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_memoizeCapped.js [app-client] (ecmascript)");
/** Used to match property names within property paths. */ var rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
/** Used to match backslashes in property paths. */ var reEscapeChar = /\\(\\)?/g;
/**
 * Converts `string` to a property path array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the property path array.
 */ var stringToPath = memoizeCapped(function(string) {
    var result = [];
    if (string.charCodeAt(0) === 46 /* . */ ) {
        result.push('');
    }
    string.replace(rePropName, function(match, number, quote, subString) {
        result.push(quote ? subString.replace(reEscapeChar, '$1') : number || match);
    });
    return result;
});
module.exports = stringToPath;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_arrayMap.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * A specialized version of `_.map` for arrays without support for iteratee
 * shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns the new mapped array.
 */ function arrayMap(array, iteratee) {
    var index = -1, length = array == null ? 0 : array.length, result = Array(length);
    while(++index < length){
        result[index] = iteratee(array[index], index, array);
    }
    return result;
}
module.exports = arrayMap;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseToString.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var Symbol = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_Symbol.js [app-client] (ecmascript)"), arrayMap = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_arrayMap.js [app-client] (ecmascript)"), isArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArray.js [app-client] (ecmascript)"), isSymbol = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isSymbol.js [app-client] (ecmascript)");
/** Used as references for various `Number` constants. */ var INFINITY = 1 / 0;
/** Used to convert symbols to primitives and strings. */ var symbolProto = Symbol ? Symbol.prototype : undefined, symbolToString = symbolProto ? symbolProto.toString : undefined;
/**
 * The base implementation of `_.toString` which doesn't convert nullish
 * values to empty strings.
 *
 * @private
 * @param {*} value The value to process.
 * @returns {string} Returns the string.
 */ function baseToString(value) {
    // Exit early for strings to avoid a performance hit in some environments.
    if (typeof value == 'string') {
        return value;
    }
    if (isArray(value)) {
        // Recursively convert values (susceptible to call stack limits).
        return arrayMap(value, baseToString) + '';
    }
    if (isSymbol(value)) {
        return symbolToString ? symbolToString.call(value) : '';
    }
    var result = value + '';
    return result == '0' && 1 / value == -INFINITY ? '-0' : result;
}
module.exports = baseToString;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/toString.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseToString = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseToString.js [app-client] (ecmascript)");
/**
 * Converts `value` to a string. An empty string is returned for `null`
 * and `undefined` values. The sign of `-0` is preserved.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to convert.
 * @returns {string} Returns the converted string.
 * @example
 *
 * _.toString(null);
 * // => ''
 *
 * _.toString(-0);
 * // => '-0'
 *
 * _.toString([1, 2, 3]);
 * // => '1,2,3'
 */ function toString(value) {
    return value == null ? '' : baseToString(value);
}
module.exports = toString;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_castPath.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var isArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArray.js [app-client] (ecmascript)"), isKey = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isKey.js [app-client] (ecmascript)"), stringToPath = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_stringToPath.js [app-client] (ecmascript)"), toString = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/toString.js [app-client] (ecmascript)");
/**
 * Casts `value` to a path array if it's not one.
 *
 * @private
 * @param {*} value The value to inspect.
 * @param {Object} [object] The object to query keys on.
 * @returns {Array} Returns the cast property path array.
 */ function castPath(value, object) {
    if (isArray(value)) {
        return value;
    }
    return isKey(value, object) ? [
        value
    ] : stringToPath(toString(value));
}
module.exports = castPath;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_toKey.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var isSymbol = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isSymbol.js [app-client] (ecmascript)");
/** Used as references for various `Number` constants. */ var INFINITY = 1 / 0;
/**
 * Converts `value` to a string key if it's not a string or symbol.
 *
 * @private
 * @param {*} value The value to inspect.
 * @returns {string|symbol} Returns the key.
 */ function toKey(value) {
    if (typeof value == 'string' || isSymbol(value)) {
        return value;
    }
    var result = value + '';
    return result == '0' && 1 / value == -INFINITY ? '-0' : result;
}
module.exports = toKey;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseGet.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var castPath = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_castPath.js [app-client] (ecmascript)"), toKey = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_toKey.js [app-client] (ecmascript)");
/**
 * The base implementation of `_.get` without support for default values.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Array|string} path The path of the property to get.
 * @returns {*} Returns the resolved value.
 */ function baseGet(object, path) {
    path = castPath(path, object);
    var index = 0, length = path.length;
    while(object != null && index < length){
        object = object[toKey(path[index++])];
    }
    return index && index == length ? object : undefined;
}
module.exports = baseGet;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/get.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseGet = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseGet.js [app-client] (ecmascript)");
/**
 * Gets the value at `path` of `object`. If the resolved value is
 * `undefined`, the `defaultValue` is returned in its place.
 *
 * @static
 * @memberOf _
 * @since 3.7.0
 * @category Object
 * @param {Object} object The object to query.
 * @param {Array|string} path The path of the property to get.
 * @param {*} [defaultValue] The value returned for `undefined` resolved values.
 * @returns {*} Returns the resolved value.
 * @example
 *
 * var object = { 'a': [{ 'b': { 'c': 3 } }] };
 *
 * _.get(object, 'a[0].b.c');
 * // => 3
 *
 * _.get(object, ['a', '0', 'b', 'c']);
 * // => 3
 *
 * _.get(object, 'a.b.c', 'default');
 * // => 'default'
 */ function get(object, path, defaultValue) {
    var result = object == null ? undefined : baseGet(object, path);
    return result === undefined ? defaultValue : result;
}
module.exports = get;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseHasIn.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * The base implementation of `_.hasIn` without support for deep paths.
 *
 * @private
 * @param {Object} [object] The object to query.
 * @param {Array|string} key The key to check.
 * @returns {boolean} Returns `true` if `key` exists, else `false`.
 */ function baseHasIn(object, key) {
    return object != null && key in Object(object);
}
module.exports = baseHasIn;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_hasPath.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var castPath = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_castPath.js [app-client] (ecmascript)"), isArguments = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArguments.js [app-client] (ecmascript)"), isArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArray.js [app-client] (ecmascript)"), isIndex = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isIndex.js [app-client] (ecmascript)"), isLength = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isLength.js [app-client] (ecmascript)"), toKey = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_toKey.js [app-client] (ecmascript)");
/**
 * Checks if `path` exists on `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Array|string} path The path to check.
 * @param {Function} hasFunc The function to check properties.
 * @returns {boolean} Returns `true` if `path` exists, else `false`.
 */ function hasPath(object, path, hasFunc) {
    path = castPath(path, object);
    var index = -1, length = path.length, result = false;
    while(++index < length){
        var key = toKey(path[index]);
        if (!(result = object != null && hasFunc(object, key))) {
            break;
        }
        object = object[key];
    }
    if (result || ++index != length) {
        return result;
    }
    length = object == null ? 0 : object.length;
    return !!length && isLength(length) && isIndex(key, length) && (isArray(object) || isArguments(object));
}
module.exports = hasPath;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/hasIn.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseHasIn = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseHasIn.js [app-client] (ecmascript)"), hasPath = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_hasPath.js [app-client] (ecmascript)");
/**
 * Checks if `path` is a direct or inherited property of `object`.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Object
 * @param {Object} object The object to query.
 * @param {Array|string} path The path to check.
 * @returns {boolean} Returns `true` if `path` exists, else `false`.
 * @example
 *
 * var object = _.create({ 'a': _.create({ 'b': 2 }) });
 *
 * _.hasIn(object, 'a');
 * // => true
 *
 * _.hasIn(object, 'a.b');
 * // => true
 *
 * _.hasIn(object, ['a', 'b']);
 * // => true
 *
 * _.hasIn(object, 'b');
 * // => false
 */ function hasIn(object, path) {
    return object != null && hasPath(object, path, baseHasIn);
}
module.exports = hasIn;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseMatchesProperty.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseIsEqual = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIsEqual.js [app-client] (ecmascript)"), get = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/get.js [app-client] (ecmascript)"), hasIn = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/hasIn.js [app-client] (ecmascript)"), isKey = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isKey.js [app-client] (ecmascript)"), isStrictComparable = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isStrictComparable.js [app-client] (ecmascript)"), matchesStrictComparable = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_matchesStrictComparable.js [app-client] (ecmascript)"), toKey = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_toKey.js [app-client] (ecmascript)");
/** Used to compose bitmasks for value comparisons. */ var COMPARE_PARTIAL_FLAG = 1, COMPARE_UNORDERED_FLAG = 2;
/**
 * The base implementation of `_.matchesProperty` which doesn't clone `srcValue`.
 *
 * @private
 * @param {string} path The path of the property to get.
 * @param {*} srcValue The value to match.
 * @returns {Function} Returns the new spec function.
 */ function baseMatchesProperty(path, srcValue) {
    if (isKey(path) && isStrictComparable(srcValue)) {
        return matchesStrictComparable(toKey(path), srcValue);
    }
    return function(object) {
        var objValue = get(object, path);
        return objValue === undefined && objValue === srcValue ? hasIn(object, path) : baseIsEqual(srcValue, objValue, COMPARE_PARTIAL_FLAG | COMPARE_UNORDERED_FLAG);
    };
}
module.exports = baseMatchesProperty;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/identity.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * This method returns the first argument it receives.
 *
 * @static
 * @since 0.1.0
 * @memberOf _
 * @category Util
 * @param {*} value Any value.
 * @returns {*} Returns `value`.
 * @example
 *
 * var object = { 'a': 1 };
 *
 * console.log(_.identity(object) === object);
 * // => true
 */ function identity(value) {
    return value;
}
module.exports = identity;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseProperty.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * The base implementation of `_.property` without support for deep paths.
 *
 * @private
 * @param {string} key The key of the property to get.
 * @returns {Function} Returns the new accessor function.
 */ function baseProperty(key) {
    return function(object) {
        return object == null ? undefined : object[key];
    };
}
module.exports = baseProperty;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_basePropertyDeep.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseGet = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseGet.js [app-client] (ecmascript)");
/**
 * A specialized version of `baseProperty` which supports deep paths.
 *
 * @private
 * @param {Array|string} path The path of the property to get.
 * @returns {Function} Returns the new accessor function.
 */ function basePropertyDeep(path) {
    return function(object) {
        return baseGet(object, path);
    };
}
module.exports = basePropertyDeep;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/property.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseProperty = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseProperty.js [app-client] (ecmascript)"), basePropertyDeep = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_basePropertyDeep.js [app-client] (ecmascript)"), isKey = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_isKey.js [app-client] (ecmascript)"), toKey = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_toKey.js [app-client] (ecmascript)");
/**
 * Creates a function that returns the value at `path` of a given object.
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Util
 * @param {Array|string} path The path of the property to get.
 * @returns {Function} Returns the new accessor function.
 * @example
 *
 * var objects = [
 *   { 'a': { 'b': 2 } },
 *   { 'a': { 'b': 1 } }
 * ];
 *
 * _.map(objects, _.property('a.b'));
 * // => [2, 1]
 *
 * _.map(_.sortBy(objects, _.property(['a', 'b'])), 'a.b');
 * // => [1, 2]
 */ function property(path) {
    return isKey(path) ? baseProperty(toKey(path)) : basePropertyDeep(path);
}
module.exports = property;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIteratee.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseMatches = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseMatches.js [app-client] (ecmascript)"), baseMatchesProperty = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseMatchesProperty.js [app-client] (ecmascript)"), identity = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/identity.js [app-client] (ecmascript)"), isArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArray.js [app-client] (ecmascript)"), property = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/property.js [app-client] (ecmascript)");
/**
 * The base implementation of `_.iteratee`.
 *
 * @private
 * @param {*} [value=_.identity] The value to convert to an iteratee.
 * @returns {Function} Returns the iteratee.
 */ function baseIteratee(value) {
    // Don't store the `typeof` result in a variable to avoid a JIT bug in Safari 9.
    // See https://bugs.webkit.org/show_bug.cgi?id=156034 for more details.
    if (typeof value == 'function') {
        return value;
    }
    if (value == null) {
        return identity;
    }
    if (typeof value == 'object') {
        return isArray(value) ? baseMatchesProperty(value[0], value[1]) : baseMatches(value);
    }
    return property(value);
}
module.exports = baseIteratee;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_createAggregator.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var arrayAggregator = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_arrayAggregator.js [app-client] (ecmascript)"), baseAggregator = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseAggregator.js [app-client] (ecmascript)"), baseIteratee = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseIteratee.js [app-client] (ecmascript)"), isArray = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isArray.js [app-client] (ecmascript)");
/**
 * Creates a function like `_.groupBy`.
 *
 * @private
 * @param {Function} setter The function to set accumulator values.
 * @param {Function} [initializer] The accumulator object initializer.
 * @returns {Function} Returns the new aggregator function.
 */ function createAggregator(setter, initializer) {
    return function(collection, iteratee) {
        var func = isArray(collection) ? arrayAggregator : baseAggregator, accumulator = initializer ? initializer() : {};
        return func(collection, setter, baseIteratee(iteratee, 2), accumulator);
    };
}
module.exports = createAggregator;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/lodash/groupBy.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var baseAssignValue = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_baseAssignValue.js [app-client] (ecmascript)"), createAggregator = __turbopack_context__.r("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/_createAggregator.js [app-client] (ecmascript)");
/** Used for built-in method references. */ var objectProto = Object.prototype;
/** Used to check objects for own properties. */ var hasOwnProperty = objectProto.hasOwnProperty;
/**
 * Creates an object composed of keys generated from the results of running
 * each element of `collection` thru `iteratee`. The order of grouped values
 * is determined by the order they occur in `collection`. The corresponding
 * value of each key is an array of elements responsible for generating the
 * key. The iteratee is invoked with one argument: (value).
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Collection
 * @param {Array|Object} collection The collection to iterate over.
 * @param {Function} [iteratee=_.identity] The iteratee to transform keys.
 * @returns {Object} Returns the composed aggregate object.
 * @example
 *
 * _.groupBy([6.1, 4.2, 6.3], Math.floor);
 * // => { '4': [4.2], '6': [6.1, 6.3] }
 *
 * // The `_.property` iteratee shorthand.
 * _.groupBy(['one', 'two', 'three'], 'length');
 * // => { '3': ['one', 'two'], '5': ['three'] }
 */ var groupBy = createAggregator(function(result, value, key) {
    if (hasOwnProperty.call(result, key)) {
        result[key].push(value);
    } else {
        baseAssignValue(result, key, [
            value
        ]);
    }
});
module.exports = groupBy;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/parse.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parse",
    ()=>parse
]);
function parse(path) {
    return path.split(/[[.\]]/g).filter(Boolean).map((seg)=>seg.includes("==") ? parseSegment(seg) : coerce(seg));
}
const IS_NUMERIC = /^-?\d+$/;
function unquote(str) {
    return str.replace(/^['"]/, "").replace(/['"]$/, "");
}
function parseSegment(segment) {
    const [key, value] = segment.split("==");
    if (key !== "_key") throw new Error(`Currently only "_key" is supported as path segment. Found ${key}`);
    if (typeof value > "u") throw new Error('Invalid path segment, expected `key=="value"`');
    return {
        _key: unquote(value)
    };
}
function coerce(segment) {
    return IS_NUMERIC.test(segment) ? Number(segment) : segment;
}
;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/stringify.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isArrayElement",
    ()=>isArrayElement,
    "isElementEqual",
    ()=>isElementEqual,
    "isEqual",
    ()=>isEqual,
    "isIndexElement",
    ()=>isIndexElement,
    "isKeyElement",
    ()=>isKeyElement,
    "isKeyedElement",
    ()=>isKeyedElement,
    "isPropertyElement",
    ()=>isPropertyElement,
    "startsWith",
    ()=>startsWith,
    "stringify",
    ()=>stringify
]);
function safeGetElementAt(array, index) {
    if (index < 0 || index >= array.length) throw new Error("Index out of bounds");
    return array[index];
}
function startsWith(parentPath, path) {
    return parentPath.length <= path.length && parentPath.every((segment, i)=>isElementEqual(segment, safeGetElementAt(path, i)));
}
function isEqual(path, otherPath) {
    return path.length === otherPath.length && path.every((segment, i)=>isElementEqual(segment, safeGetElementAt(path, i)));
}
function isElementEqual(segmentA, segmentB) {
    return isKeyElement(segmentA) && isKeyElement(segmentB) ? segmentA._key === segmentB._key : isIndexElement(segmentA) ? Number(segmentA) === Number(segmentB) : segmentA === segmentB;
}
function isKeyElement(segment) {
    return typeof segment?._key == "string";
}
function isIndexElement(segment) {
    return typeof segment == "number";
}
function isKeyedElement(element) {
    return typeof element == "object" && "_key" in element && typeof element._key == "string";
}
function isArrayElement(element) {
    return typeof element == "number" || isKeyedElement(element);
}
function isPropertyElement(element) {
    return typeof element == "string";
}
const IS_DOTTABLE = /^[a-z_$]+/;
function stringifySegment(segment, hasLeading) {
    return Array.isArray(segment) ? `[${segment[0]}:${segment[1] || ""}]` : typeof segment == "number" ? `[${segment}]` : isKeyedElement(segment) ? `[_key==${JSON.stringify(segment._key)}]` : typeof segment == "string" && IS_DOTTABLE.test(segment) ? hasLeading ? segment : `.${segment}` : `['${segment}']`;
}
function stringify(pathArray) {
    return pathArray.map((segment, i)=>stringifySegment(segment, i === 0)).join("");
}
;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/arrify.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "arrify",
    ()=>arrify
]);
function arrify(val) {
    return Array.isArray(val) ? val : [
        val
    ];
}
;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/decode.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "decode",
    ()=>decode,
    "decodeAll",
    ()=>decodeAll
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/parse.js [app-client] (ecmascript)");
;
function isCreateIfNotExistsMutation(sanityMutation) {
    return "createIfNotExists" in sanityMutation;
}
function isCreateOrReplaceMutation(sanityMutation) {
    return "createOrReplace" in sanityMutation;
}
function isCreateMutation(sanityMutation) {
    return "create" in sanityMutation;
}
function isDeleteMutation(sanityMutation) {
    return "delete" in sanityMutation;
}
function isPatchMutation(sanityMutation) {
    return "patch" in sanityMutation;
}
function isSetPatch(sanityPatch) {
    return "set" in sanityPatch;
}
function isSetIfMissingPatch(sanityPatch) {
    return "setIfMissing" in sanityPatch;
}
function isDiffMatchPatch(sanityPatch) {
    return "diffMatchPatch" in sanityPatch;
}
function isUnsetPatch(sanityPatch) {
    return "unset" in sanityPatch;
}
function isIncPatch(sanityPatch) {
    return "inc" in sanityPatch;
}
function isDecPatch(sanityPatch) {
    return "inc" in sanityPatch;
}
function isInsertPatch(sanityPatch) {
    return "insert" in sanityPatch;
}
function decodeAll(sanityMutations) {
    return sanityMutations.map(decodeMutation);
}
function decode(encodedMutation) {
    return decodeMutation(encodedMutation);
}
function decodeMutation(encodedMutation) {
    if (isCreateIfNotExistsMutation(encodedMutation)) return {
        type: "createIfNotExists",
        document: encodedMutation.createIfNotExists
    };
    if (isCreateOrReplaceMutation(encodedMutation)) return {
        type: "createOrReplace",
        document: encodedMutation.createOrReplace
    };
    if (isCreateMutation(encodedMutation)) return {
        type: "create",
        document: encodedMutation.create
    };
    if (isDeleteMutation(encodedMutation)) return {
        id: encodedMutation.delete.id,
        type: "delete"
    };
    if (isPatchMutation(encodedMutation)) return {
        type: "patch",
        id: encodedMutation.patch.id,
        patches: decodeNodePatches(encodedMutation.patch)
    };
    throw new Error(`Unknown mutation: ${JSON.stringify(encodedMutation)}`);
}
const POSITION_KEYS = [
    "before",
    "replace",
    "after"
];
function getInsertPosition(insert) {
    const positions = POSITION_KEYS.filter((k)=>k in insert);
    if (positions.length > 1) throw new Error(`Insert patch is ambiguous. Should only contain one of: ${POSITION_KEYS.join(", ")}, instead found ${positions.join(", ")}`);
    return positions[0];
}
function decodeNodePatches(patch) {
    return [
        ...getSetPatches(patch),
        ...getSetIfMissingPatches(patch),
        ...getUnsetPatches(patch),
        ...getIncPatches(patch),
        ...getDecPatches(patch),
        ...getInsertPatches(patch),
        ...getDiffMatchPatchPatches(patch)
    ];
}
function getSetPatches(patch) {
    return isSetPatch(patch) ? Object.keys(patch.set).map((path)=>({
            path: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parse"])(path),
            op: {
                type: "set",
                value: patch.set[path]
            }
        })) : [];
}
function getSetIfMissingPatches(patch) {
    return isSetIfMissingPatch(patch) ? Object.keys(patch.setIfMissing).map((path)=>({
            path: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parse"])(path),
            op: {
                type: "setIfMissing",
                value: patch.setIfMissing[path]
            }
        })) : [];
}
function getDiffMatchPatchPatches(patch) {
    return isDiffMatchPatch(patch) ? Object.keys(patch.diffMatchPatch).map((path)=>({
            path: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parse"])(path),
            op: {
                type: "diffMatchPatch",
                value: patch.diffMatchPatch[path]
            }
        })) : [];
}
function getUnsetPatches(patch) {
    return isUnsetPatch(patch) ? patch.unset.map((path)=>({
            path: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parse"])(path),
            op: {
                type: "unset"
            }
        })) : [];
}
function getIncPatches(patch) {
    return isIncPatch(patch) ? Object.keys(patch.inc).map((path)=>({
            path: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parse"])(path),
            op: {
                type: "inc",
                amount: patch.inc[path]
            }
        })) : [];
}
function getDecPatches(patch) {
    return isDecPatch(patch) ? Object.keys(patch.dec).map((path)=>({
            path: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parse"])(path),
            op: {
                type: "dec",
                amount: patch.dec[path]
            }
        })) : [];
}
function getInsertPatches(patch) {
    if (!isInsertPatch(patch)) return [];
    const position = getInsertPosition(patch.insert);
    if (!position) throw new Error("Insert patch missing position");
    const path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parse"])(patch.insert[position]), referenceItem = path.pop(), op = position === "replace" ? {
        type: "insert",
        position,
        referenceItem,
        items: patch.insert.items
    } : {
        type: "insert",
        position,
        referenceItem,
        items: patch.insert.items
    };
    return [
        {
            path,
            op
        }
    ];
}
;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/encode.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "encode",
    ()=>encode,
    "encodeAll",
    ()=>encodeAll,
    "encodeMutation",
    ()=>encodeMutation,
    "encodePatch",
    ()=>encodePatch,
    "encodeTransaction",
    ()=>encodeTransaction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/stringify.js [app-client] (ecmascript)");
;
function encode(mutation) {
    return encodeMutation(mutation);
}
function encodeAll(mutations) {
    return mutations.flatMap(encode);
}
function encodeTransaction(transaction) {
    return {
        transactionId: transaction.id,
        mutations: encodeAll(transaction.mutations)
    };
}
function encodeMutation(mutation) {
    switch(mutation.type){
        case "create":
            return {
                [mutation.type]: mutation.document
            };
        case "createIfNotExists":
            return {
                [mutation.type]: mutation.document
            };
        case "createOrReplace":
            return {
                [mutation.type]: mutation.document
            };
        case "delete":
            return {
                delete: {
                    id: mutation.id
                }
            };
        case "patch":
            {
                const ifRevisionID = mutation.options?.ifRevision;
                return mutation.patches.map((patch)=>({
                        patch: {
                            id: mutation.id,
                            ...ifRevisionID && {
                                ifRevisionID
                            },
                            ...encodePatch(patch)
                        }
                    }));
            }
    }
}
function encodePatch(patch) {
    const { path, op } = patch;
    if (op.type === "unset") return {
        unset: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(path)
        ]
    };
    if (op.type === "insert") return {
        insert: {
            [op.position]: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])([
                ...path,
                op.referenceItem
            ]),
            items: op.items
        }
    };
    if (op.type === "diffMatchPatch") return {
        diffMatchPatch: {
            [(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(path)]: op.value
        }
    };
    if (op.type === "inc") return {
        inc: {
            [(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(path)]: op.amount
        }
    };
    if (op.type === "dec") return {
        dec: {
            [(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(path)]: op.amount
        }
    };
    if (op.type === "set" || op.type === "setIfMissing") return {
        [op.type]: {
            [(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(path)]: op.value
        }
    };
    if (op.type === "truncate") {
        const range = [
            op.startIndex,
            typeof op.endIndex == "number" ? op.endIndex : ""
        ].join(":");
        return {
            unset: [
                `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(path)}[${range}]`
            ]
        };
    }
    if (op.type === "upsert") return {
        unset: op.items.map((item)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])([
                ...path,
                {
                    _key: item._key
                }
            ])),
        insert: {
            [op.position]: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])([
                ...path,
                op.referenceItem
            ]),
            items: op.items
        }
    };
    if (op.type === "assign") return {
        set: Object.fromEntries(Object.keys(op.value).map((key)=>[
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(path.concat(key)),
                op.value[key]
            ]))
    };
    if (op.type === "unassign") return {
        unset: op.keys.map((key)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(path.concat(key)))
    };
    if (op.type === "replace") return {
        insert: {
            replace: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(path.concat(op.referenceItem)),
            items: op.items
        }
    };
    if (op.type === "remove") return {
        unset: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(path.concat(op.referenceItem))
        ]
    };
    throw op.type === "insertIfMissing" ? new Error("Patch type insertIfMissing is not supported by Sanity") : new Error(`Unknown operation type ${op.type}`);
}
;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/isObject.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isObject",
    ()=>isObject
]);
function isObject(val) {
    return val !== null && typeof val == "object" && !Array.isArray(val);
}
;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CompactEncoder",
    ()=>index$2,
    "CompactFormatter",
    ()=>compact,
    "FormCompatEncoder",
    ()=>index$1,
    "SanityEncoder",
    ()=>index,
    "append",
    ()=>append,
    "assign",
    ()=>assign,
    "at",
    ()=>at,
    "autoKeys",
    ()=>autoKeys,
    "create",
    ()=>create,
    "createIfNotExists",
    ()=>createIfNotExists,
    "createOrReplace",
    ()=>createOrReplace,
    "dec",
    ()=>dec,
    "del",
    ()=>del,
    "delete_",
    ()=>delete_,
    "destroy",
    ()=>destroy,
    "diffMatchPatch",
    ()=>diffMatchPatch,
    "inc",
    ()=>inc,
    "insert",
    ()=>insert,
    "insertAfter",
    ()=>insertAfter,
    "insertBefore",
    ()=>insertBefore,
    "insertIfMissing",
    ()=>insertIfMissing,
    "patch",
    ()=>patch,
    "prepend",
    ()=>prepend,
    "remove",
    ()=>remove,
    "replace",
    ()=>replace,
    "set",
    ()=>set,
    "setIfMissing",
    ()=>setIfMissing,
    "truncate",
    ()=>truncate,
    "unassign",
    ()=>unassign,
    "unset",
    ()=>unset,
    "upsert",
    ()=>upsert
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$lodash$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/isObject.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/parse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/stringify.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$arrify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/arrify.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$decode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/decode.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$encode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/encode.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/isObject.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
function decode(mutations) {
    return mutations.map(decodeMutation);
}
function decodeMutation(mutation) {
    const [type] = mutation;
    if (type === "delete") {
        const [, id] = mutation;
        return {
            id,
            type
        };
    } else if (type === "create") {
        const [, document] = mutation;
        return {
            type,
            document
        };
    } else if (type === "createIfNotExists") {
        const [, document] = mutation;
        return {
            type,
            document
        };
    } else if (type === "createOrReplace") {
        const [, document] = mutation;
        return {
            type,
            document
        };
    } else if (type === "patch") return decodePatchMutation(mutation);
    throw new Error(`Unrecognized mutation: ${JSON.stringify(mutation)}`);
}
function decodePatchMutation(mutation) {
    const [, type, id, serializedPath, , revisionId] = mutation, path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parse"])(serializedPath);
    if (type === "dec" || type === "inc") {
        const [, , , , [amount]] = mutation;
        return {
            type: "patch",
            id,
            patches: [
                {
                    path,
                    op: {
                        type: "inc",
                        amount
                    }
                }
            ],
            ...createOpts(revisionId)
        };
    }
    if (type === "unset") return {
        type: "patch",
        id,
        patches: [
            {
                path,
                op: {
                    type: "unset"
                }
            }
        ],
        ...createOpts(revisionId)
    };
    if (type === "insert") {
        const [, , , , [position, ref, items]] = mutation;
        return {
            type: "patch",
            id,
            patches: [
                {
                    path,
                    op: {
                        type: "insert",
                        position,
                        items,
                        referenceItem: typeof ref == "string" ? {
                            _key: ref
                        } : ref
                    }
                }
            ],
            ...createOpts(revisionId)
        };
    }
    if (type === "set") {
        const [, , , , [value]] = mutation;
        return {
            type: "patch",
            id,
            patches: [
                {
                    path,
                    op: {
                        type: "set",
                        value
                    }
                }
            ],
            ...createOpts(revisionId)
        };
    }
    if (type === "setIfMissing") {
        const [, , , , [value]] = mutation;
        return {
            type: "patch",
            id,
            patches: [
                {
                    path,
                    op: {
                        type: "setIfMissing",
                        value
                    }
                }
            ],
            ...createOpts(revisionId)
        };
    }
    if (type === "diffMatchPatch") {
        const [, , , , [value]] = mutation;
        return {
            type: "patch",
            id,
            patches: [
                {
                    path,
                    op: {
                        type: "diffMatchPatch",
                        value
                    }
                }
            ],
            ...createOpts(revisionId)
        };
    }
    if (type === "truncate") {
        const [, , , , [startIndex, endIndex]] = mutation;
        return {
            type: "patch",
            id,
            patches: [
                {
                    path,
                    op: {
                        type: "truncate",
                        startIndex,
                        endIndex
                    }
                }
            ],
            ...createOpts(revisionId)
        };
    }
    if (type === "assign") {
        const [, , , , [value]] = mutation;
        return {
            type: "patch",
            id,
            patches: [
                {
                    path,
                    op: {
                        type: "assign",
                        value
                    }
                }
            ],
            ...createOpts(revisionId)
        };
    }
    if (type === "replace") {
        const [, , , , [ref, items]] = mutation;
        return {
            type: "patch",
            id,
            patches: [
                {
                    path,
                    op: {
                        type: "replace",
                        items,
                        referenceItem: decodeItemRef(ref)
                    }
                }
            ],
            ...createOpts(revisionId)
        };
    }
    if (type === "upsert") {
        const [, , , , [position, referenceItem, items]] = mutation, decodedReferenceItem = decodeItemRef(referenceItem);
        return {
            type: "patch",
            id,
            patches: [
                {
                    path,
                    op: {
                        type: "upsert",
                        items,
                        referenceItem: decodedReferenceItem,
                        position
                    }
                }
            ],
            ...createOpts(revisionId)
        };
    }
    throw new Error(`Invalid mutation type: ${type}`);
}
function decodeItemRef(ref) {
    if (typeof ref == "string") return {
        _key: ref
    };
    if (typeof ref == "number") return ref;
    if (!hasKey$1(ref)) throw new Error("Cannot decode upsert patch: referenceItem is missing key");
    return ref;
}
function createOpts(revisionId) {
    return revisionId ? {
        options: {
            ifRevision: revisionId
        }
    } : null;
}
function hasKey$1(item) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$lodash$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(item) && "_key" in item;
}
function encode(mutations) {
    return mutations.flatMap((m)=>encodeMutation$1(m));
}
function encodeItemRef$1(ref) {
    return typeof ref == "number" ? ref : ref._key;
}
function encodeMutation$1(mutation) {
    if (mutation.type === "create" || mutation.type === "createIfNotExists" || mutation.type === "createOrReplace") return [
        [
            mutation.type,
            mutation.document
        ]
    ];
    if (mutation.type === "delete") return [
        [
            "delete",
            mutation.id
        ]
    ];
    if (mutation.type === "patch") return mutation.patches.map((patch2)=>maybeAddRevision(mutation.options?.ifRevision, encodePatchMutation(mutation.id, patch2)));
    throw new Error(`Invalid mutation type: ${mutation.type}`);
}
function encodePatchMutation(id, patch2) {
    const { op } = patch2, path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(patch2.path);
    if (op.type === "unset") return [
        "patch",
        "unset",
        id,
        path,
        []
    ];
    if (op.type === "diffMatchPatch") return [
        "patch",
        "diffMatchPatch",
        id,
        path,
        [
            op.value
        ]
    ];
    if (op.type === "inc" || op.type === "dec") return [
        "patch",
        op.type,
        id,
        path,
        [
            op.amount
        ]
    ];
    if (op.type === "set") return [
        "patch",
        op.type,
        id,
        path,
        [
            op.value
        ]
    ];
    if (op.type === "setIfMissing") return [
        "patch",
        op.type,
        id,
        path,
        [
            op.value
        ]
    ];
    if (op.type === "insert") return [
        "patch",
        "insert",
        id,
        path,
        [
            op.position,
            encodeItemRef$1(op.referenceItem),
            op.items
        ]
    ];
    if (op.type === "upsert") return [
        "patch",
        "upsert",
        id,
        path,
        [
            op.position,
            encodeItemRef$1(op.referenceItem),
            op.items
        ]
    ];
    if (op.type === "insertIfMissing") return [
        "patch",
        "insertIfMissing",
        id,
        path,
        [
            op.position,
            encodeItemRef$1(op.referenceItem),
            op.items
        ]
    ];
    if (op.type === "assign") return [
        "patch",
        "assign",
        id,
        path,
        [
            op.value
        ]
    ];
    if (op.type === "unassign") return [
        "patch",
        "assign",
        id,
        path,
        [
            op.keys
        ]
    ];
    if (op.type === "replace") return [
        "patch",
        "replace",
        id,
        path,
        [
            encodeItemRef$1(op.referenceItem),
            op.items
        ]
    ];
    if (op.type === "truncate") return [
        "patch",
        "truncate",
        id,
        path,
        [
            op.startIndex,
            op.endIndex
        ]
    ];
    if (op.type === "remove") return [
        "patch",
        "remove",
        id,
        path,
        [
            encodeItemRef$1(op.referenceItem)
        ]
    ];
    throw new Error(`Invalid operation type: ${op.type}`);
}
function maybeAddRevision(revision, mut) {
    const [mutType, patchType, id, path, args] = mut;
    return revision ? [
        mutType,
        patchType,
        id,
        path,
        args,
        revision
    ] : mut;
}
var index$2 = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    decode,
    encode
});
function create(document) {
    return {
        type: "create",
        document
    };
}
function patch(id, patches, options) {
    return {
        type: "patch",
        id,
        patches: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$arrify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrify"])(patches),
        ...options ? {
            options
        } : {}
    };
}
function at(path, operation) {
    return {
        path: typeof path == "string" ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parse"])(path) : path,
        op: operation
    };
}
function createIfNotExists(document) {
    return {
        type: "createIfNotExists",
        document
    };
}
function createOrReplace(document) {
    return {
        type: "createOrReplace",
        document
    };
}
function delete_(id) {
    return {
        type: "delete",
        id
    };
}
const del = delete_, destroy = delete_, set = (value)=>({
        type: "set",
        value
    }), assign = (value)=>({
        type: "assign",
        value
    }), unassign = (keys)=>({
        type: "unassign",
        keys
    }), setIfMissing = (value)=>({
        type: "setIfMissing",
        value
    }), unset = ()=>({
        type: "unset"
    }), inc = (amount = 1)=>({
        type: "inc",
        amount
    }), dec = (amount = 1)=>({
        type: "dec",
        amount
    }), diffMatchPatch = (value)=>({
        type: "diffMatchPatch",
        value
    });
function insert(items, position, indexOrReferenceItem) {
    return {
        type: "insert",
        referenceItem: indexOrReferenceItem,
        position,
        items: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$arrify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrify"])(items)
    };
}
function append(items) {
    return insert(items, "after", -1);
}
function prepend(items) {
    return insert(items, "before", 0);
}
function insertBefore(items, indexOrReferenceItem) {
    return insert(items, "before", indexOrReferenceItem);
}
const insertAfter = (items, indexOrReferenceItem)=>insert(items, "after", indexOrReferenceItem);
function truncate(startIndex, endIndex) {
    return {
        type: "truncate",
        startIndex,
        endIndex
    };
}
function replace(items, referenceItem) {
    return {
        type: "replace",
        referenceItem,
        items: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$arrify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrify"])(items)
    };
}
function remove(referenceItem) {
    return {
        type: "remove",
        referenceItem
    };
}
function upsert(items, position, referenceItem) {
    return {
        type: "upsert",
        items: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$arrify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrify"])(items),
        referenceItem,
        position
    };
}
function insertIfMissing(items, position, referenceItem) {
    return {
        type: "insertIfMissing",
        items: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$arrify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrify"])(items),
        referenceItem,
        position
    };
}
function assertCompatible(formPatchPath) {
    if (formPatchPath.length === 0) return formPatchPath;
    for (const element of formPatchPath)if (Array.isArray(element)) throw new Error("Form patch paths cannot include arrays");
    return formPatchPath;
}
function encodePatches(patches) {
    return patches.map((formPatch)=>{
        const path = assertCompatible(formPatch.path);
        if (formPatch.type === "unset") return at(path, unset());
        if (formPatch.type === "set") return at(path, set(formPatch.value));
        if (formPatch.type === "setIfMissing") return at(path, setIfMissing(formPatch.value));
        if (formPatch.type === "insert") {
            const arrayPath = path.slice(0, -1), itemRef = formPatch.path[formPatch.path.length - 1];
            return at(arrayPath, insert(formPatch.items, formPatch.position, itemRef));
        }
        if (formPatch.type === "diffMatchPatch") return at(path, diffMatchPatch(formPatch.value));
        throw new Error(`Unknown patch type ${formPatch.type}`);
    });
}
var index$1 = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    encodePatches
}), index = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$decode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decode"],
    decodeAll: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$decode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decodeAll"],
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$encode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encode"],
    encodeAll: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$encode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodeAll"],
    encodeMutation: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$encode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodeMutation"],
    encodePatch: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$encode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodePatch"],
    encodeTransaction: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$encode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodeTransaction"]
});
function format(mutations) {
    return mutations.flatMap((m)=>encodeMutation(m)).join(`
`);
}
function encodeItemRef(ref) {
    return typeof ref == "number" ? ref : ref._key;
}
function encodeMutation(mutation) {
    if (mutation.type === "create" || mutation.type === "createIfNotExists" || mutation.type === "createOrReplace") return [
        mutation.type,
        ": ",
        JSON.stringify(mutation.document)
    ].join("");
    if (mutation.type === "delete") return [
        "delete ",
        mutation.id
    ].join(": ");
    if (mutation.type === "patch") {
        const ifRevision = mutation.options?.ifRevision;
        return [
            "patch",
            " ",
            `id=${mutation.id}`,
            ifRevision ? ` (if revision==${ifRevision})` : "",
            `:
`,
            mutation.patches.map((nodePatch)=>`  ${formatPatchMutation(nodePatch)}`).join(`
`)
        ].join("");
    }
    throw new Error(`Invalid mutation type: ${mutation.type}`);
}
function formatPatchMutation(patch2) {
    const { op } = patch2, path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(patch2.path);
    if (op.type === "unset") return [
        path,
        "unset()"
    ].join(": ");
    if (op.type === "diffMatchPatch") return [
        path,
        `diffMatchPatch(${op.value})`
    ].join(": ");
    if (op.type === "inc" || op.type === "dec") return [
        path,
        `${op.type}(${op.amount})`
    ].join(": ");
    if (op.type === "set" || op.type === "setIfMissing") return [
        path,
        `${op.type}(${JSON.stringify(op.value)})`
    ].join(": ");
    if (op.type === "assign") return [
        path,
        `${op.type}(${JSON.stringify(op.value)})`
    ].join(": ");
    if (op.type === "unassign") return [
        path,
        `${op.type}(${JSON.stringify(op.keys)})`
    ].join(": ");
    if (op.type === "insert" || op.type === "upsert" || op.type === "insertIfMissing") return [
        path,
        `${op.type}(${op.position}, ${encodeItemRef(op.referenceItem)}, ${JSON.stringify(op.items)})`
    ].join(": ");
    if (op.type === "replace") return [
        path,
        `replace(${encodeItemRef(op.referenceItem)}, ${JSON.stringify(op.items)})`
    ].join(": ");
    if (op.type === "truncate") return [
        path,
        `truncate(${op.startIndex}, ${op.endIndex}`
    ].join(": ");
    if (op.type === "remove") return [
        path,
        `remove(${encodeItemRef(op.referenceItem)})`
    ].join(": ");
    throw new Error(`Invalid operation type: ${op.type}`);
}
var compact = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    format
});
function autoKeys(generateKey) {
    const ensureKeys = createEnsureKeys(generateKey), insert$1 = (position, referenceItem, items)=>insert(ensureKeys(items), position, referenceItem), upsert$1 = (items, position, referenceItem)=>upsert(ensureKeys(items), position, referenceItem), replace$1 = (items, position, referenceItem)=>replace(ensureKeys(items), referenceItem), insertBefore2 = (ref, items)=>insert$1("before", ref, items);
    return {
        insert: insert$1,
        upsert: upsert$1,
        replace: replace$1,
        insertBefore: insertBefore2,
        prepend: (items)=>insertBefore2(0, items),
        insertAfter: (ref, items)=>insert$1("after", ref, items),
        append: (items)=>insert$1("after", -1, items)
    };
}
function hasKey(item) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(item) && "_key" in item;
}
function createEnsureKeys(generateKey) {
    return (array)=>{
        let didModify = !1;
        const withKeys = array.map((item)=>hasKey(item) ? item : (didModify = !0, {
                ...item,
                _key: generateKey(item)
            }));
        return didModify ? withKeys : array;
    };
}
;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "applyNodePatch",
    ()=>applyNodePatch,
    "applyOp",
    ()=>applyOp,
    "applyPatchMutation",
    ()=>applyPatchMutation,
    "applyPatches",
    ()=>applyPatches,
    "assignId",
    ()=>assignId,
    "hasId",
    ()=>hasId,
    "splice",
    ()=>splice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/stringify.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/isObject.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$diff$2d$match$2d$patch$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/diff-match-patch/dist/index.js [app-client] (ecmascript)");
;
;
;
function keyOf(value) {
    return value !== null && typeof value == "object" && typeof value._key == "string" && value._key || null;
}
function findTargetIndex(array, pathSegment) {
    if (typeof pathSegment == "number") return normalizeIndex(array.length, pathSegment);
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isKeyedElement"])(pathSegment)) {
        const idx = array.findIndex((value)=>keyOf(value) === pathSegment._key);
        return idx === -1 ? null : idx;
    }
    throw new Error(`Expected path segment to be addressing a single array item either by numeric index or by '_key'. Instead saw ${JSON.stringify(pathSegment)}`);
}
function getTargetIdx(position, index) {
    return position === "before" ? index : index + 1;
}
function normalizeIndex(length, index) {
    if (length === 0 && (index === -1 || index === 0)) return 0;
    const normalized = index < 0 ? length + index : index;
    return normalized >= length || normalized < 0 ? null : normalized;
}
function splice(arr, start, deleteCount, items) {
    const copy = arr.slice();
    return copy.splice(start, deleteCount, ...items || []), copy;
}
function omit(val, props) {
    const copy = {
        ...val
    };
    for (const prop of props)delete copy[prop];
    return copy;
}
function insert(op, currentValue) {
    if (!Array.isArray(currentValue)) throw new TypeError('Cannot apply "insert()" on non-array value');
    const index = findTargetIndex(currentValue, op.referenceItem);
    if (index === null) throw new Error(`Found no matching array element to insert ${op.position}`);
    return currentValue.length === 0 ? op.items : splice(currentValue, getTargetIdx(op.position, index), 0, op.items);
}
function upsert(op, currentValue) {
    if (!Array.isArray(currentValue)) throw new TypeError('Cannot apply "upsert()" on non-array value');
    if (op.items.length === 0) return currentValue;
    const replaceItemsMap = {}, insertItems = [];
    op.items.forEach((itemToBeUpserted, i)=>{
        const existingIndex = currentValue.findIndex((existingItem)=>existingItem?._key === itemToBeUpserted._key);
        existingIndex >= 0 ? replaceItemsMap[existingIndex] = i : insertItems.push(itemToBeUpserted);
    });
    const itemsToReplace = Object.keys(replaceItemsMap);
    if (itemsToReplace.length === 0 && insertItems.length == 0) return currentValue;
    const next = [
        ...currentValue
    ];
    for (const i of itemsToReplace){
        const index = Number(i);
        next[index] = op.items[replaceItemsMap[index]];
    }
    return insert({
        items: insertItems,
        referenceItem: op.referenceItem,
        position: op.position
    }, next);
}
function insertIfMissing(op, currentValue) {
    if (!Array.isArray(currentValue)) throw new TypeError('Cannot apply "insertIfMissing()" on non-array value');
    if (op.items.length === 0) return currentValue;
    const itemsToInsert = op.items.filter((item)=>!currentValue.find((existing)=>item._key === existing?._key));
    return itemsToInsert.length === 0 ? currentValue : insert({
        items: itemsToInsert,
        referenceItem: op.referenceItem,
        position: op.position
    }, currentValue);
}
function replace(op, currentValue) {
    if (!Array.isArray(currentValue)) throw new TypeError('Cannot apply "replace()" on non-array value');
    const index = findTargetIndex(currentValue, op.referenceItem);
    if (index === null) throw new Error("Found no matching array element to replace");
    return splice(currentValue, index, op.items.length, op.items);
}
function remove(op, currentValue) {
    if (!Array.isArray(currentValue)) throw new TypeError('Cannot apply "remove()" on non-array value');
    const index = findTargetIndex(currentValue, op.referenceItem);
    if (index === null) throw new Error("Found no matching array element to replace");
    return splice(currentValue, index, 1, []);
}
function truncate(op, currentValue) {
    if (!Array.isArray(currentValue)) throw new TypeError('Cannot apply "truncate()" on non-array value');
    return typeof op.endIndex == "number" ? currentValue.slice(0, op.startIndex).concat(currentValue.slice(op.endIndex)) : currentValue.slice(0, op.startIndex);
}
function set(op, currentValue) {
    return op.value;
}
function setIfMissing(op, currentValue) {
    return currentValue ?? op.value;
}
function unset(op) {}
function inc(op, currentValue) {
    if (typeof currentValue != "number") throw new TypeError('Cannot apply "inc()" on non-numeric value');
    return currentValue + op.amount;
}
function dec(op, currentValue) {
    if (typeof currentValue != "number") throw new TypeError('Cannot apply "dec()" on non-numeric value');
    return currentValue - op.amount;
}
const hasOwn = Object.prototype.hasOwnProperty.call.bind(Object.prototype.hasOwnProperty);
function isEmpty(v) {
    for(const key in v)if (hasOwn(v, key)) return !1;
    return !0;
}
function unassign(op, currentValue) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(currentValue)) throw new TypeError('Cannot apply "unassign()" on non-object value');
    return op.keys.length === 0 ? currentValue : omit(currentValue, op.keys);
}
function assign(op, currentValue) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(currentValue)) throw new TypeError('Cannot apply "assign()" on non-object value');
    return isEmpty(op.value) ? currentValue : {
        ...currentValue,
        ...op.value
    };
}
function diffMatchPatch(op, currentValue) {
    if (typeof currentValue != "string") throw new TypeError('Cannot apply "diffMatchPatch()" on non-string value');
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$diff$2d$match$2d$patch$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyPatches"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$diff$2d$match$2d$patch$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parsePatch"])(op.value), currentValue)[0];
}
var operations = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    assign,
    dec,
    diffMatchPatch,
    inc,
    insert,
    insertIfMissing,
    remove,
    replace,
    set,
    setIfMissing,
    truncate,
    unassign,
    unset,
    upsert
});
function applyOp(op, currentValue) {
    if (!(op.type in operations)) throw new Error(`Invalid operation type: "${op.type}"`);
    return operations[op.type](op, currentValue);
}
function applyPatches(patches, document) {
    return patches.reduce((prev, patch)=>applyNodePatch(patch, prev), document);
}
function applyNodePatch(patch, document) {
    return applyAtPath(patch.path, patch.op, document);
}
function applyAtPath(path, op, value) {
    if (!isNonEmptyArray(path)) return applyOp(op, value);
    const [head, ...tail] = path;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArrayElement"])(head) && Array.isArray(value)) return applyInArray(head, tail, op, value);
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPropertyElement"])(head) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$isObject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(value)) return applyInObject(head, tail, op, value);
    throw new Error(`Cannot apply operation of type "${op.type}" to path ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(path)} on ${typeof value} value`);
}
function applyInObject(head, tail, op, object) {
    const current = object[head];
    if (current === void 0 && tail.length > 0) return object;
    const patchedValue = applyAtPath(tail, op, current);
    return patchedValue === void 0 ? omit(object, [
        head
    ]) : patchedValue === current ? object : {
        ...object,
        [head]: patchedValue
    };
}
function applyInArray(head, tail, op, value) {
    const index = findTargetIndex(value, head);
    if (index === null || index === -1) return value;
    const current = value[index], patchedItem = applyAtPath(tail, op, current);
    return patchedItem === current ? value : splice(value, index, 1, // unset op on an array item should not leave a "hole" in the array
    // eg. apply(at('someArray[1]', unset()), ['foo', 'bar', 'baz'] should result in
    // ['foo', 'baz'], not ['foo', undefined, 'baz']
    patchedItem === void 0 ? [] : [
        patchedItem
    ]);
}
function isNonEmptyArray(a) {
    return a.length > 0;
}
function applyPatchMutation(mutation, document) {
    if (mutation.options?.ifRevision && document._rev !== mutation.options.ifRevision) throw new Error("Revision mismatch");
    if (mutation.id !== document._id) throw new Error(`Document id mismatch. Refusing to apply mutation for document with id="${mutation.id}" on the given document with id="${document._id}"`);
    return applyPatches(mutation.patches, document);
}
function hasId(doc) {
    return "_id" in doc;
}
function assignId(doc, generateId) {
    return hasId(doc) ? doc : {
        ...doc,
        _id: generateId()
    };
}
;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/getAtPath.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAtPath",
    ()=>getAtPath
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/stringify.js [app-client] (ecmascript)");
;
function getAtPath(path, value) {
    if (path.length === 0) return value;
    let current = value;
    for (const head of path){
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArrayElement"])(head)) {
            if (!Array.isArray(current)) return;
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isKeyedElement"])(head)) {
                current = current.find((item)=>item._key === head._key);
                continue;
            }
            current = current[head];
            continue;
        }
        current = current[head];
    }
    return current;
}
;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/toTransactions.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "applyAll",
    ()=>applyAll,
    "applyMutations",
    ()=>applyMutations,
    "createTransactionId",
    ()=>createTransactionId,
    "getMutationDocumentId",
    ()=>getMutationDocumentId,
    "rebase",
    ()=>rebase,
    "squashDMPStrings",
    ()=>squashDMPStrings,
    "squashMutationGroups",
    ()=>squashMutationGroups,
    "toTransactions",
    ()=>toTransactions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$lodash$2f$groupBy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/lodash/groupBy.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$getAtPath$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/getAtPath.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$nanoid$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/nanoid/index.browser.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$diff$2d$match$2d$patch$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/diff-match-patch/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/stringify.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$uuid$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__$3c$export__v4__as__uuid$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/uuid/node_modules/uuid/dist/esm-browser/v4.js [app-client] (ecmascript) <export default as v4> <export v4 as uuid>");
;
;
;
;
;
;
;
function getMutationDocumentId(mutation) {
    if (mutation.type === "patch") return mutation.id;
    if (mutation.type === "create") return mutation.document._id;
    if (mutation.type === "delete") return mutation.id;
    if (mutation.type === "createIfNotExists" || mutation.type === "createOrReplace") return mutation.document._id;
    throw new Error("Invalid mutation type");
}
function applyAll(current, mutation) {
    return mutation.reduce((doc, m)=>{
        const res = applyDocumentMutation(doc, m);
        if (res.status === "error") throw new Error(res.message);
        return res.status === "noop" ? doc : res.after;
    }, current);
}
function applyDocumentMutation(document, mutation) {
    if (mutation.type === "create") return create(document, mutation);
    if (mutation.type === "createIfNotExists") return createIfNotExists(document, mutation);
    if (mutation.type === "delete") return del(document, mutation);
    if (mutation.type === "createOrReplace") return createOrReplace(document, mutation);
    if (mutation.type === "patch") return patch(document, mutation);
    throw new Error(`Invalid mutation type: ${mutation.type}`);
}
function create(document, mutation) {
    if (document) return {
        status: "error",
        message: "Document already exist"
    };
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignId"])(mutation.document, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$nanoid$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["nanoid"]);
    return {
        status: "created",
        id: result._id,
        after: result
    };
}
function createIfNotExists(document, mutation) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasId"])(mutation.document) ? document ? {
        status: "noop"
    } : {
        status: "created",
        id: mutation.document._id,
        after: mutation.document
    } : {
        status: "error",
        message: "Cannot createIfNotExists on document without _id"
    };
}
function createOrReplace(document, mutation) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasId"])(mutation.document) ? document ? {
        status: "updated",
        id: mutation.document._id,
        before: document,
        after: mutation.document
    } : {
        status: "created",
        id: mutation.document._id,
        after: mutation.document
    } : {
        status: "error",
        message: "Cannot createIfNotExists on document without _id"
    };
}
function del(document, mutation) {
    return document ? mutation.id !== document._id ? {
        status: "error",
        message: "Delete mutation targeted wrong document"
    } : {
        status: "deleted",
        id: mutation.id,
        before: document,
        after: void 0
    } : {
        status: "noop"
    };
}
function patch(document, mutation) {
    if (!document) return {
        status: "error",
        message: "Cannot apply patch on nonexistent document"
    };
    const next = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyPatchMutation"])(mutation, document);
    return document === next ? {
        status: "noop"
    } : {
        status: "updated",
        id: mutation.id,
        before: document,
        after: next
    };
}
function applyMutations(mutations, documentMap, transactionId) {
    const updatedDocs = /* @__PURE__ */ Object.create(null);
    for (const mutation of mutations){
        const documentId = getMutationDocumentId(mutation);
        if (!documentId) throw new Error("Unable to get document id from mutation");
        const before = updatedDocs[documentId]?.after || documentMap.get(documentId), res = applyDocumentMutation(before, mutation);
        if (res.status === "error") throw new Error(res.message);
        res.status !== "noop" && (res.status === "updated" || res.status === "created" || res.status === "deleted") && (documentId in updatedDocs || (updatedDocs[documentId] = {
            before,
            after: void 0,
            muts: []
        }), transactionId && (res.after._rev = transactionId), documentMap.set(documentId, res.after), updatedDocs[documentId].after = res.after, updatedDocs[documentId].muts.push(mutation));
    }
    return Object.entries(updatedDocs).map(([id, { before, after, muts }])=>({
            id,
            status: after ? before ? "updated" : "created" : "deleted",
            mutations: muts,
            before,
            after
        }));
}
function takeUntilRight(arr, predicate, opts) {
    const result = [];
    for (const item of arr.slice().reverse()){
        if (predicate(item)) return result;
        result.push(item);
    }
    return result.reverse();
}
function isEqualPath(p1, p2) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(p1) === (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringify"])(p2);
}
function supersedes(later, earlier) {
    return (earlier.type === "set" || earlier.type === "unset") && (later.type === "set" || later.type === "unset");
}
function squashNodePatches(patches) {
    return compactSetIfMissingPatches(compactSetPatches(compactUnsetPatches(patches)));
}
function compactUnsetPatches(patches) {
    return patches.reduce((earlierPatches, laterPatch)=>{
        if (laterPatch.op.type !== "unset") return earlierPatches.push(laterPatch), earlierPatches;
        const unaffected = earlierPatches.filter((earlierPatch)=>!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$stringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startsWith"])(laterPatch.path, earlierPatch.path));
        return unaffected.push(laterPatch), unaffected;
    }, []);
}
function compactSetPatches(patches) {
    return patches.reduceRight((laterPatches, earlierPatch)=>(laterPatches.find((later)=>supersedes(later.op, earlierPatch.op) && isEqualPath(later.path, earlierPatch.path)) || laterPatches.unshift(earlierPatch), laterPatches), []);
}
function compactSetIfMissingPatches(patches) {
    return patches.reduce((previousPatches, laterPatch)=>laterPatch.op.type !== "setIfMissing" ? (previousPatches.push(laterPatch), previousPatches) : (takeUntilRight(previousPatches, (patch2)=>patch2.op.type === "unset").find((precedingPatch)=>precedingPatch.op.type === "setIfMissing" && isEqualPath(precedingPatch.path, laterPatch.path)) || previousPatches.push(laterPatch), previousPatches), []);
}
function compactDMPSetPatches(base, patches) {
    let edge = base;
    return patches.reduce((previousPatches, patch2)=>{
        const before = edge;
        if (edge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyNodePatch"])(patch2, edge), patch2.op.type === "set" && typeof patch2.op.value == "string") {
            const current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$getAtPath$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtPath"])(patch2.path, before);
            if (typeof current == "string") {
                const replaced = {
                    ...patch2,
                    op: {
                        type: "diffMatchPatch",
                        value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$diff$2d$match$2d$patch$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringifyPatches"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$diff$2d$match$2d$patch$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["makePatches"])(current, patch2.op.value))
                    }
                };
                return previousPatches.flatMap((ep)=>isEqualPath(ep.path, patch2.path) && ep.op.type === "diffMatchPatch" ? [] : ep).concat(replaced);
            }
        }
        return previousPatches.push(patch2), previousPatches;
    }, []);
}
function squashDMPStrings(base, mutationGroups) {
    return mutationGroups.map((mutationGroup)=>({
            ...mutationGroup,
            mutations: dmpIfyMutations(base, mutationGroup.mutations)
        }));
}
function dmpIfyMutations(store, mutations) {
    return mutations.map((mutation, i)=>{
        if (mutation.type !== "patch") return mutation;
        const base = store.get(mutation.id);
        return base ? dmpifyPatchMutation(base, mutation) : mutation;
    });
}
function dmpifyPatchMutation(base, mutation) {
    return {
        ...mutation,
        patches: compactDMPSetPatches(base, mutation.patches)
    };
}
function mergeMutationGroups(mutationGroups) {
    return chunkWhile(mutationGroups, (group)=>!group.transaction).flatMap((chunk)=>({
            ...chunk[0],
            mutations: chunk.flatMap((c)=>c.mutations)
        }));
}
function chunkWhile(arr, predicate) {
    const res = [];
    let currentChunk = [];
    return arr.forEach((item)=>{
        predicate(item) ? currentChunk.push(item) : (currentChunk.length > 0 && res.push(currentChunk), currentChunk = [], res.push([
            item
        ]));
    }), currentChunk.length > 0 && res.push(currentChunk), res;
}
function squashMutationGroups(staged) {
    return mergeMutationGroups(staged).map((transaction)=>({
            ...transaction,
            mutations: squashMutations(transaction.mutations)
        })).map((transaction)=>({
            ...transaction,
            mutations: transaction.mutations.map((mutation)=>mutation.type !== "patch" ? mutation : {
                    ...mutation,
                    patches: squashNodePatches(mutation.patches)
                })
        }));
}
function squashMutations(mutations) {
    const byDocument = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$lodash$2f$groupBy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(mutations, getMutationDocumentId);
    return Object.values(byDocument).flatMap((documentMutations)=>squashCreateIfNotExists(squashDelete(documentMutations)).flat().reduce((acc, docMutation)=>{
            const prev = acc[acc.length - 1];
            return (!prev || prev.type === "patch") && docMutation.type === "patch" ? acc.slice(0, -1).concat({
                ...docMutation,
                patches: (prev?.patches || []).concat(docMutation.patches)
            }) : acc.concat(docMutation);
        }, []));
}
function squashCreateIfNotExists(mutations) {
    return mutations.length === 0 ? mutations : mutations.reduce((previousMuts, laterMut)=>laterMut.type !== "createIfNotExists" ? (previousMuts.push(laterMut), previousMuts) : (takeUntilRight(previousMuts, (m)=>m.type === "delete").find((precedingPatch)=>precedingPatch.type === "createIfNotExists") || previousMuts.push(laterMut), previousMuts), []);
}
function squashDelete(mutations) {
    return mutations.length === 0 ? mutations : mutations.reduce((previousMuts, laterMut)=>laterMut.type === "delete" ? [
            laterMut
        ] : (previousMuts.push(laterMut), previousMuts), []);
}
function rebase(documentId, oldBase, newBase, localMutations) {
    let edge = oldBase;
    const dmpified = localMutations.map((transaction)=>{
        const mutations = transaction.mutations.flatMap((mut)=>{
            if (getMutationDocumentId(mut) !== documentId) return [];
            const before = edge;
            return edge = applyAll(edge, [
                mut
            ]), !before || mut.type !== "patch" ? mut : {
                type: "dmpified",
                mutation: {
                    ...mut,
                    // Todo: make compactDMPSetPatches return pairs of patches that was dmpified with their
                    //  original as dmpPatches and original is not 1:1 (e..g some of the original may not be dmpified)
                    dmpPatches: compactDMPSetPatches(before, mut.patches),
                    original: mut.patches
                }
            };
        });
        return {
            ...transaction,
            mutations
        };
    });
    let newBaseWithDMPForOldBaseApplied = newBase;
    return dmpified.map((transaction)=>{
        const applied = [];
        return transaction.mutations.forEach((mut)=>{
            if (mut.type === "dmpified") try {
                newBaseWithDMPForOldBaseApplied = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyPatches"])(mut.mutation.dmpPatches, newBaseWithDMPForOldBaseApplied), applied.push(mut);
            } catch  {
                console.warn("Failed to apply dmp patch, falling back to original");
                try {
                    newBaseWithDMPForOldBaseApplied = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyPatches"])(mut.mutation.original, newBaseWithDMPForOldBaseApplied), applied.push(mut);
                } catch (second) {
                    throw new Error(`Failed to apply patch for document "${documentId}": ${second.message}`, {
                        cause: second
                    });
                }
            }
            else newBaseWithDMPForOldBaseApplied = applyAll(newBaseWithDMPForOldBaseApplied, [
                mut
            ]);
        });
    }), [
        localMutations.map((transaction)=>({
                ...transaction,
                mutations: transaction.mutations.map((mut)=>mut.type !== "patch" || getMutationDocumentId(mut) !== documentId ? mut : {
                        ...mut,
                        patches: mut.patches.map((patch2)=>patch2.op.type !== "set" ? patch2 : {
                                ...patch2,
                                op: {
                                    ...patch2.op,
                                    value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$getAtPath$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtPath"])(patch2.path, newBaseWithDMPForOldBaseApplied)
                                }
                            })
                    })
            })),
        newBaseWithDMPForOldBaseApplied
    ];
}
function createTransactionId() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$uuid$2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__$3c$export__v4__as__uuid$3e$__["uuid"])();
}
function toTransactions(groups) {
    return groups.map((group)=>group.transaction && group.id !== void 0 ? {
            id: group.id,
            mutations: group.mutations
        } : {
            id: createTransactionId(),
            mutations: group.mutations
        });
}
;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_unstable_machine.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "commit",
    ()=>commit,
    "createSharedListener",
    ()=>createSharedListener,
    "documentMutatorMachine",
    ()=>documentMutatorMachine
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$toTransactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/toTransactions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$mendoza$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/mendoza/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$share$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/operators/share.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$filter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/operators/filter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$observable$2f$merge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/observable/merge.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$shareReplay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/operators/shareReplay.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$observable$2f$defer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/observable/defer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$observeOn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/operators/observeOn.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$scheduler$2f$asap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rxjs/dist/esm5/internal/scheduler/asap.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/xstate/dist/xstate.development.esm.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2d$actors$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/xstate/dist/xstate-actors.development.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$5a37e0ee$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__sendParent$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/xstate/dist/log-5a37e0ee.development.esm.js [app-client] (ecmascript) <export b as sendParent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$5a37e0ee$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__e__as__enqueueActions$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/xstate/dist/log-5a37e0ee.development.esm.js [app-client] (ecmascript) <export e as enqueueActions>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$f338cee3$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/xstate/dist/assign-f338cee3.development.esm.js [app-client] (ecmascript) <export a as assign>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$74097812$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__s__as__stopChild$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/xstate/dist/raise-74097812.development.esm.js [app-client] (ecmascript) <export s as stopChild>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$74097812$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__spawnChild$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/xstate/dist/raise-74097812.development.esm.js [app-client] (ecmascript) <export b as spawnChild>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$74097812$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__r__as__raise$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/xstate/dist/raise-74097812.development.esm.js [app-client] (ecmascript) <export r as raise>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$encode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/@sanity/mutate/dist/_chunks-es/encode.js [app-client] (ecmascript)");
;
;
;
;
;
;
function commit(results, documentMap) {
    results.forEach((result)=>{
        (result.status === "created" || result.status === "updated") && documentMap.set(result.id, result.after), result.status === "deleted" && documentMap.delete(result.id);
    });
}
function createSharedListener(client) {
    const allEvents$ = client.listen('*[!(_id in path("_.**"))]', {}, {
        events: [
            "welcome",
            "mutation",
            "reconnect"
        ],
        includeResult: !1,
        includePreviousRevision: !1,
        visibility: "transaction",
        effectFormat: "mendoza",
        includeMutations: !1
    }).pipe((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$share$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["share"])({
        resetOnRefCountZero: !0
    })), reconnect = allEvents$.pipe((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$filter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filter"])((event)=>event.type === "reconnect")), welcome = allEvents$.pipe((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$filter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filter"])((event)=>event.type === "welcome")), mutations = allEvents$.pipe((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$filter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filter"])((event)=>event.type === "mutation")), replayWelcome = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$observable$2f$merge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["merge"])(welcome, reconnect).pipe((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$shareReplay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shareReplay"])({
        bufferSize: 1,
        refCount: !0
    })).pipe((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$filter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filter"])((latestConnectionEvent)=>latestConnectionEvent.type === "welcome"));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$observable$2f$merge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["merge"])(replayWelcome, mutations, reconnect);
}
const documentMutatorMachine = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["setup"])({
    types: {},
    actions: {
        "assign error to context": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$f338cee3$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
            error: ({ event })=>event
        }),
        "clear error from context": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$f338cee3$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
            error: void 0
        }),
        "connect to server-sent events": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$74097812$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__r__as__raise$3e$__["raise"])({
            type: "connect"
        }),
        "listen to server-sent events": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$74097812$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__spawnChild$3e$__["spawnChild"])("server-sent events", {
            id: "listener",
            input: ({ context })=>({
                    listener: context.sharedListener || createSharedListener(context.client),
                    id: context.id
                })
        }),
        "stop listening to server-sent events": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$raise$2d$74097812$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__s__as__stopChild$3e$__["stopChild"])("listener"),
        "buffer remote mutation events": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$f338cee3$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
            mutationEvents: ({ event, context })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "mutation"), [
                    ...context.mutationEvents,
                    event
                ])
        }),
        "restore stashed changes": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$f338cee3$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
            stagedChanges: ({ event, context })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "xstate.done.actor.submitTransactions"), context.stashedChanges),
            stashedChanges: []
        }),
        "rebase fetched remote snapshot": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$5a37e0ee$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__e__as__enqueueActions$3e$__["enqueueActions"])(({ enqueue })=>{
            enqueue.assign(({ event, context })=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "xstate.done.actor.getDocument");
                const previousRemote = context.remote;
                let nextRemote = event.output, seenCurrentRev = !1;
                for (const patch of context.mutationEvents)!patch.effects?.apply || !patch.previousRev && patch.transition !== "appear" || (!seenCurrentRev && patch.previousRev === nextRemote?._rev && (seenCurrentRev = !0), seenCurrentRev && (nextRemote = applyMendozaPatch(nextRemote, patch.effects.apply, patch.resultRev)));
                context.cache && // If the shared cache don't have the document already we can just set it
                (!context.cache.has(context.id) || // But when it's in the cache, make sure it's necessary to update it
                context.cache.get(context.id)._rev !== nextRemote?._rev) && context.cache.set(context.id, nextRemote);
                const [stagedChanges, local] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$toTransactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rebase"])(context.id, // It's annoying to convert between null and undefined, reach consensus
                previousRemote === null ? void 0 : previousRemote, nextRemote === null ? void 0 : nextRemote, context.stagedChanges);
                return {
                    remote: nextRemote,
                    local,
                    stagedChanges,
                    // Since the snapshot handler applies all the patches they are no longer needed, allow GC
                    mutationEvents: []
                };
            }), enqueue.sendParent(({ context })=>({
                    type: "rebased.remote",
                    id: context.id,
                    document: context.remote
                }));
        }),
        "apply mendoza patch": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$f338cee3$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])(({ event, context })=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "mutation");
            const previousRemote = context.remote;
            if (event.transactionId === previousRemote?._rev) return {};
            const nextRemote = applyMendozaPatch(previousRemote, event.effects.apply, event.resultRev);
            context.cache && // If the shared cache don't have the document already we can just set it
            (!context.cache.has(context.id) || // But when it's in the cache, make sure it's necessary to update it
            context.cache.get(context.id)._rev !== nextRemote?._rev) && context.cache.set(context.id, nextRemote);
            const [stagedChanges, local] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$toTransactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rebase"])(context.id, // It's annoying to convert between null and undefined, reach consensus
            previousRemote === null ? void 0 : previousRemote, nextRemote === null ? void 0 : nextRemote, context.stagedChanges);
            return {
                remote: nextRemote,
                local,
                stagedChanges
            };
        }),
        "increment fetch attempts": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$f338cee3$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
            fetchRemoteSnapshotAttempts: ({ context })=>context.fetchRemoteSnapshotAttempts + 1
        }),
        "reset fetch attempts": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$f338cee3$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
            fetchRemoteSnapshotAttempts: 0
        }),
        "increment submit attempts": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$f338cee3$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
            submitTransactionsAttempts: ({ context })=>context.submitTransactionsAttempts + 1
        }),
        "reset submit attempts": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$f338cee3$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
            submitTransactionsAttempts: 0
        }),
        "stage mutation": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$f338cee3$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
            stagedChanges: ({ event, context })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "mutate"), [
                    ...context.stagedChanges,
                    {
                        transaction: !1,
                        mutations: event.mutations
                    }
                ])
        }),
        "stash mutation": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$assign$2d$f338cee3$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a__as__assign$3e$__["assign"])({
            stashedChanges: ({ event, context })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "mutate"), [
                    ...context.stashedChanges,
                    {
                        transaction: !1,
                        mutations: event.mutations
                    }
                ])
        }),
        "rebase local snapshot": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$5a37e0ee$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__e__as__enqueueActions$3e$__["enqueueActions"])(({ enqueue })=>{
            enqueue.assign({
                local: ({ event, context })=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "mutate");
                    const localDataset = /* @__PURE__ */ new Map();
                    context.local && localDataset.set(context.id, context.local);
                    const results = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$toTransactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyMutations"])(event.mutations, localDataset);
                    return commit(results, localDataset), localDataset.get(context.id);
                }
            }), enqueue.sendParent(({ context })=>({
                    type: "rebased.local",
                    id: context.id,
                    document: context.local
                }));
        }),
        "send pristine event to parent": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$5a37e0ee$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__sendParent$3e$__["sendParent"])(({ context })=>({
                type: "pristine",
                id: context.id
            })),
        "send sync event to parent": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$5a37e0ee$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__sendParent$3e$__["sendParent"])(({ context })=>({
                type: "sync",
                id: context.id,
                document: context.remote
            })),
        "send mutation event to parent": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$log$2d$5a37e0ee$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b__as__sendParent$3e$__["sendParent"])(({ context, event })=>((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assertEvent"])(event, "mutation"), {
                type: "mutation",
                id: context.id,
                previousRev: event.previousRev,
                resultRev: event.resultRev,
                effects: event.effects
            }))
    },
    actors: {
        "server-sent events": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2d$actors$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromEventObservable"])(({ input })=>{
            const { listener, id } = input;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$observable$2f$defer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defer"])(()=>listener).pipe((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$filter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filter"])((event)=>event.type === "welcome" || event.type === "reconnect" || event.type === "mutation" && event.documentId === id), // This is necessary to avoid sync emitted events from `shareReplay` from happening before the actor is ready to receive them
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$operators$2f$observeOn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["observeOn"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rxjs$2f$dist$2f$esm5$2f$internal$2f$scheduler$2f$asap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asapScheduler"]));
        }),
        "fetch remote snapshot": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2d$actors$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromPromise"])(async ({ input, signal })=>{
            const { client, id } = input;
            return await client.getDocument(id, {
                signal
            }).catch((e)=>{
                if (!(e instanceof Error && e.name === "AbortError")) throw e;
            });
        }),
        "submit mutations as transactions": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$xstate$2f$dist$2f$xstate$2d$actors$2e$development$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromPromise"])(async ({ input, signal })=>{
            const { client, transactions } = input;
            for (const transaction of transactions){
                if (signal.aborted) return;
                await client.dataRequest("mutate", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$encode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodeTransaction"])(transaction), {
                    visibility: "async",
                    returnDocuments: !1,
                    signal
                }).catch((e)=>{
                    if (!(e instanceof Error && e.name === "AbortError")) throw e;
                });
            }
        })
    },
    delays: {
        // Exponential backoff delay function
        fetchRemoteSnapshotTimeout: ({ context })=>Math.pow(2, context.fetchRemoteSnapshotAttempts) * 1e3,
        submitTransactionsTimeout: ({ context })=>Math.pow(2, context.submitTransactionsAttempts) * 1e3
    }
}).createMachine({
    /** @xstate-layout N4IgpgJg5mDOIC5QQPYGMCuBbMA7ALgLRYb4CG+KATgMQnn5gDaADALqKgAOKsAlvj4pcnEAA9EADhYAWAHQA2GSwUBmAKwBOaQEZJkhQBoQAT0Q6ATAF8rx1JhwFipCtTkQ+sNMNxg0jCBpvXF9-Vg4kEB5+QWFRCQQLFhY5PQB2dRU1SQsdGSVjMwRlHTkWNM00nR1VKryKmzt0bDwielcqOWDQwVwoGgB3MAAbbxxw0WiBIRFIhPUKuQ1NVU0tTU0WFdVCxAt1dTlNhX2WdRltGUk061sQexandspO7r9e-qo-H3eJyKnYrNQPNJJollpVutNttdghVCo5MoTgoMpo8jIkqpGvdmo42i4Xl0fv4+H0aGAqFRqH9uLxpnE5ogFrCLFd5CtNBYFJkdOpuaosXcHnjnAw3G9-AAxMh8YYYL5BYn4GlROmA+KIFEs1R6ORpZYWHIXGR6bHC1qijpyL4Sj6DEZjZjsSZqmYaxK1ORcvlc-ZqSoyNKwnRpGTyK4WDK5BQ6BQ5BRm3EW55uG1K0n9ClUqgqgFuxketJe7nIv2rUNB0x7LmSL2qGMsSySevcmSJhzJgnipWQOgEma510M4HmcqHZYyWqaOMqTQyWGh0osVSGiwC5uGyftx74sWvHuBNMhX7O-5DoHiPae72lvnlwPBydFlRVS7qPIl7cilP74-+SByMMKBkB4ZKoL4cikgAbigADWYByDA+AACJJgQg4xPmI7FHkZQrKGsjqKcCiaMG9YpJOxySBiCiyPoX6dnuRJ-gEgHAaBmaUm4XDDBQABm1BYIhYAoWhyqnrSmHDpeCAKCicjUbU6g6nkFichYsJrLWVxaPsk7KdICZCmJlqEraAFASBvbPAOEmqlJF4JJURbVDcy4Yvk1GVkUsabApMjKZGqjNg2kgMU8Xa-j0FnsQBXBUJ4vRgH2DBOhEkn0o5TLKV6y6WDG6lhkYVYIDoKzyBkeR8pUDZqOFu5WuZEBsVZzUeFQ+AmDQsAYAARlgAgYZl7o6I2tYLJINSSO+3JaMGlQpGkhFhryo2jW2xkdhFTFNS1EAAT1-UCHa4EIdBcEIYdA34AAKlQZC4LAZAksIsBDeqBbrdpym8iuByxlcLK5BYqQLBUZyTcFvL1aZ3YsTFrVyFdx0ZuSXGdDx-GCUjfXXXdD1PS9j3vVhMnrWCFRxtNaRLdcfIsiwuS5fkgZaOUlhpDDP7MdFzWWftzXI-gdrPGlLoOSNyiHFstRySisjcgzahyFoUYBbRsac5tO6w1F7wIwLONHfg0qyvKyVfPgVAmCT0kJGt41pJD02xgcpElUkcZ6rI+q5JcckbU0W0NWZB57QduMCKbcoKmIsCpXIZB8YwVAABRC-jj3PYCsA3XwOAoKQACUNDmttjVh-zEfG9H5u21lpVjSrTtTTNbsstUYJJAFWgA37XORTz+t8+xtcKpb1v1+6KJFopGQqRi6nBlstYcqNK5riusYDztlejzKMfJXHCdJynqd8SJaAABYAEpgFgKCMAAyrgZBcLAV+P3nBfF6XJnc7tfmY8xZnglgWGe-klILzUhYDSJVRpnCONNOcWxWRKBRDYO4uAUD7XgJEMuIdqDi2GgWQgOhgxMyRKyFc8IuQkXUDvK0HgvAHmIR9bCD4SoeSWCoLkoZpxrmXIw0OLEMxsNJgkSc418KhnrHyG4oZYTcPhMifhJx4SCiDjrABSpgHiLtogAUhwW77DRIGXkk55wexKCrJQsg1jBTnPsYRqZviiL6PohuORgyhhBhGKMsZYzxhcXrf8EBPHulUJOPCtRlABWIu7IoORVBIIhMpNYGJyghKHmEvaYjQEkOwhkxQrJtBES0JDOBPlkgKD1JYZSjZORyTXNkwBsVwkFPYTJVYS58JxPKbOYM0gUj7FjGcEMOpciaJxMHXWOTWJV2avFRKpIwARILJRGJBF4mZBIkDE0KtIxLSSDkDYGhWl70Ru1Tq6zsLURBkoLyWRmz8PmlUZmcY1zXDKdMghcy2mIyFh8W5ZN4RFmOFyKaZwiLeT2GVJcy5pBrguCiMK2tvyDwBYbIWejOkSMQBkeQORJq0RNCUDIDNondxuGpPQmRqIXPhiPECuKMpdMkbILZ-SEnLxyjqOJMZsj1jRTYIAA */ id: "document-mutator",
    context: ({ input })=>({
            client: input.client.withConfig({
                allowReconfigure: !1
            }),
            sharedListener: input.sharedListener,
            id: input.id,
            remote: void 0,
            local: void 0,
            mutationEvents: [],
            stagedChanges: [],
            stashedChanges: [],
            error: void 0,
            fetchRemoteSnapshotAttempts: 0,
            submitTransactionsAttempts: 0,
            cache: input.cache
        }),
    // Auto start the connection by default
    entry: [
        "connect to server-sent events"
    ],
    on: {
        mutate: {
            actions: [
                "rebase local snapshot",
                "stage mutation"
            ]
        }
    },
    initial: "disconnected",
    states: {
        disconnected: {
            on: {
                connect: {
                    target: "connecting",
                    actions: [
                        "listen to server-sent events"
                    ]
                }
            }
        },
        connecting: {
            on: {
                welcome: "connected",
                reconnect: "reconnecting",
                error: "connectFailure"
            },
            tags: [
                "busy"
            ]
        },
        connectFailure: {
            on: {
                connect: {
                    target: "connecting",
                    actions: [
                        "listen to server-sent events"
                    ]
                }
            },
            entry: [
                "stop listening to server-sent events",
                "assign error to context"
            ],
            exit: [
                "clear error from context"
            ],
            tags: [
                "error"
            ]
        },
        reconnecting: {
            on: {
                welcome: {
                    target: "connected"
                },
                error: {
                    target: "connectFailure"
                }
            },
            tags: [
                "busy",
                "error"
            ]
        },
        connected: {
            on: {
                mutation: {
                    actions: [
                        "buffer remote mutation events"
                    ]
                },
                reconnect: "reconnecting"
            },
            entry: [
                "clear error from context"
            ],
            initial: "loading",
            states: {
                loading: {
                    invoke: {
                        src: "fetch remote snapshot",
                        id: "getDocument",
                        input: ({ context })=>({
                                client: context.client,
                                id: context.id
                            }),
                        onError: {
                            target: "loadFailure"
                        },
                        onDone: {
                            target: "loaded",
                            actions: [
                                "rebase fetched remote snapshot",
                                "reset fetch attempts"
                            ]
                        }
                    },
                    tags: [
                        "busy"
                    ]
                },
                loaded: {
                    entry: [
                        "send sync event to parent"
                    ],
                    on: {
                        mutation: {
                            actions: [
                                "apply mendoza patch",
                                "send mutation event to parent"
                            ]
                        }
                    },
                    initial: "pristine",
                    states: {
                        pristine: {
                            on: {
                                mutate: {
                                    actions: [
                                        "rebase local snapshot",
                                        "stage mutation"
                                    ],
                                    target: "dirty"
                                }
                            },
                            tags: [
                                "ready"
                            ]
                        },
                        dirty: {
                            on: {
                                submit: "submitting"
                            },
                            tags: [
                                "ready"
                            ]
                        },
                        submitting: {
                            on: {
                                mutate: {
                                    actions: [
                                        "rebase local snapshot",
                                        "stash mutation"
                                    ]
                                }
                            },
                            invoke: {
                                src: "submit mutations as transactions",
                                id: "submitTransactions",
                                input: ({ context })=>{
                                    const remoteDataset = /* @__PURE__ */ new Map();
                                    return remoteDataset.set(context.id, context.remote), {
                                        client: context.client,
                                        transactions: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$toTransactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTransactions"])(// Squashing DMP strings is the last thing we do before submitting
                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$toTransactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["squashDMPStrings"])(remoteDataset, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f40$sanity$2f$mutate$2f$dist$2f$_chunks$2d$es$2f$toTransactions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["squashMutationGroups"])(context.stagedChanges)))
                                    };
                                },
                                onError: {
                                    target: "submitFailure"
                                },
                                onDone: {
                                    target: "pristine",
                                    actions: [
                                        "restore stashed changes",
                                        "reset submit attempts",
                                        "send pristine event to parent"
                                    ]
                                }
                            },
                            /**
               * 'busy' means we should show a spinner, 'ready' means we can still accept mutations, they'll be applied optimistically right away, and queued for submissions after the current submission settles
               */ tags: [
                                "busy",
                                "ready"
                            ]
                        },
                        submitFailure: {
                            exit: [
                                "clear error from context"
                            ],
                            after: {
                                submitTransactionsTimeout: {
                                    actions: [
                                        "increment submit attempts"
                                    ],
                                    target: "submitting"
                                }
                            },
                            on: {
                                retry: "submitting"
                            },
                            /**
               * How can it be both `ready` and `error`? `ready` means it can receive mutations, optimistically apply them, and queue them for submission. `error` means it failed to submit previously applied mutations.
               * It's completely fine to keep queueing up more mutations and applying them optimistically, while showing UI that notifies that mutations didn't submit, and show a count down until the next automatic retry.
               */ tags: [
                                "error",
                                "ready"
                            ]
                        }
                    }
                },
                loadFailure: {
                    exit: [
                        "clear error from context"
                    ],
                    after: {
                        fetchRemoteSnapshotTimeout: {
                            actions: [
                                "increment fetch attempts"
                            ],
                            target: "loading"
                        }
                    },
                    on: {
                        retry: "loading"
                    },
                    tags: [
                        "error"
                    ]
                }
            }
        }
    }
});
function applyMendozaPatch(document, patch, nextRevision) {
    const next = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$mendoza$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyPatch"])(omitRev(document), patch);
    return next ? Object.assign(next, {
        _rev: nextRevision
    }) : null;
}
function omitRev(document) {
    if (!document) return null;
    const { _rev, ...doc } = document;
    return doc;
}
;
}),
"[project]/node_modules/@sanity/visual-editing-csm/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createDataAttribute",
    ()=>createDataAttribute,
    "decodeSanityNodeData",
    ()=>decodeSanityNodeData,
    "encodeSanityNodeData",
    ()=>encodeSanityNodeData,
    "pathToUrlString",
    ()=>pathToUrlString,
    "urlStringToPath",
    ()=>urlStringToPath
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$resolveEditInfo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/client/dist/_chunks-es/resolveEditInfo.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing-csm/node_modules/valibot/dist/index.mjs [app-client] (ecmascript)");
;
;
const lengthyStr$1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pipe"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["string"])(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["minLength"])(1)), optionalLengthyStr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optional"])(lengthyStr$1), sanityNodeSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["object"])({
    baseUrl: lengthyStr$1,
    dataset: optionalLengthyStr,
    id: lengthyStr$1,
    path: lengthyStr$1,
    projectId: optionalLengthyStr,
    tool: optionalLengthyStr,
    type: optionalLengthyStr,
    workspace: optionalLengthyStr,
    perspective: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fallback"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["string"])(), "drafts")
});
function isValidSanityNode(node) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["is"])(sanityNodeSchema, node);
}
function isArray(value) {
    return value !== null && Array.isArray(value);
}
function pathToUrlString(path) {
    let str = "";
    for (const segment of path){
        if (typeof segment == "string") {
            str && (str += "."), str += segment;
            continue;
        }
        if (typeof segment == "number") {
            str && (str += ":"), str += `${segment}`;
            continue;
        }
        if (isArray(segment)) {
            str && (str += ":"), str += `${segment.join(",")}}`;
            continue;
        }
        if (segment._key) {
            str && (str += ":"), str += `${segment._key}`;
            continue;
        }
    }
    return str;
}
function encodeSanityNodeData(node) {
    const { id: _id, path, baseUrl, tool, workspace, type } = node;
    return isValidSanityNode(node) ? [
        [
            "id",
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$resolveEditInfo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPublishedId"])(_id)
        ],
        [
            "type",
            type
        ],
        [
            "path",
            pathToUrlString(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$resolveEditInfo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioPath"].fromString(path))
        ],
        [
            "base",
            encodeURIComponent(baseUrl)
        ],
        [
            "workspace",
            workspace
        ],
        [
            "tool",
            tool
        ]
    ].filter(([, value])=>!!value).map((part)=>part.join("=")).join(";") : void 0;
}
function createDataAttribute(props) {
    function normalizePath(path) {
        return path ? typeof path == "string" ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$resolveEditInfo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioPath"].fromString(path) : path : [];
    }
    function toString(props2) {
        if (!props2.id) throw new Error("`id` is required to create a data attribute");
        if (!props2.type) throw new Error("`type` is required to create a data attribute");
        if (!props2.path || !props2.path.length) throw new Error("`path` is required to create a data attribute");
        const attrs = {
            baseUrl: props2.baseUrl || "/",
            workspace: props2.workspace,
            tool: props2.tool,
            type: props2.type,
            id: props2.id,
            path: typeof props2.path == "string" ? props2.path : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$resolveEditInfo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioPath"].toString(props2.path),
            perspective: props2.perspective
        };
        return encodeSanityNodeData(attrs);
    }
    const DataAttribute = (path)=>toString({
            ...props,
            path: [
                ...normalizePath(props.path),
                ...normalizePath(path)
            ]
        });
    return DataAttribute.toString = function() {
        return toString(props);
    }, DataAttribute.combine = function(attrs) {
        return createDataAttribute({
            ...props,
            ...attrs
        });
    }, DataAttribute.scope = function(path) {
        return createDataAttribute({
            ...props,
            path: [
                ...normalizePath(props.path),
                ...normalizePath(path)
            ]
        });
    }, DataAttribute;
}
const RE_SEGMENT_WITH_INDEX = /^([\w-]+):(0|[1-9][0-9]*)$/, RE_SEGMENT_WITH_TUPLE = /^([\w-]+):([0-9]+),([0-9]+)$/, RE_SEGMENT_WITH_KEY = /^([\w-]+):([\w-]+)$/;
function urlStringToPath(str) {
    const path = [];
    for (const segment of str.split(".")){
        const withIndex = RE_SEGMENT_WITH_INDEX.exec(segment);
        if (withIndex) {
            path.push(withIndex[1], Number(withIndex[2]));
            continue;
        }
        const withTuple = RE_SEGMENT_WITH_TUPLE.exec(segment);
        if (withTuple) {
            path.push(withTuple[1], [
                Number(withTuple[2]),
                Number(withTuple[3])
            ]);
            continue;
        }
        const withKey = RE_SEGMENT_WITH_KEY.exec(segment);
        if (withKey) {
            path.push(withKey[1], {
                _key: withKey[2]
            });
            continue;
        }
        path.push(segment);
    }
    return path;
}
const lengthyStr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pipe"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["string"])(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["minLength"])(1)), sanityLegacyNodeSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["object"])({
    origin: lengthyStr,
    href: lengthyStr,
    data: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optional"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["record"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["string"])(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unknown"])()))
});
function decodeSanityString(str) {
    const data = str.split(";").reduce((acc, segment)=>{
        const [key, value] = segment.split("=");
        if (!key || segment.includes("=") && !value) return acc;
        switch(key){
            case "id":
                acc.id = value;
                break;
            case "type":
                acc.type = value;
                break;
            case "path":
                acc.path = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$resolveEditInfo$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studioPath"].toString(urlStringToPath(value));
                break;
            case "base":
                acc.baseUrl = decodeURIComponent(value);
                break;
            case "perspective":
                acc.perspective = value;
                break;
            case "tool":
                acc.tool = value;
                break;
            case "workspace":
                acc.workspace = value;
                break;
            case "projectId":
                acc.projectId = value;
                break;
            case "dataset":
                acc.dataset = value;
                break;
        }
        return acc;
    }, {});
    if (isValidSanityNode(data)) return data;
}
function decodeSanityObject(data) {
    const sanityNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParse"])(sanityNodeSchema, data);
    if (sanityNode.success) return sanityNode.output;
    const sanityLegacyNode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safeParse"])(sanityLegacyNodeSchema, data);
    if (sanityLegacyNode.success) try {
        const url = new URL(sanityLegacyNode.output.href, typeof document > "u" ? "https://example.com" : location.origin);
        return url.searchParams.size > 0 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2d$csm$2f$node_modules$2f$valibot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parse"])(sanityNodeSchema, Object.fromEntries(url.searchParams.entries())) : sanityLegacyNode.output;
    } catch (err) {
        return console.error("Failed to parse sanity node", err), sanityLegacyNode.output;
    }
}
function decodeSanityNodeData(data) {
    if (typeof data == "object" && data !== null) return decodeSanityObject(data);
    try {
        const obj = JSON.parse(data);
        return decodeSanityObject(obj);
    } catch  {
        return decodeSanityString(data);
    }
}
;
}),
"[project]/node_modules/@vercel/stega/dist/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VERCEL_STEGA_REGEX",
    ()=>x,
    "legacyStegaEncode",
    ()=>C,
    "vercelStegaClean",
    ()=>w,
    "vercelStegaCombine",
    ()=>y,
    "vercelStegaDecode",
    ()=>X,
    "vercelStegaDecodeAll",
    ()=>M,
    "vercelStegaEncode",
    ()=>A,
    "vercelStegaSplit",
    ()=>P
]);
var p = {
    0: 8203,
    1: 8204,
    2: 8205,
    3: 8290,
    4: 8291,
    5: 8288,
    6: 65279,
    7: 8289,
    8: 119155,
    9: 119156,
    a: 119157,
    b: 119158,
    c: 119159,
    d: 119160,
    e: 119161,
    f: 119162
}, l = {
    0: 8203,
    1: 8204,
    2: 8205,
    3: 65279
}, d = {
    0: String.fromCodePoint(l[0]),
    1: String.fromCodePoint(l[1]),
    2: String.fromCodePoint(l[2]),
    3: String.fromCodePoint(l[3])
}, u = new Array(4).fill(String.fromCodePoint(l[0])).join(""), g = String.fromCharCode(0);
function A(e) {
    let r = JSON.stringify(e), t = new TextEncoder().encode(r), i = "";
    for(let c = 0; c < t.length; c++){
        let n = t[c];
        i += d[n >> 6 & 3] + d[n >> 4 & 3] + d[n >> 2 & 3] + d[n & 3];
    }
    return u + i;
}
function C(e) {
    let r = JSON.stringify(e);
    return Array.from(r).map((t)=>{
        let i = t.charCodeAt(0);
        if (i > 255) throw new Error(`Only ASCII edit info can be encoded. Error attempting to encode ${r} on character ${t} (${i})`);
        return Array.from(i.toString(16).padStart(2, "0")).map((c)=>String.fromCodePoint(p[c])).join("");
    }).join("");
}
function I(e) {
    return !Number.isNaN(Number(e)) || /[a-z]/i.test(e) && !/\d+(?:[-:\/]\d+){2}(?:T\d+(?:[-:\/]\d+){1,2}(\.\d+)?Z?)?/.test(e) ? !1 : !!Date.parse(e);
}
function S(e) {
    try {
        new URL(e, e.startsWith("/") ? "https://acme.com" : void 0);
    } catch  {
        return !1;
    }
    return !0;
}
function y(e, r, t = "auto") {
    return t === !0 || t === "auto" && (I(e) || S(e)) ? e : `${e}${A(r)}`;
}
var m = Object.fromEntries(Object.entries(d).map((e)=>[
        e[1],
        +e[0]
    ])), T = Object.fromEntries(Object.entries(p).map((e)=>e.reverse())), h = `${Object.values(p).map((e)=>`\\u{${e.toString(16)}}`).join("")}`, x = new RegExp(`[${h}]{4,}`, "gu");
function X(e) {
    let r = e.match(x);
    if (r) return E(r[0], !0)[0];
}
function M(e) {
    let r = e.match(x);
    if (r) return r.map((t)=>E(t)).flat();
}
function E(e, r = !1) {
    let t = Array.from(e), i = 1 / 0, c = -1;
    for(let n = 0; n < t.length; ++n)t[n] === u[0] && t[n + 1] === u[1] && t[n + 2] === u[2] && t[n + 3] === u[3] && (i = Math.min(i, n), c = Math.max(c, n));
    if (c === -1) return _(t, r);
    for(let n = i; n <= c; ++n)if (!((t.length - n) % 4)) try {
        let f = t.slice(n + 4), s = new Uint8Array(f.length / 4);
        for(let o = 0; o < s.length; o++)s[o] = m[f[o * 4]] << 6 | m[f[o * 4 + 1]] << 4 | m[f[o * 4 + 2]] << 2 | m[f[o * 4 + 3]];
        let a = new TextDecoder().decode(s);
        if (r) {
            let o = a.indexOf(g);
            return o === -1 && (o = a.length), [
                JSON.parse(a.slice(0, o))
            ];
        }
        return a.split(g).filter(Boolean).map((o)=>JSON.parse(o));
    } catch  {}
    return [];
}
function _(e, r) {
    var f;
    let t = [];
    for(let s = e.length * .5; s--;){
        let a = `${T[e[s * 2].codePointAt(0)]}${T[e[s * 2 + 1].codePointAt(0)]}`;
        t.unshift(String.fromCharCode(parseInt(a, 16)));
    }
    let i = [], c = [
        t.join("")
    ], n = 10;
    for(; c.length;){
        let s = c.shift();
        try {
            if (i.push(JSON.parse(s)), r) return i;
        } catch (a) {
            if (!n--) throw a;
            let o = +((f = a.message.match(/\sposition\s(\d+)$/)) == null ? void 0 : f[1]);
            if (!o) throw a;
            c.unshift(s.substring(0, o), s.substring(o));
        }
    }
    return i;
}
function P(e) {
    var r;
    return {
        cleaned: e.replace(x, ""),
        encoded: ((r = e.match(x)) == null ? void 0 : r[0]) || ""
    };
}
function w(e) {
    return e && JSON.parse(P(JSON.stringify(e)).cleaned);
}
;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_arrayReduce.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/**
 * A specialized version of `_.reduce` for arrays without support for
 * iteratee shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @param {*} [accumulator] The initial value.
 * @param {boolean} [initAccum] Specify using the first element of `array` as
 *  the initial value.
 * @returns {*} Returns the accumulated value.
 */ function arrayReduce(array, iteratee, accumulator, initAccum) {
    var index = -1, length = array == null ? 0 : array.length;
    if (initAccum && length) {
        accumulator = array[++index];
    }
    while(++index < length){
        accumulator = iteratee(accumulator, array[index], index, array);
    }
    return accumulator;
}
const __TURBOPACK__default__export__ = arrayReduce;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_basePropertyOf.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/**
 * The base implementation of `_.propertyOf` without support for deep paths.
 *
 * @private
 * @param {Object} object The object to query.
 * @returns {Function} Returns the new accessor function.
 */ function basePropertyOf(object) {
    return function(key) {
        return object == null ? undefined : object[key];
    };
}
const __TURBOPACK__default__export__ = basePropertyOf;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_deburrLetter.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_basePropertyOf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_basePropertyOf.js [app-client] (ecmascript)");
;
/** Used to map Latin Unicode letters to basic Latin letters. */ var deburredLetters = {
    // Latin-1 Supplement block.
    '\xc0': 'A',
    '\xc1': 'A',
    '\xc2': 'A',
    '\xc3': 'A',
    '\xc4': 'A',
    '\xc5': 'A',
    '\xe0': 'a',
    '\xe1': 'a',
    '\xe2': 'a',
    '\xe3': 'a',
    '\xe4': 'a',
    '\xe5': 'a',
    '\xc7': 'C',
    '\xe7': 'c',
    '\xd0': 'D',
    '\xf0': 'd',
    '\xc8': 'E',
    '\xc9': 'E',
    '\xca': 'E',
    '\xcb': 'E',
    '\xe8': 'e',
    '\xe9': 'e',
    '\xea': 'e',
    '\xeb': 'e',
    '\xcc': 'I',
    '\xcd': 'I',
    '\xce': 'I',
    '\xcf': 'I',
    '\xec': 'i',
    '\xed': 'i',
    '\xee': 'i',
    '\xef': 'i',
    '\xd1': 'N',
    '\xf1': 'n',
    '\xd2': 'O',
    '\xd3': 'O',
    '\xd4': 'O',
    '\xd5': 'O',
    '\xd6': 'O',
    '\xd8': 'O',
    '\xf2': 'o',
    '\xf3': 'o',
    '\xf4': 'o',
    '\xf5': 'o',
    '\xf6': 'o',
    '\xf8': 'o',
    '\xd9': 'U',
    '\xda': 'U',
    '\xdb': 'U',
    '\xdc': 'U',
    '\xf9': 'u',
    '\xfa': 'u',
    '\xfb': 'u',
    '\xfc': 'u',
    '\xdd': 'Y',
    '\xfd': 'y',
    '\xff': 'y',
    '\xc6': 'Ae',
    '\xe6': 'ae',
    '\xde': 'Th',
    '\xfe': 'th',
    '\xdf': 'ss',
    // Latin Extended-A block.
    '\u0100': 'A',
    '\u0102': 'A',
    '\u0104': 'A',
    '\u0101': 'a',
    '\u0103': 'a',
    '\u0105': 'a',
    '\u0106': 'C',
    '\u0108': 'C',
    '\u010a': 'C',
    '\u010c': 'C',
    '\u0107': 'c',
    '\u0109': 'c',
    '\u010b': 'c',
    '\u010d': 'c',
    '\u010e': 'D',
    '\u0110': 'D',
    '\u010f': 'd',
    '\u0111': 'd',
    '\u0112': 'E',
    '\u0114': 'E',
    '\u0116': 'E',
    '\u0118': 'E',
    '\u011a': 'E',
    '\u0113': 'e',
    '\u0115': 'e',
    '\u0117': 'e',
    '\u0119': 'e',
    '\u011b': 'e',
    '\u011c': 'G',
    '\u011e': 'G',
    '\u0120': 'G',
    '\u0122': 'G',
    '\u011d': 'g',
    '\u011f': 'g',
    '\u0121': 'g',
    '\u0123': 'g',
    '\u0124': 'H',
    '\u0126': 'H',
    '\u0125': 'h',
    '\u0127': 'h',
    '\u0128': 'I',
    '\u012a': 'I',
    '\u012c': 'I',
    '\u012e': 'I',
    '\u0130': 'I',
    '\u0129': 'i',
    '\u012b': 'i',
    '\u012d': 'i',
    '\u012f': 'i',
    '\u0131': 'i',
    '\u0134': 'J',
    '\u0135': 'j',
    '\u0136': 'K',
    '\u0137': 'k',
    '\u0138': 'k',
    '\u0139': 'L',
    '\u013b': 'L',
    '\u013d': 'L',
    '\u013f': 'L',
    '\u0141': 'L',
    '\u013a': 'l',
    '\u013c': 'l',
    '\u013e': 'l',
    '\u0140': 'l',
    '\u0142': 'l',
    '\u0143': 'N',
    '\u0145': 'N',
    '\u0147': 'N',
    '\u014a': 'N',
    '\u0144': 'n',
    '\u0146': 'n',
    '\u0148': 'n',
    '\u014b': 'n',
    '\u014c': 'O',
    '\u014e': 'O',
    '\u0150': 'O',
    '\u014d': 'o',
    '\u014f': 'o',
    '\u0151': 'o',
    '\u0154': 'R',
    '\u0156': 'R',
    '\u0158': 'R',
    '\u0155': 'r',
    '\u0157': 'r',
    '\u0159': 'r',
    '\u015a': 'S',
    '\u015c': 'S',
    '\u015e': 'S',
    '\u0160': 'S',
    '\u015b': 's',
    '\u015d': 's',
    '\u015f': 's',
    '\u0161': 's',
    '\u0162': 'T',
    '\u0164': 'T',
    '\u0166': 'T',
    '\u0163': 't',
    '\u0165': 't',
    '\u0167': 't',
    '\u0168': 'U',
    '\u016a': 'U',
    '\u016c': 'U',
    '\u016e': 'U',
    '\u0170': 'U',
    '\u0172': 'U',
    '\u0169': 'u',
    '\u016b': 'u',
    '\u016d': 'u',
    '\u016f': 'u',
    '\u0171': 'u',
    '\u0173': 'u',
    '\u0174': 'W',
    '\u0175': 'w',
    '\u0176': 'Y',
    '\u0177': 'y',
    '\u0178': 'Y',
    '\u0179': 'Z',
    '\u017b': 'Z',
    '\u017d': 'Z',
    '\u017a': 'z',
    '\u017c': 'z',
    '\u017e': 'z',
    '\u0132': 'IJ',
    '\u0133': 'ij',
    '\u0152': 'Oe',
    '\u0153': 'oe',
    '\u0149': "'n",
    '\u017f': 's'
};
/**
 * Used by `_.deburr` to convert Latin-1 Supplement and Latin Extended-A
 * letters to basic Latin letters.
 *
 * @private
 * @param {string} letter The matched letter to deburr.
 * @returns {string} Returns the deburred letter.
 */ var deburrLetter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_basePropertyOf$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(deburredLetters);
const __TURBOPACK__default__export__ = deburrLetter;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_freeGlobal.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/** Detect free variable `global` from Node.js. */ var freeGlobal = ("TURBOPACK compile-time value", "object") == 'object' && /*TURBOPACK member replacement*/ __turbopack_context__.g && /*TURBOPACK member replacement*/ __turbopack_context__.g.Object === Object && /*TURBOPACK member replacement*/ __turbopack_context__.g;
const __TURBOPACK__default__export__ = freeGlobal;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_root.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_freeGlobal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_freeGlobal.js [app-client] (ecmascript)");
;
/** Detect free variable `self`. */ var freeSelf = typeof self == 'object' && self && self.Object === Object && self;
/** Used as a reference to the global object. */ var root = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_freeGlobal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] || freeSelf || Function('return this')();
const __TURBOPACK__default__export__ = root;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_Symbol.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_root$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_root.js [app-client] (ecmascript)");
;
/** Built-in value references. */ var Symbol = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_root$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Symbol;
const __TURBOPACK__default__export__ = Symbol;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_arrayMap.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/**
 * A specialized version of `_.map` for arrays without support for iteratee
 * shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns the new mapped array.
 */ function arrayMap(array, iteratee) {
    var index = -1, length = array == null ? 0 : array.length, result = Array(length);
    while(++index < length){
        result[index] = iteratee(array[index], index, array);
    }
    return result;
}
const __TURBOPACK__default__export__ = arrayMap;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/isArray.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/**
 * Checks if `value` is classified as an `Array` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array, else `false`.
 * @example
 *
 * _.isArray([1, 2, 3]);
 * // => true
 *
 * _.isArray(document.body.children);
 * // => false
 *
 * _.isArray('abc');
 * // => false
 *
 * _.isArray(_.noop);
 * // => false
 */ var isArray = Array.isArray;
const __TURBOPACK__default__export__ = isArray;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_getRawTag.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_Symbol$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_Symbol.js [app-client] (ecmascript)");
;
/** Used for built-in method references. */ var objectProto = Object.prototype;
/** Used to check objects for own properties. */ var hasOwnProperty = objectProto.hasOwnProperty;
/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */ var nativeObjectToString = objectProto.toString;
/** Built-in value references. */ var symToStringTag = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_Symbol$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_Symbol$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].toStringTag : undefined;
/**
 * A specialized version of `baseGetTag` which ignores `Symbol.toStringTag` values.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the raw `toStringTag`.
 */ function getRawTag(value) {
    var isOwn = hasOwnProperty.call(value, symToStringTag), tag = value[symToStringTag];
    try {
        value[symToStringTag] = undefined;
        var unmasked = true;
    } catch (e) {}
    var result = nativeObjectToString.call(value);
    if (unmasked) {
        if (isOwn) {
            value[symToStringTag] = tag;
        } else {
            delete value[symToStringTag];
        }
    }
    return result;
}
const __TURBOPACK__default__export__ = getRawTag;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_objectToString.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/** Used for built-in method references. */ var objectProto = Object.prototype;
/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */ var nativeObjectToString = objectProto.toString;
/**
 * Converts `value` to a string using `Object.prototype.toString`.
 *
 * @private
 * @param {*} value The value to convert.
 * @returns {string} Returns the converted string.
 */ function objectToString(value) {
    return nativeObjectToString.call(value);
}
const __TURBOPACK__default__export__ = objectToString;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_baseGetTag.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_Symbol$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_Symbol.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_getRawTag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_getRawTag.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_objectToString$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_objectToString.js [app-client] (ecmascript)");
;
;
;
/** `Object#toString` result references. */ var nullTag = '[object Null]', undefinedTag = '[object Undefined]';
/** Built-in value references. */ var symToStringTag = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_Symbol$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_Symbol$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].toStringTag : undefined;
/**
 * The base implementation of `getTag` without fallbacks for buggy environments.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the `toStringTag`.
 */ function baseGetTag(value) {
    if (value == null) {
        return value === undefined ? undefinedTag : nullTag;
    }
    return symToStringTag && symToStringTag in Object(value) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_getRawTag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(value) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_objectToString$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(value);
}
const __TURBOPACK__default__export__ = baseGetTag;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/isObjectLike.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */ function isObjectLike(value) {
    return value != null && typeof value == 'object';
}
const __TURBOPACK__default__export__ = isObjectLike;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/isSymbol.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_baseGetTag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_baseGetTag.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$isObjectLike$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/isObjectLike.js [app-client] (ecmascript)");
;
;
/** `Object#toString` result references. */ var symbolTag = '[object Symbol]';
/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */ function isSymbol(value) {
    return typeof value == 'symbol' || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$isObjectLike$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(value) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_baseGetTag$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(value) == symbolTag;
}
const __TURBOPACK__default__export__ = isSymbol;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_baseToString.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_Symbol$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_Symbol.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_arrayMap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_arrayMap.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$isArray$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/isArray.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$isSymbol$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/isSymbol.js [app-client] (ecmascript)");
;
;
;
;
/** Used as references for various `Number` constants. */ var INFINITY = 1 / 0;
/** Used to convert symbols to primitives and strings. */ var symbolProto = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_Symbol$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_Symbol$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].prototype : undefined, symbolToString = symbolProto ? symbolProto.toString : undefined;
/**
 * The base implementation of `_.toString` which doesn't convert nullish
 * values to empty strings.
 *
 * @private
 * @param {*} value The value to process.
 * @returns {string} Returns the string.
 */ function baseToString(value) {
    // Exit early for strings to avoid a performance hit in some environments.
    if (typeof value == 'string') {
        return value;
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$isArray$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(value)) {
        // Recursively convert values (susceptible to call stack limits).
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_arrayMap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(value, baseToString) + '';
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$isSymbol$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(value)) {
        return symbolToString ? symbolToString.call(value) : '';
    }
    var result = value + '';
    return result == '0' && 1 / value == -INFINITY ? '-0' : result;
}
const __TURBOPACK__default__export__ = baseToString;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/toString.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_baseToString$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_baseToString.js [app-client] (ecmascript)");
;
/**
 * Converts `value` to a string. An empty string is returned for `null`
 * and `undefined` values. The sign of `-0` is preserved.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to convert.
 * @returns {string} Returns the converted string.
 * @example
 *
 * _.toString(null);
 * // => ''
 *
 * _.toString(-0);
 * // => '-0'
 *
 * _.toString([1, 2, 3]);
 * // => '1,2,3'
 */ function toString(value) {
    return value == null ? '' : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_baseToString$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(value);
}
const __TURBOPACK__default__export__ = toString;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/deburr.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_deburrLetter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_deburrLetter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$toString$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/toString.js [app-client] (ecmascript)");
;
;
/** Used to match Latin Unicode letters (excluding mathematical operators). */ var reLatin = /[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g;
/** Used to compose unicode character classes. */ var rsComboMarksRange = '\\u0300-\\u036f', reComboHalfMarksRange = '\\ufe20-\\ufe2f', rsComboSymbolsRange = '\\u20d0-\\u20ff', rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange;
/** Used to compose unicode capture groups. */ var rsCombo = '[' + rsComboRange + ']';
/**
 * Used to match [combining diacritical marks](https://en.wikipedia.org/wiki/Combining_Diacritical_Marks) and
 * [combining diacritical marks for symbols](https://en.wikipedia.org/wiki/Combining_Diacritical_Marks_for_Symbols).
 */ var reComboMark = RegExp(rsCombo, 'g');
/**
 * Deburrs `string` by converting
 * [Latin-1 Supplement](https://en.wikipedia.org/wiki/Latin-1_Supplement_(Unicode_block)#Character_table)
 * and [Latin Extended-A](https://en.wikipedia.org/wiki/Latin_Extended-A)
 * letters to basic Latin letters and removing
 * [combining diacritical marks](https://en.wikipedia.org/wiki/Combining_Diacritical_Marks).
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category String
 * @param {string} [string=''] The string to deburr.
 * @returns {string} Returns the deburred string.
 * @example
 *
 * _.deburr('déjà vu');
 * // => 'deja vu'
 */ function deburr(string) {
    string = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$toString$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(string);
    return string && string.replace(reLatin, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_deburrLetter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]).replace(reComboMark, '');
}
const __TURBOPACK__default__export__ = deburr;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_asciiWords.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/** Used to match words composed of alphanumeric characters. */ var reAsciiWord = /[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;
/**
 * Splits an ASCII `string` into an array of its words.
 *
 * @private
 * @param {string} The string to inspect.
 * @returns {Array} Returns the words of `string`.
 */ function asciiWords(string) {
    return string.match(reAsciiWord) || [];
}
const __TURBOPACK__default__export__ = asciiWords;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_hasUnicodeWord.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/** Used to detect strings that need a more robust regexp to match words. */ var reHasUnicodeWord = /[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;
/**
 * Checks if `string` contains a word composed of Unicode symbols.
 *
 * @private
 * @param {string} string The string to inspect.
 * @returns {boolean} Returns `true` if a word is found, else `false`.
 */ function hasUnicodeWord(string) {
    return reHasUnicodeWord.test(string);
}
const __TURBOPACK__default__export__ = hasUnicodeWord;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_unicodeWords.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/** Used to compose unicode character classes. */ var rsAstralRange = '\\ud800-\\udfff', rsComboMarksRange = '\\u0300-\\u036f', reComboHalfMarksRange = '\\ufe20-\\ufe2f', rsComboSymbolsRange = '\\u20d0-\\u20ff', rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange, rsDingbatRange = '\\u2700-\\u27bf', rsLowerRange = 'a-z\\xdf-\\xf6\\xf8-\\xff', rsMathOpRange = '\\xac\\xb1\\xd7\\xf7', rsNonCharRange = '\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf', rsPunctuationRange = '\\u2000-\\u206f', rsSpaceRange = ' \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000', rsUpperRange = 'A-Z\\xc0-\\xd6\\xd8-\\xde', rsVarRange = '\\ufe0e\\ufe0f', rsBreakRange = rsMathOpRange + rsNonCharRange + rsPunctuationRange + rsSpaceRange;
/** Used to compose unicode capture groups. */ var rsApos = "['\u2019]", rsBreak = '[' + rsBreakRange + ']', rsCombo = '[' + rsComboRange + ']', rsDigits = '\\d+', rsDingbat = '[' + rsDingbatRange + ']', rsLower = '[' + rsLowerRange + ']', rsMisc = '[^' + rsAstralRange + rsBreakRange + rsDigits + rsDingbatRange + rsLowerRange + rsUpperRange + ']', rsFitz = '\\ud83c[\\udffb-\\udfff]', rsModifier = '(?:' + rsCombo + '|' + rsFitz + ')', rsNonAstral = '[^' + rsAstralRange + ']', rsRegional = '(?:\\ud83c[\\udde6-\\uddff]){2}', rsSurrPair = '[\\ud800-\\udbff][\\udc00-\\udfff]', rsUpper = '[' + rsUpperRange + ']', rsZWJ = '\\u200d';
/** Used to compose unicode regexes. */ var rsMiscLower = '(?:' + rsLower + '|' + rsMisc + ')', rsMiscUpper = '(?:' + rsUpper + '|' + rsMisc + ')', rsOptContrLower = '(?:' + rsApos + '(?:d|ll|m|re|s|t|ve))?', rsOptContrUpper = '(?:' + rsApos + '(?:D|LL|M|RE|S|T|VE))?', reOptMod = rsModifier + '?', rsOptVar = '[' + rsVarRange + ']?', rsOptJoin = '(?:' + rsZWJ + '(?:' + [
    rsNonAstral,
    rsRegional,
    rsSurrPair
].join('|') + ')' + rsOptVar + reOptMod + ')*', rsOrdLower = '\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])', rsOrdUpper = '\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])', rsSeq = rsOptVar + reOptMod + rsOptJoin, rsEmoji = '(?:' + [
    rsDingbat,
    rsRegional,
    rsSurrPair
].join('|') + ')' + rsSeq;
/** Used to match complex or compound words. */ var reUnicodeWord = RegExp([
    rsUpper + '?' + rsLower + '+' + rsOptContrLower + '(?=' + [
        rsBreak,
        rsUpper,
        '$'
    ].join('|') + ')',
    rsMiscUpper + '+' + rsOptContrUpper + '(?=' + [
        rsBreak,
        rsUpper + rsMiscLower,
        '$'
    ].join('|') + ')',
    rsUpper + '?' + rsMiscLower + '+' + rsOptContrLower,
    rsUpper + '+' + rsOptContrUpper,
    rsOrdUpper,
    rsOrdLower,
    rsDigits,
    rsEmoji
].join('|'), 'g');
/**
 * Splits a Unicode `string` into an array of its words.
 *
 * @private
 * @param {string} The string to inspect.
 * @returns {Array} Returns the words of `string`.
 */ function unicodeWords(string) {
    return string.match(reUnicodeWord) || [];
}
const __TURBOPACK__default__export__ = unicodeWords;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/words.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_asciiWords$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_asciiWords.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_hasUnicodeWord$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_hasUnicodeWord.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$toString$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/toString.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_unicodeWords$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_unicodeWords.js [app-client] (ecmascript)");
;
;
;
;
/**
 * Splits `string` into an array of its words.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category String
 * @param {string} [string=''] The string to inspect.
 * @param {RegExp|string} [pattern] The pattern to match words.
 * @param- {Object} [guard] Enables use as an iteratee for methods like `_.map`.
 * @returns {Array} Returns the words of `string`.
 * @example
 *
 * _.words('fred, barney, & pebbles');
 * // => ['fred', 'barney', 'pebbles']
 *
 * _.words('fred, barney, & pebbles', /[^, ]+/g);
 * // => ['fred', 'barney', '&', 'pebbles']
 */ function words(string, pattern, guard) {
    string = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$toString$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(string);
    pattern = guard ? undefined : pattern;
    if (pattern === undefined) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_hasUnicodeWord$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(string) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_unicodeWords$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(string) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_asciiWords$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(string);
    }
    return string.match(pattern) || [];
}
const __TURBOPACK__default__export__ = words;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_createCompounder.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_arrayReduce$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_arrayReduce.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$deburr$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/deburr.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$words$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/words.js [app-client] (ecmascript)");
;
;
;
/** Used to compose unicode capture groups. */ var rsApos = "['\u2019]";
/** Used to match apostrophes. */ var reApos = RegExp(rsApos, 'g');
/**
 * Creates a function like `_.camelCase`.
 *
 * @private
 * @param {Function} callback The function to combine each word.
 * @returns {Function} Returns the new compounder function.
 */ function createCompounder(callback) {
    return function(string) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_arrayReduce$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$words$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$deburr$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(string).replace(reApos, '')), callback, '');
    };
}
const __TURBOPACK__default__export__ = createCompounder;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_baseSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/**
 * The base implementation of `_.slice` without an iteratee call guard.
 *
 * @private
 * @param {Array} array The array to slice.
 * @param {number} [start=0] The start position.
 * @param {number} [end=array.length] The end position.
 * @returns {Array} Returns the slice of `array`.
 */ function baseSlice(array, start, end) {
    var index = -1, length = array.length;
    if (start < 0) {
        start = -start > length ? 0 : length + start;
    }
    end = end > length ? length : end;
    if (end < 0) {
        end += length;
    }
    length = start > end ? 0 : end - start >>> 0;
    start >>>= 0;
    var result = Array(length);
    while(++index < length){
        result[index] = array[index + start];
    }
    return result;
}
const __TURBOPACK__default__export__ = baseSlice;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_castSlice.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_baseSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_baseSlice.js [app-client] (ecmascript)");
;
/**
 * Casts `array` to a slice if it's needed.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {number} start The start position.
 * @param {number} [end=array.length] The end position.
 * @returns {Array} Returns the cast slice.
 */ function castSlice(array, start, end) {
    var length = array.length;
    end = end === undefined ? length : end;
    return !start && end >= length ? array : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_baseSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(array, start, end);
}
const __TURBOPACK__default__export__ = castSlice;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_hasUnicode.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/** Used to compose unicode character classes. */ var rsAstralRange = '\\ud800-\\udfff', rsComboMarksRange = '\\u0300-\\u036f', reComboHalfMarksRange = '\\ufe20-\\ufe2f', rsComboSymbolsRange = '\\u20d0-\\u20ff', rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange, rsVarRange = '\\ufe0e\\ufe0f';
/** Used to compose unicode capture groups. */ var rsZWJ = '\\u200d';
/** Used to detect strings with [zero-width joiners or code points from the astral planes](http://eev.ee/blog/2015/09/12/dark-corners-of-unicode/). */ var reHasUnicode = RegExp('[' + rsZWJ + rsAstralRange + rsComboRange + rsVarRange + ']');
/**
 * Checks if `string` contains Unicode symbols.
 *
 * @private
 * @param {string} string The string to inspect.
 * @returns {boolean} Returns `true` if a symbol is found, else `false`.
 */ function hasUnicode(string) {
    return reHasUnicode.test(string);
}
const __TURBOPACK__default__export__ = hasUnicode;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_asciiToArray.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/**
 * Converts an ASCII `string` to an array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the converted array.
 */ function asciiToArray(string) {
    return string.split('');
}
const __TURBOPACK__default__export__ = asciiToArray;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_unicodeToArray.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/** Used to compose unicode character classes. */ var rsAstralRange = '\\ud800-\\udfff', rsComboMarksRange = '\\u0300-\\u036f', reComboHalfMarksRange = '\\ufe20-\\ufe2f', rsComboSymbolsRange = '\\u20d0-\\u20ff', rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange, rsVarRange = '\\ufe0e\\ufe0f';
/** Used to compose unicode capture groups. */ var rsAstral = '[' + rsAstralRange + ']', rsCombo = '[' + rsComboRange + ']', rsFitz = '\\ud83c[\\udffb-\\udfff]', rsModifier = '(?:' + rsCombo + '|' + rsFitz + ')', rsNonAstral = '[^' + rsAstralRange + ']', rsRegional = '(?:\\ud83c[\\udde6-\\uddff]){2}', rsSurrPair = '[\\ud800-\\udbff][\\udc00-\\udfff]', rsZWJ = '\\u200d';
/** Used to compose unicode regexes. */ var reOptMod = rsModifier + '?', rsOptVar = '[' + rsVarRange + ']?', rsOptJoin = '(?:' + rsZWJ + '(?:' + [
    rsNonAstral,
    rsRegional,
    rsSurrPair
].join('|') + ')' + rsOptVar + reOptMod + ')*', rsSeq = rsOptVar + reOptMod + rsOptJoin, rsSymbol = '(?:' + [
    rsNonAstral + rsCombo + '?',
    rsCombo,
    rsRegional,
    rsSurrPair,
    rsAstral
].join('|') + ')';
/** Used to match [string symbols](https://mathiasbynens.be/notes/javascript-unicode). */ var reUnicode = RegExp(rsFitz + '(?=' + rsFitz + ')|' + rsSymbol + rsSeq, 'g');
/**
 * Converts a Unicode `string` to an array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the converted array.
 */ function unicodeToArray(string) {
    return string.match(reUnicode) || [];
}
const __TURBOPACK__default__export__ = unicodeToArray;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_stringToArray.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_asciiToArray$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_asciiToArray.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_hasUnicode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_hasUnicode.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_unicodeToArray$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_unicodeToArray.js [app-client] (ecmascript)");
;
;
;
/**
 * Converts `string` to an array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the converted array.
 */ function stringToArray(string) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_hasUnicode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(string) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_unicodeToArray$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(string) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_asciiToArray$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(string);
}
const __TURBOPACK__default__export__ = stringToArray;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_createCaseFirst.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_castSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_castSlice.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_hasUnicode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_hasUnicode.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_stringToArray$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_stringToArray.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$toString$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/toString.js [app-client] (ecmascript)");
;
;
;
;
/**
 * Creates a function like `_.lowerFirst`.
 *
 * @private
 * @param {string} methodName The name of the `String` case method to use.
 * @returns {Function} Returns the new case function.
 */ function createCaseFirst(methodName) {
    return function(string) {
        string = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$toString$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(string);
        var strSymbols = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_hasUnicode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(string) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_stringToArray$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(string) : undefined;
        var chr = strSymbols ? strSymbols[0] : string.charAt(0);
        var trailing = strSymbols ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_castSlice$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(strSymbols, 1).join('') : string.slice(1);
        return chr[methodName]() + trailing;
    };
}
const __TURBOPACK__default__export__ = createCaseFirst;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/upperFirst.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_createCaseFirst$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_createCaseFirst.js [app-client] (ecmascript)");
;
/**
 * Converts the first character of `string` to upper case.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category String
 * @param {string} [string=''] The string to convert.
 * @returns {string} Returns the converted string.
 * @example
 *
 * _.upperFirst('fred');
 * // => 'Fred'
 *
 * _.upperFirst('FRED');
 * // => 'FRED'
 */ var upperFirst = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_createCaseFirst$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('toUpperCase');
const __TURBOPACK__default__export__ = upperFirst;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/startCase.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_createCompounder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/_createCompounder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$upperFirst$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/upperFirst.js [app-client] (ecmascript)");
;
;
/**
 * Converts `string` to
 * [start case](https://en.wikipedia.org/wiki/Letter_case#Stylistic_or_specialised_usage).
 *
 * @static
 * @memberOf _
 * @since 3.1.0
 * @category String
 * @param {string} [string=''] The string to convert.
 * @returns {string} Returns the start cased string.
 * @example
 *
 * _.startCase('--foo-bar--');
 * // => 'Foo Bar'
 *
 * _.startCase('fooBar');
 * // => 'Foo Bar'
 *
 * _.startCase('__FOO_BAR__');
 * // => 'FOO BAR'
 */ var startCase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$_createCompounder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(function(result, word, index) {
    return result + (index ? ' ' : '') + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$upperFirst$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(word);
});
const __TURBOPACK__default__export__ = startCase;
}),
"[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/startCase.js [app-client] (ecmascript) <export default as startCase>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "startCase",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$startCase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$startCase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/startCase.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@sanity/insert-menu/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InsertMenu",
    ()=>InsertMenu
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/icons/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/dist/_chunks-es/_visual-editing.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$startCase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__startCase$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/insert-menu/node_modules/lodash-es/startCase.js [app-client] (ecmascript) <export default as startCase>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-is/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
function getSchemaTypeIcon(schemaType) {
    const referenceIcon = isReferenceSchemaType(schemaType) && (schemaType.to ?? []).length === 1 ? schemaType.to[0].icon : void 0;
    return schemaType.icon ?? schemaType.type?.icon ?? referenceIcon;
}
function isReferenceSchemaType(type) {
    return isRecord(type) && (type.name === "reference" || isReferenceSchemaType(type.type));
}
function isRecord(value) {
    return !!value && (typeof value == "object" || typeof value == "function");
}
function fullInsertMenuReducer(state, event) {
    return {
        query: event.type === "change query" ? event.query : state.query,
        groups: event.type === "select group" ? state.groups.map((group)=>({
                ...group,
                selected: event.name === group.name
            })) : state.groups,
        views: event.type === "toggle view" ? state.views.map((view)=>({
                ...view,
                selected: event.name === view.name
            })) : state.views
    };
}
const ALL_ITEMS_GROUP_NAME = "all-items", gridStyle = {
    gridTemplateColumns: "repeat(auto-fill, minmax(118px, 1fr))",
    alignItems: "start"
};
function InsertMenu(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(54), showIcons = props.showIcons === void 0 ? !0 : props.showIcons, showFilter = props.filter === void 0 || props.filter === "auto" ? props.schemaTypes.length > 5 : props.filter;
    let t0;
    $[0] !== props.groups || $[1] !== props.labels ? (t0 = props.groups ? [
        {
            name: ALL_ITEMS_GROUP_NAME,
            title: props.labels["insert-menu.filter.all-items"],
            selected: !0
        },
        ...props.groups.map(_temp)
    ] : [], $[0] = props.groups, $[1] = props.labels, $[2] = t0) : t0 = $[2];
    let t1;
    $[3] !== props.views ? (t1 = props.views ?? [
        {
            name: "list"
        }
    ], $[3] = props.views, $[4] = t1) : t1 = $[4];
    let t2;
    $[5] !== t1 ? (t2 = t1.map(_temp2), $[5] = t1, $[6] = t2) : t2 = $[6];
    let t3;
    $[7] !== t0 || $[8] !== t2 ? (t3 = {
        query: "",
        groups: t0,
        views: t2
    }, $[7] = t0, $[8] = t2, $[9] = t3) : t3 = $[9];
    const [state, send] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(fullInsertMenuReducer, t3);
    let T0, T1, T2, t4, t5, t6, t7, t8, t9;
    if ($[10] !== props || $[11] !== showFilter || $[12] !== showIcons || $[13] !== state.groups || $[14] !== state.query || $[15] !== state.views) {
        const filteredSchemaTypes = filterSchemaTypes(props.schemaTypes, state.query, state.groups), selectedView = state.views.find(_temp3), showingFilterOrViews = showFilter || state.views.length > 1, showingTabs = state.groups && state.groups.length > 0, showingAnyOptions = showingFilterOrViews || showingTabs;
        T2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Menu"], t9 = 0, T1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Flex"], t6 = "column", t7 = "fill";
        let t102;
        $[25] !== showingAnyOptions ? (t102 = showingAnyOptions ? {
            style: {
                borderBottom: "1px solid var(--card-border-color)"
            },
            paddingBottom: 1
        } : {}, $[25] = showingAnyOptions, $[26] = t102) : t102 = $[26];
        let t112;
        $[27] !== props.labels || $[28] !== showFilter || $[29] !== showingFilterOrViews || $[30] !== state.query || $[31] !== state.views ? (t112 = showingFilterOrViews ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Flex"], {
            flex: "none",
            align: "center",
            paddingTop: 1,
            paddingX: 1,
            gap: 1,
            children: [
                showFilter ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
                    flex: 1,
                    children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextInput"], {
                        autoFocus: !0,
                        border: !1,
                        fontSize: 1,
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SearchIcon"],
                        onChange: (event)=>{
                            send({
                                type: "change query",
                                query: event.target.value
                            });
                        },
                        placeholder: props.labels["insert-menu.search.placeholder"],
                        value: state.query
                    })
                }) : null,
                state.views.length > 1 ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
                    flex: "none",
                    children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ViewToggle, {
                        views: state.views,
                        onToggle: (name)=>{
                            send({
                                type: "toggle view",
                                name
                            });
                        },
                        labels: props.labels
                    })
                }) : null
            ]
        }) : null, $[27] = props.labels, $[28] = showFilter, $[29] = showingFilterOrViews, $[30] = state.query, $[31] = state.views, $[32] = t112) : t112 = $[32];
        let t122;
        $[33] !== showingTabs || $[34] !== state.groups ? (t122 = showingTabs ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
            paddingTop: 1,
            paddingX: 1,
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabList"], {
                space: 1,
                children: state.groups.map((group_0)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tab"], {
                        id: `${group_0.name}-tab`,
                        "aria-controls": `${group_0.name}-panel`,
                        label: group_0.title ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$startCase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__startCase$3e$__["startCase"])(group_0.name),
                        selected: group_0.selected,
                        onClick: ()=>{
                            send({
                                type: "select group",
                                name: group_0.name
                            });
                        }
                    }, group_0.name))
            })
        }) : null, $[33] = showingTabs, $[34] = state.groups, $[35] = t122) : t122 = $[35], $[36] !== t102 || $[37] !== t112 || $[38] !== t122 ? (t8 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
            ...t102,
            children: [
                t112,
                t122
            ]
        }), $[36] = t102, $[37] = t112, $[38] = t122, $[39] = t8) : t8 = $[39], T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], t4 = 1, t5 = filteredSchemaTypes.length === 0 ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
            padding: 2,
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                muted: !0,
                size: 1,
                children: props.labels["insert-menu.search.no-results"]
            })
        }) : selectedView ? selectedView.name === "grid" ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Grid"], {
            autoRows: "auto",
            flex: 1,
            gap: 1,
            style: gridStyle,
            children: filteredSchemaTypes.map((schemaType)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(GridMenuItem, {
                    icon: showIcons ? getSchemaTypeIcon(schemaType) : void 0,
                    onClick: ()=>{
                        props.onSelect(schemaType);
                    },
                    previewImageUrl: selectedView.previewImageUrl?.(schemaType.name),
                    schemaType
                }, schemaType.name))
        }) : /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stack"], {
            flex: 1,
            space: 1,
            children: filteredSchemaTypes.map((schemaType_0)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuItem"], {
                    icon: showIcons ? getSchemaTypeIcon(schemaType_0) : void 0,
                    onClick: ()=>{
                        props.onSelect(schemaType_0);
                    },
                    text: schemaType_0.title ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$insert$2d$menu$2f$node_modules$2f$lodash$2d$es$2f$startCase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__startCase$3e$__["startCase"])(schemaType_0.name)
                }, schemaType_0.name))
        }) : null, $[10] = props, $[11] = showFilter, $[12] = showIcons, $[13] = state.groups, $[14] = state.query, $[15] = state.views, $[16] = T0, $[17] = T1, $[18] = T2, $[19] = t4, $[20] = t5, $[21] = t6, $[22] = t7, $[23] = t8, $[24] = t9;
    } else T0 = $[16], T1 = $[17], T2 = $[18], t4 = $[19], t5 = $[20], t6 = $[21], t7 = $[22], t8 = $[23], t9 = $[24];
    let t10;
    $[40] !== T0 || $[41] !== t4 || $[42] !== t5 ? (t10 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(T0, {
        padding: t4,
        children: t5
    }), $[40] = T0, $[41] = t4, $[42] = t5, $[43] = t10) : t10 = $[43];
    let t11;
    $[44] !== T1 || $[45] !== t10 || $[46] !== t6 || $[47] !== t7 || $[48] !== t8 ? (t11 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(T1, {
        direction: t6,
        height: t7,
        children: [
            t8,
            t10
        ]
    }), $[44] = T1, $[45] = t10, $[46] = t6, $[47] = t7, $[48] = t8, $[49] = t11) : t11 = $[49];
    let t12;
    return $[50] !== T2 || $[51] !== t11 || $[52] !== t9 ? (t12 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(T2, {
        padding: t9,
        children: t11
    }), $[50] = T2, $[51] = t11, $[52] = t9, $[53] = t12) : t12 = $[53], t12;
}
function _temp3(view_0) {
    return view_0.selected;
}
function _temp2(view, index) {
    return {
        ...view,
        selected: index === 0
    };
}
function _temp(group) {
    return {
        ...group,
        selected: !1
    };
}
const viewToggleIcon = {
    grid: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThLargeIcon"],
    list: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UlistIcon"]
}, viewToggleTooltip = {
    grid: "insert-menu.toggle-grid-view.tooltip",
    list: "insert-menu.toggle-list-view.tooltip"
};
function ViewToggle(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(11), viewIndex = props.views.findIndex(_temp4), nextView = props.views[viewIndex + 1] ?? props.views[0], t0 = props.labels[viewToggleTooltip[nextView.name]];
    let t1;
    $[0] !== t0 ? (t1 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
        size: 1,
        children: t0
    }), $[0] = t0, $[1] = t1) : t1 = $[1];
    const t2 = viewToggleIcon[nextView.name];
    let t3;
    $[2] !== nextView.name || $[3] !== props ? (t3 = ()=>{
        props.onToggle(nextView.name);
    }, $[2] = nextView.name, $[3] = props, $[4] = t3) : t3 = $[4];
    let t4;
    $[5] !== t2 || $[6] !== t3 ? (t4 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
        mode: "bleed",
        icon: t2,
        onClick: t3
    }), $[5] = t2, $[6] = t3, $[7] = t4) : t4 = $[7];
    let t5;
    return $[8] !== t1 || $[9] !== t4 ? (t5 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tooltip"], {
        content: t1,
        placement: "top",
        portal: !0,
        children: t4
    }), $[8] = t1, $[9] = t4, $[10] = t5) : t5 = $[10], t5;
}
function _temp4(view) {
    return view.selected;
}
function GridMenuItem(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(20), [failedToLoad, setFailedToLoad] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), Icon = props.icon, hasPreviewImage = !!props.previewImageUrl && !failedToLoad;
    let t0;
    $[0] === /* @__PURE__ */ Symbol.for("react.memo_cache_sentinel") ? (t0 = {
        overflow: "hidden"
    }, $[0] = t0) : t0 = $[0];
    let t1;
    $[1] === /* @__PURE__ */ Symbol.for("react.memo_cache_sentinel") ? (t1 = {
        backgroundColor: "var(--card-muted-bg-color)",
        paddingBottom: "66.6%",
        position: "relative"
    }, $[1] = t1) : t1 = $[1];
    let t2;
    $[2] !== Icon || $[3] !== hasPreviewImage ? (t2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElementType"])(Icon) && !hasPreviewImage ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Flex"], {
        align: "center",
        justify: "center",
        style: {
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%"
        },
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
            size: 1,
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Icon, {})
        })
    }) : null, $[2] = Icon, $[3] = hasPreviewImage, $[4] = t2) : t2 = $[4];
    let t3;
    $[5] !== hasPreviewImage || $[6] !== props.previewImageUrl ? (t3 = hasPreviewImage ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("img", {
        src: props.previewImageUrl,
        style: {
            objectFit: "contain",
            width: "100%",
            height: "100%",
            position: "absolute",
            inset: 0
        },
        onError: ()=>{
            setFailedToLoad(!0);
        }
    }) : null, $[5] = hasPreviewImage, $[6] = props.previewImageUrl, $[7] = t3) : t3 = $[7];
    let t4;
    $[8] === /* @__PURE__ */ Symbol.for("react.memo_cache_sentinel") ? (t4 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        style: {
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            boxShadow: "inset 0 0 0 0.5px var(--card-fg-color)",
            opacity: 0.1
        }
    }), $[8] = t4) : t4 = $[8];
    let t5;
    $[9] !== t2 || $[10] !== t3 ? (t5 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
        flex: "none",
        style: t1,
        children: [
            t2,
            t3,
            t4
        ]
    }), $[9] = t2, $[10] = t3, $[11] = t5) : t5 = $[11];
    const t6 = props.schemaType.title ?? props.schemaType.name;
    let t7;
    $[12] !== t6 ? (t7 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
        flex: "none",
        paddingX: 2,
        paddingY: 1,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
            size: 1,
            weight: "medium",
            children: t6
        })
    }), $[12] = t6, $[13] = t7) : t7 = $[13];
    let t8;
    $[14] !== t5 || $[15] !== t7 ? (t8 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Flex"], {
        direction: "column",
        gap: 1,
        padding: 1,
        children: [
            t5,
            t7
        ]
    }), $[14] = t5, $[15] = t7, $[16] = t8) : t8 = $[16];
    let t9;
    return $[17] !== props.onClick || $[18] !== t8 ? (t9 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuItem"], {
        padding: 0,
        radius: 2,
        onClick: props.onClick,
        style: t0,
        children: t8
    }), $[17] = props.onClick, $[18] = t8, $[19] = t9) : t9 = $[19], t9;
}
function filterSchemaTypes(schemaTypes, query, groups) {
    return schemaTypes.filter((schemaType)=>passesGroupFilter(schemaType, groups) && passesQueryFilter(schemaType, query));
}
function passesQueryFilter(schemaType, query) {
    const sanitizedQuery = query.trim().toLowerCase();
    return schemaType.title ? schemaType.title?.toLowerCase().includes(sanitizedQuery) : schemaType.name.includes(sanitizedQuery);
}
function passesGroupFilter(schemaType, groups) {
    const selectedGroup = groups.find((group)=>group.selected);
    return selectedGroup ? selectedGroup.name === ALL_ITEMS_GROUP_NAME ? !0 : selectedGroup.of?.includes(schemaType.name) : !0;
}
;
}),
"[project]/node_modules/scroll-into-view-if-needed/node_modules/compute-scroll-into-view/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "compute",
    ()=>r
]);
const t = (t)=>"object" == typeof t && null != t && 1 === t.nodeType, e = (t, e)=>(!e || "hidden" !== t) && "visible" !== t && "clip" !== t, n = (t, n)=>{
    if (t.clientHeight < t.scrollHeight || t.clientWidth < t.scrollWidth) {
        const o = getComputedStyle(t, null);
        return e(o.overflowY, n) || e(o.overflowX, n) || ((t)=>{
            const e = ((t)=>{
                if (!t.ownerDocument || !t.ownerDocument.defaultView) return null;
                try {
                    return t.ownerDocument.defaultView.frameElement;
                } catch (t) {
                    return null;
                }
            })(t);
            return !!e && (e.clientHeight < t.scrollHeight || e.clientWidth < t.scrollWidth);
        })(t);
    }
    return !1;
}, o = (t, e, n, o, l, r, i, s)=>r < t && i > e || r > t && i < e ? 0 : r <= t && s <= n || i >= e && s >= n ? r - t - o : i > e && s < n || r < t && s > n ? i - e + l : 0, l = (t)=>{
    const e = t.parentElement;
    return null == e ? t.getRootNode().host || null : e;
}, r = (e, r)=>{
    var i, s, d, h;
    if ("undefined" == typeof document) return [];
    const { scrollMode: c, block: f, inline: u, boundary: a, skipOverflowHiddenElements: g } = r, p = "function" == typeof a ? a : (t)=>t !== a;
    if (!t(e)) throw new TypeError("Invalid target");
    const m = document.scrollingElement || document.documentElement, w = [];
    let W = e;
    for(; t(W) && p(W);){
        if (W = l(W), W === m) {
            w.push(W);
            break;
        }
        null != W && W === document.body && n(W) && !n(document.documentElement) || null != W && n(W, g) && w.push(W);
    }
    const b = null != (s = null == (i = window.visualViewport) ? void 0 : i.width) ? s : innerWidth, H = null != (h = null == (d = window.visualViewport) ? void 0 : d.height) ? h : innerHeight, { scrollX: y, scrollY: M } = window, { height: v, width: E, top: x, right: C, bottom: I, left: R } = e.getBoundingClientRect(), { top: T, right: B, bottom: F, left: V } = ((t)=>{
        const e = window.getComputedStyle(t);
        return {
            top: parseFloat(e.scrollMarginTop) || 0,
            right: parseFloat(e.scrollMarginRight) || 0,
            bottom: parseFloat(e.scrollMarginBottom) || 0,
            left: parseFloat(e.scrollMarginLeft) || 0
        };
    })(e);
    let k = "start" === f || "nearest" === f ? x - T : "end" === f ? I + F : x + v / 2 - T + F, D = "center" === u ? R + E / 2 - V + B : "end" === u ? C + B : R - V;
    const L = [];
    for(let t = 0; t < w.length; t++){
        const e = w[t], { height: l, width: r, top: i, right: s, bottom: d, left: h } = e.getBoundingClientRect();
        if ("if-needed" === c && x >= 0 && R >= 0 && I <= H && C <= b && (e === m && !n(e) || x >= i && I <= d && R >= h && C <= s)) return L;
        const a = getComputedStyle(e), g = parseInt(a.borderLeftWidth, 10), p = parseInt(a.borderTopWidth, 10), W = parseInt(a.borderRightWidth, 10), T = parseInt(a.borderBottomWidth, 10);
        let B = 0, F = 0;
        const V = "offsetWidth" in e ? e.offsetWidth - e.clientWidth - g - W : 0, S = "offsetHeight" in e ? e.offsetHeight - e.clientHeight - p - T : 0, X = "offsetWidth" in e ? 0 === e.offsetWidth ? 0 : r / e.offsetWidth : 0, Y = "offsetHeight" in e ? 0 === e.offsetHeight ? 0 : l / e.offsetHeight : 0;
        if (m === e) B = "start" === f ? k : "end" === f ? k - H : "nearest" === f ? o(M, M + H, H, p, T, M + k, M + k + v, v) : k - H / 2, F = "start" === u ? D : "center" === u ? D - b / 2 : "end" === u ? D - b : o(y, y + b, b, g, W, y + D, y + D + E, E), B = Math.max(0, B + M), F = Math.max(0, F + y);
        else {
            B = "start" === f ? k - i - p : "end" === f ? k - d + T + S : "nearest" === f ? o(i, d, l, p, T + S, k, k + v, v) : k - (i + l / 2) + S / 2, F = "start" === u ? D - h - g : "center" === u ? D - (h + r / 2) + V / 2 : "end" === u ? D - s + W + V : o(h, s, r, g, W + V, D, D + E, E);
            const { scrollLeft: t, scrollTop: n } = e;
            B = 0 === Y ? 0 : Math.max(0, Math.min(n + B / Y, e.scrollHeight - l / Y + S)), F = 0 === X ? 0 : Math.max(0, Math.min(t + F / X, e.scrollWidth - r / X + V)), k += n - B, D += t - F;
        }
        L.push({
            el: e,
            top: B,
            left: F
        });
    }
    return L;
};
;
}),
"[project]/node_modules/scroll-into-view-if-needed/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>e
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$scroll$2d$into$2d$view$2d$if$2d$needed$2f$node_modules$2f$compute$2d$scroll$2d$into$2d$view$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/scroll-into-view-if-needed/node_modules/compute-scroll-into-view/dist/index.js [app-client] (ecmascript)");
;
const o = (t)=>!1 === t ? {
        block: "end",
        inline: "nearest"
    } : ((t)=>t === Object(t) && 0 !== Object.keys(t).length)(t) ? t : {
        block: "start",
        inline: "nearest"
    };
function e(e, r) {
    if (!e.isConnected || !((t)=>{
        let o = t;
        for(; o && o.parentNode;){
            if (o.parentNode === document) return !0;
            o = o.parentNode instanceof ShadowRoot ? o.parentNode.host : o.parentNode;
        }
        return !1;
    })(e)) return;
    const n = ((t)=>{
        const o = window.getComputedStyle(t);
        return {
            top: parseFloat(o.scrollMarginTop) || 0,
            right: parseFloat(o.scrollMarginRight) || 0,
            bottom: parseFloat(o.scrollMarginBottom) || 0,
            left: parseFloat(o.scrollMarginLeft) || 0
        };
    })(e);
    if (((t)=>"object" == typeof t && "function" == typeof t.behavior)(r)) return r.behavior((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$scroll$2d$into$2d$view$2d$if$2d$needed$2f$node_modules$2f$compute$2d$scroll$2d$into$2d$view$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compute"])(e, r));
    const l = "boolean" == typeof r || null == r ? void 0 : r.behavior;
    for (const { el: a, top: i, left: s } of (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$scroll$2d$into$2d$view$2d$if$2d$needed$2f$node_modules$2f$compute$2d$scroll$2d$into$2d$view$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compute"])(e, o(r))){
        const t = i - n.top + n.bottom, o = s - n.left + n.right;
        a.scroll({
            top: t,
            left: o,
            behavior: l
        });
    }
}
;
}),
"[project]/node_modules/@sanity/diff-match-patch/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DIFF_DELETE",
    ()=>DIFF_DELETE,
    "DIFF_EQUAL",
    ()=>DIFF_EQUAL,
    "DIFF_INSERT",
    ()=>DIFF_INSERT,
    "adjustIndiciesToUcs2",
    ()=>adjustIndiciesToUcs2,
    "applyPatches",
    ()=>apply,
    "cleanupEfficiency",
    ()=>cleanupEfficiency,
    "cleanupSemantic",
    ()=>cleanupSemantic,
    "makeDiff",
    ()=>diff,
    "makePatches",
    ()=>make,
    "match",
    ()=>match,
    "parsePatch",
    ()=>parse,
    "stringifyPatch",
    ()=>stringifyPatch,
    "stringifyPatches",
    ()=>stringify,
    "xIndex",
    ()=>xIndex
]);
function cloneDiff(diff2) {
    const [type, patch] = diff2;
    return [
        type,
        patch
    ];
}
function getCommonOverlap(textA, textB) {
    let text1 = textA, text2 = textB;
    const text1Length = text1.length, text2Length = text2.length;
    if (text1Length === 0 || text2Length === 0) return 0;
    text1Length > text2Length ? text1 = text1.substring(text1Length - text2Length) : text1Length < text2Length && (text2 = text2.substring(0, text1Length));
    const textLength = Math.min(text1Length, text2Length);
    if (text1 === text2) return textLength;
    let best = 0, length = 1;
    for(let found = 0; found !== -1;){
        const pattern = text1.substring(textLength - length);
        if (found = text2.indexOf(pattern), found === -1) return best;
        length += found, (found === 0 || text1.substring(textLength - length) === text2.substring(0, length)) && (best = length, length++);
    }
    return best;
}
function getCommonPrefix(text1, text2) {
    if (!text1 || !text2 || text1[0] !== text2[0]) return 0;
    let pointerMin = 0, pointerMax = Math.min(text1.length, text2.length), pointerMid = pointerMax, pointerStart = 0;
    for(; pointerMin < pointerMid;)text1.substring(pointerStart, pointerMid) === text2.substring(pointerStart, pointerMid) ? (pointerMin = pointerMid, pointerStart = pointerMin) : pointerMax = pointerMid, pointerMid = Math.floor((pointerMax - pointerMin) / 2 + pointerMin);
    return pointerMid;
}
function getCommonSuffix(text1, text2) {
    if (!text1 || !text2 || text1[text1.length - 1] !== text2[text2.length - 1]) return 0;
    let pointerMin = 0, pointerMax = Math.min(text1.length, text2.length), pointerMid = pointerMax, pointerEnd = 0;
    for(; pointerMin < pointerMid;)text1.substring(text1.length - pointerMid, text1.length - pointerEnd) === text2.substring(text2.length - pointerMid, text2.length - pointerEnd) ? (pointerMin = pointerMid, pointerEnd = pointerMin) : pointerMax = pointerMid, pointerMid = Math.floor((pointerMax - pointerMin) / 2 + pointerMin);
    return pointerMid;
}
function isHighSurrogate(char) {
    const charCode = char.charCodeAt(0);
    return charCode >= 55296 && charCode <= 56319;
}
function isLowSurrogate(char) {
    const charCode = char.charCodeAt(0);
    return charCode >= 56320 && charCode <= 57343;
}
function bisect(text1, text2, deadline) {
    const text1Length = text1.length, text2Length = text2.length, maxD = Math.ceil((text1Length + text2Length) / 2), vOffset = maxD, vLength = 2 * maxD, v1 = new Array(vLength), v2 = new Array(vLength);
    for(let x = 0; x < vLength; x++)v1[x] = -1, v2[x] = -1;
    v1[vOffset + 1] = 0, v2[vOffset + 1] = 0;
    const delta = text1Length - text2Length, front = delta % 2 !== 0;
    let k1start = 0, k1end = 0, k2start = 0, k2end = 0;
    for(let d = 0; d < maxD && !(Date.now() > deadline); d++){
        for(let k1 = -d + k1start; k1 <= d - k1end; k1 += 2){
            const k1Offset = vOffset + k1;
            let x1;
            k1 === -d || k1 !== d && v1[k1Offset - 1] < v1[k1Offset + 1] ? x1 = v1[k1Offset + 1] : x1 = v1[k1Offset - 1] + 1;
            let y1 = x1 - k1;
            for(; x1 < text1Length && y1 < text2Length && text1.charAt(x1) === text2.charAt(y1);)x1++, y1++;
            if (v1[k1Offset] = x1, x1 > text1Length) k1end += 2;
            else if (y1 > text2Length) k1start += 2;
            else if (front) {
                const k2Offset = vOffset + delta - k1;
                if (k2Offset >= 0 && k2Offset < vLength && v2[k2Offset] !== -1) {
                    const x2 = text1Length - v2[k2Offset];
                    if (x1 >= x2) return bisectSplit(text1, text2, x1, y1, deadline);
                }
            }
        }
        for(let k2 = -d + k2start; k2 <= d - k2end; k2 += 2){
            const k2Offset = vOffset + k2;
            let x2;
            k2 === -d || k2 !== d && v2[k2Offset - 1] < v2[k2Offset + 1] ? x2 = v2[k2Offset + 1] : x2 = v2[k2Offset - 1] + 1;
            let y2 = x2 - k2;
            for(; x2 < text1Length && y2 < text2Length && text1.charAt(text1Length - x2 - 1) === text2.charAt(text2Length - y2 - 1);)x2++, y2++;
            if (v2[k2Offset] = x2, x2 > text1Length) k2end += 2;
            else if (y2 > text2Length) k2start += 2;
            else if (!front) {
                const k1Offset = vOffset + delta - k2;
                if (k1Offset >= 0 && k1Offset < vLength && v1[k1Offset] !== -1) {
                    const x1 = v1[k1Offset], y1 = vOffset + x1 - k1Offset;
                    if (x2 = text1Length - x2, x1 >= x2) return bisectSplit(text1, text2, x1, y1, deadline);
                }
            }
        }
    }
    return [
        [
            DIFF_DELETE,
            text1
        ],
        [
            DIFF_INSERT,
            text2
        ]
    ];
}
function bisectSplit(text1, text2, x, y, deadline) {
    const text1a = text1.substring(0, x), text2a = text2.substring(0, y), text1b = text1.substring(x), text2b = text2.substring(y), diffs = doDiff(text1a, text2a, {
        checkLines: !1,
        deadline
    }), diffsb = doDiff(text1b, text2b, {
        checkLines: !1,
        deadline
    });
    return diffs.concat(diffsb);
}
function findHalfMatch(text1, text2, timeout = 1) {
    if (timeout <= 0) return null;
    const longText = text1.length > text2.length ? text1 : text2, shortText = text1.length > text2.length ? text2 : text1;
    if (longText.length < 4 || shortText.length * 2 < longText.length) return null;
    const halfMatch1 = halfMatchI(longText, shortText, Math.ceil(longText.length / 4)), halfMatch2 = halfMatchI(longText, shortText, Math.ceil(longText.length / 2));
    let halfMatch;
    if (halfMatch1 && halfMatch2) halfMatch = halfMatch1[4].length > halfMatch2[4].length ? halfMatch1 : halfMatch2;
    else {
        if (!halfMatch1 && !halfMatch2) return null;
        halfMatch2 ? halfMatch1 || (halfMatch = halfMatch2) : halfMatch = halfMatch1;
    }
    if (!halfMatch) throw new Error("Unable to find a half match.");
    let text1A, text1B, text2A, text2B;
    text1.length > text2.length ? (text1A = halfMatch[0], text1B = halfMatch[1], text2A = halfMatch[2], text2B = halfMatch[3]) : (text2A = halfMatch[0], text2B = halfMatch[1], text1A = halfMatch[2], text1B = halfMatch[3]);
    const midCommon = halfMatch[4];
    return [
        text1A,
        text1B,
        text2A,
        text2B,
        midCommon
    ];
}
function halfMatchI(longText, shortText, i) {
    const seed = longText.slice(i, i + Math.floor(longText.length / 4));
    let j = -1, bestCommon = "", bestLongTextA, bestLongTextB, bestShortTextA, bestShortTextB;
    for(; (j = shortText.indexOf(seed, j + 1)) !== -1;){
        const prefixLength = getCommonPrefix(longText.slice(i), shortText.slice(j)), suffixLength = getCommonSuffix(longText.slice(0, i), shortText.slice(0, j));
        bestCommon.length < suffixLength + prefixLength && (bestCommon = shortText.slice(j - suffixLength, j) + shortText.slice(j, j + prefixLength), bestLongTextA = longText.slice(0, i - suffixLength), bestLongTextB = longText.slice(i + prefixLength), bestShortTextA = shortText.slice(0, j - suffixLength), bestShortTextB = shortText.slice(j + prefixLength));
    }
    return bestCommon.length * 2 >= longText.length ? [
        bestLongTextA || "",
        bestLongTextB || "",
        bestShortTextA || "",
        bestShortTextB || "",
        bestCommon || ""
    ] : null;
}
function charsToLines(diffs, lineArray) {
    for(let x = 0; x < diffs.length; x++){
        const chars = diffs[x][1], text = [];
        for(let y = 0; y < chars.length; y++)text[y] = lineArray[chars.charCodeAt(y)];
        diffs[x][1] = text.join("");
    }
}
function linesToChars(textA, textB) {
    const lineArray = [], lineHash = {};
    lineArray[0] = "";
    function diffLinesToMunge(text) {
        let chars = "", lineStart = 0, lineEnd = -1, lineArrayLength = lineArray.length;
        for(; lineEnd < text.length - 1;){
            lineEnd = text.indexOf(`
`, lineStart), lineEnd === -1 && (lineEnd = text.length - 1);
            let line = text.slice(lineStart, lineEnd + 1);
            (lineHash.hasOwnProperty ? lineHash.hasOwnProperty(line) : lineHash[line] !== void 0) ? chars += String.fromCharCode(lineHash[line]) : (lineArrayLength === maxLines && (line = text.slice(lineStart), lineEnd = text.length), chars += String.fromCharCode(lineArrayLength), lineHash[line] = lineArrayLength, lineArray[lineArrayLength++] = line), lineStart = lineEnd + 1;
        }
        return chars;
    }
    let maxLines = 4e4;
    const chars1 = diffLinesToMunge(textA);
    maxLines = 65535;
    const chars2 = diffLinesToMunge(textB);
    return {
        chars1,
        chars2,
        lineArray
    };
}
function doLineModeDiff(textA, textB, opts) {
    let text1 = textA, text2 = textB;
    const a = linesToChars(text1, text2);
    text1 = a.chars1, text2 = a.chars2;
    const linearray = a.lineArray;
    let diffs = doDiff(text1, text2, {
        checkLines: !1,
        deadline: opts.deadline
    });
    charsToLines(diffs, linearray), diffs = cleanupSemantic(diffs), diffs.push([
        DIFF_EQUAL,
        ""
    ]);
    let pointer = 0, countDelete = 0, countInsert = 0, textDelete = "", textInsert = "";
    for(; pointer < diffs.length;){
        switch(diffs[pointer][0]){
            case DIFF_INSERT:
                countInsert++, textInsert += diffs[pointer][1];
                break;
            case DIFF_DELETE:
                countDelete++, textDelete += diffs[pointer][1];
                break;
            case DIFF_EQUAL:
                if (countDelete >= 1 && countInsert >= 1) {
                    diffs.splice(pointer - countDelete - countInsert, countDelete + countInsert), pointer = pointer - countDelete - countInsert;
                    const aa = doDiff(textDelete, textInsert, {
                        checkLines: !1,
                        deadline: opts.deadline
                    });
                    for(let j = aa.length - 1; j >= 0; j--)diffs.splice(pointer, 0, aa[j]);
                    pointer += aa.length;
                }
                countInsert = 0, countDelete = 0, textDelete = "", textInsert = "";
                break;
            default:
                throw new Error("Unknown diff operation.");
        }
        pointer++;
    }
    return diffs.pop(), diffs;
}
function computeDiff(text1, text2, opts) {
    let diffs;
    if (!text1) return [
        [
            DIFF_INSERT,
            text2
        ]
    ];
    if (!text2) return [
        [
            DIFF_DELETE,
            text1
        ]
    ];
    const longtext = text1.length > text2.length ? text1 : text2, shorttext = text1.length > text2.length ? text2 : text1, i = longtext.indexOf(shorttext);
    if (i !== -1) return diffs = [
        [
            DIFF_INSERT,
            longtext.substring(0, i)
        ],
        [
            DIFF_EQUAL,
            shorttext
        ],
        [
            DIFF_INSERT,
            longtext.substring(i + shorttext.length)
        ]
    ], text1.length > text2.length && (diffs[0][0] = DIFF_DELETE, diffs[2][0] = DIFF_DELETE), diffs;
    if (shorttext.length === 1) return [
        [
            DIFF_DELETE,
            text1
        ],
        [
            DIFF_INSERT,
            text2
        ]
    ];
    const halfMatch = findHalfMatch(text1, text2);
    if (halfMatch) {
        const text1A = halfMatch[0], text1B = halfMatch[1], text2A = halfMatch[2], text2B = halfMatch[3], midCommon = halfMatch[4], diffsA = doDiff(text1A, text2A, opts), diffsB = doDiff(text1B, text2B, opts);
        return diffsA.concat([
            [
                DIFF_EQUAL,
                midCommon
            ]
        ], diffsB);
    }
    return opts.checkLines && text1.length > 100 && text2.length > 100 ? doLineModeDiff(text1, text2, opts) : bisect(text1, text2, opts.deadline);
}
var __defProp$2 = Object.defineProperty, __getOwnPropSymbols$2 = Object.getOwnPropertySymbols, __hasOwnProp$2 = Object.prototype.hasOwnProperty, __propIsEnum$2 = Object.prototype.propertyIsEnumerable, __defNormalProp$2 = (obj, key, value)=>key in obj ? __defProp$2(obj, key, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value
    }) : obj[key] = value, __spreadValues$2 = (a, b)=>{
    for(var prop in b || (b = {}))__hasOwnProp$2.call(b, prop) && __defNormalProp$2(a, prop, b[prop]);
    if (__getOwnPropSymbols$2) for (var prop of __getOwnPropSymbols$2(b))__propIsEnum$2.call(b, prop) && __defNormalProp$2(a, prop, b[prop]);
    return a;
};
const DIFF_DELETE = -1, DIFF_INSERT = 1, DIFF_EQUAL = 0;
function diff(textA, textB, opts) {
    if (textA === null || textB === null) throw new Error("Null input. (diff)");
    const diffs = doDiff(textA, textB, createInternalOpts(opts || {}));
    return adjustDiffForSurrogatePairs(diffs), diffs;
}
function doDiff(textA, textB, options) {
    let text1 = textA, text2 = textB;
    if (text1 === text2) return text1 ? [
        [
            DIFF_EQUAL,
            text1
        ]
    ] : [];
    let commonlength = getCommonPrefix(text1, text2);
    const commonprefix = text1.substring(0, commonlength);
    text1 = text1.substring(commonlength), text2 = text2.substring(commonlength), commonlength = getCommonSuffix(text1, text2);
    const commonsuffix = text1.substring(text1.length - commonlength);
    text1 = text1.substring(0, text1.length - commonlength), text2 = text2.substring(0, text2.length - commonlength);
    let diffs = computeDiff(text1, text2, options);
    return commonprefix && diffs.unshift([
        DIFF_EQUAL,
        commonprefix
    ]), commonsuffix && diffs.push([
        DIFF_EQUAL,
        commonsuffix
    ]), diffs = cleanupMerge(diffs), diffs;
}
function createDeadLine(timeout) {
    let t = 1;
    return typeof timeout < "u" && (t = timeout <= 0 ? Number.MAX_VALUE : timeout), Date.now() + t * 1e3;
}
function createInternalOpts(opts) {
    return __spreadValues$2({
        checkLines: !0,
        deadline: createDeadLine(opts.timeout || 1)
    }, opts);
}
function combineChar(data, char, dir) {
    return dir === 1 ? data + char : char + data;
}
function splitChar(data, dir) {
    return dir === 1 ? [
        data.substring(0, data.length - 1),
        data[data.length - 1]
    ] : [
        data.substring(1),
        data[0]
    ];
}
function hasSharedChar(diffs, i, j, dir) {
    return dir === 1 ? diffs[i][1][diffs[i][1].length - 1] === diffs[j][1][diffs[j][1].length - 1] : diffs[i][1][0] === diffs[j][1][0];
}
function deisolateChar(diffs, i, dir) {
    const inv = dir === 1 ? -1 : 1;
    let insertIdx = null, deleteIdx = null, j = i + dir;
    for(; j >= 0 && j < diffs.length && (insertIdx === null || deleteIdx === null); j += dir){
        const [op, text2] = diffs[j];
        if (text2.length !== 0) {
            if (op === DIFF_INSERT) {
                insertIdx === null && (insertIdx = j);
                continue;
            } else if (op === DIFF_DELETE) {
                deleteIdx === null && (deleteIdx = j);
                continue;
            } else if (op === DIFF_EQUAL) {
                if (insertIdx === null && deleteIdx === null) {
                    const [rest, char2] = splitChar(diffs[i][1], dir);
                    diffs[i][1] = rest, diffs[j][1] = combineChar(diffs[j][1], char2, inv);
                    return;
                }
                break;
            }
        }
    }
    if (insertIdx !== null && deleteIdx !== null && hasSharedChar(diffs, insertIdx, deleteIdx, dir)) {
        const [insertText, insertChar] = splitChar(diffs[insertIdx][1], inv), [deleteText] = splitChar(diffs[deleteIdx][1], inv);
        diffs[insertIdx][1] = insertText, diffs[deleteIdx][1] = deleteText, diffs[i][1] = combineChar(diffs[i][1], insertChar, dir);
        return;
    }
    const [text, char] = splitChar(diffs[i][1], dir);
    diffs[i][1] = text, insertIdx === null ? (diffs.splice(j, 0, [
        DIFF_INSERT,
        char
    ]), deleteIdx !== null && deleteIdx >= j && deleteIdx++) : diffs[insertIdx][1] = combineChar(diffs[insertIdx][1], char, inv), deleteIdx === null ? diffs.splice(j, 0, [
        DIFF_DELETE,
        char
    ]) : diffs[deleteIdx][1] = combineChar(diffs[deleteIdx][1], char, inv);
}
function adjustDiffForSurrogatePairs(diffs) {
    for(let i = 0; i < diffs.length; i++){
        const [diffType, diffText] = diffs[i];
        if (diffText.length === 0) continue;
        const firstChar = diffText[0], lastChar = diffText[diffText.length - 1];
        isHighSurrogate(lastChar) && diffType === DIFF_EQUAL && deisolateChar(diffs, i, 1), isLowSurrogate(firstChar) && diffType === DIFF_EQUAL && deisolateChar(diffs, i, -1);
    }
    for(let i = 0; i < diffs.length; i++)diffs[i][1].length === 0 && diffs.splice(i, 1);
}
function cleanupSemantic(rawDiffs) {
    let diffs = rawDiffs.map((diff2)=>cloneDiff(diff2)), hasChanges = !1;
    const equalities = [];
    let equalitiesLength = 0, lastEquality = null, pointer = 0, lengthInsertions1 = 0, lengthDeletions1 = 0, lengthInsertions2 = 0, lengthDeletions2 = 0;
    for(; pointer < diffs.length;)diffs[pointer][0] === DIFF_EQUAL ? (equalities[equalitiesLength++] = pointer, lengthInsertions1 = lengthInsertions2, lengthDeletions1 = lengthDeletions2, lengthInsertions2 = 0, lengthDeletions2 = 0, lastEquality = diffs[pointer][1]) : (diffs[pointer][0] === DIFF_INSERT ? lengthInsertions2 += diffs[pointer][1].length : lengthDeletions2 += diffs[pointer][1].length, lastEquality && lastEquality.length <= Math.max(lengthInsertions1, lengthDeletions1) && lastEquality.length <= Math.max(lengthInsertions2, lengthDeletions2) && (diffs.splice(equalities[equalitiesLength - 1], 0, [
        DIFF_DELETE,
        lastEquality
    ]), diffs[equalities[equalitiesLength - 1] + 1][0] = DIFF_INSERT, equalitiesLength--, equalitiesLength--, pointer = equalitiesLength > 0 ? equalities[equalitiesLength - 1] : -1, lengthInsertions1 = 0, lengthDeletions1 = 0, lengthInsertions2 = 0, lengthDeletions2 = 0, lastEquality = null, hasChanges = !0)), pointer++;
    for(hasChanges && (diffs = cleanupMerge(diffs)), diffs = cleanupSemanticLossless(diffs), pointer = 1; pointer < diffs.length;){
        if (diffs[pointer - 1][0] === DIFF_DELETE && diffs[pointer][0] === DIFF_INSERT) {
            const deletion = diffs[pointer - 1][1], insertion = diffs[pointer][1], overlapLength1 = getCommonOverlap(deletion, insertion), overlapLength2 = getCommonOverlap(insertion, deletion);
            overlapLength1 >= overlapLength2 ? (overlapLength1 >= deletion.length / 2 || overlapLength1 >= insertion.length / 2) && (diffs.splice(pointer, 0, [
                DIFF_EQUAL,
                insertion.substring(0, overlapLength1)
            ]), diffs[pointer - 1][1] = deletion.substring(0, deletion.length - overlapLength1), diffs[pointer + 1][1] = insertion.substring(overlapLength1), pointer++) : (overlapLength2 >= deletion.length / 2 || overlapLength2 >= insertion.length / 2) && (diffs.splice(pointer, 0, [
                DIFF_EQUAL,
                deletion.substring(0, overlapLength2)
            ]), diffs[pointer - 1][0] = DIFF_INSERT, diffs[pointer - 1][1] = insertion.substring(0, insertion.length - overlapLength2), diffs[pointer + 1][0] = DIFF_DELETE, diffs[pointer + 1][1] = deletion.substring(overlapLength2), pointer++), pointer++;
        }
        pointer++;
    }
    return diffs;
}
const nonAlphaNumericRegex = /[^a-zA-Z0-9]/, whitespaceRegex = /\s/, linebreakRegex = /[\r\n]/, blanklineEndRegex = /\n\r?\n$/, blanklineStartRegex = /^\r?\n\r?\n/;
function cleanupSemanticLossless(rawDiffs) {
    const diffs = rawDiffs.map((diff2)=>cloneDiff(diff2));
    function diffCleanupSemanticScore(one, two) {
        if (!one || !two) return 6;
        const char1 = one.charAt(one.length - 1), char2 = two.charAt(0), nonAlphaNumeric1 = char1.match(nonAlphaNumericRegex), nonAlphaNumeric2 = char2.match(nonAlphaNumericRegex), whitespace1 = nonAlphaNumeric1 && char1.match(whitespaceRegex), whitespace2 = nonAlphaNumeric2 && char2.match(whitespaceRegex), lineBreak1 = whitespace1 && char1.match(linebreakRegex), lineBreak2 = whitespace2 && char2.match(linebreakRegex), blankLine1 = lineBreak1 && one.match(blanklineEndRegex), blankLine2 = lineBreak2 && two.match(blanklineStartRegex);
        return blankLine1 || blankLine2 ? 5 : lineBreak1 || lineBreak2 ? 4 : nonAlphaNumeric1 && !whitespace1 && whitespace2 ? 3 : whitespace1 || whitespace2 ? 2 : nonAlphaNumeric1 || nonAlphaNumeric2 ? 1 : 0;
    }
    let pointer = 1;
    for(; pointer < diffs.length - 1;){
        if (diffs[pointer - 1][0] === DIFF_EQUAL && diffs[pointer + 1][0] === DIFF_EQUAL) {
            let equality1 = diffs[pointer - 1][1], edit = diffs[pointer][1], equality2 = diffs[pointer + 1][1];
            const commonOffset = getCommonSuffix(equality1, edit);
            if (commonOffset) {
                const commonString = edit.substring(edit.length - commonOffset);
                equality1 = equality1.substring(0, equality1.length - commonOffset), edit = commonString + edit.substring(0, edit.length - commonOffset), equality2 = commonString + equality2;
            }
            let bestEquality1 = equality1, bestEdit = edit, bestEquality2 = equality2, bestScore = diffCleanupSemanticScore(equality1, edit) + diffCleanupSemanticScore(edit, equality2);
            for(; edit.charAt(0) === equality2.charAt(0);){
                equality1 += edit.charAt(0), edit = edit.substring(1) + equality2.charAt(0), equality2 = equality2.substring(1);
                const score = diffCleanupSemanticScore(equality1, edit) + diffCleanupSemanticScore(edit, equality2);
                score >= bestScore && (bestScore = score, bestEquality1 = equality1, bestEdit = edit, bestEquality2 = equality2);
            }
            diffs[pointer - 1][1] !== bestEquality1 && (bestEquality1 ? diffs[pointer - 1][1] = bestEquality1 : (diffs.splice(pointer - 1, 1), pointer--), diffs[pointer][1] = bestEdit, bestEquality2 ? diffs[pointer + 1][1] = bestEquality2 : (diffs.splice(pointer + 1, 1), pointer--));
        }
        pointer++;
    }
    return diffs;
}
function cleanupMerge(rawDiffs) {
    let diffs = rawDiffs.map((diff2)=>cloneDiff(diff2));
    diffs.push([
        DIFF_EQUAL,
        ""
    ]);
    let pointer = 0, countDelete = 0, countInsert = 0, textDelete = "", textInsert = "", commonlength;
    for(; pointer < diffs.length;)switch(diffs[pointer][0]){
        case DIFF_INSERT:
            countInsert++, textInsert += diffs[pointer][1], pointer++;
            break;
        case DIFF_DELETE:
            countDelete++, textDelete += diffs[pointer][1], pointer++;
            break;
        case DIFF_EQUAL:
            countDelete + countInsert > 1 ? (countDelete !== 0 && countInsert !== 0 && (commonlength = getCommonPrefix(textInsert, textDelete), commonlength !== 0 && (pointer - countDelete - countInsert > 0 && diffs[pointer - countDelete - countInsert - 1][0] === DIFF_EQUAL ? diffs[pointer - countDelete - countInsert - 1][1] += textInsert.substring(0, commonlength) : (diffs.splice(0, 0, [
                DIFF_EQUAL,
                textInsert.substring(0, commonlength)
            ]), pointer++), textInsert = textInsert.substring(commonlength), textDelete = textDelete.substring(commonlength)), commonlength = getCommonSuffix(textInsert, textDelete), commonlength !== 0 && (diffs[pointer][1] = textInsert.substring(textInsert.length - commonlength) + diffs[pointer][1], textInsert = textInsert.substring(0, textInsert.length - commonlength), textDelete = textDelete.substring(0, textDelete.length - commonlength))), pointer -= countDelete + countInsert, diffs.splice(pointer, countDelete + countInsert), textDelete.length && (diffs.splice(pointer, 0, [
                DIFF_DELETE,
                textDelete
            ]), pointer++), textInsert.length && (diffs.splice(pointer, 0, [
                DIFF_INSERT,
                textInsert
            ]), pointer++), pointer++) : pointer !== 0 && diffs[pointer - 1][0] === DIFF_EQUAL ? (diffs[pointer - 1][1] += diffs[pointer][1], diffs.splice(pointer, 1)) : pointer++, countInsert = 0, countDelete = 0, textDelete = "", textInsert = "";
            break;
        default:
            throw new Error("Unknown diff operation");
    }
    diffs[diffs.length - 1][1] === "" && diffs.pop();
    let hasChanges = !1;
    for(pointer = 1; pointer < diffs.length - 1;)diffs[pointer - 1][0] === DIFF_EQUAL && diffs[pointer + 1][0] === DIFF_EQUAL && (diffs[pointer][1].substring(diffs[pointer][1].length - diffs[pointer - 1][1].length) === diffs[pointer - 1][1] ? (diffs[pointer][1] = diffs[pointer - 1][1] + diffs[pointer][1].substring(0, diffs[pointer][1].length - diffs[pointer - 1][1].length), diffs[pointer + 1][1] = diffs[pointer - 1][1] + diffs[pointer + 1][1], diffs.splice(pointer - 1, 1), hasChanges = !0) : diffs[pointer][1].substring(0, diffs[pointer + 1][1].length) === diffs[pointer + 1][1] && (diffs[pointer - 1][1] += diffs[pointer + 1][1], diffs[pointer][1] = diffs[pointer][1].substring(diffs[pointer + 1][1].length) + diffs[pointer + 1][1], diffs.splice(pointer + 1, 1), hasChanges = !0)), pointer++;
    return hasChanges && (diffs = cleanupMerge(diffs)), diffs;
}
function trueCount(...args) {
    return args.reduce((n, bool)=>n + (bool ? 1 : 0), 0);
}
function cleanupEfficiency(rawDiffs, editCost = 4) {
    let diffs = rawDiffs.map((diff2)=>cloneDiff(diff2)), hasChanges = !1;
    const equalities = [];
    let equalitiesLength = 0, lastEquality = null, pointer = 0, preIns = !1, preDel = !1, postIns = !1, postDel = !1;
    for(; pointer < diffs.length;)diffs[pointer][0] === DIFF_EQUAL ? (diffs[pointer][1].length < editCost && (postIns || postDel) ? (equalities[equalitiesLength++] = pointer, preIns = postIns, preDel = postDel, lastEquality = diffs[pointer][1]) : (equalitiesLength = 0, lastEquality = null), postIns = !1, postDel = !1) : (diffs[pointer][0] === DIFF_DELETE ? postDel = !0 : postIns = !0, lastEquality && (preIns && preDel && postIns && postDel || lastEquality.length < editCost / 2 && trueCount(preIns, preDel, postIns, postDel) === 3) && (diffs.splice(equalities[equalitiesLength - 1], 0, [
        DIFF_DELETE,
        lastEquality
    ]), diffs[equalities[equalitiesLength - 1] + 1][0] = DIFF_INSERT, equalitiesLength--, lastEquality = null, preIns && preDel ? (postIns = !0, postDel = !0, equalitiesLength = 0) : (equalitiesLength--, pointer = equalitiesLength > 0 ? equalities[equalitiesLength - 1] : -1, postIns = !1, postDel = !1), hasChanges = !0)), pointer++;
    return hasChanges && (diffs = cleanupMerge(diffs)), diffs;
}
var __defProp$1 = Object.defineProperty, __getOwnPropSymbols$1 = Object.getOwnPropertySymbols, __hasOwnProp$1 = Object.prototype.hasOwnProperty, __propIsEnum$1 = Object.prototype.propertyIsEnumerable, __defNormalProp$1 = (obj, key, value)=>key in obj ? __defProp$1(obj, key, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value
    }) : obj[key] = value, __spreadValues$1 = (a, b)=>{
    for(var prop in b || (b = {}))__hasOwnProp$1.call(b, prop) && __defNormalProp$1(a, prop, b[prop]);
    if (__getOwnPropSymbols$1) for (var prop of __getOwnPropSymbols$1(b))__propIsEnum$1.call(b, prop) && __defNormalProp$1(a, prop, b[prop]);
    return a;
};
const DEFAULT_OPTIONS = {
    /**
   * At what point is no match declared (0.0 = perfection, 1.0 = very loose).
   */ threshold: 0.5,
    /**
   * How far to search for a match (0 = exact location, 1000+ = broad match).
   * A match this many characters away from the expected location will add
   * 1.0 to the score (0.0 is a perfect match).
   */ distance: 1e3
};
function applyDefaults(options) {
    return __spreadValues$1(__spreadValues$1({}, DEFAULT_OPTIONS), options);
}
const MAX_BITS$1 = 32;
function bitap(text, pattern, loc, opts = {}) {
    if (pattern.length > MAX_BITS$1) throw new Error("Pattern too long for this browser.");
    const options = applyDefaults(opts), s = getAlphabetFromPattern(pattern);
    function getBitapScore(e, x) {
        const accuracy = e / pattern.length, proximity = Math.abs(loc - x);
        return options.distance ? accuracy + proximity / options.distance : proximity ? 1 : accuracy;
    }
    let scoreThreshold = options.threshold, bestLoc = text.indexOf(pattern, loc);
    bestLoc !== -1 && (scoreThreshold = Math.min(getBitapScore(0, bestLoc), scoreThreshold), bestLoc = text.lastIndexOf(pattern, loc + pattern.length), bestLoc !== -1 && (scoreThreshold = Math.min(getBitapScore(0, bestLoc), scoreThreshold)));
    const matchmask = 1 << pattern.length - 1;
    bestLoc = -1;
    let binMin, binMid, binMax = pattern.length + text.length, lastRd = [];
    for(let d = 0; d < pattern.length; d++){
        for(binMin = 0, binMid = binMax; binMin < binMid;)getBitapScore(d, loc + binMid) <= scoreThreshold ? binMin = binMid : binMax = binMid, binMid = Math.floor((binMax - binMin) / 2 + binMin);
        binMax = binMid;
        let start = Math.max(1, loc - binMid + 1);
        const finish = Math.min(loc + binMid, text.length) + pattern.length, rd = new Array(finish + 2);
        rd[finish + 1] = (1 << d) - 1;
        for(let j = finish; j >= start; j--){
            const charMatch = s[text.charAt(j - 1)];
            if (d === 0 ? rd[j] = (rd[j + 1] << 1 | 1) & charMatch : rd[j] = (rd[j + 1] << 1 | 1) & charMatch | ((lastRd[j + 1] | lastRd[j]) << 1 | 1) | lastRd[j + 1], rd[j] & matchmask) {
                const score = getBitapScore(d, j - 1);
                if (score <= scoreThreshold) if (scoreThreshold = score, bestLoc = j - 1, bestLoc > loc) start = Math.max(1, 2 * loc - bestLoc);
                else break;
            }
        }
        if (getBitapScore(d + 1, loc) > scoreThreshold) break;
        lastRd = rd;
    }
    return bestLoc;
}
function getAlphabetFromPattern(pattern) {
    const s = {};
    for(let i = 0; i < pattern.length; i++)s[pattern.charAt(i)] = 0;
    for(let i = 0; i < pattern.length; i++)s[pattern.charAt(i)] |= 1 << pattern.length - i - 1;
    return s;
}
function match(text, pattern, searchLocation, options = {}) {
    if (text === null || pattern === null || searchLocation === null) throw new Error("Null input. (match())");
    const loc = Math.max(0, Math.min(searchLocation, text.length));
    if (text === pattern) return 0;
    if (text.length) {
        if (text.substring(loc, loc + pattern.length) === pattern) return loc;
    } else return -1;
    return bitap(text, pattern, loc, options);
}
function diffText1(diffs) {
    const text = [];
    for(let x = 0; x < diffs.length; x++)diffs[x][0] !== DIFF_INSERT && (text[x] = diffs[x][1]);
    return text.join("");
}
function diffText2(diffs) {
    const text = [];
    for(let x = 0; x < diffs.length; x++)diffs[x][0] !== DIFF_DELETE && (text[x] = diffs[x][1]);
    return text.join("");
}
function levenshtein(diffs) {
    let leven = 0, insertions = 0, deletions = 0;
    for(let x = 0; x < diffs.length; x++){
        const op = diffs[x][0], data = diffs[x][1];
        switch(op){
            case DIFF_INSERT:
                insertions += data.length;
                break;
            case DIFF_DELETE:
                deletions += data.length;
                break;
            case DIFF_EQUAL:
                leven += Math.max(insertions, deletions), insertions = 0, deletions = 0;
                break;
            default:
                throw new Error("Unknown diff operation.");
        }
    }
    return leven += Math.max(insertions, deletions), leven;
}
function xIndex(diffs, location) {
    let chars1 = 0, chars2 = 0, lastChars1 = 0, lastChars2 = 0, x;
    for(x = 0; x < diffs.length && (diffs[x][0] !== DIFF_INSERT && (chars1 += diffs[x][1].length), diffs[x][0] !== DIFF_DELETE && (chars2 += diffs[x][1].length), !(chars1 > location)); x++)lastChars1 = chars1, lastChars2 = chars2;
    return diffs.length !== x && diffs[x][0] === DIFF_DELETE ? lastChars2 : lastChars2 + (location - lastChars1);
}
function countUtf8Bytes(str) {
    let bytes = 0;
    for(let i = 0; i < str.length; i++){
        const codePoint = str.codePointAt(i);
        if (typeof codePoint > "u") throw new Error("Failed to get codepoint");
        bytes += utf8len(codePoint);
    }
    return bytes;
}
function adjustIndiciesToUcs2(patches, base, options = {}) {
    let byteOffset = 0, idx = 0;
    function advanceTo(target) {
        for(; byteOffset < target;){
            const codePoint = base.codePointAt(idx);
            if (typeof codePoint > "u") return idx;
            byteOffset += utf8len(codePoint), codePoint > 65535 ? idx += 2 : idx += 1;
        }
        if (!options.allowExceedingIndices && byteOffset !== target) throw new Error("Failed to determine byte offset");
        return idx;
    }
    const adjusted = [];
    for (const patch of patches)adjusted.push({
        diffs: patch.diffs.map((diff2)=>cloneDiff(diff2)),
        start1: advanceTo(patch.start1),
        start2: advanceTo(patch.start2),
        utf8Start1: patch.utf8Start1,
        utf8Start2: patch.utf8Start2,
        length1: patch.length1,
        length2: patch.length2,
        utf8Length1: patch.utf8Length1,
        utf8Length2: patch.utf8Length2
    });
    return adjusted;
}
function utf8len(codePoint) {
    return codePoint <= 127 ? 1 : codePoint <= 2047 ? 2 : codePoint <= 65535 ? 3 : 4;
}
const MAX_BITS = 32, DEFAULT_MARGIN = 4;
function addPadding(patches, margin = DEFAULT_MARGIN) {
    const paddingLength = margin;
    let nullPadding = "";
    for(let x = 1; x <= paddingLength; x++)nullPadding += String.fromCharCode(x);
    for (const p of patches)p.start1 += paddingLength, p.start2 += paddingLength, p.utf8Start1 += paddingLength, p.utf8Start2 += paddingLength;
    let patch = patches[0], diffs = patch.diffs;
    if (diffs.length === 0 || diffs[0][0] !== DIFF_EQUAL) diffs.unshift([
        DIFF_EQUAL,
        nullPadding
    ]), patch.start1 -= paddingLength, patch.start2 -= paddingLength, patch.utf8Start1 -= paddingLength, patch.utf8Start2 -= paddingLength, patch.length1 += paddingLength, patch.length2 += paddingLength, patch.utf8Length1 += paddingLength, patch.utf8Length2 += paddingLength;
    else if (paddingLength > diffs[0][1].length) {
        const firstDiffLength = diffs[0][1].length, extraLength = paddingLength - firstDiffLength;
        diffs[0][1] = nullPadding.substring(firstDiffLength) + diffs[0][1], patch.start1 -= extraLength, patch.start2 -= extraLength, patch.utf8Start1 -= extraLength, patch.utf8Start2 -= extraLength, patch.length1 += extraLength, patch.length2 += extraLength, patch.utf8Length1 += extraLength, patch.utf8Length2 += extraLength;
    }
    if (patch = patches[patches.length - 1], diffs = patch.diffs, diffs.length === 0 || diffs[diffs.length - 1][0] !== DIFF_EQUAL) diffs.push([
        DIFF_EQUAL,
        nullPadding
    ]), patch.length1 += paddingLength, patch.length2 += paddingLength, patch.utf8Length1 += paddingLength, patch.utf8Length2 += paddingLength;
    else if (paddingLength > diffs[diffs.length - 1][1].length) {
        const extraLength = paddingLength - diffs[diffs.length - 1][1].length;
        diffs[diffs.length - 1][1] += nullPadding.substring(0, extraLength), patch.length1 += extraLength, patch.length2 += extraLength, patch.utf8Length1 += extraLength, patch.utf8Length2 += extraLength;
    }
    return nullPadding;
}
function createPatchObject(start1, start2) {
    return {
        diffs: [],
        start1,
        start2,
        utf8Start1: start1,
        utf8Start2: start2,
        length1: 0,
        length2: 0,
        utf8Length1: 0,
        utf8Length2: 0
    };
}
function splitMax(patches, margin = DEFAULT_MARGIN) {
    const patchSize = MAX_BITS;
    for(let x = 0; x < patches.length; x++){
        if (patches[x].length1 <= patchSize) continue;
        const bigpatch = patches[x];
        patches.splice(x--, 1);
        let start1 = bigpatch.start1, start2 = bigpatch.start2, preContext = "";
        for(; bigpatch.diffs.length !== 0;){
            const patch = createPatchObject(start1 - preContext.length, start2 - preContext.length);
            let empty = !0;
            if (preContext !== "") {
                const precontextByteCount = countUtf8Bytes(preContext);
                patch.length1 = preContext.length, patch.utf8Length1 = precontextByteCount, patch.length2 = preContext.length, patch.utf8Length2 = precontextByteCount, patch.diffs.push([
                    DIFF_EQUAL,
                    preContext
                ]);
            }
            for(; bigpatch.diffs.length !== 0 && patch.length1 < patchSize - margin;){
                const diffType = bigpatch.diffs[0][0];
                let diffText = bigpatch.diffs[0][1], diffTextByteCount = countUtf8Bytes(diffText);
                if (diffType === DIFF_INSERT) {
                    patch.length2 += diffText.length, patch.utf8Length2 += diffTextByteCount, start2 += diffText.length;
                    const diff2 = bigpatch.diffs.shift();
                    diff2 && patch.diffs.push(diff2), empty = !1;
                } else diffType === DIFF_DELETE && patch.diffs.length === 1 && patch.diffs[0][0] === DIFF_EQUAL && diffText.length > 2 * patchSize ? (patch.length1 += diffText.length, patch.utf8Length1 += diffTextByteCount, start1 += diffText.length, empty = !1, patch.diffs.push([
                    diffType,
                    diffText
                ]), bigpatch.diffs.shift()) : (diffText = diffText.substring(0, patchSize - patch.length1 - margin), diffTextByteCount = countUtf8Bytes(diffText), patch.length1 += diffText.length, patch.utf8Length1 += diffTextByteCount, start1 += diffText.length, diffType === DIFF_EQUAL ? (patch.length2 += diffText.length, patch.utf8Length2 += diffTextByteCount, start2 += diffText.length) : empty = !1, patch.diffs.push([
                    diffType,
                    diffText
                ]), diffText === bigpatch.diffs[0][1] ? bigpatch.diffs.shift() : bigpatch.diffs[0][1] = bigpatch.diffs[0][1].substring(diffText.length));
            }
            preContext = diffText2(patch.diffs), preContext = preContext.substring(preContext.length - margin);
            const postContext = diffText1(bigpatch.diffs).substring(0, margin), postContextByteCount = countUtf8Bytes(postContext);
            postContext !== "" && (patch.length1 += postContext.length, patch.length2 += postContext.length, patch.utf8Length1 += postContextByteCount, patch.utf8Length2 += postContextByteCount, patch.diffs.length !== 0 && patch.diffs[patch.diffs.length - 1][0] === DIFF_EQUAL ? patch.diffs[patch.diffs.length - 1][1] += postContext : patch.diffs.push([
                DIFF_EQUAL,
                postContext
            ])), empty || patches.splice(++x, 0, patch);
        }
    }
}
function apply(patches, originalText, opts = {}) {
    if (typeof patches == "string") throw new Error("Patches must be an array - pass the patch to `parsePatch()` first");
    let text = originalText;
    if (patches.length === 0) return [
        text,
        []
    ];
    const parsed = adjustIndiciesToUcs2(patches, text, {
        allowExceedingIndices: opts.allowExceedingIndices
    }), margin = opts.margin || DEFAULT_MARGIN, deleteThreshold = opts.deleteThreshold || 0.4, nullPadding = addPadding(parsed, margin);
    text = nullPadding + text + nullPadding, splitMax(parsed, margin);
    let delta = 0;
    const results = [];
    for(let x = 0; x < parsed.length; x++){
        const expectedLoc = parsed[x].start2 + delta, text1 = diffText1(parsed[x].diffs);
        let startLoc, endLoc = -1;
        if (text1.length > MAX_BITS ? (startLoc = match(text, text1.substring(0, MAX_BITS), expectedLoc), startLoc !== -1 && (endLoc = match(text, text1.substring(text1.length - MAX_BITS), expectedLoc + text1.length - MAX_BITS), (endLoc === -1 || startLoc >= endLoc) && (startLoc = -1))) : startLoc = match(text, text1, expectedLoc), startLoc === -1) results[x] = !1, delta -= parsed[x].length2 - parsed[x].length1;
        else {
            results[x] = !0, delta = startLoc - expectedLoc;
            let text2;
            if (endLoc === -1 ? text2 = text.substring(startLoc, startLoc + text1.length) : text2 = text.substring(startLoc, endLoc + MAX_BITS), text1 === text2) text = text.substring(0, startLoc) + diffText2(parsed[x].diffs) + text.substring(startLoc + text1.length);
            else {
                let diffs = diff(text1, text2, {
                    checkLines: !1
                });
                if (text1.length > MAX_BITS && levenshtein(diffs) / text1.length > deleteThreshold) results[x] = !1;
                else {
                    diffs = cleanupSemanticLossless(diffs);
                    let index1 = 0, index2 = 0;
                    for(let y = 0; y < parsed[x].diffs.length; y++){
                        const mod = parsed[x].diffs[y];
                        mod[0] !== DIFF_EQUAL && (index2 = xIndex(diffs, index1)), mod[0] === DIFF_INSERT ? text = text.substring(0, startLoc + index2) + mod[1] + text.substring(startLoc + index2) : mod[0] === DIFF_DELETE && (text = text.substring(0, startLoc + index2) + text.substring(startLoc + xIndex(diffs, index1 + mod[1].length))), mod[0] !== DIFF_DELETE && (index1 += mod[1].length);
                    }
                }
            }
        }
    }
    return text = text.substring(nullPadding.length, text.length - nullPadding.length), [
        text,
        results
    ];
}
var __defProp = Object.defineProperty, __getOwnPropSymbols = Object.getOwnPropertySymbols, __hasOwnProp = Object.prototype.hasOwnProperty, __propIsEnum = Object.prototype.propertyIsEnumerable, __defNormalProp = (obj, key, value)=>key in obj ? __defProp(obj, key, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value
    }) : obj[key] = value, __spreadValues = (a, b)=>{
    for(var prop in b || (b = {}))__hasOwnProp.call(b, prop) && __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols) for (var prop of __getOwnPropSymbols(b))__propIsEnum.call(b, prop) && __defNormalProp(a, prop, b[prop]);
    return a;
};
const DEFAULT_OPTS = {
    margin: 4
};
function getDefaultOpts(opts = {}) {
    return __spreadValues(__spreadValues({}, DEFAULT_OPTS), opts);
}
function make(a, b, options) {
    if (typeof a == "string" && typeof b == "string") {
        let diffs = diff(a, b, {
            checkLines: !0
        });
        return diffs.length > 2 && (diffs = cleanupSemantic(diffs), diffs = cleanupEfficiency(diffs)), _make(a, diffs, getDefaultOpts(options));
    }
    if (a && Array.isArray(a) && typeof b > "u") return _make(diffText1(a), a, getDefaultOpts(options));
    if (typeof a == "string" && b && Array.isArray(b)) return _make(a, b, getDefaultOpts(options));
    throw new Error("Unknown call format to make()");
}
function _make(textA, diffs, options) {
    if (diffs.length === 0) return [];
    const patches = [];
    let patch = createPatchObject(0, 0), patchDiffLength = 0, charCount1 = 0, charCount2 = 0, utf8Count1 = 0, utf8Count2 = 0, prepatchText = textA, postpatchText = textA;
    for(let x = 0; x < diffs.length; x++){
        const currentDiff = diffs[x], [diffType, diffText] = currentDiff, diffTextLength = diffText.length, diffByteLength = countUtf8Bytes(diffText);
        switch(!patchDiffLength && diffType !== DIFF_EQUAL && (patch.start1 = charCount1, patch.start2 = charCount2, patch.utf8Start1 = utf8Count1, patch.utf8Start2 = utf8Count2), diffType){
            case DIFF_INSERT:
                patch.diffs[patchDiffLength++] = currentDiff, patch.length2 += diffTextLength, patch.utf8Length2 += diffByteLength, postpatchText = postpatchText.substring(0, charCount2) + diffText + postpatchText.substring(charCount2);
                break;
            case DIFF_DELETE:
                patch.length1 += diffTextLength, patch.utf8Length1 += diffByteLength, patch.diffs[patchDiffLength++] = currentDiff, postpatchText = postpatchText.substring(0, charCount2) + postpatchText.substring(charCount2 + diffTextLength);
                break;
            case DIFF_EQUAL:
                diffTextLength <= 2 * options.margin && patchDiffLength && diffs.length !== x + 1 ? (patch.diffs[patchDiffLength++] = currentDiff, patch.length1 += diffTextLength, patch.length2 += diffTextLength, patch.utf8Length1 += diffByteLength, patch.utf8Length2 += diffByteLength) : diffTextLength >= 2 * options.margin && patchDiffLength && (addContext(patch, prepatchText, options), patches.push(patch), patch = createPatchObject(-1, -1), patchDiffLength = 0, prepatchText = postpatchText, charCount1 = charCount2, utf8Count1 = utf8Count2);
                break;
            default:
                throw new Error("Unknown diff type");
        }
        diffType !== DIFF_INSERT && (charCount1 += diffTextLength, utf8Count1 += diffByteLength), diffType !== DIFF_DELETE && (charCount2 += diffTextLength, utf8Count2 += diffByteLength);
    }
    return patchDiffLength && (addContext(patch, prepatchText, options), patches.push(patch)), patches;
}
function addContext(patch, text, opts) {
    if (text.length === 0) return;
    let pattern = text.substring(patch.start2, patch.start2 + patch.length1), padding = 0;
    for(; text.indexOf(pattern) !== text.lastIndexOf(pattern) && pattern.length < MAX_BITS - opts.margin - opts.margin;)padding += opts.margin, pattern = text.substring(patch.start2 - padding, patch.start2 + patch.length1 + padding);
    padding += opts.margin;
    let prefixStart = patch.start2 - padding;
    prefixStart >= 1 && isLowSurrogate(text[prefixStart]) && prefixStart--;
    const prefix = text.substring(prefixStart, patch.start2);
    prefix && patch.diffs.unshift([
        DIFF_EQUAL,
        prefix
    ]);
    const prefixLength = prefix.length, prefixUtf8Length = countUtf8Bytes(prefix);
    let suffixEnd = patch.start2 + patch.length1 + padding;
    suffixEnd < text.length && isLowSurrogate(text[suffixEnd]) && suffixEnd++;
    const suffix = text.substring(patch.start2 + patch.length1, suffixEnd);
    suffix && patch.diffs.push([
        DIFF_EQUAL,
        suffix
    ]);
    const suffixLength = suffix.length, suffixUtf8Length = countUtf8Bytes(suffix);
    patch.start1 -= prefixLength, patch.start2 -= prefixLength, patch.utf8Start1 -= prefixUtf8Length, patch.utf8Start2 -= prefixUtf8Length, patch.length1 += prefixLength + suffixLength, patch.length2 += prefixLength + suffixLength, patch.utf8Length1 += prefixUtf8Length + suffixUtf8Length, patch.utf8Length2 += prefixUtf8Length + suffixUtf8Length;
}
const patchHeader = /^@@ -(\d+),?(\d*) \+(\d+),?(\d*) @@$/;
function parse(textline) {
    if (!textline) return [];
    const patches = [], lines = textline.split(`
`);
    let textPointer = 0;
    for(; textPointer < lines.length;){
        const m = lines[textPointer].match(patchHeader);
        if (!m) throw new Error(`Invalid patch string: ${lines[textPointer]}`);
        const patch = createPatchObject(toInt(m[1]), toInt(m[3]));
        for(patches.push(patch), m[2] === "" ? (patch.start1--, patch.utf8Start1--, patch.length1 = 1, patch.utf8Length1 = 1) : m[2] === "0" ? (patch.length1 = 0, patch.utf8Length1 = 0) : (patch.start1--, patch.utf8Start1--, patch.utf8Length1 = toInt(m[2]), patch.length1 = patch.utf8Length1), m[4] === "" ? (patch.start2--, patch.utf8Start2--, patch.length2 = 1, patch.utf8Length2 = 1) : m[4] === "0" ? (patch.length2 = 0, patch.utf8Length2 = 0) : (patch.start2--, patch.utf8Start2--, patch.utf8Length2 = toInt(m[4]), patch.length2 = patch.utf8Length2), textPointer++; textPointer < lines.length;){
            const currentLine = lines[textPointer], sign = currentLine.charAt(0);
            if (sign === "@") break;
            if (sign === "") {
                textPointer++;
                continue;
            }
            let line;
            try {
                line = decodeURI(currentLine.slice(1));
            } catch (ex) {
                throw new Error(`Illegal escape in parse: ${currentLine}`);
            }
            const utf8Diff = countUtf8Bytes(line) - line.length;
            if (sign === "-") patch.diffs.push([
                DIFF_DELETE,
                line
            ]), patch.length1 -= utf8Diff;
            else if (sign === "+") patch.diffs.push([
                DIFF_INSERT,
                line
            ]), patch.length2 -= utf8Diff;
            else if (sign === " ") patch.diffs.push([
                DIFF_EQUAL,
                line
            ]), patch.length1 -= utf8Diff, patch.length2 -= utf8Diff;
            else throw new Error(`Invalid patch mode "${sign}" in: ${line}`);
            textPointer++;
        }
    }
    return patches;
}
function toInt(num) {
    return parseInt(num, 10);
}
function stringify(patches) {
    return patches.map(stringifyPatch).join("");
}
function stringifyPatch(patch) {
    const { utf8Length1, utf8Length2, utf8Start1, utf8Start2, diffs } = patch;
    let coords1;
    utf8Length1 === 0 ? coords1 = `${utf8Start1},0` : utf8Length1 === 1 ? coords1 = `${utf8Start1 + 1}` : coords1 = `${utf8Start1 + 1},${utf8Length1}`;
    let coords2;
    utf8Length2 === 0 ? coords2 = `${utf8Start2},0` : utf8Length2 === 1 ? coords2 = `${utf8Start2 + 1}` : coords2 = `${utf8Start2 + 1},${utf8Length2}`;
    const text = [
        `@@ -${coords1} +${coords2} @@
`
    ];
    let op;
    for(let x = 0; x < diffs.length; x++){
        switch(diffs[x][0]){
            case DIFF_INSERT:
                op = "+";
                break;
            case DIFF_DELETE:
                op = "-";
                break;
            case DIFF_EQUAL:
                op = " ";
                break;
            default:
                throw new Error("Unknown patch operation.");
        }
        text[x + 1] = `${op + encodeURI(diffs[x][1])}
`;
    }
    return text.join("").replace(/%20/g, " ");
}
;
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/nanoid/url-alphabet/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "urlAlphabet",
    ()=>urlAlphabet
]);
let urlAlphabet = 'useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict';
}),
"[project]/node_modules/@sanity/visual-editing/node_modules/nanoid/index.browser.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "customAlphabet",
    ()=>customAlphabet,
    "customRandom",
    ()=>customRandom,
    "nanoid",
    ()=>nanoid,
    "random",
    ()=>random
]);
/* @ts-self-types="./index.d.ts" */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$nanoid$2f$url$2d$alphabet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/visual-editing/node_modules/nanoid/url-alphabet/index.js [app-client] (ecmascript)");
;
;
let random = (bytes)=>crypto.getRandomValues(new Uint8Array(bytes));
let customRandom = (alphabet, defaultSize, getRandom)=>{
    let safeByteCutoff = 256 - 256 % alphabet.length;
    if (safeByteCutoff === 256) {
        let mask = alphabet.length - 1;
        return (size = defaultSize)=>{
            if (!size) return '';
            let id = '';
            while(true){
                let bytes = getRandom(size);
                let j = size;
                while(j--){
                    id += alphabet[bytes[j] & mask];
                    if (id.length >= size) return id;
                }
            }
        };
    }
    let step = Math.ceil(1.6 * 256 * defaultSize / safeByteCutoff);
    return (size = defaultSize)=>{
        if (!size) return '';
        let id = '';
        while(true){
            let bytes = getRandom(step);
            let j = step;
            while(j--){
                if (bytes[j] < safeByteCutoff) {
                    id += alphabet[bytes[j] % alphabet.length];
                    if (id.length >= size) return id;
                }
            }
        }
    };
};
let customAlphabet = (alphabet, size = 21)=>customRandom(alphabet, size | 0, random);
let nanoid = (size = 21)=>{
    let id = '';
    let bytes = crypto.getRandomValues(new Uint8Array(size |= 0));
    while(size--){
        id += __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$visual$2d$editing$2f$node_modules$2f$nanoid$2f$url$2d$alphabet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["urlAlphabet"][bytes[size] & 63];
    }
    return id;
};
}),
"[project]/node_modules/mendoza/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "applyPatch",
    ()=>applyPatch,
    "incremental",
    ()=>incrementalPatcher
]);
const OPS = [
    "Value",
    "Copy",
    "Blank",
    "ReturnIntoArray",
    "ReturnIntoObject",
    "ReturnIntoObjectSameKey",
    "PushField",
    "PushElement",
    "PushParent",
    "Pop",
    "PushFieldCopy",
    "PushFieldBlank",
    "PushElementCopy",
    "PushElementBlank",
    "ReturnIntoObjectPop",
    "ReturnIntoObjectSameKeyPop",
    "ReturnIntoArrayPop",
    "ObjectSetFieldValue",
    "ObjectCopyField",
    "ObjectDeleteField",
    "ArrayAppendValue",
    "ArrayAppendSlice",
    "StringAppendString",
    "StringAppendSlice"
];
class Patcher {
    model;
    root;
    patch;
    i;
    inputStack;
    outputStack;
    constructor(model, root, patch){
        this.model = model, this.root = root, this.patch = patch, this.i = 0, this.inputStack = [], this.outputStack = [];
    }
    read() {
        return this.patch[this.i++];
    }
    process() {
        for(this.inputStack.push({
            value: this.root
        }), this.outputStack.push({
            value: this.root
        }); this.i < this.patch.length;){
            let opcode = this.read(), op = OPS[opcode];
            if (!op) throw new Error(`Unknown opcode: ${opcode}`);
            let processor = `process${op}`;
            this[processor].apply(this);
        }
        let entry = this.outputStack.pop();
        return this.finalizeOutput(entry);
    }
    inputEntry() {
        return this.inputStack[this.inputStack.length - 1];
    }
    inputKey(entry, idx) {
        return entry.keys || (entry.keys = this.model.objectGetKeys(entry.value).sort()), entry.keys[idx];
    }
    outputEntry() {
        return this.outputStack[this.outputStack.length - 1];
    }
    outputArray() {
        let entry = this.outputEntry();
        return entry.writeValue || (entry.writeValue = this.model.copyArray(entry.value)), entry.writeValue;
    }
    outputObject() {
        let entry = this.outputEntry();
        return entry.writeValue || (entry.writeValue = this.model.copyObject(entry.value)), entry.writeValue;
    }
    outputString() {
        let entry = this.outputEntry();
        return entry.writeValue || (entry.writeValue = this.model.copyString(entry.value)), entry.writeValue;
    }
    finalizeOutput(entry) {
        return entry.writeValue ? this.model.finalize(entry.writeValue) : entry.value;
    }
    // Processors:
    processValue() {
        let value = this.model.wrap(this.read());
        this.outputStack.push({
            value
        });
    }
    processCopy() {
        let input = this.inputEntry();
        this.outputStack.push({
            value: input.value
        });
    }
    processBlank() {
        this.outputStack.push({
            value: null
        });
    }
    processReturnIntoArray() {
        let entry = this.outputStack.pop(), result = this.finalizeOutput(entry), arr = this.outputArray();
        this.model.arrayAppendValue(arr, result);
    }
    processReturnIntoObject() {
        let key = this.read(), entry = this.outputStack.pop(), result = this.finalizeOutput(entry);
        result = this.model.markChanged(result);
        let obj = this.outputObject();
        this.model.objectSetField(obj, key, result);
    }
    processReturnIntoObjectSameKey() {
        let input = this.inputEntry(), entry = this.outputStack.pop(), result = this.finalizeOutput(entry), obj = this.outputObject();
        this.model.objectSetField(obj, input.key, result);
    }
    processPushField() {
        let idx = this.read(), entry = this.inputEntry(), key = this.inputKey(entry, idx), value = this.model.objectGetField(entry.value, key);
        this.inputStack.push({
            value,
            key
        });
    }
    processPushElement() {
        let idx = this.read(), entry = this.inputEntry(), value = this.model.arrayGetElement(entry.value, idx);
        this.inputStack.push({
            value
        });
    }
    processPop() {
        this.inputStack.pop();
    }
    processPushFieldCopy() {
        this.processPushField(), this.processCopy();
    }
    processPushFieldBlank() {
        this.processPushField(), this.processBlank();
    }
    processPushElementCopy() {
        this.processPushElement(), this.processCopy();
    }
    processPushElementBlank() {
        this.processPushElement(), this.processBlank();
    }
    processReturnIntoObjectPop() {
        this.processReturnIntoObject(), this.processPop();
    }
    processReturnIntoObjectSameKeyPop() {
        this.processReturnIntoObjectSameKey(), this.processPop();
    }
    processReturnIntoArrayPop() {
        this.processReturnIntoArray(), this.processPop();
    }
    processObjectSetFieldValue() {
        this.processValue(), this.processReturnIntoObject();
    }
    processObjectCopyField() {
        this.processPushField(), this.processCopy(), this.processReturnIntoObjectSameKey(), this.processPop();
    }
    processObjectDeleteField() {
        let idx = this.read(), entry = this.inputEntry(), key = this.inputKey(entry, idx), obj = this.outputObject();
        this.model.objectDeleteField(obj, key);
    }
    processArrayAppendValue() {
        let value = this.model.wrap(this.read()), arr = this.outputArray();
        this.model.arrayAppendValue(arr, value);
    }
    processArrayAppendSlice() {
        let left = this.read(), right = this.read(), str = this.outputArray(), val = this.inputEntry().value;
        this.model.arrayAppendSlice(str, val, left, right);
    }
    processStringAppendString() {
        let value = this.model.wrap(this.read()), str = this.outputString();
        this.model.stringAppendValue(str, value);
    }
    processStringAppendSlice() {
        let left = this.read(), right = this.read(), str = this.outputString(), val = this.inputEntry().value;
        this.model.stringAppendSlice(str, val, left, right);
    }
}
function utf8charSize(code) {
    return code >> 16 ? 4 : code >> 11 ? 3 : code >> 7 ? 2 : 1;
}
function utf8stringSize(str) {
    let b = 0;
    for(let i = 0; i < str.length; i++){
        let code = str.codePointAt(i), size = utf8charSize(code);
        size == 4 && i++, b += size;
    }
    return b;
}
function utf8resolveIndex(str, idx, start = 0) {
    let byteCount = start, ucsIdx = 0;
    for(ucsIdx = start; byteCount < idx; ucsIdx++){
        let code = str.codePointAt(ucsIdx), size = utf8charSize(code);
        size === 4 && ucsIdx++, byteCount += size;
    }
    return ucsIdx;
}
function commonPrefix(str, str2) {
    let len = Math.min(str.length, str2.length), b = 0;
    for(let i = 0; i < len;){
        let aPoint = str.codePointAt(i), bPoint = str2.codePointAt(i);
        if (aPoint !== bPoint) return b;
        let size = utf8charSize(aPoint);
        b += size, i += size === 4 ? 2 : 1;
    }
    return b;
}
function commonSuffix(str, str2, prefix = 0) {
    let len = Math.min(str.length, str2.length) - prefix, b = 0;
    for(let i = 0; i < len;){
        let aPoint = str.codePointAt(str.length - 1 - i), bPoint = str2.codePointAt(str2.length - 1 - i);
        if (aPoint !== bPoint) return b;
        let size = utf8charSize(aPoint);
        b += size, i += size === 4 ? 2 : 1;
    }
    return b;
}
class IncrementalModel {
    meta;
    constructor(meta){
        this.meta = meta;
    }
    wrap(data) {
        return this.wrapWithMeta(data, this.meta, this.meta);
    }
    wrapWithMeta(data, startMeta, endMeta = this.meta) {
        return {
            data,
            startMeta,
            endMeta
        };
    }
    asObject(value) {
        if (!value.content) {
            let fields = {};
            for (let [key, val] of Object.entries(value.data))fields[key] = this.wrapWithMeta(val, value.startMeta);
            value.content = {
                type: "object",
                fields
            };
        }
        return value.content;
    }
    asArray(value) {
        if (!value.content) {
            let elements = value.data.map((item)=>this.wrapWithMeta(item, value.startMeta)), metas = elements.map(()=>this.meta);
            value.content = {
                type: "array",
                elements,
                metas
            };
        }
        return value.content;
    }
    asString(value) {
        if (!value.content) {
            let str = value.data, part = {
                value: str,
                utf8size: utf8stringSize(str),
                uses: [],
                startMeta: value.startMeta,
                endMeta: value.endMeta
            };
            value.content = this.stringFromParts([
                part
            ]);
        }
        return value.content;
    }
    stringFromParts(parts) {
        let str = {
            type: "string",
            parts
        };
        for (let part of parts)part.uses.push(str);
        return str;
    }
    objectGetKeys(value) {
        return value.content ? Object.keys(value.content.fields) : Object.keys(value.data);
    }
    objectGetField(value, key) {
        return this.asObject(value).fields[key];
    }
    arrayGetElement(value, idx) {
        return this.asArray(value).elements[idx];
    }
    finalize(content) {
        return this.updateEndMeta(content), {
            content,
            startMeta: this.meta,
            endMeta: this.meta
        };
    }
    markChanged(value) {
        return this.wrap(unwrap(value));
    }
    updateEndMeta(content) {
        if (content.type == "string") for (let part of content.parts)part.endMeta = this.meta;
        else if (content.type === "array") for (let val of content.elements)val.content && val.endMeta !== this.meta && this.updateEndMeta(val.content), val.endMeta = this.meta;
        else for (let val of Object.values(content.fields))val.content && val.endMeta !== this.meta && this.updateEndMeta(val.content), val.endMeta = this.meta;
    }
    copyString(value) {
        if (value) {
            let other = this.asString(value);
            return this.stringFromParts(other.parts.slice());
        } else return {
            type: "string",
            parts: []
        };
    }
    copyObject(value) {
        let obj = {
            type: "object",
            fields: {}
        };
        if (value) {
            let other = this.asObject(value);
            Object.assign(obj.fields, other.fields);
        }
        return obj;
    }
    copyArray(value) {
        let arr = value ? this.asArray(value) : null, elements = arr ? arr.elements : [], metas = arr ? arr.metas : [];
        return {
            type: "array",
            elements,
            metas
        };
    }
    objectSetField(target, key, value) {
        target.fields[key] = value;
    }
    objectDeleteField(target, key) {
        delete target.fields[key];
    }
    arrayAppendValue(target, value) {
        target.elements.push(value), target.metas.push(this.meta);
    }
    arrayAppendSlice(target, source, left, right) {
        let arr = this.asArray(source), samePosition = arr.elements.length === left;
        if (target.elements.push(...arr.elements.slice(left, right)), samePosition) target.metas.push(...arr.metas.slice(left, right));
        else for(let i = left; i < right; i++)target.metas.push(this.meta);
    }
    stringAppendValue(target, value) {
        let str = this.asString(value);
        for (let part of str.parts)this.stringAppendPart(target, part);
    }
    stringAppendPart(target, part) {
        target.parts.push(part), part.uses.push(target);
    }
    resolveStringPart(str, from, len) {
        if (len === 0) return from;
        for(let i = from; i < str.parts.length; i++){
            let part = str.parts[i];
            if (len === part.utf8size) return i + 1;
            if (len < part.utf8size) return this.splitString(part, len), i + 1;
            len -= part.utf8size;
        }
        throw new Error("splitting string out of bounds");
    }
    splitString(part, idx) {
        let leftValue, rightValue, leftSize = idx, rightSize = part.utf8size - leftSize;
        if (part.utf8size !== part.value.length) {
            let byteCount = 0;
            for(idx = 0; byteCount < leftSize; idx++){
                let code = part.value.codePointAt(idx), size = utf8charSize(code);
                size === 4 && idx++, byteCount += size;
            }
        }
        leftValue = part.value.slice(0, idx), rightValue = part.value.slice(idx);
        let newPart = {
            value: rightValue,
            utf8size: rightSize,
            uses: part.uses.slice(),
            startMeta: part.startMeta,
            endMeta: part.endMeta
        };
        part.value = leftValue, part.utf8size = leftSize;
        for (let use of part.uses){
            let ndx = use.parts.indexOf(part);
            if (ndx === -1) throw new Error("bug: mismatch between string parts and use.");
            use.parts.splice(ndx + 1, 0, newPart);
        }
    }
    stringAppendSlice(target, source, left, right) {
        let str = this.asString(source), firstPart = this.resolveStringPart(str, 0, left), lastPart = this.resolveStringPart(str, firstPart, right - left);
        for(let i = firstPart; i < lastPart; i++){
            let part = str.parts[i];
            this.stringAppendPart(target, part);
        }
    }
}
function wrap(data, meta) {
    return {
        data,
        startMeta: meta,
        endMeta: meta
    };
}
function unwrap(value) {
    if (typeof value.data < "u") return value.data;
    let result, content = value.content;
    switch(content.type){
        case "string":
            result = content.parts.map((part)=>part.value).join("");
            break;
        case "array":
            result = content.elements.map((val)=>unwrap(val));
            break;
        case "object":
            {
                result = {};
                for (let [key, val] of Object.entries(content.fields))result[key] = unwrap(val);
            }
    }
    return value.data = result, result;
}
function getType(value) {
    return value.content ? value.content.type : Array.isArray(value.data) ? "array" : value.data === null ? "null" : typeof value.data;
}
function rebaseValue(left, right) {
    let leftType = getType(left), rightType = getType(right);
    if (leftType !== rightType) return right;
    let leftModel = new IncrementalModel(left.endMeta), rightModel = new IncrementalModel(right.endMeta);
    switch(leftType){
        case "object":
            {
                let leftObj = leftModel.asObject(left), rightObj = rightModel.asObject(right), identicalFieldCount = 0, leftFieldCount = Object.keys(leftObj.fields).length, rightFieldCount = Object.keys(rightObj.fields).length;
                for (let [key, rightVal] of Object.entries(rightObj.fields)){
                    let leftVal = leftObj.fields[key];
                    leftVal && (rightObj.fields[key] = rebaseValue(leftVal, rightVal), rightObj.fields[key] === leftVal && identicalFieldCount++);
                }
                return leftFieldCount === rightFieldCount && leftFieldCount === identicalFieldCount ? left : right;
            }
        case "array":
            {
                let leftArr = leftModel.asArray(left), rightArr = rightModel.asArray(right);
                if (leftArr.elements.length !== rightArr.elements.length) break;
                let numRebased = 0;
                for(let i = 0; i < rightArr.elements.length; i++)rightArr.elements[i] = rebaseValue(leftArr.elements[i], rightArr.elements[i]), rightArr.elements[i] !== leftArr.elements[i] && numRebased++;
                return numRebased === 0 ? left : right;
            }
        case "null":
        case "boolean":
        case "number":
            {
                if (unwrap(left) === unwrap(right)) return left;
                break;
            }
        case "string":
            {
                let leftRaw = unwrap(left), rightRaw = unwrap(right);
                if (leftRaw === rightRaw) return left;
                let result = rightModel.copyString(null), prefix = commonPrefix(leftRaw, rightRaw), suffix = commonSuffix(leftRaw, rightRaw, prefix), rightLen = utf8stringSize(rightRaw), leftLen = utf8stringSize(leftRaw);
                0 < prefix && rightModel.stringAppendSlice(result, left, 0, prefix), prefix < rightLen - suffix && rightModel.stringAppendSlice(result, right, prefix, rightLen - suffix), leftLen - suffix < leftLen && rightModel.stringAppendSlice(result, left, leftLen - suffix, leftLen);
                let value = rightModel.finalize(result);
                if (unwrap(value) !== rightRaw) throw new Error("incorrect string rebase");
                return value;
            }
    }
    return right;
}
function applyPatch$1(left, patch, startMeta) {
    let model = new IncrementalModel(startMeta);
    return new Patcher(model, left, patch).process();
}
var incrementalPatcher = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    applyPatch: applyPatch$1,
    getType,
    rebaseValue,
    unwrap,
    wrap
});
class SimpleModel {
    wrap(data) {
        return data;
    }
    finalize(b) {
        return Array.isArray(b) ? b : b.data;
    }
    markChanged(value) {
        return value;
    }
    objectGetKeys(value) {
        return Object.keys(value);
    }
    objectGetField(value, key) {
        return value[key];
    }
    arrayGetElement(value, idx) {
        return value[idx];
    }
    copyObject(value) {
        let res = {
            type: "object",
            data: {}
        };
        if (value !== null) for (let [key, val] of Object.entries(value))res.data[key] = val;
        return res;
    }
    copyArray(value) {
        return value === null ? [] : value.slice();
    }
    copyString(value) {
        return {
            type: "string",
            data: value === null ? "" : value
        };
    }
    objectSetField(target, key, value) {
        target.data[key] = value;
    }
    objectDeleteField(target, key) {
        delete target.data[key];
    }
    arrayAppendValue(target, value) {
        target.push(value);
    }
    arrayAppendSlice(target, source, left, right) {
        target.push(...source.slice(left, right));
    }
    stringAppendSlice(target, source, left, right) {
        const sourceString = source, leftPos = utf8resolveIndex(sourceString, left), rightPos = utf8resolveIndex(sourceString, right, leftPos);
        target.data += sourceString.slice(leftPos, rightPos);
    }
    stringAppendValue(target, value) {
        target.data += value;
    }
}
function applyPatch(left, patch) {
    let root = left;
    return new Patcher(new SimpleModel(), root, patch).process();
}
;
}),
"[project]/node_modules/dequal/lite/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "dequal",
    ()=>dequal
]);
var has = Object.prototype.hasOwnProperty;
function dequal(foo, bar) {
    var ctor, len;
    if (foo === bar) return true;
    if (foo && bar && (ctor = foo.constructor) === bar.constructor) {
        if (ctor === Date) return foo.getTime() === bar.getTime();
        if (ctor === RegExp) return foo.toString() === bar.toString();
        if (ctor === Array) {
            if ((len = foo.length) === bar.length) {
                while(len-- && dequal(foo[len], bar[len]));
            }
            return len === -1;
        }
        if (!ctor || typeof foo === 'object') {
            len = 0;
            for(ctor in foo){
                if (has.call(foo, ctor) && ++len && !has.call(bar, ctor)) return false;
                if (!(ctor in bar) || !dequal(foo[ctor], bar[ctor])) return false;
            }
            return Object.keys(bar).length === len;
        }
    }
    return foo !== foo && bar !== bar;
}
}),
"[project]/node_modules/next-sanity/dist/live/client-components/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SanityLive",
    ()=>SanityLive
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
"use client";
;
/**
* @internal CAUTION: this is an internal component and does not follow semver. Using it directly is at your own risk.
*/ const SanityLive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/node_modules/next-sanity/dist/SanityLive.js [app-client] (ecmascript, async loader)"), {
    ssr: false
});
;
}),
"[project]/node_modules/next-sanity/dist/visual-editing/client-component/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VisualEditing",
    ()=>VisualEditing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
"use client";
;
const VisualEditing = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/node_modules/next-sanity/dist/VisualEditing.js [app-client] (ecmascript, async loader)"), {
    ssr: false
});
;
}),
]);

//# debugId=b203e564-0f3a-6467-60e7-d10b2a0d548d
//# sourceMappingURL=node_modules_0r-8-lb._.js.map