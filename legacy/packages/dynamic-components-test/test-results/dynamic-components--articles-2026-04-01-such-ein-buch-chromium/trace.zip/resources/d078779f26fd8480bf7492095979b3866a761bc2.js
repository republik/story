;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="07769603-3b39-ccc8-1b9c-de719d5442e2")}catch(e){}}();
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/www/src/app/(sanity)/components/portable-text/marks.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Em",
    ()=>Em,
    "ExternalLink",
    ()=>ExternalLink,
    "InternalLink",
    ()=>InternalLink,
    "Strong",
    ()=>Strong,
    "Sub",
    ()=>Sub,
    "Sup",
    ()=>Sup
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
;
;
function Strong({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            fontWeight: 700
        }),
        children: children
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/marks.tsx",
        lineNumber: 7,
        columnNumber: 10
    }, this);
}
_c = Strong;
function Em({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("em", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            fontStyle: 'italic'
        }),
        children: children
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/marks.tsx",
        lineNumber: 11,
        columnNumber: 10
    }, this);
}
_c1 = Em;
const subSupBaseAttrs = {
    display: 'inline-block',
    textDecoration: 'none',
    fontSize: '75%',
    lineHeight: '1.4em',
    position: 'relative',
    verticalAlign: 'baseline'
};
function Sup({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("sup", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            ...subSupBaseAttrs,
            top: '-0.5em'
        }),
        children: children
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/marks.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_c2 = Sup;
function Sub({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("sub", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            ...subSupBaseAttrs,
            bottom: '-0.25em'
        }),
        children: children
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/marks.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_c3 = Sub;
const linkStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
    textDecoration: 'underline',
    cursor: 'pointer'
});
function InternalLink({ text, value }) {
    const href = value.slug?.current;
    return href ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: href,
        className: linkStyle,
        children: text
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/marks.tsx",
        lineNumber: 45,
        columnNumber: 5
    }, this) : text;
}
_c4 = InternalLink;
function ExternalLink({ text, value }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
        href: value.href,
        target: "_blank",
        rel: "noreferrer",
        className: linkStyle,
        children: text
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/marks.tsx",
        lineNumber: 55,
        columnNumber: 5
    }, this);
}
_c5 = ExternalLink;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "Strong");
__turbopack_context__.k.register(_c1, "Em");
__turbopack_context__.k.register(_c2, "Sup");
__turbopack_context__.k.register(_c3, "Sub");
__turbopack_context__.k.register(_c4, "InternalLink");
__turbopack_context__.k.register(_c5, "ExternalLink");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/portable-text/unknownComponent.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "UnknownType",
    ()=>UnknownType
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function UnknownType({ value, isInline }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        style: isInline ? {
            background: 'hotpink'
        } : {
            background: 'hotpink',
            display: 'block',
            padding: 30,
            overflowWrap: 'anywhere'
        },
        children: JSON.stringify(value, null, 2)
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/unknownComponent.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
}
_c = UnknownType;
var _c;
__turbopack_context__.k.register(_c, "UnknownType");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/portable-text/render.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InlinePortableText",
    ()=>InlinePortableText,
    "NestedPortableText",
    ()=>NestedPortableText
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$marks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/portable-text/marks.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$unknownComponent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/portable-text/unknownComponent.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$portabletext$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@portabletext/react/dist/index.js [app-client] (ecmascript) <locals>");
;
;
;
;
const inlineComponents = {
    unknownType: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$unknownComponent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnknownType"],
    block: {
        // Inline PT can only contain 1 paragraph, so we unwrap it
        normal: ({ children })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: children
            }, void 0, false)
    },
    marks: {
        strong: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$marks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Strong"],
        em: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$marks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Em"],
        sub: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$marks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sub"],
        sup: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$marks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sup"],
        link: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$marks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ExternalLink"],
        internalLink: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$marks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternalLink"]
    }
};
function InlinePortableText({ value }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$portabletext$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PortableText"], {
        components: inlineComponents,
        value: value
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/render.tsx",
        lineNumber: 31,
        columnNumber: 10
    }, this);
}
_c = InlinePortableText;
const nestedComponents = {
    unknownType: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$unknownComponent$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnknownType"],
    block: {
        heading: ({ children })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                children: children
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/render.tsx",
                lineNumber: 38,
                columnNumber: 32
            }, ("TURBOPACK compile-time value", void 0))
    },
    marks: {
        strong: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$marks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Strong"],
        em: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$marks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Em"],
        sub: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$marks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sub"],
        sup: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$marks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sup"],
        link: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$marks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ExternalLink"],
        internalLink: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$marks$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternalLink"]
    }
};
function NestedPortableText({ value }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$portabletext$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PortableText"], {
        components: nestedComponents,
        value: value
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/render.tsx",
        lineNumber: 51,
        columnNumber: 10
    }, this);
}
_c1 = NestedPortableText;
var _c, _c1;
__turbopack_context__.k.register(_c, "InlinePortableText");
__turbopack_context__.k.register(_c1, "NestedPortableText");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/translations.json.[json].cjs [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = JSON.parse("{\"data\":[{\"key\":\"nav/events\",\"value\":\"Veranstaltungen\"},{\"key\":\"nav/searchLink\",\"value\":\"Spickzettel\"},{\"key\":\"nav/community\",\"value\":\"Community\"},{\"key\":\"nav/genossenschaftsrat\",\"value\":\"Genossenschaftsrat\"},{\"key\":\"nav/team\",\"value\":\"Team\"},{\"key\":\"nav/give\",\"value\":\"Verschenken\"},{\"key\":\"nav/donate\",\"value\":\"Freiwilliger Beitrag\"},{\"key\":\"nav/share\",\"value\":\"Republik teilen\"},{\"key\":\"nav/invite-friends\",\"value\":\"Verstärkung holen\"},{\"key\":\"nav/becomemember\",\"value\":\"Mitglied werden\"},{\"key\":\"nav/active-page\",\"value\":\"(aktive Seite)\"},{\"key\":\"nav/sections\",\"value\":\"Alle Rubriken\"},{\"key\":\"navbar/front\",\"value\":\"Magazin\"},{\"key\":\"navbar/feed\",\"value\":\"Feed\"},{\"key\":\"navbar/discussion\",\"value\":\"Dialog\"},{\"key\":\"navbar/climatelab\",\"value\":\"Klimalabor\"},{\"key\":\"pages/magazine/title\",\"value\":\"Magazin\"},{\"key\":\"pages/index/pageTitle\",\"value\":\"Republik – das digitale Magazin\"},{\"key\":\"pages/index/title\",\"value\":\"Republik\"},{\"key\":\"pages/index/description\",\"value\":\"Kommen Sie jetzt an Bord.\"},{\"key\":\"pages/feuilleton/pageTitle\",\"value\":\"Republik-Feuilleton\"},{\"key\":\"pages/feuilleton/title\",\"value\":\"Lesen Sie Kulturjournalismus mit Relevanz!\"},{\"key\":\"pages/feuilleton/description\",\"value\":\"Die Republik ist ein digitales Magazin, sein Feuilleton steht für Kulturkritik auf der Höhe unserer Zeit. Die Republik wird von ihren Leserinnen und Lesern finanziert. Kommen Sie an Bord!\"},{\"key\":\"discussion/pageTitle\",\"value\":\"Alle Diskussionen\"},{\"key\":\"pages/feed/title\",\"value\":\"Feed\"},{\"key\":\"pages/notifications/title\",\"value\":\"Benachrichtigungen\"},{\"key\":\"pages/search/title\",\"value\":\"Suche\"},{\"key\":\"pages/account/title\",\"value\":\"Konto\"},{\"key\":\"pages/signin/title\",\"value\":\"Anmelden\"},{\"key\":\"pages/signin/message\",\"value\":\"Melden Sie sich mit der E-Mail-Adresse an, die zu Ihrem Abonnement gehört.\"},{\"key\":\"pages/profile/pageTitle\",\"value\":\"Profil von {name} – Republik\"},{\"key\":\"pages/profile/title\",\"value\":\"Profil von {name}\"},{\"key\":\"pages/profile/empty/pageTitle\",\"value\":\"Profil – Republik\"},{\"key\":\"pages/profile/empty/title\",\"value\":\"Dieses Profil wurde nicht gefunden, weil es nicht existiert oder Sie es nicht sehen dürfen.\"},{\"key\":\"pages/claim/meta/title\",\"value\":\"Gutschein einlösen\"},{\"key\":\"pages/claim/meta/description\",\"value\":\"Lösen Sie hier Ihren Gutschein ein.\"},{\"key\":\"Frame/Popover/myaccount\",\"value\":\"Konto\"},{\"key\":\"Frame/Popover/myprofile\",\"value\":\"Profil\"},{\"key\":\"withAuthorization/title\",\"value\":\"Geschützter Bereich\"},{\"key\":\"withAuthorization/authorizedRoles\",\"value\":\"Zugelassene Rollen: {roles}\"},{\"key\":\"withMembership/title\",\"value\":\"Verlegerbereich\"},{\"key\":\"withMembership/signIn/note\",\"value\":\"Noch nicht Verlegerin? {buyLink} {moreLink}\"},{\"key\":\"withMembership/signIn/note/buyText\",\"value\":\"Jetzt beitreten!\"},{\"key\":\"withMembership/signIn/note/moreText\",\"value\":\"Mehr erfahren.\"},{\"key\":\"withMembership/unauthorized\",\"value\":\"Sie haben keine aktive Mitgliedschaft. {buyLink} oder {accountLink}?\"},{\"key\":\"withMembership/unauthorized/buyText\",\"value\":\"Jetzt kaufen\"},{\"key\":\"withMembership/unauthorized/accountText\",\"value\":\"Konto ansehen\"},{\"key\":\"withMembership/native/unauthorized/title\",\"value\":\"Verlegerbereich\"},{\"key\":\"withMembership/native/unauthorized/noMembership\",\"value\":\"Sie haben keine aktive Mitgliedschaft.\"},{\"key\":\"withMembership/native/unauthorized/signIn\",\"value\":\"Die Nutzung der App erfordert eine Mitgliedschaft oder ein Abo bei der Republik. \"},{\"key\":\"withMembership/ios/unauthorized/claimText\",\"value\":\"Sie haben einen Gutschein? {claimLink}.\"},{\"key\":\"withMembership/ios/unauthorized/claimLink\",\"value\":\"Jetzt einlösen\"},{\"key\":\"network-error/failed\",\"value\":\"Die Verbindung zur Republik ist fehlgeschlagen. Bitte prüfen Sie Ihre Internetverbindung und versuchen Sie es erneut.\"},{\"key\":\"network-error/misc\",\"value\":\"Bei Ihrer Anfrage ist ein Fehler aufgetreten: «{error}». Erste-Hilfe-Team: kontakt@republik.ch.\"},{\"key\":\"signIn/button\",\"value\":\"Anmelden\"},{\"key\":\"signIn/email/label\",\"value\":\"E-Mail-Adresse\"},{\"key\":\"signIn/faq\",\"value\":\"FAQ\"},{\"key\":\"signIn/privacy\",\"value\":\"Datenschutz\"},{\"key\":\"signIn/hint\",\"value\":\"Erste-Hilfe-Team: kontakt@republik.ch.\"},{\"key\":\"signIn/success\",\"value\":\"Erfolgreich als {nameOrEmail} angemeldet.\"},{\"key\":\"signIn/polling/APP/title\",\"value\":\"Zugriff via Republik-App bestätigen\"},{\"key\":\"signIn/polling/APP/text\",\"value\":\"Wir haben Ihnen auf Ihre Republik-App <b>eine Benachrichtigung</b> geschickt. Bitte prüfen Sie Ihr Smartphone oder Tablet. Schliessen Sie diese Seite nicht.\"},{\"key\":\"signIn/polling/EMAIL_TOKEN/title\",\"value\":\"Zugriff via E-Mail bestätigen\"},{\"key\":\"signIn/polling/EMAIL_TOKEN/text\",\"value\":\"Wir haben Ihnen <b>eine E-Mail</b> geschickt, mit der Sie diesen Zugriff freischalten können. Schliessen Sie diese Seite nicht.\"},{\"key\":\"signIn/polling/switch/APP\",\"value\":\"Zugriff via Republik-App bestätigen?\"},{\"key\":\"signIn/polling/switch/EMAIL_TOKEN\",\"value\":\"Zugriff via E-Mail bestätigen?\"},{\"key\":\"signIn/polling/phrase\",\"value\":\"Seltsame Wörter (eine Sicherheitsmassnahme)\"},{\"key\":\"signIn/polling/phrase/EMAIL_TOKEN/hint\",\"value\":\"Wie funktioniert diese Sicherheitsmassnahme? Vergleichen Sie diese Wörter. Stehen sie ebenfalls auf der Bestätigungsseite, können Sie sicher sein, dass Sie dieser Anfrage den Zugriff freischalten.\"},{\"key\":\"signIn/polling/phrase/APP/hint\",\"value\":\"Wie funktioniert diese Sicherheitsmassnahme? Vergleichen Sie diese Wörter. Stehen sie ebenfalls auf der Bestätigungsmaske in der Republik-App, können Sie sicher sein, dass Sie dieser Anfrage den Zugriff freischalten.\"},{\"key\":\"signIn/polling/phrase/hint/show\",\"value\":\"Wie funktioniert diese Sicherheitsmassnahme?\"},{\"key\":\"signIn/polling/email\",\"value\":\"E-Mail-Adresse\"},{\"key\":\"signIn/polling/cancel\",\"value\":\"Vertippt? E-Mail-Adresse erneut eingeben.\"},{\"key\":\"signIn/email/error/empty\",\"value\":\"E-Mail-Adresse fehlt\"},{\"key\":\"signIn/email/error/invalid\",\"value\":\"E-Mail-Adresse ungültig\"},{\"key\":\"cookies/disabled/error\",\"value\":\"Cookies nicht erlaubt\"},{\"key\":\"cookies/disabled/error/explanation\",\"value\":\"Es scheint, als könnten wir Ihnen keinen Keks (Cookie) unterjubeln. Bitte erlauben Sie uns, in Ihrem Browser ein Cookie zu hinterlegen. Nur damit gestatten Sie uns, Sie wiederzuerkennen und entsprechenden Zugriff auf Beiträge und Diskussionen zu ermöglichen.<br />\\n<ul>\\n<li><a href=\\\"https://wiki.selfhtml.org/wiki/Sicherheit/Cookies_erlauben\\\" target=\\\"_blank\\\">Cookies für republik.ch erlauben?</a></li>\\n<li><a href=\\\"/datenschutz\\\" target=\\\"_blank\\\">Mehr über Datenschutz bei der Republik AG erfahren?</a></li>\\n</ul>\\nWir helfen Ihnen per E-Mail unter <a href=\\\"mailto:kontakt@republik.ch\\\">kontakt@republik.ch</a> gerne weiter.\"},{\"key\":\"signOut/label\",\"value\":\"Abmelden\"},{\"key\":\"signOut/error\",\"value\":\"Unbekannter Fehler\"},{\"key\":\"me/signedOut\",\"value\":\"Sie sind nicht angemeldet\"},{\"key\":\"me/signedinAs\",\"value\":\"Sie sind angemeldet als: {nameOrEmail}\"},{\"key\":\"error/404\",\"value\":\"Nicht gefunden\"},{\"key\":\"error/503\",\"value\":\"System nicht verfügbar\"},{\"key\":\"redirection/external/message\",\"value\":\"Sie werden auf {link} weitergeleitet.\"},{\"key\":\"redirection/external/genericLink\",\"value\":\"eine externe Webseite\"},{\"key\":\"marketing/join/button/label\",\"value\":\"Mitglied werden\"},{\"key\":\"marketing/trial/button/label\",\"value\":\"Probe lesen\"},{\"key\":\"marketing/magazine/button/label\",\"value\":\"Zum Magazin\"},{\"key\":\"marketing/signin\",\"value\":\"Sie haben schon einen Zugang? {link}\"},{\"key\":\"marketing/signin/link\",\"value\":\"Jetzt anmelden\"},{\"key\":\"marketing/claim\",\"value\":\"Sie haben einen Gutschein? {claimLink}\"},{\"key\":\"marketing/trynote/cta\",\"value\":\"21 Tage kostenlos und unverbindlich Zugang zu allen Artikeln und Podcasts der Republik.\"},{\"key\":\"marketing/community/title/plain\",\"value\":\"Unsere Verlegerinnen und Verleger\"},{\"key\":\"marketing/community/title\",\"value\":\"{count} Verlegerinnen und Verleger\"},{\"key\":\"marketing/community/defaultCount\",\"value\":\"Über 22’000\"},{\"key\":\"marketing/community/link\",\"value\":\"Zur Community\"},{\"key\":\"marketing/signup/title\",\"value\":\"Danke für Ihre Neugier!\"},{\"key\":\"marketing/signup/lead\",\"value\":\"Bitte tragen Sie unten Ihre E-Mail-Adresse ein. Im Gegenzug laden wir Sie auf einen Streifzug durch die Republik ein. Gerne schicken wir Ihnen zudem einen aktuellen Newsletter, dann sehen Sie einen Tag lang, worüber wir berichten. \"},{\"key\":\"marketing/signup/button/label\",\"value\":\"Anmelden\"},{\"key\":\"cta/button\",\"value\":\"Jetzt abonnieren\"},{\"key\":\"cta/buttonsmall\",\"value\":\"Abo\"},{\"key\":\"marketing/readAloud/title\",\"value\":\"Die Republik zum Hören\"},{\"key\":\"marketing/readAloud/lead1\",\"value\":\"Demnächst werden alle unsere Texte von Sprecherinnen vorgelesen.\"},{\"key\":\"marketing/readAloud/lead2\",\"value\":\"Dürfen wir Sie benachrichtigen, sobald es losgeht?\"},{\"key\":\"marketing/offers/students\",\"value\":\"Ausbildungs-Mitgliedschaft\"},{\"key\":\"marketing/offers/students/reasonTemplate\",\"value\":\"Ausbildung: \"},{\"key\":\"marketing/offers/claim\",\"value\":\"Gutschein einlösen\"},{\"key\":\"marketing/overview/more\",\"value\":\"Chronologie {years}\"},{\"key\":\"marketing/join/ABO/button/label\",\"value\":\"Jahresmitgliedschaft\"},{\"key\":\"marketing/join/MONTHLY_ABO/button/label\",\"value\":\"Monatsabo für 22.–\"},{\"key\":\"marketing/claim/link\",\"value\":\"Jetzt einlösen\"},{\"key\":\"marketing/offers/title\",\"value\":\"Angebote\"},{\"key\":\"marketing/trial/title\",\"value\":\"Probe lesen\"},{\"key\":\"marketing/monthly/button/label\",\"value\":\"Monats-Abo CHF 22\"},{\"key\":\"sections/pageTitle\",\"value\":\"Rubriken – Republik\"},{\"key\":\"sections/title\",\"value\":\"Rubriken\"},{\"key\":\"sections/description\",\"value\":\"Hier finden Sie alles, was regelmässig in der Republik auftaucht: Briefings, Kolumnen, Formate, Audio und Kleinzeug.\"},{\"key\":\"etiquette/pageTitle\",\"value\":\"Etikette – Republik\"},{\"key\":\"etiquette/title\",\"value\":\"Die Etikette\"},{\"key\":\"etiquette/description\",\"value\":\"Wie wir in der Republik debattieren\"},{\"key\":\"markdown/pageTitle\",\"value\":\"Markdown – Republik\"},{\"key\":\"markdown/title\",\"value\":\"Markdown\"},{\"key\":\"markdown/description\",\"value\":\"Wie Sie Ihre Debattenbeiträge mit Markdown formatieren können\"},{\"key\":\"account/signedOut/title\",\"value\":\"Zu Ihrem Konto\"},{\"key\":\"account/signedOut/signIn\",\"value\":\"Bitte anmelden:\"},{\"key\":\"account/ios/box\",\"value\":\"In der App können Sie Ihre Mitgliedschaft nicht verwalten.\"},{\"key\":\"Account/title\",\"value\":\"Willkommen\"},{\"key\":\"Account/title/name\",\"value\":\"Willkommen, {name}\"},{\"key\":\"Account/Update/name/label\",\"value\":\"Name\"},{\"key\":\"Account/Update/address/label\",\"value\":\"Adresse\"},{\"key\":\"Account/Update/title\",\"value\":\"Persönliche Angaben\"},{\"key\":\"Account/Update/birthyear/label\",\"value\":\"Geburtsjahr\"},{\"key\":\"Account/Update/birthyear/label/optional\",\"value\":\"Geburtsjahr (optional)\"},{\"key\":\"Account/Update/gender/label\",\"value\":\"Geschlecht\"},{\"key\":\"Account/Update/gender/label/optional\",\"value\":\"Geschlecht (optional)\"},{\"key\":\"Account/Update/phone/label\",\"value\":\"Telefonnummer\"},{\"key\":\"Account/Update/phone/label/optional\",\"value\":\"Telefonnummer (optional)\"},{\"key\":\"Account/Update/phone/label/alt\",\"value\":\"Telefonnummer\"},{\"key\":\"Account/Update/birthyear/hint/statute\",\"value\":\"JJJJ, notwendig für Ihre Mitgliedschaft bei Project R\"},{\"key\":\"Account/Update/birthyear/hint/plain\",\"value\":\"JJJJ\"},{\"key\":\"Account/Update/birthyear/error/empty\",\"value\":\"Geburtsjahr fehlt\"},{\"key\":\"Account/Update/birthyear/error/invalid\",\"value\":\"Geburtsjahr ungültig\"},{\"key\":\"Account/Update/notEligible\",\"value\":\"Mitgliederbereich. <b>Haben Sie ein Abonnement? <a href='/anmelden'>Anmelden</a></b>\"},{\"key\":\"Account/Update/submit\",\"value\":\"speichern\"},{\"key\":\"Account/Update/updating\",\"value\":\"speichert\"},{\"key\":\"Account/Update/edit\",\"value\":\"ändern\"},{\"key\":\"Account/Update/email/edit\",\"value\":\"E-Mail ändern\"},{\"key\":\"Account/Update/cancel\",\"value\":\"abbrechen\"},{\"key\":\"Account/Update/email/submit\",\"value\":\"speichern\"},{\"key\":\"Account/Update/email/confirm\",\"value\":\"Sind Sie sicher, dass die neue E-Mail-Adresse für Ihr Republik-Konto {email} lauten soll?\"},{\"key\":\"Account/Update/email/hint\",\"value\":\"Achtung: Wenn Sie Ihre E-Mail-Adresse ändern, werden Sie auf allen Geräten abgemeldet und Sie können sich danach ausschliesslich mit der neuen E-Mail-Adresse anmelden!\"},{\"key\":\"Account/Update/email/error/invalid\",\"value\":\"Das ist keine gültige E-Mail-Adresse\"},{\"key\":\"Account/Update/email/empty\",\"value\":\"Geben Sie eine gültige E-Mail-Adresse ein.\"},{\"key\":\"Account/Update/email/form/label\",\"value\":\"Ihre neue E-Mail-Adresse\"},{\"key\":\"Account/Update/email/label\",\"value\":\"E-Mail-Adresse\"},{\"key\":\"Account/Update/email/updating\",\"value\":\"Neue E-Mail-Adresse wird gespeichert\"},{\"key\":\"Account/Update/details/title\",\"value\":\"Bitte überprüfen Sie Ihre Angaben und korrigieren beziehungsweise ergänzen Sie sie.\"},{\"key\":\"Account/Delete/title\",\"value\":\"Konto löschen\"},{\"key\":\"Account/Delete/text\",\"value\":\"Beantragen Sie die Löschung Ihres Kontos und der bei uns gespeicherten personenbezogenen Daten mit einer {link}.\"},{\"key\":\"Account/Delete/link\",\"value\":\"Löschungsanfrage\"},{\"key\":\"UserGuidance/title\",\"value\":\"Kein laufendes Abonnement\"},{\"key\":\"UserGuidance/p1\",\"value\":\"Das Konto mit der E-Mail {email} hat kein gültiges Abonnement.\"},{\"key\":\"UserGuidance/p2\",\"value\":\"Falsches Konto? {signout} oder wenden Sie sich ans {support}.\"},{\"key\":\"UserGuidance/signput\",\"value\":\"Loggen Sie sich aus\"},{\"key\":\"Account/AddressForm/title\",\"value\":\"Ihre Adresse\"},{\"key\":\"Account/AddressForm/organization/label\",\"value\":\"Firma (optional)\"},{\"key\":\"Account/AddressForm/name/label\",\"value\":\"Ihr Name\"},{\"key\":\"Account/AddressForm/name/error/empty\",\"value\":\"Ihr Name fehlt\"},{\"key\":\"Account/AddressForm/name/error/tooLong\",\"value\":\"Ihr Name, maximal {maxLength} Zeichen\"},{\"key\":\"Account/AddressForm/line1/label\",\"value\":\"Strasse und Hausnummer\"},{\"key\":\"Account/AddressForm/line1/error/empty\",\"value\":\"Strasse und Hausnummer fehlen\"},{\"key\":\"Account/AddressForm/line1/error/tooLong\",\"value\":\"Strasse und Hausnummer, maximal {maxLength} Zeichen\"},{\"key\":\"Account/AddressForm/line2/label\",\"value\":\"Zusatz (optional)\"},{\"key\":\"Account/AddressForm/line2/explanation\",\"value\":\"Postfach, Stockwerk, Gebäude etc.\"},{\"key\":\"Account/AddressForm/postalCode/label\",\"value\":\"Postleitzahl\"},{\"key\":\"Account/AddressForm/postalCode/error/empty\",\"value\":\"Postleitzahl fehlt\"},{\"key\":\"Account/AddressForm/city/label\",\"value\":\"Ort\"},{\"key\":\"Account/AddressForm/city/error/empty\",\"value\":\"Ort fehlt\"},{\"key\":\"Account/AddressForm/city/error/tooLong\",\"value\":\"Ort, maximal {maxLength} Zeichen\"},{\"key\":\"Account/AddressForm/country/label\",\"value\":\"Land\"},{\"key\":\"Account/AddressForm/country/error/empty\",\"value\":\"Land fehlt\"},{\"key\":\"Account/AddressForm/edit\",\"value\":\"ändern\"},{\"key\":\"Account/AddressForm/editName\",\"value\":\"bearbeiten\"},{\"key\":\"Account/AddressForm/reset\",\"value\":\"zurücksetzen\"},{\"key\":\"account/paymentSource/saving\",\"value\":\"verifizieren\"},{\"key\":\"account/paymentSource/save\",\"value\":\"speichern\"},{\"key\":\"account/paymentSource/error\",\"value\":\"Fehler\"},{\"key\":\"account/item/label\",\"value\":\"Erstellt am {formattedDate} um {formattedTime}\"},{\"key\":\"pages/account/newsletter/lead\",\"value\":\"Abonnieren Sie unsere Newsletter per E-Mail, um auf dem Laufenden zu bleiben.\"},{\"key\":\"account/newsletterSubscriptions/unauthorized\",\"value\":\"Sie müssen angemeldet sein, um Ihre Newsletter-Einstellungen zu ändern.\"},{\"key\":\"account/newsletterSubscriptions/unsubscribed\",\"value\":\"Sie haben alle Newsletter pausiert. Möchten Sie die Newsletter wieder erhalten?\"},{\"key\":\"account/newsletterSubscriptions/resubscribe\",\"value\":\"Newsletter reaktivieren\"},{\"key\":\"account/newsletterSubscriptions/resendResubscribeEmail\",\"value\":\"E-Mail erneut senden\"},{\"key\":\"account/newsletterSubscriptions/resubscribed\",\"value\":\"Sie haben alle Newsletter pausiert. Wir haben Ihnen eine E-Mail geschickt um die Reaktivierung zu bestätigen. Vielen Dank.\"},{\"key\":\"account/newsletterSubscriptions/resubscribeEmailPending\",\"value\":\"Sie haben alle Newsletter pausiert. Wir haben Ihnen bereits eine E-Mail geschickt um die Newsletter zu reaktivieren.\"},{\"key\":\"account/newsletterSubscriptions/DAILY/label\",\"value\":\"Republik heute\"},{\"key\":\"account/newsletterSubscriptions/DAILY/frequency\",\"value\":\"Von Montag bis Freitag um 5 Uhr\"},{\"key\":\"account/newsletterSubscriptions/DAILY/description\",\"value\":\"Was die Republik aktuell zu bieten hat. Von Montag bis Freitag um 5 Uhr in Ihrem virtuellen Briefkasten.\"},{\"key\":\"account/newsletterSubscriptions/WDWWW/label\",\"value\":\"Was diese Woche wichtig war\"},{\"key\":\"account/newsletterSubscriptions/WDWWW/frequency\",\"value\":\"Jeden Freitag\"},{\"key\":\"account/newsletterSubscriptions/WDWWW/description\",\"value\":\"Wir beobachten für Sie das Weltgeschehen, filtern das Wichtigste heraus, ordnen es ein – und schicken es Ihnen jeden Freitag ansprechend verpackt in Ihre Inbox.\"},{\"key\":\"account/newsletterSubscriptions/SUNDAY/label\",\"value\":\"Republik am Sonntag\"},{\"key\":\"account/newsletterSubscriptions/SUNDAY/frequency\",\"value\":\"Jeden Sonntag um 8 Uhr\"},{\"key\":\"account/newsletterSubscriptions/SUNDAY/description\",\"value\":\"Lesegenuss fernab aktueller News-Hektik. Jeden Sonntag präsentieren wir Ihnen einen Beitrag aus dem Archiv der Republik, der heute genauso lesenswert ist wie damals.\"},{\"key\":\"account/newsletterSubscriptions/BAB/label\",\"value\":\"Briefing aus Bern\"},{\"key\":\"account/newsletterSubscriptions/BAB/frequency\",\"value\":\"Jeden Donnerstag\"},{\"key\":\"account/newsletterSubscriptions/BAB/description\",\"value\":\"Das Wichtigste aus der Schweizer Politik auf einen Blick.\"},{\"key\":\"account/newsletterSubscriptions/TECH/label\",\"value\":\"CTRL\"},{\"key\":\"account/newsletterSubscriptions/TECH/frequency\",\"value\":\"Alle 2 bis 3 Wochen\"},{\"key\":\"account/newsletterSubscriptions/TECH/description\",\"value\":\"Technologie ist politisch. Wir schauen genau hin. Der Digitalpolitik-Newsletter der Republik mit Adrienne Fichter.\"},{\"key\":\"account/newsletterSubscriptions/PROJECTR/label\",\"value\":\"Project-R-Newsletter\"},{\"key\":\"account/newsletterSubscriptions/PROJECTR/description\",\"value\":\"Alles über unsere Unternehmung – von geplanten Veränderungen über anstehende Urabstimmungen bis hin zu wichtigen Entwicklungen in der Medienlandschaft. Kostenlos für alle Interessierten verfügbar.\"},{\"key\":\"account/newsletterSubscriptions/PROJECTR/frequency\",\"value\":\"8 bis 12 Mal pro Jahr\\n\"},{\"key\":\"account/newsletterSubscriptions/ACCOMPLICE/label\",\"value\":\"Komplizen-Newsletter\"},{\"key\":\"account/newsletterSubscriptions/ACCOMPLICE/description\",\"value\":\"Wir informieren Sie über Möglichkeiten, wie Sie die Zukunft der Republik mitgestalten und sich für Medienvielfalt engagieren können. Und Sie erhalten Einladungen zu Veranstaltungen und Neuigkeiten aus der Republik-Crew.\"},{\"key\":\"account/newsletterSubscriptions/ACCOMPLICE/frequency\",\"value\":\"4 bis 6 Mal pro Jahr\"},{\"key\":\"account/newsletterSubscriptions/CLIMATE/label\",\"value\":\"Challenge Accepted\"},{\"key\":\"account/newsletterSubscriptions/CLIMATE/frequency\",\"value\":\"Alle 2 bis 3 Wochen\"},{\"key\":\"account/newsletterSubscriptions/CLIMATE/description\",\"value\":\"Der Newsletter für alle, die sich der Klimakrise stellen. Und gemeinsam Wege aus der Krise finden wollen. Neugierig, kritisch, konstruktiv.\"},{\"key\":\"account/newsletterSubscriptions/onlyName/subscribe\",\"value\":\"abonnieren\"},{\"key\":\"account/newsletterSubscriptions/onlyName/subscribed\",\"value\":\"abonniert\"},{\"key\":\"account/newsletterSubscriptions/button/subscribe\",\"value\":\"Abonnieren\"},{\"key\":\"account/authSettings/title\",\"value\":\"Anmeldung\"},{\"key\":\"account/authSettings/firstfactor/label\",\"value\":\"Am liebsten melde ich mich an per:\"},{\"key\":\"account/authSettings/firstfactor/EMAIL_TOKEN/label\",\"value\":\"E-Mail\"},{\"key\":\"account/authSettings/firstfactor/APP/label\",\"value\":\"App\"},{\"key\":\"account/authSettings/firstfactor/APP/disabled\",\"value\":\"Sie müssen sich zuerst in der App anmelden um neue Anmeldungen in der App bestätigen zu können.\"},{\"key\":\"account/notificationOptions/dialog\",\"value\":\"Ihre Standardeinstellung für den Dialog:\"},{\"key\":\"account/notificationChannels/EMAIL/label\",\"value\":\"E-Mail\"},{\"key\":\"account/notificationChannels/APP/label\",\"value\":\"App\"},{\"key\":\"account/defaultDiscussionNotificationOption/label\",\"value\":\"Standardeinstellung für Dialog-Benachrichtigungen\"},{\"key\":\"account/progress/title\",\"value\":\"Lese- und Hörposition\"},{\"key\":\"account/progress/consent/label\",\"value\":\"Leseposition nutzen\"},{\"key\":\"account/progress/consent/confirmRevoke\",\"value\":\"Ihre Einwilligung wirklich rückgängig machen? Sobald Sie das tun, werden auch alle gespeicherten Positionen gelöscht.\"},{\"key\":\"account/progress/consent/noMembership\",\"value\":\"Die Funktion ist nur für Mitglieder und Abonnentinnen die Republik zugänglich.\"},{\"key\":\"account/prolitteris/title\",\"value\":\"Zugriffszählung\"},{\"key\":\"account/prolitteris/consent/label\",\"value\":\"Zählung erlauben\"},{\"key\":\"account/prolitteris/description\",\"value\":\"Um die Kopiervergütung durch die Verwertungsgesellschaft Pro Litteris zu ermöglichen, senden wir beim Besuch eines Beitrages die Uhrzeit und das Datum des Zugriffs sowie eine anonymisierte Version der IP-Adressen der Leser an Pro Litteris. Falls Sie trotz Anonymisierung die Zählung unterbinden wollen, können Sie dies hier tun.\"},{\"key\":\"account/prolitteris/consent/noMembership\",\"value\":\"Die Funktion ist nur für Mitglieder und Abonnentinnen die Republik zugänglich.\"},{\"key\":\"account/pledges/free-delivery\",\"value\":\"Kostenlose Lieferung\"},{\"key\":\"account/pledges/title\",\"value\":\"Einkäufe\"},{\"key\":\"account/pledges/payment/methods/loading\",\"value\":\"Zahlungsmittel werden geladen\"},{\"key\":\"account/pledges/payment/methods/wallet/loading\",\"value\":\"{wallet} lädt noch.\"},{\"key\":\"account/pledges/payment/methods/wallet/unavailable\",\"value\":\"{wallet} ist nicht verfügbar. Bitte überprüfen Sie Ihre Einstellungen, geben Sie Ihre Kreditkarte von Hand ein oder wählen Sie eine andere Zahlungsart.\"},{\"key\":\"account/pledges/payment/methods/wallet/exception\",\"value\":\"{wallet} konnte nicht geladen werden. Mögliche Ursachen: eine wackelige Internetverbindung, ein temporärer Ausfall, ein VPN oder Ihre Browsererweiterungen. Wählen Sie bitte eine andere Zahlungsart oder versuchen Sie es in einigen Sekunden erneut.\"},{\"key\":\"account/pledges/payment/canceled\",\"value\":\"Die Zahlung wurde abgebrochen.\"},{\"key\":\"account/pledges/payment/method/STRIPE\",\"value\":\"Kreditkarte\"},{\"key\":\"account/pledges/payment/method/STRIPE-WALLET-APPLE-PAY\",\"value\":\"Apple Pay\"},{\"key\":\"account/pledges/payment/method/STRIPE-WALLET-GOOGLE-PAY\",\"value\":\"Google Pay\"},{\"key\":\"account/pledges/payment/method/POSTFINANCECARD\",\"value\":\"Postcard\"},{\"key\":\"account/pledges/payment/method/PAYPAL\",\"value\":\"PayPal\"},{\"key\":\"account/pledges/payment/method/PAYMENTSLIP\",\"value\":\"Rechnung\"},{\"key\":\"account/pledges/payment/your-payment-data\",\"value\":\"Ihre Kreditkartendaten\"},{\"key\":\"account/pledges/payment/status/generic/WAITING\",\"value\":\"{formattedTotal} ausstehend\"},{\"key\":\"account/pledges/payment/status/generic/PAID\",\"value\":\"{formattedTotal} bezahlt mit {method}{dateSuffix}\"},{\"key\":\"account/pledges/payment/status/generic/PAID/dateSuffix\",\"value\":\" am {createdAt}\"},{\"key\":\"account/pledges/payment/status/generic/WAITING_FOR_REFUND\",\"value\":\"{formattedTotal} wird zurückerstattet\"},{\"key\":\"account/pledges/payment/status/generic/REFUNDED\",\"value\":\"{formattedTotal} zurückerstattet\"},{\"key\":\"account/pledges/payment/status/generic/CANCELLED\",\"value\":\"{formattedTotal} storniert\"},{\"key\":\"account/pledges/payment/paymentslipLink\",\"value\":\"QR-Rechnung anzeigen\"},{\"key\":\"account/pledges/payment/paymentslipHint\",\"value\":\"Die QR-Rechnung ersetzt den Einzahlungsschein. Sie können damit die Zahlung via Mobile Banking, E-Banking oder am Schalter bei Bank und Post auslösen.\"},{\"key\":\"account/pledges/payment/status/PAYMENTSLIP/WAITING\",\"value\":\"Bitte überweisen Sie {formattedTotal} mit der Mitteilung «{hrid}» im Betreff-Feld an:<br /><br />\\nPC 61-11760-6<br />\\nIBAN: CH50 0900 0000 6101 1760 6<br />\\nlautend auf:<br />\\nProject R Genossenschaft<br />\\nSihlhallenstrasse 1<br />\\n8004 Zürich\\n\"},{\"key\":\"account/pledges/payment/status/PAYMENTSLIP/REPUBLIK/WAITING\",\"value\":\"Bitte überweisen Sie {formattedTotal} mit der Mitteilung «{hrid}» im Betreff-Feld an:<br /><br />\\nPC 61-229215-3<br />\\nIBAN: CH23 0900 0000 6122 9215 3<br />\\nBIC: POFICHBEXXX<br /><br />\\nlautend auf:<br />\\nRepublik AG<br />\\nSihlhallenstrasse 1<br />\\n8004 Zürich\\n\"},{\"key\":\"account/pledges/payment/status/PAYMENTSLIP/PROJECT_R/WAITING\",\"value\":\"Bitte überweisen Sie {formattedTotal} mit der Mitteilung «{hrid}» im Betreff-Feld an:<br /><br />\\nPC 61-11760-6<br />\\nIBAN: CH50 0900 0000 6101 1760 6<br />\\nBIC: POFICHBEXXX<br /><br />\\nlautend auf:<br />\\nProject R Genossenschaft<br />\\nSihlhallenstrasse 1<br />\\n8004 Zürich\\n\"},{\"key\":\"account/pledges/payment/status/PAYMENTSLIP/PAID\",\"value\":\"{formattedTotal} bezahlt\"},{\"key\":\"account/pledges/payment/PAYMENTSLIP/paperInvoice/1\",\"value\":\"Sie erhalten eine Rechnung per Post. Sollte der Brief verloren gehen, hier noch einmal alle Zahlungsinformationen auf einen Blick:\"},{\"key\":\"account/pledges/payment/PAYMENTSLIP/paperInvoice/0\",\"value\":\"Sie haben die Zahlungsanweisungen per E-Mail erhalten. Und hier schon ein Überblick:\"},{\"key\":\"Account/Access/Grants/explanation\",\"value\":\"Sie können die Republik lesen, weil Verlegerinnen Ihnen den Zugriff ermöglichen:\"},{\"key\":\"Account/Access/Grants/grant\",\"value\":\"... durch {granter} bis zum {endAt}\"},{\"key\":\"Account/Access/Grants/link/pledges\",\"value\":\"Ein eigenes Abonnement kaufen\"},{\"key\":\"Account/Access/Grants/REDUCED/message/claimed\",\"value\":\"Dankeschön fürs Mitmachen im «{campaignTitle}».\"},{\"key\":\"Account/Access/Campaigns/title\",\"value\":\"Republik teilen\"},{\"key\":\"Account/Access/Campaigns/Form/title/0\",\"value\":\"Gäste einladen\"},{\"key\":\"Account/Access/Campaigns/Form/title/other\",\"value\":\"Einen weiteren Zugriff teilen\"},{\"key\":\"Account/Access/Campaigns/Form/explanation\",\"value\":\"Ihre Gäste erhalten eine Einladungs-E-Mail mit Ihrem Namen und Ihrer E-Mail-Adresse sowie einen Link, über den sie ihren Probezugriff einlösen können.\"},{\"key\":\"Account/Access/Campaigns/login/title\",\"value\":\"Anmelden und Republik verschenken\"},{\"key\":\"Account/Access/Campaigns/becomeMember/title\",\"value\":\"Mitglied werden und Republik verschenken\"},{\"key\":\"Account/Access/Campaigns/Form/explanation/linkClaim\",\"value\":\"republik.ch/abholen\"},{\"key\":\"Account/Access/Campaigns/Form/reset\",\"value\":\"weiteren Zugriff teilen\"},{\"key\":\"Account/Access/Campaigns/Form/freeSlots/0\",\"value\":\"Alle verfügbaren Plätze vergeben.\"},{\"key\":\"Account/Access/Campaigns/Form/freeSlots/1\",\"value\":\"noch einen Platz übrig\"},{\"key\":\"Account/Access/Campaigns/Form/freeSlots/other\",\"value\":\"noch {count} Plätze übrig\"},{\"key\":\"Account/Access/Campaigns/Form/button/submit\",\"value\":\"Jetzt einladen\"},{\"key\":\"Account/Access/Campaigns/Form/input/email/label\",\"value\":\"E-Mail-Adresse\"},{\"key\":\"Account/Access/Campaigns/Form/input/email/missing\",\"value\":\"E-Mail-Adresse fehlt\"},{\"key\":\"Account/Access/Campaigns/Form/input/email/invalid\",\"value\":\"E-Mail-Adresse unvollständig\"},{\"key\":\"Account/Access/Campaigns/Form/input/message/label\",\"value\":\"Persönliche Nachricht (optional)\"},{\"key\":\"Account/Access/Campaigns/Form/input/message/tooLong\",\"value\":\"Persönliche Nachricht, höchstens {maxLength} Zeichen\"},{\"key\":\"Account/Access/Campaigns/Form/mutationError/hint\",\"value\":\"Falls das Problem weiterhin besteht, schreiben Sie uns: kontakt@republik.ch\"},{\"key\":\"Account/Access/Campaigns/Revoke/link/revoke\",\"value\":\"Zugriff entfernen\"},{\"key\":\"Account/Access/Campaigns/Revoke/mutationError\",\"value\":\"Fehler: Zugriff kann im Moment nicht gelöscht werden\"},{\"key\":\"Account/Access/Campaigns/Grants/title/1\",\"value\":\"Geteilter Zugriff\"},{\"key\":\"Account/Access/Campaigns/Grants/title/other\",\"value\":\"Geteilte Zugriffe\"},{\"key\":\"Account/Access/Campaigns/Grants/recipient\",\"value\":\"an {recipient}\"},{\"key\":\"Account/Access/Campaigns/Grants/unclaimed\",\"value\":\"noch nicht eingelöst, Gutscheincode: {voucherCode}\"},{\"key\":\"Account/Access/Campaigns/Grants/beginAt\",\"value\":\"eingelöst am {beginAt}\"},{\"key\":\"Account/Access/Campaigns/Grants/endAt\",\"value\":\"gültig bis zum {endAt}\"},{\"key\":\"Account/Access/Campaigns/Grants/beginBefore\",\"value\":\"einlösbar bis zum {beginBefore}\"},{\"key\":\"Account/Onboarding/link\",\"value\":\"Einrichtungsassistent\"},{\"key\":\"account/tabs/OVERVIEW\",\"value\":\"Übersicht\"},{\"key\":\"account/tabs/MEMBERSHIP\",\"value\":\"Abo\"},{\"key\":\"account/tabs/TRANSACTIONS\",\"value\":\"Einkäufe\"},{\"key\":\"account/tabs/SETTINGS\",\"value\":\"Einstellungen\"},{\"key\":\"account/tabs/NOTIFICATIONS\",\"value\":\"Benachrichtigungen\"},{\"key\":\"account/tabs/NEWSLETTER\",\"value\":\"Newsletter\"},{\"key\":\"pages/account/newsletter/title\",\"value\":\"Newsletter – Konto\"},{\"key\":\"pages/account/notifications/title\",\"value\":\"Benachrichtigungen – Konto\"},{\"key\":\"pages/account/settings/title\",\"value\":\"Einstellungen – Konto\"},{\"key\":\"pages/account/transactions/title\",\"value\":\"Einkäufe – Konto\"},{\"key\":\"profile/documents/title/other\",\"value\":\"{count} Beiträge\"},{\"key\":\"profile/documents/title/1\",\"value\":\"Ein Beitrag\"},{\"key\":\"profile/comments/title/other\",\"value\":\"{count} Debattenbeiträge\"},{\"key\":\"profile/comments/title/1\",\"value\":\"Ein Debattenbeitrag\"},{\"key\":\"profile/edit/start\",\"value\":\"Profil bearbeiten\"},{\"key\":\"profile/edit/cancel\",\"value\":\"abbrechen\"},{\"key\":\"profile/edit/return\",\"value\":\"Zurück zum Profil\"},{\"key\":\"profile/edit/save\",\"value\":\"speichern\"},{\"key\":\"profile/edit/errors\",\"value\":\"Fehler:\"},{\"key\":\"profile/credentials/label\",\"value\":\"Rolle\"},{\"key\":\"profile/credentials/title\",\"value\":\"Rollen\"},{\"key\":\"profile/credentials/description\",\"value\":\"Geben Sie mit der «Rolle» Auskunft darüber, aus welcher Position Sie sich beteiligen. Das kann ein Beruf, eine Interessenbindung, Verbandsmitgliedschaft oder sonstige Angaben zu Ihrer Lebenssituation sein.\"},{\"key\":\"profile/credentials/errors/tooLong\",\"value\":\"Rolle, maximal 40 Zeichen\"},{\"key\":\"profile/credentials/private\",\"value\":\"Rollen aus den Diskussionen:\"},{\"key\":\"profile/contact/facebook/label\",\"value\":\"Facebook\"},{\"key\":\"profile/contact/prolitterisId/label\",\"value\":\"Prolitteris ID\"},{\"key\":\"profile/contact/prolitterisId/error\",\"value\":\"Eine Prolitteris ID ist eine sechsstellige Zahl.\"},{\"key\":\"profile/contact/twitter/label\",\"value\":\"Twitter\"},{\"key\":\"profile/url/error\",\"value\":\"Die eingegebene URL ist ungültig. Webseiten müssen mit https:// beginnen.\"},{\"key\":\"Account/ProfileForm/isEmailPublic/label\",\"value\":\"E-Mail im Profil anzeigen\"},{\"key\":\"profile/contact/access/ADMIN\",\"value\":\"Nur Administration\"},{\"key\":\"profile/contact/access/EDITOR\",\"value\":\"Redaktion\"},{\"key\":\"profile/contact/access/MEMBER\",\"value\":\"Mitglieder\"},{\"key\":\"profile/contact/access/PUBLIC\",\"value\":\"Öffentlichkeit\"},{\"key\":\"profile/contact/email/label\",\"value\":\"E-Mail\"},{\"key\":\"profile/contact/email/access/label\",\"value\":\"E-Mail sichtbar für\"},{\"key\":\"profile/contact/pgpPublicKey/label\",\"value\":\"PGP-Public-Key\"},{\"key\":\"profile/contact/pgpPublicKey/error/private\",\"value\":\"Dies ist ein privater PGP-Key, diesen sollten Sie nie auf eine Webseite hochladen. Bitte geben Sie Ihren Public-Key an.\"},{\"key\":\"profile/contact/pgpPublicKey/error/noKey\",\"value\":\"Dies ist kein gültiger PGP-Key.\"},{\"key\":\"profile/settings/isListed/label\",\"value\":\"Auf Community-Seite anzeigen\"},{\"key\":\"profile/settings/isListed/note\",\"value\":\"Ihr Name, Ihr Profilbild und Ihr Statement erscheinen auf {communityLink}.\"},{\"key\":\"climate/profile/settings/isListed/true/note\",\"value\":\"Ihr Name, Ihr Profilbild und Ihr Statement erscheinen auf {communityLink}. Sie zeigen damit nach innen und nach aussen, dass Sie die Republik unterstützen.\"},{\"key\":\"profile/settings/isAdminUnlisted/note\",\"value\":\"Leider können wir Sie auf der Community-Seite nicht anzeigen. Schreiben Sie an kontakt@republik.ch für weitere Informationen.\"},{\"key\":\"profile/settings/hasPublicProfile/true/label\",\"value\":\"Öffentliches Profil\"},{\"key\":\"profile/settings/hasPublicProfile/false/label\",\"value\":\"Privates Profil\"},{\"key\":\"profile/settings/hasPublicProfile/true/note\",\"value\":\"Alle (auch Suchmaschinen) können Ihr Profil sehen. Die Dialogbeiträge auf Ihrer Profilseite sind jedoch nur für Verlegerinnen sichtbar. Im Dialog erscheinen Ihre Beiträge unter Ihrem vollen Namen. Ausser Sie wählen die Option, einen Beitrag anonym zu veröffentlichen.\"},{\"key\":\"profile/settings/hasPublicProfile/false/note\",\"value\":\"Ihre Profilseite ist nicht öffentlich und über die Republik-Suchfunktion nicht auffindbar. Im Dialog ist Ihr voller Name nur für andere Verlegerinnen und angemeldete Gäste sichtbar. Alle anderen sehen über Ihren Dialog-Beiträgen bloss Ihre Initialen. Ausser Sie wählen die Option, einen Dialog-Beitrag anonym zu veröffentlichen.\"},{\"key\":\"profile/settings/isEligibleForProfile/notEligible\",\"value\":\"Sie benötigen ein laufendes Abonnement um Ihr Profil öffentlich zu machen oder auf der Community-Seite anzeigen zu lassen.\"},{\"key\":\"profile/settings/privacy/communityLink\",\"value\":\"der Community-Seite\"},{\"key\":\"profile/section/bio/title\",\"value\":\"Steckbrief und Statement\"},{\"key\":\"profile/section/bio/description\",\"value\":\"Erfassen Sie eine kurze Biografie von sich oder erzählen Sie, was Ihnen wichtig ist. Im Steckbrief haben Sie Platz dafür. Das Statement ist kürzer (höchstens 140 Zeichen). Als Leitsatz erscheint es über Ihrem Profil.\"},{\"key\":\"profile/section/profileLinks/title\",\"value\":\"Ihre Links\"},{\"key\":\"profile/section/profileLinks/description\",\"value\":\"Verweisen Sie in Ihrem Profil auf bis zu drei Webseiten, die etwas über Sie aussagen (Social-Media-Konten, Blogs, Vereinshomepage etc.).\"},{\"key\":\"profile/section/privacy/title\",\"value\":\"Privatsphäre\"},{\"key\":\"profile/section/privacy/description\",\"value\":\"Mit den folgenden Einstellungen steuern Sie, wer Ihr Profil aufrufen kann.\"},{\"key\":\"profile/section/other/title\",\"value\":\"Weiteres\"},{\"key\":\"profile/biography/label\",\"value\":\"Steckbrief\"},{\"key\":\"profile/biography/label/tooLong\",\"value\":\"Steckbrief, maximal 1500 Zeichen\"},{\"key\":\"profile/disclosures/label\",\"value\":\"Interessenbindungen\"},{\"key\":\"profile/disclosures/tooLong\",\"value\":\"Interessenbindungen, maximal 140 Zeichen\"},{\"key\":\"profile/disclosures/explanation\",\"value\":\"Keine Interessenbindungen? Lassen Sie das Feld leer.\"},{\"key\":\"profile/statement/label\",\"value\":\"Statement\"},{\"key\":\"profile/statement/error\",\"value\":\"Statement fehlt\"},{\"key\":\"profile/statement/tooLong\",\"value\":\"Statement, maximal 140 Zeichen\"},{\"key\":\"profile/private\",\"value\":\"Privates Profil: Nur für Sie und andere Mitglieder und Abonnentinnen sichtbar.\"},{\"key\":\"profile/username/label\",\"value\":\"Profil-URL\"},{\"key\":\"profile/username/note\",\"value\":\"Erlaubte Zeichen: Kleinbuchstaben (a-z), Zahlen (0-9) und Punkt (.)\"},{\"key\":\"profile/username/title\",\"value\":\"Profil-URL\"},{\"key\":\"profile/username/description\",\"value\":\"Über diesen Link ist Ihr Profil auffindbar, wenn Sie ein öffentliches Profil haben. Entscheiden Sie selbst, wie der Link zu Ihrer Profilseite lauten soll.\"},{\"key\":\"profile/portrait/choose\",\"value\":\"Porträtbild auswählen\"},{\"key\":\"profile/portrait/invalidType\",\"value\":\"Nur Bilder erlaubt (jpg, png, gif)\"},{\"key\":\"profile/portrait/readError\",\"value\":\"Bild konnte nicht geladen werden\"},{\"key\":\"profile/portrait/tooBig\",\"value\":\"Maximal 6 MB\"},{\"key\":\"profile/portrait/update\",\"value\":\"Porträtbild ändern\"},{\"key\":\"profile/portrait/empty\",\"value\":\"Sie müssen ein Porträtbild hochladen\"},{\"key\":\"profile/report/label\",\"value\":\"Benutzer melden\"},{\"key\":\"profile/report/confirm\",\"value\":\"Sind Sie sicher, dass dieser Benutzer gegen die Etikette verstossen hat und Sie die Moderation herbeirufen möchten? Nennen Sie bitte den Grund für diese Meldung.\"},{\"key\":\"profile/report/provideReason\",\"value\":\"Bitte geben Sie einen Grund an, warum Sie diesen Benutzer melden möchten.\"},{\"key\":\"profile/report/success\",\"value\":\"Wir haben Ihre Meldung erhalten.\"},{\"key\":\"profile/report/error\",\"value\":\"Beim Senden der Meldung ist ein Fehler aufgetreten.\"},{\"key\":\"profile/report/tooLong\",\"value\":\"Sie können maximal {max} Zeichen eingeben.{br}Ihre Eingabe: {input}\"},{\"key\":\"profile/gender\",\"value\":\"Geschlecht (optional)\"},{\"key\":\"profile/gender/empty\",\"value\":\"Geschlecht fehlt\"},{\"key\":\"profile/gender/custom\",\"value\":\"Ihre Bezeichnung\"},{\"key\":\"testimonial/meta/pageTitle\",\"value\":\"Community – Republik\"},{\"key\":\"testimonial/meta/title\",\"value\":\"Die ganze Community auf einen Blick\"},{\"key\":\"testimonial/meta/description\",\"value\":\"Jetzt Mitglied werden.\"},{\"key\":\"testimonial/meta/single/title\",\"value\":\"{name} unterstützt Republik\"},{\"key\":\"testimonial/meta/single/pageTitle\",\"value\":\"{name} – Community – Republik\"},{\"key\":\"testimonial/meta/single/description\",\"value\":\"Jetzt Mitglied werden.\"},{\"key\":\"testimonial/search/label\",\"value\":\"Suchen\"},{\"key\":\"testimonial/search/videosOnly\",\"value\":\"Nur Videos\"},{\"key\":\"testimonial/search/seed\",\"value\":\"Neu Mischen\"},{\"key\":\"testimonial/infinite/end\",\"value\":\"Sie haben gerade {count} Statements angeschaut.\"},{\"key\":\"testimonial/infinite/endless\",\"value\":\"Das waren {count} Verleger und Verlegerinnen. Weitere {remaining} anschauen?\"},{\"key\":\"header/title\",\"value\":\"Republik\"},{\"key\":\"header/signin\",\"value\":\"Anmelden\"},{\"key\":\"header/nav/open/aria\",\"value\":\"Navigation öffnen\"},{\"key\":\"header/nav/close/aria\",\"value\":\"Navigation schliessen\"},{\"key\":\"header/nav/user/open/aria\",\"value\":\"Meine Republik öffnen\"},{\"key\":\"header/nav/user/close/aria\",\"value\":\"Meine Republik schliessen\"},{\"key\":\"header/nav/search/aria\",\"value\":\"Suche\"},{\"key\":\"header/nav/notifications/aria\",\"value\":\"Benachrichtigungen\\n\"},{\"key\":\"header/back\",\"value\":\"zurück\"},{\"key\":\"header/logo/feed/aria\",\"value\":\"Republik – Feed\"},{\"key\":\"header/logo/magazine/aria\",\"value\":\"Republik – Magazin\"},{\"key\":\"footer/contact/title\",\"value\":\"Kontakt\"},{\"key\":\"footer/contact/name\",\"value\":\"Republik AG\"},{\"key\":\"footer/contact/address\",\"value\":\"Sihlhallenstrasse 1 \\n8004 Zürich \\nSchweiz\"},{\"key\":\"footer/contact/mail\",\"value\":\"kontakt@republik.ch\"},{\"key\":\"footer/about/title\",\"value\":\"Über uns\"},{\"key\":\"footer/crew\",\"value\":\"Crew\"},{\"key\":\"footer/about\",\"value\":\"Das sind wir\"},{\"key\":\"footer/events\",\"value\":\"Veranstaltungen\"},{\"key\":\"footer/about/projecR\",\"value\":\"Project R\"},{\"key\":\"footer/about/manifest\",\"value\":\"Manifest\"},{\"key\":\"footer/about/en\",\"value\":\"English Manifesto\"},{\"key\":\"footer/legal/title\",\"value\":\"Rechtliches\"},{\"key\":\"footer/legal/tos\",\"value\":\"AGB\"},{\"key\":\"footer/legal/privacy\",\"value\":\"Datenschutz\"},{\"key\":\"footer/legal/statute\",\"value\":\"Project R Statuten\"},{\"key\":\"footer/shareholder\",\"value\":\"Aktionariat\"},{\"key\":\"footer/legal/imprint\",\"value\":\"Impressum\"},{\"key\":\"footer/media\",\"value\":\"Medieninformationen\"},{\"key\":\"footer/me/title\",\"value\":\"Meine Republik\"},{\"key\":\"footer/me/signIn\",\"value\":\"Bereits an Bord?\"},{\"key\":\"footer/me/signedIn\",\"value\":\"Konto\"},{\"key\":\"footer/me/profile\",\"value\":\"Profil\"},{\"key\":\"footer/offers\",\"value\":\"Angebote\"},{\"key\":\"footer/me/give\",\"value\":\"Verschenken\"},{\"key\":\"footer/me/donate\",\"value\":\"Freiwilliger Beitrag\"},{\"key\":\"footer/me/signOut\",\"value\":\"Abmelden\"},{\"key\":\"footer/me/claim\",\"value\":\"Gutschein einlösen\"},{\"key\":\"footer/me/share\",\"value\":\"Republik teilen\"},{\"key\":\"footer/me/faq\",\"value\":\"FAQ\"},{\"key\":\"footer/since\",\"value\":\"seit 2018\"},{\"key\":\"footer/me/etiquette\",\"value\":\"Etikette für Debatten\"},{\"key\":\"footer/jobs\",\"value\":\"Jobs\"},{\"key\":\"footer/researchBudget\",\"value\":\"Rechercheetat\"},{\"key\":\"footer/whistleblower\",\"value\":\"Whistleblower\"},{\"key\":\"footer/opensource\",\"value\":\"Der Republik Code ist Open Source\"},{\"key\":\"footer/becomemember\",\"value\":\"Mitglied werden\"},{\"key\":\"footer/signIn/alt\",\"value\":\"Anmelden\"},{\"key\":\"footer/icon/instagram\",\"value\":\"Instagram\"},{\"key\":\"footer/icon/facebook\",\"value\":\"Facebook\"},{\"key\":\"footer/icon/twitter\",\"value\":\"Twitter\"},{\"key\":\"footer/icon/github\",\"value\":\"Github\"},{\"key\":\"components/Discussion/OrderBy/selected\",\"value\":\"(aktive Sortierung)\"},{\"key\":\"components/Discussion/OrderBy/DATE\",\"value\":\"Neueste\"},{\"key\":\"components/Discussion/OrderBy/VOTES\",\"value\":\"Beliebteste\"},{\"key\":\"components/Discussion/OrderBy/HOT\",\"value\":\"Hottest\"},{\"key\":\"components/Discussion/OrderBy/REPLIES\",\"value\":\"Meiste Antworten\"},{\"key\":\"components/Discussion/TagFilter/selected\",\"value\":\"(aktiver Filter)\"},{\"key\":\"components/Discussion/reload\",\"value\":\"neu laden\"},{\"key\":\"components/Discussion/Notification/MY_CHILDREN/label\",\"value\":\"Antworten auf meine Beiträge\"},{\"key\":\"components/Discussion/Notification/ALL/label\",\"value\":\"Alle neuen Beiträge\"},{\"key\":\"components/Discussion/Notification/NONE/label\",\"value\":\"Keine Benachrichtigungen\"},{\"key\":\"components/Discussion/Notification/settings\",\"value\":\"Allgemeine Einstellungen\"},{\"key\":\"components/Discussion/Statement/Placeholder\",\"value\":\"Plädoyer verfassen…\"},{\"key\":\"components/Discussion/etiquette\",\"value\":\"Etikette\"},{\"key\":\"components/Discussion/markdown/title\",\"value\":\"Sie können Ihren Beitrag mit Markdown formatieren\"},{\"key\":\"components/Discussion/empty\",\"value\":\"Noch keine Beiträge.\"},{\"key\":\"discussion/meta/title\",\"value\":\"Dialog {quotedDiscussionTitle}\"},{\"key\":\"discussion/meta/focus/title\",\"value\":\"{authorName} in {quotedDiscussionTitle}\"},{\"key\":\"discussion/missing\",\"value\":\"Diese Diskussion fehlt in unserer Datenbank.\"},{\"key\":\"discussion/focus/loadError\",\"value\":\"Dieser spezifische Beitrag konnte nicht geladen werden.\"},{\"key\":\"discussion/focus/notFound\",\"value\":\"Dieser spezifische Beitrag wurde nicht gefunden.\"},{\"key\":\"discussion/focus/missing\",\"value\":\"Dieser spezifische Beitrag ging verloren. Versuchen Sie die Seite neu zu laden.\"},{\"key\":\"discussion/share/title\",\"value\":\"Beitrag teilen\"},{\"key\":\"discussion/share/emailSubject\",\"value\":\"Republik: {title}\"},{\"key\":\"discussion/closed\",\"value\":\"Diese Diskussion ist geschlossen.\"},{\"key\":\"styleguide/AudioPlayer/aria\",\"value\":\"Audio-Player\"},{\"key\":\"styleguide/AudioPlayer/play\",\"value\":\"Anhören\"},{\"key\":\"styleguide/AudioPlayer/pause\",\"value\":\"Anhalten\"},{\"key\":\"styleguide/AudioPlayer/download\",\"value\":\"Herunterladen\"},{\"key\":\"styleguide/AudioPlayer/partialrewind\",\"value\":\"10 Sekunden zurück\"},{\"key\":\"styleguide/AudioPlayer/expand\",\"value\":\"Audioplayer vergrössern\"},{\"key\":\"styleguide/AudioPlayer/shrink\",\"value\":\"Audioplayer minimieren\"},{\"key\":\"styleguide/AudioPlayer/close\",\"value\":\"Audioplayer schliessen\"},{\"key\":\"styleguide/AudioPlayer/partialfastforward\",\"value\":\"30 Sekunden vorwärts\"},{\"key\":\"styleguide/AudioPlayer/loading\",\"value\":\"Wird geladen …\"},{\"key\":\"styleguide/AudioPlayer/sourceError\",\"value\":\"Audio konnte nicht geladen werden.\"},{\"key\":\"styleguide/AudioPlayer/sourceErrorTryAgain\",\"value\":\"Nochmal versuchen\"},{\"key\":\"styleguide/AudioPlayer/autoplayOn\",\"value\":\"Autoplay an\"},{\"key\":\"styleguide/AudioPlayer/autoplayOff\",\"value\":\"Autoplay aus\"},{\"key\":\"styleguide/CommentComposer/placeholder\",\"value\":\"Einen Beitrag verfassen…\"},{\"key\":\"styleguide/CommentComposer/wait\",\"value\":\"Sie können {time} wieder einen Beitrag schreiben.\"},{\"key\":\"styleguide/CommentComposer/answer\",\"value\":\"antworten\"},{\"key\":\"styleguide/CommentComposer/cancel\",\"value\":\"abbrechen\"},{\"key\":\"styleguide/CommentComposer/preview\",\"value\":\"Vorschau\"},{\"key\":\"styleguide/CommentComposer/exitPreview\",\"value\":\"bearbeiten\"},{\"key\":\"styleguide/CommentComposer/formatting/asterisk\",\"value\":\"Damit das Gendersternchen im Kommentar als solches dargestellt wird, muss ein Backslash vorangestellt werden: Leser\\\\*in\"},{\"key\":\"styleguide/CommentActions/answer\",\"value\":\"Antworten\"},{\"key\":\"styleguide/CommentActions/unpublish\",\"value\":\"zurückziehen\"},{\"key\":\"styleguide/CommentActions/unpublish/confirm\",\"value\":\"Wollen Sie Ihren Beitrag zurückziehen? Mit einer Notiz wird vermerkt bleiben, dass hier ein Beitrag war.\"},{\"key\":\"styleguide/CommentActions/unpublish/confirm/admin\",\"value\":\"Wollen Sie den Beitrag von {name} zurückziehen? Mit einer Notiz wird vermerkt bleiben, dass hier ein Beitrag war.\"},{\"key\":\"styleguide/CommentActions/edit\",\"value\":\"bearbeiten\"},{\"key\":\"styleguide/CommentActions/upvote\",\"value\":\"+1\"},{\"key\":\"styleguide/CommentActions/report\",\"value\":\"Moderation herbeirufen\"},{\"key\":\"styleguide/CommentActions/reportWithAmount\",\"value\":\"Moderation herbeigerufen ({amount})\"},{\"key\":\"styleguide/CommentActions/reported\",\"value\":\"Moderation herbeigerufen\"},{\"key\":\"styleguide/CommentActions/reportMessage\",\"value\":\"Sind Sie sicher, dass dieser Beitrag gegen die Etikette verstösst und Sie die Moderation herbeirufen möchten?\"},{\"key\":\"styleguide/CommentActions/upvote/count/0\",\"value\":\"Keine Stimmen dafür\"},{\"key\":\"styleguide/CommentActions/upvote/count/1\",\"value\":\"Eine Stimme dafür\"},{\"key\":\"styleguide/CommentActions/upvote/count/other\",\"value\":\"{count} Stimmen dafür\"},{\"key\":\"styleguide/CommentActions/downvote\",\"value\":\"-1\"},{\"key\":\"styleguide/CommentActions/downvote/count/0\",\"value\":\"Keine Gegenstimmen\"},{\"key\":\"styleguide/CommentActions/downvote/count/1\",\"value\":\"Eine Gegenstimme\"},{\"key\":\"styleguide/CommentActions/downvote/count/other\",\"value\":\"{count} Gegenstimmen\"},{\"key\":\"styleguide/CommentActions/expand\",\"value\":\"Kommentare anschauen\"},{\"key\":\"styleguide/CommentActions/feature\",\"value\":\"hervorheben\"},{\"key\":\"styleguide/CommentActions/featured\",\"value\":\"Hervorgehoben am {date} um {time} Uhr.\"},{\"key\":\"styleguide/Collapsable/expand\",\"value\":\"Mehr lesen\"},{\"key\":\"styleguide/Collapsable/collapse\",\"value\":\"Weniger lesen\"},{\"key\":\"styleguide/Collapsable/table/expand\",\"value\":\"Alles anzeigen\"},{\"key\":\"styleguide/Collapsable/table/collapse\",\"value\":\"Weniger\"},{\"key\":\"styleguide/CommentActions/share\",\"value\":\"Beitrag teilen\"},{\"key\":\"styleguide/CommentActions/share/short\",\"value\":\"Teilen\"},{\"key\":\"styleguide/CommentTeaser/comment/link\",\"value\":\"Beitrag in {link}\"},{\"key\":\"styleguide/CommentTeaser/commentWithCount/link\",\"value\":\"{count} weitere Beiträge zu {link}\"},{\"key\":\"styleguide/CommentTeaser/reply/link\",\"value\":\"Antwort in {link}\"},{\"key\":\"styleguide/CommentTreeLoadMore/label\",\"value\":\"Weitere Beiträge anzeigen\"},{\"key\":\"styleguide/CommentTreeCollapse/label\",\"value\":\"einklappen\"},{\"key\":\"styleguide/comment/header/expandCount/1\",\"value\":\"1 Beitrag\"},{\"key\":\"styleguide/comment/header/expandCount/other\",\"value\":\"{count} Beiträge\"},{\"key\":\"styleguide/comment/header/credentialMissing\",\"value\":\"Rolle definieren\"},{\"key\":\"styleguide/comment/header/updated\",\"value\":\"editiert\"},{\"key\":\"styleguide/comment/header/verifiedCredential\",\"value\":\"Verifizierte Rolle\"},{\"key\":\"styleguide/comment/header/unpublishedByUser\",\"value\":\"(durch User zurückgezogen)\"},{\"key\":\"styleguide/comment/header/unpublishedByAdmin\",\"value\":\"(von der Moderation verborgen)\"},{\"key\":\"styleguide/comment/header/unavailable\",\"value\":\"(Autorenschaft nicht verfügbar)\"},{\"key\":\"styleguide/comment/header/loading\",\"value\":\"Lädt…\"},{\"key\":\"styleguide/comment/edit/submit\",\"value\":\"speichern\"},{\"key\":\"styleguide/comment/unpublished\",\"value\":\"(unsichtbar)\"},{\"key\":\"styleguide/comment/unpublished/userCanEdit\",\"value\":\"Bearbeiten Sie den Beitrag, um ihn erneut zu publizieren.\"},{\"key\":\"styleguide/comment/adminUnpublished\",\"value\":\"Leider mussten wir Ihren Beitrag verbergen. Bei Fragen wenden Sie sich an kontakt@republik.ch.\"},{\"key\":\"styleguide/SeriesNav/seriesoverview/link\",\"value\":\" {link}.\"},{\"key\":\"styleguide/SeriesNav/seriesoverview\",\"value\":\"Zur Übersicht\"},{\"key\":\"styleguide/SeriesNav/current\",\"value\":\"Sie lesen:\"},{\"key\":\"styleguide/Tag/count\",\"value\":\"Beiträge\"},{\"key\":\"timeago/justNow/other\",\"value\":\"gerade eben\"},{\"key\":\"timeago/seconds/1\",\"value\":\"vor einer Sekunde\"},{\"key\":\"timeago/seconds/other\",\"value\":\"vor {count} Sekunden\"},{\"key\":\"timeago/minutes/1\",\"value\":\"vor einer Minute\"},{\"key\":\"timeago/minutes/other\",\"value\":\"vor {count} Minuten\"},{\"key\":\"timeago/hours/1\",\"value\":\"vor einer Stunde\"},{\"key\":\"timeago/hours/other\",\"value\":\"vor {count} Stunden\"},{\"key\":\"timeago/days/1\",\"value\":\"vor einem Tag\"},{\"key\":\"timeago/days/other\",\"value\":\"vor {count} Tagen\"},{\"key\":\"timeago/weeks/1\",\"value\":\"vor einer Woche\"},{\"key\":\"timeago/weeks/other\",\"value\":\"vor {count} Wochen\"},{\"key\":\"timeago/months/1\",\"value\":\"vor einem Monat\"},{\"key\":\"timeago/months/other\",\"value\":\"vor {count} Monaten\"},{\"key\":\"timeago/years/1\",\"value\":\"vor einem Jahr\"},{\"key\":\"timeago/years/other\",\"value\":\"vor {count} Jahren\"},{\"key\":\"timeAhead/justNow/other\",\"value\":\"in weniger als einer Minute\"},{\"key\":\"timeAhead/minutes/1\",\"value\":\"in einer Minute\"},{\"key\":\"timeAhead/minutes/other\",\"value\":\"in {count} Minuten\"},{\"key\":\"timeAhead/hours/1\",\"value\":\"in einer Stunde\"},{\"key\":\"timeAhead/hours/other\",\"value\":\"in {count} Stunden\"},{\"key\":\"timeAhead/days/1\",\"value\":\"erst in einem Tag\"},{\"key\":\"timeAhead/days/other\",\"value\":\"in {count} Tagen\"},{\"key\":\"timeAhead/weeks/1\",\"value\":\"erst in einer Woche\"},{\"key\":\"timeAhead/weeks/other\",\"value\":\"in {count} Wochen\"},{\"key\":\"timeAhead/months/1\",\"value\":\"in einem Monat\"},{\"key\":\"timeAhead/months/other\",\"value\":\"in {count} Monaten\"},{\"key\":\"timeAhead/years/1\",\"value\":\"in einem Jahr\"},{\"key\":\"timeAhead/years/other\",\"value\":\"in {count} Jahren\"},{\"key\":\"timeduration/seconds\",\"value\":\"vor {count} s\"},{\"key\":\"timeduration/minutes\",\"value\":\"vor {count} m\"},{\"key\":\"timeduration/hours\",\"value\":\"vor {count} h\"},{\"key\":\"timeduration/days\",\"value\":\"vor {count} d\"},{\"key\":\"timeduration/weeks\",\"value\":\"vor {count} w\"},{\"key\":\"timeduration/years\",\"value\":\"vor {count} y\"},{\"key\":\"components/DiscussionPreferences/modalTitle\",\"value\":\"Diskussionsteilnahme anpassen\"},{\"key\":\"components/DiscussionPreferences/profilePreview\",\"value\":\"So erscheint Ihr Profil\"},{\"key\":\"components/DiscussionPreferences/save\",\"value\":\"Speichern\"},{\"key\":\"components/DiscussionPreferences/commentAnonymously\",\"value\":\"Anonym teilnehmen\"},{\"key\":\"components/DiscussionPreferences/commentAnonymouslyLabel\",\"value\":\"Aktivieren\"},{\"key\":\"components/DiscussionPreferences/commentAnonymously/description\",\"value\":\"Sie können auch anonym teilnehmen. Die Anonymität gilt für alle in dieser Diskussion veröffentlichten Beiträge. Ihre Identität bleibt für administrative Zwecke nachvollziehbar.\"},{\"key\":\"components/DiscussionPreferences/credentialHeading\",\"value\":\"Rolle festlegen\"},{\"key\":\"components/DiscussionPreferences/credentialLabel\",\"value\":\"Aktive Rolle\"},{\"key\":\"components/DiscussionPreferences/credentialLabel/tooLong\",\"value\":\"Aktive Rolle, maximal 40 Zeichen\"},{\"key\":\"components/DiscussionPreferences/credential/description\",\"value\":\"Bitte geben Sie an, aus welcher Perspektive Sie schreiben (z. B. in Ihrer Rolle als Grossvater, als Lehrperson, als Rechtsexpertin)\"},{\"key\":\"components/DiscussionPreferences/existingCredentialLabel\",\"value\":\"Ihre bisherigen Rollen:\"},{\"key\":\"components/DiscussionPreferences/showAllCredentials\",\"value\":\"Alle anzeigen\"},{\"key\":\"components/DiscussionPreferences/loading\",\"value\":\"Loading…\"},{\"key\":\"components/DiscussionPreferences/explain\",\"value\":\"Sie können hier einstellen, wie Sie an dieser Debatte teilnehmen wollen. Die Einstellungen gelten für alle Ihre Beiträge in dieser Debatte.\"},{\"key\":\"components/DiscussionPreferences/credentialAnonymityWarning\",\"value\":\"Achtung: Die Rolle ist öffentlich einsehbar und könnte Rückschlüsse auf Ihre Identität zulassen.\"},{\"key\":\"discussion/displayUser/anonymous\",\"value\":\"Anonym\"},{\"key\":\"submitComment/notEligible\",\"value\":\"Ihr Interesse an dieser Republik-Debatte freut uns sehr. Wollen Sie daran teilnehmen? Werden Sie jetzt {pledgeLink}.\"},{\"key\":\"submitComment/notEligible/pledgeText\",\"value\":\"Verleger und Abonnentin\"},{\"key\":\"submitComment/rootSubmitLabel\",\"value\":\"publizieren\"},{\"key\":\"submitComment/noDisplayAuthor\",\"value\":\"Noch nicht bereit, versuchen sie es erneut in einigen Sekunden.\"},{\"key\":\"package/customize/price/label\",\"value\":\"Betrag in CHF\"},{\"key\":\"package/customize/price/error\",\"value\":\"Betrag, mindestens {formattedCHF}\"},{\"key\":\"package/customize/option/error/max\",\"value\":\"{label}, höchstens {maxAmount}\"},{\"key\":\"package/customize/option/error/min\",\"value\":\"{label}, mindestens {minAmount}\"},{\"key\":\"package/customize/option/error/step\",\"value\":\"{label}, nicht zugelassen, vielleicht {suggestedValue}?\"},{\"key\":\"package/customize/userPrice/reason/label\",\"value\":\"Begründung\"},{\"key\":\"package/customize/userPrice/reason/error\",\"value\":\"Bitte begründen\"},{\"key\":\"package/customize/userPrice/YEARLY_ABO/beforeReason\",\"value\":\"Eine grosse und vielfältige Community ist für ein leserinnenfinanziertes Magazin unbezahlbar. Deshalb geben wir Ihnen zum 5-Jahres-Jubiläum der Republik die Möglichkeit, den Preis für Ihr Abo selber zu wählen. \"},{\"key\":\"package/customize/userPrice/beforeReason\",\"value\":\"Journalismus kostet. Aber wir wollen niemanden ausschliessen. Falls Sie sich die 240 Franken nicht leisten können, bitten wir Sie um eine knappe Begründung und einen Preis, der Ihnen gerecht scheint. \"},{\"key\":\"package/price\",\"value\":\"{formattedCHF}\"},{\"key\":\"package/price/free\",\"value\":\"kostenlos\"},{\"key\":\"package/DONATE/title\",\"value\":\"Spenden\"},{\"key\":\"package/DONATE/description\",\"value\":\"Sie wollen hervorragenden Journalismus unterstützen. Denn Sie wissen: Guter Journalismus kostet.\"},{\"key\":\"package/students/price\",\"value\":\"{formattedCHF} pro Jahr\"},{\"key\":\"package/ABO/price\",\"value\":\"{formattedCHF} pro Jahr\"},{\"key\":\"package/ABO/userPrice/teaser\",\"value\":\"Sie können sich den Betrag nicht leisten?\"},{\"key\":\"package/ABO/title\",\"value\":\"Jahresmitgliedschaft\"},{\"key\":\"package/ABO_GIVE_MONTHS/price\",\"value\":\"{formattedCHF} pro Monat\"},{\"key\":\"package/ABO_GIVE_MONTHS/title\",\"value\":\"3-Monats-Abo als Geschenk\"},{\"key\":\"package/ABO_GIVE_MONTHS/description\",\"value\":\"Das Geschenk-Abo können Sie in Form eines digitalen oder physischen Gutscheins der beschenkten Person überreichen. Den Gutscheincode schicken wir Ihnen direkt per E-Mail zu.\"},{\"key\":\"package/YEARLY_ABO/price\",\"value\":\"{formattedCHF} für ein Jahr\"},{\"key\":\"package/YEARLY_ABO/title\",\"value\":\"Republik-Abonnement\"},{\"key\":\"package/YEARLY_ABO/description\",\"value\":\"Es freut uns, dass Sie dabei sind! Sie bekommen Zugriff auf unser Magazin, zum Lesen und zum Hören, können Briefings und Newsletter abonnieren und sich mit Autorinnen und anderen Abonnentinnen in unserem Dialog-Bereich austauschen.\"},{\"key\":\"package/BENEFACTOR/title\",\"value\":\"Gönner-Mitgliedschaft\"},{\"key\":\"package/BENEFACTOR/price\",\"value\":\"{formattedCHF} pro Jahr\"},{\"key\":\"package/MONTHLY_ABO/title\",\"value\":\"Monats-Abo\"},{\"key\":\"package/MONTHLY_ABO/einstiegsmonat/title\",\"value\":\"Monats-Abo zum Einstiegspreis\"},{\"key\":\"package/MONTHLY_ABO/price\",\"value\":\"{formattedCHF}\"},{\"key\":\"package/MONTHLY_ABO/description\",\"value\":\"Schön, dass Sie dabei sind. Sie erhalten ab sofort unser Magazin. Und sind während der Zeit Ihres Abonnements Verlegerin oder Verleger der Republik. Das Monatsabonnement wird jeweils automatisch verlängert. Sie können es aber jederzeit in Ihrem Konto kündigen.\"},{\"key\":\"package/MONTHLY_ABO/einstiegsmonat/description\",\"value\":\"Das Abo erneuert sich nach 30 Tagen automatisch zum regulären Preis von CHF 22. Es ist jederzeit kündbar.\"},{\"key\":\"package/LESHA/title\",\"value\":\"Buch «We Stay»\"},{\"key\":\"package/LESHA/price\",\"value\":\"{formattedCHF}\"},{\"key\":\"package/LESHA/description\",\"value\":\"Als er am Morgen des 24. Februar 2022 aufwacht, ist Lesha Berezovskiys Leben mit einem Schlag anders. Bomben­alarm in Kiew, Russland hat die ukrainische Hauptstadt angegriffen.\\nIn seiner Kolumne «Leben in Trümmern» lässt er uns seither an seinem Alltag teilhaben.\\nDaraus ist nun ein Buch entstanden: Ein Zeitdokument, das das Leben in einem Land unter Beschuss aus einer persönlichen Perspektive auch uns hier näher­bringt, die vom Krieg nicht unmittelbar betroffen sind.\\n\\n<strong>Auf Anfrage: Limitierte Sonderedition mit Print (300 CHF)</strong>\\n\\nLesha Berezovskiys Bildkolumne «Leben in Trümmern» als Buch – in einer limitierten und nummerierten Sonderedition (25 Exemplare). Enthält einen hochwertigen, von Lesha signierten Print: «Red Stone, 2022» im Format 20 x 25 cm. Anfragen an: <a href=\\\"mailto:annette.keller@republik.ch\\\">annette.keller@republik.ch</a>\"},{\"key\":\"package/group/ME\",\"value\":\"Für mich\"},{\"key\":\"package/group/GIVE\",\"value\":\"Geschenke\"},{\"key\":\"package/group/HIDDEN\",\"value\":\"Angebote\"},{\"key\":\"option/ABO/label/other\",\"value\":\"Mitgliedschaften\"},{\"key\":\"option/ABO/label/1\",\"value\":\"Mitgliedschaft\"},{\"key\":\"option/NOTEBOOK/label/other\",\"value\":\"Notizbücher\"},{\"key\":\"option/NOTEBOOK/label/1\",\"value\":\"Notizbuch\"},{\"key\":\"option/NOTEBOOK/label/0\",\"value\":\"Notizbuch\"},{\"key\":\"option/TOTEBAG/label/other\",\"value\":\"Taschen\"},{\"key\":\"option/TOTEBAG/label/1\",\"value\":\"Tasche\"},{\"key\":\"option/TOTEBAG/label/0\",\"value\":\"Tasche\"},{\"key\":\"option/ABO_GIVE_MONTHS/label\",\"value\":\"Anzahl Abos\"},{\"key\":\"option/ABO_GIVE_MONTHS/interval/month/label/1\",\"value\":\"Monat pro Abo\"},{\"key\":\"option/ABO_GIVE_MONTHS/interval/month/label/other\",\"value\":\"Monate pro Abo\"},{\"key\":\"option/YEARLY_ABO/label/other\",\"value\":\"Mitstreiter-Abos\"},{\"key\":\"option/YEARLY_ABO/label/1\",\"value\":\"Mitstreiter-Abo\"},{\"key\":\"package/customize/ABO_GIVE_MONTHS/years/1\",\"value\":\"Verschenken Sie eine Jahresmitgliedschaft statt Monate\"},{\"key\":\"package/customize/ABO_GIVE_MONTHS/years/other\",\"value\":\"Verschenken Sie Jahresmitgliedschaften statt Monate\"},{\"key\":\"option/ABO_GIVE_MONTHS/periods/notice/reachedMax\",\"value\":\"Ab zehn Monaten lohnt sich eine Jahresmitgliedschaft: {link}\"},{\"key\":\"payment/title\",\"value\":\"Zahlungsart auswählen\"},{\"key\":\"payment/title/single\",\"value\":\"Bezahlung\"},{\"key\":\"payment/title/single/DEFAULT_SOURCE\",\"value\":\"Ihre Kreditkarte\"},{\"key\":\"payment/secure\",\"value\":\"Sichere Verbindung\"},{\"key\":\"payment/insecure\",\"value\":\"Unsichere Verbindung\"},{\"key\":\"payment/method/STRIPE\",\"value\":\"Visa/Mastercard/Amex\"},{\"key\":\"payment/method/PAYMENTSLIP\",\"value\":\"Rechnung\"},{\"key\":\"payment/method/POSTFINANCECARD\",\"value\":\"PostFinance Card\"},{\"key\":\"payment/method/PAYPAL\",\"value\":\"PayPal\"},{\"key\":\"payment/method/choose\",\"value\":\"Wählen Sie eine Zahlungsart\"},{\"key\":\"payment/method/existing\",\"value\":\"Gespeicherte Kreditkarte\"},{\"key\":\"payment/method/new\",\"value\":\"Neue Kreditkarte oder Zahlungsart\"},{\"key\":\"payment/method/new/stripe\",\"value\":\"Neue Kreditkarte erfassen\"},{\"key\":\"payment/stripe/prefered\",\"value\":\"Falls es für Sie keinen Unterschied macht: Die Kreditkarte (Visa, Mastercard, Amex) ist für uns das bevorzugte Zahlungsmittel.\"},{\"key\":\"payment/stripe/only/MONTHLY_ABO\",\"value\":\"Das Monatsabo ist nur mit Kreditkarte (Visa, Mastercard, Amex) verfügbar.\"},{\"key\":\"payment/method/selected\",\"value\":\"(ausgewählte Zahlungsart)\"},{\"key\":\"payment/stripe/js/failed\",\"value\":\"Kreditkartenzahlungen sind zurzeit nicht möglich. Die Verbindung zu stripe.com, unserem Dienstleister für Kreditkartenzahlungen, ist fehlgeschlagen. Mögliche Ursachen: eine wackelige Internetverbindung, ein temporärer Ausfall oder Ihre Browsererweiterungen. Wählen Sie bitte eine andere Zahlungsart oder versuchen Sie es in einigen Sekunden erneut.\"},{\"key\":\"payment/stripe/cardNumber/label\",\"value\":\"Kreditkartennummer\"},{\"key\":\"payment/stripe/cardNumber/error/empty\",\"value\":\"Kreditkartennummer fehlt\"},{\"key\":\"payment/stripe/cardNumber/error/incomplete_number\",\"value\":\"Kreditkartennummer unvollständig\"},{\"key\":\"payment/stripe/cardNumber/error/generic\",\"value\":\"Kreditkartennummer ungültig\"},{\"key\":\"payment/stripe/expiry/label\",\"value\":\"Ablaufdatum Ihrer Karte\"},{\"key\":\"payment/stripe/expiry/error/empty\",\"value\":\"Ablaufdatum Ihrer Karte fehlt\"},{\"key\":\"payment/stripe/expiry/error/incomplete_expiry\",\"value\":\"Ablaufdatum Ihrer Karte unvollständig\"},{\"key\":\"payment/stripe/expiry/error/generic\",\"value\":\"Ablaufdatum Ihrer Karte ungültig\"},{\"key\":\"payment/stripe/cvc/label\",\"value\":\"Prüfziffer (CVC)\"},{\"key\":\"payment/stripe/cvc/error/empty\",\"value\":\"Prüfziffer (CVC) fehlt\"},{\"key\":\"payment/stripe/cvc/error/incomplete_cvc\",\"value\":\"Prüfziffer (CVC) unvollständig\"},{\"key\":\"payment/stripe/cvc/error/generic\",\"value\":\"Prüfziffer (CVC) ungültig\"},{\"key\":\"payment/paymentslip/explanation\",\"value\":\"Nach der Bestellung senden wir Ihnen per E-Mail eine QR-Rechnung.\"},{\"key\":\"payment/paymentslip/emailInvoice\",\"value\":\"Zahlungsanweisungen per E-Mail\"},{\"key\":\"payment/paymentslip/paperInvoice\",\"value\":\"Rechnung per Post\"},{\"key\":\"pledge/claim/signIn/before\",\"value\":\"Geben Sie Ihre richtige E-Mail-Adresse ein:\"},{\"key\":\"pledge/claim/signIn/button\",\"value\":\"Ändern\"},{\"key\":\"pledge/claim/loading\",\"value\":\"überprüfen\"},{\"key\":\"pledge/title\",\"value\":\"Willkommen an Bord!\"},{\"key\":\"pledge/contact/preface/ABO_GIVE\",\"value\":\"Eine Mitgliedschaft als Geschenk erhalten Sie in Form eines Gutscheincodes, den Sie direkt der zu beschenkenden Person überreichen können.\"},{\"key\":\"pledge/contact/preface/ABO_GIVE_MONTHS\",\"value\":\"Ein Monats-Abo als Geschenk erhalten Sie in Form eines Gutscheincodes, den Sie direkt der zu beschenkenden Person überreichen können.\"},{\"key\":\"pledge/contact/title\",\"value\":\"Ihre Kontaktinformationen\"},{\"key\":\"pledge/contact/title/ABO_GIVE\",\"value\":\"Kontaktinformationen des Zahlenden\"},{\"key\":\"pledge/contact/pastPledges/1\",\"value\":\"Sie haben bereits einmal mitgemacht.\"},{\"key\":\"pledge/contact/pastPledges/other\",\"value\":\"Sie haben bereits {count} mal mitgemacht.\"},{\"key\":\"pledge/contact/signOut\",\"value\":\"abmelden\"},{\"key\":\"pledge/contact/signIn/show\",\"value\":\"Haben Sie bereits ein Konto? Melden Sie sich an.\\n\"},{\"key\":\"pledge/contact/signIn/customMe\",\"value\":\"anmelden\"},{\"key\":\"pledge/contact/signIn/hide\",\"value\":\"Das erste Mal hier?\"},{\"key\":\"pledge/contact/firstName/label\",\"value\":\"Ihr Vorname\"},{\"key\":\"pledge/contact/firstName/error/empty\",\"value\":\"Vorname fehlt\"},{\"key\":\"pledge/contact/lastName/label\",\"value\":\"Ihr Nachname\"},{\"key\":\"pledge/contact/lastName/error/empty\",\"value\":\"Nachname fehlt\"},{\"key\":\"pledge/contact/email/label\",\"value\":\"Ihre E-Mail-Adresse\"},{\"key\":\"pledge/contact/email/error/empty\",\"value\":\"E-Mail-Adresse fehlt\"},{\"key\":\"pledge/contact/email/error/invalid\",\"value\":\"E-Mail-Adresse ungültig\"},{\"key\":\"pledge/submit/package/error\",\"value\":\"Wählen Sie zuoberst ein Angebot aus\"},{\"key\":\"pledge/submit/payMethod/error\",\"value\":\"Zahlungsart auswählen\"},{\"key\":\"pledge/submit/payMethod/label\",\"value\":\"Wählen Sie eine Zahlungsart:\"},{\"key\":\"noscript\",\"value\":\"JavaScript ist deaktiviert. Formulare – u. a. die Anmeldung – und interaktive Elemente funktionieren nur wenn Sie JavaScript aktivieren. Anleitung um <a href=\\\"https://wiki.selfhtml.org/wiki/JavaScript/Tutorials/JavaScript_aktivieren\\\">JavaScript zu aktivieren auf selfhtml.org lesen</a>.\"},{\"key\":\"pledge/address/shipping/title\",\"value\":\"Lieferadresse\"},{\"key\":\"pledge/address/shipping/updateAccount\",\"value\":\"Ihre Standardadresse aktualisieren\"},{\"key\":\"pledge/address/shipping/setAccount\",\"value\":\"Als Ihre Standardadresse speichern\"},{\"key\":\"pledge/address/payment/title\",\"value\":\"Rechnungsadresse\"},{\"key\":\"pledge/address/payment/likeShipping\",\"value\":\"Gleich wie Lieferadresse\"},{\"key\":\"pledge/address/payment/other\",\"value\":\"Andere Adresse\"},{\"key\":\"pledge/submit/emailVerify/note\",\"value\":\"Diese E-Mail-Adresse wurde schon einmal verwendet. Falls das Ihre E-Mail-Adresse ist, klicken Sie bitte auf «anmelden».\"},{\"key\":\"pledge/submit/emailVerify/done\",\"value\":\"Vielen Dank für das Verifizieren Ihrer E-Mail-Adresse.\"},{\"key\":\"pledge/submit/error/title\",\"value\":\"Fehler\"},{\"key\":\"pledge/submit/button/pay\",\"value\":\"{formattedChf} bezahlen\"},{\"key\":\"pledge/consents/label/PRIVACY_STATUTE_TOS\",\"value\":\"Ich bin mit den <a href=\\\"/agb\\\" target=\\\"_blank\\\">AGB</a>, den <a href=\\\"/datenschutz\\\" target=\\\"_blank\\\">Datenschutz&shy;bestimmungen</a> und den <a href=\\\"/statuten\\\" target=\\\"_blank\\\">Statuten</a> der Project R Genossenschaft einverstanden.\"},{\"key\":\"pledge/consents/label/PRIVACY_TOS\",\"value\":\"Ich bin mit den <a href=\\\"/agb\\\" target=\\\"_blank\\\">AGB</a> und den <a href=\\\"/datenschutz\\\" target=\\\"_blank\\\">Datenschutz&shy;bestimmungen</a> einverstanden.\"},{\"key\":\"pledge/consents/label/PRIVACY\",\"value\":\"Ich bin mit den <a href=\\\"/datenschutz\\\" target=\\\"_blank\\\">Datenschutz&shy;bestimmungen</a> einverstanden.\"},{\"key\":\"pledge/consents/error/PRIVACY_STATUTE_TOS\",\"value\":\"Sie müssen sich mit den AGB, den Datenschutzbestimmungen und den Statuten der Project R Genossenschaft einverstanden erklären.\"},{\"key\":\"pledge/consents/error/PRIVACY_TOS\",\"value\":\"Sie müssen sich mit den AGB und den Datenschutzbestimmungen einverstanden erklären.\"},{\"key\":\"pledge/consents/error/PRIVACY\",\"value\":\"Sie müssen sich mit den Datenschutzbestimmungen einverstanden erklären.\"},{\"key\":\"pledge/submit/loading/submit\",\"value\":\"einreichen\"},{\"key\":\"pledge/submit/loading/stripe\",\"value\":\"bezahlen\"},{\"key\":\"pledge/submit/loading/postfinance\",\"value\":\"weiterleiten\"},{\"key\":\"pledge/submit/loading/paypal\",\"value\":\"weiterleiten\"},{\"key\":\"pledge/submit/loading/pay\",\"value\":\"verarbeiten\"},{\"key\":\"pledge/recievePayment/pf/mailto/subject\",\"value\":\"PostFinance {status}\"},{\"key\":\"pledge/recievePayment/pf/mailto/body\",\"value\":\"Liebe Republik\\n\\nLasst uns über Geld sprechen.\\n\\nBuchungsreferenz:\\n{pledgeId}\\n\\nPostFinance:\\n{payload}\"},{\"key\":\"pledge/recievePayment/pf/92\",\"value\":\"Während des Zahlungsverfahrens ist ein technisches Problem bei PostFinance aufgetreten, das zu einem nicht vorhersehbaren Resultat geführt hat.<br />\\n<br />\\nBitte nehmen Sie Kontakt mit uns auf unter {mailto}. Sie sollten es nicht erneut versuchen da die Buchung möglicherweise bereits akzeptiert wurde.\"},{\"key\":\"pledge/recievePayment/pf/invalid\",\"value\":\"Die Zahlung ist ungültig. Versuchen Sie bitte ein anderes Zahlungsmittel.\"},{\"key\":\"pledge/recievePayment/pf/denied\",\"value\":\"Die Zahlung wurde verweigert. Nutzen Sie eine andere Karte oder wählen Sie ein anderes Zahlungsmittel.\"},{\"key\":\"pledge/recievePayment/pf/canceled\",\"value\":\"Zahlung abgebrochen. Wählen Sie bitte ein anderes Zahlungsmittel, um Ihre Bestellung abzuschliessen.\"},{\"key\":\"pledge/recievePayment/pf/retry\",\"value\":\"Während des Zahlungsverfahrens ist ein technisches Problem bei PostFinance aufgetreten, versuchen Sie es bitte erneut oder wählen Sie ein anderes Zahlungsmittel.\"},{\"key\":\"pledge/recievePayment/error\",\"value\":\"Zahlung fehlgeschlagen.<br />\\n<br />\\nBitte versuchen Sie es erneut oder kontaktieren Sie uns unter {mailto}.\"},{\"key\":\"pledge/recievePayment/noPledge\",\"value\":\"Die Bestellung wurde nicht gefunden. Kontaktieren Sie uns unter kontakt@republik.ch mit folgender Bestellungsreferenz: {pledgeId}.\"},{\"key\":\"pledge/recievePayment/paypal/cancel\",\"value\":\"Zahlung abgebrochen. Wählen Sie bitte ein anderes Zahlungsmittel, um Ihre Bestellung abzuschliessen.\"},{\"key\":\"pledge/recievePayment/paypal/deny\",\"value\":\"Zahlung fehlgeschlagen.<br />\\n<br />\\nWählen Sie bitte ein anderes Zahlungsmittel, um Ihre Bestellung abzuschliessen.\"},{\"key\":\"pledge/recievePayment/paypal/contactUs\",\"value\":\"Während des Zahlungsverfahrens mit PayPal ist ein Problem aufgetreten, das zu einem nicht vorhersehbaren Resultat geführt hat.<br />\\n<br />\\nBitte nehmen Sie Kontakt mit uns auf unter {mailto}. Sie sollten es nicht erneut versuchen da die Buchung möglicherweise bereits akzeptiert wurde.\"},{\"key\":\"pledge/recievePayment/paypal/mailto/subject\",\"value\":\"PayPal {status}\"},{\"key\":\"pledge/recievePayment/paypal/mailto/body\",\"value\":\"Liebe Republik\\n\\nLasst uns über Geld sprechen.\\n\\nBuchungsreferenz:\\n{pledgeId}\\n\\nPayPal:\\n{payload}\"},{\"key\":\"pledge/recievePayment/3dsecure/failed\",\"value\":\"3-D Secure fehlgeschlagen. Versuchen Sie es bitte nochmals oder wählen Sie ein anderes Zahlungsmittel.\"},{\"key\":\"shareholder/pageTitle\",\"value\":\"Aktionariat – Republik\"},{\"key\":\"shareholder/title\",\"value\":\"Aktionariat\"},{\"key\":\"shareholder/description\",\"value\":\"Aufteilung der Stimmen in der Republik AG\"},{\"key\":\"shareholder/table/title\",\"value\":\"Alle Aktionärinnen\"},{\"key\":\"shareholder/contact\",\"value\":\"Für weitere Auskünfte:\"},{\"key\":\"shareholder/contact/email\",\"value\":\"kontakt@republik.ch\"},{\"key\":\"shareholder/contact/phone\",\"value\":\"+41 44 505 67 80\"},{\"key\":\"shareholder/contact/phone/link\",\"value\":\"+41445056780\"},{\"key\":\"front/prepublication/notice\",\"value\":\"Interne Publikation (Editoren-Vorschau)\"},{\"key\":\"front/finite/feed\",\"value\":\"Zum Feed\"},{\"key\":\"front/finite\",\"value\":\"Sie haben die aktuelle Republik gelesen.\"},{\"key\":\"front/chronology\",\"value\":\"Archiv {years}\"},{\"key\":\"front/loadMore\",\"value\":\"Ältere Beiträge laden\\n\"},{\"key\":\"feed/title/1\",\"value\":\"Ein Beitrag\"},{\"key\":\"feed/title/other\",\"value\":\"{count} Beiträge\"},{\"key\":\"feed/loadMore\",\"value\":\"Das waren die neuesten {count} Beiträge. Weitere {remaining} anschauen?\"},{\"key\":\"feed/loadMore/comments\",\"value\":\"Das waren die neuesten {count} Debattenbeiträge. Weitere {remaining} anschauen?\"},{\"key\":\"feed/actionbar/dossier\",\"value\":\"In einem Dossier\"},{\"key\":\"feed/actionbar/gallery\",\"value\":\"Bildstrecke\"},{\"key\":\"feed/actionbar/audio\",\"value\":\"Zum Hören\"},{\"key\":\"feed/actionbar/video\",\"value\":\"Video\"},{\"key\":\"feed/actionbar/chart\",\"value\":\"Chart\"},{\"key\":\"feed/actionbar/readingTime/hours/other\",\"value\":\"{count}h \"},{\"key\":\"feed/actionbar/readingTime/minutes/1\",\"value\":\"1 Minute\"},{\"key\":\"feed/actionbar/readingTime/minutes/other\",\"value\":\"{count} Minuten\"},{\"key\":\"feed/actionbar/readingTime/minutesShort/other\",\"value\":\"{count}'\"},{\"key\":\"feed/actionbar/readingTime/title\",\"value\":\"ungefähr {hours}{minutes}\"},{\"key\":\"feed/actionbar/discussion/long\",\"value\":\"Reden Sie mit: {count} Dialog Beiträge\"},{\"key\":\"feed/actionbar/edit\",\"value\":\"Im Publikator bearbeiten\"},{\"key\":\"format/feed/title/1\",\"value\":\"Ein Beitrag\"},{\"key\":\"format/feed/title/other\",\"value\":\"{count} Beiträge\"},{\"key\":\"format/feed/payNote\",\"value\":\"Sie brauchen eine Mitgliedschaft, um die Beiträge zu lesen.\"},{\"key\":\"section/feed/title/1\",\"value\":\"Ein Beitrag\"},{\"key\":\"section/feed/title/other\",\"value\":\"{count} Beiträge\"},{\"key\":\"article/share/title\",\"value\":\"Beitrag teilen\"},{\"key\":\"article/share/emailSubject\",\"value\":\"Republik: {title}\"},{\"key\":\"article/actionbar/share\",\"value\":\"Teilen\"},{\"key\":\"article/actionbar/facebook/title\",\"value\":\"Auf Facebook teilen\"},{\"key\":\"article/actionbar/facebook/label\",\"value\":\"Facebook\"},{\"key\":\"article/actionbar/twitter/title\",\"value\":\"Auf Twitter teilen\"},{\"key\":\"article/actionbar/twitter/label\",\"value\":\"Twitter\"},{\"key\":\"article/actionbar/whatsapp/title\",\"value\":\"Auf WhatsApp teilen\"},{\"key\":\"article/actionbar/whatsapp/label\",\"value\":\"WhatsApp\"},{\"key\":\"article/actionbar/bluesky/label\",\"value\":\"Bluesky\"},{\"key\":\"article/actionbar/bluesky/title\",\"value\":\"Auf Bluesky teilen\"},{\"key\":\"article/actionbar/threema/title\",\"value\":\"Auf Threema teilen\"},{\"key\":\"article/actionbar/threema/label\",\"value\":\"Threema\"},{\"key\":\"article/actionbar/telegram/title\",\"value\":\"Auf Telegram teilen\"},{\"key\":\"article/actionbar/telegram/label\",\"value\":\"Telegram\"},{\"key\":\"article/actionbar/email/title\",\"value\":\"Per E-Mail verschicken\"},{\"key\":\"article/actionbar/email/label\",\"value\":\"E-Mail\"},{\"key\":\"article/actionbar/pocket/title\",\"value\":\"In Pocket speichern\"},{\"key\":\"article/actionbar/pocket/label\",\"value\":\"Pocket\"},{\"key\":\"article/actionbar/dossier\",\"value\":\"Zum Dossier\"},{\"key\":\"article/actionbar/download\",\"value\":\"Herunterladen\"},{\"key\":\"article/actionbar/download/processing\",\"value\":\"wird heruntergeladen...\"},{\"key\":\"article/actionbar/audio\",\"value\":\"Beitrag anhören\"},{\"key\":\"article/actionbar/pdf/open\",\"value\":\"Als PDF öffnen\"},{\"key\":\"article/actionbar/pdf/options\",\"value\":\"PDF-Optionen\"},{\"key\":\"article/actionbar/link/title\",\"value\":\"Link kopieren\"},{\"key\":\"article/actionbar/link/label\",\"value\":\"Link kopieren\"},{\"key\":\"article/actionbar/link/label/success\",\"value\":\"Link kopiert!\"},{\"key\":\"article/actionbar/link/label/error\",\"value\":\"Kopieren fehlgeschlagen\"},{\"key\":\"article/actionbar/fontSize/title\",\"value\":\"Schriftgrösse anpassen\"},{\"key\":\"article/actionbar/fontSize/increase\",\"value\":\"Schriftgrösse vergrössern\\n\"},{\"key\":\"article/actionbar/fontSize/decrease\",\"value\":\"Schriftgrösse verkleinern\\n\"},{\"key\":\"article/actionbar/fontSize/reset\",\"value\":\"zurücksetzen\\n\"},{\"key\":\"article/actionbar/fontSize/example\",\"value\":\"Beispiel\"},{\"key\":\"article/actionbar/progress/read\",\"value\":\"Gelesen\"},{\"key\":\"article/actionbar/progress/unread\",\"value\":\"Als ungelesen markieren\"},{\"key\":\"article/actionbar/progress/markasread\",\"value\":\"Als gelesen markieren\"},{\"key\":\"article/actionbar/discussion\",\"value\":\"Zum Dialog\"},{\"key\":\"article/actionbar/discussion/label/0\",\"value\":\"0 Beiträge\"},{\"key\":\"article/actionbar/discussion/label/1\",\"value\":\"1 Beitrag\"},{\"key\":\"article/actionbar/discussion/label/other\",\"value\":\"{count} Beiträge\"},{\"key\":\"article/actionbar/discussion/call-to-action/0\",\"value\":\"Reden Sie mit\"},{\"key\":\"article/actionbar/discussion/call-to-action/1\",\"value\":\"Reden Sie mit: 1 Dialog-Beitrag\"},{\"key\":\"article/actionbar/discussion/call-to-action/other\",\"value\":\"Reden Sie mit: {count} Dialog-Beiträge\"},{\"key\":\"article/actionbar/userprogress\",\"value\":\"Leseposition\"},{\"key\":\"article/actionbar/audio/play\",\"value\":\"Hören\"},{\"key\":\"article/actionbar/audio/queue/add\",\"value\":\"Hinzufügen\"},{\"key\":\"article/actionbar/audio/queue/remove\",\"value\":\"Entfernen\"},{\"key\":\"article/actionbar/audio/info/title\",\"value\":\"Vorgelesener Beitrag\"},{\"key\":\"article/actionbar/audio/info/speaker/default\",\"value\":\"unserem Sprecherinnen-Team\"},{\"key\":\"article/actionbar/audio/info/speaker\",\"value\":\"Vorgelesen von\"},{\"key\":\"article/actionbar/audio/info/voices/0\",\"value\":\"Vorgelesen von unserem Sprecherinnen-Team\"},{\"key\":\"article/actionbar/audio/info/voices/other\",\"value\":\"Vorgelesen von {names}\"},{\"key\":\"article/actionbar/audio/info/play-synth\",\"value\":\"Anhören (synthetisch)\"},{\"key\":\"article/actionbar/audio/info/synthetic\",\"value\":\"Diesen Beitrag anhören\"},{\"key\":\"article/actionbar/audio/info/readAloud\",\"value\":\"{subscribe} sobald vorgelesen {synthetic}\"},{\"key\":\"article/actionbar/audio/info/readAloud/subscribe\",\"value\":\"Benachrichtigen, sobald vorgelesen\"},{\"key\":\"article/actionbar/audio/info/readAloud/checkbox\",\"value\":\"Ich möchte benachrichtigt werden.\"},{\"key\":\"article/actionbar/audio/info/readAloud/synthetic\",\"value\":\"oder synthetische Version {action}\"},{\"key\":\"article/actionbar/audio/info/readAloud/synthetic/action\",\"value\":\"anhören\"},{\"key\":\"article/actionbar/audio/info/read-soon\",\"value\":\"Diesen Beitrag lesen wir im Laufe des Tages ein.\"},{\"key\":\"article/actionbar/audio/info/read-aloud-notification\",\"value\":\"Benachrichtigen.\"},{\"key\":\"article/syntheticReadAloud/title\",\"value\":\"Beitrag von synthetischer Stimme vorlesen lassen.\"},{\"key\":\"article/syntheticReadAloud/hint/label\",\"value\":\"Fehler melden\"},{\"key\":\"article/syntheticReadAloud/hint/link\",\"value\":\"/2022/05/04/helfen-sie-uns-die-synthetische-stimme-zu-verbessern/diskussion\"},{\"key\":\"article/readAloud/title\",\"value\":\"Beitrag vorlesen lassen.\"},{\"key\":\"article/readAloud/hint/label\",\"value\":\"Alle vorgelesenen Beiträge\"},{\"key\":\"article/readAloud/hint/link\",\"value\":\"/format/vorgelesen\"},{\"key\":\"article/series/episode\",\"value\":\"Episode {count}\"},{\"key\":\"article/pdf/title\",\"value\":\"PDF\"},{\"key\":\"article/pdf/open\",\"value\":\"PDF öffnen\"},{\"key\":\"article/pdf/download\",\"value\":\"herunterladen\"},{\"key\":\"article/pdf/images\",\"value\":\"mit Bildern\"},{\"key\":\"article/autodiscussionteaser/title\",\"value\":\"Jetzt sind Sie dran!\"},{\"key\":\"article/autodiscussionteaser/text\",\"value\":\"Was gefällt Ihnen an diesem Beitrag? Was gibt es zu ergänzen? Was ist kritikwürdig? Ihre Mitverlegerinnen und die Redaktion freuen sich auf Ihr Wissen und Ihre Perspektive. {link}.\"},{\"key\":\"article/autodiscussionteaser/linktext\",\"value\":\"Reden Sie mit auf unserer Dialogseite\"},{\"key\":\"article/progressprompt/headline\",\"value\":\"Lese- und Hörposition merken?\"},{\"key\":\"article/progressprompt/description/feature\",\"value\":\"Springen Sie an die Stelle zurück, an der Sie einen Text oder ein Hörstück unterbrochen haben. Wenn die Funktion aktiv ist, wird Ihr Leseverhalten bei der Republik aufgezeichnet.\"},{\"key\":\"article/progressprompt/question\",\"value\":\"Möchten Sie diese Funktion nutzen?\"},{\"key\":\"article/progressprompt/button/confirm\",\"value\":\"Aktivieren\"},{\"key\":\"article/progressprompt/button/reject\",\"value\":\"Nicht aktivieren\"},{\"key\":\"article/progressprompt/description/settings\",\"value\":\"Sie können dies natürlich jederzeit in Ihrem {link} ändern.\"},{\"key\":\"article/progressprompt/description/settings/link\",\"value\":\"Konto\"},{\"key\":\"article/gallery/error\",\"value\":\"Das Bild konnte nicht geladen werden.\"},{\"key\":\"article/gallery/close\",\"value\":\"Schliessen (Esc)\"},{\"key\":\"article/gallery/forward\",\"value\":\"Vorwärts\"},{\"key\":\"article/gallery/back\",\"value\":\"Zurück\"},{\"key\":\"article/prepublication/notice\",\"value\":\"Interne Publikation (Editoren-Vorschau)\"},{\"key\":\"progress/restore/time\",\"value\":\"{day} um {time} Uhr\"},{\"key\":\"progress/restore/time/today\",\"value\":\"Von heute\"},{\"key\":\"progress/restore/time/yesterday\",\"value\":\"Von gestern\"},{\"key\":\"progress/restore/time/other\",\"value\":\"Vom {date}\"},{\"key\":\"progress/restore/title\",\"value\":\"Zu Ihrer Leseposition: {percent}\"},{\"key\":\"progress/restore/titleShort\",\"value\":\"Weiterlesen: {percent}\"},{\"key\":\"progress/restore/close\",\"value\":\"Schliessen\"},{\"key\":\"progress/time\",\"value\":\"Ihre Leseposition {day} um {time} Uhr\"},{\"key\":\"progress/time/today\",\"value\":\"heute\"},{\"key\":\"progress/time/yesterday\",\"value\":\"gestern\"},{\"key\":\"progress/time/other\",\"value\":\"am {date}\"},{\"key\":\"merci/postpay/lead\",\"value\":\"Danke, Sie sind mit dem Wichtigsten durch. Jetzt müssen Sie noch Ihre E-Mail-Adresse bestätigen.\"},{\"key\":\"merci/postpay/reclaim\",\"value\":\"Falsche E-Mail-Adresse?\"},{\"key\":\"merci/claim/signIn/before\",\"value\":\"Geben Sie Ihre richtige E-Mail-Adresse ein:\"},{\"key\":\"merci/claim/signIn/button\",\"value\":\"Ändern\"},{\"key\":\"merci/claim/loading\",\"value\":\"überprüfen\"},{\"key\":\"merci/postpay/signInError/title\",\"value\":\"E-Mail-Verifizierung fehlgeschlagen\"},{\"key\":\"merci/postpay/signInError/text\",\"value\":\"Ihre Zahlungsinformationen wurden gespeichert. Leider konnte das System aber Ihre E-Mail-Adresse «{email}» zurzeit nicht verifizieren. Versuchen Sie es in 10 Minuten erneut. Klappt das ein zweites Mal nicht, stehen wir Ihnen gerne mit Rat zur Verfügung. Schreiben Sie uns Ihr Problem an {contactEmailLink}.\"},{\"key\":\"merci/postpay/signInError/email/subject\",\"value\":\"E-Mail-Verifizierung fehlgeschlagen nach dem Bezahlen\"},{\"key\":\"merci/postpay/signInError/email/body\",\"value\":\"E-Mail-Adresse:\\n{email}\\n\\nBuchungsreferenz:\\n{pledgeId}\\n\\nFehler:\\n{error}\"},{\"key\":\"merci/postpay/signInError/retry\",\"value\":\"erneut versuchen\"},{\"key\":\"merci/empty/title\",\"value\":\"Hallo {nameOrEmail}\"},{\"key\":\"merci/empty/text\",\"value\":\"Möchten auch Sie uns unterstützen?\"},{\"key\":\"merci/empty/button\",\"value\":\"Jetzt mitmachen\"},{\"key\":\"merci/title/noName\",\"value\":\"Willkommen an Bord\"},{\"key\":\"merci/title\",\"value\":\"Willkommen an Bord, {name}\"},{\"key\":\"merci/title/package/ABO_GIVE\",\"value\":\"Guten Tag, {name}\"},{\"key\":\"merci/title/package/ABO_GIVE_MONTHS\",\"value\":\"Guten Tag, {name}\"},{\"key\":\"merci/title/package/YEARLY_ABO\"},{\"key\":\"merci/title/package/DONATE\",\"value\":\"Guten Tag, {name}\"},{\"key\":\"merci/title/package/MASK\",\"value\":\"Guten Tag, {name}\"},{\"key\":\"merci/title/package/ABO_GIVE/noName\",\"value\":\"Guten Tag\"},{\"key\":\"merci/title/package/ABO_GIVE_MONTHS/noName\",\"value\":\"Guten Tag\"},{\"key\":\"merci/title/package/DONATE/noName\",\"value\":\"Guten Tag\"},{\"key\":\"merci/title/package/MASK/noName\",\"value\":\"Guten Tag\"},{\"key\":\"merci/title/package/LESHA\",\"value\":\"Vielen Dank für Ihre Bestellung, {name}!\"},{\"key\":\"merci/title/package/LESHA/noName\",\"value\":\"Vielen Dank für Ihre Bestellung!\"},{\"key\":\"merci/lead\",\"value\":\"Vielen Dank für Ihre Unterstützung. Es ist uns eine Ehre, Sie bei uns als Verlegerin respektive Verleger zu begrüssen. Also als Teil unseres Unternehmens.\\n\\nAuf dieser Seite finden Sie alles, was wir von Ihnen wissen: Ihre Einkäufe, Ihre persönlichen Angaben und Ihre Newsletter-Einstellungen.\"},{\"key\":\"merci/lead/package/ABO_GIVE\",\"value\":\"Vielen Dank für Ihre Grosszügigkeit! Sie erhalten ein E-Mail mit den Details zu Ihrer Bestellung.\\n\\nAuf dieser Seite finden Sie alles, was wir von Ihnen wissen: Ihre Einkäufe, Ihre persönlichen Angaben und Ihre Newsletter-Einstellungen.\"},{\"key\":\"merci/lead/package/ABO_GIVE_MONTHS\",\"value\":\"Vielen Dank für Ihre Grosszügigkeit! Sie erhalten ein E-Mail mit den Details zu Ihrer Bestellung.\\n\\nAuf dieser Seite finden Sie alles, was wir von Ihnen wissen: Ihre Einkäufe, Ihre persönlichen Angaben und Ihre Newsletter-Einstellungen.\"},{\"key\":\"merci/lead/package/DONATE\",\"value\":\"Vielen Dank für Ihre Grosszügigkeit!\\n\\nAuf dieser Seite finden Sie alles, was wir von Ihnen wissen: Ihre Einkäufe, Ihre persönlichen Angaben und Ihre Newsletter-Einstellungen.\"},{\"key\":\"merci/lead/package/UNKOWN\",\"value\":\"Vielen Dank für Ihre Unterstützung!\"},{\"key\":\"merci/lead/package/PROLONG\",\"value\":\"Wir freuen uns sehr, Sie weiterhin an Bord zu wissen, denn mutiger Journalismus braucht ein aufmerksames, neugieriges, furchtloses Publikum!\\n\\nGemeinsam schützen wir die Medienvielfalt, die Informationsfreiheit und die Demokratie: Wir hören zu und diskutieren über drängende Fragen der Gegenwart.\"},{\"key\":\"merci/title/package/PROLONG\",\"value\":\"{name}, danke für Ihre Verlängerung, für Ihr Vertrauen und für Ihre Unterstützung.\"},{\"key\":\"merci/title/package/PROLONG/noName\",\"value\":\"Danke für Ihre Verlängerung, für Ihr Vertrauen und für Ihre Unterstützung.\"},{\"key\":\"package/PROLONG/ABO_GIVE_MONTHS/pageTitle\",\"value\":\"Willkommen an Bord!\"},{\"key\":\"merci/title/package/UNKOWN\",\"value\":\"Danke, {name}\"},{\"key\":\"merci/title/package/UNKOWN/noName\",\"value\":\"Danke\"},{\"key\":\"merci/lead/package/LESHA\",\"value\":\"Viel Spass mit «We Stay» von Lesha Berezovskiy. Wir versenden das Buch innerhalb von 7 Werktagen.\"},{\"key\":\"merci/action/read\",\"value\":\"Zum Magazin\"},{\"key\":\"merci/action/dialog\",\"value\":\"Am Dialog teilnehmen\"},{\"key\":\"merci/share/title\",\"value\":\"Ein neues, unabhängiges Magazin\"},{\"key\":\"merci/share/tweetTemplate\",\"value\":\"Journalismus ist mehr als nur ein Geschäft für irgendwelche Konzerne, beteilige dich.\"},{\"key\":\"merci/share/emailSubject\",\"value\":\"Ein neues, unabhängiges Magazin\"},{\"key\":\"merci/share/emailBody\",\"value\":\"Hallo\\n\\nWerde Mitglied und Abonnent der Republik: {url}\\n\\nHerzliche Grüsse, {backerName}\"},{\"key\":\"memberships/title/1\",\"value\":\"Abonnement\"},{\"key\":\"memberships/title/other\",\"value\":\"Abonnements\"},{\"key\":\"memberships/title/payment\",\"value\":\"Zahlungsart\"},{\"key\":\"memberships/giver/giveable/show\",\"value\":\"Mitgliedschaft verschenken?\"},{\"key\":\"memberships/giver/given/notGive\",\"value\":\"Sie haben die Mitgliedschaft verschenkt.\"},{\"key\":\"memberships/giver/given/1\",\"value\":\"Sie haben schon eine Mitgliedschaft verschenkt.\"},{\"key\":\"memberships/giver/given/other\",\"value\":\"Sie haben schon {count} Mitgliedschaften verschenkt.\"},{\"key\":\"memberships/giver/description\",\"value\":\"Empfänger:\"},{\"key\":\"memberships/give/show\",\"value\":\"Verschenken?\"},{\"key\":\"memberships/give/hide\",\"value\":\"behalten\"},{\"key\":\"memberships/give/description/before/notGive\",\"value\":\"Wollen Sie das Abonnement nicht selber nutzen? Und nicht Mitglied von Project R werden? Sie können Ihre Mitgliedschaft mit folgendem Gutscheincode verschenken:\"},{\"key\":\"memberships/give/description/before/1\",\"value\":\"Sie können die Mitgliedschaft mit folgendem Gutscheincode verschenken:\"},{\"key\":\"memberships/give/description/before/other\",\"value\":\"Sie können die Mitgliedschaften mit folgenden Gutscheincodes verschenken:\"},{\"key\":\"memberships/give/ABO_GIVE_MONTHS/description/before/1\",\"value\":\"Sie können das Abo mit folgendem Gutscheincode verschenken:\"},{\"key\":\"memberships/give/ABO_GIVE_MONTHS/description/before/other\",\"value\":\"Sie können die Abos mit folgenden Gutscheincodes verschenken:\"},{\"key\":\"memberships/give/description/after\",\"value\":\"Die Gutscheincodes können dann von der beschenkten Person auf <a href=\\\"/abholen\\\">republik.ch/abholen</a> eingelöst werden.\"},{\"key\":\"memberships/noActive\",\"value\":\"Sie haben keine aktiven Mitgliedschaften oder Abonnements.\"},{\"key\":\"memberships/latestPeriod/renew/true/autoPay/true\",\"value\":\"Automatische Erneuerung am {formattedEndDate}\"},{\"key\":\"memberships/latestPeriod/renew/true/autoPay/false\",\"value\":\"Erneuerung am {formattedEndDate} fällig\"},{\"key\":\"memberships/MONTHLY_ABO/latestPeriod/renew/true/autoPay/false\",\"value\":\"Automatische Erneuerung am {formattedEndDate}\"},{\"key\":\"memberships/latestPeriod/renew/false/autoPay/true\",\"value\":\"Gültig bis am {formattedEndDate}\"},{\"key\":\"memberships/latestPeriod/renew/false/autoPay/false\",\"value\":\"Gültig bis am {formattedEndDate}\"},{\"key\":\"memberships/latestPeriod/overdue\",\"value\":\"Überfällig seit dem {formattedEndDate}\"},{\"key\":\"memberships/latestPeriod/ended\",\"value\":\"Endete am {formattedEndDate}\"},{\"key\":\"memberships/MONTHLY_ABO/manage/prolong/link\",\"value\":\"Abonnement verlängern\"},{\"key\":\"memberships/MONTHLY_ABO/manage/cancel/link\",\"value\":\"Abonnement künden\"},{\"key\":\"memberships/MONTHLY_ABO/manage/upgrade/link\",\"value\":\"Wenn Sie ein {buyLink}, beenden wir automatisch Ihr Monatsabo.\"},{\"key\":\"memberships/MONTHLY_ABO/manage/upgrade/link/buyText\",\"value\":\"Jahresmitgliedschaft lösen\"},{\"key\":\"memberships/MONTHLY_ABO/manage/reactivate\",\"value\":\"Abonnement reaktivieren\"},{\"key\":\"memberships/ABO_GIVE_MONTHS/manage/prolong/link\",\"value\":\"Abonnement verlängern\"},{\"key\":\"memberships/ABO_GIVE_MONTHS/manage/cancel/link\",\"value\":\"Abonnement künden\"},{\"key\":\"memberships/ABO_GIVE_MONTHS/manage/reactivate\",\"value\":\"Abonnement reaktivieren\"},{\"key\":\"memberships/YEARLY_ABO/manage/prolong/link\",\"value\":\"Abonnement verlängern\"},{\"key\":\"memberships/YEARLY_ABO/manage/cancel/link\",\"value\":\"Abonnement kündigen\"},{\"key\":\"memberships/YEARLY_ABO/manage/upgrade/link\",\"value\":\"{buyLink} und behalten Sie Ihren Zugang zur Republik auch nach Ablauf Ihres Mitstreiterinnen-Abos.\"},{\"key\":\"memberships/YEARLY_ABO/manage/upgrade/link/buyText\",\"value\":\"Lösen Sie eine Jahresmitgliedschaft\"},{\"key\":\"memberships/YEARLY_ABO/manage/reactivate\",\"value\":\"Abonnement-Kündigung zurückziehen\"},{\"key\":\"memberships/claim/lead\",\"value\":\"Gutschein einlösen\"},{\"key\":\"memberships/claim/voucherCode/label\",\"value\":\"Gutscheincode\"},{\"key\":\"memberships/claim/voucherCode/label/error/empty\",\"value\":\"Gutscheincode fehlt\"},{\"key\":\"memberships/claim/voucherCode/label/error/unrecognized\",\"value\":\"Gutscheincode nicht erkannt\"},{\"key\":\"memberships/claim/addendum\",\"value\":\"Wir schützen Ihre Privatsphäre. Wenn wir Informationen weitergeben, zeigen wir das an. In diesem Fall: Die Herausgeberin des Gutscheins wird sehen können, dass Sie den Gutschein eingelöst haben.\"},{\"key\":\"memberships/claim/button\",\"value\":\"Einlösen\"},{\"key\":\"memberships/claim/loading\",\"value\":\"überprüfen\"},{\"key\":\"memberships/claim/personal/lead\",\"value\":\"{name} schenkt Ihnen einen Republik-Probezugang\"},{\"key\":\"memberships/claim/access/lead\",\"value\":\"Geteilten Zugriff aktivieren\"},{\"key\":\"memberships/claim/access/body\",\"value\":\"Sie wurden eingeladen, mit der Republik eine Testfahrt zu machen. Füllen Sie das folgende Formular vollständig aus und kommen Sie an Bord.\"},{\"key\":\"memberships/claim/error/title\",\"value\":\"Fehler\"},{\"key\":\"memberships/sequenceNumber/label\",\"value\":\"Abo #{sequenceNumber}\"},{\"key\":\"Share/chart/title\",\"value\":\"Aktuell lesen {currentActiveAccessGrants} Personen die Republik mit einem geteilten Abo\"},{\"key\":\"Share/chart/lead\",\"value\":\"Anzahl geteilter Zugriffe während der letzten {days} Tage\"},{\"key\":\"Share/chart/after\",\"value\":\"Seit dem {startDate} wurden {invites} Personen eingeladen, die Republik kennenzulernen. {claims} haben den Probezugriff eingelöst, und {pledges} durften wir in der Verlagsetage begrüssen – dank Ihrem Engagement.\"},{\"key\":\"Share/chart/legend\",\"value\":\"Es zählen Mitgliedschaften, Abos und Spenden innerhalb von 30 Tagen nach Probezugriff. Datenstand: {formattedDateTime}\"},{\"key\":\"Share/chart/annotation/lastBucket\",\"value\":\"Aktuell\"},{\"key\":\"notifications/pageTitle\",\"value\":\"Mitteilung – Republik\"},{\"key\":\"notifications/email-confirmed/title\",\"value\":\"Zugriff bestätigt\"},{\"key\":\"notifications/email-confirmed/projectr/title\",\"value\":\"E-Mail-Adresse bestätigt\"},{\"key\":\"notifications/email-confirmed/newsletter/title\",\"value\":\"Anmeldung bestätigt\"},{\"key\":\"notifications/email-confirmed/text\",\"value\":\"Vielen Dank.\"},{\"key\":\"notifications/email-confirmed/claim/text\",\"value\":\"Bitte kehren Sie zum vorherigen Fenster zurück, um den Vorgang abzuschliessen. \"},{\"key\":\"notifications/email-confirmed/preview/text\",\"value\":\"Bitte kehren Sie zum vorherigen Fenster zurück, um den Vorgang abzuschliessen. \"},{\"key\":\"notifications/session-denied/title\",\"value\":\"Zugriff abgelehnt\"},{\"key\":\"notifications/session-denied/text\",\"value\":\"Sie haben den Schwarzleser vor einem leeren Bildschirm sitzen lassen.\"},{\"key\":\"notifications/closeNote\",\"value\":\"Sie können dieses Fenster schliessen. \"},{\"key\":\"notifications/invalid-token/title\",\"value\":\"Ungültiger Link\"},{\"key\":\"notifications/invalid-token/text\",\"value\":\"Der von Ihnen aufgerufene Link ist nicht gültig. Links zur Anmeldung sind nur einmal gültig.\"},{\"key\":\"notifications/invalid-email/title\",\"value\":\"Ungültige E-Mail-Adresse\"},{\"key\":\"notifications/invalid-email/text\",\"value\":\"Der von Ihnen aufgerufene Link enthält eine ungültige E-Mail-Adresse: «{email}».<br /><br />Es könnte sein, dass die Zeichenkodierung beim Übertragen korrumpiert wurde. Bitte versuchen Sie es mit einem anderen E-Mail-Programm.<br /><br />Und melden Sie uns, unter welchen Umständen dies passiert ist: <a href=\\\"mailto:kontakt@republik.ch?subject=Korrumpierte%20E-Mail-Adresse\\\">kontakt@republik.ch</a>.\"},{\"key\":\"notifications/unavailable/title\",\"value\":\"System nicht verfügbar\"},{\"key\":\"notifications/unavailable/text\",\"value\":\"Leider kann unser System Ihre Anfrage zurzeit nicht bearbeiten. Versuchen Sie es in 10 Minuten erneut. Klappt es ein zweites Mal nicht, stehen wir Ihnen gerne mit Rat zur Verfügung. Schreiben Sie uns an <a href=\\\"mailto:kontakt@republik.ch?subject=Anmeldung%20nicht%20verf%C3%BCgbar\\\">kontakt@republik.ch</a>.\"},{\"key\":\"notifications/unkown/title\",\"value\":\"Unbekannte Mitteilung\"},{\"key\":\"notifications/unkown/text\",\"value\":\"Das System konnte Ihre Anfrage nicht erkennen. Es könnte sein, dass ein Übertragungsfehler vorliegt: Melden Sie sich bei <a href=\\\"mailto:kontakt@republik.ch?subject=Kaputter%20Link\\\">kontakt@republik.ch</a> mit einem Screenshot.\"},{\"key\":\"notifications/newsletter-subscription/title\",\"value\":\"Newsletter-Anmeldung\"},{\"key\":\"notifications/newsletter-subscript-disabledion/title\",\"value\":\"Newsletter-Anmeldung\"},{\"key\":\"notifications/newsletter/title\",\"value\":\"Newsletter-Anmeldung\"},{\"key\":\"notifications/newsletter/name:READALOUD/title\",\"value\":\"Die Republik zum Hören\"},{\"key\":\"macNewsletterSubscription/name:READALOUD/text\",\"value\":\"Dürfen wir Sie benachrichtigen, sobald alle unsere Texte von Sprecherinnen vorgelesen werden?\"},{\"key\":\"macNewsletterSubscription/button\",\"value\":\"bestätigen\"},{\"key\":\"notifications/closeButton\",\"value\":\"Magazin ansehen\"},{\"key\":\"notifications/closeButton/app\",\"value\":\"OK\"},{\"key\":\"notifications/links/merci\",\"value\":\"Ihre persönliche Übersicht\"},{\"key\":\"notifications/minifeed/nounread\",\"value\":\"Keine ungelesenen Benachrichtigungen. {link}\"},{\"key\":\"notifications/minifeed/nounread/link\",\"value\":\"Alle anzeigen\"},{\"key\":\"events/pageTitle\",\"value\":\"Veranstaltungen – Republik\"},{\"key\":\"events/title\",\"value\":\"Alle Veranstaltungen im Überblick\"},{\"key\":\"events/metaDescription\",\"value\":\"Das digitale Magazin von Project R – jetzt Mitglied werden.\"},{\"key\":\"events/upcoming\",\"value\":\"Kommende Veranstaltungen\"},{\"key\":\"events/past\",\"value\":\"Vergangene Veranstaltungen\"},{\"key\":\"events/share/title\",\"value\":\"Anlass teilen\"},{\"key\":\"events/all\",\"value\":\"Alle Veranstaltungen\"},{\"key\":\"events/labels/description\",\"value\":\"Was\"},{\"key\":\"events/labels/date\",\"value\":\"Wann\"},{\"key\":\"events/labels/location\",\"value\":\"Wo\"},{\"key\":\"faq/pageTitle\",\"value\":\"Fragen – Republik\"},{\"key\":\"faq/title\",\"value\":\"Antworten auf die häufigsten Fragen\"},{\"key\":\"faq/metaDescription\",\"value\":\"Jetzt Mitglied werden.\"},{\"key\":\"faq/before/title\",\"value\":\"FAQ – Ihre häufigsten Fragen\"},{\"key\":\"faq/before/support/title\",\"value\":\"Erste-Hilfe-Team\"},{\"key\":\"faq/before/support/text\",\"value\":\"Bei allen technischen Problemen helfen wir Ihnen gerne so schnell wie möglich per Mail: <a href=\\\"mailto:kontakt@republik.ch\\\">kontakt@republik.ch</a>\"},{\"key\":\"tokenAuthorization/title/existing\",\"value\":\"Zugriff geben?\"},{\"key\":\"tokenAuthorization/title/new\",\"value\":\"Nutzung Ihrer E-Mail-Adresse erlauben?\"},{\"key\":\"tokenAuthorization/title/sessionInfo\",\"value\":\"Möchten Sie folgendem Gerät Zugriff geben?\"},{\"key\":\"pages/feedback/title\",\"value\":\"Dialog\"},{\"key\":\"feedback/title\",\"value\":\"Dialog\"},{\"key\":\"feedback/unauthorized\",\"value\":\"Die Republik ist nur so stark wie ihre Community. Werden Sie ein Teil davon und lassen Sie uns miteinander reden. {buyLink}\"},{\"key\":\"feedback/unauthorized/buyText\",\"value\":\"Kommen Sie jetzt an Bord!\"},{\"key\":\"feedback/lead\",\"value\":\"Die Republik ist nur so stark wie ihre Community. Teilen Sie Ihr Wissen und Ihre Perspektive. {a}\"},{\"key\":\"feedback/lead/etikette\",\"value\":\"Wie wir in der Republik debattieren.\"},{\"key\":\"feedback/general/title\",\"value\":\"Allgemeines Feedback\"},{\"key\":\"feedback/general/lead\",\"value\":\"Hier können Sie Wünsche, Kritik und Lob an die Adresse der Republik einbringen.\"},{\"key\":\"feedback/link/general\",\"value\":\"Ich möchte Wünsche, Kritik oder Lob zur Republik abgeben.\"},{\"key\":\"feedback/article/headline\",\"value\":\"Zu welchem Stück wollen Sie einen Beitrag schreiben oder lesen?\"},{\"key\":\"feedback/activeDiscussions/label\",\"value\":\"Aktive Debatten\"},{\"key\":\"feedback/autoArticle/selected/headline\",\"value\":\"Beiträge zu {link}\"},{\"key\":\"feedback/latestComments/headline\",\"value\":\"Neueste Beiträge\"},{\"key\":\"feedback/articleSearch/label\",\"value\":\"Suche\"},{\"key\":\"feedback/articleSearch/empty\",\"value\":\"Keine Ergebnisse\"},{\"key\":\"feedback/articleItem/newPage/title\",\"value\":\"Zur Debattenseite\"},{\"key\":\"tokenAuthorization/error\",\"value\":\"Ungültiger Link\"},{\"key\":\"tokenAuthorization/after\",\"value\":\"Falls Sie diese Anfrage nicht ausgelöst haben, wählen Sie «Nein». Haben Sie den Verdacht, dass jemand Unbekanntes sich mit Ihrem Abonnement Zugang verschaffen will? Dann wenden Sie sich bitte an kontakt@republik.ch.\"},{\"key\":\"tokenAuthorization/location\",\"value\":\"Standort\"},{\"key\":\"tokenAuthorization/location/unknown\",\"value\":\"Unbekannt\"},{\"key\":\"tokenAuthorization/phrase\",\"value\":\"Seltsame Wörter\"},{\"key\":\"tokenAuthorization/email\",\"value\":\"Ihre E-Mail-Adresse\"},{\"key\":\"tokenAuthorization/ip\",\"value\":\"IP-Adresse\"},{\"key\":\"tokenAuthorization/grant\",\"value\":\"Ja\"},{\"key\":\"tokenAuthorization/deny\",\"value\":\"Nein\"},{\"key\":\"tokenAuthorization/fields/explanation\",\"value\":\"Um Ihr Konto zu aktivieren, benötigen wir noch folgende Informationen:\"},{\"key\":\"tokenAuthorization/fields/label/firstName\",\"value\":\"Ihr Vorname\"},{\"key\":\"tokenAuthorization/fields/error/firstName/missing\",\"value\":\"Vorname fehlt\"},{\"key\":\"tokenAuthorization/fields/label/lastName\",\"value\":\"Ihr Nachname\"},{\"key\":\"tokenAuthorization/fields/error/lastName/missing\",\"value\":\"Nachname fehlt\"},{\"key\":\"search/input/label\",\"value\":\"Suche\"},{\"key\":\"search/input/submit/aria\",\"value\":\"Ergebnisse anzeigen\"},{\"key\":\"search/input/reset/aria\",\"value\":\"Suche zurücksetzen\"},{\"key\":\"search/preloaded/results/0\",\"value\":\"Keine Ergebnisse\"},{\"key\":\"search/preloaded/results/1\",\"value\":\"{count} Ergebnis\"},{\"key\":\"search/preloaded/results/other\",\"value\":\"{count} Ergebnisse\"},{\"key\":\"search/preloaded/showresults/1\",\"value\":\"{count} Ergebnis anzeigen\"},{\"key\":\"search/preloaded/showresults/other\",\"value\":\"{count} Ergebnisse anzeigen\"},{\"key\":\"search/results/empty\",\"value\":\"Schande! Wir haben nichts gefunden.<br /><br />\\nFalls es sich nicht um einen Rechtschreibfehler von Ihnen handelt, handelt es sich vielleicht um ein Versäumnis von uns. Sollten wir ein unverzichtbares Thema verpasst haben, schreiben Sie uns ein kurzes E-Mail an <a href=\\\"mailto:kontakt@republik.ch?subject=Sch%C3%A4ndliche%20Suche\\\">kontakt@republik.ch</a>.\"},{\"key\":\"search/pageInfo/loadMore\",\"value\":\"mehr laden\"},{\"key\":\"search/pageInfo/total/0\",\"value\":\"Keine Ergebnisse\"},{\"key\":\"search/pageInfo/total/1\",\"value\":\"{count} Ergebnis\"},{\"key\":\"search/pageInfo/total/other\",\"value\":\"{count} Ergebnisse\"},{\"key\":\"search/pageInfo/loadedTotal\",\"value\":\"{loaded} von insgesamt {total} Ergebnissen\"},{\"key\":\"search/commentTeaser/discussionReference\",\"value\":\"Debatte {link}\"},{\"key\":\"search/sort/relevance\",\"value\":\"Relevanz\"},{\"key\":\"search/sort/publishedAt\",\"value\":\"Zeit\"},{\"key\":\"search/sort/ASC/aria\",\"value\":\"aufsteigend\"},{\"key\":\"search/sort/DESC/aria\",\"value\":\"absteigend\"},{\"key\":\"search/sort/random\",\"value\":\"Zufall\"},{\"key\":\"search/sort/createdAt\",\"value\":\"Zeit\"},{\"key\":\"search/excerpt\",\"value\":\"Auszug\"},{\"key\":\"search/docs/title\",\"value\":\"Spickzettel\"},{\"key\":\"search/docs/text\",\"value\":\"Enthält alle diese Wörter:\\n<br />\\n<a href='/suche?q=Energie Klima CO2'>Energie Klima CO2</a>\\n<br />\\n<br />\\nEnthält einige dieser Wörter: <b>Wort | Wort | …</b>\\n<br />\\n<a href='/suche?q=Bundesrat | Zauberformel | Parlament'>Bundesrat | Zauberformel | Parlament</a>\\n<br />\\n<br />\\nEnthält den exakten Ausdruck: <b>\\\"Ausdruck\\\"</b>\\n<br />\\n<a href='/suche?q=\\\"Europäische Union\\\"'>\\\"Europäische Union\\\"</a>\\n<br />\\n<br />\\nEin Wort ausschliessen: <b>-Wort</b>\\n<br />\\n<a href='/suche?q=\\\"Fake News\\\" -Russland'>\\\"Fake News\\\" -Russland</a>\\n<br />\\n<br />\\nKombinierte Suche: <b>( … )</b>\\n<br />\\n<a href='/suche?q=Daniel ( Binswanger | Ryser | Graf )'>\\n  Daniel ( Binswanger | Ryser | Graf )\\n</a>\\n\"},{\"key\":\"styleguide/video/dnt/note\",\"value\":\"Dies ist ein {player}-Video. Wenn Sie das Video abspielen, kann {platform} Sie tracken.\"},{\"key\":\"styleguide/video/dnt/player/youtube\",\"value\":\"Youtube\"},{\"key\":\"styleguide/video/dnt/player/vimeo\",\"value\":\"Vimeo\"},{\"key\":\"styleguide/charts/y-cut\",\"value\":\"Achse gekürzt\"},{\"key\":\"styleguide/charts/error\",\"value\":\"Diese Visualisierung kann, aufgrund eines technischen Fehlers, nicht dargestellt werden.\"},{\"key\":\"plattformUnauthorizedZoneText/native\",\"value\":\"Inhalt nur für Mitglieder. <a href=\\\"/probelesen\\\">Probelesen?</a>\"},{\"key\":\"styleguide/DynamicComponent/error\",\"value\":\"Diese Komponente kann, aufgrund eines technischen Fehlers, nicht dargestellt werden.\"},{\"key\":\"questionnaire/title\",\"value\":\"Republik-Umfrage\"},{\"key\":\"questionnaire/description\",\"value\":\"Sagen Sie uns Ihre Meinung!\"},{\"key\":\"questionnaire/header\",\"value\":\"Sie haben {userAnswerCount} von {questionCount} Fragen beantwortet.\"},{\"key\":\"questionnaire/invalid\",\"value\":\"Bitte beantworten Sie mindestens eine Frage.\"},{\"key\":\"questionnaire/notEligible\",\"value\":\"Nur Mitglieder können den Fragebogen beantworten.<br/><b>Haben Sie ein Abonnement? <a href='/anmelden'>Anmelden</a></b>\"},{\"key\":\"questionnaire/privacy/private\",\"value\":\"Antworten sind öffentlich einsehbar. Für Probeleser und Mitverlegerinnen erscheint der ausgefüllte Fragebogen unter Ihrem Namen. Gäste sehen lediglich Ihre Initialen.\"},{\"key\":\"questionnaire/privacy/public\",\"value\":\"Antworten sind öffentlich einsehbar. Da Sie ein öffentliches Profil haben, erscheint Ihr Fragebogen für alle unter Ihrem Namen.\"},{\"key\":\"questionnaire/submit\",\"value\":\"abschicken\"},{\"key\":\"questionnaire/publish\",\"value\":\"publizieren\"},{\"key\":\"questionnaire/update\",\"value\":\"aktualisieren\"},{\"key\":\"questionnaire/reset\",\"value\":\"Antworten löschen\"},{\"key\":\"questionnaire/reset/confirm\",\"value\":\"Sind Sie sicher, dass Sie Ihre Antworten löschen wollen?\"},{\"key\":\"questionnaire/turnout\",\"value\":\"Basierend auf {formattedSubmittedCount} Antworten. {formattedSkippedCount} Personen haben diese Frage übersprungen.\"},{\"key\":\"questionnaire/share/dialogTitle\",\"value\":\"Fragebogen teilen\"},{\"key\":\"questionnaire/share/title\",\"value\":\"Fragebogen von {name}\"},{\"key\":\"questionnaire/thankyou\",\"value\":\"Ihre Antworten sind bei uns angekommen. Danke fürs Mitmachen!\"},{\"key\":\"questionnaire/thankyou/public\",\"value\":\"Ihre Antworten sind publiziert. Danke fürs Mitmachen!\"},{\"key\":\"questionnaire/thankyou/resubmit\",\"value\":\"bearbeiten\"},{\"key\":\"questionnaire/thankyou/revoke\",\"value\":\"zurückziehen\"},{\"key\":\"questionnaire/ended\",\"value\":\"Die Umfrage ist vorbei.\"},{\"key\":\"questionnaire/article/help\",\"value\":\"Suchen Sie mit dem Titel oder einem Stichwort nach dem Artikel. Sie können diese Frage auch überspringen.\"},{\"key\":\"questionnaire/article/label\",\"value\":\"Artikel suchen\"},{\"key\":\"questionnaire/text/label\",\"value\":\"Ihre Antwort\"},{\"key\":\"questionnaire/text/max\",\"value\":\"max. {maxLength} Zeichen\"},{\"key\":\"questionnaire/text/remaining\",\"value\":\"{remaining} Zeichen übrig\"},{\"key\":\"questionnaire/choice/helpMultiple\",\"value\":\"Sie können mehrere Optionen auswählen.\"},{\"key\":\"questionnaire/crowd/title\",\"value\":\"Republik-Komplizin werden\"},{\"key\":\"questionnaire/crowd/description\",\"value\":\"Die Republik muss bekannter werden. Helfen Sie uns, Ihnen zu helfen, uns zu helfen.\"},{\"key\":\"questionnaire/crowd/intro\",\"value\":\"Schön, sind Sie hier! Helfen Sie mit, damit die Republik besser und bekannter wird. Dieses kleine Formular hilft uns, Sie ein wenig besser kennenzulernen. Am Schluss können Sie den Komplizen-Newsletter abonnieren.\"},{\"key\":\"questionnaire/crowd/question1\",\"value\":\"Möchten Sie die Republik als Komplizin unterstützen?\\n\\n\"},{\"key\":\"questionnaire/crowd/question1/alt\",\"value\":\"Nur um sicherzugehen: Haben Sie sich vertippt?\"},{\"key\":\"questionnaire/crowd/submitted/title\",\"value\":\"Komplizen-Newsletter abonnieren\"},{\"key\":\"questionnaire/crowd/submitted/intro\",\"value\":\"Vielen Dank für Ihre Bereitschaft, unser gemeinsames Unternehmen als Komplizin zu unterstützen. Ohne das Engagement vieler Menschen wie Sie wären wir nicht an dem Punkt, an dem wir heute sind.\\n\\nDürfen wir Ihnen den Komplizen-Newsletter zustellen? Er ist der wichtigste Informationskanal für unsere Komplizen. Er wird rund 4 bis 6 Mal im Jahr verschickt und informiert Sie über Veranstaltungen und Aktionen sowie aktuelle Möglichkeiten, die Republik besser und bekannter zu machen.\"},{\"key\":\"questionnaire/crowd/submitted/optout\",\"value\":\"Sie können sich jederzeit wieder aus der Liste austragen.\"},{\"key\":\"questionnaire/crowd/submitted/declined/intro\",\"value\":\"Vielen Dank für Ihre Zeit. Hier gehts zurück zum Magazin.\"},{\"key\":\"questionnaire/submissions/count/1\",\"value\":\"Eine Person hat bereits geantwortet\"},{\"key\":\"questionnaire/submissions/count/other\",\"value\":\"{count} Teilnehmende\"},{\"key\":\"questionnaire/submissions/showAnswers/other\",\"value\":\"{count} weitere Antworten lesen\"},{\"key\":\"questionnaire/submissions/showAnswers/1\",\"value\":\"Eine weitere Antwort lesen\"},{\"key\":\"questionnaire/submissions/answers/other\",\"value\":\"{count} Antworten\"},{\"key\":\"questionnaire/submissions/answers/1\",\"value\":\"Eine Antwort\"},{\"key\":\"questionnaire/submissions/loadMore/other\",\"value\":\"Weitere {count} Fragebögen laden\"},{\"key\":\"questionnaire/submissions/loadMore/1\",\"value\":\"Einen weiteren Fragebogen laden\"},{\"key\":\"questionnaire/submissions/shareText\",\"value\":\"Stöbern Sie durch die Antworten der Republik-Leserinnen, und fügen Sie Ihre eigene Antwort hinzu.\"},{\"key\":\"questionnaire/submission/description\",\"value\":\"Die Antworten von {name}\"},{\"key\":\"instantSurvey/toggle/answers\",\"value\":\"Antworten anzeigen\"},{\"key\":\"instantSurvey/toggle/question\",\"value\":\"Frage beantworten\"},{\"key\":\"instantSurvey/toggle/question\",\"value\":\"Frage beantworten\"},{\"key\":\"instantSurvey/toggle/votes/0\",\"value\":\"Bisher ist keine Stimme eingegangen.\"},{\"key\":\"instantSurvey/toggle/votes/1\",\"value\":\"{count} Stimme\"},{\"key\":\"instantSurvey/toggle/votes/other\",\"value\":\"{count} Stimmen\"},{\"key\":\"instantSurvey/login\",\"value\":\"<a href='/anmelden'>Melden Sie sich an</a>, um die Frage zu beantworten.\"},{\"key\":\"pages/meta/questionnaire/unauthorized\",\"value\":\"Vielen Dank für Ihr Interesse an unserer Umfrage. Unsere Mitglieder und Abonnentinnen können daran teilnehmen – {buyLink}\"},{\"key\":\"pages/meta/questionnaire/unauthorized/buyText\",\"value\":\"kommen Sie an Bord!\"},{\"key\":\"pages/meta/questionnaire/crowd/socialTitle\",\"value\":\"Das 1-Minuten-Formular\"},{\"key\":\"questionnaire/postcard/submit\",\"value\":\"Karte speichern\"},{\"key\":\"questionnaire/postcard/publish\",\"value\":\"Abschicken\"},{\"key\":\"questionnaire/submitanonym\",\"value\":\"Anonym abschicken\"},{\"key\":\"questionnaire/postcard/revoke\",\"value\":\"Nochmals bearbeiten\"},{\"key\":\"questionnaire/climatepersonalinfo/submit\",\"value\":\"Speichern\"},{\"key\":\"questionnaire/postcard/privacy/public\",\"value\":\"Sie haben ein öffentliches Profil bei der Republik. Wenn Sie nicht möchten, dass Sie als Absenderin erkennbar sind, wählen Sie «Anonym abschicken».\"},{\"key\":\"questionnaire/postcard/privacy/private\",\"value\":\"Wenn Sie nicht möchten, dass Sie als Absenderin erkennbar sind, wählen Sie «Anonym abschicken».\"},{\"key\":\"package/PROLONG/title\",\"value\":\"Verlängern\"},{\"key\":\"package/PROLONG/pageTitle\",\"value\":\"Verlängern Sie Ihr Investment.\"},{\"key\":\"package/PROLONG/price\",\"value\":\"{formattedCHF} pro Jahr\"},{\"key\":\"package/PROLONG/price/give\",\"value\":\"{formattedCHF}\"},{\"key\":\"option/PROLONG/ABO/label\",\"value\":\"Reguläre Verlängerung\"},{\"key\":\"option/PROLONG/ABO/label/give\",\"value\":\"Verlängerung schenken\"},{\"key\":\"option/PROLONG/BENEFACTOR_ABO/label\",\"value\":\"Gönnerin oder Gönner\"},{\"key\":\"option/PROLONG/resetGroup\",\"value\":\"Jetzt nicht\"},{\"key\":\"memberships/manage/reactivate\",\"value\":\"Kündigung zurücknehmen\"},{\"key\":\"memberships/manage/prolong/link\",\"value\":\"Jetzt verlängern\"},{\"key\":\"memberships/manage/prolong/awaiting\",\"value\":\"Sie haben bereits eine weitere Mitgliedschaft, diese wird automatisch zur Verlängerung genutzt.\"},{\"key\":\"memberships/manage/cancel/link\",\"value\":\"Mitgliedschaft kündigen\"},{\"key\":\"memberships/manage/autoPay/enable\",\"value\":\"Automatische Abbuchung aktivieren\"},{\"key\":\"memberships/manage/autoPay/disable\",\"value\":\"Automatische Abbuchung deaktivieren\"},{\"key\":\"memberships/manage/native/info\",\"value\":\"Zum Verwalten besuchen Sie unsere Webseite.\"},{\"key\":\"option/PROLONG/additionalPeriods/endDate\",\"value\":\"Neu gültig bis {formattedEndDate}\"},{\"key\":\"option/PROLONG/additionalPeriods/REGULAR/title\",\"value\":\"Verlängerung um ein Jahr\"},{\"key\":\"option/PROLONG/additionalPeriods/BONUS/title\",\"value\":\"Plus {days} zusätzliche Tage als Geschenk für Unterstützerinnen des ersten Tages.\"},{\"key\":\"option/PROLONG/additionalPeriods/give\",\"value\":\"{name} wird per E-Mail über die geschenkte Verlängerung informiert.\"},{\"key\":\"package/TABLEBOOK/title\",\"value\":\"Buch «Republik bei Stromausfall»\"},{\"key\":\"package/MASK/title\",\"value\":\"Republik-Maske\"},{\"key\":\"memberships/title/ABO\",\"value\":\"Mitgliedschaft (#{sequenceNumber})\"},{\"key\":\"memberships/title/BENEFACTOR_ABO\",\"value\":\"Gönner-Mitgliedschaft (#{sequenceNumber})\"},{\"key\":\"memberships/title/MONTHLY_ABO\",\"value\":\"Monats-Abo (#{sequenceNumber})\"},{\"key\":\"memberships/title/ABO_GIVE_MONTHS\",\"value\":\"Abonnement (#{sequenceNumber})\"},{\"key\":\"memberships/title/YEARLY_ABO\",\"value\":\"Mitstreiter-Abo\"},{\"key\":\"memberships/title/ABO/give\",\"value\":\"{name} (#{sequenceNumber})\"},{\"key\":\"memberships/title/BENEFACTOR_ABO/give\",\"value\":\"{name}: Gönner-Mitgliedschaft (#{sequenceNumber})\"},{\"key\":\"memberships/title/ABO_GIVE_MONTHS/give\",\"value\":\"{name} (#{sequenceNumber})\"},{\"key\":\"pledge/submit/autoPay\",\"value\":\"Ohne Bürokratie: Verlängerungen automatisch von meiner Kreditkarte abbuchen.\"},{\"key\":\"pledge/submit/autoPay/note\",\"value\":\"Wir erinnern Sie, bevor wir abbuchen. Und Sie können jederzeit in Ihrem Konto kündigen.\"},{\"key\":\"pledge/submit/MONTHLY_ABO/autoPay/note\",\"value\":\"Ihr Monatsabo verlängert sich automatisch. Sie können das Abo jederzeit in Ihrem Konto kündigen.\"},{\"key\":\"pledge/submit/PROLONG/autoPay\",\"value\":\"Keine Bürokratie mehr: zukünftige Verlängerungen meiner Mitgliedschaft automatisch von meiner Kreditkarte abbuchen.\"},{\"key\":\"pledge/title/member\",\"value\":\"Das Angebot\"},{\"key\":\"package/customize/price/payMore/normal\",\"value\":\"Reguläre {formattedCHF}\"},{\"key\":\"package/customize/price/payMore/bonus\",\"value\":\"Keine Geschenke! Ich zahle die zusätzlichen Tage: {formattedCHF}\"},{\"key\":\"package/customize/price/payLess\",\"value\":\"Ich kann mir den Betrag nicht leisten\"},{\"key\":\"package/customize/userPrice/YEARLY_ABO/beforePrice\",\"value\":\"Welcher Preis stimmt für Sie?\"},{\"key\":\"package/customize/userPrice/beforePrice\",\"value\":\"Wie viel können Sie bezahlen?\"},{\"key\":\"memberships/cancel/notFound\",\"value\":\"Mitgliedschaft nicht gefunden\"},{\"key\":\"memberships/cancel/title\",\"value\":\"Mitgliedschaft kündigen\"},{\"key\":\"memberships/cancel/signIn\",\"value\":\"Sie müssen sich anmelden, um zu kündigen.\"},{\"key\":\"memberships/cancel/info\",\"value\":\"Ich möchte die Republik aus folgendem Grund nicht mehr unterstützen:\"},{\"key\":\"memberships/cancel/confirmation\",\"value\":\"Haben Sie gekündigt, weil Sie das Gefühl haben, zu wenig Zeit zu haben? Dann geben Sie uns noch eine zweite Chance und bleiben Sie aus ideellen Gründen dabei. Wir brauchen jede und jeden.\"},{\"key\":\"memberships/cancel/confirmation/title\",\"value\":\"Sie haben erfolgreich gekündigt.\"},{\"key\":\"memberships/cancel/description\",\"value\":\"Erläuterungen\"},{\"key\":\"memberships/cancel/description/empty\",\"value\":\"Erläuterungen fehlt\"},{\"key\":\"memberships/cancel/accountLink\",\"value\":\"Zum Konto\"},{\"key\":\"memberships/cancel/button\",\"value\":\"Kündigung abschicken\"},{\"key\":\"memberships/cancel/userPrice\",\"value\":\"Sie können sich den Betrag nicht leisten? Journalismus kostet. Aber wir wollen niemanden ausschliessen.\"},{\"key\":\"memberships/cancel/userPriceLink\",\"value\":\"Wie viel können Sie bezahlen?\"},{\"key\":\"account/app/prolong/link\",\"value\":\"Jetzt Mitgliedschaft verlängern\"},{\"key\":\"testimonial/detail/share/package/PROLONG\",\"value\":\"Ich habe mein Abo verlängert\"},{\"key\":\"pledge/form/statement/PROLONG/title\",\"value\":\"{name} hat das Abo bereits verlängert.\"},{\"key\":\"pledge/form/instruction/PROLONG/signIn\",\"value\":\"Melden Sie sich an, um Ihr Abo zu verlängern. Oder, falls Sie noch nicht Mitglied sind: Jetzt ist ein guter Zeitpunkt dafür, die Republik zu unterstützen.\"},{\"key\":\"pledge/form/instruction/PROLONG/availableWithStatement\",\"value\":\"Jetzt sind Sie dran!\"},{\"key\":\"pledge/form/instruction/PROLONG/notAvailable\",\"value\":\"Zurzeit ist für Sie keine Verlängerung verfügbar. Entweder haben Sie bereits verlängert, oder Sie sind noch nicht Mitglied. Alle Informationen finden Sie in Ihrem {accountLink}.\"},{\"key\":\"pledge/form/instruction/PROLONG/accountText\",\"value\":\"Konto\"},{\"key\":\"pledge/form/instruction/TABLEBOOK/notAvailable\",\"value\":\"Dieses Produkt steht im Moment nicht zur Verfügung.\"},{\"key\":\"pledge/form/instruction/TABLEBOOK/signIn\",\"value\":\"Dieses Produkt steht im Moment nicht zur Verfügung.\"},{\"key\":\"pledge/form/instruction/MASK/notAvailable\",\"value\":\"Dieses Produkt steht im Moment nicht zur Verfügung.\"},{\"key\":\"pledge/form/instruction/MASK/signIn\",\"value\":\"Dieses Produkt steht im Moment nicht zur Verfügung.\"},{\"key\":\"pledge/meta/title\",\"value\":\"Republik-Mitglied und Abonnentin werden\"},{\"key\":\"pledge/meta/description\",\"value\":\"Wir sind ein digitales Magazin für Politik, Wirtschaft, Gesellschaft und Kultur. Unabhängig. Werbefrei.\"},{\"key\":\"pledge/meta/group/GIVE/title\",\"value\":\"Die Republik zum Verschenken\"},{\"key\":\"pledge/meta/group/GIVE/description\",\"value\":\"Wir sind ein digitales Magazin für Politik, Wirtschaft, Gesellschaft und Kultur. Unabhängig. Werbefrei.\"},{\"key\":\"pledge/meta/package/ABO_GIVE/title\",\"value\":\"Republik Jahresmitgliedschaft verschenken\"},{\"key\":\"pledge/meta/package/ABO_GIVE/description\",\"value\":\"Wir sind ein digitales Magazin für Politik, Wirtschaft, Gesellschaft und Kultur. Unabhängig. Werbefrei.\"},{\"key\":\"pledge/meta/package/ABO_GIVE_MONTHS/title\",\"value\":\"Republik Monats-Abo verschenken\"},{\"key\":\"pledge/meta/package/ABO_GIVE_MONTHS/description\",\"value\":\"Wir sind ein digitales Magazin für Politik, Wirtschaft, Gesellschaft und Kultur. Unabhängig. Werbefrei.\"},{\"key\":\"pledge/meta/package/YEARLY_ABO/title\",\"value\":\"Verstärken Sie die Republik-Community!\"},{\"key\":\"pledge/meta/package/YEARLY_ABO/description\",\"value\":\"Wir sind ein digitales Magazin für Politik, Wirtschaft, Gesellschaft und Kultur. Unabhängig. Werbefrei.\"},{\"key\":\"pledge/meta/package/LESHA/title\",\"value\":\"Lesha Berezovskiy: «We Stay»\"},{\"key\":\"pledge/meta/package/LESHA/description\",\"value\":\"Ein persönlicher, fotografischer Blick auf den Krieg in der Ukraine.\"},{\"key\":\"pledge/form/statement/share/title\",\"value\":\"{name} bleibt der Republik treu.\"},{\"key\":\"pledge/form/statement/share/description\",\"value\":\"Verlängern auch Sie jetzt Ihr Abo.\"},{\"key\":\"statement/title\",\"value\":\"Jetzt ein Statement abgeben.\"},{\"key\":\"statement/title/update\",\"value\":\"Jetzt Ihr Statement aktualisieren.\"},{\"key\":\"statement/description\",\"value\":\"Sie können ein Statement abgeben und es zusammen mit einem Porträtbild auf unserer Community-Seite veröffentlichen.\"},{\"key\":\"statement/description/update\",\"value\":\"Ihr Statement erscheint auf unserer Community-Seite.\"},{\"key\":\"statement/adminUnpublished\",\"value\":\"Wir können Ihr Statement leider nicht publizieren. Schreiben Sie an kontakt@republik.ch für weitere Informationen.\"},{\"key\":\"statement/submit/update\",\"value\":\"aktualisieren\"},{\"key\":\"statement/submit\",\"value\":\"veröffentlichen\"},{\"key\":\"statement/unpublish\",\"value\":\"Statement zurücknehmen\"},{\"key\":\"statement/unpublished\",\"value\":\"Ihr Statement ist zurzeit nicht publik.\"},{\"key\":\"statement/viewLive\",\"value\":\"ansehen\"},{\"key\":\"statement/404\",\"value\":\"Das gewünschte Statement ist zurzeit nicht verfügbar.\"},{\"key\":\"statement/share/overlayTitle\",\"value\":\"Statement von {name}\"},{\"key\":\"statement/share/title\",\"value\":\"{name} unterstützt die Republik.\"},{\"key\":\"statement/share/PROLONG/title\",\"value\":\"{name} hat bereits das Abo verlängert\"},{\"key\":\"statement/share/please\",\"value\":\"Teilen Sie, dass Sie die Republik unterstützen:\"},{\"key\":\"statement/share/PROLONG/please\",\"value\":\"Teilen Sie, dass Sie Ihr Abo verlängert haben:\"},{\"key\":\"statement/share/PROLONG/emailBody\",\"value\":\"Hallo\\n\\nEine funktionierende Demokratie braucht funktionierende Medien. Und dafür braucht es nicht nur Journalistinnen und Journalisten, sondern Menschen, die bereit sind, langfristig in unabhängigen Journalismus zu investieren.\\n\\nIch habe soeben meine Republik-Mitgliedschaft verlängert.\\n\\nJetzt Mitgliedschaft verlängern oder Mitglied werden: {url}\\n\\nHerzliche Grüsse,  {backerName}\"},{\"key\":\"package/customize/price/label/total\",\"value\":\"Gesamtbetrag in CHF\"},{\"key\":\"package/customize/group/aboGive\",\"value\":\"Sie haben im letzten Jahr mindestens einer guten Freundin oder einem Feind einen Sitz in der Republik-Verlegerschaft geschenkt. Soll Ihr Geschenk weiterlaufen?\"},{\"key\":\"pledge/contact/signIn/wrongToken\",\"value\":\"Ist das nicht Ihre E-Mail-Adresse?\"},{\"key\":\"pledge/option/PROLONG/ABO/label\",\"value\":\"Jahresmitgliedschaft\"},{\"key\":\"pledge/option/PROLONG/ABO/label/give\",\"value\":\"Mitgliedschaft für {name} (#{sequenceNumber}){endDateSuffix}\"},{\"key\":\"pledge/option/PROLONG/BENEFACTOR_ABO/label\",\"value\":\"Gönner-Mitgliedschaft\"},{\"key\":\"pledge/option/PROLONG/BENEFACTOR_ABO/label/give\",\"value\":\"Gönner-Mitgliedschaft für {name} (#{sequenceNumber}){endDateSuffix}\"},{\"key\":\"pledge/option/ABO_GIVE_MONTHS/ABO_GIVE_MONTHS/label/1\",\"value\":\"Monats-Abo als Geschenk für {periods}\"},{\"key\":\"pledge/option/ABO_GIVE_MONTHS/ABO_GIVE_MONTHS/label/other\",\"value\":\"Monats-Abos als Geschenk für {periods}\"},{\"key\":\"pledge/option/ABO_GIVE_MONTHS/ABO_GIVE_MONTHS/label/give\",\"value\":\"Monats-Abo als Geschenk für {name} (#{sequenceNumber}){endDateSuffix}\"},{\"key\":\"option/ABO_GIVE_MONTHS/interval/month/periods/1\",\"value\":\"einen Monat\"},{\"key\":\"option/ABO_GIVE_MONTHS/interval/month/periods/other\",\"value\":\"{count} Monate\"},{\"key\":\"option/suffix/endDate\",\"value\":\" bis {formattedEndDate}\"},{\"key\":\"crowdfunding/status/goal/people\",\"value\":\"von {count} Mitgliedern\"},{\"key\":\"crowdfunding/status/goal/memberships\",\"value\":\"von {count} Mitgliedschaften\"},{\"key\":\"crowdfunding/status/goal/PROLONG/memberships\",\"value\":\"bereits verlängerte Mitgliedschaften. Ziel: {count}.\"},{\"key\":\"crowdfunding/status/goal/SURVIVE/memberships\",\"value\":\"neue Mitgliedschaften und Abos im März. Ambition: {count}.\"},{\"key\":\"crowdfunding/status/goal/money\",\"value\":\"von {count}\"},{\"key\":\"crowdfunding/status/time/label\",\"value\":\"bis Deadline\"},{\"key\":\"crowdfunding/status/time/days/1\",\"value\":\"1 Tag\"},{\"key\":\"crowdfunding/status/time/days/other\",\"value\":\"{count} Tage\"},{\"key\":\"crowdfunding/status/time/hours/1\",\"value\":\"1 Stunde\"},{\"key\":\"crowdfunding/status/time/hours/other\",\"value\":\"{count} Stunden\"},{\"key\":\"crowdfunding/status/time/minutes/1\",\"value\":\"1 Minute\"},{\"key\":\"crowdfunding/status/time/minutes/other\",\"value\":\"{count} Minuten\"},{\"key\":\"crowdfunding/status/time/seconds/1\",\"value\":\"1 Sekunde\"},{\"key\":\"crowdfunding/status/time/seconds/other\",\"value\":\"{count} Sekunden\"},{\"key\":\"crowdfunding/status/time/ended\",\"value\":\"Das Crowdfunding ist vorbei.\"},{\"key\":\"meta/prolong/title\",\"value\":\"Mit der Republik ins zweite Jahr\"},{\"key\":\"stats/membershipPeriods/labels/prolong\",\"value\":\"Erneuerungen\"},{\"key\":\"stats/membershipPeriods/labels/cancel\",\"value\":\"Kündigungen\"},{\"key\":\"stats/membershipPeriods/prolongRate/past\",\"value\":\"Erneuerungsrate\"},{\"key\":\"stats/membershipPeriods/prolongRate/current\",\"value\":\"Aktuelle Erneuerungsrate\"},{\"key\":\"meta/prolong/signIn\",\"value\":\"Melden Sie sich an, um Ihr {prolongLink}. Oder, falls Sie noch nicht Mitglied sind: Jetzt ist ein guter Zeitpunkt dafür, die {pledgeLink}.\"},{\"key\":\"meta/prolong/signIn/prolongText\",\"value\":\"Abo zu verlängern\"},{\"key\":\"meta/prolong/signIn/pledgeText\",\"value\":\"Republik zu unterstützen\"},{\"key\":\"meta/prolong/available\",\"value\":\"Jetzt verlängern\"},{\"key\":\"overview/meta/title\",\"value\":\"Jahresüberblick {year}\"},{\"key\":\"overview/meta/title/wochen\",\"value\":\"Jahresüberblick {year} Wochen\"},{\"key\":\"overview/meta/description\",\"value\":\"Lassen Sie Reportagen, Analysen, Recherchen, Essays, Kolumnen, Debatten, Veranstaltungen, Experimente und Irrtümer nochmals Revue passieren – Monat für Monat, Tag für Tag.\"},{\"key\":\"overview/meta/description/wochen\",\"value\":\"Lassen Sie Reportagen, Analysen, Recherchen, Essays, Kolumnen, Debatten, Veranstaltungen, Experimente und Irrtümer nochmals Revue passieren – Woche für Woche, Tag für Tag.\"},{\"key\":\"overview/2018/meta/title\",\"value\":\"Schauen Sie auf dieses Jahr!\"},{\"key\":\"overview/2018/meta/description\",\"value\":\"2018, das waren auch die ersten 300 Tage Republik. Lassen Sie alle Reportagen, Analysen, Recherchen, Essays, Kolumnen, Debatten, Veranstaltungen, Experimente und Irrtümer nochmals Revue passieren.\"},{\"key\":\"overview/title\",\"value\":\"{year}, Monat für Monat\"},{\"key\":\"overview/title/wochen\",\"value\":\"{year}, Woche für Woche\"},{\"key\":\"overview/2018/lead\",\"value\":\"Lassen Sie das erste Jahr der Republik Revue passieren.\"},{\"key\":\"overview/lead/signIn\",\"value\":\"Melden Sie sich an, um die Beiträge lesen zu können. Noch nicht Mitglied?\"},{\"key\":\"overview/lead/pledge\",\"value\":\"Werden Sie Mitglied, um die Beiträge lesen zu können.\"},{\"key\":\"overview/lead/pledgeButton\",\"value\":\"Kommen Sie an Bord!\"},{\"key\":\"overview/after/pledgeButton\",\"value\":\"Jetzt Mitglied werden\"},{\"key\":\"prolongNecessary/ABO_GIVE_MONTHS/due\",\"value\":\"Ihr Abonnement läuft aus: {link}\"},{\"key\":\"prolongNecessary/ABO_GIVE_MONTHS/due/linkText\",\"value\":\"Jetzt verlängern\"},{\"key\":\"prolongNecessary/due\",\"value\":\"Ihr Mitgliedschaftsbeitrag ist fällig: {link}\"},{\"key\":\"prolongNecessary/due/linkText\",\"value\":\"Jetzt bezahlen\"},{\"key\":\"prolongNecessary/ABO_GIVE_MONTHS/overdue\",\"value\":\"Ihr Abonnement ist überfällig.\"},{\"key\":\"prolongNecessary/overdue\",\"value\":\"Ihr Mitglied­schafts­beitrag ist überfällig.\"},{\"key\":\"prolongNecessary/ABO_GIVE_MONTHS/overdue/button\",\"value\":\"Jetzt verlängern\"},{\"key\":\"prolongNecessary/overdue/button\",\"value\":\"Jetzt bezahlen\"},{\"key\":\"prolongNecessary/ABO_GIVE_MONTHS/overdue/explanation\",\"value\":\"Ihr Abonnement lief {daysAgo} aus und wird am {graceEndDate} deaktiviert. Sie möchten uns nicht mehr lesen? {cancelLink}.\"},{\"key\":\"prolongNecessary/overdue/explanation\",\"value\":\"Ihre Mitgliedschaft wird am {graceEndDate} deaktiviert, wenn Sie bis dahin nicht bezahlen. Wollen Sie die Republik nicht mehr lesen? Bitte kündigen Sie Ihre Mitgliedschaft: {cancelLink}.\"},{\"key\":\"prolongNecessary/ABO_GIVE_MONTHS/overdue/explanation/cancelText\",\"value\":\"Sagen Sie uns, warum\"},{\"key\":\"prolongNecessary/overdue/explanation/cancelText\",\"value\":\"Teilen Sie uns mit, warum\"},{\"key\":\"prolongNecessary/days/0\",\"value\":\"heute\"},{\"key\":\"prolongNecessary/days/1\",\"value\":\"gestern\"},{\"key\":\"prolongNecessary/days/other\",\"value\":\"vor {count} Tagen\"},{\"key\":\"prolongNecessary/YEARLY_ABO/before\",\"value\":\"Ihr Abo endet bald: {link}\"},{\"key\":\"prolongNecessary/YEARLY_ABO/before/linkText\",\"value\":\"Jahresmitglied werden\"},{\"key\":\"prolongNecessary/YEARLY_ABO/due\",\"value\":\"Mitstreiter-Abo endet bald: {link}\"},{\"key\":\"prolongNecessary/YEARLY_ABO/due/linkText\",\"value\":\"Jetzt Jahresmitglied werden\"},{\"key\":\"prolongNecessary/YEARLY_ABO/overdue\",\"value\":\"Ihr Abo endet – und Ihre Mitgliedschaft beginnt?\"},{\"key\":\"prolongNecessary/YEARLY_ABO/overdue/button\",\"value\":\"Jetzt Jahresmitglied werden\"},{\"key\":\"prolongNecessary/YEARLY_ABO/overdue/explanation\",\"value\":\"Ihr Abo läuft am {endDate} aus. Doch das muss nicht das Ende Ihrer Zeit bei der Republik bedeuten: Werden Sie jetzt Jahresmitglied und unterstützen Sie unseren Journalismus auch in Zukunft.\"},{\"key\":\"prolongNecessary/YEARLY_ABO/overdue/explanation/cancelText\",\"value\":\"Abonnement kündigen\"},{\"key\":\"prolongNecessary/native/info\",\"value\":\"besuchen Sie unsere Webseite.\"},{\"key\":\"crowdfunding/status/time/ended/PROLONG\",\"value\":\"Ein detaillierter Überblick folgt Ende Monat.\"},{\"key\":\"crowdfunding/status/time/ended/SURVIVE\",\"value\":\"Wir haben es geschafft.\"},{\"key\":\"nav/bookmarks\",\"value\":\"Lesezeichen\"},{\"key\":\"nav/vote\",\"value\":\"Urabstimmung\"},{\"key\":\"bookmark/title/bookmarked\",\"value\":\"Lesezeichen entfernen\"},{\"key\":\"bookmark/title/default\",\"value\":\"Lesezeichen hinzufügen\"},{\"key\":\"bookmark/label\",\"value\":\"Merken\"},{\"key\":\"pages/bookmarks/title\",\"value\":\"Lesezeichen\"},{\"key\":\"pages/bookmarks/placeholder\",\"value\":\"Sie haben keine Lesezeichen gesetzt. Stöbern Sie im {feedLink} und klicken Sie bei einem Beitrag auf {bookmarkIcon} – dann erscheint er hier auf Ihrer persönlichen Liste. \"},{\"key\":\"pages/bookmarks/placeholder/continue\",\"value\":\"Sie haben zur Zeit keine angefangen Lesepositionen und keine nicht gelesenen Lesezeichen. Stöbern Sie im {feedLink} um etwas Neues zu finden. \"},{\"key\":\"pages/bookmarks/placeholder/read\",\"value\":\"Es sind noch keine fertig gelesenen Beiträge gespeicherte.\"},{\"key\":\"pages/bookmarks/help\",\"value\":\"Neu hinzugefügte Beiträge erscheinen zuoberst.\"},{\"key\":\"pages/bookmarks/placeholder/feedText\",\"value\":\"Feed\"},{\"key\":\"pages/bookmarks/help/bookmarks\",\"value\":\"Alle Lesezeichen. Neu hinzugefügte Beiträge erscheinen zuoberst.\"},{\"key\":\"pages/bookmarks/help/continue\",\"value\":\"Angefangene Beiträge und noch nicht gelesene Lesezeichen. Zuletzt angefangene oder hinzugefügte Beiträge erscheinen zuoberst.\"},{\"key\":\"pages/bookmarks/help/read\",\"value\":\"Alle fertig gelesenen Beiträge. Zuletzt gelesene Beiträge erscheinen zuoberst.\"},{\"key\":\"pages/bookmarks/tab/bookmarks\",\"value\":\"Gemerkt\"},{\"key\":\"pages/bookmarks/tab/continue\",\"value\":\"Weiterlesen\"},{\"key\":\"pages/bookmarks/tab/read\",\"value\":\"Gelesen\"},{\"key\":\"styleguide/TeaserFeed/InternalOnlyTag\",\"value\":\"Interne Publikation (Editoren-Vorschau)\"},{\"key\":\"AudioPlayer/Latest\",\"value\":\"Neueste Beiträge\"},{\"key\":\"AudioPlayer/Latest/ReadAloud\",\"value\":\"Vorgelesen\"},{\"key\":\"AudioPlayer/Latest/All\",\"value\":\"Alle\"},{\"key\":\"AudioPlayer/Latest/NoItems\",\"value\":\"Keine Beiträge verfügbar.\"},{\"key\":\"AudioPlayer/Latest/LoadMore\",\"value\":\"Weitere Beiträge laden\"},{\"key\":\"AudioPlayer/Queue\",\"value\":\"Wiedergabeliste\"},{\"key\":\"AudioPlayer/noMemberText\",\"value\":\"Die Wiedergabeliste ist nur für Mitglieder verfügbar.\"},{\"key\":\"AudioPlayer/Queue/Add\",\"value\":\"Zur Wiedergabeliste hinzufügen\"},{\"key\":\"AudioPlayer/Queue/alreadyInQueue\",\"value\":\"Bereits in der Wiedergabeliste vorhanden\"},{\"key\":\"AudioPlayer/Queue/ActiveHeading\",\"value\":\"Aktueller Beitrag\"},{\"key\":\"AudioPlayer/Queue/NoActiveHeading\",\"value\":\"Audioplayer\"},{\"key\":\"AudioPlayer/Queue/Remove\",\"value\":\"Aus Wiedergabeliste entfernen\"},{\"key\":\"AudioPlayer/Queue/Download\",\"value\":\"Audiodatei herunterladen\"},{\"key\":\"AudioPlayer/Queue/AddToQueueAsNext\",\"value\":\"Als Nächstes abspielen\"},{\"key\":\"AudioPlayer/Queue/GoToItem\",\"value\":\"Zum Beitrag\"},{\"key\":\"AudioPlayer/Queue/EmptyQueue/p1\",\"value\":\"Sie haben noch keine Beiträge in Ihrer Wiedergabeliste.\"},{\"key\":\"AudioPlayer/Queue/EmptyQueue/p2\",\"value\":\"Über das Wiedergabelisten-Symbol {icon}, können Sie Beiträge in Ihre Wiedergabeliste hinzufügen.\"},{\"key\":\"AudioPlayer/Queue/EmptyQueue/progressInfo\",\"value\":\"Damit die Abspielposition von angehörten Beiträgen gespeichert wird, müssen Sie das\"},{\"key\":\"AudioPlayer/Queue/EmptyQueue/progressLink\",\"value\":\"Aufzeichnen der Hörposition aktivieren\"},{\"key\":\"AudioPlayer/error\",\"value\":\"Beim Abspielen ist ein Fehler aufgetreten.\"},{\"key\":\"AudioPlayer/error/reload\",\"value\":\"Bitte laden Sie die Seite neu.\"},{\"key\":\"Auth/CodeAuthorization/title\",\"value\":\"E-Mail-Adresse bestätigen\"},{\"key\":\"Auth/CodeAuthorization/description\",\"value\":\"Wir haben Ihnen {emphasis} geschickt. Tragen Sie diese im folgenden Feld ein.\"},{\"key\":\"Auth/CodeAuthorization/description/emphasis\",\"value\":\"Bestätigungsziffern per E-Mail\"},{\"key\":\"Auth/CodeAuthorization/description/emphasis/email\",\"value\":\"Bestätigungsziffern an Ihre  E-Mail-Adresse, {email},\"},{\"key\":\"Auth/CodeAuthorization/code/label\",\"value\":\"Bestätigungsziffern\"},{\"key\":\"Auth/CodeAuthorization/code/invalid\",\"value\":\"Bestätigungsziffern ungültig\"},{\"key\":\"Auth/CodeAuthorization/code/missing\",\"value\":\"Bestätigungsziffern fehlen\"},{\"key\":\"Auth/CodeAuthorization/code/tooShort\",\"value\":\"Bestätigungsziffern müssen 6-stellig sein\"},{\"key\":\"Auth/CodeAuthorization/button/label\",\"value\":\"Überprüfen\"},{\"key\":\"Auth/CodeAuthorization/help/cancelLink\",\"value\":\"Vertippt? E-Mail-Adresse erneut eingeben.\"},{\"key\":\"Auth/CodeAuthorization/help/lastResort\",\"value\":\"Reissen alle Stricke, verzagen Sie nicht: Schreiben Sie unserem Erste-Hilfe-Team unter kontakt@republik.ch.\"},{\"key\":\"Climatelab/Postcard/PostcardPreview/merci1\",\"value\":\"Danke für Ihre Postkarte. Sie wird uns helfen, zu verstehen, wie Sie in die Zukunft blicken. Darum wird es im Klimalabor immer wieder gehen: Wir wollen über die Zukunft nachdenken, den Blick für positive Entwicklungen schärfen und herausfinden, was es braucht, damit wir zuversichtlich und handlungsfähig bleiben.\"},{\"key\":\"Climatelab/Postcard/PostcardPreview/merci2\",\"value\":\"Wir sammeln alle Postkarten und machen sie demnächst in einer Online-Galerie öffentlich, damit Sie sehen können, wie andere Zeitreisende die Zukunft erleben.\"},{\"key\":\"Climatelab/Postcard/PostcardPreview/credit\",\"value\":\"Illustration: «2083» von {credit}\"},{\"key\":\"Climatelab/Postcard/PostcardDynamicComponent/noaccess/text\",\"value\":\"Die Zeitreise ist für alle, die beim Klimalabor der Republik mitmachen. Noch nicht dabei? {link}\"},{\"key\":\"Climatelab/Postcard/PostcardDynamicComponent/noaccess/linkText\",\"value\":\"Hier anmelden\"},{\"key\":\"Climatelab/Questionnaire/title\",\"value\":\"Können Sie einer 5-Jährigen die Klimakrise erklären? Und ihr dabei in die Augen schauen?\"},{\"key\":\"Climatelab/Questionnaire/description\",\"value\":\"Fragen über Fragen zur Klimakrise. Das sind die Antworten von {name}. Was sind Ihre?\"},{\"key\":\"Climatelab/Questionnaire/Person/title\",\"value\":\"15 Fragen zum Klima – die Antworten von {name}\"},{\"key\":\"Trial/Form/withAccess/button/label\",\"value\":\"Zum Magazin\"},{\"key\":\"Trial/Form/withAccess/setup/label\",\"value\":\"Konto einrichten\"},{\"key\":\"Trial/Form/withAccess/close/label\",\"value\":\"Schliessen\"},{\"key\":\"Trial/Form/email/error/empty\",\"value\":\"E-Mail-Adresse fehlt\"},{\"key\":\"Trial/Form/email/error/invalid\",\"value\":\"E-Mail-Adresse ungültig\"},{\"key\":\"Trial/Form/email/label\",\"value\":\"Ihre E-Mail-Adresse\"},{\"key\":\"Trial/Form/email/submit\",\"value\":\"E-Mail-Adresse abschicken\"},{\"key\":\"Trial/Form/error/title\",\"value\":\"Fehler\"},{\"key\":\"Trial/Form/series/waiting/title\",\"value\":\"Sie haben Post!\"},{\"key\":\"Trial/Form/series/completed/title\",\"value\":\"Herzlich willkommen!\"},{\"key\":\"Trial/Form/series/initial/title\",\"value\":\"Kostenlos Probe&shy;lesen für 21&nbsp;Tage.\"},{\"key\":\"Trial/Form/series/initial/beforeSignIn\",\"value\":\"Melden Sie sich an und lesen Sie die ganze Serie. \"},{\"key\":\"Trial/Form/series/initial/afterSignIn\",\"value\":\"Sie können sich in den kommenden Tagen ohne Einschränkung bei uns umsehen.\"},{\"key\":\"pages/cardGroups/description\",\"value\":\"Wischen Sie sich durch die engagierten, sich aufopfernden und machthungrigen Politikerinnen Ihres Kantons und treten Sie in einen Dialog mit ihnen.\"},{\"key\":\"pages/cardGroups/pageTitle\",\"value\":\"«Republik Wahltindär»\"},{\"key\":\"pages/cardGroups/title\",\"value\":\"«Republik Wahltindär»\"},{\"key\":\"pages/cardGroups/headline\",\"value\":\"Wahltindär\"},{\"key\":\"pages/cardGroups/lead\",\"value\":\"Über 4700 Kandidaturen für 246 Plätze im National- und im Ständerat. Wischen Sie sich durch die engagierten, sich aufopfernden und machthungrigen Politikerinnen Ihres Kantons und treten Sie in einen Dialog mit ihnen.\"},{\"key\":\"pages/cardGroups/lead/more\",\"value\":\"Mehr über das Projekt erfahren.\"},{\"key\":\"pages/cardGroups/comingsoon\",\"value\":\"In wenigen Tagen hier verfügbar.\"},{\"key\":\"pages/cardGroups/cardCount/other\",\"value\":\"{count} Kandidaturen\"},{\"key\":\"pages/cardGroups/latestComments\",\"value\":\"Neuste Statements\"},{\"key\":\"pages/cardGroup/title\",\"value\":\"🔥 Kanton {name} – Wahltindär\"},{\"key\":\"pages/cardGroup/description\",\"value\":\"Wischen Sie sich durch die engagierten, sich aufopfernden und machthungrigen {count} Politikerinnen des Kantons {name} und treten Sie in einen Dialog mit ihnen.\"},{\"key\":\"components/Card/Claim/404/title\",\"value\":\"Da passt etwas nicht.\"},{\"key\":\"components/Card/Claim/404/lead\",\"value\":\"In unserer Datenbank lässt sich nichts Passendes finden.\"},{\"key\":\"components/Card/Claim/404/help\",\"value\":\"Wahrscheinlich ist der von Ihnen verwendete Link bereits benutzt worden oder unvollständig. Falls das Problem wider alle Erwartungen weiterhin auftritt, helfen wir Ihnen unter <a href=\\\"mailto:wahlen19@republik.ch?subject=Nicht%20gefunden\\\">wahlen19@republik.ch</a> gerne und zügig weiter.\"},{\"key\":\"components/Frame/Meta/title\",\"value\":\"{title} – Republik\"},{\"key\":\"pages/cardSetup/title\",\"value\":\"Profil einrichten – Wahltindär\"},{\"key\":\"pages/cardSetup/description\",\"value\":\"Hier können Kandidatinnen und Kandidaten ihr Profil einrichten.\"},{\"key\":\"components/Card/Claim/headline\",\"value\":\"Profil einrichten\"},{\"key\":\"components/Card/Claim/lead\",\"value\":\"Wir laden Sie dazu ein, sich bei unserem Publikum zur Wahl zu empfehlen und an unserem Dialog teilzunehmen. Richten Sie dafür Ihr Profil ein und geben Sie ein Statement ab, um bei der Debatten dabei zu sein. <a href=\\\"/wahltindaer/meta\\\" target=\\\"_blank\\\">Mehr erfahren</a>.\"},{\"key\":\"components/Card/Claim/statement/label\",\"value\":\"Ihr Statement\"},{\"key\":\"components/Card/Claim/statement/question\",\"value\":\"Wofür stehen Sie? Warum sollte man Sie wählen? Sollte man Sie kumulieren? \"},{\"key\":\"components/Card/Claim/me/account\",\"value\":\"Angemeldet mit:\"},{\"key\":\"components/Card/Claim/me/assignNote\",\"value\":\"Beim Speichern wird diese Wahltindär-Karte Ihrem Konto zugeordnet. Um diese Karte einem anderen Konto zuzuordnen, melden Sie sich bitte ab.\"},{\"key\":\"components/Card/Claim/me/signOut\",\"value\":\"Abmelden\"},{\"key\":\"components/Card/Claim/submit\",\"value\":\"Speichern\"},{\"key\":\"components/Card/Update/title\",\"value\":\"Vielen Dank für Ihr Statement 🔥!\"},{\"key\":\"components/Card/Update/lead\",\"value\":\"Wir freuen uns, Sie an Bord des «Republik Wahltindär» begrüssen zu dürfen, und sind in besonderem Masse begeistert, dass Sie sich die Zeit dafür genommen haben. <a href=\\\"/wahltindaer/meta\\\" target=\\\"_blank\\\">Mehr erfahren</a>.\"},{\"key\":\"components/Card/Update/financing/title\",\"value\":\"Vielen Dank für Ihre Teilnahme!\"},{\"key\":\"components/Card/Update/financing/lead\",\"value\":\"Wir freuen uns und sind in besonderem Masse begeistert, dass Sie sich die Zeit dafür genommen haben.\"},{\"key\":\"components/Card/Update/submit\",\"value\":\"Aktualisieren\"},{\"key\":\"components/Card/Update/nothing/title\",\"value\":\"Diese Seite ist Kandidatinnen und Kandidaten der Parlamentswahlen vorbehalten.\"},{\"key\":\"components/Card/Update/nothing/lead\",\"value\":\"Ihrem Konto ist keine Wahltindär-Karte hinterlegt. Falls Sie sich für eine Kandidatur in den Nationalrat oder den Ständerat angemeldet haben, können Sie Ihre Wahltindär-Karte über den speziellen Link in der Begrüssungs-E-Mail übernehmen.\"},{\"key\":\"components/Card/Update/nothing/help\",\"value\":\"Bei Schwierigkeiten wenden Sie sich bitte an <a href=\\\"mailto:wahlen19@republik.ch?subject=Keine%20Karte\\\">wahlen19@republik.ch</a>\"},{\"key\":\"components/Card/Update/read\",\"value\":\"Zum Magazin\"},{\"key\":\"components/Card/Update/onboarding\",\"value\":\"Konto einrichten\"},{\"key\":\"components/Card/Group/noLocalStorage\",\"value\":\"Ihr Browser kann Ihre Wischer auf Ihrem Computer nicht abspeichern. Vermutlich weil Sie im Privatmodus unterwegs sind oder er sehr alt ist. Die können Ihre Daten aber auf der Übersichtsseite herunterladen. \"},{\"key\":\"components/Card/Group/end/done\",\"value\":\"Sie haben alle Kandidaturen des Kantons {groupName} durchgeswipt.\"},{\"key\":\"components/Card/Group/end/showList\",\"value\":\"Ihre Liste anzeigen\"},{\"key\":\"components/Card/Group/sequence\",\"value\":\"{swipes}/{total}\"},{\"key\":\"components/Card/Group/label\",\"value\":\"Kanton {groupName}\"},{\"key\":\"components/Card/Group/labelShort\",\"value\":\"{groupName}\"},{\"key\":\"components/Card/Group/noDiscussion\",\"value\":\"Diese Debatte ist zurzeit nicht verfügbar.\"},{\"key\":\"components/Card/Group/discussion/title\",\"value\":\"Wahldebatte {groupName}\"},{\"key\":\"components/Card/Group/discussion/lead\",\"value\":\"Hier können Sie den Kandidatinnen und Kandidaten Fragen stellen, ihnen entgegnen, beipflichten und nachhaken. Oder Statements, die Sie nicht überzeugen, gepflegt ignorieren. Falls Sie Feedback für die Republik haben: <a href=\\\"https://www.republik.ch/dialog?t=article&id=da157c69-e8a9-4be7-9ce0-b12e0f548d19\\\">Allgemeines zum «Wahltindär»</a>.\"},{\"key\":\"components/Card/Group/discussion/lead/closed\",\"value\":\"Die Wahldebatten sind vorbei. Falls Sie Feedback für die Republik haben: <a href=\\\"https://www.republik.ch/dialog?t=article&id=da157c69-e8a9-4be7-9ce0-b12e0f548d19\\\">Allgemeines zum «Wahltindär»</a>.\"},{\"key\":\"components/Card/Group/revert\",\"value\":\"zurücksetzen\"},{\"key\":\"components/Card/Group/ignore\",\"value\":\"ignorieren\"},{\"key\":\"components/Card/Group/follow\",\"value\":\"folgen\"},{\"key\":\"components/Card/Group/overview\",\"value\":\"Ihre Übersicht\"},{\"key\":\"components/Card/Group/switch\",\"value\":\"Kanton wechseln\"},{\"key\":\"components/Card/Footer/sources\",\"value\":\"Quelle: Smartvote, BFS et al.\"},{\"key\":\"components/Card/ignore\",\"value\":\"ignorieren\"},{\"key\":\"components/Card/follow\",\"value\":\"folgen\"},{\"key\":\"components/Card/yes\",\"value\":\"ja\"},{\"key\":\"components/Card/no\",\"value\":\"nein\"},{\"key\":\"components/Card/financing/title\",\"value\":\"Wahlkampffinanzierung\"},{\"key\":\"components/Card/financing/source\",\"value\":\"Quelle: Selbstdeklaration gegenüber der Republik; voraussichtliche Werte\"},{\"key\":\"components/Card/financing/1/title\",\"value\":\"Verfügbare Mittel:\"},{\"key\":\"components/Card/financing/2/title\",\"value\":\"Ausgaben:\"},{\"key\":\"components/Card/financing/3/title\",\"value\":\"Anmerkungen:\"},{\"key\":\"components/Card/financing/1a\",\"value\":\"Eigenmittel\"},{\"key\":\"components/Card/financing/1b\",\"value\":\"Privatpersonen\"},{\"key\":\"components/Card/financing/1b/other\",\"value\":\"{count} Privatpersonen\"},{\"key\":\"components/Card/financing/1b/1\",\"value\":\"Eine Privatperson\"},{\"key\":\"components/Card/financing/1bI/label\",\"value\":\"Anzahl Privatpersonen: \"},{\"key\":\"components/Card/financing/1c\",\"value\":\"Institutionelle Spender\"},{\"key\":\"components/Card/financing/1cI/label\",\"value\":\"Institutionelle Spender:\"},{\"key\":\"components/Card/financing/1cII\",\"value\":\"Indirekt\"},{\"key\":\"components/Card/financing/1d\",\"value\":\"Partei\"},{\"key\":\"components/Card/financing/2a\",\"value\":\"Plakate, Inserate und Flyer\"},{\"key\":\"components/Card/financing/2b\",\"value\":\"Google-Ads und Werbebanner\"},{\"key\":\"components/Card/financing/2c\",\"value\":\"Social Media\"},{\"key\":\"components/Card/financing/2d\",\"value\":\"Beitrag an Partei\"},{\"key\":\"components/Card/personalBudget\",\"value\":\"Wahlkampfbudget:\"},{\"key\":\"components/Card/na\",\"value\":\"keine Angaben\"},{\"key\":\"components/Card/unidentified\",\"value\":\"unbekannt\"},{\"key\":\"components/Card/Smartspider/title\",\"value\":\"Wertehaltungen\"},{\"key\":\"components/Card/Smartspider/legend\",\"value\":\"Von 0 = keine bis 100 = starke Zustimmung.\"},{\"key\":\"components/Card/sourceSmartvote\",\"value\":\"Quelle: Smartvote\"},{\"key\":\"components/Card/vestedInterests\",\"value\":\"Interessenbindungen:\"},{\"key\":\"components/Card/candidacy/sr_nr\",\"value\":\"Stände- und Nationalratskandidatur\"},{\"key\":\"components/Card/candidacy/sr\",\"value\":\"Ständeratskandidatur\"},{\"key\":\"components/Card/candidacy/nr\",\"value\":\"Nationalratskandidatur\"},{\"key\":\"components/Card/incumbent\",\"value\":\"bisher\"},{\"key\":\"components/Card/incumbent/nr\",\"value\":\"bisher im Nationalrat\"},{\"key\":\"components/Card/incumbent/new\",\"value\":\"neu\"},{\"key\":\"components/Card/listPlaces\",\"value\":\"Listenplatz:\"},{\"key\":\"components/Card/Group/title\",\"value\":\"Ihre Liste: {groupName}\"},{\"key\":\"components/Card/MyList/followTitle/other\",\"value\":\"Sie folgen {count} Personen:\"},{\"key\":\"components/Card/MyList/followTitle/1\",\"value\":\"Sie folgen einer Person:\"},{\"key\":\"components/Card/MyList/data/title\",\"value\":\"Ihre Daten\"},{\"key\":\"components/Card/MyList/data/isPersisted\",\"value\":\"Sind in Ihrem Browser abgespeichert. Falls Sie nicht im Privatmodus sind, bleiben sie auch gespeichert, und Sie können später zu dieser Seite zurückkehren und Ihre Liste wieder einsehen.\"},{\"key\":\"components/Card/MyList/data/notPersisted\",\"value\":\"Ihr Browser kann Ihre Wischer auf Ihrem Computer nicht abspeichern. Vermutlich deshalb, weil Sie im Privatmodus unterwegs sind oder weil Ihr Computer ein älteres Modell ist.\"},{\"key\":\"components/Card/MyList/data/download\",\"value\":\"Daten als CSV herunterladen.\"},{\"key\":\"components/Card/MyList/data/clear/confirm/suffix\",\"value\":\"In der Debatte können Sie den Politiker entfolgen.\"},{\"key\":\"components/Card/electionPlausibility/title\",\"value\":\"Rating des Listen­platzes: {text} {emoji}\"},{\"key\":\"components/Card/electionPlausibility/GOOD\",\"value\":\"gut\"},{\"key\":\"components/Card/electionPlausibility/DECENT\",\"value\":\"passabel\"},{\"key\":\"components/Card/electionPlausibility/WEAK\",\"value\":\"schlecht\"},{\"key\":\"components/Card/electionPlausibility/UNKNOWN\",\"value\":\"unbekannt\"},{\"key\":\"components/Card/electionPlausibility/GOOD/emoji\",\"value\":\"👍\"},{\"key\":\"components/Card/electionPlausibility/DECENT/emoji\",\"value\":\"👌\"},{\"key\":\"components/Card/electionPlausibility/WEAK/emoji\",\"value\":\"🤞\"},{\"key\":\"components/Card/electionPlausibility/UNKNOWN/emoji\",\"value\":\"🤞\"},{\"key\":\"components/Card/MyList/nothing\",\"value\":\"Sie haben in diesem Browser noch nicht gewischt.\"},{\"key\":\"components/Card/Group/tutorial/right\",\"value\":\"Indem Sie nach rechts wischen, folgen Sie dieser Person im Dialog. Wenn diese reden will, werden Sie benachrichtigt.\"},{\"key\":\"components/Card/Group/tutorial/left\",\"value\":\"Wischen Sie eine Profilkarte nach links, ignorieren Sie die Person. Übrigens: Sie können innerhalb einer Karte zwischen Porträt, Smartspider und Finanzen blättern. Drücken Sie dazu die Karte auf der linken oder der rechten Hälfte.\"},{\"key\":\"components/Card/Group/promo/trial\",\"value\":\"Möchten Sie die Republik 14 Tage lang Probe lesen und die Wahl­debatte live mit­ver­fol­gen?\"},{\"key\":\"components/Card/Group/promo/abo\",\"value\":\"Wie wärs mit einem Republik-Abo? Unser Magazin ist unabhängig und werbefrei. Unser einziger Kunde sind Sie – wir wollen Sie inspirieren, bereichern und überraschen.\"},{\"key\":\"components/Card/Details/source\",\"value\":\"Quellen und Methodik\"},{\"key\":\"components/Card/Details/links\",\"value\":\"Weiterführende Informationen\"},{\"key\":\"components/Card/Details/smartvote\",\"value\":\"Smartvote-Profil\"},{\"key\":\"components/Card/Details/smartvote/note\",\"value\":\"Unsere Hauptquelle. Übrigens: Der Verein hinter Smartvote sucht noch Spenden.\"},{\"key\":\"components/Card/Details/lobbywatch\",\"value\":\"Interessenbindungen auf lobbywatch.ch\"},{\"key\":\"components/Card/Details/lobbywatch/note\",\"value\":\"Interessenbindungen von diesem bisherigen Mitglied der Bundesversammlung.\"},{\"key\":\"components/Card/Group/preferences\",\"value\":\"Ihre Präferenzen\"},{\"key\":\"components/Card/Group/preferences/none\",\"value\":\"Präferenz festlegen\"},{\"key\":\"components/Card/Group/preferences/elected\",\"value\":\"gewählt\"},{\"key\":\"components/Card/Group/preferences/filter\",\"value\":\"mit {filters}\"},{\"key\":\"components/Card/Group/preferences/filter/portrait\",\"value\":\"Porträtbild\"},{\"key\":\"components/Card/Group/preferences/filter/smartspider\",\"value\":\"Smartspider\"},{\"key\":\"components/Card/Group/preferences/filter/statement\",\"value\":\"Statement\"},{\"key\":\"components/Card/Group/preferences/filter/financing\",\"value\":\"Finanzantworten\"},{\"key\":\"components/Card/Group/preferences/partySort\",\"value\":\"nach {party}-Wertehaltung\"},{\"key\":\"components/Card/Group/preferences/mySort\",\"value\":\"nach Ihrer Wertehaltung\"},{\"key\":\"components/Card/Preferences/filter\",\"value\":\"Nur:\"},{\"key\":\"components/Card/Preferences/filter/portrait\",\"value\":\"mit Porträtbild\"},{\"key\":\"components/Card/Preferences/filter/smartspider\",\"value\":\"mit Smartspider\"},{\"key\":\"components/Card/Preferences/filter/statement\",\"value\":\"mit Statement\"},{\"key\":\"components/Card/Preferences/filter/financing\",\"value\":\"mit Finanzantworten\"},{\"key\":\"components/Card/Preferences/mySmartspider\",\"value\":\"Ihre Wertehaltung:\"},{\"key\":\"components/Card/Preferences/mySmartspider/intro\",\"value\":\"Haben Sie den Smartvote-Fragebogen ausgefüllt? Dann können Sie hier Ihre Wertehaltungen übertragen zum Vergleichen und Sortieren. Falls nicht: {link}.\"},{\"key\":\"components/Card/Preferences/mySmartspider/intro/linkText\",\"value\":\"Jetzt ausfüllen und vergleichbare Werte erhalten\"},{\"key\":\"components/Card/Preferences/mySmartspider/intro/linkHref\",\"value\":\"https://www.smartvote.ch/de/group/2/election/19_ch_nr/matching/questionnaire/rapid/category/1\"},{\"key\":\"components/Card/Preferences/mySmartspider/sort\",\"value\":\"Profile mit geringster Distanz zu Ihnen zuerst\"},{\"key\":\"components/Card/Preferences/mySmartspider/reset\",\"value\":\"Smartspider zurücksetzen\"},{\"key\":\"components/Card/Preferences/mySmartspider/resetConfirm\",\"value\":\"Möchten Sie Ihre Smartspider-Werte entfernen?\"},{\"key\":\"components/Card/Group/end/doneFilterCount/0\",\"value\":\"Es gibt keine Kandidatur im Kanton {groupName}, die auf Ihre Präferenzen passt.\"},{\"key\":\"components/Card/Group/end/doneFilterCount/other\",\"value\":\"Sie haben alle auf Ihre Präferenzen passenden Kandidaturen im Kanton {groupName} durchgeswipt.\"},{\"key\":\"components/Card/Group/end/showPreferences\",\"value\":\"Präferenzen anpassen\"},{\"key\":\"components/Card/MyList/data/clear\",\"value\":\"Daten aus Ihrem Browser löschen.\"},{\"key\":\"components/Card/MyList/data/clear/confirm\",\"value\":\"Sind Sie sicher, dass Sie Ihre Daten löschen wollen? Sofern Sie angemeldet sind, folgen Sie den Personen, welche Sie nach rechts gewischt haben, weiterhin (schliesslich sollten Sie ein Auge auf die Politikerinnen haben). Sie können oben die Personen welchen Sie folgen einzeln entfolgen.\"},{\"key\":\"components/Card/MyList/ignoreTitle/other\",\"value\":\"Sie ignorieren {count} Personen:\"},{\"key\":\"components/Card/MyList/ignoreTitle/1\",\"value\":\"Sie ignorieren eine Person:\"},{\"key\":\"components/Card/MyList/trial\",\"value\":\"Möchten Sie die Republik 14 Tage lang Probe lesen und die Wahl­debatte live mit­ver­fol­gen?\"},{\"key\":\"components/Card/Preferences/medianSmartspiders\",\"value\":\"Nach Wertehaltung der Bundeshausparteien sortieren:\"},{\"key\":\"components/Card/Preferences/medianSmartspiders/explanation\",\"value\":\"Die Position der Partei entspricht dem nationalen Mittelwert ihrer Kandidierenden. Drücken Sie auf eine Grafik um Profile mit ähnlichen Werten zuerst zu sehen.\"},{\"key\":\"components/Card/Form/Financing/headline\",\"value\":\"Umfrage zur Wahlkampffinanzierung\"},{\"key\":\"components/Card/Form/Financing/section/1\",\"value\":\"Einnahmen\"},{\"key\":\"components/Card/Form/Financing/section/2\",\"value\":\"Ausgaben\"},{\"key\":\"components/Card/Form/Financing/section/3\",\"value\":\"Anderes\"},{\"key\":\"components/Card/Form/Financing/question/label\",\"value\":\"in CHF\"},{\"key\":\"components/Card/Form/Financing/question/1\",\"value\":\"Wie hoch sind voraussichtlich Ihre Gesamteinnahmen für den Wahlkampf 2019?\"},{\"key\":\"components/Card/Form/Financing/question/1a\",\"value\":\"Wie viel Geld investieren Sie persönlich in Ihren Wahlkampf?\"},{\"key\":\"components/Card/Form/Financing/question/1b\",\"value\":\"Wie hoch ist der Betrag, den Sie von Privatpersonen erhalten?\"},{\"key\":\"components/Card/Form/Financing/question/1bI\",\"value\":\"Wie viele Privatpersonen unterstützen Ihren Wahlkampf finanziell?\"},{\"key\":\"components/Card/Form/Financing/question/1bI/label\",\"value\":\"Anzahl Personen\"},{\"key\":\"components/Card/Form/Financing/question/1c\",\"value\":\"Wie hoch ist der Betrag, den Sie von institutionellen Spendern wie Unternehmen, Verbänden und Vereinen erhalten?\"},{\"key\":\"components/Card/Form/Financing/question/1cI\",\"value\":\"Bitte führen Sie Ihre institutionellen Spender auf.\"},{\"key\":\"components/Card/Form/Financing/question/1cI/label\",\"value\":\"Namen und Frankenbetrag\"},{\"key\":\"components/Card/Form/Financing/question/1cII\",\"value\":\"Falls institutionelle Spender direkt für Ihre Kandidatur werben, wie viel Geld investieren diese schätzungsweise?\"},{\"key\":\"components/Card/Form/Financing/question/1d\",\"value\":\"Erhalten Sie einen Betrag für Ihren persönlichen Wahlkampf von Ihrer Partei? Wie hoch ist dieser?\"},{\"key\":\"components/Card/Form/Financing/question/2\",\"value\":\"Wie hoch sind voraussichtlich Ihre Gesamtausgaben für den Wahlkampf 2019?\"},{\"key\":\"components/Card/Form/Financing/question/2a\",\"value\":\"Wie viel investieren Sie in klassische Werbemittel wie Plakate, Inserate und Flyer?\"},{\"key\":\"components/Card/Form/Financing/question/2b\",\"value\":\"Wie hoch sind Ihre Ausgaben für Online-Werbung wie Google-Ads und Werbebanner auf Webseiten?\"},{\"key\":\"components/Card/Form/Financing/question/2c\",\"value\":\"Wie viel geben Sie für Social Media wie Facebook und Twitter aus?\"},{\"key\":\"components/Card/Form/Financing/question/2d\",\"value\":\"Bezahlen Sie einen Beitrag an den Wahlkampf Ihrer Partei? Wie hoch ist dieser?\"},{\"key\":\"components/Card/Form/Financing/question/3\",\"value\":\"Was möchten Sie hinzufügen?\"},{\"key\":\"components/Card/Form/Financing/question/3/label\",\"value\":\"Anmerkungen\"},{\"key\":\"components/Card/Form/Financing/headline/fr_CH\",\"value\":\"Sondage sur le financement des campagnes électorales\"},{\"key\":\"components/Card/Form/Financing/section/1/fr_CH\",\"value\":\"Rentrées\"},{\"key\":\"components/Card/Form/Financing/section/2/fr_CH\",\"value\":\"Dépenses\"},{\"key\":\"components/Card/Form/Financing/section/3/fr_CH\",\"value\":\"Autres\"},{\"key\":\"components/Card/Form/Financing/question/label/fr_CH\",\"value\":\"en francs\"},{\"key\":\"components/Card/Form/Financing/question/1/fr_CH\",\"value\":\"À combien s’élèvent probablement vos rentrées totales pour la campagne électorale de 2019?\"},{\"key\":\"components/Card/Form/Financing/question/1a/fr_CH\",\"value\":\"Combien d’argent investissez-vous personnellement dans votre campagne électorale?\"},{\"key\":\"components/Card/Form/Financing/question/1b/fr_CH\",\"value\":\"Quel est le montant que vous recevez de personnes privées?\"},{\"key\":\"components/Card/Form/Financing/question/1bI/fr_CH\",\"value\":\"Combien de personnes privées soutiennent financièrement votre campagne électorale?\"},{\"key\":\"components/Card/Form/Financing/question/1bI/label/fr_CH\",\"value\":\"Nombre de personnes\"},{\"key\":\"components/Card/Form/Financing/question/1c/fr_CH\",\"value\":\"Quel est le montant que vous recevez de la part de donateurs institutionnels tels que des entreprises ou des associations?\"},{\"key\":\"components/Card/Form/Financing/question/1cI/fr_CH\",\"value\":\"Nous vous prions de bien vouloir citer vos donateurs institutionnels.\"},{\"key\":\"components/Card/Form/Financing/question/1cI/label/fr_CH\",\"value\":\"Noms et montant en francs\"},{\"key\":\"components/Card/Form/Financing/question/1cII/fr_CH\",\"value\":\"Si des donateurs institutionnels font directement de la publicité pour votre candidature, quel montant investissent-ils approximativement?\"},{\"key\":\"components/Card/Form/Financing/question/1d/fr_CH\",\"value\":\"Recevez-vous un montant pour votre campagne électorale personnelle de la part de votre parti? À combien s’élève ce montant?\"},{\"key\":\"components/Card/Form/Financing/question/2/fr_CH\",\"value\":\"À combien s’élèvent vraisemblablement vos dépenses totales pour la campagne électorale de 2019?\"},{\"key\":\"components/Card/Form/Financing/question/2a/fr_CH\",\"value\":\"Combien investissez-vous dans des supports publicitaires classiques tels que des affiches, des annonces et des flyers?\"},{\"key\":\"components/Card/Form/Financing/question/2b/fr_CH\",\"value\":\"À combien s’élèvent vos dépenses pour la publicité en ligne, comme les annonces Google et les bannières publicitaires sur des sites Web?\"},{\"key\":\"components/Card/Form/Financing/question/2c/fr_CH\",\"value\":\"Combien dépensez-vous pour les réseaux sociaux comme Facebook et Twitter?\"},{\"key\":\"components/Card/Form/Financing/question/2d/fr_CH\",\"value\":\"Versez-vous une contribution à la campagne électorale de votre parti? À combien s’élève cette contribution?\"},{\"key\":\"components/Card/Form/Financing/question/3/fr_CH\",\"value\":\"Que souhaiteriez-vous ajouter?\"},{\"key\":\"components/Card/Form/Financing/question/3/label/fr_CH\",\"value\":\"Annotations\"},{\"key\":\"components/Card/Form/Financing/headline/it_CH\",\"value\":\"Sondaggio sul finanziamento della campagna\"},{\"key\":\"components/Card/Form/Financing/section/1/it_CH\",\"value\":\"Entrate\"},{\"key\":\"components/Card/Form/Financing/section/2/it_CH\",\"value\":\"Spese\"},{\"key\":\"components/Card/Form/Financing/section/3/it_CH\",\"value\":\"Altri\"},{\"key\":\"components/Card/Form/Financing/question/label/it_CH\",\"value\":\"in CHF\"},{\"key\":\"components/Card/Form/Financing/question/1/it_CH\",\"value\":\"A quanto ammontano presumibilmente le Sue entrate complessive per la campagna elettorale 2019?\"},{\"key\":\"components/Card/Form/Financing/question/1a/it_CH\",\"value\":\"Quanto denaro investe personalmente nella Sua campagna elettorale?\"},{\"key\":\"components/Card/Form/Financing/question/1b/it_CH\",\"value\":\"A quanto ammontano le donazioni versate da privati?\"},{\"key\":\"components/Card/Form/Financing/question/1bI/it_CH\",\"value\":\"Quanti privati sostengono finanziariamente la Sua campagna elettorale?\"},{\"key\":\"components/Card/Form/Financing/question/1bI/label/it_CH\",\"value\":\"Numero di persone\"},{\"key\":\"components/Card/Form/Financing/question/1c/it_CH\",\"value\":\"A quanto ammonta l’importo che ottiene da donatori istituzionali quali imprese, associazioni o unioni? \"},{\"key\":\"components/Card/Form/Financing/question/1cI/it_CH\",\"value\":\"Voglia elencare i donatori istituzionali che La sostengono.\"},{\"key\":\"components/Card/Form/Financing/question/1cI/label/it_CH\",\"value\":\"Indicando il nome e l’importo versato in CHF\"},{\"key\":\"components/Card/Form/Financing/question/1cII/it_CH\",\"value\":\"Se i donatori istituzionali promuovono direttamente la Sua candidatura, secondo la Sua stima, quanto denaro investono?\"},{\"key\":\"components/Card/Form/Financing/question/1d/it_CH\",\"value\":\"Ottiene un contributo per la Sua campagna elettorale personale dal Suo partito? A quanto ammonta?\"},{\"key\":\"components/Card/Form/Financing/question/2/it_CH\",\"value\":\"A quanto ammontano presumibilmente le Sue spese complessive per la campagna elettorale 2019?\"},{\"key\":\"components/Card/Form/Financing/question/2a/it_CH\",\"value\":\"Quanto investe in strumenti pubblicitari classici quali manifesti, inserzioni o volantini?\"},{\"key\":\"components/Card/Form/Financing/question/2b/it_CH\",\"value\":\"A quanto ammontano le Sue spese per la pubblicità in rete, ad esempio per Google Ads o per banner pubblicitari sui siti web?\"},{\"key\":\"components/Card/Form/Financing/question/2c/it_CH\",\"value\":\"Quanto spende per i social media quali Facebook o Twitter?\"},{\"key\":\"components/Card/Form/Financing/question/2d/it_CH\",\"value\":\"Paga un contributo alla campagna elettorale del Suo partito? Se sì, a quanto ammonta?\"},{\"key\":\"components/Card/Form/Financing/question/3/it_CH\",\"value\":\"Desidera aggiungere altro?\"},{\"key\":\"components/Card/Form/Financing/question/3/label/it_CH\",\"value\":\"Annotazioni\"},{\"key\":\"pages/cardGroups/lead/pending\",\"value\":\"Bald finden Sie hier alle Gewählten. Diese Ansicht wird fortlaufend mit Daten des Bundesamts für Statistik aktualisiert.\"},{\"key\":\"pages/cardGroups/lead/complete\",\"value\":\"Der grosse Wahltag ist vorbei. Alle Nationalratssitze und die Mehrheit des Ständerats wurden besetzt. Wischen Sie sich durch das neue Parlament und folgen Sie einigen Ihrer neuen Freunde und Feinde.\"},{\"key\":\"pages/cardGroups/choose\",\"value\":\"Nach Kanton:\"},{\"key\":\"pages/cardGroups/elected\",\"value\":\"Alle Gewählten:\"},{\"key\":\"pages/cardGroups/elected/title\",\"value\":\"Neue Bundesversammlung\"},{\"key\":\"pages/cardGroups/elected/nationalCouncil\",\"value\":\"Nationalrat: \"},{\"key\":\"pages/cardGroups/elected/councilOfStates\",\"value\":\"Ständerat: \"},{\"key\":\"pages/cardGroups/elected/open\",\"value\":\"{nationalCouncil} {councilOfStates} sind noch offen.\"},{\"key\":\"pages/cardGroups/elected/open/nationalCouncil/0\",\"value\":\" \"},{\"key\":\"pages/cardGroups/elected/open/nationalCouncil/other\",\"value\":\"{count} Nationalratssitze und\"},{\"key\":\"pages/cardGroups/elected/open/nationalCouncil/1\",\"value\":\"Ein Nationalratssitz und\"},{\"key\":\"pages/cardGroups/elected/open/councilOfStates/other\",\"value\":\"{count} Ständeratssitze\"},{\"key\":\"pages/cardGroups/elected/open/councilOfStates/1\",\"value\":\"Ein Ständeratssitz\"},{\"key\":\"pages/cardGroups/openSuffix\",\"value\":\"offen\"},{\"key\":\"components/Card/elected\",\"value\":\"gewählt\"},{\"key\":\"components/Card/elected/silent\",\"value\":\"in stiller Wahl gewählt\"},{\"key\":\"components/Card/reelected/silent\",\"value\":\"in stiller Wahl wiedergewählt\"},{\"key\":\"components/Card/elected/appenzell-innerrhoden\",\"value\":\"an der Landsgemeinde gewählt\"},{\"key\":\"components/Card/reelected/appenzell-innerrhoden\",\"value\":\"an der Landsgemeinde wiedergewählt\"},{\"key\":\"components/Card/elected/sr\",\"value\":\"in den Ständerat gewählt\"},{\"key\":\"components/Card/elected/nr\",\"value\":\"in den Nationalrat gewählt\"},{\"key\":\"components/Card/reelected\",\"value\":\"wiedergewählt\"},{\"key\":\"components/Card/reelected/sr\",\"value\":\"in den Ständerat wiedergewählt\"},{\"key\":\"components/Card/reelected/nr\",\"value\":\"in den Nationalrat wiedergewählt\"},{\"key\":\"components/Card/votes/other\",\"value\":\"{formattedCount} Stimmen\"},{\"key\":\"components/Card/votes/1\",\"value\":\"Eine Stimme\"},{\"key\":\"components/Card/Preferences/filter/elected\",\"value\":\"gewählt\"},{\"key\":\"components/Card/Group/switch/special\",\"value\":\"Kanton wählen\"},{\"key\":\"pages/cardGroup/title/bundesversammlung\",\"value\":\"🔥 Die neue Bundesversammlung im Wahltindär\"},{\"key\":\"pages/cardGroup/description/bundesversammlung\",\"value\":\"Wischen Sie sich durch die neue Bundesversammlung und folgen Sie einigen Ihrer neuen Freunde und Feinde.\"},{\"key\":\"components/Card/Group/end/done/bundesversammlung\",\"value\":\"Sie haben die (aktuell gewählte) neue Bundesversammlung durchgeswipt.\"},{\"key\":\"components/Card/Group/end/doneFilterCount/bundesversammlung/0\",\"value\":\"Es gibt keine Person, die auf Ihre Präferenzen passt.\"},{\"key\":\"components/Card/Group/end/doneFilterCount/bundesversammlung/other\",\"value\":\"Sie haben alle auf Ihre Präferenzen Passenden durchgeswipt.\"},{\"key\":\"article/tryNote/thankYou\",\"value\":\"<b>Herzlich willkommen!</b> Sie können sich in den kommenden Tagen ohne Einschränkung bei uns umsehen.\"},{\"key\":\"account/newsletterSubscriptions/noMembership\",\"value\":\"Journalismus kostet. Deshalb erhalten Sie den 7-Uhr-Newsletter und den Wochenend-Newsletter erst wenn Sie eine aktive Mitgliedschaft oder ein aktives Abo haben.\"},{\"key\":\"section/feed/payNote\",\"value\":\"Sie brauchen eine Mitgliedschaft oder Abo, um die Beiträge zu lesen.\"},{\"key\":\"section/feed/payNote/sample\",\"value\":\"Sie brauchen eine Mitgliedschaft oder Abo, um alle Beiträge zu lesen.\"},{\"key\":\"account/newsletterSubscriptions/WEEKLY/description\",\"value\":\"Lektüre für das Wochenende samt Rückblick auf die Geschichten der vergangenen Woche.\"},{\"key\":\"account/newsletterSubscriptions/WEEKLY/label\",\"value\":\"Republik am Wochenende\"},{\"key\":\"account/newsletterSubscriptions/WEEKLY/frequency\",\"value\":\"Samstags um 5 Uhr\"},{\"key\":\"package/ABO/description\",\"value\":\"Es freut uns, dass Sie dabei sind! Mit Ihrem jährlichen Beitrag sind Sie Mitglied der Project R Genossenschaft. Und damit zu einem kleinen Teil Verlegerin oder Verleger der Republik. Sie erhalten ab sofort unser Magazin.\"},{\"key\":\"package/BENEFACTOR/description\",\"value\":\"Sie wollen nicht nur ein unabhängiges Magazin lesen, sondern Sie wollen sich auch energisch dafür einsetzen, dass dieses existiert. Mit Ihrer Gönner-Mitgliedschaft werden Sie automatisch Mitglied der Project R Genossenschaft. Und damit Verleger oder Verlegerin der Republik. Um uns für Ihre Unterstützung zu revanchieren, schicken wir Ihnen ein kleines Dankeschön zu.\"},{\"key\":\"package/PROLONG/description\",\"value\":\"Eine funktionierende Demokratie braucht funktionierende Medien. Und dafür braucht es nicht nur Journalistinnen und Journalisten, sondern auch Sie. Als Leserin. Als Bürger. Als Verlegerin, die bereit ist, langfristig auf unabhängigen Journalismus zu setzen.\"},{\"key\":\"package/PROLONG/ABO_GIVE_MONTHS/description\",\"value\":\"Eine funktionierende Demokratie braucht funktionierende Medien. Und dafür braucht es nicht nur Journalistinnen und Journalisten, sondern auch Sie. Als Leserin. Als Bürger. Als Verlegerin, die bereit ist, langfristig auf unabhängigen Journalismus zu setzen. Durch Ihren jährlichen Beitrag werden Sie Mitglied der Project R Genossenschaft.\"},{\"key\":\"Goodies/title\",\"value\":\"Noch etwas Handfestes?\"},{\"key\":\"Goodies/title/free\",\"value\":\"Gratis zum Kauf\"},{\"key\":\"Goodies/note/delivery\",\"value\":\"Versand nur in die Schweiz und Liechtenstein möglich\"},{\"key\":\"Goodie/dropdown/label\",\"value\":\"Anzahl\"},{\"key\":\"Goodie/label/FONDUE\",\"value\":\"Republik Fondue\"},{\"key\":\"Goodie/description/FONDUE\",\"value\":\"Eine von Hauskulinariker Michael Rüegg entworfene Mischung. Für 2 Personen. Versand am 26.01.22. Nur innerhalb der Schweiz möglich.\"},{\"key\":\"Goodie/label/NOTEBOOK\",\"value\":\"Republik-Notizbuch\"},{\"key\":\"Goodie/description/NOTEBOOK\",\"value\":\"Ein Moleskine-Notizbuch mit Republik-Gravierung. Lieferung innerhalb von 7 Werktagen.\"},{\"key\":\"Goodie/label/LIBRARYBOOK\",\"value\":\"Republik-Bibliothek Taschenbuch\"},{\"key\":\"Goodie/description/LIBRARYBOOK\",\"value\":\"Ein zufällig ausgewähltes Exemplar aus der neuen Republik-Bibliothek-Sonderedition.\"},{\"key\":\"Goodie/label/TOTEBAG\",\"value\":\"Republik-Tasche\"},{\"key\":\"Goodie/description/TOTEBAG\",\"value\":\"Mit Logo auf der Vorderseite und Manifest auf der Rückseite. Lieferung innerhalb von 7 Werktagen.\"},{\"key\":\"Goodie/label/MUG\",\"value\":\"Republik-Tasse\"},{\"key\":\"Goodie/description/MUG\",\"value\":\"Mit Logo und Claim «Ohne Journalismus keine Demokratie». Lieferung innerhalb von 10 Werktagen.\"},{\"key\":\"Goodie/label/MUG_CERAMIC\",\"value\":\"Republik-Tasse\"},{\"key\":\"Goodie/description/MUG_CERAMIC\",\"value\":\"Mit Logo und Claim «Ohne Journalismus keine Demokratie». Lieferung innerhalb von 10 Werktagen.\"},{\"key\":\"Goodie/label/LESHA\",\"value\":\"Buch «We Stay»\"},{\"key\":\"Goodie/description/LESHA\",\"value\":\"Lesha Berezovskiys Bildkolumne «Leben in Trümmern» als Buch. Lieferung innerhalb von 7 Werktagen.\"},{\"key\":\"Goodie/label/COOKIE\",\"value\":\"Republik-Guetsliform\"},{\"key\":\"Goodie/description/COOKIE\",\"value\":\"Buchstaben zum Naschen, limitiertes Sonderangebot. Versand bis 22.12., nur innerhalb der Schweiz möglich.\"},{\"key\":\"Goodie/label/TOTEBAG_BLACK\",\"value\":\"Republik-Tasche, schwarz\"},{\"key\":\"Goodie/description/TOTEBAG_BLACK\",\"value\":\"Mit Logo auf der Vorderseite und Manifest auf der Rückseite. Versand im April, nur in die Schweiz und nach Liechtenstein.\"},{\"key\":\"option/TABLEBOOK/label/other\",\"value\":\"Republik bei Stromausfall\"},{\"key\":\"option/MASK/label/other\",\"value\":\"Republik-Masken\"},{\"key\":\"option/MASK/label/1\",\"value\":\"Republik-Maske\"},{\"key\":\"option/FONDUE/label/other\",\"value\":\"Republik-Fondues\"},{\"key\":\"option/FONDUE/label/1\",\"value\":\"Republik-Fondue\"},{\"key\":\"option/MUG/label/other\",\"value\":\"Tassen\"},{\"key\":\"option/MUG/label/1\",\"value\":\"Tasse\"},{\"key\":\"option/MUG_CERAMIC/label/other\",\"value\":\"Tassen\"},{\"key\":\"option/MUG_CERAMIC/label/1\",\"value\":\"Tasse\"},{\"key\":\"option/LESHA/label/1\",\"value\":\"Buch «We Stay»\"},{\"key\":\"option/LESHA/label/other\",\"value\":\"Bücher «We Stay»\"},{\"key\":\"option/COOKIE/label/1\",\"value\":\"Republik-Guetsliform\"},{\"key\":\"option/COOKIE/label/other\",\"value\":\"Republik-Guetsliformen\"},{\"key\":\"package/customize/price/payMore/userPrice\",\"value\":\"Können Sie Ihr Investment erhöhen?\"},{\"key\":\"package/customize/price/payMore/ABO_GIVE_MONTHS\",\"value\":\"Möchten Sie Ihr Investment erhöhen?\"},{\"key\":\"package/customize/price/payMore\",\"value\":\"Möchten Sie vergünstigte Mitgliedschaften ermöglichen?\"},{\"key\":\"package/customize/price/payMore/1.5\",\"value\":\"Ich bin für Grosszügigkeit: {formattedCHF}\"},{\"key\":\"package/customize/price/payMore/thx\",\"value\":\"Danke!\"},{\"key\":\"prolongNecessary/before\",\"value\":\"Ihre Verlängerung steht an: {link}\"},{\"key\":\"prolongNecessary/before/linkText\",\"value\":\"Jetzt bezahlen\"},{\"key\":\"package/customize/price/payMore/2\",\"value\":\"Tollkühne {formattedCHF}\"},{\"key\":\"package/customize/price/payMore/thx/2\",\"value\":\"Herzlichen Dank!\"},{\"key\":\"package/customize/price/payRegular\",\"value\":\"Auf den regulären Betrag zurücksetzen\"},{\"key\":\"package/PROLONG/pageTitle/reactivate\",\"value\":\"Reaktivieren Sie Ihr Investment.\"},{\"key\":\"crowdfunding/status/time/label/SURVIVE\",\"value\":\" \"},{\"key\":\"crowdfunding/status/goal/SURVIVE/people\",\"value\":\"Mitglieder und Abonnenten am 31. März. Ziel: {count}.\"},{\"key\":\"crowdfunding/status/goal/SURVIVE/money\",\"value\":\"zusätzliche Mittel von Investorinnen und Mitgliedern. Ziel: {count}.\"},{\"key\":\"nav/cockpit\",\"value\":\"Cockpit\"},{\"key\":\"cockpit/ios\",\"value\":\"In der iOS-App können wir Ihnen aufgrund der Bestimmungen von Apple zurzeit leider keine Möglichkeiten zur Verwaltung der Mitgliedschaft oder zum Bezahlen anbieten.\"},{\"key\":\"cockpit/ios/cta\",\"value\":\"Komplizin werden\"},{\"key\":\"crowdfunding/status/support/other\",\"value\":\"{count} Komplizen\"},{\"key\":\"crowdfunding/status/support/1\",\"value\":\"{count} Komplize\"},{\"key\":\"crowdfunding/status/support/label\",\"value\":\"Verlegerinnen, die bereit sind, die Republik bekannter zu machen.\"},{\"key\":\"memberships/cancel/confirmation/cockpit\",\"value\":\"Mehr erfahren\"},{\"key\":\"crowdfunding/status/current/other\",\"value\":\"{count} Verlegerinnen\"},{\"key\":\"crowdfunding/status/current/1\",\"value\":\"{count} Verlegerin\"},{\"key\":\"crowdfunding/status/current/label\",\"value\":\"haben wir aktuell. Aber bis zum 31. März sind noch <strong>{openPeople}</strong> Erneuerungen fällig.\"},{\"key\":\"PodcastButtons/title/play\",\"value\":\"Anhören und abonnieren\"},{\"key\":\"PodcastButtons/title\",\"value\":\"Abonnieren\"},{\"key\":\"PodcastButtons/play\",\"value\":\"Abspielen\"},{\"key\":\"PodcastButtons/app\",\"value\":\"Podcast-App\"},{\"key\":\"PodcastButtons/rss\",\"value\":\"RSS-Feed\"},{\"key\":\"PodcastButtons/copy\",\"value\":\"URL kopieren\"},{\"key\":\"PodcastButtons/copy/success\",\"value\":\"URL kopiert!\"},{\"key\":\"PodcastButtons/copy/error\",\"value\":\"Kopieren fehlgeschlagen\"},{\"key\":\"PodcastButtons/spotify\",\"value\":\"Spotify\"},{\"key\":\"PodcastButtons/apple\",\"value\":\"Apple\"},{\"key\":\"PodcastButtons/google\",\"value\":\"Google\"},{\"key\":\"profile/tryNote/content\",\"value\":\"Um die Beiträge von {name} zu lesen, benötigen Sie eine Mitgliedschaft oder ein Monatsabonnement. Sie wollen uns erst kennenlernen? Dann lesen Sie die Republik jetzt unverbindlich und kostenlos 21 Tage Probe.\"},{\"key\":\"option/ABO/accessGranted/label/other\",\"value\":\"Wachstums-Mitgliedschaften\"},{\"key\":\"option/ABO/accessGranted/label/1\",\"value\":\"Wachstums-Mitgliedschaft\"},{\"key\":\"option/ABO_GIVE/ABO/label/other\",\"value\":\"Geschenk-Mitgliedschaften\"},{\"key\":\"option/ABO_GIVE/ABO/label/1\",\"value\":\"Geschenk-Mitgliedschaft\"},{\"key\":\"package/DONATE_POT/title\",\"value\":\"Wachstum spenden\"},{\"key\":\"package/ABO_GIVE/price\",\"value\":\"{formattedCHF}\"},{\"key\":\"package/ABO_GIVE/title\",\"value\":\"Mitgliedschaft als Geschenk\"},{\"key\":\"package/ABO_GIVE/description\",\"value\":\"Die Geschenkmitgliedschaft können Sie in Form eines digitalen oder physischen Gutscheins der beschenkten Person überreichen. Den Gutscheincode schicken wir Ihnen direkt per E-Mail zu.\"},{\"key\":\"package/customize/price/payMore/threemonth\",\"value\":\"Drei Monate {formattedCHF}\"},{\"key\":\"package/customize/price/payMore/halfayear\",\"value\":\"Ein halbes Jahr {formattedCHF}\"},{\"key\":\"package/customize/price/payMore/ayear\",\"value\":\"Ein ganzes Jahr {formattedCHF}\"},{\"key\":\"package/customize/price/payMore/thx/ayear\",\"value\":\"Herzlichen Dank!\"},{\"key\":\"Account/Access/Page/title\",\"value\":\"Die Republik teilen\\n\"},{\"key\":\"Account/Access/text\",\"value\":\"Ermöglichen Sie Ihren Freunden und Feinden {link}.\"},{\"key\":\"Account/Access/link\",\"value\":\"kostenloses Probelesen\"},{\"key\":\"Account/Access/Page/noCampaign\",\"value\":\"Um die Republik zu teilen, brauchen Sie ein aktives Abonnement.\"},{\"key\":\"Account/Access/Page/link\",\"value\":\"Republik abonnieren\"},{\"key\":\"pages/access/title\",\"value\":\"Teilen Sie die Republik\"},{\"key\":\"pages/access/description\",\"value\":\"Laden Sie Ihre Freunde und Feinde ein, die Republik zu testen. Ermöglicht den Empfangenden einen 21-tägigen Probezugriff zur Republik.\"},{\"key\":\"nav/crowdfunding2\",\"value\":\"Märzkampagne\"},{\"key\":\"cockpit19/beforeNote\",\"value\":\"Das ist das archivierte Cockpit aus dem Dezember 2019.\"},{\"key\":\"cockpit19/beforeNote/link\",\"value\":\"Zum aktuellen Cockpit.\"},{\"key\":\"crowdfunding/beforeNote\",\"value\":\"Das ist unser Crowdfunding aus dem Jahr 2017.\"},{\"key\":\"crowdfunding/beforeNote/link\",\"value\":\"Zum aktuellen Stand unseres Unternehmens.\"},{\"key\":\"crowdfunding2/beforeNote\",\"value\":\"Das ist unsere Märzkampagne aus dem Jahr 2020.\"},{\"key\":\"crowdfunding2/beforeNote/link\",\"value\":\"Zum aktuellen Stand unseres Unternehmens.\"},{\"key\":\"package/customize/changePackage\",\"value\":\"Zum gesamten Angebot\"},{\"key\":\"Account/Access/Campaigns/Grants/givingMemberships/title/1\",\"value\":\"Verschenkte Mitgliedschaft\"},{\"key\":\"Account/Access/Campaigns/Grants/givingMemberships/title/other\",\"value\":\"Verschenkte Mitgliedschaften\"},{\"key\":\"Account/Access/Campaigns/Form/givingMemberships/title/0\",\"value\":\"Mitgliedschaft verschenken\"},{\"key\":\"Account/Access/Campaigns/Form/givingMemberships/title/other\",\"value\":\"Eine weitere Mitgliedschaft verschenken\"},{\"key\":\"Account/Access/Campaigns/Form/givingMemberships/reset\",\"value\":\"Weitere Mitgliedschaft verschenken\"},{\"key\":\"Account/Access/Campaigns/Campaign/giftableMemberships/0\",\"value\":\"Aktuell sind keine Mitgliedschaften zu vergeben.\"},{\"key\":\"Account/Access/Campaigns/Campaign/giftableMemberships/1\",\"value\":\"Aktuell ist eine Mitgliedschaft zu vergeben.\"},{\"key\":\"Account/Access/Campaigns/Campaign/giftableMemberships/other\",\"value\":\"Aktuell sind {count} Mitgliedschaften zu vergeben.\"},{\"key\":\"Account/Access/Campaigns/Campaign/giftableMemberships/slots/0\",\"value\":\"Sie dürfen keine mehr verschenken.\"},{\"key\":\"Account/Access/Campaigns/Campaign/giftableMemberships/slots/1\",\"value\":\"Sie dürfen noch eine verschenken.\"},{\"key\":\"Account/Access/Campaigns/Campaign/giftableMemberships/slots/other\",\"value\":\"Sie dürfen noch {count} verschenken.\"},{\"key\":\"Account/Access/Campaigns/Grants/reducedCampaign/title/1\",\"value\":\"Verschickte Einladung\"},{\"key\":\"Account/Access/Campaigns/Grants/reducedCampaign/title/other\",\"value\":\"Verschickte Einladungen\"},{\"key\":\"Auth/NewsletterSignUp/submit\",\"value\":\"Abonnieren\"},{\"key\":\"Auth/NewsletterSignUp/success\",\"value\":\"Danke. Jetzt müssen Sie noch Ihre E-Mail-Adresse bestätigen.\"},{\"key\":\"Auth/NewsletterSignUp/settingTitle\",\"value\":\"Newsletter per E-Mail\"},{\"key\":\"Notifications/title/0\",\"value\":\"Benachrichtigungen\"},{\"key\":\"Notifications/title/1\",\"value\":\"Eine neue Benachrichtigung\"},{\"key\":\"Notifications/title/other\",\"value\":\"{count} neue Benachrichtigungen\"},{\"key\":\"Notifications/unpublished/label\",\"value\":\"Beitrag nicht mehr verfügbar\"},{\"key\":\"Notifications/empty/title\",\"value\":\"Noch keine Benachrichtigungen\"},{\"key\":\"Notifications/empty/paragraph\",\"value\":\"Sie haben noch keine Benachrichtigungen. In <a href=\\\"/konto/benachrichtigungen\\\">Ihren Einstellungen</a> finden Sie Rubriken, die Sie abonnieren können. Und Benachrichtigungen aus den Debatten erscheinen auch hier, sobald Sie im <a href=\\\"/dialog\\\">Dialog</a> eine neue Antwort bekommen.\"},{\"key\":\"Notifications/settings\",\"value\":\"Ihre Einstellungen\"},{\"key\":\"Notifications/markAsRead\",\"value\":\"Alle als gelesen markieren\"},{\"key\":\"Notifications/refresh/1\",\"value\":\"Sie haben eine neue Benachrichtigung bekommen.\"},{\"key\":\"Notifications/refresh/other\",\"value\":\"Sie haben {count} neue Benachrichtigungen bekommen.\"},{\"key\":\"Notifications/refresh/link\",\"value\":\"Seite neu laden?\"},{\"key\":\"Notifications/settings/authors\",\"value\":\"Gefolgte Profile\"},{\"key\":\"Notifications/settings/back\",\"value\":\"Zu Ihren Benachrichtigungen\"},{\"key\":\"Notifications/settings/title\",\"value\":\"Benachrichtigungs-Einstellungen\"},{\"key\":\"Notifications/settings/formats\",\"value\":\"Gefolgte Rubriken\"},{\"key\":\"Notifications/settings/formats/show\",\"value\":\"Alle anzeigen\"},{\"key\":\"Notifications/settings/formats/hide\",\"value\":\"Weniger anzeigen\"},{\"key\":\"Notifications/settings/formats/summary/0\",\"value\":\"Sie folgen noch keinen Rubriken.\"},{\"key\":\"Notifications/settings/formats/summary/1\",\"value\":\"Sie folgen einer Rubrik:\"},{\"key\":\"Notifications/settings/formats/summary/other\",\"value\":\"Sie folgen {count} Rubriken:\"},{\"key\":\"Notifications/settings/discussion\",\"value\":\"Dialog-Benachrichtigungen\"},{\"key\":\"Notifications/settings/newsletter\",\"value\":\"Können Sie in {link} abonnieren.\"},{\"key\":\"Notifications/settings/newsletter/link\",\"value\":\"Ihrem Konto\"},{\"key\":\"account/notificationChannels/intro\",\"value\":\"Ich möchte Benachrichtigungen zu neuen Beiträgen im Magazin und im Dialog auf folgendem Weg erhalten:\"},{\"key\":\"Onboarding/Sections/Subscriptions/heading\",\"value\":\"Benachrichtigung\"},{\"key\":\"Onboarding/Sections/Subscriptions/preamble\",\"value\":\"Sie können Rubriken abonnieren. Sobald Sie die App installiert haben, bekommen Sie Benachrichtigungen über neue Beiträge direkt auf Ihr Telefon. Sie können auch die Newsletter als Benachrichtigung abonnieren.\"},{\"key\":\"Onboarding/Sections/Subscriptions/hint\",\"value\":\"Die Liste {link} finden Sie jederzeit, indem Sie oben links auf Ihr Profilbild oder Ihre Initialen drücken. Dort können Sie auch diese Einstellungen anpassen.\"},{\"key\":\"Onboarding/Sections/Subscriptions/hint/link\",\"value\":\"Ihrer Benachrichtigungen\"},{\"key\":\"Onboarding/Sections/Newsletter/heading\",\"value\":\"Newsletter per E-Mail\"},{\"key\":\"account/newsletterSubscriptions/title\",\"value\":\"E-Mail-Newsletter abonnieren\"},{\"key\":\"SubscribeCallout/Comment\",\"value\":\"Im Dialog\"},{\"key\":\"SubscribeCallout/Document\",\"value\":\"Im Magazin\"},{\"key\":\"SubscribeCallout/ReadAloud\",\"value\":\"Benachrichtigung, sobald vorgelesen\"},{\"key\":\"SubscribeCallout/settingsLink\",\"value\":\"Allgemeine Einstellungen\"},{\"key\":\"SubscribeCallout/onlyYourself\",\"value\":\"Andere können Ihnen hier folgen.\"},{\"key\":\"SubscribeMenu/title\",\"value\":\"Folgen\"},{\"key\":\"SubscribeDocument/title\",\"value\":\"Rubrik abonnieren\"},{\"key\":\"SubscribeDebate/title\",\"value\":\"Beiträge zu {debate} abonnieren\"},{\"key\":\"SubscribeDebate/option/MY_CHILDREN/label\",\"value\":\"Antworten\"},{\"key\":\"SubscribeDebate/option/ALL/label\",\"value\":\"Alle\"},{\"key\":\"SubscribeDebate/option/NONE/label\",\"value\":\"Keine\"},{\"key\":\"feuilleton/deprecatedPage\",\"value\":\"Diese Seite wird nicht mehr aktualisiert. Sie finden die aktuellen Kulturbeiträge im <a href=\\\"/\\\">Magazin</a> und über die <a href=\\\"/rubriken\\\">Rubriken</a>.\"},{\"key\":\"FeatureCommentOverlay/title\",\"value\":\"hervorheben\"},{\"key\":\"FeatureCommentOverlay/DEFAULT/add\",\"value\":\"Front\"},{\"key\":\"FeatureCommentOverlay/MARKETING/add\",\"value\":\"Marketingseite\"},{\"key\":\"FeatureCommentOverlay/text/label\",\"value\":\"Hervorgehobenes Zitat\"},{\"key\":\"FeatureCommentOverlay/submit\",\"value\":\"Publizieren\"},{\"key\":\"FeatureCommentOverlay/warning\",\"value\":\"Dieses Beitrag ist nicht hervorgehoben.\"},{\"key\":\"FeatureCommentOverlay/remove\",\"value\":\"Zurückziehen\"},{\"key\":\"FeatureCommentOverlay/front/preview\",\"value\":\"Front Vorschau\"},{\"key\":\"FeatureCommentOverlay/marketing/preview\",\"value\":\"Marketingseite Vorschau\"},{\"key\":\"crowdfunding/status/lastSeen/other\",\"value\":\"{count} monatlich aktiv\"},{\"key\":\"crowdfunding/status/lastSeen/label\",\"value\":\"Verlegerinnen, die uns innerhalb der letzten 30 Tage besucht haben\"},{\"key\":\"crowdfunding/status/goal/PERMANENT/memberships\",\"value\":\"Mitgliedschaften und Abos.\"},{\"key\":\"Trial/Form/button\",\"value\":\"Anmelden\"},{\"key\":\"Trial/Form/button/signedIn\",\"value\":\"Aktivieren\"},{\"key\":\"components/outdatedAppVersion/text\",\"value\":\"Sie nutzen eine veraltete Version der App. Aktualisieren Sie Ihre App, um von den neusten Funktionalitäten zu profitieren.\"},{\"key\":\"components/outdatedAppVersion/ios/primaryAction\",\"value\":\"Zum App Store\"},{\"key\":\"components/outdatedAppVersion/android/primaryAction\",\"value\":\"Zum Google Play Store\"},{\"key\":\"components/outdatedAppVersion/android/secondaryAction\",\"value\":\"APK direkt herunterladen\"},{\"key\":\"articleRecommendations/heading\",\"value\":\"Von der Redaktion für Sie empfohlen:\"},{\"key\":\"darkmode/switch/label\",\"value\":\"Nachtmodus: {iconLabel}\"},{\"key\":\"darkmode/switch/on\",\"value\":\"Ein\"},{\"key\":\"darkmode/switch/off\",\"value\":\"Aus\"},{\"key\":\"darkmode/switch/auto\",\"value\":\"Automatisch\"},{\"key\":\"darkmode/switch/notSupported\",\"value\":\"Der Nachtmodus wird in Ihrem Browser nicht unterstützt.\"},{\"key\":\"darkmode/switch/notAvailable\",\"value\":\"Der Nachtmodus ist auf dieser Seite nicht verfügbar.\"},{\"key\":\"AppSignInOverlay/title\",\"value\":\"Zugriff bestätigen\"},{\"key\":\"Trial/Form/climate/button/signedIn\",\"value\":\"Ich bin dabei!\"},{\"key\":\"Trial/Form/climate/button\",\"value\":\"Ich bin dabei!\"},{\"key\":\"Climate/Trial/Heading/CampaignMember\",\"value\":\"Willkommen zurück\"},{\"key\":\"Climate/Trial/Action/CampaignMember\",\"value\":\"Zum Klimalabor\"},{\"key\":\"Climate/Trial/Heading/NonCampaignMember\",\"value\":\"Für den Newsletter anmelden\"},{\"key\":\"Climate/Logo/altText\",\"value\":\"Das Klimalabor der Republik\"},{\"key\":\"ClimateLandingPage/seo/title\",\"value\":\"Klimalabor der Republik — machen Sie mit!\"},{\"key\":\"ClimateLandingPage/seo/description\",\"value\":\"Die Klimakrise ist hier. Die Lage ist ernst. Was tun? Das Klimalabor der Republik ist ein Ort für Austausch und Experimente. Melden Sie sich jetzt an.\"},{\"key\":\"ClimateLandingPage/content/heading1\",\"value\":\"Die Klimakrise ist{nbsp}hier.{br}Die Lage ist ernst.{br}Was{nbsp}tun?\"},{\"key\":\"ClimateLandingPage/content/paragraph1\",\"value\":\"Unser Anspruch: Journalismus, der Sie in der Klimakrise wirklich weiterbringt.\"},{\"key\":\"ClimateLandingPage/content/paragraph2\",\"value\":\"Darum haben wir das Klimalabor gestartet. Einen Ort für Austausch und Experimente. Um gemeinsam mit Ihnen herauszufinden, mit welchem Angebot wir künftig der Klima­krise und Ihren Bedürfnissen gerecht werden können.\"},{\"key\":\"ClimateLandingPage/content/paragraph3\",\"value\":\"Wir freuen uns darauf, Ihnen bald mehr zu erzählen. Und Sie in der Zwischenzeit mit Lesenswertem zur Klimakrise zu versorgen.\"},{\"key\":\"ClimateLandingPage/content/counterText\",\"value\":\"Menschen machen schon mit im Klimalabor.\"},{\"key\":\"ClimateLandingPage/content/byRepublikText\",\"value\":\"Das Klimalabor ist ein Projekt der Republik. Die Republik ist ein digitales Magazin für Politik, Wirtschaft, Gesellschaft und Kultur. Finanziert von seinen Leserinnen und Lesern.\"},{\"key\":\"ClimateLandingPage/content/questionsText\",\"value\":\"Fragen, Anregungen? klimalabor@republik.ch\"},{\"key\":\"ClimateTeaser/content/text1\",\"value\":\"Die Klimakrise ist{nbsp}hier.{br}Die Lage ist ernst.{br}Was{nbsp}tun?\"},{\"key\":\"ClimateTeaser/content/text2\",\"value\":\"Das Klimalabor der Republik ist ein Ort für Austausch und Experimente. Gemeinsam wollen wir herausfinden: Wie bringt uns Journalismus in der Klimakrise wirklich weiter?\"},{\"key\":\"ClimateTeaser/content/buttonAction\",\"value\":\"Mehr erfahren\"},{\"key\":\"ClimateInlineTeaser/content/title\",\"value\":\"Das Klimalabor der Republik\"},{\"key\":\"ClimateInlineTeaser/NonMember/content/text\",\"value\":\"Die Klimakrise ist hier. Die Lage ist ernst. Was tun? Das Klimalabor ist unser Ort für Austausch und Experimente.\"},{\"key\":\"ClimateInlineTeaser/NonMember/content/link\",\"value\":\"Mehr erfahren\"},{\"key\":\"ClimateInlineTeaser/Member/content/text\",\"value\":\"Die Klimakrise ist hier. Die Lage ist ernst. Was tun? Das Klimalabor ist unser Ort für Austausch und Experimente.\"},{\"key\":\"ClimateInlineTeaser/Member/content/link\",\"value\":\"Mehr erfahren\"},{\"key\":\"CallToActions/customComponents/FutureCampaignBanner/headline\",\"value\":\"Dank {sender} Verlegerinnen ist die Republik um {receiver} Stimmen reicher geworden.\"},{\"key\":\"CallToActions/customComponents/FutureCampaignBanner/button/other\",\"value\":\"Noch {daysLeft} Tage Verstärkung holen und Gratismonate sichern\"},{\"key\":\"CallToActions/customComponents/FutureCampaignBanner/button/1\",\"value\":\"Noch heute Verstärkung holen und Gratismonate sichern\"},{\"key\":\"CallToActions/customComponents/FutureCampaignBanner/button/0\",\"value\":\"Noch heute Verstärkung holen und Gratismonate sichern\"},{\"key\":\"magazineSubscription/title/YEARLY_SUBSCRIPTION\",\"value\":\"Jahresmitgliedschaft\"},{\"key\":\"magazineSubscription/title/BENEFACTOR_SUBSCRIPTION\",\"value\":\"Gönner-Mitgliedschaft\"},{\"key\":\"magazineSubscription/title/MONTHLY_SUBSCRIPTION\",\"value\":\"Monats-Abo\"},{\"key\":\"magazineSubscription/title/canceled\",\"value\":\"(gekündigt)\"},{\"key\":\"magazineSubscription/description\",\"value\":\"Erneuert sich am {currentPeriodEnd} für CHF {renewsAtPrice}\"},{\"key\":\"magazineSubscription/paymentMethod\",\"value\":\"Zahlungsart: {paymentMethod}\"},{\"key\":\"magazineSubscription/paymentMethod/change\",\"value\":\"Zahlungsart ändern\"},{\"key\":\"magazineSubscription/noActiveSubscription\",\"value\":\"Sie haben kein gültiges Abonnement\"},{\"key\":\"magazineSubscription/canceled\",\"value\":\"Wurde am {canceledAt} gekündigt und läuft am {cancelAt} aus.\"},{\"key\":\"magazineSubscription/cancel/YEARLY_SUBSCRIPTION\",\"value\":\"Jahresmitgliedschaft kündigen\"},{\"key\":\"magazineSubscription/cancel/BENEFACTOR_SUBSCRIPTION\",\"value\":\"Gönner-Mitgliedschaft kündigen\"},{\"key\":\"magazineSubscription/cancel/MONTHLY_SUBSCRIPTION\",\"value\":\"Monats-Abo kündigen\"},{\"key\":\"magazineSubscriptionUpgrade/title\",\"value\":\"Wechsel von {from} auf {to}\"},{\"key\":\"magazineSubscriptionUpgrade/description/YEARLY_SUBSCRIPTION\",\"value\":\"Wechselt am {startAt} zu einer Jahresmitgliedschaft für CHF {amount}.\"},{\"key\":\"magazineSubscriptionUpgrade/description/BENEFACTOR_SUBSCRIPTION\",\"value\":\"Wechselt am {startAt} zu einer Gönner-Mitgliedschaft für CHF {amount}.\"},{\"key\":\"magazineSubscriptionUpgrade/description/MONTHLY_SUBSCRIPTION\",\"value\":\"Wechselt am {startAt} zu einem Monats-Abo für CHF {amount}.\"},{\"key\":\"magazineSubscriptionUpgrade/cancel\",\"value\":\"Wechsel rückgängig machen\"},{\"key\":\"magazineSubscription/donation/update\",\"value\":\"Ändern\"},{\"key\":\"magazineSubscription/donation/choose\",\"value\":\"Beitrag erhöhen\"},{\"key\":\"magazineSubscription/donation/chooseCustom\",\"value\":\"Wählen\"},{\"key\":\"magazineSubscription/donation/remove\",\"value\":\"Ich möchte meinen Beitrag nicht mehr erhöhen\"},{\"key\":\"magazineSubscription/donation/note\",\"value\":\"Wählen Sie einen Betrag, um den Sie ihren Beitrag erhöhen möchten. Der angepasste Beitrag wird erst fällig, wenn sich Ihre Mitgliedschaft erneuert. Sie können ihn jederzeit anpassen oder zurücksetzen.\"},{\"key\":\"magazineSubscription/donation/wannaGiveMore\",\"value\":\"Die Republik ist Ihnen mehr wert?\"},{\"key\":\"magazineSubscription/donation/add\",\"value\":\"Erhöhen Sie Ihren Beitrag\"},{\"key\":\"magazineSubscription/donation/label\",\"value\":\"Beinhaltet einen freiwilligen Beitrag von CHF {amount}.\"},{\"key\":\"magazineSubscription/reactivate/YEARLY_SUBSCRIPTION\",\"value\":\"Mitgliedschaft reaktivieren\"},{\"key\":\"magazineSubscription/reactivate/BENEFACTOR_SUBSCRIPTION\",\"value\":\"Mitgliedschaft reaktivieren\"},{\"key\":\"magazineSubscription/reactivate/MONTHLY_SUBSCRIPTION\",\"value\":\"Abo reaktivieren\"},{\"key\":\"magazineSubscription/shoplink/MONTHLY\",\"value\":\"Monats-Abo\"},{\"key\":\"magazineSubscription/shoplink/YEARLY\",\"value\":\"Jahresmitgliedschaft\"},{\"key\":\"auth/login/email/info\",\"value\":\"Geben Sie Ihre E-Mail-Adresse ein, um sich anzumelden.\"},{\"key\":\"auth/login/email/placeholder\",\"value\":\"E-Mail-Adresse\"},{\"key\":\"auth/login/email/missing\",\"value\":\"Bitte geben Sie Ihre E-Mail-Adresse ein.\"},{\"key\":\"auth/login/email/reset\",\"value\":\"Nicht korrekt?\"},{\"key\":\"auth/login/email/submit\",\"value\":\"Anmelden\"},{\"key\":\"auth/login/code/placeholder\",\"value\":\"Zugangscode\"},{\"key\":\"auth/login/code/title\",\"value\":\"Wir haben Ihnen einen Zugangscode geschickt\"},{\"key\":\"auth/login/code/description\",\"value\":\"Geben Sie den 6-stelligen Code ein, den Sie via {email} erhalten haben.\"},{\"key\":\"auth/login/code/pending\",\"value\":\"Wir überprüfen Ihren Code…\"},{\"key\":\"auth/login/code/help\",\"value\":\"Sie können Ihren Code nicht finden? Überprüfen Sie Ihren Spam-Ordner oder {changeEmail}.\"},{\"key\":\"auth/login/code/help/changeEmail\",\"value\":\"ändern Sie Ihre E-Mail-Adresse\"},{\"key\":\"auth/login/tos\",\"value\":\"Mit der Anmeldung akzeptieren Sie die {link} und sind einverstanden E-Mails zu Republik-Angeboten zu erhalten.\"},{\"key\":\"auth/trial/request\",\"value\":\"Weiterlesen\"},{\"key\":\"regwall/login\",\"value\":\"Haben Sie ein Abonnement? {link}\"},{\"key\":\"regwall/login/link\",\"value\":\"Anmelden\"},{\"key\":\"regwall/header/title\",\"value\":\"Weiterlesen, ohne zu bezahlen\"},{\"key\":\"regwall/header/description\",\"value\":\"<b>Werden Sie unser Gast:</b> Eine Woche lang gratis alle Republik-Beiträge lesen, keine automatische Verlängerung.\"},{\"key\":\"regwall/cta\",\"value\":\"Als Gast anmelden und weiterlesen\"},{\"key\":\"regwall/whyRegister/title\",\"value\":\"Warum eine E-Mail-Adresse?\"},{\"key\":\"regwall/whyRegister/expanded\",\"value\":\"<p>Damit wir Ihnen zeigen können, wie wir arbeiten und warum es sich lohnt, unseren Journalismus zu unterstützen. Über Ihre E-Mail-Adresse können wir direkt mit Ihnen in Kontakt treten, ohne dass externe Suchmaschinen oder Social-Media-Plattformen zwischengeschaltet sind. <b>Wir geben Ihre E-Mail-Adresse niemals ausserhalb der Republik weiter</b>.</p><p>Wenn Sie keine Nachrichten mehr von der Republik erhalten möchten, können Sie sich <b>jederzeit abmelden</b>.</p>\"},{\"key\":\"regwall/offers/description\",\"value\":\"<b>Für Grosszügige und Unerschrockene:</b>\"},{\"key\":\"regwall/offers/cta\",\"value\":\"Abo ab CHF 22.– / Monat\"},{\"key\":\"regwall/offers/cancellable\",\"value\":\"Jederzeit kündbar\"},{\"key\":\"paywall/offers/caption\",\"value\":\"Einstiegsangebot\"},{\"key\":\"paywall/a/offers/title/1\",\"value\":\"Ihre kostenlose Gastwoche ist zu Ende.\"},{\"key\":\"paywall/a/offers/title/2\",\"value\":\"Doch unsere gemeinsame Reise muss hier nicht enden.\"},{\"key\":\"paywall/b/offers/title/1\",\"value\":\"Wie schön, Sie sind zurück!\"},{\"key\":\"paywall/b/offers/title/2\",\"value\":\"Wenn Sie schon da sind, dann bleiben Sie doch gleich?\"},{\"key\":\"paywall/offers/yearly/duration\",\"value\":\"erstes Jahr\"},{\"key\":\"paywall/offers/yearly/description\",\"value\":\"Danach 240.- jährlich. Jederzeit kündbar.\"},{\"key\":\"paywall/offers/monthly/duration\",\"value\":\"erster Monat\"},{\"key\":\"paywall/offers/monthly/description\",\"value\":\"Danach 22.- monatlich. Jederzeit kündbar.\"},{\"key\":\"paywall/offers/cta\",\"value\":\"Jetzt abonnieren\"},{\"key\":\"paywall/offers/survey\",\"value\":\"Nein Danke, weil…\"},{\"key\":\"paywall/offers/all\",\"value\":\"Weitere Angebote anzeigen\"},{\"key\":\"paywall/survey/hint\",\"value\":\"Wählen Sie aus, was am ehesten zutrifft.\"},{\"key\":\"paywall/survey/all\",\"value\":\"Weitere Angebote anzeigen\"},{\"key\":\"paywall/survey/thanks/title\",\"value\":\"Vielen Dank für Ihr Feedback, wir hoffen, Sie bald wiederzusehen! 👋\"},{\"key\":\"paywall/survey/thanks/description\",\"value\":\"PS: Wussten Sie, dass Sie unser wöchentliches Nachrichtenbriefing auch ohne Abo als Newsletter erhalten können?\"},{\"key\":\"paywall/survey/thanks/link\",\"value\":\"Das interessiert mich\"},{\"key\":\"paynotes/dialog/title\",\"value\":\"Willkommen im Dialog\"},{\"key\":\"paynotes/dialog/description\",\"value\":\"Als Gast sehen Sie, was zu reden gibt. Mit einem Abo nehmen Sie direkt am Gespräch mit Autorinnen und anderen Lesern teil.\"},{\"key\":\"paynotes/dialog/cta\",\"value\":\"Abonnieren und mitreden\"},{\"key\":\"paynotes/native/caption\",\"value\":\"Unterstützen Sie unabhängigen Journalismus.\"},{\"key\":\"paynotes/native/cta\",\"value\":\"Alle Angebote auf {link}\"},{\"key\":\"paynotes/ios/text\",\"value\":\"Alle Angebote auf shop.republik.ch\"},{\"key\":\"paynotes/android/text\",\"value\":\"Alle Angebote finden Sie auf der Republik-Webseite.\"},{\"key\":\"paynotes/welcomeBanner\",\"value\":\"Ab sofort läuft Ihre siebentägige Gastwoche bei der Republik: Herzlich willkommen!\"},{\"key\":\"paynotes/account/title\",\"value\":\"Willkommen bei der Republik!\"},{\"key\":\"paynotes/account/description\",\"value\":\"<b>Bis zum {maxEndAt} sind Sie unser Gast und haben kostenlosen Zugang zum gesamten Magazin.</b><br/>Sie wollen länger bleiben? Dann haben wir ein paar Vorschläge für Sie.\"},{\"key\":\"paynotes/account/cta\",\"value\":\"Alle Angebote anzeigen\"},{\"key\":\"nextReads/curatedFeed/title\",\"value\":\"Von der Redaktion empfohlen\"},{\"key\":\"nextReads/mostReadFeed/title\",\"value\":\"Was andere lesen\"},{\"key\":\"nextReads/mostReadFeed/subtitle\",\"value\":\"Die meistbeachteten Beiträge der vergangenen Tage\"},{\"key\":\"nextReads/mostCommentedFeed/title\",\"value\":\"Verpasst?\"},{\"key\":\"nextReads/mostCommentedFeed/subtitle\",\"value\":\"Was in den letzten Wochen zu reden gab\"},{\"key\":\"nextReads/bookmarkedFeed/title\",\"value\":\"Gemerkte Beiträge\"},{\"key\":\"nextReads/bookmarkedFeed/subtitle\",\"value\":\"Ist jetzt ein guter Zeitpunkt?\"},{\"key\":\"nextReads/bookmarkedFeed/readMore\",\"value\":\"Weiterlesen\"},{\"key\":\"nextReads/bookmarkedFeed/manageBookmarks\",\"value\":\"Lesezeichen bearbeiten\"},{\"key\":\"loginPopup/title\",\"value\":\"Willkommen zurück!\"},{\"key\":\"loginPopup/description\",\"value\":\"Bitte <b>melden Sie sich an</b>, um den Beitrag zu lesen.\"},{\"key\":\"newsletter/subscribe\",\"value\":\"Newsletter abonnieren\"},{\"key\":\"newsletter/isSubscribed\",\"value\":\"Newsletter abonniert\"},{\"key\":\"newsletter/subscribeCourse\",\"value\":\"Kostenlosen Kurs abonnieren\"},{\"key\":\"newsletter/isSubscribedCourse\",\"value\":\"Kurs abonniert\"},{\"key\":\"newsletters/postbox\",\"value\":\"ins Postfach bekommen\"},{\"key\":\"newsletters/DAILY/name\",\"value\":\"Republik heute\"},{\"key\":\"newsletters/DAILY/description\",\"value\":\"Jeden Morgen die kompakte Übersicht: was die Republik aktuell zu bieten hat.\"},{\"key\":\"newsletters/DAILY/schedule\",\"value\":\"Montag bis Freitag\"},{\"key\":\"newsletters/WDWWW/name\",\"value\":\"Was diese Woche wichtig war\"},{\"key\":\"newsletters/WDWWW/description\",\"value\":\"Die News der Woche, sorgfältig ausgewählt und kompakt eingeordnet.\"},{\"key\":\"newsletters/WDWWW/schedule\",\"value\":\"Freitag\"},{\"key\":\"newsletters/WEEKLY/name\",\"value\":\"Republik am Wochenende\"},{\"key\":\"newsletters/WEEKLY/description\",\"value\":\"Lektüre für das Wochenende und alle Beiträge der Woche nochmals im Überblick.\"},{\"key\":\"newsletters/WEEKLY/schedule\",\"value\":\"Samstag\"},{\"key\":\"newsletters/CLIMATE/name\",\"value\":\"Challenge Accepted\"},{\"key\":\"newsletters/CLIMATE/description\",\"value\":\"Der Newsletter für alle, die sich der Klimakrise stellen.\"},{\"key\":\"newsletters/CLIMATE/schedule\",\"value\":\"Alle 2 bis 3 Wochen\"},{\"key\":\"newsletters/SUNDAY/name\",\"value\":\"Republik am Sonntag\"},{\"key\":\"newsletters/SUNDAY/description\",\"value\":\"Lesegenuss fernab aktueller News-Hektik.\"},{\"key\":\"newsletters/SUNDAY/schedule\",\"value\":\"Sonntag\"},{\"key\":\"newsletters/BAB/name\",\"value\":\"Briefing aus Bern\"},{\"key\":\"newsletters/BAB/description\",\"value\":\"Das Wichtigste aus der Schweizer Politik auf einen Blick.\"},{\"key\":\"newsletters/BAB/schedule\",\"value\":\"Donnerstag\"},{\"key\":\"newsletters/TECH/name\",\"value\":\"CTRL\"},{\"key\":\"newsletters/TECH/description\",\"value\":\"Technologie ist politisch. Wir schauen genau hin. Der Digitalpolitik-Newsletter der Republik mit Adrienne Fichter.\"},{\"key\":\"newsletters/TECH/schedule\",\"value\":\"Alle 2 bis 3 Wochen\"},{\"key\":\"newsletters/PROJECTR/name\",\"value\":\"Project R\"},{\"key\":\"newsletters/PROJECTR/description\",\"value\":\"Der schonungslose Blick hinter die Kulissen unseres Unternehmens.\"},{\"key\":\"newsletters/PROJECTR/schedule\",\"value\":\"Alle 1 bis 2 Monate\"},{\"key\":\"newsletters/COURSE-BIGTECH/name\",\"value\":\"Bye-Bye Big Tech\"},{\"key\":\"newsletters/COURSE-BIGTECH/description\",\"value\":\"In 5 Wochen digital unabhängiger werden.\"},{\"key\":\"newsletters/COURSE-BIGTECH/schedule\",\"value\":\"5 Wochen\"},{\"key\":\"newsletters/COURSE-CLIMATE/name\",\"value\":\"Klimakrise – challenge accepted!\"},{\"key\":\"newsletters/COURSE-CLIMATE/description\",\"value\":\"Wir zeigen Ihnen, wie Sie ab sofort mehr fürs Klima tun können.\"},{\"key\":\"newsletters/COURSE-CLIMATE/schedule\",\"value\":\"5 Wochen\"},{\"key\":\"onboarding/newsletters/step\",\"value\":\"Tipp 1 von 2\"},{\"key\":\"onboarding/newsletters/title\",\"value\":\"Lassen Sie sich die Republik ins Postfach liefern\"},{\"key\":\"onboarding/newsletters/description\",\"value\":\"Welche Newsletter möchten Sie erhalten?\"},{\"key\":\"onboarding/newsletters/next\",\"value\":\"Weiter\"},{\"key\":\"onboarding/follow/step\",\"value\":\"Tipp 2 von 2\"},{\"key\":\"onboarding/follow/title\",\"value\":\"Folgen Sie Stimmen, die Sie interessieren\"},{\"key\":\"onboarding/follow/web/description\",\"value\":\"Wir informieren Sie per E-Mail über neue Beiträge.\"},{\"key\":\"onboarding/follow/app/description\",\"value\":\"Wir informieren Sie per Push-Benachrichtigung über neue Beiträge.\"},{\"key\":\"onboarding/follow/next\",\"value\":\"Fertig!\"},{\"key\":\"onboarding/formats/title\",\"value\":\"Kolumnen\"},{\"key\":\"onboarding/authors/title\",\"value\":\"Autorinnen\"},{\"key\":\"onboarding/authors/more\",\"value\":\"Mehr anzeigen\"},{\"key\":\"onboarding/authors/less\",\"value\":\"Weniger anzeigen\"},{\"key\":\"onboarding/podcasts/title\",\"value\":\"Podcasts\"},{\"key\":\"onboarding/formats/republik/format-binswanger/author\",\"value\":\"Daniel Binswanger\"},{\"key\":\"onboarding/formats/republik/format-rosenwasser/author\",\"value\":\"Anna Rosenwasser\"},{\"key\":\"onboarding/formats/republik/format-format-wie-reden-wir-eigentlich/author\",\"value\":\"Marie-José Kolly\"},{\"key\":\"onboarding/formats/republik/format-vahland/author\",\"value\":\"Kia Vahland\"},{\"key\":\"onboarding/formats/republik/format-pfister/author\",\"value\":\"Gerhard Pfister\"},{\"key\":\"onboarding/formats/republik/format-gedankensplitter/author\",\"value\":\"Daniel Strassberg\"},{\"key\":\"onboarding/podcasts/republik/format-dritte-gewalt/title\",\"value\":\"Dritte Gewalt\"},{\"key\":\"onboarding/podcasts/republik/format-sondersession/title\",\"value\":\"Sonder session\"},{\"key\":\"onboarding/podcasts/republik/format-gute-frage/title\",\"value\":\"Gute Frage\"},{\"key\":\"onboarding/podcasts/republik/format-was-wurde-eigentlich-aus/title\",\"value\":\"Update!\"},{\"key\":\"onboarding/podcasts/republik/format-am-klavier/title\",\"value\":\"Dritte Gewalt\"},{\"key\":\"onboarding/podcasts/republik/format-republik-live/title\",\"value\":\"Sonder session\"},{\"key\":\"onboarding/podcasts/republik/format-wochenrevue/title\",\"value\":\"Gute Frage\"},{\"key\":\"onboarding/podcasts/republik/format-im-gespraech/title\",\"value\":\"Update!\"},{\"key\":\"onboarding/authors/adriennefichter/beat\",\"value\":\"Big Tech\"},{\"key\":\"onboarding/authors/dbuehler/beat\",\"value\":\"Medien\"},{\"key\":\"onboarding/authors/sabrinamweiss/beat\",\"value\":\"Klimakrise\"},{\"key\":\"onboarding/authors/palbrecht/beat\",\"value\":\"Wirtschaft\"},{\"key\":\"onboarding/authors/angelikahardegger/beat\",\"value\":\"Reporterin\"},{\"key\":\"onboarding/authors/ceisenach/beat\",\"value\":\"Wissenschaft\"},{\"key\":\"onboarding/authors/graf/beat\",\"value\":\"Literatur\"},{\"key\":\"onboarding/authors/bhurlimann/beat\",\"value\":\"Justiz\"},{\"key\":\"onboarding/authors/chanimann/beat\",\"value\":\"Reporter\"},{\"key\":\"onboarding/authors/luciaherrmann/beat\",\"value\":\"Community\"},{\"key\":\"onboarding/authors/ywegelin/beat\",\"value\":\"Wirtschaft\"},{\"key\":\"onboarding/authors/vheintges/beat\",\"value\":\"Theater\"},{\"key\":\"follow/authors/all\",\"value\":\"Alle Autorinnen anzeigen\"},{\"key\":\"follow/format/all\",\"value\":\"Alle anzeigen\"},{\"key\":\"follow/discussion/ALL/label\",\"value\":\"Alle neuen Kommentare\"},{\"key\":\"follow/discussion/ALL/action\",\"value\":\"Gefolgt\"},{\"key\":\"follow/discussion/MY_CHILDREN/label\",\"value\":\"Antworten auf meine Kommentare\"},{\"key\":\"follow/discussion/MY_CHILDREN/action\",\"value\":\"Gefolgt\"},{\"key\":\"follow/discussion/NONE/label\",\"value\":\"Entfolgen\"},{\"key\":\"follow/discussion/NONE/action\",\"value\":\"Folgen\"},{\"key\":\"follow/author/ALL/label\",\"value\":\"Im Magazin und im Dialog\"},{\"key\":\"follow/author/ALL/action\",\"value\":\"Gefolgt\"},{\"key\":\"follow/author/DOCUMENTS/label\",\"value\":\"Im Magazin\"},{\"key\":\"follow/author/DOCUMENTS/action\",\"value\":\"Gefolgt\"},{\"key\":\"follow/author/NONE/label\",\"value\":\"Entfolgen\"},{\"key\":\"follow/author/NONE/action\",\"value\":\"Folgen\"}]}");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/withT.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "t",
    ()=>t,
    "useTranslation",
    ()=>useTranslation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$dist$2f$lib$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/styleguide/dist/lib.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$dist$2f$chunk$2d$QCYBJGVP$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/styleguide/dist/chunk-QCYBJGVP.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$translations$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/translations.json.[json].cjs [app-client] (ecmascript)");
;
;
;
const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$dist$2f$chunk$2d$QCYBJGVP$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createFormatter"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$translations$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].data);
const withT = (Component)=>(props)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Component, {
            ...props,
            t: t
        }, void 0, false, {
            fileName: "[project]/apps/www/src/lib/withT.js",
            lineNumber: 6,
            columnNumber: 41
        }, ("TURBOPACK compile-time value", void 0));
const __TURBOPACK__default__export__ = withT;
function useTranslation() {
    return {
        t
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/lib/analytics/event-tracking.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EventTrackingContext",
    ()=>EventTrackingContext,
    "trackEvent",
    ()=>trackEvent,
    "trackEventOnClick",
    ()=>trackEventOnClick,
    "trackRevenue",
    ()=>trackRevenue,
    "useTrackEvent",
    ()=>useTrackEvent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$plausible$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-plausible/dist/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$dist$2f$lib$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/styleguide/dist/lib.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$dist$2f$chunk$2d$QCYBJGVP$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/styleguide/dist/chunk-QCYBJGVP.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
const ctx = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
ctx.displayName = 'EventTrackingContext';
const { Provider } = ctx;
const EventTrackingContext = ({ category, action, name, children })=>{
    _s();
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "EventTrackingContext.useMemo[value]": ()=>({
                category,
                action,
                name
            })
    }["EventTrackingContext.useMemo[value]"], [
        category,
        action,
        name
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/lib/analytics/event-tracking.tsx",
        lineNumber: 48,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
_s(EventTrackingContext, "tPauEVZ6EeuERV9ttvKTwQ7++Gw=");
_c = EventTrackingContext;
const useTrackEvent = ()=>{
    _s1();
    const ctxValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ctx);
    const trackPlausibleEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$plausible$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePlausible"])();
    if (!ctxValue) {
        if ("TURBOPACK compile-time truthy", 1) {
            console.error(`useTrackEvent: context missing. Please wrap this component in a <TrackingContext> `);
        }
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useTrackEvent.useCallback": (params)=>{
            const { category, ...props } = {
                ...ctxValue,
                ...params
            };
            if (!props.action) {
                if ("TURBOPACK compile-time truthy", 1) {
                    console.warn(`useTrackEvent: action undefined. Set one on the TrackingContext or function argument`);
                }
            } else {
                if ("TURBOPACK compile-time truthy", 1) {
                    console.log('Track Event', category, props);
                }
                trackPlausibleEvent(category, {
                    props
                });
            }
        }
    }["useTrackEvent.useCallback"], [
        ctxValue,
        trackPlausibleEvent
    ]);
};
_s1(useTrackEvent, "/MJ/o/6dQmT/mMoKu4Gbk2mAsDM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$plausible$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePlausible"]
    ];
});
;
const trackRevenue = (amount)=>{
    window.plausible?.('Sales', {
        revenue: {
            currency: 'CHF',
            amount
        }
    });
};
const trackEvent = ([eventName, action, name, value = undefined])=>{
    window.plausible?.(eventName, {
        props: {
            action,
            name,
            value
        }
    });
};
const trackEventOnClick = ([eventName, action, name, value], onClick)=>(e)=>{
        trackEvent([
            eventName,
            action,
            name,
            value
        ]);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$dist$2f$chunk$2d$QCYBJGVP$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shouldIgnoreClick"])(e, false)) {
            return;
        }
        e.preventDefault();
        onClick(e);
    };
var _c;
__turbopack_context__.k.register(_c, "EventTrackingContext");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/next-reads/helpers.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CategoryLabel",
    ()=>CategoryLabel,
    "NextReadAuthor",
    ()=>NextReadAuthor,
    "NextReadDuration",
    ()=>NextReadDuration,
    "NextReadLink",
    ()=>NextReadLink
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$render$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/portable-text/render.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$analytics$2f$event$2d$tracking$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/lib/analytics/event-tracking.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$link$2d$overlay$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/link-overlay.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
function NextReadAuthor({ article }) {
    const authorsNames = article.contributors?.filter((contributor)=>contributor.kind?.includes('Text')).map((contributor)=>contributor.name);
    if (!authorsNames?.length) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        className: "author",
        children: [
            "Von ",
            authorsNames.join(', ')
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/helpers.tsx",
        lineNumber: 19,
        columnNumber: 10
    }, this);
}
_c = NextReadAuthor;
function NextReadDuration({ document }) {
    const duration = document.meta.estimatedReadingMinutes || document.meta.estimatedConsumptionMinutes;
    if (!duration) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        className: "duration",
        children: [
            duration,
            " min"
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/helpers.tsx",
        lineNumber: 36,
        columnNumber: 10
    }, this);
}
_c1 = NextReadDuration;
function CategoryLabel({ article }) {
    const label = article.heading?.title;
    if (!label) return null;
    const color = article.theme?.accentColor?.hex;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
        style: {
            color
        },
        children: label
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/helpers.tsx",
        lineNumber: 45,
        columnNumber: 10
    }, this);
}
_c2 = CategoryLabel;
function NextReadLink({ article, index }) {
    _s();
    const trackEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$analytics$2f$event$2d$tracking$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTrackEvent"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: article.slug?.current ?? '#',
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$link$2d$overlay$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["linkOverlay"])(),
        onClick: ()=>{
            trackEvent({
                action: 'click recommended read',
                slug: article.slug?.current,
                index
            });
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$render$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InlinePortableText"], {
            value: article.title
        }, void 0, false, {
            fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/helpers.tsx",
            lineNumber: 69,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/helpers.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}
_s(NextReadLink, "L9SSy1WZaq0MI5bCSnAumeK3LfA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$analytics$2f$event$2d$tracking$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTrackEvent"]
    ];
});
_c3 = NextReadLink;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "NextReadAuthor");
__turbopack_context__.k.register(_c1, "NextReadDuration");
__turbopack_context__.k.register(_c2, "CategoryLabel");
__turbopack_context__.k.register(_c3, "NextReadLink");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/next-reads/styles.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "nextReadHeader",
    ()=>nextReadHeader,
    "nextReadItemTypography",
    ()=>nextReadItemTypography,
    "nextReadsSection",
    ()=>nextReadsSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
const nextReadsSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
    borderTopWidth: '1px',
    borderTopStyle: 'solid',
    borderTopColor: 'contrast',
    maxWidth: '1700px',
    margin: '0 auto',
    textAlign: 'center'
});
const nextReadHeader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
    mt: 8,
    mb: 8,
    '& h3': {
        textStyle: 'subtitleBold',
        mb: 4
    },
    '& .tagline': {
        fontFamily: 'rubis',
        fontWeight: 300,
        fontStyle: 'italic',
        fontSize: 16
    }
});
const nextReadItemTypography = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
    // title of the document
    '& h4': {
        fontFamily: 'rubis',
        fontWeight: 'medium',
        fontSize: 18,
        lineHeight: 1.2,
        marginBottom: 2
    },
    // format or series name
    '& h5': {
        fontFamily: 'gtAmericaStandard',
        fontWeight: 500,
        fontSize: 14,
        lineHeight: 1,
        letterSpacing: '-0.02em',
        marginBottom: 4
    },
    '& p.description': {
        fontFamily: 'rubis',
        fontWeight: 400,
        fontSize: 16,
        lineHeight: 1.5,
        marginBottom: 2
    },
    '& p.author': {
        fontFamily: 'gtAmericaStandard',
        fontWeight: 500,
        fontSize: 14,
        lineHeight: 1.2,
        letterSpacing: '0.01em'
    },
    '& p.duration': {
        fontFamily: 'gtAmericaStandard',
        fontWeight: 400,
        fontSize: 14,
        lineHeight: 1.2
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/next-reads/article-recommendations.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArticleRecommendations",
    ()=>ArticleRecommendations
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// TODO: rename ./sanity-helpers to ./helpers once we are fully migrated
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$render$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/portable-text/render.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/withT.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/cx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$next$2d$reads$2f$helpers$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/next-reads/helpers.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$next$2d$reads$2f$styles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/next-reads/styles.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function RecommendedRead({ article, index }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cx"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$next$2d$reads$2f$styles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nextReadItemTypography"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            pb: 8,
            mb: 8,
            borderBottomWidth: 1,
            borderBottomStyle: 'solid',
            borderBottomColor: 'divider',
            position: 'relative',
            // exclude last item from border
            '&:last-of-type': {
                borderBottom: 'none',
                pb: 0
            }
        })),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$next$2d$reads$2f$helpers$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CategoryLabel"], {
                article: article
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/article-recommendations.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$next$2d$reads$2f$helpers$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NextReadLink"], {
                    article: article,
                    index: index
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/article-recommendations.tsx",
                    lineNumber: 40,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/article-recommendations.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "description",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$render$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InlinePortableText"], {
                    value: article.description
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/article-recommendations.tsx",
                    lineNumber: 43,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/article-recommendations.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$next$2d$reads$2f$helpers$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NextReadAuthor"], {
                article: article
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/article-recommendations.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/article-recommendations.tsx",
        lineNumber: 23,
        columnNumber: 5
    }, this);
}
_c = RecommendedRead;
function ArticleRecommendations({ recommendations }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    if (!recommendations?.length) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$next$2d$reads$2f$styles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nextReadsSection"],
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cx"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$next$2d$reads$2f$styles$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nextReadHeader"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                        textAlign: 'left'
                    })),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        children: t('nextReads/curatedFeed/title')
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/article-recommendations.tsx",
                        lineNumber: 63,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/article-recommendations.tsx",
                    lineNumber: 62,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/article-recommendations.tsx",
                lineNumber: 61,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    pt: 4,
                    pb: 16
                }),
                children: recommendations.map((rec, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(RecommendedRead, {
                        article: rec,
                        index: index
                    }, rec._id, false, {
                        fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/article-recommendations.tsx",
                        lineNumber: 68,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/next-reads/article-recommendations.tsx",
                lineNumber: 66,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(ArticleRecommendations, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"]
    ];
});
_c1 = ArticleRecommendations;
var _c, _c1;
__turbopack_context__.k.register(_c, "RecommendedRead");
__turbopack_context__.k.register(_c1, "ArticleRecommendations");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/theme.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Theme",
    ()=>Theme
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$theme$2d$provider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/theme-provider.tsx [app-client] (ecmascript) <locals>");
'use client';
;
;
function Theme({ theme }) {
    if (!theme) return null;
    if (theme.darkMode) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$theme$2d$provider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useForceTheme"])('dark');
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
        children: `:root { --page-theme-accent-color: ${theme?.accentColor?.hex}; }`
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/theme.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = Theme;
var _c;
__turbopack_context__.k.register(_c, "Theme");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/ui/spinner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Spinner",
    ()=>Spinner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cva$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/cva.mjs [app-client] (ecmascript)");
;
;
const spinnerVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cva$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])({
    base: {
        ml: '2',
        mr: '-1',
        animation: '[spin 1s ease-in-out infinite]'
    },
    variants: {
        size: {
            default: {
                h: '16px',
                w: '16px'
            },
            large: {
                h: '24px',
                w: '24px'
            },
            full: {
                h: '24px',
                w: '24px'
            },
            small: {
                h: '12px',
                w: '12px'
            }
        }
    },
    defaultVariants: {
        size: 'default'
    }
});
function Spinner({ size }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        className: spinnerVariants({
            size
        }),
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    opacity: '0.25'
                }),
                cx: "12px",
                cy: "12px",
                r: "10px",
                stroke: "currentColor",
                strokeWidth: "4"
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/ui/spinner.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    opacity: '0.75'
                }),
                fill: "currentColor",
                d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/ui/spinner.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/components/ui/spinner.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
_c = Spinner;
var _c;
__turbopack_context__.k.register(_c, "Spinner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/ui/button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/cx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$recipes$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/recipes/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$recipes$2f$button$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/recipes/button.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$spinner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/ui/spinner.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const Button = ({ className, variant, size = 'default', asChild = false, children, loading, ...props })=>{
    _s();
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : 'button';
    const content = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Button.useMemo[content]": ()=>{
            if (!loading) {
                return children;
            }
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    display: 'flex',
                    flexDirection: 'row'
                }),
                children: [
                    children,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$spinner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Spinner"], {
                        size: size
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/components/ui/button.tsx",
                        lineNumber: 32,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/apps/www/src/app/components/ui/button.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0));
        }
    }["Button.useMemo[content]"], [
        children,
        loading
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cx"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$recipes$2f$button$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["button"])({
            variant,
            size
        }), loading && (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            cursor: 'loading'
        }), className),
        "aria-busy": loading,
        ...props,
        children: content
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/components/ui/button.tsx",
        lineNumber: 38,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Button, "nOKcCO/DZR7PO8GpYaNDiNh8hVA=");
_c = Button;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/follow/follow-button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FollowButton",
    ()=>FollowButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/graphql/republik-api/__generated__/gql/graphql.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$analytics$2f$event$2d$tracking$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/lib/analytics/event-tracking.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withInNativeApp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/apps/www/src/lib/withInNativeApp.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hooks/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
function FollowButton({ type, subscriptionId, objectId, objectName, size = 'small', filters = [
    __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EventObjectType"].Document
] }) {
    _s();
    const [subscribe] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SubscribeDocument"]);
    const [unsubscribe] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnsubscribeDocument"]);
    const [isPending, setIsPending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showSpinner, setShowSpinner] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const track = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$analytics$2f$event$2d$tracking$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTrackEvent"])();
    const trackingInfo = `${type}: ${objectName}`;
    async function toggleSubscription(e) {
        e.stopPropagation();
        if (isPending) return;
        setIsPending(true);
        // while we disable the button for the whole duration of the request,
        // we only show the spinner if the request takes longer than 1s
        const spinner = setTimeout(()=>setShowSpinner(true), 1000);
        if (subscriptionId) {
            await unsubscribe({
                variables: {
                    subscriptionId
                }
            });
            track({
                action: 'Unfollow',
                name: trackingInfo
            });
        } else {
            await subscribe({
                variables: {
                    objectId,
                    type,
                    filters
                }
            });
            track({
                action: 'Follow',
                name: trackingInfo
            });
            // triggers the push permission popup in the app
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withInNativeApp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["postMessage"])({
                type: 'isSignedIn',
                payload: true
            });
        }
        clearTimeout(spinner);
        setShowSpinner(false);
        setIsPending(false);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            fontWeight: 500,
            textDecoration: 'none'
        }),
        onClick: toggleSubscription,
        disabled: isPending,
        type: "button",
        size: size,
        variant: subscriptionId ? 'outline' : 'default',
        loading: showSpinner,
        children: subscriptionId ? 'Gefolgt' : 'Folgen'
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-button.tsx",
        lineNumber: 79,
        columnNumber: 5
    }, this);
}
_s(FollowButton, "1Lb8/h9hvP/fkG3+1oApKVDPJII=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$analytics$2f$event$2d$tracking$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTrackEvent"]
    ];
});
_c = FollowButton;
var _c;
__turbopack_context__.k.register(_c, "FollowButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/follow/follow-collection-container.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
'use client';
;
;
function FollowCollectionContainer({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            my: 8,
            pt: 8,
            borderTopWidth: '1px',
            borderTopStyle: 'solid',
            borderTopColor: 'text',
            display: 'flex',
            alignItems: 'center',
            gap: 4
        }),
        children: children
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-collection-container.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
}
_c = FollowCollectionContainer;
const __TURBOPACK__default__export__ = FollowCollectionContainer;
var _c;
__turbopack_context__.k.register(_c, "FollowCollectionContainer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/lib/client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "client",
    ()=>client
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/client/dist/index.browser.js [app-client] (ecmascript) <locals>");
;
const projectId = ("TURBOPACK compile-time value", "obvmvrpv");
const dataset = ("TURBOPACK compile-time value", "development");
const studioUrl = ("TURBOPACK compile-time value", "http://localhost:3333");
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])({
    projectId,
    dataset,
    apiVersion: '2026-02-01',
    useCdn: true,
    stega: {
        studioUrl
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/lib/urlFor.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "urlFor",
    ()=>urlFor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$image$2d$url$2f$lib$2f$_chunks$2d$es$2f$compat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/image-url/lib/_chunks-es/compat.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/lib/client.ts [app-client] (ecmascript)");
;
;
const builder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$image$2d$url$2f$lib$2f$_chunks$2d$es$2f$compat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createImageUrlBuilder"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["client"]);
function urlFor(source) {
    return builder.image(source);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/follow/follow-collection-card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/graphql/republik-api/__generated__/gql/graphql.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$follow$2f$follow$2d$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/follow/follow-button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$follow$2f$follow$2d$collection$2d$container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/follow/follow-collection-container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$lib$2f$urlFor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/lib/urlFor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
function FollowCollectionCard({ collection }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$follow$2f$follow$2d$collection$2d$container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                            textStyle: 'subtitleBold',
                            lineHeight: 1.2
                        }),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    color: '#909090'
                                },
                                children: "Das war:"
                            }, void 0, false, {
                                fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-collection-card.tsx",
                                lineNumber: 24,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-collection-card.tsx",
                                lineNumber: 25,
                                columnNumber: 11
                            }, this),
                            collection.title
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-collection-card.tsx",
                        lineNumber: 18,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                            pt: 1,
                            pb: 4,
                            textStyle: 'airy'
                        }),
                        children: collection.description
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-collection-card.tsx",
                        lineNumber: 28,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$follow$2f$follow$2d$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FollowButton"], {
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SubscriptionObjectType"].Document,
                        size: "small"
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-collection-card.tsx",
                        lineNumber: 31,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-collection-card.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, this),
            !!collection.image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$lib$2f$urlFor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["urlFor"])(collection.image).width(360).height(360).url(),
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    width: 120,
                    height: 120,
                    borderRadius: 120,
                    ml: 'auto',
                    objectFit: 'cover'
                })
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-collection-card.tsx",
                lineNumber: 34,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-collection-card.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
_c = FollowCollectionCard;
const __TURBOPACK__default__export__ = FollowCollectionCard;
var _c;
__turbopack_context__.k.register(_c, "FollowCollectionCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/follow/follow-contributor-card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/graphql/republik-api/__generated__/gql/graphql.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$follow$2f$follow$2d$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/follow/follow-button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$lib$2f$urlFor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/lib/urlFor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$link$2d$overlay$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/link-overlay.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
function FollowContributorCard({ contributor }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            marginTop: 4,
            pt: 4,
            borderTopStyle: 'solid',
            borderTopWidth: '1px',
            borderTopColor: 'divider',
            display: 'flex',
            alignItems: 'center',
            gap: 2,
            position: 'relative',
            cursor: 'pointer',
            md: {
                gap: 4,
                px: 4
            }
        }),
        children: [
            contributor.portrait && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$lib$2f$urlFor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["urlFor"])(contributor.portrait).width(250).height(250).url(),
                width: "84",
                height: "84",
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    borderRadius: '96px'
                }),
                alt: ""
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributor-card.tsx",
                lineNumber: 35,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                            fontWeight: 'bold',
                            lineHeight: '1.2'
                        }),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: `/~${contributor.slug}`,
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$link$2d$overlay$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["linkOverlay"])(),
                            children: contributor.name
                        }, void 0, false, {
                            fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributor-card.tsx",
                            lineNumber: 47,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributor-card.tsx",
                        lineNumber: 46,
                        columnNumber: 9
                    }, this),
                    !!contributor.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                            fontSize: 'sm',
                            color: 'textSoft',
                            lineHeight: '1.2',
                            wordBreak: 'break-word'
                        }),
                        children: contributor.description
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributor-card.tsx",
                        lineNumber: 52,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributor-card.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    ml: 'auto',
                    position: 'relative',
                    zIndex: 10,
                    pl: 2
                }),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$follow$2f$follow$2d$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FollowButton"], {
                    type: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SubscriptionObjectType"].User
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributor-card.tsx",
                    lineNumber: 67,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributor-card.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributor-card.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
_c = FollowContributorCard;
const __TURBOPACK__default__export__ = FollowContributorCard;
var _c;
__turbopack_context__.k.register(_c, "FollowContributorCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/follow/follow-contributors.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$follow$2f$follow$2d$contributor$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/follow/follow-contributor-card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/withT.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$collapsible$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-collapsible/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const CONTRIBUTORS_SHOWN = 3;
function ContributorsList({ contributors }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: contributors.map((contributor)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$follow$2f$follow$2d$contributor$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                contributor: contributor
            }, contributor.slug, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributors.tsx",
                lineNumber: 21,
                columnNumber: 9
            }, this))
    }, void 0, false);
}
_c = ContributorsList;
function FollowContributors({ contributors }) {
    _s();
    const [showAll, setShowAll] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    if (!contributors?.length) return null;
    const contributorsShown = contributors.slice(0, CONTRIBUTORS_SHOWN);
    const contributorsHidden = contributors.slice(CONTRIBUTORS_SHOWN);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            mt: 8,
            mb: 12,
            md: {
                mb: 16
            }
        }),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContributorsList, {
                contributors: contributorsShown
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributors.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this),
            !!contributorsHidden?.length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$collapsible$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
                open: showAll,
                onOpenChange: setShowAll,
                children: [
                    !showAll && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$collapsible$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"], {
                        asChild: true,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                                mt: 8,
                                display: 'flex',
                                color: 'textSoft'
                            }),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "link",
                                onClick: ()=>setShowAll(true),
                                type: "button",
                                children: t('follow/authors/all')
                            }, void 0, false, {
                                fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributors.tsx",
                                lineNumber: 57,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributors.tsx",
                            lineNumber: 50,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributors.tsx",
                        lineNumber: 49,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$collapsible$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
                        "data-collapsible-collapsed-items": true,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                            overflow: 'hidden',
                            animationTimingFunction: 'ease-out',
                            animationDuration: '300ms',
                            '&[data-state="open"]': {
                                animationName: 'radixCollapsibleSlideDown'
                            },
                            '&[data-state="closed"]:not([hidden])': {
                                animationName: 'radixCollapsibleSlideUp'
                            }
                        }),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContributorsList, {
                            contributors: contributorsHidden
                        }, void 0, false, {
                            fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributors.tsx",
                            lineNumber: 81,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributors.tsx",
                        lineNumber: 67,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributors.tsx",
                lineNumber: 47,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-contributors.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_s(FollowContributors, "5Y0z6AwdIpHVJPfIhozz/mOFO2s=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"]
    ];
});
_c1 = FollowContributors;
const __TURBOPACK__default__export__ = FollowContributors;
var _c, _c1;
__turbopack_context__.k.register(_c, "ContributorsList");
__turbopack_context__.k.register(_c1, "FollowContributors");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/newsletters/helpers.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isSubscribedToNewsletter",
    ()=>isSubscribedToNewsletter
]);
const isSubscribedToNewsletter = (name, subscriptions)=>subscriptions?.find((s)=>s?.name === name)?.subscribed;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/newsletters/newsletters-status.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NewslettersStatus",
    ()=>NewslettersStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/graphql/republik-api/__generated__/gql/graphql.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hooks/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/withT.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
function NewslettersStatus({ userId, status }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const [resubscribe, { data, loading, error }] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NewslettersResubscribeDocument"], {
        variables: {
            userId
        }
    });
    if (status === 'subscribed') {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-theme": "light",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            display: 'flex',
            flexDirection: 'column',
            gap: '4',
            alignItems: 'flex-start',
            color: 'text',
            backgroundColor: 'background.marketing',
            p: '8'
        }),
        children: data?.resubscribeEmail.status === 'pending' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: t('account/newsletterSubscriptions/resubscribed')
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletters-status.tsx",
                lineNumber: 39,
                columnNumber: 11
            }, this)
        }, void 0, false) : status === 'unsubscribed' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: t('account/newsletterSubscriptions/unsubscribed')
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletters-status.tsx",
                    lineNumber: 43,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    onClick: ()=>{
                        resubscribe();
                    },
                    loading: loading,
                    children: t('account/newsletterSubscriptions/resubscribe')
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletters-status.tsx",
                    lineNumber: 45,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true) : status === 'pending' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: t('account/newsletterSubscriptions/resubscribeEmailPending')
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletters-status.tsx",
                    lineNumber: 56,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    onClick: ()=>{
                        resubscribe();
                    },
                    loading: loading,
                    size: "small",
                    variant: "outline",
                    children: t('account/newsletterSubscriptions/resendResubscribeEmail')
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletters-status.tsx",
                    lineNumber: 58,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true) : null
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletters-status.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_s(NewslettersStatus, "ap3MvWrozP6dgtLmjAuN04r4UZc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
_c = NewslettersStatus;
var _c;
__turbopack_context__.k.register(_c, "NewslettersStatus");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/auth/login/error-message.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ErrorMessage",
    ()=>ErrorMessage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/icons/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
'use client';
;
;
;
const ErrorMessage = ({ error })=>{
    const message = typeof error === 'string' ? error : error?.networkError ? 'Network error' : error?.graphQLErrors[0]?.message;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            color: 'error',
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            gap: '2',
            mb: '4'
        }),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconInfoOutline"], {}, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/auth/login/error-message.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    textAlign: 'left'
                }),
                children: message || 'Error'
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/auth/login/error-message.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/components/auth/login/error-message.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = ErrorMessage;
var _c;
__turbopack_context__.k.register(_c, "ErrorMessage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/ui/form.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FormField",
    ()=>FormField
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/cx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$visually$2d$hidden$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/visually-hidden.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function FormField({ label, error, name, type = 'text', description, hideLabel, ...inputProps }) {
    _s();
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            display: 'flex',
            flexDirection: 'column',
            gap: '1.5',
            width: 'full'
        }),
        "data-invalid": error ? 'true' : undefined,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: id,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cx"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    fontSize: 's',
                    display: 'block',
                    color: 'text.secondary',
                    textAlign: 'left',
                    fontWeight: 'medium'
                }), hideLabel && (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$visually$2d$hidden$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["visuallyHidden"])()),
                children: label
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/ui/form.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                ...inputProps,
                id: id,
                name: name,
                type: type,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cx"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    background: 'white',
                    borderWidth: '1px',
                    borderColor: 'black',
                    borderRadius: '5px',
                    color: 'black',
                    lineHeight: 1.5,
                    p: '2',
                    _disabled: {
                        color: 'text.secondary',
                        background: 'disabled'
                    },
                    _placeholder: {
                        color: 'text.tertiary',
                        fontWeight: 'normal'
                    }
                }), error && (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    borderColor: 'error'
                }), inputProps?.className)
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/ui/form.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "aria-live": "polite",
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    color: 'error',
                    fontSize: 'sm'
                }),
                children: error
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/ui/form.tsx",
                lineNumber: 78,
                columnNumber: 9
            }, this),
            description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    color: 'text.tertiary',
                    fontSize: 'xs'
                }),
                children: description
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/ui/form.tsx",
                lineNumber: 89,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/components/ui/form.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
_s(FormField, "WhsuKpSQZEWeFcB7gWlfDRQktoQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = FormField;
var _c;
__turbopack_context__.k.register(_c, "FormField");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NewsletterSubscribeButton",
    ()=>NewsletterSubscribeButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/graphql/republik-api/__generated__/gql/graphql.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$newsletters$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/newsletters/helpers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$newsletters$2f$newsletters$2d$status$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/newsletters/newsletters-status.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$auth$2f$login$2f$error$2d$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/auth/login/error-message.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/ui/form.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$analytics$2f$event$2d$tracking$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/lib/analytics/event-tracking.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$analytics$2f$utm$2d$session$2d$storage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/lib/analytics/utm-session-storage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/withT.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$errors$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/errors/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hooks/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hooks/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$validator$2f$lib$2f$isEmail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/validator/lib/isEmail.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
function NewsletterSubscribeForm({ newsletter }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const track = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$analytics$2f$event$2d$tracking$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTrackEvent"])();
    const [subscribe] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SignUpForNewsletterDocument"]);
    const [isPending, setIsPending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [confirmEmail, setConfirmEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    async function submitEmail(e) {
        e.preventDefault();
        if (isPending) {
            return;
        }
        setIsPending(true);
        const form = e.target;
        const formData = new FormData(form);
        const email = formData.get('email');
        if (!email || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$validator$2f$lib$2f$isEmail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(email)) {
            setIsPending(false);
            setError(t('auth/login/email/missing'));
            return;
        }
        const result = await subscribe({
            variables: {
                email: email,
                name: newsletter.name,
                context: 'newsletter',
                meta: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$analytics$2f$utm$2d$session$2d$storage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUTMSessionStorage"])()
            }
        });
        if (result.errors && result.errors.length > 0) {
            setError(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$errors$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApolloError"]({
                graphQLErrors: result.errors
            }));
            return setIsPending(false);
        }
        track({
            action: 'Anonymous Newsletter Subscribe',
            name: newsletter.title
        });
        setIsPending(false);
        setConfirmEmail(true);
    }
    if (confirmEmail) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                textStyle: 'airy'
            }),
            children: t('Auth/NewsletterSignUp/success')
        }, void 0, false, {
            fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx",
            lineNumber: 77,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        action: "POST",
        onSubmit: submitEmail,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                containerType: 'inline-size'
            }),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                        gap: '2',
                        display: 'flex',
                        alignItems: 'end',
                        flexDirection: 'column',
                        pb: 2,
                        '@/md': {
                            flexDirection: 'row'
                        }
                    }),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FormField"], {
                            label: "Ihre E-Mail-Adresse",
                            name: "email",
                            type: "email"
                        }, void 0, false, {
                            fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx",
                            lineNumber: 96,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                                display: 'none',
                                '@/md': {
                                    display: 'block'
                                }
                            }),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                type: "submit",
                                disabled: isPending,
                                loading: isPending,
                                children: t('newsletter/subscribe')
                            }, void 0, false, {
                                fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx",
                                lineNumber: 100,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx",
                            lineNumber: 97,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx",
                    lineNumber: 86,
                    columnNumber: 9
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$auth$2f$login$2f$error$2d$message$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorMessage"], {
                    error: error
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx",
                    lineNumber: 105,
                    columnNumber: 19
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                        '@/md': {
                            display: 'none'
                        }
                    }),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        type: "submit",
                        size: "full",
                        disabled: isPending,
                        loading: isPending,
                        children: t('newsletter/subscribe')
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx",
                        lineNumber: 107,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx",
                    lineNumber: 106,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx",
            lineNumber: 85,
            columnNumber: 7
        }, this)
    }, "email-submit", false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx",
        lineNumber: 84,
        columnNumber: 5
    }, this);
}
_s(NewsletterSubscribeForm, "le8rn4R/Rx+T4rQTaIpQTxbv0yg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$analytics$2f$event$2d$tracking$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTrackEvent"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
_c = NewsletterSubscribeForm;
function NewsletterSubscribeButton({ newsletter }) {
    _s1();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const [updateNewsletterSubscription] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UpdateNewsletterSubscriptionDocument"]);
    const [isPending, setIsPending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const track = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$analytics$2f$event$2d$tracking$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTrackEvent"])();
    const { data } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NewsletterSettingsDocument"]);
    if (!data) return null;
    if (!data.me) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NewsletterSubscribeForm, {
            newsletter: newsletter
        }, void 0, false, {
            fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx",
            lineNumber: 138,
            columnNumber: 12
        }, this);
    }
    const subscriptions = data.me.newsletterSettings.subscriptions;
    const isDisabled = data.me.newsletterSettings.status !== 'subscribed';
    const isSubscribed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$newsletters$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSubscribedToNewsletter"])(newsletter.name, subscriptions);
    async function toggleSubscription(e) {
        e.stopPropagation();
        if (isPending || isDisabled) return;
        setIsPending(true);
        const { data } = await updateNewsletterSubscription({
            variables: {
                name: newsletter.name,
                subscribed: !isSubscribed
            }
        });
        if (data) {
            track({
                action: data.updateNewsletterSubscription.subscribed ? 'Newsletter Subscribe' : 'Newsletter Unsubscribe',
                name: newsletter.title
            });
        }
        setIsPending(false);
    }
    if (isDisabled) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$newsletters$2f$newsletters$2d$status$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NewslettersStatus"], {
        userId: data.me.id,
        status: "unsubscribed"
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx",
        lineNumber: 170,
        columnNumber: 12
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            fontWeight: 500,
            textDecoration: 'none'
        }),
        onClick: toggleSubscription,
        disabled: isPending || isDisabled,
        type: "button",
        variant: isSubscribed ? 'outline' : 'default',
        loading: isPending,
        children: isSubscribed ? t('newsletter/isSubscribed') : t('newsletter/subscribe')
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx",
        lineNumber: 173,
        columnNumber: 5
    }, this);
}
_s1(NewsletterSubscribeButton, "dV3pEEhHA7D8DyMy3dECG40qRzM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$analytics$2f$event$2d$tracking$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTrackEvent"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
_c1 = NewsletterSubscribeButton;
var _c, _c1;
__turbopack_context__.k.register(_c, "NewsletterSubscribeForm");
__turbopack_context__.k.register(_c1, "NewsletterSubscribeButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-article-card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$follow$2f$follow$2d$collection$2d$container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/follow/follow-collection-container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$newsletters$2f$newsletter$2d$subscribe$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-subscribe.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$lib$2f$urlFor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/lib/urlFor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/withT.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function NewsletterArticleCard({ newsletter }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$follow$2f$follow$2d$collection$2d$container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                background: 'background',
                color: 'text',
                textAlign: 'left',
                position: 'relative',
                display: 'flex',
                gap: 4,
                height: '100%',
                width: '100%',
                mb: 6,
                flexDirection: 'column'
            }),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                        flex: '0 0 1',
                        alignSelf: 'flex-start',
                        pt: 1,
                        width: 64
                    }),
                    src: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$lib$2f$urlFor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["urlFor"])(newsletter.image).width(192).height(192).url(),
                    alt: ""
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-article-card.tsx",
                    lineNumber: 33,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                                textStyle: 'subtitleBold',
                                lineHeight: 1.2
                            }),
                            children: [
                                newsletter.title,
                                ' ',
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                                        fontWeight: 500
                                    }),
                                    children: t('newsletters/postbox')
                                }, void 0, false, {
                                    fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-article-card.tsx",
                                    lineNumber: 51,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-article-card.tsx",
                            lineNumber: 44,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                                textStyle: 'airy',
                                my: 1
                            }),
                            children: newsletter.description
                        }, void 0, false, {
                            fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-article-card.tsx",
                            lineNumber: 59,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                                color: 'textSoft'
                            }),
                            children: newsletter.frequency
                        }, void 0, false, {
                            fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-article-card.tsx",
                            lineNumber: 62,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-article-card.tsx",
                    lineNumber: 43,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$newsletters$2f$newsletter$2d$subscribe$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NewsletterSubscribeButton"], {
                        newsletter: newsletter
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-article-card.tsx",
                        lineNumber: 65,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-article-card.tsx",
                    lineNumber: 64,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-article-card.tsx",
            lineNumber: 19,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-article-card.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
_s(NewsletterArticleCard, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withT$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"]
    ];
});
_c = NewsletterArticleCard;
const __TURBOPACK__default__export__ = NewsletterArticleCard;
var _c;
__turbopack_context__.k.register(_c, "NewsletterArticleCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/follow/follow-article.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$follow$2f$follow$2d$collection$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/follow/follow-collection-card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$follow$2f$follow$2d$contributors$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/follow/follow-contributors.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$newsletters$2f$newsletter$2d$article$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/newsletters/newsletter-article-card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/context/MeContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
// order of priority:
// subscribe to newsletter > follow collection > follow contributors
function FollowArticle({ newsletter, collection, contributors }) {
    _s();
    const { me, meLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMe"])();
    if (meLoading) return null;
    if (newsletter) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$newsletters$2f$newsletter$2d$article$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            newsletter: newsletter
        }, void 0, false, {
            fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-article.tsx",
            lineNumber: 29,
            columnNumber: 12
        }, this);
    }
    if (!me) return null;
    if (collection) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$follow$2f$follow$2d$collection$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            collection: collection
        }, void 0, false, {
            fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-article.tsx",
            lineNumber: 35,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$follow$2f$follow$2d$contributors$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        contributors: contributors.filter((c)=>c.slug)
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/follow/follow-article.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
_s(FollowArticle, "IcyHXW+66He2jKAzHSBWzkmOBcw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMe"]
    ];
});
_c = FollowArticle;
const __TURBOPACK__default__export__ = FollowArticle;
var _c;
__turbopack_context__.k.register(_c, "FollowArticle");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/portable-text/button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/ui/button.tsx [app-client] (ecmascript)");
'use client';
;
;
function Button({ value }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
        asChild: true,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            href: value.url,
            children: value.text
        }, void 0, false, {
            fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/button.tsx",
            lineNumber: 10,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/button.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
_c = Button;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/portable-text/conditional.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Conditional",
    ()=>Conditional
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$render$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/(sanity)/components/portable-text/render.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/context/MeContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function Conditional({ value }) {
    _s();
    const { meLoading, hasAccess } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMe"])();
    if (meLoading) {
        return null;
    }
    // TODO: exhaustively check for conditions
    let conditionIsSatisfied;
    switch(value.present){
        case 'hasAccess':
            conditionIsSatisfied = value._type === 'if' ? hasAccess : !hasAccess;
            break;
        default:
            conditionIsSatisfied = true;
    }
    return conditionIsSatisfied ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f28$sanity$292f$components$2f$portable$2d$text$2f$render$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NestedPortableText"], {
        value: value.body
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/conditional.tsx",
        lineNumber: 23,
        columnNumber: 33
    }, this) : null;
}
_s(Conditional, "q1LeNotZhggoa7EgFcZcoIXY5fc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMe"]
    ];
});
_c = Conditional;
var _c;
__turbopack_context__.k.register(_c, "Conditional");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/portable-text/dynamic-compontent.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DynamicComponent",
    ()=>DynamicComponent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$spinner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/ui/spinner.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$stegaClean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/client/dist/_chunks-es/stegaClean.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/script.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function DynamicComponent({ value }) {
    _s();
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // TODO: figure out where to put tagname
    // TODO: generic shape for component data
    const Component = 'republik-quiz';
    // Attention: JSON is only valid if Sanity Stega chars are removed
    const dataJson = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$client$2f$dist$2f$_chunks$2d$es$2f$stegaClean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stegaClean"])(value.props?.code ?? '{}');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    textStyle: 'sans',
                    color: 'error'
                }),
                children: error
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/dynamic-compontent.tsx",
                lineNumber: 22,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Component, {
                data: dataJson,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                        minHeight: '150px',
                        position: 'relative',
                        display: 'grid',
                        placeContent: 'center'
                    }),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$ui$2f$spinner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Spinner"], {}, void 0, false, {
                        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/dynamic-compontent.tsx",
                        lineNumber: 40,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/dynamic-compontent.tsx",
                    lineNumber: 32,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/dynamic-compontent.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                type: "module",
                src: "https://story-git-migrate-dynamic-components.preview.republik.love/legacy/dynamic-components/quiz/dist/index.mjs",
                // src='http://localhost:3000/legacy/dynamic-components/quiz/dist/index.mjs'
                strategy: "lazyOnload",
                onError: (e)=>{
                    console.error('Dynamic Component could not be loaded', e);
                    setError('Beim Laden dieser Komponente ist ein Fehler aufgetreten.');
                }
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/dynamic-compontent.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/dynamic-compontent.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
_s(DynamicComponent, "A8i/78Fx3FIozbyR2zwnz0NK35o=");
_c = DynamicComponent;
var _c;
__turbopack_context__.k.register(_c, "DynamicComponent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/portable-text/embed-datawrapper.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EmbedDataWrapper",
    ()=>EmbedDataWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-themes/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/script.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cva$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/cva.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/cx.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const figureStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cva$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])({
    base: {
        '& > figcaption': {
            mt: '1'
        }
    },
    variants: {
        size: {
            NORMAL: {},
            BREAKOUT: {
                gridColumn: 'breakout'
            },
            FULL: {
                gridColumn: 'full',
                '& > figcaption': {
                    ml: '4'
                }
            }
        }
    }
});
const styles = {
    hidePrint: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        '@media print': {
            display: 'none'
        }
    }),
    showPrint: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        display: 'none',
        '@media print': {
            display: 'block'
        }
    })
};
function DataWrapperInteractive({ value: { datawrapperId, forceDark = false, size, plain = false } }) {
    _s();
    const chartRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [embedData, setEmbedData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    const [scriptReady, setScriptReady] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { theme: themeSetting, forcedTheme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const theme = forcedTheme ?? themeSetting;
    const idMissing = !datawrapperId;
    // Datawrapper supports true/false/"auto"
    const dark = forceDark || (theme === 'dark' ? true : theme === 'light' ? false : 'auto');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DataWrapperInteractive.useEffect": ()=>{
            setError(undefined);
            const target = chartRef.current;
            if (target) {
                // Remove all children of the target because datawrapper.render() will just append more
                while(target.firstChild){
                    target.removeChild(target.firstChild);
                }
            }
            if (datawrapperId) {
                fetch(`https://datawrapper.dwcdn.net/${datawrapperId}/embed.json`).then({
                    "DataWrapperInteractive.useEffect": (res)=>res.json()
                }["DataWrapperInteractive.useEffect"]).then({
                    "DataWrapperInteractive.useEffect": (data)=>{
                        setEmbedData(data);
                    }
                }["DataWrapperInteractive.useEffect"]).catch({
                    "DataWrapperInteractive.useEffect": (e)=>{
                        setError('Grafik konnte nicht geladen werden');
                        console.error(e);
                    }
                }["DataWrapperInteractive.useEffect"]);
            }
        }
    }["DataWrapperInteractive.useEffect"], [
        datawrapperId
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DataWrapperInteractive.useEffect": ()=>{
            const target = chartRef.current;
            if (embedData && target && scriptReady) {
                // Remove all children of the target because datawrapper.render() will just append more
                while(target.firstChild){
                    target.removeChild(target.firstChild);
                }
                window.datawrapper?.render(embedData, {
                    // the node that will be turned into the web component
                    target,
                    // optionally include flags (e.g dark, fitchart) here
                    // see https://developer.datawrapper.de/docs/render-flags
                    flags: {
                        dark,
                        plain
                    }
                });
            }
        }
    }["DataWrapperInteractive.useEffect"], [
        embedData,
        plain,
        scriptReady,
        dark
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("figure", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cx"])(figureStyle({
            size
        }), styles.hidePrint),
        children: [
            idMissing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    color: 'error',
                    p: '4'
                }),
                children: "Chart-ID fehlt"
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/embed-datawrapper.tsx",
                lineNumber: 115,
                columnNumber: 9
            }, this) : error ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    color: 'error',
                    p: '4'
                }),
                children: error
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/embed-datawrapper.tsx",
                lineNumber: 124,
                columnNumber: 9
            }, this) : null,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: chartRef,
                style: {
                    minHeight: 10
                }
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/embed-datawrapper.tsx",
                lineNumber: 133,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "datawrapper-lib",
                src: "https://datawrapper.dwcdn.net/lib/datawrapper.js",
                onReady: ()=>{
                    setScriptReady(true);
                },
                // Not sure why but onReady isn't always called, so we also use onLoad
                onLoad: ()=>{
                    setScriptReady(true);
                }
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/embed-datawrapper.tsx",
                lineNumber: 134,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/embed-datawrapper.tsx",
        lineNumber: 113,
        columnNumber: 5
    }, this);
}
_s(DataWrapperInteractive, "fjOHIvi9RKddqiNPRI/mRtsV6q0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c = DataWrapperInteractive;
// We use the image instead of the interactive chart for the pdf version
// https://datawrapper.dwcdn.net/DW123ID/full.png -> 600px wide
function DataWrapperPrint({ datawrapperId }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("figure", {
        className: styles.showPrint,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
            width: 600,
            src: `https://datawrapper.dwcdn.net/${datawrapperId}/full.png`
        }, void 0, false, {
            fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/embed-datawrapper.tsx",
            lineNumber: 154,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/embed-datawrapper.tsx",
        lineNumber: 153,
        columnNumber: 5
    }, this);
}
_c1 = DataWrapperPrint;
function EmbedDataWrapper({ value }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DataWrapperInteractive, {
                value: value
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/embed-datawrapper.tsx",
                lineNumber: 165,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DataWrapperPrint, {
                datawrapperId: value.datawrapperId
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/(sanity)/components/portable-text/embed-datawrapper.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_c2 = EmbedDataWrapper;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "DataWrapperInteractive");
__turbopack_context__.k.register(_c1, "DataWrapperPrint");
__turbopack_context__.k.register(_c2, "EmbedDataWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/(sanity)/components/portable-text/variable.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Variable",
    ()=>Variable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/context/MeContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function Variable({ value }) {
    _s();
    const { meLoading, me } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMe"])();
    if (meLoading) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: me?.[value.name]
    }, void 0, false);
}
_s(Variable, "laHVlY8EJxUKdmMzSFMcXpO3nWk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMe"]
    ];
});
_c = Variable;
var _c;
__turbopack_context__.k.register(_c, "Variable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# debugId=07769603-3b39-ccc8-1b9c-de719d5442e2
//# sourceMappingURL=apps_www_src_018x73x._.js.map