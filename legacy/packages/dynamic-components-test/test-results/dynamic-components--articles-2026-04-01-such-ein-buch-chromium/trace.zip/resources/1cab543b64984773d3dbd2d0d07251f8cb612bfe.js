;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="393a6bd2-097b-956d-a8e5-547d586586b7")}catch(e){}}();
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@sanity/ui/dist/theme.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "COLOR_CONFIG_AVATAR_COLORS",
    ()=>COLOR_CONFIG_AVATAR_COLORS,
    "COLOR_CONFIG_BLEND_KEYS",
    ()=>COLOR_CONFIG_BLEND_KEYS,
    "COLOR_CONFIG_CARD_KEYS",
    ()=>COLOR_CONFIG_CARD_KEYS,
    "COLOR_CONFIG_CARD_TONES",
    ()=>COLOR_CONFIG_CARD_TONES,
    "COLOR_CONFIG_INPUT_MODES",
    ()=>COLOR_CONFIG_INPUT_MODES,
    "COLOR_CONFIG_INPUT_STATES",
    ()=>COLOR_CONFIG_INPUT_STATES,
    "COLOR_CONFIG_STATES",
    ()=>COLOR_CONFIG_STATES,
    "COLOR_CONFIG_STATE_KEYS",
    ()=>COLOR_CONFIG_STATE_KEYS,
    "COLOR_CONFIG_STATE_TONES",
    ()=>COLOR_CONFIG_STATE_TONES,
    "THEME_COLOR_AVATAR_COLORS",
    ()=>THEME_COLOR_AVATAR_COLORS,
    "THEME_COLOR_BLEND_MODES",
    ()=>THEME_COLOR_BLEND_MODES,
    "THEME_COLOR_BUTTON_MODES",
    ()=>THEME_COLOR_BUTTON_MODES,
    "THEME_COLOR_CARD_TONES",
    ()=>THEME_COLOR_CARD_TONES,
    "THEME_COLOR_INPUT_MODES",
    ()=>THEME_COLOR_INPUT_MODES,
    "THEME_COLOR_INPUT_STATES",
    ()=>THEME_COLOR_INPUT_STATES,
    "THEME_COLOR_SCHEMES",
    ()=>THEME_COLOR_SCHEMES,
    "THEME_COLOR_STATES",
    ()=>THEME_COLOR_STATES,
    "THEME_COLOR_STATE_TONES",
    ()=>THEME_COLOR_STATE_TONES,
    "buildTheme",
    ()=>buildTheme,
    "createColorTheme",
    ()=>createColorTheme,
    "getContrastRatio",
    ()=>getContrastRatio,
    "getScopedTheme",
    ()=>getScopedTheme,
    "getTheme_v2",
    ()=>getTheme_v2,
    "hexToRgb",
    ()=>hexToRgb,
    "hslToRgb",
    ()=>hslToRgb,
    "isColorBlendModeValue",
    ()=>isColorBlendModeValue,
    "isColorButtonMode",
    ()=>isColorButtonMode,
    "isColorConfigBaseKey",
    ()=>isColorConfigBaseKey,
    "isColorConfigBaseTone",
    ()=>isColorConfigBaseTone,
    "isColorConfigBlendKey",
    ()=>isColorConfigBlendKey,
    "isColorConfigStateKey",
    ()=>isColorConfigStateKey,
    "isColorConfigStateTone",
    ()=>isColorConfigStateTone,
    "isColorHueKey",
    ()=>isColorHueKey,
    "isColorOpacityValue",
    ()=>isColorOpacityValue,
    "isColorTintKey",
    ()=>isColorTintKey,
    "isColorTokenValue",
    ()=>isColorTokenValue,
    "isColorValue",
    ()=>isColorValue,
    "is_v0",
    ()=>is_v0,
    "is_v2",
    ()=>is_v2,
    "mix",
    ()=>mix,
    "multiply",
    ()=>multiply,
    "parseColor",
    ()=>parseColor,
    "parseTokenKey",
    ()=>parseTokenKey,
    "parseTokenValue",
    ()=>parseTokenValue,
    "rgbToHex",
    ()=>rgbToHex,
    "rgbToHsl",
    ()=>rgbToHsl,
    "rgba",
    ()=>rgba,
    "rgbaToRGBA",
    ()=>rgbaToRGBA,
    "screen",
    ()=>screen,
    "v0_v2",
    ()=>v0_v2,
    "v2_v0",
    ()=>v2_v0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$color$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/color/dist/index.js [app-client] (ecmascript)");
;
function createSelectableTones(opts, base, dark, solid, muted) {
    return {
        default: _createSelectableStates(opts, base, dark, solid, muted, "default"),
        primary: _createSelectableStates(opts, base, dark, solid, muted, "primary"),
        positive: _createSelectableStates(opts, base, dark, solid, muted, "positive"),
        caution: _createSelectableStates(opts, base, dark, solid, muted, "caution"),
        critical: _createSelectableStates(opts, base, dark, solid, muted, "critical")
    };
}
function _createSelectableStates(opts, base, dark, solid, muted, tone) {
    return {
        enabled: opts.selectable({
            base,
            dark,
            solid,
            muted,
            state: "enabled",
            tone
        }),
        hovered: opts.selectable({
            base,
            dark,
            solid,
            muted,
            state: "hovered",
            tone
        }),
        pressed: opts.selectable({
            base,
            dark,
            solid,
            muted,
            state: "pressed",
            tone
        }),
        selected: opts.selectable({
            base,
            dark,
            solid,
            muted,
            state: "selected",
            tone
        }),
        disabled: opts.selectable({
            base,
            dark,
            solid,
            muted,
            state: "disabled",
            tone
        })
    };
}
function createSolidTones(opts, base, dark, name) {
    return {
        default: {
            enabled: opts.solid({
                base,
                dark,
                tone: "default",
                name,
                state: "enabled"
            }),
            disabled: opts.solid({
                base,
                dark,
                tone: "default",
                name,
                state: "disabled"
            }),
            hovered: opts.solid({
                base,
                dark,
                tone: "default",
                name,
                state: "hovered"
            }),
            pressed: opts.solid({
                base,
                dark,
                tone: "default",
                name,
                state: "pressed"
            }),
            selected: opts.solid({
                base,
                dark,
                tone: "default",
                name,
                state: "selected"
            })
        },
        transparent: {
            enabled: opts.solid({
                base,
                dark,
                tone: "transparent",
                name,
                state: "enabled"
            }),
            disabled: opts.solid({
                base,
                dark,
                tone: "transparent",
                name,
                state: "disabled"
            }),
            hovered: opts.solid({
                base,
                dark,
                tone: "transparent",
                name,
                state: "hovered"
            }),
            pressed: opts.solid({
                base,
                dark,
                tone: "transparent",
                name,
                state: "pressed"
            }),
            selected: opts.solid({
                base,
                dark,
                tone: "transparent",
                name,
                state: "selected"
            })
        },
        primary: {
            enabled: opts.solid({
                base,
                dark,
                tone: "primary",
                name,
                state: "enabled"
            }),
            disabled: opts.solid({
                base,
                dark,
                tone: "primary",
                name,
                state: "disabled"
            }),
            hovered: opts.solid({
                base,
                dark,
                tone: "primary",
                name,
                state: "hovered"
            }),
            pressed: opts.solid({
                base,
                dark,
                tone: "primary",
                name,
                state: "pressed"
            }),
            selected: opts.solid({
                base,
                dark,
                tone: "primary",
                name,
                state: "selected"
            })
        },
        positive: {
            enabled: opts.solid({
                base,
                dark,
                tone: "positive",
                name,
                state: "enabled"
            }),
            disabled: opts.solid({
                base,
                dark,
                tone: "positive",
                name,
                state: "disabled"
            }),
            hovered: opts.solid({
                base,
                dark,
                tone: "positive",
                name,
                state: "hovered"
            }),
            pressed: opts.solid({
                base,
                dark,
                tone: "positive",
                name,
                state: "pressed"
            }),
            selected: opts.solid({
                base,
                dark,
                tone: "positive",
                name,
                state: "selected"
            })
        },
        caution: {
            enabled: opts.solid({
                base,
                dark,
                tone: "caution",
                name,
                state: "enabled"
            }),
            disabled: opts.solid({
                base,
                dark,
                tone: "caution",
                name,
                state: "disabled"
            }),
            hovered: opts.solid({
                base,
                dark,
                tone: "caution",
                name,
                state: "hovered"
            }),
            pressed: opts.solid({
                base,
                dark,
                tone: "caution",
                name,
                state: "pressed"
            }),
            selected: opts.solid({
                base,
                dark,
                tone: "caution",
                name,
                state: "selected"
            })
        },
        critical: {
            enabled: opts.solid({
                base,
                dark,
                tone: "critical",
                name,
                state: "enabled"
            }),
            disabled: opts.solid({
                base,
                dark,
                tone: "critical",
                name,
                state: "disabled"
            }),
            hovered: opts.solid({
                base,
                dark,
                tone: "critical",
                name,
                state: "hovered"
            }),
            pressed: opts.solid({
                base,
                dark,
                tone: "critical",
                name,
                state: "pressed"
            }),
            selected: opts.solid({
                base,
                dark,
                tone: "critical",
                name,
                state: "selected"
            })
        }
    };
}
function createButtonTones(opts, base, dark, solid, muted, mode) {
    return {
        default: opts.button({
            base,
            dark,
            solid: solid.default,
            muted: muted.default,
            mode
        }),
        primary: opts.button({
            base,
            dark,
            solid: solid.primary,
            muted: muted.primary,
            mode
        }),
        positive: opts.button({
            base,
            dark,
            solid: solid.positive,
            muted: muted.positive,
            mode
        }),
        caution: opts.button({
            base,
            dark,
            solid: solid.caution,
            muted: muted.caution,
            mode
        }),
        critical: opts.button({
            base,
            dark,
            solid: solid.critical,
            muted: muted.critical,
            mode
        })
    };
}
function createButtonModes(opts, base, dark, solid, muted) {
    return {
        default: createButtonTones(opts, base, dark, solid, muted, "default"),
        ghost: createButtonTones(opts, base, dark, solid, muted, "ghost"),
        bleed: createButtonTones(opts, base, dark, solid, muted, "bleed")
    };
}
function createCardStates(opts, base, dark, name, solid, muted) {
    return {
        enabled: opts.card({
            base,
            dark,
            name,
            state: "enabled",
            solid,
            muted
        }),
        disabled: opts.card({
            base,
            dark,
            name,
            state: "disabled",
            solid,
            muted
        }),
        hovered: opts.card({
            base,
            dark,
            name,
            state: "hovered",
            solid,
            muted
        }),
        pressed: opts.card({
            base,
            dark,
            name,
            state: "pressed",
            solid,
            muted
        }),
        selected: opts.card({
            base,
            dark,
            name,
            state: "selected",
            solid,
            muted
        })
    };
}
const black = "hsl(0, 0%, 0%)", white = "hsl(0, 0%, 100%)", colors = {
    default: {
        lightest: "hsl(0, 0%, 95%)",
        lighter: "hsl(0, 0%, 70%)",
        light: "hsl(0, 0%, 65%)",
        base: "hsl(0, 0%, 50%)",
        dark: "hsl(0, 0%, 35%)",
        darker: "hsl(0, 0%, 20%)",
        darkest: "hsl(0, 0%, 5%)"
    },
    transparent: {
        lightest: "hsl(240, 100%, 95%)",
        lighter: "hsl(240, 100%, 70%)",
        light: "hsl(240, 100%, 65%)",
        base: "hsl(240, 100%, 50%)",
        dark: "hsl(240, 100%, 35%)",
        darker: "hsl(240, 100%, 20%)",
        darkest: "hsl(240, 100%, 5%)"
    },
    primary: {
        lightest: "hsl(240, 100%, 95%)",
        lighter: "hsl(240, 100%, 70%)",
        light: "hsl(240, 100%, 65%)",
        base: "hsl(240, 100%, 50%)",
        dark: "hsl(240, 100%, 35%)",
        darker: "hsl(240, 100%, 20%)",
        darkest: "hsl(240, 100%, 5%)"
    },
    positive: {
        lightest: "hsl(120, 100%, 95%)",
        lighter: "hsl(120, 100%, 70%)",
        light: "hsl(120, 100%, 65%)",
        base: "hsl(120, 100%, 50%)",
        dark: "hsl(120, 100%, 35%)",
        darker: "hsl(120, 100%, 20%)",
        darkest: "hsl(120, 100%, 5%)"
    },
    caution: {
        lightest: "hsl(60, 100%, 95%)",
        lighter: "hsl(60, 100%, 70%)",
        light: "hsl(60, 100%, 65%)",
        base: "hsl(60, 100%, 50%)",
        dark: "hsl(60, 100%, 35%)",
        darker: "hsl(60, 100%, 20%)",
        darkest: "hsl(60, 100%, 5%)"
    },
    critical: {
        lightest: "hsl(0, 100%, 95%)",
        lighter: "hsl(0, 100%, 70%)",
        light: "hsl(0, 100%, 65%)",
        base: "hsl(0, 100%, 50%)",
        dark: "hsl(0, 100%, 35%)",
        darker: "hsl(0, 100%, 20%)",
        darkest: "hsl(0, 100%, 5%)"
    }
}, spots = {
    gray: "hsl(0, 0%, 50%)",
    red: "hsl(0, 100%, 50%)",
    orange: "hsl(30, 100%, 50%)",
    yellow: "hsl(60, 100%, 50%)",
    green: "hsl(120, 100%, 50%)",
    cyan: "hsl(180, 100%, 50%)",
    blue: "hsl(240, 100%, 50%)",
    purple: "hsl(270, 100%, 50%)",
    magenta: "hsl(300, 100%, 50%)"
}, tones = {
    transparent: {
        bg: [
            colors.transparent.darkest,
            colors.transparent.lightest
        ],
        fg: [
            colors.transparent.lightest,
            colors.transparent.darkest
        ],
        border: [
            colors.transparent.darker,
            colors.transparent.lighter
        ],
        focusRing: [
            colors.transparent.base,
            colors.transparent.base
        ]
    },
    primary: {
        bg: [
            colors.primary.darkest,
            colors.primary.lightest
        ],
        fg: [
            colors.primary.lightest,
            colors.primary.darkest
        ],
        border: [
            colors.primary.darker,
            colors.primary.lighter
        ],
        focusRing: [
            colors.primary.base,
            colors.primary.base
        ]
    },
    positive: {
        bg: [
            colors.positive.darkest,
            colors.positive.lightest
        ],
        fg: [
            colors.positive.lightest,
            colors.positive.darkest
        ],
        border: [
            colors.positive.darker,
            colors.positive.lighter
        ],
        focusRing: [
            colors.positive.base,
            colors.positive.base
        ]
    },
    caution: {
        bg: [
            colors.caution.darkest,
            colors.caution.lightest
        ],
        fg: [
            colors.caution.lightest,
            colors.caution.darkest
        ],
        border: [
            colors.caution.darker,
            colors.caution.lighter
        ],
        focusRing: [
            colors.caution.base,
            colors.caution.base
        ]
    },
    critical: {
        bg: [
            colors.critical.darkest,
            colors.critical.lightest
        ],
        fg: [
            colors.critical.lightest,
            colors.critical.darkest
        ],
        border: [
            colors.critical.darker,
            colors.critical.lighter
        ],
        focusRing: [
            colors.critical.base,
            colors.critical.base
        ]
    }
}, defaultOpts = {
    base: ({ dark, name })=>name === "default" ? {
            bg: dark ? black : white,
            fg: dark ? white : black,
            border: dark ? colors.default.darkest : colors.default.lightest,
            focusRing: colors.primary.base,
            shadow: {
                outline: black,
                umbra: black,
                penumbra: black,
                ambient: black
            },
            skeleton: {
                from: dark ? white : black,
                to: dark ? white : black
            }
        } : {
            bg: tones[name].bg[dark ? 0 : 1],
            fg: tones[name].fg[dark ? 0 : 1],
            border: tones[name].border[dark ? 0 : 1],
            focusRing: tones[name].focusRing[dark ? 0 : 1],
            shadow: {
                outline: black,
                umbra: black,
                penumbra: black,
                ambient: black
            },
            skeleton: {
                from: dark ? white : black,
                to: dark ? white : black
            }
        },
    solid: ({ base, dark, state, tone })=>{
        const color2 = colors[tone];
        return state === "hovered" ? {
            bg: dark ? color2.light : color2.dark,
            bg2: dark ? color2.light : color2.dark,
            border: dark ? color2.lighter : color2.darker,
            fg: dark ? color2.darkest : color2.lightest,
            icon: dark ? color2.darkest : color2.lightest,
            muted: {
                fg: black
            },
            accent: {
                fg: black
            },
            link: {
                fg: black
            },
            code: {
                bg: black,
                fg: black
            },
            skeleton: base.skeleton
        } : {
            bg: color2.base,
            bg2: color2.base,
            border: dark ? color2.light : color2.dark,
            fg: dark ? color2.darkest : color2.lightest,
            icon: dark ? color2.darkest : color2.lightest,
            muted: {
                fg: black
            },
            accent: {
                fg: black
            },
            link: {
                fg: black
            },
            code: {
                bg: black,
                fg: black
            },
            skeleton: base.skeleton
        };
    },
    muted: ({ base, dark, state, tone })=>{
        const color2 = colors[tone];
        return state === "hovered" ? {
            bg: dark ? color2.darker : color2.lighter,
            bg2: dark ? color2.darker : color2.lighter,
            border: dark ? color2.lighter : color2.darker,
            fg: dark ? color2.lightest : color2.darkest,
            icon: dark ? color2.lightest : color2.darkest,
            muted: {
                fg: black
            },
            accent: {
                fg: black
            },
            link: {
                fg: black
            },
            code: {
                bg: black,
                fg: black
            },
            skeleton: base.skeleton
        } : {
            bg: dark ? color2.darkest : color2.lightest,
            bg2: dark ? color2.darkest : color2.lightest,
            border: dark ? color2.darker : color2.lighter,
            fg: dark ? color2.lighter : color2.darker,
            icon: dark ? color2.lighter : color2.darker,
            muted: {
                fg: black
            },
            accent: {
                fg: black
            },
            link: {
                fg: black
            },
            code: {
                bg: black,
                fg: black
            },
            skeleton: base.skeleton
        };
    },
    button: ({ base, mode, muted, solid })=>mode === "bleed" ? {
            ...muted,
            enabled: {
                bg: "transparent",
                bg2: "transparent",
                fg: muted.enabled.fg,
                icon: muted.enabled.fg,
                border: "transparent",
                muted: {
                    fg: black
                },
                accent: {
                    fg: black
                },
                link: {
                    fg: black
                },
                code: {
                    bg: black,
                    fg: black
                },
                skeleton: base.skeleton
            },
            hovered: {
                bg: muted.enabled.bg,
                bg2: muted.enabled.bg,
                fg: muted.hovered.fg,
                icon: muted.hovered.fg,
                border: "transparent",
                muted: {
                    fg: black
                },
                accent: {
                    fg: black
                },
                link: {
                    fg: black
                },
                code: {
                    bg: black,
                    fg: black
                },
                skeleton: base.skeleton
            }
        } : mode === "ghost" ? {
            ...solid,
            enabled: muted.enabled
        } : solid,
    card: ({ base })=>({
            bg: black,
            bg2: black,
            fg: black,
            icon: black,
            border: black,
            muted: {
                fg: black
            },
            accent: {
                fg: black
            },
            link: {
                fg: black
            },
            code: {
                bg: black,
                fg: black
            },
            skeleton: base.skeleton
        }),
    input: ()=>({
            bg: black,
            bg2: black,
            fg: black,
            border: black,
            placeholder: black
        }),
    selectable: ({ muted, state, tone })=>muted[tone][state],
    spot: ({ key })=>spots[key],
    syntax: ()=>({
            atrule: black,
            attrName: black,
            attrValue: black,
            attribute: black,
            boolean: black,
            builtin: black,
            cdata: black,
            char: black,
            class: black,
            className: black,
            comment: black,
            constant: black,
            deleted: black,
            doctype: black,
            entity: black,
            function: black,
            hexcode: black,
            id: black,
            important: black,
            inserted: black,
            keyword: black,
            number: black,
            operator: black,
            prolog: black,
            property: black,
            pseudoClass: black,
            pseudoElement: black,
            punctuation: black,
            regex: black,
            selector: black,
            string: black,
            symbol: black,
            tag: black,
            unit: black,
            url: black,
            variable: black
        })
};
function createInputModes(opts, base, dark, solid, muted) {
    return {
        default: {
            enabled: opts.input({
                base,
                dark,
                mode: "default",
                state: "enabled",
                solid: solid.default,
                muted: muted.default
            }),
            disabled: opts.input({
                base,
                dark,
                mode: "default",
                state: "disabled",
                solid: solid.default,
                muted: muted.default
            }),
            hovered: opts.input({
                base,
                dark,
                mode: "default",
                state: "hovered",
                solid: solid.default,
                muted: muted.default
            }),
            readOnly: opts.input({
                base,
                dark,
                mode: "default",
                state: "readOnly",
                solid: solid.default,
                muted: muted.default
            })
        },
        invalid: {
            enabled: opts.input({
                base,
                dark,
                mode: "invalid",
                state: "enabled",
                solid: solid.default,
                muted: muted.default
            }),
            disabled: opts.input({
                base,
                dark,
                mode: "invalid",
                state: "disabled",
                solid: solid.default,
                muted: muted.default
            }),
            hovered: opts.input({
                base,
                dark,
                mode: "invalid",
                state: "hovered",
                solid: solid.default,
                muted: muted.default
            }),
            readOnly: opts.input({
                base,
                dark,
                mode: "invalid",
                state: "readOnly",
                solid: solid.default,
                muted: muted.default
            })
        }
    };
}
function createMutedTones(opts, base, dark, name) {
    return {
        default: {
            enabled: opts.muted({
                base,
                dark,
                tone: "default",
                name,
                state: "enabled"
            }),
            disabled: opts.muted({
                base,
                dark,
                tone: "default",
                name,
                state: "disabled"
            }),
            hovered: opts.muted({
                base,
                dark,
                tone: "default",
                name,
                state: "hovered"
            }),
            pressed: opts.muted({
                base,
                dark,
                tone: "default",
                name,
                state: "pressed"
            }),
            selected: opts.muted({
                base,
                dark,
                tone: "default",
                name,
                state: "selected"
            })
        },
        transparent: {
            enabled: opts.muted({
                base,
                dark,
                tone: "transparent",
                name,
                state: "enabled"
            }),
            disabled: opts.muted({
                base,
                dark,
                tone: "transparent",
                name,
                state: "disabled"
            }),
            hovered: opts.muted({
                base,
                dark,
                tone: "transparent",
                name,
                state: "hovered"
            }),
            pressed: opts.muted({
                base,
                dark,
                tone: "transparent",
                name,
                state: "pressed"
            }),
            selected: opts.muted({
                base,
                dark,
                tone: "transparent",
                name,
                state: "selected"
            })
        },
        primary: {
            enabled: opts.muted({
                base,
                dark,
                tone: "primary",
                name,
                state: "enabled"
            }),
            disabled: opts.muted({
                base,
                dark,
                tone: "primary",
                name,
                state: "disabled"
            }),
            hovered: opts.muted({
                base,
                dark,
                tone: "primary",
                name,
                state: "hovered"
            }),
            pressed: opts.muted({
                base,
                dark,
                tone: "primary",
                name,
                state: "pressed"
            }),
            selected: opts.muted({
                base,
                dark,
                tone: "primary",
                name,
                state: "selected"
            })
        },
        positive: {
            enabled: opts.muted({
                base,
                dark,
                tone: "positive",
                name,
                state: "enabled"
            }),
            disabled: opts.muted({
                base,
                dark,
                tone: "positive",
                name,
                state: "disabled"
            }),
            hovered: opts.muted({
                base,
                dark,
                tone: "positive",
                name,
                state: "hovered"
            }),
            pressed: opts.muted({
                base,
                dark,
                tone: "positive",
                name,
                state: "pressed"
            }),
            selected: opts.muted({
                base,
                dark,
                tone: "positive",
                name,
                state: "selected"
            })
        },
        caution: {
            enabled: opts.muted({
                base,
                dark,
                tone: "caution",
                name,
                state: "enabled"
            }),
            disabled: opts.muted({
                base,
                dark,
                tone: "caution",
                name,
                state: "disabled"
            }),
            hovered: opts.muted({
                base,
                dark,
                tone: "caution",
                name,
                state: "hovered"
            }),
            pressed: opts.muted({
                base,
                dark,
                tone: "caution",
                name,
                state: "pressed"
            }),
            selected: opts.muted({
                base,
                dark,
                tone: "caution",
                name,
                state: "selected"
            })
        },
        critical: {
            enabled: opts.muted({
                base,
                dark,
                tone: "critical",
                name,
                state: "enabled"
            }),
            disabled: opts.muted({
                base,
                dark,
                tone: "critical",
                name,
                state: "disabled"
            }),
            hovered: opts.muted({
                base,
                dark,
                tone: "critical",
                name,
                state: "hovered"
            }),
            pressed: opts.muted({
                base,
                dark,
                tone: "critical",
                name,
                state: "pressed"
            }),
            selected: opts.muted({
                base,
                dark,
                tone: "critical",
                name,
                state: "selected"
            })
        }
    };
}
function createSpot(opts, base, dark) {
    return {
        gray: opts.spot({
            base,
            dark,
            key: "gray"
        }),
        blue: opts.spot({
            base,
            dark,
            key: "blue"
        }),
        purple: opts.spot({
            base,
            dark,
            key: "purple"
        }),
        magenta: opts.spot({
            base,
            dark,
            key: "magenta"
        }),
        red: opts.spot({
            base,
            dark,
            key: "red"
        }),
        orange: opts.spot({
            base,
            dark,
            key: "orange"
        }),
        yellow: opts.spot({
            base,
            dark,
            key: "yellow"
        }),
        green: opts.spot({
            base,
            dark,
            key: "green"
        }),
        cyan: opts.spot({
            base,
            dark,
            key: "cyan"
        })
    };
}
function createColorTheme(partialOpts = {}) {
    const builders = {
        ...defaultOpts,
        ...partialOpts
    };
    return {
        light: _createColorScheme(builders, !1),
        dark: _createColorScheme(builders, !0)
    };
}
function _createColorScheme(opts, dark) {
    return {
        default: _createColor(opts, dark, "default"),
        transparent: _createColor(opts, dark, "transparent"),
        primary: _createColor(opts, dark, "primary"),
        positive: _createColor(opts, dark, "positive"),
        caution: _createColor(opts, dark, "caution"),
        critical: _createColor(opts, dark, "critical")
    };
}
function _createColor(opts, dark, name) {
    const base = opts.base({
        dark,
        name
    }), solid = createSolidTones(opts, base, dark, name), muted = createMutedTones(opts, base, dark, name);
    return {
        base,
        button: createButtonModes(opts, base, dark, solid, muted),
        card: createCardStates(opts, base, dark, name, solid, muted),
        dark,
        input: createInputModes(opts, base, dark, solid, muted),
        selectable: createSelectableTones(opts, base, dark, solid, muted),
        spot: createSpot(opts, base, dark),
        syntax: opts.syntax({
            base,
            dark
        }),
        solid,
        muted
    };
}
const defaultThemeConfig = {
    avatar: {
        sizes: [
            {
                distance: -4,
                size: 19
            },
            {
                distance: -4,
                size: 25
            },
            {
                distance: -8,
                size: 33
            },
            {
                distance: -12,
                size: 49
            }
        ],
        focusRing: {
            offset: 1,
            width: 1
        }
    },
    button: {
        textWeight: "medium",
        border: {
            width: 1
        },
        focusRing: {
            offset: -1,
            width: 1
        }
    },
    card: {
        border: {
            width: 1
        },
        focusRing: {
            offset: -1,
            width: 1
        },
        shadow: {
            outline: 0.5
        }
    },
    container: [
        320,
        640,
        960,
        1280,
        1600,
        1920
    ],
    media: [
        360,
        600,
        900,
        1200,
        1800,
        2400
    ],
    layer: {
        dialog: {
            zOffset: 600
        },
        popover: {
            zOffset: 400
        },
        tooltip: {
            zOffset: 200
        }
    },
    radius: [
        0,
        1,
        3,
        6,
        9,
        12,
        21
    ],
    shadow: [
        null,
        {
            umbra: [
                0,
                0,
                0,
                0
            ],
            penumbra: [
                0,
                0,
                0,
                0
            ],
            ambient: [
                0,
                0,
                0,
                0
            ]
        },
        {
            umbra: [
                0,
                3,
                5,
                -2
            ],
            penumbra: [
                0,
                6,
                10,
                0
            ],
            ambient: [
                0,
                1,
                18,
                1
            ]
        },
        {
            umbra: [
                0,
                7,
                8,
                -4
            ],
            penumbra: [
                0,
                12,
                17,
                2
            ],
            ambient: [
                0,
                5,
                22,
                4
            ]
        },
        {
            umbra: [
                0,
                9,
                11,
                -5
            ],
            penumbra: [
                0,
                18,
                28,
                2
            ],
            ambient: [
                0,
                7,
                34,
                6
            ]
        },
        {
            umbra: [
                0,
                11,
                15,
                -7
            ],
            penumbra: [
                0,
                24,
                38,
                3
            ],
            ambient: [
                0,
                9,
                46,
                8
            ]
        }
    ],
    space: [
        0,
        4,
        8,
        12,
        20,
        32,
        52,
        84,
        136,
        220
    ],
    input: {
        border: {
            width: 1
        },
        checkbox: {
            size: 17,
            focusRing: {
                offset: -1,
                width: 1
            }
        },
        radio: {
            size: 17,
            markSize: 9,
            focusRing: {
                offset: -1,
                width: 1
            }
        },
        switch: {
            width: 25,
            height: 17,
            padding: 5,
            transitionDurationMs: 150,
            transitionTimingFunction: "ease-out",
            focusRing: {
                offset: 1,
                width: 1
            }
        },
        select: {
            focusRing: {
                offset: -1,
                width: 1
            }
        },
        text: {
            focusRing: {
                offset: -1,
                width: 1
            }
        }
    },
    style: {
        button: {
            root: {
                transition: "background-color 100ms,border-color 100ms,color 100ms"
            }
        }
    }
}, defaultThemeFonts = {
    code: {
        family: "ui-monospace, SFMono-Regular, SF Mono, Menlo, Consolas, Liberation Mono, monospace",
        weights: {
            regular: 400,
            medium: 500,
            semibold: 600,
            bold: 700
        },
        sizes: [
            {
                ascenderHeight: 4,
                descenderHeight: 4,
                fontSize: 10,
                iconSize: 17,
                lineHeight: 15,
                letterSpacing: 0
            },
            {
                ascenderHeight: 5,
                descenderHeight: 5,
                fontSize: 13,
                iconSize: 21,
                lineHeight: 19,
                letterSpacing: 0
            },
            {
                ascenderHeight: 6,
                descenderHeight: 6,
                fontSize: 16,
                iconSize: 25,
                lineHeight: 23,
                letterSpacing: 0
            },
            {
                ascenderHeight: 7,
                descenderHeight: 7,
                fontSize: 19,
                iconSize: 29,
                lineHeight: 27,
                letterSpacing: 0
            },
            {
                ascenderHeight: 8,
                descenderHeight: 8,
                fontSize: 22,
                iconSize: 33,
                lineHeight: 31,
                letterSpacing: 0
            }
        ]
    },
    heading: {
        family: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", "Liberation Sans", Helvetica, Arial, system-ui, sans-serif',
        weights: {
            regular: 700,
            medium: 800,
            semibold: 900,
            bold: 900
        },
        sizes: [
            {
                ascenderHeight: 5,
                descenderHeight: 5,
                fontSize: 13,
                iconSize: 17,
                lineHeight: 19,
                letterSpacing: 0
            },
            {
                ascenderHeight: 6,
                descenderHeight: 6,
                fontSize: 16,
                iconSize: 25,
                lineHeight: 23,
                letterSpacing: 0
            },
            {
                ascenderHeight: 7,
                descenderHeight: 7,
                fontSize: 21,
                iconSize: 33,
                lineHeight: 29,
                letterSpacing: 0
            },
            {
                ascenderHeight: 8,
                descenderHeight: 8,
                fontSize: 27,
                iconSize: 41,
                lineHeight: 35,
                letterSpacing: 0
            },
            {
                ascenderHeight: 9.5,
                descenderHeight: 8.5,
                fontSize: 33,
                iconSize: 49,
                lineHeight: 41,
                letterSpacing: 0
            },
            {
                ascenderHeight: 10.5,
                descenderHeight: 9.5,
                fontSize: 38,
                iconSize: 53,
                lineHeight: 47,
                letterSpacing: 0
            }
        ]
    },
    label: {
        family: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", "Liberation Sans", system-ui, sans-serif',
        weights: {
            regular: 600,
            medium: 700,
            semibold: 800,
            bold: 900
        },
        sizes: [
            {
                ascenderHeight: 2,
                descenderHeight: 2,
                fontSize: 8.1,
                iconSize: 13,
                lineHeight: 10,
                letterSpacing: 0.5
            },
            {
                ascenderHeight: 2,
                descenderHeight: 2,
                fontSize: 9.5,
                iconSize: 15,
                lineHeight: 11,
                letterSpacing: 0.5
            },
            {
                ascenderHeight: 2,
                descenderHeight: 2,
                fontSize: 10.8,
                iconSize: 17,
                lineHeight: 12,
                letterSpacing: 0.5
            },
            {
                ascenderHeight: 2,
                descenderHeight: 2,
                fontSize: 12.25,
                iconSize: 19,
                lineHeight: 13,
                letterSpacing: 0.5
            },
            {
                ascenderHeight: 2,
                descenderHeight: 2,
                fontSize: 13.6,
                iconSize: 21,
                lineHeight: 14,
                letterSpacing: 0.5
            },
            {
                ascenderHeight: 2,
                descenderHeight: 2,
                fontSize: 15,
                iconSize: 23,
                lineHeight: 15,
                letterSpacing: 0.5
            }
        ]
    },
    text: {
        family: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", "Liberation Sans", Helvetica, Arial, system-ui, sans-serif',
        weights: {
            regular: 400,
            medium: 500,
            semibold: 600,
            bold: 700
        },
        sizes: [
            {
                ascenderHeight: 4,
                descenderHeight: 4,
                fontSize: 10,
                iconSize: 17,
                lineHeight: 15,
                letterSpacing: 0
            },
            {
                ascenderHeight: 5,
                descenderHeight: 5,
                fontSize: 13,
                iconSize: 21,
                lineHeight: 19,
                letterSpacing: 0
            },
            {
                ascenderHeight: 6,
                descenderHeight: 6,
                fontSize: 15,
                iconSize: 25,
                lineHeight: 23,
                letterSpacing: 0
            },
            {
                ascenderHeight: 7,
                descenderHeight: 7,
                fontSize: 18,
                iconSize: 29,
                lineHeight: 27,
                letterSpacing: 0
            },
            {
                ascenderHeight: 8,
                descenderHeight: 8,
                fontSize: 21,
                iconSize: 33,
                lineHeight: 31,
                letterSpacing: 0
            }
        ]
    }
}, cache$4 = /* @__PURE__ */ new WeakMap();
function themeColor_v0_v2(color_v0) {
    const cached_v2 = cache$4.get(color_v0);
    if (cached_v2) return cached_v2;
    const base = stateThemeColor_v0_v2(color_v0, color_v0.card.enabled), color_v2 = {
        _blend: color_v0._blend || (color_v0.dark ? "screen" : "multiply"),
        _dark: color_v0.dark,
        accent: base.accent,
        avatar: base.avatar,
        backdrop: color_v0.base.shadow.ambient,
        badge: base.badge,
        bg: color_v0.base.bg,
        border: color_v0.base.border,
        button: {
            default: stateTonesThemeColor_v0_v2(color_v0, color_v0.button.default),
            ghost: stateTonesThemeColor_v0_v2(color_v0, color_v0.button.ghost),
            bleed: stateTonesThemeColor_v0_v2(color_v0, color_v0.button.bleed)
        },
        code: base.code,
        fg: color_v0.base.fg,
        focusRing: color_v0.base.focusRing,
        icon: base.muted.fg,
        input: {
            default: inputStatesThemeColor_v0_v2(color_v0.input.default),
            invalid: inputStatesThemeColor_v0_v2(color_v0.input.invalid)
        },
        kbd: base.kbd,
        link: base.link,
        muted: {
            ...base.muted,
            bg: color_v0.selectable?.default.enabled.bg2 || color_v0.base.bg
        },
        selectable: stateTonesThemeColor_v0_v2(color_v0, color_v0.selectable || color_v0.muted),
        shadow: color_v0.base.shadow,
        skeleton: {
            from: color_v0.skeleton?.from || color_v0.base.border,
            to: color_v0.skeleton?.to || color_v0.base.border
        },
        syntax: color_v0.syntax
    };
    return cache$4.set(color_v0, color_v2), color_v2;
}
function stateTonesThemeColor_v0_v2(v0, t) {
    return {
        default: {
            enabled: stateThemeColor_v0_v2(v0, t.default.enabled),
            hovered: stateThemeColor_v0_v2(v0, t.default.hovered),
            pressed: stateThemeColor_v0_v2(v0, t.default.pressed),
            selected: stateThemeColor_v0_v2(v0, t.default.selected),
            disabled: stateThemeColor_v0_v2(v0, t.default.disabled)
        },
        neutral: {
            enabled: stateThemeColor_v0_v2(v0, t.default.enabled),
            hovered: stateThemeColor_v0_v2(v0, t.default.hovered),
            pressed: stateThemeColor_v0_v2(v0, t.default.pressed),
            selected: stateThemeColor_v0_v2(v0, t.default.selected),
            disabled: stateThemeColor_v0_v2(v0, t.default.disabled)
        },
        primary: {
            enabled: stateThemeColor_v0_v2(v0, t.primary.enabled),
            hovered: stateThemeColor_v0_v2(v0, t.primary.hovered),
            pressed: stateThemeColor_v0_v2(v0, t.primary.pressed),
            selected: stateThemeColor_v0_v2(v0, t.primary.selected),
            disabled: stateThemeColor_v0_v2(v0, t.primary.disabled)
        },
        suggest: {
            enabled: stateThemeColor_v0_v2(v0, t.primary.enabled),
            hovered: stateThemeColor_v0_v2(v0, t.primary.hovered),
            pressed: stateThemeColor_v0_v2(v0, t.primary.pressed),
            selected: stateThemeColor_v0_v2(v0, t.primary.selected),
            disabled: stateThemeColor_v0_v2(v0, t.primary.disabled)
        },
        positive: {
            enabled: stateThemeColor_v0_v2(v0, t.positive.enabled),
            hovered: stateThemeColor_v0_v2(v0, t.positive.hovered),
            pressed: stateThemeColor_v0_v2(v0, t.positive.pressed),
            selected: stateThemeColor_v0_v2(v0, t.positive.selected),
            disabled: stateThemeColor_v0_v2(v0, t.positive.disabled)
        },
        caution: {
            enabled: stateThemeColor_v0_v2(v0, t.caution.enabled),
            hovered: stateThemeColor_v0_v2(v0, t.caution.hovered),
            pressed: stateThemeColor_v0_v2(v0, t.caution.pressed),
            selected: stateThemeColor_v0_v2(v0, t.caution.selected),
            disabled: stateThemeColor_v0_v2(v0, t.caution.disabled)
        },
        critical: {
            enabled: stateThemeColor_v0_v2(v0, t.critical.enabled),
            hovered: stateThemeColor_v0_v2(v0, t.critical.hovered),
            pressed: stateThemeColor_v0_v2(v0, t.critical.pressed),
            selected: stateThemeColor_v0_v2(v0, t.critical.selected),
            disabled: stateThemeColor_v0_v2(v0, t.critical.disabled)
        }
    };
}
function stateThemeColor_v0_v2(v0, state) {
    return {
        ...state,
        avatar: {
            gray: {
                bg: v0.spot.gray,
                fg: v0.base.bg
            },
            blue: {
                bg: v0.spot.blue,
                fg: v0.base.bg
            },
            purple: {
                bg: v0.spot.purple,
                fg: v0.base.bg
            },
            magenta: {
                bg: v0.spot.magenta,
                fg: v0.base.bg
            },
            red: {
                bg: v0.spot.red,
                fg: v0.base.bg
            },
            orange: {
                bg: v0.spot.orange,
                fg: v0.base.bg
            },
            yellow: {
                bg: v0.spot.yellow,
                fg: v0.base.bg
            },
            green: {
                bg: v0.spot.green,
                fg: v0.base.bg
            },
            cyan: {
                bg: v0.spot.cyan,
                fg: v0.base.bg
            }
        },
        badge: {
            default: {
                bg: v0.muted.default.enabled.bg,
                fg: v0.muted.default.enabled.fg,
                dot: v0.muted.default.enabled.muted.fg,
                icon: v0.muted.default.enabled.muted.fg
            },
            neutral: {
                bg: v0.muted.transparent.enabled.bg,
                fg: v0.muted.transparent.enabled.fg,
                dot: v0.muted.transparent.enabled.muted.fg,
                icon: v0.muted.transparent.enabled.muted.fg
            },
            primary: {
                bg: v0.muted.primary.enabled.bg,
                fg: v0.muted.primary.enabled.fg,
                dot: v0.muted.primary.enabled.muted.fg,
                icon: v0.muted.primary.enabled.muted.fg
            },
            suggest: {
                bg: v0.muted.primary.enabled.bg,
                fg: v0.muted.primary.enabled.fg,
                dot: v0.muted.primary.enabled.muted.fg,
                icon: v0.muted.primary.enabled.muted.fg
            },
            positive: {
                bg: v0.muted.positive.enabled.bg,
                fg: v0.muted.positive.enabled.fg,
                dot: v0.muted.positive.enabled.muted.fg,
                icon: v0.muted.positive.enabled.muted.fg
            },
            caution: {
                bg: v0.muted.caution.enabled.bg,
                fg: v0.muted.caution.enabled.fg,
                dot: v0.muted.caution.enabled.muted.fg,
                icon: v0.muted.caution.enabled.muted.fg
            },
            critical: {
                bg: v0.muted.critical.enabled.bg,
                fg: v0.muted.critical.enabled.fg,
                dot: v0.muted.critical.enabled.muted.fg,
                icon: v0.muted.critical.enabled.muted.fg
            }
        },
        kbd: {
            bg: v0.muted.default.enabled.bg,
            fg: v0.muted.default.enabled.fg,
            border: v0.muted.default.enabled.border
        },
        muted: {
            ...v0.muted.default.enabled.muted,
            bg: state.bg2 || state.bg
        },
        skeleton: {
            from: state.skeleton?.from || state.border,
            to: state.skeleton?.to || state.border
        }
    };
}
function inputStatesThemeColor_v0_v2(states) {
    return {
        enabled: inputStateThemeColor_v0_v2(states.enabled),
        disabled: inputStateThemeColor_v0_v2(states.disabled),
        readOnly: inputStateThemeColor_v0_v2(states.readOnly),
        hovered: inputStateThemeColor_v0_v2(states.hovered)
    };
}
function inputStateThemeColor_v0_v2(state) {
    return {
        bg: state.bg,
        border: state.border,
        fg: state.fg,
        muted: {
            bg: state.bg2
        },
        placeholder: state.placeholder
    };
}
const cache$3 = /* @__PURE__ */ new WeakMap();
function getTheme_v2(theme) {
    if (theme.sanity.v2?._resolved) return theme.sanity.v2;
    const cached_v2 = cache$3.get(theme);
    if (cached_v2) return cached_v2;
    const v2 = {
        _version: 2,
        _resolved: !0,
        avatar: {
            ...defaultThemeConfig.avatar,
            ...theme.sanity.avatar
        },
        button: {
            ...defaultThemeConfig.button,
            ...theme.sanity.button
        },
        card: defaultThemeConfig.card,
        color: themeColor_v0_v2(theme.sanity.color),
        container: theme.sanity.container,
        font: theme.sanity.fonts,
        input: {
            ...defaultThemeConfig.input,
            ...theme.sanity.input,
            checkbox: {
                ...defaultThemeConfig.input.checkbox,
                ...theme.sanity.input.checkbox
            },
            radio: {
                ...defaultThemeConfig.input.radio,
                ...theme.sanity.input.radio
            },
            switch: {
                ...defaultThemeConfig.input.switch,
                ...theme.sanity.input.switch
            }
        },
        layer: theme.sanity.layer ?? defaultThemeConfig.layer,
        media: theme.sanity.media,
        radius: theme.sanity.radius,
        shadow: theme.sanity.shadows,
        space: theme.sanity.space,
        style: theme.sanity.styles
    };
    return cache$3.set(theme, v2), v2;
}
function is_v0(themeProp) {
    return themeProp._version === 0;
}
function is_v2(themeProp) {
    return themeProp._version === 2;
}
const cache$2 = /* @__PURE__ */ new WeakMap();
function v0_v2(v0) {
    if (v0.v2) return v0.v2;
    const cached_v2 = cache$2.get(v0);
    if (cached_v2) return cached_v2;
    const { avatar, button, color: color2, container, fonts: font, input, layer, media, radius, shadows: shadow, space, styles: style } = v0, v2 = {
        _version: 2,
        avatar: {
            ...defaultThemeConfig.avatar,
            ...avatar
        },
        button: {
            ...defaultThemeConfig.button,
            ...button
        },
        card: defaultThemeConfig.card,
        color: {
            light: {
                transparent: themeColor_v0_v2(color2.light.transparent),
                default: themeColor_v0_v2(color2.light.default),
                neutral: themeColor_v0_v2(color2.light.transparent),
                primary: themeColor_v0_v2(color2.light.primary),
                suggest: themeColor_v0_v2(color2.light.primary),
                positive: themeColor_v0_v2(color2.light.positive),
                caution: themeColor_v0_v2(color2.light.caution),
                critical: themeColor_v0_v2(color2.light.critical)
            },
            dark: {
                transparent: themeColor_v0_v2(color2.dark.transparent),
                default: themeColor_v0_v2(color2.dark.default),
                neutral: themeColor_v0_v2(color2.dark.transparent),
                primary: themeColor_v0_v2(color2.dark.primary),
                suggest: themeColor_v0_v2(color2.dark.primary),
                positive: themeColor_v0_v2(color2.dark.positive),
                caution: themeColor_v0_v2(color2.dark.caution),
                critical: themeColor_v0_v2(color2.dark.critical)
            }
        },
        container,
        font,
        input: {
            ...defaultThemeConfig.input,
            ...input,
            checkbox: {
                ...defaultThemeConfig.input.checkbox,
                ...input.checkbox
            },
            radio: {
                ...defaultThemeConfig.input.radio,
                ...input.radio
            },
            switch: {
                ...defaultThemeConfig.input.switch,
                ...input.switch
            }
        },
        layer: layer ?? defaultThemeConfig.layer,
        media,
        radius,
        shadow,
        space,
        style
    };
    return cache$2.set(v0, v2), v2;
}
function defineLazyProperty(obj, key, factory) {
    Object.defineProperty(obj, key, {
        get () {
            const value = factory();
            return Object.defineProperty(obj, key, {
                value,
                enumerable: !0,
                writable: !1,
                configurable: !1
            }), value;
        },
        enumerable: !0,
        configurable: !0
    });
}
const cache$1 = /* @__PURE__ */ new WeakMap(), V0_TONES = [
    "transparent",
    "default",
    "primary",
    "positive",
    "caution",
    "critical"
];
function lazyV0Scheme(schemeKey, color2) {
    const scheme = {};
    for (const tone of V0_TONES)defineLazyProperty(scheme, tone, ()=>themeColor_v2_v0(color2[schemeKey][tone]));
    return scheme;
}
function v2_v0(v2) {
    const cachedTheme = cache$1.get(v2);
    if (cachedTheme) return cachedTheme;
    const { avatar, button, color: color2, container, font: fonts, input, media, radius, shadow: shadows, space, style: styles } = v2, v0Color = {};
    defineLazyProperty(v0Color, "light", ()=>lazyV0Scheme("light", color2)), defineLazyProperty(v0Color, "dark", ()=>lazyV0Scheme("dark", color2));
    const theme = {
        _version: 0,
        avatar,
        button,
        container,
        color: v0Color,
        focusRing: input.text.focusRing,
        fonts,
        input,
        media,
        radius,
        shadows,
        space,
        styles,
        v2
    };
    return cache$1.set(v2, theme), theme;
}
function themeColor_v2_v0(color_v2) {
    return {
        base: {
            bg: color_v2.bg,
            fg: color_v2.fg,
            border: color_v2.border,
            focusRing: color_v2.focusRing,
            shadow: color_v2.shadow
        },
        button: color_v2.button,
        card: color_v2.selectable.default,
        dark: color_v2._dark,
        input: {
            default: inputStatesThemeColor_v2_v0(color_v2.input.default),
            invalid: inputStatesThemeColor_v2_v0(color_v2.input.invalid)
        },
        muted: {
            ...color_v2.button.ghost,
            transparent: color_v2.button.ghost.default
        },
        solid: {
            ...color_v2.button.default,
            transparent: color_v2.button.default.default
        },
        selectable: color_v2.selectable,
        spot: {
            gray: color_v2.avatar.gray.bg,
            blue: color_v2.avatar.blue.bg,
            purple: color_v2.avatar.purple.bg,
            magenta: color_v2.avatar.magenta.bg,
            red: color_v2.avatar.red.bg,
            orange: color_v2.avatar.orange.bg,
            yellow: color_v2.avatar.yellow.bg,
            green: color_v2.avatar.green.bg,
            cyan: color_v2.avatar.cyan.bg
        },
        syntax: color_v2.syntax
    };
}
function inputStatesThemeColor_v2_v0(t) {
    return {
        enabled: inputStateThemeColor_v2_v0(t.enabled),
        disabled: inputStateThemeColor_v2_v0(t.disabled),
        readOnly: inputStateThemeColor_v2_v0(t.readOnly),
        hovered: inputStateThemeColor_v2_v0(t.hovered)
    };
}
function inputStateThemeColor_v2_v0(t) {
    return {
        bg: t.bg,
        bg2: t.muted.bg,
        border: t.border,
        fg: t.fg,
        placeholder: t.placeholder
    };
}
const THEME_COLOR_SCHEMES = [
    "light",
    "dark"
], THEME_COLOR_BLEND_MODES = [
    "multiply",
    "screen"
], THEME_COLOR_CARD_TONES = [
    "transparent",
    "default",
    "neutral",
    "primary",
    // deprecated
    "suggest",
    "positive",
    "caution",
    "critical"
], THEME_COLOR_STATE_TONES = [
    "default",
    "neutral",
    "primary",
    // deprecated
    "suggest",
    "positive",
    "caution",
    "critical"
], THEME_COLOR_STATES = [
    "enabled",
    "hovered",
    "pressed",
    "selected",
    "disabled"
], THEME_COLOR_BUTTON_MODES = [
    "default",
    "ghost",
    "bleed"
], THEME_COLOR_INPUT_MODES = [
    "default",
    "invalid"
], THEME_COLOR_INPUT_STATES = [
    "enabled",
    "hovered",
    "readOnly",
    "disabled"
], THEME_COLOR_AVATAR_COLORS = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$color$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLOR_HUES"];
function isColorBlendModeValue(str) {
    return THEME_COLOR_BLEND_MODES.includes(str);
}
function isColorHueKey(str) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$color$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLOR_HUES"].includes(str);
}
function isColorTintKey(str) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$color$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLOR_TINTS"].includes(str);
}
function isColorButtonMode(str) {
    return THEME_COLOR_BUTTON_MODES.includes(str);
}
const COLOR_CONFIG_STATE_KEYS = [
    "_hue",
    "bg",
    "fg",
    "border",
    "focusRing",
    "muted/fg",
    "accent/fg",
    "link/fg",
    "code/bg",
    "code/fg",
    "skeleton/from",
    "skeleton/to",
    "status/dot",
    "status/icon"
], COLOR_CONFIG_CARD_KEYS = [
    ...COLOR_CONFIG_STATE_KEYS,
    "_hue",
    "bg",
    "fg",
    "border",
    "focusRing",
    "shadow/outline",
    "shadow/umbra",
    "shadow/penumbra",
    "shadow/ambient"
], COLOR_CONFIG_BLEND_KEYS = [
    "_blend"
], COLOR_CONFIG_AVATAR_COLORS = [
    "*",
    ...THEME_COLOR_AVATAR_COLORS
], COLOR_CONFIG_CARD_TONES = [
    "*",
    ...THEME_COLOR_CARD_TONES
], COLOR_CONFIG_STATE_TONES = [
    "*",
    ...THEME_COLOR_STATE_TONES
], COLOR_CONFIG_STATES = [
    "*",
    ...THEME_COLOR_STATES
], COLOR_CONFIG_INPUT_MODES = [
    "*",
    ...THEME_COLOR_INPUT_MODES
], COLOR_CONFIG_INPUT_STATES = [
    "*",
    ...THEME_COLOR_INPUT_STATES
];
function parseTokenKey(str) {
    const segments = str.split("/"), segment0 = segments.shift() || "";
    if (isColorConfigBaseTone(segment0)) {
        const key = segments.join("/");
        if (isColorConfigBaseKey(key)) return {
            type: "base",
            tone: segment0,
            key
        };
        if (isColorConfigBlendKey(key)) return {
            type: "base",
            tone: segment0,
            key
        };
    }
    if (segment0 === "button") {
        const segment1 = segments.shift() || "";
        if (isColorConfigStateTone(segment1)) {
            const segment2 = segments.shift() || "";
            if (isColorButtonMode(segment2)) {
                const key = segments.join("/");
                if (isColorConfigStateKey(key)) return {
                    type: "button",
                    tone: segment1,
                    mode: segment2,
                    key
                };
                if (isColorConfigBlendKey(key)) return {
                    type: "button",
                    tone: segment1,
                    mode: segment2,
                    key
                };
            }
        }
    }
}
function isColorMixPercentValue(str) {
    return /^\d+%$/.test(str);
}
function parseTokenValue(str) {
    const segments = str.split("/");
    let nextSegment = segments.shift() || "";
    const [segment0, segment0mix] = nextSegment.split(" ");
    if (isColorTintKey(segment0)) {
        const tint = segment0, segment1 = segments.shift() || "";
        if (isColorMixPercentValue(segment0mix)) {
            const mix2 = Number(segment0mix.slice(0, -1)) / 100;
            return {
                type: "color",
                tint,
                mix: mix2
            };
        }
        if (isColorOpacityValue(segment1)) {
            const opacity = Number(segment1);
            return {
                type: "color",
                tint,
                opacity
            };
        }
        return {
            type: "color",
            tint
        };
    }
    if (isColorValue(segment0)) {
        const key = segment0, segment1 = segments.shift() || "";
        if (isColorMixPercentValue(segment0mix)) {
            const mix2 = Number(segment0mix.slice(0, -1)) / 100;
            return {
                type: "color",
                key,
                mix: mix2
            };
        }
        if (isColorOpacityValue(segment1)) {
            const opacity = Number(segment1);
            return {
                type: "color",
                key,
                opacity
            };
        }
        return {
            type: "color",
            key
        };
    }
    if (isColorHueKey(segment0)) {
        const hue = segment0;
        nextSegment = segments.shift() || "";
        const [segment1, segment1mix] = nextSegment.split(" ");
        if (isColorTintKey(segment1)) {
            const tint = segment1, segment2 = segments.shift() || "";
            if (isColorMixPercentValue(segment1mix)) {
                const mix2 = Number(segment1mix.slice(0, -1)) / 100;
                return {
                    type: "color",
                    hue,
                    tint,
                    mix: mix2
                };
            }
            if (isColorOpacityValue(segment2)) {
                const opacity = Number(segment2);
                return {
                    type: "color",
                    hue,
                    tint,
                    opacity
                };
            }
            return {
                type: "color",
                hue,
                tint
            };
        }
        return {
            type: "hue",
            value: hue
        };
    }
    if (isColorBlendModeValue(segment0)) return {
        type: "blendMode",
        value: segment0
    };
}
function isColorConfigBaseTone(str) {
    return COLOR_CONFIG_CARD_TONES.includes(str);
}
function isColorConfigBaseKey(str) {
    return COLOR_CONFIG_CARD_KEYS.includes(str);
}
function isColorConfigStateKey(str) {
    return COLOR_CONFIG_STATE_KEYS.includes(str);
}
function isColorConfigStateTone(str) {
    return COLOR_CONFIG_STATE_TONES.includes(str);
}
function isColorConfigBlendKey(str) {
    return COLOR_CONFIG_BLEND_KEYS.includes(str);
}
function isColorTokenValue(str) {
    return parseTokenValue(str)?.type === "color" || parseTokenValue(str)?.type === "hue";
}
function isColorValue(str) {
    return str === "black" || str === "white";
}
function isColorOpacityValue(str) {
    return str === "0" || /^0\.[0-9]+$/.test(str) || str === "1";
}
function compileColorTokenValue(node) {
    let key = "";
    return node.key === "black" || node.key === "white" ? key = node.key : key = `${node.hue}/${node.tint}`, node.mix !== void 0 ? `${key} ${node.mix * 100}%` : (node.opacity !== void 0 && (key += `/${node.opacity}`), key);
}
const DEFAULT_COLOR_TOKEN_VALUE = [
    "500",
    "500"
];
function resolveColorTokenValue(context, value = DEFAULT_COLOR_TOKEN_VALUE) {
    const { hue, scheme } = context, node = parseTokenValue(value[scheme === "light" ? 0 : 1]);
    if (!node || node.type !== "color") throw new Error(`Invalid color token: ${value[0]}`);
    return compileColorTokenValue({
        ...node,
        hue: node.hue || hue
    });
}
const defaultColorTokens = {
    base: {
        "*": {
            _blend: [
                "multiply",
                "screen"
            ],
            accent: {
                fg: [
                    "purple/600",
                    "purple/400"
                ]
            },
            avatar: {
                "*": {
                    _blend: [
                        "screen",
                        "multiply"
                    ],
                    bg: [
                        "500",
                        "400"
                    ],
                    fg: [
                        "white",
                        "black"
                    ]
                }
            },
            backdrop: [
                "gray/200/0.5",
                "black/0.5"
            ],
            badge: {
                "*": {
                    bg: [
                        "100",
                        "900"
                    ],
                    fg: [
                        "600",
                        "400"
                    ],
                    icon: [
                        "500",
                        "500"
                    ],
                    dot: [
                        "500",
                        "500"
                    ]
                },
                positive: {
                    bg: [
                        "200 50%",
                        "900"
                    ],
                    fg: [
                        "600",
                        "500"
                    ]
                },
                caution: {
                    bg: [
                        "200 50%",
                        "900"
                    ],
                    fg: [
                        "600",
                        "500"
                    ]
                }
            },
            bg: [
                "50",
                "950"
            ],
            border: [
                "200",
                "800"
            ],
            code: {
                bg: [
                    "50",
                    "950"
                ],
                fg: [
                    "600",
                    "400"
                ]
            },
            fg: [
                "800",
                "200"
            ],
            focusRing: [
                "blue/500",
                "blue/500"
            ],
            icon: [
                "600",
                "400"
            ],
            kbd: {
                bg: [
                    "white",
                    "black"
                ],
                fg: [
                    "600",
                    "400"
                ],
                border: [
                    "200",
                    "800"
                ]
            },
            link: {
                fg: [
                    "blue/600",
                    "blue/300"
                ]
            },
            muted: {
                bg: [
                    "50",
                    "950"
                ],
                fg: [
                    "700 75%",
                    "300 75%"
                ]
            },
            shadow: {
                outline: [
                    "500/0.3",
                    "500/0.4"
                ],
                umbra: [
                    "gray/500/0.1",
                    "black/0.2"
                ],
                penumbra: [
                    "gray/500/0.07",
                    "black/0.14"
                ],
                ambient: [
                    "gray/500/0.06",
                    "black/0.12"
                ]
            },
            skeleton: {
                from: [
                    "100",
                    "900"
                ],
                to: [
                    "100 50%",
                    "900 50%"
                ]
            }
        },
        transparent: {
            bg: [
                "50",
                "black"
            ]
        },
        default: {
            bg: [
                "white",
                "950"
            ],
            fg: [
                "800",
                "200"
            ],
            muted: {
                fg: [
                    "600",
                    "400"
                ]
            }
        },
        primary: {
            _hue: "blue"
        },
        suggest: {
            _hue: "purple"
        },
        positive: {
            _hue: "green",
            shadow: {
                outline: [
                    "500/0.4",
                    "500/0.4"
                ]
            }
        },
        caution: {
            _hue: "yellow",
            shadow: {
                outline: [
                    "600/0.3",
                    "500/0.4"
                ]
            }
        },
        critical: {
            _hue: "red"
        }
    },
    button: {
        default: {
            "*": {
                "*": {
                    _blend: [
                        "screen",
                        "multiply"
                    ],
                    accent: {
                        fg: [
                            "purple/300",
                            "purple/700"
                        ]
                    },
                    avatar: {
                        "*": {
                            _blend: [
                                "screen",
                                "multiply"
                            ],
                            bg: [
                                "500",
                                "400"
                            ],
                            fg: [
                                "white",
                                "black"
                            ]
                        }
                    },
                    badge: {
                        "*": {
                            bg: [
                                "900",
                                "100"
                            ],
                            fg: [
                                "400",
                                "600"
                            ],
                            dot: [
                                "500",
                                "500"
                            ],
                            icon: [
                                "500",
                                "500"
                            ]
                        }
                    },
                    bg: [
                        "500",
                        "400"
                    ],
                    border: [
                        "500/0",
                        "400/0"
                    ],
                    code: {
                        bg: [
                            "500 20%",
                            "400 20%"
                        ],
                        fg: [
                            "200",
                            "600"
                        ]
                    },
                    fg: [
                        "white",
                        "black"
                    ],
                    icon: [
                        "100 70%",
                        "900 70%"
                    ],
                    kbd: {
                        bg: [
                            "black",
                            "white"
                        ],
                        fg: [
                            "200",
                            "600"
                        ],
                        border: [
                            "800",
                            "200"
                        ]
                    },
                    link: {
                        fg: [
                            "blue/200",
                            "blue/600"
                        ]
                    },
                    muted: {
                        bg: [
                            "950",
                            "50"
                        ],
                        fg: [
                            "100 70%",
                            "900 70%"
                        ]
                    },
                    skeleton: {
                        from: [
                            "900",
                            "100"
                        ],
                        to: [
                            "900 50%",
                            "100 50%"
                        ]
                    }
                },
                hovered: {
                    bg: [
                        "600",
                        "300"
                    ],
                    border: [
                        "700/0",
                        "300/0"
                    ]
                },
                pressed: {
                    bg: [
                        "700",
                        "300"
                    ]
                },
                selected: {
                    bg: [
                        "700",
                        "300"
                    ]
                },
                disabled: {
                    _hue: "gray",
                    accent: {
                        fg: [
                            "100 70%",
                            "900 70%"
                        ]
                    },
                    avatar: {
                        "*": {
                            _blend: [
                                "screen",
                                "multiply"
                            ],
                            bg: [
                                "gray/500",
                                "gray/400"
                            ],
                            fg: [
                                "white",
                                "black"
                            ]
                        }
                    },
                    badge: {
                        "*": {
                            bg: [
                                "gray/700",
                                "gray/300"
                            ],
                            fg: [
                                "white",
                                "black"
                            ],
                            dot: [
                                "white",
                                "black"
                            ],
                            icon: [
                                "white",
                                "black"
                            ]
                        }
                    },
                    bg: [
                        "300",
                        "600"
                    ],
                    code: {
                        bg: [
                            "950",
                            "50"
                        ],
                        fg: [
                            "300",
                            "600"
                        ]
                    },
                    fg: [
                        "300",
                        "600"
                    ],
                    muted: {
                        bg: [
                            "950",
                            "50"
                        ],
                        fg: [
                            "300",
                            "600"
                        ]
                    },
                    kbd: {
                        bg: [
                            "black",
                            "white"
                        ],
                        fg: [
                            "white",
                            "black"
                        ],
                        border: [
                            "700",
                            "300"
                        ]
                    },
                    link: {
                        fg: [
                            "100 70%",
                            "900 70%"
                        ]
                    }
                }
            },
            default: {
                "*": {
                    avatar: {
                        "*": {
                            _blend: [
                                "screen",
                                "multiply"
                            ],
                            bg: [
                                "500",
                                "400"
                            ],
                            fg: [
                                "white",
                                "black"
                            ]
                        }
                    },
                    bg: [
                        "800",
                        "200"
                    ],
                    muted: {
                        bg: [
                            "950",
                            "50"
                        ],
                        fg: [
                            "400",
                            "600"
                        ]
                    }
                },
                hovered: {
                    bg: [
                        "900",
                        "100"
                    ]
                },
                pressed: {
                    bg: [
                        "black",
                        "white"
                    ]
                },
                selected: {
                    bg: [
                        "black",
                        "white"
                    ]
                }
            }
        },
        ghost: {
            "*": {
                "*": {
                    _blend: [
                        "multiply",
                        "screen"
                    ],
                    accent: {
                        fg: [
                            "purple/700 60%",
                            "purple/300 70%"
                        ]
                    },
                    avatar: {
                        "*": {
                            _blend: [
                                "screen",
                                "multiply"
                            ],
                            bg: [
                                "500",
                                "400"
                            ],
                            fg: [
                                "white",
                                "black"
                            ]
                        }
                    },
                    badge: {
                        "*": {
                            bg: [
                                "100",
                                "900"
                            ],
                            fg: [
                                "600",
                                "400"
                            ],
                            dot: [
                                "500",
                                "500"
                            ],
                            icon: [
                                "500",
                                "500"
                            ]
                        }
                    },
                    bg: [
                        "50",
                        "950"
                    ],
                    border: [
                        "100",
                        "900"
                    ],
                    code: {
                        bg: [
                            "500 10%",
                            "400 10%"
                        ],
                        fg: [
                            "700 60%",
                            "400 60%"
                        ]
                    },
                    fg: [
                        "600",
                        "400"
                    ],
                    icon: [
                        "700 60%",
                        "300 60%"
                    ],
                    kbd: {
                        bg: [
                            "white",
                            "black"
                        ],
                        fg: [
                            "600",
                            "400"
                        ],
                        border: [
                            "200",
                            "800"
                        ]
                    },
                    link: {
                        fg: [
                            "blue/700 60%",
                            "blue/300 60%"
                        ]
                    },
                    muted: {
                        bg: [
                            "100",
                            "950"
                        ],
                        fg: [
                            "700 60%",
                            "300 60%"
                        ]
                    },
                    skeleton: {
                        from: [
                            "100",
                            "900"
                        ],
                        to: [
                            "100 50%",
                            "900 50%"
                        ]
                    }
                },
                hovered: {
                    bg: [
                        "100",
                        "900"
                    ],
                    fg: [
                        "700",
                        "300"
                    ]
                },
                pressed: {
                    bg: [
                        "200",
                        "800"
                    ],
                    fg: [
                        "800",
                        "200"
                    ]
                },
                selected: {
                    bg: [
                        "200",
                        "800"
                    ],
                    fg: [
                        "800",
                        "200"
                    ]
                },
                disabled: {
                    _hue: "gray",
                    accent: {
                        fg: [
                            "200",
                            "800"
                        ]
                    },
                    avatar: {
                        "*": {
                            _blend: [
                                "screen",
                                "multiply"
                            ],
                            bg: [
                                "gray/100",
                                "gray/900"
                            ],
                            fg: [
                                "white",
                                "black"
                            ]
                        }
                    },
                    badge: {
                        "*": {
                            _hue: "gray",
                            bg: [
                                "50",
                                "950"
                            ],
                            fg: [
                                "gray/200",
                                "gray/800"
                            ],
                            dot: [
                                "gray/200",
                                "gray/800"
                            ],
                            icon: [
                                "gray/200",
                                "gray/800"
                            ]
                        }
                    },
                    border: [
                        "100",
                        "900"
                    ],
                    code: {
                        bg: [
                            "50",
                            "950"
                        ],
                        fg: [
                            "200",
                            "800"
                        ]
                    },
                    fg: [
                        "400",
                        "600"
                    ],
                    icon: [
                        "300",
                        "700"
                    ],
                    muted: {
                        fg: [
                            "300",
                            "700"
                        ]
                    },
                    kbd: {
                        bg: [
                            "white",
                            "black"
                        ],
                        fg: [
                            "200",
                            "800"
                        ],
                        border: [
                            "100",
                            "900"
                        ]
                    },
                    link: {
                        fg: [
                            "200",
                            "800"
                        ]
                    }
                }
            },
            positive: {
                "*": {
                    border: [
                        "600 20%",
                        "800"
                    ]
                }
            },
            caution: {
                "*": {
                    border: [
                        "600 20%",
                        "800"
                    ]
                }
            }
        },
        bleed: {
            "*": {
                "*": {
                    _blend: [
                        "multiply",
                        "screen"
                    ],
                    accent: {
                        fg: [
                            "purple/700 70%",
                            "purple/300 70%"
                        ]
                    },
                    avatar: {
                        "*": {
                            _blend: [
                                "screen",
                                "multiply"
                            ],
                            bg: [
                                "500",
                                "400"
                            ],
                            fg: [
                                "white",
                                "black"
                            ]
                        }
                    },
                    badge: {
                        "*": {
                            bg: [
                                "100",
                                "900"
                            ],
                            fg: [
                                "600",
                                "400"
                            ],
                            dot: [
                                "500",
                                "500"
                            ],
                            icon: [
                                "500",
                                "500"
                            ]
                        }
                    },
                    bg: [
                        "white",
                        "black"
                    ],
                    border: [
                        "white/0",
                        "black/0"
                    ],
                    code: {
                        bg: [
                            "50",
                            "950"
                        ],
                        fg: [
                            "700 75%",
                            "300 75%"
                        ]
                    },
                    fg: [
                        "700",
                        "300"
                    ],
                    icon: [
                        "700 75%",
                        "300 75%"
                    ],
                    kbd: {
                        bg: [
                            "white",
                            "black"
                        ],
                        fg: [
                            "700",
                            "300"
                        ],
                        border: [
                            "200",
                            "800"
                        ]
                    },
                    link: {
                        fg: [
                            "blue/700 70%",
                            "blue/300 70%"
                        ]
                    },
                    muted: {
                        bg: [
                            "100",
                            "950"
                        ],
                        fg: [
                            "700 75%",
                            "300 75%"
                        ]
                    },
                    skeleton: {
                        from: [
                            "100",
                            "900"
                        ],
                        to: [
                            "100 50%",
                            "900 50%"
                        ]
                    }
                },
                hovered: {
                    bg: [
                        "50",
                        "900"
                    ],
                    fg: [
                        "800",
                        "200"
                    ],
                    icon: [
                        "800 70%",
                        "300 70%"
                    ]
                },
                pressed: {
                    bg: [
                        "100",
                        "800"
                    ],
                    fg: [
                        "800",
                        "200"
                    ],
                    icon: [
                        "800 70%",
                        "200 70%"
                    ]
                },
                selected: {
                    bg: [
                        "100",
                        "900"
                    ],
                    fg: [
                        "800",
                        "200"
                    ],
                    icon: [
                        "800 60%",
                        "200 60%"
                    ]
                },
                disabled: {
                    _hue: "gray",
                    accent: {
                        fg: [
                            "200",
                            "800"
                        ]
                    },
                    avatar: {
                        "*": {
                            _blend: [
                                "screen",
                                "multiply"
                            ],
                            bg: [
                                "gray/100",
                                "gray/900"
                            ],
                            fg: [
                                "white",
                                "black"
                            ]
                        }
                    },
                    badge: {
                        "*": {
                            _hue: "gray",
                            bg: [
                                "50",
                                "950"
                            ],
                            fg: [
                                "gray/200",
                                "gray/800"
                            ],
                            dot: [
                                "gray/200",
                                "gray/800"
                            ],
                            icon: [
                                "gray/200",
                                "gray/800"
                            ]
                        }
                    },
                    code: {
                        bg: [
                            "50",
                            "950"
                        ],
                        fg: [
                            "200",
                            "800"
                        ]
                    },
                    fg: [
                        "400",
                        "600"
                    ],
                    icon: [
                        "300",
                        "700"
                    ],
                    muted: {
                        fg: [
                            "400",
                            "600"
                        ]
                    },
                    kbd: {
                        bg: [
                            "white",
                            "black"
                        ],
                        fg: [
                            "200",
                            "800"
                        ],
                        border: [
                            "100",
                            "900"
                        ]
                    },
                    link: {
                        fg: [
                            "200",
                            "800"
                        ]
                    }
                }
            }
        }
    },
    input: {
        "*": {
            "*": {
                _blend: [
                    "multiply",
                    "screen"
                ],
                bg: [
                    "white",
                    "black"
                ],
                border: [
                    "200",
                    "700"
                ],
                fg: [
                    "black",
                    "200"
                ],
                muted: {
                    bg: [
                        "50",
                        "950"
                    ]
                },
                placeholder: [
                    "400",
                    "600"
                ]
            },
            hovered: {
                border: [
                    "300",
                    "700"
                ]
            },
            readOnly: {
                bg: [
                    "50",
                    "950"
                ],
                border: [
                    "200",
                    "800"
                ],
                fg: [
                    "800",
                    "200"
                ]
            },
            disabled: {
                bg: [
                    "50",
                    "950"
                ],
                fg: [
                    "400",
                    "600"
                ],
                border: [
                    "100",
                    "900"
                ],
                placeholder: [
                    "200",
                    "800 50%"
                ]
            }
        },
        invalid: {
            "*": {
                _hue: "red",
                bg: [
                    "100",
                    "950"
                ]
            }
        }
    },
    selectable: {
        "*": {
            "*": {
                _blend: [
                    "multiply",
                    "screen"
                ],
                accent: {
                    fg: [
                        "purple/700 70%",
                        "purple/300 70%"
                    ]
                },
                avatar: {
                    "*": {
                        _blend: [
                            "screen",
                            "multiply"
                        ],
                        bg: [
                            "500",
                            "400"
                        ],
                        fg: [
                            "white",
                            "black"
                        ]
                    }
                },
                badge: {
                    "*": {
                        bg: [
                            "100",
                            "900"
                        ],
                        fg: [
                            "600",
                            "400"
                        ],
                        dot: [
                            "500",
                            "500"
                        ],
                        icon: [
                            "500",
                            "500"
                        ]
                    }
                },
                bg: [
                    "white",
                    "black"
                ],
                border: [
                    "200",
                    "800"
                ],
                code: {
                    bg: [
                        "50",
                        "950"
                    ],
                    fg: [
                        "600",
                        "400"
                    ]
                },
                fg: [
                    "700",
                    "300"
                ],
                icon: [
                    "700 75%",
                    "300 75%"
                ],
                kbd: {
                    bg: [
                        "white",
                        "black"
                    ],
                    fg: [
                        "600",
                        "400"
                    ],
                    border: [
                        "200",
                        "800"
                    ]
                },
                link: {
                    fg: [
                        "blue/700 70%",
                        "blue/300 70%"
                    ]
                },
                muted: {
                    bg: [
                        "50",
                        "950"
                    ],
                    fg: [
                        "700 75%",
                        "300 75%"
                    ]
                },
                skeleton: {
                    from: [
                        "100",
                        "900"
                    ],
                    to: [
                        "100 50%",
                        "900 50%"
                    ]
                }
            },
            hovered: {
                bg: [
                    "50",
                    "950"
                ]
            },
            pressed: {
                bg: [
                    "100",
                    "900"
                ]
            },
            selected: {
                _blend: [
                    "screen",
                    "multiply"
                ],
                accent: {
                    fg: [
                        "purple/300",
                        "purple/700"
                    ]
                },
                avatar: {
                    "*": {
                        _blend: [
                            "multiply",
                            "screen"
                        ],
                        bg: [
                            "white",
                            "black"
                        ],
                        fg: [
                            "black",
                            "white"
                        ]
                    }
                },
                badge: {
                    "*": {
                        bg: [
                            "900",
                            "100"
                        ],
                        fg: [
                            "400",
                            "600"
                        ],
                        dot: [
                            "500",
                            "500"
                        ],
                        icon: [
                            "500",
                            "500"
                        ]
                    }
                },
                bg: [
                    "500",
                    "400"
                ],
                border: [
                    "500 20%",
                    "400 20%"
                ],
                code: {
                    bg: [
                        "500 20%",
                        "400 20%"
                    ],
                    fg: [
                        "200",
                        "600"
                    ]
                },
                fg: [
                    "white",
                    "black"
                ],
                icon: [
                    "100 70%",
                    "900 70%"
                ],
                kbd: {
                    bg: [
                        "black",
                        "white"
                    ],
                    fg: [
                        "200",
                        "600"
                    ],
                    border: [
                        "800",
                        "200"
                    ]
                },
                link: {
                    fg: [
                        "blue/200",
                        "blue/600"
                    ]
                },
                muted: {
                    bg: [
                        "500 10%",
                        "400 10%"
                    ],
                    fg: [
                        "100 70%",
                        "900 70%"
                    ]
                },
                skeleton: {
                    from: [
                        "900",
                        "100"
                    ],
                    to: [
                        "900 50%",
                        "100 50%"
                    ]
                }
            },
            disabled: {
                _hue: "gray",
                accent: {
                    fg: [
                        "200",
                        "800"
                    ]
                },
                avatar: {
                    "*": {
                        _blend: [
                            "screen",
                            "multiply"
                        ],
                        bg: [
                            "gray/100",
                            "gray/900"
                        ],
                        fg: [
                            "white",
                            "black"
                        ]
                    }
                },
                badge: {
                    "*": {
                        _hue: "gray",
                        bg: [
                            "50",
                            "950"
                        ],
                        fg: [
                            "gray/200",
                            "gray/800"
                        ],
                        dot: [
                            "gray/200",
                            "gray/800"
                        ],
                        icon: [
                            "gray/200",
                            "gray/800"
                        ]
                    }
                },
                border: [
                    "100",
                    "900"
                ],
                code: {
                    bg: [
                        "50",
                        "950"
                    ],
                    fg: [
                        "200",
                        "800"
                    ]
                },
                fg: [
                    "200",
                    "800"
                ],
                icon: [
                    "200",
                    "800"
                ],
                kbd: {
                    bg: [
                        "white",
                        "black"
                    ],
                    fg: [
                        "200",
                        "800"
                    ],
                    border: [
                        "100",
                        "900"
                    ]
                },
                link: {
                    fg: [
                        "200",
                        "800"
                    ]
                },
                muted: {
                    bg: [
                        "50 50%",
                        "950 50%"
                    ],
                    fg: [
                        "200",
                        "800"
                    ]
                }
            }
        },
        default: {
            selected: {
                _hue: "blue"
            }
        },
        critical: {
            disabled: {
                bg: [
                    "50 50%",
                    "950 50%"
                ]
            }
        }
    },
    syntax: {
        atrule: [
            "purple/600",
            "purple/400"
        ],
        attrName: [
            "green/600",
            "green/400"
        ],
        attrValue: [
            "yellow/600",
            "yellow/400"
        ],
        attribute: [
            "yellow/600",
            "yellow/400"
        ],
        boolean: [
            "purple/600",
            "purple/400"
        ],
        builtin: [
            "purple/600",
            "purple/400"
        ],
        cdata: [
            "yellow/600",
            "yellow/400"
        ],
        char: [
            "yellow/600",
            "yellow/400"
        ],
        class: [
            "orange/600",
            "orange/400"
        ],
        className: [
            "cyan/600",
            "cyan/400"
        ],
        comment: [
            "gray/400",
            "gray/600"
        ],
        constant: [
            "purple/600",
            "purple/400"
        ],
        deleted: [
            "red/600",
            "red/400"
        ],
        entity: [
            "red/600",
            "red/400"
        ],
        function: [
            "green/600",
            "green/400"
        ],
        hexcode: [
            "blue/600",
            "blue/400"
        ],
        id: [
            "purple/600",
            "purple/400"
        ],
        important: [
            "purple/600",
            "purple/400"
        ],
        inserted: [
            "yellow/600",
            "yellow/400"
        ],
        keyword: [
            "magenta/600",
            "magenta/400"
        ],
        number: [
            "purple/600",
            "purple/400"
        ],
        operator: [
            "magenta/600",
            "magenta/400"
        ],
        property: [
            "blue/600",
            "blue/400"
        ],
        pseudoClass: [
            "yellow/600",
            "yellow/400"
        ],
        pseudoElement: [
            "yellow/600",
            "yellow/400"
        ],
        punctuation: [
            "gray/600",
            "gray/400"
        ],
        regex: [
            "blue/600",
            "blue/400"
        ],
        selector: [
            "red/600",
            "red/400"
        ],
        string: [
            "yellow/600",
            "yellow/400"
        ],
        symbol: [
            "purple/600",
            "purple/400"
        ],
        tag: [
            "red/600",
            "red/400"
        ],
        unit: [
            "orange/600",
            "orange/400"
        ],
        url: [
            "red/600",
            "red/400"
        ],
        variable: [
            "red/600",
            "red/400"
        ]
    }
};
function isRecord(value) {
    return !!(value && typeof value == "object" && !Array.isArray(value));
}
function merge(...records) {
    const _records = records.filter(Boolean);
    return _records.length === 0 ? {} : _records.reduce(_merge, {});
}
function _merge(acc, source) {
    for (const key of Object.keys(source)){
        const prevValue = acc[key], nextValue = source[key];
        isRecord(prevValue) && isRecord(nextValue) ? acc[key] = merge(prevValue, nextValue) : acc[key] = nextValue;
    }
    return acc;
}
function resolveColorTokens(inputTokens) {
    const tokens = merge(defaultColorTokens, inputTokens);
    return {
        base: resolveBaseColorTokens(tokens),
        button: resolveButtonColorTokens(tokens),
        input: resolveInputColorTokens(tokens),
        selectable: resolveSelectableColorTokens(tokens),
        syntax: tokens.syntax
    };
}
function resolveBaseColorTokens(sparseTokens) {
    const tokens = {};
    for (const tone of THEME_COLOR_CARD_TONES)tokens[tone] = resolveBaseColorTones(sparseTokens, tone);
    return tokens;
}
function resolveBaseColorTones(inputTokens, tone) {
    const spec = merge(inputTokens?.base?.["*"], inputTokens?.base?.[tone]), hue = spec._hue || inputTokens?.base?.[tone]?._hue || "gray";
    return {
        ...spec,
        _hue: hue,
        avatar: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$color$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLOR_HUES"].reduce((acc, hue2)=>({
                ...acc,
                [hue2]: merge({
                    _hue: hue2
                }, spec.avatar?.["*"], spec.avatar?.[hue2])
            }), {}),
        badge: THEME_COLOR_STATE_TONES.reduce((acc, tone2)=>({
                ...acc,
                [tone2]: {
                    _hue: inputTokens?.base?.[tone2]?._hue || hue,
                    ...spec.badge?.["*"],
                    ...spec.badge?.[tone2]
                }
            }), {})
    };
}
function resolveButtonColorTokens(inputTokens) {
    const tokens = {};
    for (const mode of THEME_COLOR_BUTTON_MODES)tokens[mode] = resolveButtonToneColorTokens(inputTokens, mode);
    return tokens;
}
function resolveButtonToneColorTokens(inputTokens, mode) {
    const tokens = {};
    for (const tone of THEME_COLOR_STATE_TONES)tokens[tone] = resolveButtonModeColorTokens(inputTokens, mode, tone);
    return tokens;
}
function resolveButtonModeColorTokens(inputTokens, mode, tone) {
    const tokens = {};
    for (const state of THEME_COLOR_STATES)tokens[state] = resolveButtonStateColorTokens(inputTokens, tone, mode, state);
    return tokens;
}
function resolveButtonStateColorTokens(inputTokens, tone, mode, state) {
    const spec = merge(inputTokens?.button?.[mode]?.["*"]?.["*"], inputTokens?.button?.[mode]?.[tone]?.["*"], inputTokens?.button?.[mode]?.["*"]?.[state], inputTokens?.button?.[mode]?.[tone]?.[state]), hue = spec._hue || inputTokens?.base?.[tone]?._hue;
    return {
        ...spec,
        _hue: hue,
        avatar: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$color$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLOR_HUES"].reduce((acc, hue2)=>({
                ...acc,
                [hue2]: merge({
                    _hue: hue2
                }, spec.avatar?.["*"], spec.avatar?.[hue2])
            }), {}),
        badge: THEME_COLOR_STATE_TONES.reduce((acc, tone2)=>({
                ...acc,
                [tone2]: {
                    _hue: inputTokens?.base?.[tone2]?._hue || hue,
                    ...spec.badge?.["*"],
                    ...spec.badge?.[tone2]
                }
            }), {})
    };
}
function resolveInputColorTokens(inputTokens) {
    const tokens = {};
    for (const mode of THEME_COLOR_INPUT_MODES)tokens[mode] = resolveInputModeColorTokens(inputTokens, mode);
    return tokens;
}
function resolveInputModeColorTokens(inputTokens, mode) {
    const states = {};
    for (const state of THEME_COLOR_INPUT_STATES)states[state] = resolveInputStateColorTokens(inputTokens, mode, state);
    return states;
}
function resolveInputStateColorTokens(inputTokens, mode, state) {
    const spec = merge(inputTokens?.input?.["*"]?.["*"], inputTokens?.input?.[mode]?.["*"], inputTokens?.input?.["*"]?.[state], inputTokens?.input?.[mode]?.[state]), hue = spec._hue || inputTokens?.input?.[mode]?._hue;
    return {
        ...spec,
        _hue: hue
    };
}
function resolveSelectableColorTokens(inputTokens) {
    const tokens = {};
    for (const tone of THEME_COLOR_STATE_TONES)tokens[tone] = resolveSelectableToneColorTokens(inputTokens, tone);
    return tokens;
}
function resolveSelectableToneColorTokens(inputTokens, tone) {
    const states = {
        _hue: inputTokens?.selectable?.[tone]?._hue || inputTokens?.base?.[tone]?._hue
    };
    for (const state of THEME_COLOR_STATES)states[state] = resolveSelectableStateColorTokens(inputTokens, tone, state);
    return states;
}
function resolveSelectableStateColorTokens(inputTokens, tone, state) {
    const spec = merge(inputTokens?.selectable?.["*"]?.["*"], inputTokens?.selectable?.[tone]?.["*"], inputTokens?.selectable?.["*"]?.[state], inputTokens?.selectable?.[tone]?.[state]), hue = spec._hue || inputTokens?.base?.[tone]?._hue;
    return {
        ...spec,
        _hue: hue,
        avatar: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$color$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLOR_HUES"].reduce((acc, hue2)=>({
                ...acc,
                [hue2]: merge({
                    _hue: hue2
                }, spec.avatar?.["*"], spec.avatar?.[hue2])
            }), {}),
        badge: THEME_COLOR_STATE_TONES.reduce((acc, tone2)=>({
                ...acc,
                [tone2]: {
                    _hue: inputTokens?.base?.[tone2]?._hue || hue,
                    ...spec.badge?.["*"],
                    ...spec.badge?.[tone2]
                }
            }), {})
    };
}
function buildColorTheme(config) {
    const resolvedConfig = {
        color: resolveColorTokens(config?.color)
    }, schemes = {};
    return defineLazyProperty(schemes, "light", ()=>buildColorScheme({
            scheme: "light"
        }, resolvedConfig)), defineLazyProperty(schemes, "dark", ()=>buildColorScheme({
            scheme: "dark"
        }, resolvedConfig)), schemes;
}
function buildColorScheme(options, config) {
    const { scheme } = options, colorScheme = {};
    for (const tone of THEME_COLOR_CARD_TONES)defineLazyProperty(colorScheme, tone, ()=>buildCardColorTheme({
            scheme,
            tone
        }, config));
    return colorScheme;
}
function buildCardColorTheme(options, config) {
    const { scheme, tone } = options, tokens = config?.color?.base?.[tone], context = {
        hue: tokens?._hue || "gray",
        scheme
    };
    return {
        _blend: (tokens?._blend || [
            "multiply",
            "screen"
        ])[scheme === "light" ? 0 : 1],
        _dark: scheme === "dark",
        accent: {
            fg: resolveColorTokenValue(context, tokens?.accent?.fg)
        },
        avatar: buildAvatarColorTheme({
            scheme
        }, tokens),
        backdrop: resolveColorTokenValue(context, tokens?.backdrop),
        badge: buildBadgeColorTheme(tokens?.badge, {
            scheme
        }, config),
        bg: resolveColorTokenValue(context, tokens?.bg),
        border: resolveColorTokenValue(context, tokens?.border),
        button: buildButtonColorTheme({
            scheme,
            tone
        }, config),
        code: {
            bg: resolveColorTokenValue(context, tokens?.code?.bg),
            fg: resolveColorTokenValue(context, tokens?.code?.fg)
        },
        fg: resolveColorTokenValue(context, tokens?.fg),
        focusRing: resolveColorTokenValue(context, tokens?.focusRing),
        icon: resolveColorTokenValue(context, tokens?.icon),
        input: buildInputColorTheme({
            scheme,
            tone
        }, config),
        kbd: {
            bg: resolveColorTokenValue(context, tokens?.kbd?.bg),
            fg: resolveColorTokenValue(context, tokens?.kbd?.fg),
            border: resolveColorTokenValue(context, tokens?.kbd?.border)
        },
        link: {
            fg: resolveColorTokenValue(context, tokens?.link?.fg)
        },
        muted: {
            bg: resolveColorTokenValue(context, tokens?.muted?.bg),
            fg: resolveColorTokenValue(context, tokens?.muted?.fg)
        },
        selectable: buildSelectableColorTheme({
            scheme,
            tone
        }, config),
        shadow: buildShadowColorTheme({
            scheme,
            tone
        }, config),
        skeleton: {
            from: resolveColorTokenValue(context, tokens?.skeleton?.from),
            to: resolveColorTokenValue(context, tokens?.skeleton?.to)
        },
        syntax: buildSyntaxColorTheme({
            scheme
        }, config)
    };
}
function buildShadowColorTheme(options, config) {
    const { scheme, tone } = options, tokens = config?.color?.base?.[tone], context = {
        hue: tokens?._hue || "gray",
        scheme
    };
    return {
        outline: resolveColorTokenValue(context, tokens?.shadow?.outline),
        umbra: resolveColorTokenValue(context, tokens?.shadow?.umbra),
        penumbra: resolveColorTokenValue(context, tokens?.shadow?.penumbra),
        ambient: resolveColorTokenValue(context, tokens?.shadow?.ambient)
    };
}
function buildAvatarColorTheme(options, stateTokens) {
    const { scheme } = options;
    return {
        gray: _buildAvatarColorTheme({
            color: "gray",
            scheme
        }, stateTokens),
        blue: _buildAvatarColorTheme({
            color: "blue",
            scheme
        }, stateTokens),
        purple: _buildAvatarColorTheme({
            color: "purple",
            scheme
        }, stateTokens),
        magenta: _buildAvatarColorTheme({
            color: "magenta",
            scheme
        }, stateTokens),
        red: _buildAvatarColorTheme({
            color: "red",
            scheme
        }, stateTokens),
        orange: _buildAvatarColorTheme({
            color: "orange",
            scheme
        }, stateTokens),
        yellow: _buildAvatarColorTheme({
            color: "yellow",
            scheme
        }, stateTokens),
        green: _buildAvatarColorTheme({
            color: "green",
            scheme
        }, stateTokens),
        cyan: _buildAvatarColorTheme({
            color: "cyan",
            scheme
        }, stateTokens)
    };
}
function _buildAvatarColorTheme(options, stateTokens) {
    const { color: color2, scheme } = options, tokens = stateTokens?.avatar?.[color2], context = {
        hue: tokens?._hue || "gray",
        scheme
    };
    return {
        _blend: (tokens?._blend || [
            "screen",
            "multiply"
        ])[scheme === "light" ? 0 : 1],
        bg: resolveColorTokenValue(context, tokens?.bg),
        fg: resolveColorTokenValue(context, tokens?.fg)
    };
}
function buildBadgeColorTheme(tokens, options, config) {
    const { scheme } = options, colorBadge = {};
    for (const tone of THEME_COLOR_STATE_TONES)colorBadge[tone] = _buildBadgeColorTheme(tokens, {
        scheme,
        tone
    }, config);
    return colorBadge;
}
function _buildBadgeColorTheme(parentTokens, options, config) {
    const { scheme, tone } = options, tokens = parentTokens?.[tone], context = {
        hue: tokens?._hue || config?.color?.base?.[tone]?._hue || "gray",
        scheme
    };
    return {
        bg: resolveColorTokenValue(context, tokens?.bg),
        fg: resolveColorTokenValue(context, tokens?.fg),
        dot: resolveColorTokenValue(context, tokens?.dot),
        icon: resolveColorTokenValue(context, tokens?.icon)
    };
}
function buildButtonColorTheme(options, config) {
    const { scheme, tone: cardTone } = options, modes = {};
    for (const mode of THEME_COLOR_BUTTON_MODES)modes[mode] = buildButtonTonesColorTheme({
        cardTone,
        scheme,
        mode
    }, config);
    return modes;
}
function buildButtonTonesColorTheme(options, config) {
    const { cardTone, mode, scheme } = options, tones2 = {};
    for (const tone of THEME_COLOR_STATE_TONES)tones2[tone] = buildButtonStatesColorTheme({
        cardTone,
        mode,
        scheme,
        tone
    }, config);
    return tones2;
}
function buildButtonStatesColorTheme(options, config) {
    const { cardTone, mode, scheme, tone } = options, states = {};
    for (const state of THEME_COLOR_STATES)states[state] = buildButtonStateColorTheme({
        cardTone,
        mode,
        tone,
        scheme,
        state
    }, config);
    return states;
}
function buildButtonStateColorTheme(options, config) {
    const { cardTone, mode, tone, scheme, state } = options, cardTokens = config?.color?.base?.[cardTone], tokens = config?.color?.button?.[mode]?.[tone]?.[state], hue = tokens?._hue || cardTokens?._hue || "gray", blendMode = tokens?._blend || [
        "screen",
        "multiply"
    ], context = {
        hue,
        scheme
    };
    return {
        _blend: blendMode[scheme === "light" ? 0 : 1],
        accent: {
            fg: resolveColorTokenValue(context, tokens?.accent?.fg)
        },
        avatar: buildAvatarColorTheme({
            scheme
        }, tokens),
        badge: buildBadgeColorTheme(tokens?.badge, {
            scheme
        }, config),
        bg: resolveColorTokenValue(context, tokens?.bg),
        border: resolveColorTokenValue(context, tokens?.border),
        code: {
            bg: resolveColorTokenValue(context, tokens?.code?.bg),
            fg: resolveColorTokenValue(context, tokens?.code?.fg)
        },
        fg: resolveColorTokenValue(context, tokens?.fg),
        icon: resolveColorTokenValue(context, tokens?.icon),
        muted: {
            bg: resolveColorTokenValue(context, tokens?.muted?.bg),
            fg: resolveColorTokenValue(context, tokens?.muted?.fg)
        },
        kbd: {
            bg: resolveColorTokenValue(context, tokens?.kbd?.bg),
            fg: resolveColorTokenValue(context, tokens?.kbd?.fg),
            border: resolveColorTokenValue(context, tokens?.kbd?.border)
        },
        link: {
            fg: resolveColorTokenValue(context, tokens?.link?.fg)
        },
        skeleton: {
            from: resolveColorTokenValue(context, tokens?.skeleton?.from),
            to: resolveColorTokenValue(context, tokens?.skeleton?.to)
        }
    };
}
function buildInputColorTheme(options, config) {
    const { scheme, tone } = options;
    return {
        default: buildInputStatesColorTheme({
            mode: "default",
            scheme,
            tone
        }, config),
        invalid: buildInputStatesColorTheme({
            mode: "invalid",
            scheme,
            tone
        }, config)
    };
}
function buildInputStatesColorTheme(options, config) {
    const { mode, scheme, tone } = options;
    return {
        enabled: buildInputStateColorTheme({
            mode,
            scheme,
            state: "enabled",
            cardTone: tone
        }, config),
        hovered: buildInputStateColorTheme({
            mode,
            scheme,
            state: "hovered",
            cardTone: tone
        }, config),
        readOnly: buildInputStateColorTheme({
            mode,
            scheme,
            state: "readOnly",
            cardTone: tone
        }, config),
        disabled: buildInputStateColorTheme({
            mode,
            scheme,
            state: "disabled",
            cardTone: tone
        }, config)
    };
}
function buildInputStateColorTheme(options, config) {
    const { cardTone, mode, scheme, state } = options, cardTokens = config?.color?.base?.[cardTone], tokens = config?.color?.input?.[mode]?.[state], hue = tokens?._hue || cardTokens?._hue || "gray", blendMode = tokens?._blend || [
        "screen",
        "multiply"
    ], context = {
        hue,
        scheme
    };
    return {
        _blend: blendMode[scheme === "light" ? 0 : 1],
        bg: resolveColorTokenValue(context, tokens?.bg),
        border: resolveColorTokenValue(context, tokens?.border),
        fg: resolveColorTokenValue(context, tokens?.fg),
        muted: {
            bg: resolveColorTokenValue(context, tokens?.muted?.bg)
        },
        placeholder: resolveColorTokenValue(context, tokens?.placeholder)
    };
}
function buildSelectableColorTheme(options, config) {
    const { scheme, tone: cardTone } = options, tones2 = {};
    for (const tone of THEME_COLOR_STATE_TONES)tones2[tone] = buildSelectableStatesColorTheme({
        cardTone,
        scheme,
        tone
    }, config);
    return tones2;
}
function buildSelectableStatesColorTheme(options, config) {
    const { cardTone, scheme, tone } = options, states = {};
    for (const state of THEME_COLOR_STATES)states[state] = buildSelectableStateColorTheme({
        cardTone,
        tone,
        scheme,
        state
    }, config);
    return states;
}
function buildSelectableStateColorTheme(options, config) {
    const { cardTone, scheme, state, tone } = options, cardTokens = config?.color?.base?.[cardTone], tokens = config?.color?.selectable?.[tone]?.[state], hue = tokens?._hue || cardTokens?._hue || "gray", blendMode = tokens?._blend || [
        "screen",
        "multiply"
    ], context = {
        hue,
        scheme
    };
    return {
        _blend: blendMode[scheme === "light" ? 0 : 1],
        accent: {
            fg: resolveColorTokenValue(context, tokens?.accent?.fg)
        },
        avatar: buildAvatarColorTheme({
            scheme
        }, tokens),
        badge: buildBadgeColorTheme(tokens?.badge, {
            scheme
        }, config),
        bg: resolveColorTokenValue(context, tokens?.bg),
        border: resolveColorTokenValue(context, tokens?.border),
        code: {
            bg: resolveColorTokenValue(context, tokens?.code?.bg),
            fg: resolveColorTokenValue(context, tokens?.code?.fg)
        },
        fg: resolveColorTokenValue(context, tokens?.fg),
        icon: resolveColorTokenValue(context, tokens?.icon),
        muted: {
            bg: resolveColorTokenValue(context, tokens?.muted?.bg),
            fg: resolveColorTokenValue(context, tokens?.muted?.fg)
        },
        kbd: {
            bg: resolveColorTokenValue(context, tokens?.kbd?.bg),
            fg: resolveColorTokenValue(context, tokens?.kbd?.fg),
            border: resolveColorTokenValue(context, tokens?.kbd?.border)
        },
        link: {
            fg: resolveColorTokenValue(context, tokens?.link?.fg)
        },
        skeleton: {
            from: resolveColorTokenValue(context, tokens?.skeleton?.from),
            to: resolveColorTokenValue(context, tokens?.skeleton?.to)
        }
    };
}
function buildSyntaxColorTheme(options, config) {
    const { scheme } = options, tokens = config?.color?.syntax, context = {
        hue: "gray",
        scheme
    };
    return {
        atrule: resolveColorTokenValue(context, tokens?.atrule),
        attrName: resolveColorTokenValue(context, tokens?.attrName),
        attrValue: resolveColorTokenValue(context, tokens?.attrValue),
        attribute: resolveColorTokenValue(context, tokens?.attribute),
        boolean: resolveColorTokenValue(context, tokens?.boolean),
        builtin: resolveColorTokenValue(context, tokens?.builtin),
        cdata: resolveColorTokenValue(context, tokens?.cdata),
        char: resolveColorTokenValue(context, tokens?.char),
        class: resolveColorTokenValue(context, tokens?.class),
        className: resolveColorTokenValue(context, tokens?.className),
        comment: resolveColorTokenValue(context, tokens?.comment),
        constant: resolveColorTokenValue(context, tokens?.constant),
        deleted: resolveColorTokenValue(context, tokens?.deleted),
        doctype: resolveColorTokenValue(context, tokens?.doctype),
        entity: resolveColorTokenValue(context, tokens?.entity),
        function: resolveColorTokenValue(context, tokens?.function),
        hexcode: resolveColorTokenValue(context, tokens?.hexcode),
        id: resolveColorTokenValue(context, tokens?.id),
        important: resolveColorTokenValue(context, tokens?.important),
        inserted: resolveColorTokenValue(context, tokens?.inserted),
        keyword: resolveColorTokenValue(context, tokens?.keyword),
        number: resolveColorTokenValue(context, tokens?.number),
        operator: resolveColorTokenValue(context, tokens?.operator),
        prolog: resolveColorTokenValue(context, tokens?.prolog),
        property: resolveColorTokenValue(context, tokens?.property),
        pseudoClass: resolveColorTokenValue(context, tokens?.pseudoClass),
        pseudoElement: resolveColorTokenValue(context, tokens?.pseudoElement),
        punctuation: resolveColorTokenValue(context, tokens?.punctuation),
        regex: resolveColorTokenValue(context, tokens?.regex),
        selector: resolveColorTokenValue(context, tokens?.selector),
        string: resolveColorTokenValue(context, tokens?.string),
        symbol: resolveColorTokenValue(context, tokens?.symbol),
        tag: resolveColorTokenValue(context, tokens?.tag),
        unit: resolveColorTokenValue(context, tokens?.unit),
        url: resolveColorTokenValue(context, tokens?.url),
        variable: resolveColorTokenValue(context, tokens?.variable)
    };
}
const defaultColorPalette = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$color$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["color"];
function mixChannel(b, s, weight) {
    const delta = (s - b) * weight;
    return b + delta;
}
function mix(b, s, weight) {
    return {
        r: mixChannel(b.r, s.r, weight),
        g: mixChannel(b.g, s.g, weight),
        b: mixChannel(b.b, s.b, weight)
    };
}
function multiplyChannel(b, s) {
    return b * s;
}
function multiply(b, s) {
    return {
        r: multiplyChannel(b.r / 255, s.r / 255) * 255,
        g: multiplyChannel(b.g / 255, s.g / 255) * 255,
        b: multiplyChannel(b.b / 255, s.b / 255) * 255
    };
}
function screenChannel(b, s) {
    return b + s - b * s;
}
function screen(b, s) {
    return {
        r: screenChannel(b.r / 255, s.r / 255) * 255,
        g: screenChannel(b.g / 255, s.g / 255) * 255,
        b: screenChannel(b.b / 255, s.b / 255) * 255
    };
}
function lerp(x, y, a) {
    return x * (1 - a) + y * a;
}
function invlerp(x, y, a) {
    return clamp((a - x) / (y - x));
}
function clamp(a, min = 0, max = 1) {
    return Math.min(max, Math.max(min, a));
}
function range(x1, y1, x2, y2, a) {
    return lerp(x2, y2, invlerp(x1, y1, a));
}
function round(value) {
    return Math.round(value);
}
function hexToRgb(hex) {
    if (hex.length === 4) {
        const hexR = hex.slice(1, 2), hexG = hex.slice(2, 3), hexB = hex.slice(3, 4);
        return {
            r: parseInt(hexR + hexR, 16),
            g: parseInt(hexG + hexG, 16),
            b: parseInt(hexB + hexB, 16)
        };
    }
    return {
        r: parseInt(hex.slice(1, 3), 16),
        g: parseInt(hex.slice(3, 5), 16),
        b: parseInt(hex.slice(5, 7), 16)
    };
}
function rgbaToRGBA(rgba2) {
    const values = rgba2.replace(/rgba\(|\)/g, "").split(",");
    return {
        r: parseInt(values[0]),
        g: parseInt(values[1]),
        b: parseInt(values[2]),
        a: parseFloat(values[3])
    };
}
function rgbToHex(color2) {
    const r = round(clamp(Math.round(color2.r), 0, 255)), g = round(clamp(Math.round(color2.g), 0, 255)), b = round(clamp(Math.round(color2.b), 0, 255));
    return "a" in color2 ? `rgba(${r},${g},${b},${color2.a})` : "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}
function rgbToHsl({ r, g, b }) {
    r /= 255, g /= 255, b /= 255;
    const cmin = Math.min(r, g, b), cmax = Math.max(r, g, b), delta = cmax - cmin;
    let h = 0, s = 0, l = 0;
    return delta == 0 ? h = 0 : cmax == r ? h = (g - b) / delta % 6 : cmax == g ? h = (b - r) / delta + 2 : h = (r - g) / delta + 4, h = Math.round(h * 60), h < 0 && (h += 360), l = (cmax + cmin) / 2, s = delta == 0 ? 0 : delta / (1 - Math.abs(2 * l - 1)), s = +(s * 100).toFixed(1), l = +(l * 100).toFixed(1), {
        h,
        s,
        l
    };
}
function hslToRgb(hsl) {
    const s = hsl.s / 100, l = hsl.l / 100, c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs(hsl.h / 60 % 2 - 1)), m = l - c / 2;
    let r = 0, g = 0, b = 0;
    return 0 <= hsl.h && hsl.h < 60 ? (r = c, g = x, b = 0) : 60 <= hsl.h && hsl.h < 120 ? (r = x, g = c, b = 0) : 120 <= hsl.h && hsl.h < 180 ? (r = 0, g = c, b = x) : 180 <= hsl.h && hsl.h < 240 ? (r = 0, g = x, b = c) : 240 <= hsl.h && hsl.h < 300 ? (r = x, g = 0, b = c) : 300 <= hsl.h && hsl.h < 360 && (r = c, g = 0, b = x), {
        r: Math.round((r + m) * 255),
        g: Math.round((g + m) * 255),
        b: Math.round((b + m) * 255)
    };
}
const HEX_CHARS = "0123456789ABCDEFabcdef", HSL_RE = /hsl\(\s*(\d+)\s*,\s*((\d+(?:\.\d+)?)%)\s*,\s*((\d+(?:\.\d+)?)%)\s*\)/i;
function isHexChars(str) {
    for (const c of str)if (HEX_CHARS.indexOf(c) === -1) return !1;
    return !0;
}
function isHex(str) {
    return str[0] !== "#" || !(str.length === 4 || str.length === 7) ? !1 : isHexChars(str.slice(1));
}
function parseHsl(str) {
    const res = HSL_RE.exec(str);
    if (!res) throw new Error(`parseHsl: string is not a HSL color: "${str}"`);
    return {
        h: parseInt(res[1]),
        s: parseFloat(res[3]),
        l: parseFloat(res[5])
    };
}
function parseColor(color2) {
    if (!color2) return {
        r: 0,
        g: 0,
        b: 0
    };
    if (typeof color2 != "string") throw new Error("parseColor: expected a string");
    if (isHex(color2)) return hexToRgb(color2);
    if (color2.startsWith("hsl(")) return hslToRgb(parseHsl(color2));
    if (color2.startsWith("rgba(")) return rgbaToRGBA(color2);
    throw new Error(`parseColor: unexpected color format: "${color2}"`);
}
function getContrastRatio(bg, fg) {
    const rgb1 = parseColor(bg), rgb2 = parseColor(fg), c1 = rgb_lrgb(rgb1), c2 = rgb_lrgb(rgb2), l1 = lrgb_luminance(c1), l2 = lrgb_luminance(c2);
    return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}
function rgb_lrgb({ r, g, b }) {
    return [
        rgb_lrgb1(r / 255),
        rgb_lrgb1(g / 255),
        rgb_lrgb1(b / 255)
    ];
}
function rgb_lrgb1(v) {
    return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
}
function lrgb_luminance([r, g, b]) {
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
function rgba(color2, a) {
    const rgb = parseColor(color2);
    return `rgba(${rgb.r},${rgb.g},${rgb.b},${a})`;
}
const RGB_RANGE = [
    0,
    255
];
function mixThemeColor(value, options) {
    const { blendMode } = options, color2 = parseColor(value), black2 = parseColor(options.black), white2 = parseColor(options.white), bg = options.bg ? parseColor(options.bg) : blendMode === "multiply" ? white2 : black2, paletteRange = {
        r: [
            black2.r,
            white2.r
        ],
        g: [
            black2.g,
            white2.g
        ],
        b: [
            black2.b,
            white2.b
        ]
    }, convertedBgColor = {
        r: clamp(range(...paletteRange.r, ...RGB_RANGE, bg.r), ...RGB_RANGE),
        g: clamp(range(...paletteRange.g, ...RGB_RANGE, bg.g), ...RGB_RANGE),
        b: clamp(range(...paletteRange.b, ...RGB_RANGE, bg.b), ...RGB_RANGE)
    }, convertedColor = {
        r: clamp(range(...paletteRange.r, ...RGB_RANGE, color2.r), ...RGB_RANGE),
        g: clamp(range(...paletteRange.g, ...RGB_RANGE, color2.g), ...RGB_RANGE),
        b: clamp(range(...paletteRange.b, ...RGB_RANGE, color2.b), ...RGB_RANGE)
    }, resultColor = blendMode === "multiply" ? multiply(convertedBgColor, convertedColor) : screen(convertedBgColor, convertedColor), v = {
        r: clamp(range(...RGB_RANGE, ...paletteRange.r, resultColor.r), ...paletteRange.r),
        g: clamp(range(...RGB_RANGE, ...paletteRange.g, resultColor.g), ...paletteRange.g),
        b: clamp(range(...RGB_RANGE, ...paletteRange.b, resultColor.b), ...paletteRange.b)
    };
    return rgbToHex(v);
}
function renderColorValue(str, options) {
    const { bg, blendMode, colorPalette } = options;
    if (bg === "white") throw new Error("Cannot blend with white background");
    const node = parseTokenValue(str);
    if (!node || node.type !== "color") throw new Error(`Invalid color token value: ${str}`);
    let hex = "";
    if (node.key === "black" && (hex = renderColorHex(colorPalette.black)), node.key === "white" && (hex = renderColorHex(colorPalette.white)), node.hue && node.tint && (hex = renderColorHex(colorPalette[node.hue][node.tint])), !hex) throw new Error(`Invalid color token value: ${str}`);
    const hexBeforeMix = hex, mixOptions = {
        blendMode,
        bg,
        black: renderColorHex(colorPalette.black),
        // opacity: node.opacity,
        white: renderColorHex(colorPalette.white)
    };
    try {
        if (hex = mixThemeColor(hex, mixOptions), bg && node.mix !== void 0) {
            const from = hexToRgb(bg), to = hexToRgb(hex);
            hex = rgbToHex(mix(from, to, node.mix));
        }
    } catch (err) {
        throw console.warn("could not blend", hex, mixOptions), err;
    }
    return hex === "#aN" && (console.warn(`invalid color token value: ${str}`), hex = hexBeforeMix), node.opacity !== void 0 && (hex = rgba(hex, node.opacity)), hex;
}
function renderColorHex(color2) {
    return typeof color2 == "string" ? color2 : color2.hex;
}
function renderThemeColorSchemes(value, config) {
    const colorPalette = config?.palette ?? defaultColorPalette, schemes = {};
    return defineLazyProperty(schemes, "light", ()=>renderThemeColorScheme(colorPalette, value.light)), defineLazyProperty(schemes, "dark", ()=>renderThemeColorScheme(colorPalette, value.dark)), schemes;
}
function renderThemeColorScheme(colorPalette, value) {
    const renderedDefaultTone = renderThemeColor(value.default, {
        colorPalette
    }), bg = renderedDefaultTone.bg;
    if (bg === "white") throw new Error("Cannot blend with white background");
    const scheme = {
        default: renderedDefaultTone
    };
    for (const tone of THEME_COLOR_CARD_TONES){
        if (tone === "default") continue;
        const opts = tone === "transparent" ? {
            colorPalette
        } : {
            bg,
            colorPalette
        };
        defineLazyProperty(scheme, tone, ()=>renderThemeColor(value[tone], opts));
    }
    return scheme;
}
function renderThemeColor(value, options) {
    const { colorPalette, bg } = options, blendMode = value._blend || "multiply", baseBg = renderColorValue(value.bg, {
        colorPalette,
        bg,
        blendMode
    }), colorOptions = {
        colorPalette,
        bg: baseBg,
        blendMode
    }, button = renderThemeColorButton(value.button, {
        baseBg,
        blendMode,
        colorPalette
    }), selectable = renderThemeColorSelectable(value.selectable, {
        colorPalette,
        baseBg,
        blendMode
    }), shadow = {
        outline: renderColorValue(value.shadow.outline, colorOptions),
        umbra: renderColorValue(value.shadow.umbra, {
            ...colorOptions,
            bg: void 0,
            colorPalette: {
                ...colorPalette,
                black: "#000000"
            }
        }),
        penumbra: renderColorValue(value.shadow.penumbra, {
            ...colorOptions,
            bg: void 0,
            colorPalette: {
                ...colorPalette,
                black: "#000000"
            }
        }),
        ambient: renderColorValue(value.shadow.ambient, {
            ...colorOptions,
            bg: void 0,
            colorPalette: {
                ...colorPalette,
                black: "#000000"
            }
        })
    };
    return {
        _blend: blendMode,
        _dark: value._dark,
        accent: {
            fg: renderColorValue(value.accent.fg, colorOptions)
        },
        avatar: renderThemeColorAvatar(value.avatar, {
            baseBg,
            colorPalette,
            blendMode
        }),
        backdrop: renderColorValue(value.backdrop, colorOptions),
        badge: renderThemeColorBadge(value.badge, {
            baseBg,
            colorPalette,
            blendMode
        }),
        bg: baseBg,
        border: renderColorValue(value.border, colorOptions),
        button,
        code: {
            bg: renderColorValue(value.code.bg, colorOptions),
            fg: renderColorValue(value.code.fg, colorOptions)
        },
        fg: renderColorValue(value.fg, colorOptions),
        focusRing: renderColorValue(value.focusRing, colorOptions),
        icon: renderColorValue(value.icon, colorOptions),
        input: renderThemeColorInput(value.input, {
            baseBg,
            colorPalette,
            blendMode
        }),
        kbd: renderThemeColorKBD(value.kbd, {
            baseBg,
            colorPalette,
            blendMode
        }),
        link: {
            fg: renderColorValue(value.link.fg, colorOptions)
        },
        muted: {
            bg: renderColorValue(value.muted.bg, colorOptions),
            fg: renderColorValue(value.muted.fg, colorOptions)
        },
        shadow,
        skeleton: {
            from: renderColorValue(value.skeleton.from, colorOptions),
            to: renderColorValue(value.skeleton.to, colorOptions)
        },
        syntax: renderSyntaxColorTheme(value.syntax, {
            baseBg,
            colorPalette,
            blendMode
        }),
        selectable
    };
}
function renderThemeColorKBD(value, options) {
    const { baseBg, blendMode, colorPalette } = options, rootOptions = {
        bg: baseBg,
        blendMode,
        colorPalette
    }, bg = renderColorValue(value.bg, rootOptions), colorOptions = {
        bg,
        blendMode,
        colorPalette
    };
    return {
        bg,
        fg: renderColorValue(value.fg, colorOptions),
        border: renderColorValue(value.border, colorOptions)
    };
}
function renderThemeColorAvatar(value, options) {
    const colorAvatar = {};
    for (const hue of __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$color$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["COLOR_HUES"])colorAvatar[hue] = renderThemeColorAvatarColor(value[hue], options);
    return colorAvatar;
}
function renderThemeColorAvatarColor(value, options) {
    const { baseBg, blendMode: rootBlendMode, colorPalette } = options, blendMode = value._blend || "multiply", rootOptions = {
        bg: baseBg,
        blendMode: rootBlendMode,
        colorPalette
    }, bg = renderColorValue(value.bg, rootOptions), colorOptions = {
        bg,
        blendMode,
        colorPalette
    };
    return {
        _blend: blendMode,
        bg,
        fg: renderColorValue(value.fg, colorOptions)
    };
}
function renderThemeColorBadge(value, options) {
    const colorBadge = {};
    for (const tone of THEME_COLOR_STATE_TONES)colorBadge[tone] = renderThemeColorBadgeColor(value[tone], options);
    return colorBadge;
}
function renderThemeColorBadgeColor(value, options) {
    const { baseBg, blendMode: rootBlendMode, colorPalette } = options, blendMode = rootBlendMode, rootOptions = {
        bg: baseBg,
        blendMode: rootBlendMode,
        colorPalette
    }, bg = renderColorValue(value.bg, rootOptions), colorOptions = {
        bg,
        blendMode,
        colorPalette
    };
    return {
        bg,
        dot: renderColorValue(value.dot, colorOptions),
        fg: renderColorValue(value.fg, colorOptions),
        icon: renderColorValue(value.icon, colorOptions)
    };
}
function renderThemeColorButton(value, options) {
    return {
        default: renderThemeColorButtonTones(value.default, options),
        ghost: renderThemeColorButtonTones(value.ghost, options),
        bleed: renderThemeColorButtonTones(value.bleed, options)
    };
}
function renderThemeColorButtonTones(value, options) {
    const colorButtonMode = {};
    for (const tone of THEME_COLOR_STATE_TONES)colorButtonMode[tone] = renderThemeColorButtonStates(value[tone], options);
    return colorButtonMode;
}
function renderThemeColorButtonStates(value, options) {
    return {
        enabled: renderThemeColorState(value.enabled, options),
        hovered: renderThemeColorState(value.hovered, options),
        pressed: renderThemeColorState(value.pressed, options),
        selected: renderThemeColorState(value.selected, options),
        disabled: renderThemeColorState(value.disabled, options)
    };
}
function renderThemeColorState(value, options) {
    const { baseBg, blendMode: rootBlendMode, colorPalette } = options, blendMode = value._blend || "multiply", rootOptions = {
        bg: baseBg,
        blendMode: rootBlendMode,
        colorPalette
    }, bg = renderColorValue(value.bg, rootOptions), colorOptions = {
        bg,
        blendMode,
        colorPalette
    };
    return {
        _blend: blendMode,
        accent: {
            fg: renderColorValue(value.accent.fg, colorOptions)
        },
        avatar: renderThemeColorAvatar(value.avatar, {
            baseBg: bg,
            colorPalette,
            blendMode
        }),
        badge: renderThemeColorBadge(value.badge, {
            baseBg: bg,
            colorPalette,
            blendMode
        }),
        bg,
        border: renderColorValue(value.border, colorOptions),
        code: {
            bg: renderColorValue(value.code.bg, colorOptions),
            fg: renderColorValue(value.code.fg, colorOptions)
        },
        fg: renderColorValue(value.fg, colorOptions),
        icon: renderColorValue(value.icon, colorOptions),
        link: {
            fg: renderColorValue(value.link.fg, colorOptions)
        },
        muted: {
            bg: renderColorValue(value.muted.bg, colorOptions),
            fg: renderColorValue(value.muted.fg, colorOptions)
        },
        kbd: {
            bg: renderColorValue(value.kbd.bg, colorOptions),
            fg: renderColorValue(value.kbd.fg, colorOptions),
            border: renderColorValue(value.kbd.border, colorOptions)
        },
        skeleton: {
            from: renderColorValue(value.skeleton?.from, colorOptions),
            to: renderColorValue(value.skeleton?.to, colorOptions)
        }
    };
}
function renderThemeColorInput(value, options) {
    return {
        default: renderInputStatesColorTheme(value.default, options),
        invalid: renderInputStatesColorTheme(value.invalid, options)
    };
}
function renderInputStatesColorTheme(value, options) {
    return {
        enabled: renderInputStateColorTheme(value.enabled, options),
        hovered: renderInputStateColorTheme(value.hovered, options),
        readOnly: renderInputStateColorTheme(value.readOnly, options),
        disabled: renderInputStateColorTheme(value.disabled, options)
    };
}
function renderInputStateColorTheme(value, options) {
    const { baseBg, blendMode: rootBlendMode, colorPalette } = options, blendMode = value._blend || "multiply", rootOptions = {
        colorPalette,
        bg: baseBg,
        blendMode: rootBlendMode
    }, bg = renderColorValue(value.bg, rootOptions), colorOptions = {
        colorPalette,
        bg,
        blendMode
    };
    return {
        _blend: blendMode,
        bg,
        border: renderColorValue(value.border, colorOptions),
        fg: renderColorValue(value.fg, colorOptions),
        muted: {
            bg: renderColorValue(value.muted.bg, colorOptions)
        },
        placeholder: renderColorValue(value.placeholder, colorOptions)
    };
}
function renderThemeColorSelectable(value, options) {
    const colorSelectable = {};
    for (const tone of THEME_COLOR_STATE_TONES)colorSelectable[tone] = renderThemeColorSelectableStates(value[tone], options);
    return colorSelectable;
}
function renderThemeColorSelectableStates(value, options) {
    return {
        enabled: renderThemeColorState(value.enabled, options),
        hovered: renderThemeColorState(value.hovered, options),
        pressed: renderThemeColorState(value.pressed, options),
        selected: renderThemeColorState(value.selected, options),
        disabled: renderThemeColorState(value.disabled, options)
    };
}
function renderSyntaxColorTheme(value, options) {
    const { colorPalette, baseBg, blendMode } = options, colorOptions = {
        colorPalette,
        bg: baseBg,
        blendMode
    };
    return {
        atrule: renderColorValue(value.atrule, colorOptions),
        attrName: renderColorValue(value.attrName, colorOptions),
        attrValue: renderColorValue(value.attrValue, colorOptions),
        attribute: renderColorValue(value.attribute, colorOptions),
        boolean: renderColorValue(value.boolean, colorOptions),
        builtin: renderColorValue(value.builtin, colorOptions),
        cdata: renderColorValue(value.cdata, colorOptions),
        char: renderColorValue(value.char, colorOptions),
        class: renderColorValue(value.class, colorOptions),
        className: renderColorValue(value.className, colorOptions),
        comment: renderColorValue(value.comment, colorOptions),
        constant: renderColorValue(value.constant, colorOptions),
        deleted: renderColorValue(value.deleted, colorOptions),
        doctype: renderColorValue(value.doctype, colorOptions),
        entity: renderColorValue(value.entity, colorOptions),
        function: renderColorValue(value.function, colorOptions),
        hexcode: renderColorValue(value.hexcode, colorOptions),
        id: renderColorValue(value.id, colorOptions),
        important: renderColorValue(value.important, colorOptions),
        inserted: renderColorValue(value.inserted, colorOptions),
        keyword: renderColorValue(value.keyword, colorOptions),
        number: renderColorValue(value.number, colorOptions),
        operator: renderColorValue(value.operator, colorOptions),
        prolog: renderColorValue(value.prolog, colorOptions),
        property: renderColorValue(value.property, colorOptions),
        pseudoClass: renderColorValue(value.pseudoClass, colorOptions),
        pseudoElement: renderColorValue(value.pseudoElement, colorOptions),
        punctuation: renderColorValue(value.punctuation, colorOptions),
        regex: renderColorValue(value.regex, colorOptions),
        selector: renderColorValue(value.selector, colorOptions),
        string: renderColorValue(value.string, colorOptions),
        symbol: renderColorValue(value.symbol, colorOptions),
        tag: renderColorValue(value.tag, colorOptions),
        unit: renderColorValue(value.unit, colorOptions),
        url: renderColorValue(value.url, colorOptions),
        variable: renderColorValue(value.variable, colorOptions)
    };
}
function buildTheme(config) {
    const colorTheme = buildColorTheme(config), v2 = {
        _version: 2,
        avatar: config?.avatar ?? defaultThemeConfig.avatar,
        button: config?.button ?? defaultThemeConfig.button,
        card: config?.card ?? defaultThemeConfig.card,
        // How colors are generated:
        // 1. Merge custom tokens with default tokens
        // 2. Generate tree of color keys (gray/500, black, white, etc.)
        // 3. Apply mixing and render to hex values
        // render(build(mergeWithDefaults()))
        color: renderThemeColorSchemes(colorTheme, config),
        container: config?.container ?? defaultThemeConfig.container,
        font: config?.font ?? defaultThemeFonts,
        input: config?.input ?? defaultThemeConfig.input,
        layer: config?.layer ?? defaultThemeConfig.layer,
        media: config?.media ?? defaultThemeConfig.media,
        radius: config?.radius ?? defaultThemeConfig.radius,
        shadow: config?.shadow ?? defaultThemeConfig.shadow,
        space: config?.space ?? defaultThemeConfig.space,
        style: config?.style ?? defaultThemeConfig.style
    };
    return v2_v0(v2);
}
function themeColor_v0_v2_9(color2) {
    if ("neutral" in color2.badge) return color2;
    const colors2 = color2;
    return {
        ...colors2,
        badge: {
            ...colors2.badge,
            neutral: colors2.badge.default,
            suggest: colors2.badge.primary
        },
        button: {
            bleed: {
                ...colors2.button.bleed,
                neutral: colors2.button.bleed.default,
                suggest: colors2.button.bleed.primary
            },
            default: {
                ...colors2.button.default,
                neutral: colors2.button.default.default,
                suggest: colors2.button.default.primary
            },
            ghost: {
                ...colors2.button.ghost,
                neutral: colors2.button.ghost.default,
                suggest: colors2.button.ghost.primary
            }
        },
        selectable: {
            ...colors2.selectable,
            neutral: colors2.selectable.default,
            suggest: colors2.selectable.primary
        }
    };
}
const cache = /* @__PURE__ */ new Map();
function getScopedTheme(themeProp, scheme, tone) {
    const cachedTheme = _getCachedTheme(themeProp, scheme, tone);
    if (cachedTheme) return cachedTheme;
    const v0 = is_v2(themeProp) ? v2_v0(themeProp) : themeProp, v2 = is_v2(themeProp) ? themeProp : v0_v2(themeProp), layer_v0 = v0.layer || defaultThemeConfig.layer, colorScheme_v2 = v2.color[scheme] || v2.color.light, color_v2 = colorScheme_v2[tone] || colorScheme_v2.default, color_v2_9 = themeColor_v0_v2_9(color_v2), layer_v2 = v2.layer || defaultThemeConfig.layer, { color: _v0Color, ...v0Rest } = v0, sanity = {
        ...v0Rest,
        layer: layer_v0,
        v2: {
            ...v2,
            _resolved: !0,
            color: color_v2_9,
            layer: layer_v2
        }
    };
    defineLazyProperty(sanity, "color", ()=>{
        const colorScheme_v0 = v0.color[scheme] || v0.color.light;
        return colorScheme_v0[tone] || colorScheme_v0.default;
    });
    const theme = {
        sanity
    };
    return _setCachedTheme(themeProp, scheme, tone, theme), theme;
}
function _getCachedTheme(rootTheme, scheme, tone) {
    const schemeCache = cache.get(scheme);
    if (!schemeCache) return;
    const toneCache = schemeCache.get(tone);
    if (toneCache) return toneCache.get(rootTheme);
}
function _setCachedTheme(rootTheme, scheme, tone, theme) {
    cache.has(scheme) || cache.set(scheme, /* @__PURE__ */ new Map());
    const schemeCache = cache.get(scheme);
    schemeCache.has(tone) || schemeCache.set(tone, /* @__PURE__ */ new WeakMap()), schemeCache.get(tone).set(rootTheme, theme);
}
;
}),
"[project]/node_modules/@sanity/ui/dist/_chunks-es/_visual-editing.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Arrow",
    ()=>Arrow,
    "Avatar",
    ()=>Avatar,
    "AvatarCounter",
    ()=>AvatarCounter,
    "AvatarStack",
    ()=>AvatarStack,
    "Badge",
    ()=>Badge,
    "BoundaryElementProvider",
    ()=>BoundaryElementProvider,
    "Box",
    ()=>Box,
    "Button",
    ()=>Button,
    "Card",
    ()=>Card,
    "Checkbox",
    ()=>Checkbox,
    "Code",
    ()=>Code,
    "ConditionalWrapper",
    ()=>ConditionalWrapper,
    "Container",
    ()=>Container,
    "EMPTY_ARRAY",
    ()=>EMPTY_ARRAY,
    "EMPTY_RECORD",
    ()=>EMPTY_RECORD,
    "ElementQuery",
    ()=>ElementQuery,
    "Flex",
    ()=>Flex,
    "Grid",
    ()=>Grid,
    "Heading",
    ()=>Heading,
    "Hotkeys",
    ()=>Hotkeys,
    "Inline",
    ()=>Inline,
    "KBD",
    ()=>KBD,
    "Label",
    ()=>Label,
    "Layer",
    ()=>Layer,
    "LayerProvider",
    ()=>LayerProvider,
    "Menu",
    ()=>Menu,
    "MenuDivider",
    ()=>MenuDivider,
    "MenuGroup",
    ()=>MenuGroup,
    "MenuItem",
    ()=>MenuItem,
    "Popover",
    ()=>Popover,
    "Portal",
    ()=>Portal,
    "PortalProvider",
    ()=>PortalProvider,
    "Radio",
    ()=>Radio,
    "Select",
    ()=>Select,
    "Spinner",
    ()=>Spinner,
    "SrOnly",
    ()=>SrOnly,
    "Stack",
    ()=>Stack,
    "Switch",
    ()=>Switch,
    "Tab",
    ()=>Tab,
    "TabList",
    ()=>TabList,
    "Text",
    ()=>Text,
    "TextArea",
    ()=>TextArea,
    "TextInput",
    ()=>TextInput,
    "ThemeColorProvider",
    ()=>ThemeColorProvider,
    "ThemeProvider",
    ()=>ThemeProvider,
    "Tooltip",
    ()=>Tooltip,
    "TooltipDelayGroupContext",
    ()=>TooltipDelayGroupContext,
    "TooltipDelayGroupProvider",
    ()=>TooltipDelayGroupProvider,
    "VirtualList",
    ()=>VirtualList,
    "_ResizeObserver",
    ()=>_ResizeObserver,
    "_cardColorStyle",
    ()=>_cardColorStyle,
    "_elementSizeObserver",
    ()=>_elementSizeObserver,
    "_fillCSSObject",
    ()=>_fillCSSObject,
    "_getArrayProp",
    ()=>_getArrayProp,
    "_getResponsiveSpace",
    ()=>_getResponsiveSpace,
    "_isEnterToClickElement",
    ()=>_isEnterToClickElement,
    "_isScrollable",
    ()=>_isScrollable,
    "_responsive",
    ()=>_responsive,
    "containsOrEqualsElement",
    ()=>containsOrEqualsElement,
    "createColorTheme",
    ()=>createColorTheme,
    "createGlobalScopedContext",
    ()=>createGlobalScopedContext,
    "hexToRgb",
    ()=>hexToRgb,
    "hslToRgb",
    ()=>hslToRgb,
    "isHTMLAnchorElement",
    ()=>isHTMLAnchorElement,
    "isHTMLButtonElement",
    ()=>isHTMLButtonElement,
    "isHTMLElement",
    ()=>isHTMLElement,
    "isHTMLInputElement",
    ()=>isHTMLInputElement,
    "isHTMLSelectElement",
    ()=>isHTMLSelectElement,
    "isHTMLTextAreaElement",
    ()=>isHTMLTextAreaElement,
    "isRecord",
    ()=>isRecord,
    "multiply",
    ()=>multiply,
    "parseColor",
    ()=>parseColor,
    "rem",
    ()=>rem,
    "responsiveCodeFontStyle",
    ()=>responsiveCodeFontStyle,
    "responsiveHeadingFont",
    ()=>responsiveHeadingFont,
    "responsiveLabelFont",
    ()=>responsiveLabelFont,
    "responsivePaddingStyle",
    ()=>responsivePaddingStyle,
    "responsiveRadiusStyle",
    ()=>responsiveRadiusStyle,
    "responsiveTextAlignStyle",
    ()=>responsiveTextAlignStyle,
    "responsiveTextFont",
    ()=>responsiveTextFont,
    "rgbToHex",
    ()=>rgbToHex,
    "rgbToHsl",
    ()=>rgbToHsl,
    "rgba",
    ()=>rgba,
    "screen",
    ()=>screen,
    "studioTheme",
    ()=>studioTheme,
    "useBoundaryElement",
    ()=>useBoundaryElement,
    "useClickOutsideEvent",
    ()=>useClickOutsideEvent,
    "useCustomValidity",
    ()=>useCustomValidity,
    "useElementSize",
    ()=>useElementSize,
    "useGlobalKeyDown",
    ()=>useGlobalKeyDown,
    "useLayer",
    ()=>useLayer,
    "useMatchMedia",
    ()=>useMatchMedia,
    "useMediaIndex",
    ()=>useMediaIndex,
    "usePortal",
    ()=>usePortal,
    "usePrefersDark",
    ()=>usePrefersDark,
    "usePrefersReducedMotion",
    ()=>usePrefersReducedMotion,
    "useRootTheme",
    ()=>useRootTheme,
    "useTheme",
    ()=>useTheme,
    "useTheme_v2",
    ()=>useTheme_v2,
    "useTooltipDelayGroup",
    ()=>useTooltipDelayGroup
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/dist/theme.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/react-compiler-runtime/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-is/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/icons/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$exports$2f$resize$2d$observer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/exports/resize-observer.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserver$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@juggle/resize-observer/lib/ResizeObserver.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$effect$2d$event$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/use-effect-event/dist/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
const createColorTheme = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createColorTheme"], hexToRgb = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgb"], hslToRgb = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hslToRgb"], multiply = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["multiply"], parseColor = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseColor"], rgbToHex = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToHex"], rgbToHsl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToHsl"], rgba = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgba"], screen = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["screen"], studioTheme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTheme"])(), EMPTY_ARRAY = [], EMPTY_RECORD = {}, POPOVER_MOTION_PROPS = {
    card: {
        initial: {
            scale: 0.97,
            willChange: "transform"
        },
        hidden: {
            opacity: 0
        },
        visible: {
            opacity: 1,
            transition: {
                when: "beforeChildren",
                duration: 0.1
            }
        },
        scaleIn: {
            scale: 1
        },
        scaleOut: {
            scale: 0.97
        }
    },
    children: {
        hidden: {
            opacity: 0
        },
        visible: {
            opacity: 1
        }
    },
    transition: {
        type: "spring",
        visualDuration: 0.2,
        bounce: 0.25
    }
};
function _isEnterToClickElement(element) {
    return isHTMLAnchorElement(element) || isHTMLButtonElement(element);
}
function isHTMLElement(node) {
    return node instanceof Node && node.nodeType === Node.ELEMENT_NODE;
}
function isHTMLAnchorElement(element) {
    return isHTMLElement(element) && element.nodeName === "A";
}
function isHTMLInputElement(element) {
    return isHTMLElement(element) && element.nodeName === "INPUT";
}
function isHTMLButtonElement(element) {
    return isHTMLElement(element) && element.nodeName === "BUTTON";
}
function isHTMLSelectElement(element) {
    return isHTMLElement(element) && element.nodeName === "SELECT";
}
function isHTMLTextAreaElement(element) {
    return isHTMLElement(element) && element.nodeName === "TEXTAREA";
}
function containsOrEqualsElement(element, node) {
    return element.contains(node) || element === node;
}
function _isScrollable(el) {
    if (!(el instanceof Element)) return !1;
    const style = window.getComputedStyle(el);
    return style.overflowX.includes("auto") || style.overflowX.includes("scroll") || style.overflowY.includes("auto") || style.overflowY.includes("scroll");
}
function _fillCSSObject(keys, value) {
    return keys.reduce((style, key2)=>(style[key2] = value, style), {});
}
function rem(pixelValue) {
    return pixelValue === 0 ? 0 : `${pixelValue / 16}rem`;
}
function _responsive(media, values, callback) {
    return (values?.map(callback) || []).map((statement, mediaIndex)=>mediaIndex === 0 ? statement : {
            [`@media screen and (min-width: ${media[mediaIndex - 1]}px)`]: statement
        });
}
function _getArrayProp(val, defaultVal) {
    return val === void 0 ? defaultVal || EMPTY_ARRAY : Array.isArray(val) ? val : [
        val
    ];
}
function _getResponsiveSpace(theme, props, spaceIndexes = EMPTY_ARRAY) {
    if (!Array.isArray(spaceIndexes)) throw new Error("the property must be array of numbers");
    if (spaceIndexes.length === 0) return null;
    const { media, space } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(theme);
    return _responsive(media, spaceIndexes, (spaceIndex)=>_fillCSSObject(props, rem(space[spaceIndex])));
}
function responsiveFont(fontKey, props) {
    const { $size, $weight } = props, { font, media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), { family, sizes, weights } = font[fontKey], fontWeight = $weight && weights[$weight] || weights.regular, defaultSize = sizes[2], base = {
        position: "relative",
        fontFamily: family,
        fontWeight: `${fontWeight}`,
        padding: "1px 0",
        margin: 0,
        "&:before": {
            content: '""',
            display: "block",
            height: 0
        },
        "&:after": {
            content: '""',
            display: "block",
            height: 0
        },
        "& > code, & > span": {
            display: "block"
        },
        "&:not([hidden])": {
            display: "block"
        }
    };
    if (!$size) return responsiveFont.warned || (console.warn("No size specified for responsive font", {
        fontKey,
        $size,
        props,
        base
    }), responsiveFont.warned = !0), [
        base
    ];
    const resp = _responsive(media, $size, (sizeIndex)=>fontSize(sizes[sizeIndex] || defaultSize));
    return [
        base,
        ...resp
    ];
}
function fontSize(size2) {
    const { ascenderHeight, descenderHeight, fontSize: fontSize2, iconSize, letterSpacing, lineHeight } = size2, negHeight = ascenderHeight + descenderHeight, capHeight = lineHeight - negHeight, iconOffset = (capHeight - iconSize) / 2, customIconSize = Math.floor(fontSize2 * 1.125 / 2) * 2 + 1, customIconOffset = (capHeight - customIconSize) / 2;
    return {
        fontSize: rem(fontSize2),
        lineHeight: `calc(${lineHeight} / ${fontSize2})`,
        letterSpacing: rem(letterSpacing),
        transform: `translateY(${rem(descenderHeight)})`,
        "&:before": {
            marginTop: `calc(${rem(0 - negHeight)} - 1px)`
        },
        "&:after": {
            marginBottom: "-1px"
        },
        "& svg:not([data-sanity-icon])": {
            fontSize: `calc(${customIconSize} / 16 * 1rem)`,
            margin: rem(customIconOffset)
        },
        "& [data-sanity-icon]": {
            fontSize: `calc(${iconSize} / 16 * 1rem)`,
            margin: rem(iconOffset)
        }
    };
}
function responsiveCodeFontStyle(props) {
    return responsiveFont("code", props);
}
function responsiveHeadingFont(props) {
    return responsiveFont("heading", props);
}
function responsiveLabelFont(props) {
    return responsiveFont("label", props);
}
function responsiveTextAlignStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$align, (textAlign)=>({
            textAlign
        }));
}
function responsiveTextFont(props) {
    return responsiveFont("text", props);
}
function getGlobalScope() {
    if (typeof globalThis < "u") return globalThis;
    if (typeof window < "u") return window;
    if (typeof self < "u") return self;
    if (("TURBOPACK compile-time value", "object") < "u") return /*TURBOPACK member replacement*/ __turbopack_context__.g;
    throw new Error("@sanity/ui: could not locate global scope");
}
const globalScope = getGlobalScope();
function createGlobalScopedContext(key2, defaultValue) {
    const symbol = Symbol.for(key2);
    if (typeof document > "u") {
        const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(defaultValue);
        return context.displayName = key2, context;
    }
    return globalScope[symbol] = globalScope[symbol] || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(defaultValue), globalScope[symbol];
}
const ThemeContext = createGlobalScopedContext("@sanity/ui/context/theme", null);
function ThemeProvider(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(15), parentTheme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ThemeContext), { children } = props, scheme = props.scheme ?? (parentTheme?.scheme || "light"), rootTheme = props.theme ?? (parentTheme?.theme || null), tone = props.tone ?? (parentTheme?.tone || "default");
    let t0;
    bb0: {
        if (!rootTheme) {
            t0 = null;
            break bb0;
        }
        let t12;
        $[0] !== rootTheme || $[1] !== scheme || $[2] !== tone ? (t12 = {
            version: 0,
            theme: rootTheme,
            scheme,
            tone
        }, $[0] = rootTheme, $[1] = scheme, $[2] = tone, $[3] = t12) : t12 = $[3], t0 = t12;
    }
    const themeContext = t0;
    let t1;
    bb1: {
        if (!rootTheme) {
            t1 = null;
            break bb1;
        }
        let t22;
        $[4] !== rootTheme || $[5] !== scheme || $[6] !== tone ? (t22 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getScopedTheme"])(rootTheme, scheme, tone), $[4] = rootTheme, $[5] = scheme, $[6] = tone, $[7] = t22) : t22 = $[7], t1 = t22;
    }
    const theme = t1;
    if (!theme) {
        let t22;
        return $[8] === Symbol.for("react.memo_cache_sentinel") ? (t22 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("pre", {
            children: 'ThemeProvider: no "theme" property provided'
        }), $[8] = t22) : t22 = $[8], t22;
    }
    let t2;
    $[9] !== children || $[10] !== theme ? (t2 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeProvider"], {
        theme,
        children
    }), $[9] = children, $[10] = theme, $[11] = t2) : t2 = $[11];
    let t3;
    return $[12] !== t2 || $[13] !== themeContext ? (t3 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ThemeContext.Provider, {
        value: themeContext,
        children: t2
    }), $[12] = t2, $[13] = themeContext, $[14] = t3) : t3 = $[14], t3;
}
ThemeProvider.displayName = "ThemeProvider";
function useRootTheme() {
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ThemeContext);
    if (!value) throw new Error("useRootTheme(): missing context value");
    return value;
}
function ThemeColorProvider(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5), { children, scheme, tone } = props, root = useRootTheme(), t0 = scheme || root.scheme;
    let t1;
    return $[0] !== children || $[1] !== root.theme || $[2] !== t0 || $[3] !== tone ? (t1 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ThemeProvider, {
        scheme: t0,
        theme: root.theme,
        tone,
        children
    }), $[0] = children, $[1] = root.theme, $[2] = t0, $[3] = tone, $[4] = t1) : t1 = $[4], t1;
}
ThemeColorProvider.displayName = "ThemeColorProvider";
function useTheme() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
}
function useTheme_v2() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2), t0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    let t1;
    return $[0] !== t0 ? (t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(t0), $[0] = t0, $[1] = t1) : t1 = $[1], t1;
}
function responsiveBorderStyle() {
    return [
        border,
        borderTop,
        borderRight,
        borderBottom,
        borderLeft
    ];
}
function border(props) {
    const { card, media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), borderStyle = `${card.border?.width ?? 1}px solid var(--card-border-color)`;
    return _responsive(media, props.$border, (value)=>value ? {
            "&&": {
                border: borderStyle
            }
        } : {
            "&&": {
                border: 0
            }
        });
}
function borderTop(props) {
    const { card, media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), borderStyle = `${card.border?.width ?? 1}px solid var(--card-border-color)`;
    return _responsive(media, props.$borderTop, (value)=>value ? {
            "&&": {
                borderTop: borderStyle
            }
        } : {
            "&&": {
                borderTop: 0
            }
        });
}
function borderRight(props) {
    const { card, media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), borderStyle = `${card.border?.width ?? 1}px solid var(--card-border-color)`;
    return _responsive(media, props.$borderRight, (value)=>value ? {
            "&&": {
                borderRight: borderStyle
            }
        } : {
            "&&": {
                borderRight: 0
            }
        });
}
function borderBottom(props) {
    const { card, media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), borderStyle = `${card.border?.width ?? 1}px solid var(--card-border-color)`;
    return _responsive(media, props.$borderBottom, (value)=>value ? {
            "&&": {
                borderBottom: borderStyle
            }
        } : {
            "&&": {
                borderBottom: 0
            }
        });
}
function borderLeft(props) {
    const { card, media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), borderStyle = `${card.border?.width ?? 1}px solid var(--card-border-color)`;
    return _responsive(media, props.$borderLeft, (value)=>value ? {
            "&&": {
                borderLeft: borderStyle
            }
        } : {
            "&&": {
                borderLeft: 0
            }
        });
}
const BASE_STYLE$4 = {
    '&[data-as="ul"],&[data-as="ol"]': {
        listStyle: "none"
    }
}, BOX_SIZING = {
    content: "content-box",
    border: "border-box"
}, BOX_HEIGHT = {
    stretch: "stretch",
    fill: "100%"
};
function boxStyle() {
    return BASE_STYLE$4;
}
function responsiveBoxStyle() {
    return [
        responsiveBoxSizingStyle,
        responsiveBoxHeightStyle,
        responsiveBoxOverflowStyle,
        responsiveBoxDisplayStyle
    ];
}
function responsiveBoxDisplayStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$display, (display)=>({
            "&:not([hidden])": {
                display
            }
        }));
}
function responsiveBoxSizingStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$sizing, (sizing)=>({
            boxSizing: BOX_SIZING[sizing]
        }));
}
function responsiveBoxHeightStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$height, (height)=>({
            height: BOX_HEIGHT[height]
        }));
}
function responsiveBoxOverflowStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$overflow, (overflow)=>({
            overflow
        }));
}
const BASE_STYLE$3 = {
    minWidth: 0,
    minHeight: 0
};
function flexItemStyle() {
    return [
        BASE_STYLE$3,
        responsiveFlexItemStyle
    ];
}
function responsiveFlexItemStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return props.$flex ? _responsive(media, props.$flex, (flex)=>({
            flex: `${flex}`
        })) : EMPTY_ARRAY;
}
const BASE_STYLE$2 = {
    "&&:not([hidden])": {
        display: "flex"
    }
};
function responsiveFlexStyle() {
    return [
        BASE_STYLE$2,
        responsiveFlexAlignStyle,
        responsiveFlexGapStyle,
        responsiveFlexWrapStyle,
        responsiveFlexJustifyStyle,
        responsiveFlexDirectionStyle
    ];
}
function responsiveFlexAlignStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$align, (align)=>({
            alignItems: align
        }));
}
function responsiveFlexGapStyle(props) {
    const { media, space } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$gap, (gap)=>({
            gap: gap ? rem(space[gap]) : void 0
        }));
}
function responsiveFlexWrapStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$wrap, (wrap)=>({
            flexWrap: wrap
        }));
}
function responsiveFlexJustifyStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$justify, (justify)=>({
            justifyContent: justify
        }));
}
function responsiveFlexDirectionStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$direction, (direction)=>({
            flexDirection: direction
        }));
}
function focusRingBorderStyle(border2) {
    return `inset 0 0 0 ${border2.width}px ${border2.color}`;
}
function focusRingStyle(opts) {
    const { base, border: border2, focusRing } = opts, focusRingOutsetWidth = focusRing.offset + focusRing.width, focusRingInsetWidth = 0 - focusRing.offset, bgColor = base ? base.bg : "var(--card-bg-color)";
    return [
        focusRingInsetWidth > 0 && `inset 0 0 0 ${focusRingInsetWidth}px var(--card-focus-ring-color)`,
        border2 && focusRingBorderStyle(border2),
        focusRingInsetWidth < 0 && `0 0 0 ${0 - focusRingInsetWidth}px ${bgColor}`,
        focusRingOutsetWidth > 0 && `0 0 0 ${focusRingOutsetWidth}px var(--card-focus-ring-color)`
    ].filter(Boolean).join(",");
}
function responsiveGridItemStyle() {
    return [
        responsiveGridItemRowStyle,
        responsiveGridItemRowStartStyle,
        responsiveGridItemRowEndStyle,
        responsiveGridItemColumnStyle,
        responsiveGridItemColumnStartStyle,
        responsiveGridItemColumnEndStyle
    ];
}
const GRID_ITEM_ROW = {
    auto: "auto",
    full: "1 / -1"
}, GRID_ITEM_COLUMN = {
    auto: "auto",
    full: "1 / -1"
};
function responsiveGridItemRowStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$row, (row)=>typeof row == "number" ? {
            gridRow: `span ${row} / span ${row}`
        } : {
            gridRow: GRID_ITEM_ROW[row]
        });
}
function responsiveGridItemRowStartStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$rowStart, (rowStart)=>({
            gridRowStart: `${rowStart}`
        }));
}
function responsiveGridItemRowEndStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$rowEnd, (rowEnd)=>({
            gridRowEnd: `${rowEnd}`
        }));
}
function responsiveGridItemColumnStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$column, (column)=>typeof column == "number" ? {
            gridColumn: `span ${column} / span ${column}`
        } : {
            gridColumn: GRID_ITEM_COLUMN[column]
        });
}
function responsiveGridItemColumnStartStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$columnStart, (columnStart)=>({
            gridColumnStart: `${columnStart}`
        }));
}
function responsiveGridItemColumnEndStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$columnEnd, (columnEnd)=>({
            gridColumnEnd: `${columnEnd}`
        }));
}
const GRID_CSS = {
    "&&:not([hidden])": {
        display: "grid"
    },
    '&[data-as="ul"],&[data-as="ol"]': {
        listStyle: "none"
    }
}, GRID_AUTO_COLUMS = {
    auto: "auto",
    min: "min-content",
    max: "max-content",
    fr: "minmax(0, 1fr)"
}, GRID_AUTO_ROWS = {
    auto: "auto",
    min: "min-content",
    max: "max-content",
    fr: "minmax(0, 1fr)"
};
function responsiveGridStyle() {
    return [
        GRID_CSS,
        responsiveGridAutoFlowStyle,
        responsiveGridAutoRowsStyle,
        responsiveGridAutoColsStyle,
        responsiveGridColumnsStyle,
        responsiveGridRowsStyle,
        responsiveGridGapStyle,
        responsiveGridGapXStyle,
        responsiveGridGapYStyle
    ];
}
function responsiveGridAutoFlowStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$autoFlow, (autoFlow)=>({
            gridAutoFlow: autoFlow
        }));
}
function responsiveGridAutoRowsStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$autoRows, (autoRows)=>({
            gridAutoRows: autoRows && GRID_AUTO_ROWS[autoRows]
        }));
}
function responsiveGridAutoColsStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$autoCols, (autoCols)=>({
            gridAutoColumns: autoCols && GRID_AUTO_COLUMS[autoCols]
        }));
}
function responsiveGridColumnsStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$columns, (columns)=>({
            gridTemplateColumns: columns && `repeat(${columns},minmax(0,1fr));`
        }));
}
function responsiveGridRowsStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$rows, (rows)=>({
            gridTemplateRows: rows && `repeat(${rows},minmax(0,1fr));`
        }));
}
function responsiveGridGapStyle(props) {
    const { media, space } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$gap, (gap)=>({
            gridGap: gap ? rem(space[gap]) : void 0
        }));
}
function responsiveGridGapXStyle(props) {
    const { media, space } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$gapX, (gapX)=>({
            columnGap: gapX ? rem(space[gapX]) : void 0
        }));
}
function responsiveGridGapYStyle(props) {
    const { media, space } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$gapY, (gapY)=>({
            rowGap: gapY ? rem(space[gapY]) : void 0
        }));
}
function responsiveInputPaddingStyle(props) {
    const { $fontSize, $iconLeft, $iconRight, $padding, $space } = props, { font, media, space } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), len = Math.max($padding.length, $space.length, $fontSize.length), _padding = [], _space = [], _fontSize = [];
    for(let i = 0; i < len; i += 1)_fontSize[i] = $fontSize[i] === void 0 ? _fontSize[i - 1] : $fontSize[i], _padding[i] = $padding[i] === void 0 ? _padding[i - 1] : $padding[i], _space[i] = $space[i] === void 0 ? _space[i - 1] : $space[i];
    return _responsive(media, _padding, (_, i)=>{
        const size2 = font.text.sizes[_fontSize[i]] || font.text.sizes[2], emSize = size2.lineHeight - size2.ascenderHeight - size2.descenderHeight, p = space[_padding[i]], s = space[_space[i]], styles = {
            paddingTop: rem(p - size2.ascenderHeight),
            paddingRight: rem(p),
            paddingBottom: rem(p - size2.descenderHeight),
            paddingLeft: rem(p)
        };
        return $iconRight && (styles.paddingRight = rem(p + emSize + s)), $iconLeft && (styles.paddingLeft = rem(p + emSize + s)), styles;
    });
}
function responsiveInputPaddingIconRightStyle(props) {
    return responsiveInputPaddingStyle({
        ...props,
        $iconRight: !0
    });
}
const ROOT_STYLE = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
  &:not([hidden]) {
    display: flex;
  }

  align-items: center;
`;
function textInputRootStyle() {
    return ROOT_STYLE;
}
function textInputBaseStyle(props) {
    const { $scheme, $tone, $weight } = props, { color, font } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    appearance: none;
    background: none;
    border: 0;
    border-radius: 0;
    outline: none;
    width: 100%;
    box-sizing: border-box;
    font-family: ${font.text.family};
    font-weight: ${$weight && font.text.weights[$weight] || font.text.weights.regular};
    margin: 0;
    position: relative;
    z-index: 1;
    display: block;

    /* NOTE: This is a hack to disable Chrome’s autofill styles */
    &:-webkit-autofill,
    &:-webkit-autofill:hover,
    &:-webkit-autofill:focus,
    &:-webkit-autofill:active {
      -webkit-text-fill-color: var(--input-fg-color) !important;
      transition: background-color 5000s;
      transition-delay: 86400s /* 24h */;
    }

    /* &:is(textarea) */
    &[data-as='textarea'] {
      resize: none;
    }

    color: var(--input-fg-color);

    &::placeholder {
      color: var(--input-placeholder-color);
    }

    &[data-scheme='${$scheme}'][data-tone='${$tone}'] {
      --input-fg-color: ${color.input.default.enabled.fg};
      --input-placeholder-color: ${color.input.default.enabled.placeholder};

      /* enabled */
      &:not(:invalid):not(:disabled):not(:read-only) {
        --input-fg-color: ${color.input.default.enabled.fg};
        --input-placeholder-color: ${color.input.default.enabled.placeholder};
      }

      /* disabled */
      &:not(:invalid):disabled {
        --input-fg-color: ${color.input.default.disabled.fg};
        --input-placeholder-color: ${color.input.default.disabled.placeholder};
      }

      /* invalid */
      &:invalid {
        --input-fg-color: ${color.input.invalid.enabled.fg};
        --input-placeholder-color: ${color.input.invalid.enabled.placeholder};
      }

      /* readOnly */
      &:read-only {
        --input-fg-color: ${color.input.default.readOnly.fg};
        --input-placeholder-color: ${color.input.default.readOnly.placeholder};
      }
    }
  `;
}
function textInputFontSizeStyle(props) {
    const { font, media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$fontSize, (sizeIndex)=>{
        const size2 = font.text.sizes[sizeIndex] || font.text.sizes[2];
        return {
            fontSize: rem(size2.fontSize),
            lineHeight: `${size2.lineHeight / size2.fontSize}`
        };
    });
}
function textInputRepresentationStyle(props) {
    const { $hasPrefix, $hasSuffix, $scheme, $tone, $unstableDisableFocusRing } = props, { color, input } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    --input-box-shadow: none;

    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: block;
    pointer-events: none;
    z-index: 0;

    background-color: var(--card-bg-color);
    box-shadow: var(--input-box-shadow);

    border-top-left-radius: ${$hasPrefix ? 0 : void 0};
    border-bottom-left-radius: ${$hasPrefix ? 0 : void 0};
    border-top-right-radius: ${$hasSuffix ? 0 : void 0};
    border-bottom-right-radius: ${$hasSuffix ? 0 : void 0};

    &[data-scheme='${$scheme}'][data-tone='${$tone}'] {
      --card-bg-color: ${color.input.default.enabled.bg};
      --card-fg-color: ${color.input.default.enabled.fg};

      /* enabled */
      *:not(:disabled) + &[data-border] {
        --input-box-shadow: ${focusRingBorderStyle({
        color: color.input.default.enabled.border,
        width: input.border.width
    })};
      }

      /* invalid */
      *:not(:disabled):invalid + & {
        --card-bg-color: ${color.input.invalid.enabled.bg};
        --card-fg-color: ${color.input.invalid.enabled.fg};

        &[data-border] {
          --input-box-shadow: ${focusRingBorderStyle({
        color: color.input.invalid.enabled.border,
        width: input.border.width
    })};
        }
      }

      /* focused */
      *:not(:disabled):focus + & {
        &[data-border] {
          --input-box-shadow: ${$unstableDisableFocusRing ? void 0 : focusRingStyle({
        border: {
            color: color.input.default.enabled.border,
            width: input.border.width
        },
        focusRing: input.text.focusRing
    })};
        }

        &:not([data-border]) {
          --input-box-shadow: ${$unstableDisableFocusRing ? void 0 : focusRingStyle({
        focusRing: input.text.focusRing
    })};
        }
      }

      /* disabled */
      *:not(:invalid):disabled + & {
        --card-bg-color: ${color.input.default.disabled.bg} !important;
        --card-fg-color: ${color.input.default.disabled.fg} !important;
        --card-icon-color: ${color.input.default.disabled.fg} !important;

        &[data-border] {
          --input-box-shadow: ${focusRingBorderStyle({
        color: color.input.default.disabled.border,
        width: input.border.width
    })};
        }
      }

      *:invalid:disabled + & {
        --card-bg-color: ${color.input.invalid.disabled.bg} !important;
        --card-fg-color: ${color.input.invalid.disabled.fg} !important;
        --card-icon-color: ${color.input.invalid.disabled.fg} !important;

        &[data-border] {
          --input-box-shadow: ${focusRingBorderStyle({
        color: color.input.invalid.disabled.border,
        width: input.border.width
    })};
        }
      }

      /* readOnly */
      *:not(:invalid):read-only + & {
        --card-bg-color: ${color.input.default.readOnly.bg} !important;
        --card-fg-color: ${color.input.default.readOnly.fg} !important;
      }

      *:invalid:read-only + & {
        --card-bg-color: ${color.input.invalid.readOnly.bg} !important;
        --card-fg-color: ${color.input.invalid.readOnly.fg} !important;
      }

      /* hovered */
      @media (hover: hover) {
        *:not(:disabled):not(:read-only):not(:invalid):hover + & {
          --card-bg-color: ${color.input.default.hovered.bg};
          --card-fg-color: ${color.input.default.hovered.fg};
        }

        *:invalid:not(:disabled):not(:read-only):hover + & {
          --card-bg-color: ${color.input.invalid.hovered.bg};
          --card-fg-color: ${color.input.invalid.hovered.fg};
        }

        *:not(:disabled):not(:read-only):not(:invalid):not(:focus):hover + &[data-border] {
          --input-box-shadow: ${focusRingBorderStyle({
        color: color.input.default.hovered.border,
        width: input.border.width
    })};
        }

        *:invalid:not(:disabled):not(:read-only):not(:focus):hover + &[data-border] {
          --input-box-shadow: ${focusRingBorderStyle({
        color: color.input.invalid.hovered.border,
        width: input.border.width
    })};
        }
      }
    }
  `;
}
function responsiveMarginStyle(props) {
    const { theme } = props;
    return [
        _getResponsiveSpace(theme, [
            "margin"
        ], props.$margin),
        _getResponsiveSpace(theme, [
            "marginLeft",
            "marginRight"
        ], props.$marginX),
        _getResponsiveSpace(theme, [
            "marginTop",
            "marginBottom"
        ], props.$marginY),
        _getResponsiveSpace(theme, [
            "marginTop"
        ], props.$marginTop),
        _getResponsiveSpace(theme, [
            "marginRight"
        ], props.$marginRight),
        _getResponsiveSpace(theme, [
            "marginBottom"
        ], props.$marginBottom),
        _getResponsiveSpace(theme, [
            "marginLeft"
        ], props.$marginLeft)
    ].filter(Boolean);
}
function responsivePaddingStyle(props) {
    const { theme } = props;
    return [
        _getResponsiveSpace(theme, [
            "padding"
        ], props.$padding),
        _getResponsiveSpace(theme, [
            "paddingLeft",
            "paddingRight"
        ], props.$paddingX),
        _getResponsiveSpace(theme, [
            "paddingTop",
            "paddingBottom"
        ], props.$paddingY),
        _getResponsiveSpace(theme, [
            "paddingTop"
        ], props.$paddingTop),
        _getResponsiveSpace(theme, [
            "paddingRight"
        ], props.$paddingRight),
        _getResponsiveSpace(theme, [
            "paddingBottom"
        ], props.$paddingBottom),
        _getResponsiveSpace(theme, [
            "paddingLeft"
        ], props.$paddingLeft)
    ].filter(Boolean);
}
function responsiveRadiusStyle(props) {
    const { media, radius } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$radius, (value)=>{
        let borderRadius = 0;
        return typeof value == "number" && (borderRadius = rem(radius[value])), value === "full" && (borderRadius = "9999px"), {
            borderRadius
        };
    });
}
function toBoxShadow(shadow, color) {
    return `${shadow.map(rem).join(" ")} ${color}`;
}
function shadowStyle(shadow, outlineWidth = 1) {
    if (!shadow) return EMPTY_RECORD;
    const outline = `0 0 0 ${rem(outlineWidth)} var(--card-shadow-outline-color)`, umbra = toBoxShadow(shadow.umbra, "var(--card-shadow-umbra-color)"), penumbra = toBoxShadow(shadow.penumbra, "var(--card-shadow-penumbra-color)"), ambient = toBoxShadow(shadow.ambient, "var(--card-shadow-ambient-color)");
    return {
        boxShadow: `${outline}, ${umbra}, ${penumbra}, ${ambient}`
    };
}
function responsiveShadowStyle(props) {
    const { card, media, shadow } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$shadow, (index)=>shadowStyle(shadow[index], card.shadow.outline));
}
const SpanWithTextOverflow = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].span.withConfig({
    displayName: "SpanWithTextOverflow",
    componentId: "sc-ol2i3b-0"
})`display:block;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;overflow:clip;`;
function labelBaseStyle(props) {
    const { $accent, $muted } = props, { font } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    text-transform: uppercase;

    ${$accent && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
      color: var(--card-accent-fg-color);
    `}

    ${$muted && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
      color: var(--card-muted-fg-color);
    `}

    & code {
      font-family: ${font.code.family};
      border-radius: 1px;
    }

    & a {
      text-decoration: none;
      border-radius: 1px;
    }

    & svg {
      /* Certain popular CSS libraries changes the defaults for SVG display */
      /* Make sure SVGs are rendered as inline elements */
      display: inline;
    }

    & [data-sanity-icon] {
      vertical-align: baseline;
    }
  `;
}
const StyledLabel = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledLabel",
    componentId: "sc-1luap7z-0"
})(responsiveLabelFont, responsiveTextAlignStyle, labelBaseStyle), Label = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(26);
    let accent, align, childrenProp, restProps, t0, t1, textOverflow, weight;
    $[0] !== props ? ({ accent, align, children: childrenProp, muted: t0, size: t1, textOverflow, weight, ...restProps } = props, $[0] = props, $[1] = accent, $[2] = align, $[3] = childrenProp, $[4] = restProps, $[5] = t0, $[6] = t1, $[7] = textOverflow, $[8] = weight) : (accent = $[1], align = $[2], childrenProp = $[3], restProps = $[4], t0 = $[5], t1 = $[6], textOverflow = $[7], weight = $[8]);
    const muted = t0 === void 0 ? !1 : t0, size2 = t1 === void 0 ? 2 : t1;
    let children = childrenProp;
    if (textOverflow === "ellipsis") {
        let t22;
        $[9] !== children ? (t22 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(SpanWithTextOverflow, {
            children
        }), $[9] = children, $[10] = t22) : t22 = $[10], children = t22;
    } else {
        let t22;
        $[11] !== children ? (t22 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
            children
        }), $[11] = children, $[12] = t22) : t22 = $[12], children = t22;
    }
    let t2;
    $[13] !== align ? (t2 = _getArrayProp(align), $[13] = align, $[14] = t2) : t2 = $[14];
    let t3;
    $[15] !== size2 ? (t3 = _getArrayProp(size2), $[15] = size2, $[16] = t3) : t3 = $[16];
    let t4;
    return $[17] !== accent || $[18] !== children || $[19] !== muted || $[20] !== ref || $[21] !== restProps || $[22] !== t2 || $[23] !== t3 || $[24] !== weight ? (t4 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledLabel, {
        "data-ui": "Label",
        ...restProps,
        $accent: accent,
        $align: t2,
        $muted: muted,
        $size: t3,
        $weight: weight,
        ref,
        children
    }), $[17] = accent, $[18] = children, $[19] = muted, $[20] = ref, $[21] = restProps, $[22] = t2, $[23] = t3, $[24] = weight, $[25] = t4) : t4 = $[25], t4;
});
Label.displayName = "ForwardRef(Label)";
const avatarStyle = {
    root: avatarRootStyle,
    arrow: avatarArrowStyle,
    bgStroke: avatarBgStrokeStyle,
    stroke: avatarStrokeStyle,
    initials: avatarInitialsStyle,
    image: avatarImageStyle
};
function avatarArrowStyle() {
    return {
        position: "absolute",
        boxSizing: "border-box",
        zIndex: "0",
        opacity: "0",
        transition: "all 0.2s linear",
        transform: "rotate(-90deg) translate3d(0, 6px, 0)",
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        "& > svg": {
            width: "11px",
            height: "7px",
            position: "absolute",
            top: "-5px",
            left: "50%",
            transform: "translateX(-6px)",
            "&:not([hidden])": {
                display: "block"
            }
        },
        "[data-arrow-position='inside'] > &": {
            transform: "rotate(-90deg) translate3d(0, 6px, 0)",
            opacity: "0"
        },
        "[data-arrow-position='top'] > &": {
            opacity: "1",
            transform: "rotate(0deg)"
        },
        "[data-arrow-position='bottom'] > &": {
            opacity: "1",
            transform: "rotate(-180deg)"
        }
    };
}
function avatarRootStyle(props) {
    const { $color } = props, { avatar } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return {
        "--avatar-bg-color": `var(--card-avatar-${$color}-bg-color)`,
        "--avatar-fg-color": `var(--card-avatar-${$color}-fg-color)`,
        backgroundColor: "var(--avatar-bg-color)",
        position: "relative",
        boxSizing: "border-box",
        userSelect: "none",
        boxShadow: "0 0 0 1px var(--card-bg-color)",
        '&[data-status="inactive"]': {
            opacity: "0.5"
        },
        "&>svg": {
            "&:not([hidden])": {
                display: "block"
            }
        },
        /* &:is(button) */ '&[data-as="button"]': {
            WebkitFontSmoothing: "inherit",
            appearance: "none",
            margin: 0,
            padding: 0,
            border: 0,
            font: "inherit",
            color: "inherit",
            outline: "none",
            "&:focus": {
                boxShadow: focusRingStyle({
                    focusRing: avatar.focusRing
                })
            },
            "&:focus:not(:focus-visible)": {
                boxShadow: "none"
            }
        }
    };
}
function responsiveAvatarSizeStyle(props) {
    const { avatar, media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$size, (size2)=>{
        const avatarSize = avatar.sizes[size2] || avatar.sizes[0];
        return {
            width: rem(avatarSize.size),
            height: rem(avatarSize.size),
            borderRadius: rem(avatarSize.size / 2),
            "&>svg": {
                width: rem(avatarSize.size),
                height: rem(avatarSize.size),
                borderRadius: rem(avatarSize.size / 2)
            }
        };
    });
}
function avatarImageStyle() {
    return {
        position: "relative"
    };
}
function avatarInitialsStyle() {
    return {
        width: "100%",
        height: "100%",
        color: "var(--avatar-fg-color)",
        alignItems: "center",
        justifyContent: "center",
        textTransform: "uppercase",
        textAlign: "center",
        borderRadius: "50%",
        "&:not([hidden])": {
            display: "flex"
        }
    };
}
function avatarBgStrokeStyle() {
    return {
        strokeWidth: "4px",
        stroke: "var(--card-bg-color)"
    };
}
function avatarStrokeStyle() {
    return {
        strokeWidth: "2px",
        stroke: "var(--avatar-bg-color)",
        '[data-status="editing"] &': {
            strokeDasharray: "2 4",
            strokeLinecap: "round"
        }
    };
}
const StyledAvatar = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledAvatar",
    componentId: "sc-1rj7kl0-0"
})(responsiveAvatarSizeStyle, avatarStyle.root), Arrow$1 = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "Arrow",
    componentId: "sc-1rj7kl0-1"
})(avatarStyle.arrow), BgStroke = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].ellipse.withConfig({
    displayName: "BgStroke",
    componentId: "sc-1rj7kl0-2"
})(avatarStyle.bgStroke), Stroke = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].ellipse.withConfig({
    displayName: "Stroke",
    componentId: "sc-1rj7kl0-3"
})(avatarStyle.stroke), Initials = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "Initials",
    componentId: "sc-1rj7kl0-4"
})(avatarStyle.initials), InitialsLabel = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Label).withConfig({
    displayName: "InitialsLabel",
    componentId: "sc-1rj7kl0-5"
})({
    color: "inherit"
}), AvatarImage = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].svg.withConfig({
    displayName: "AvatarImage",
    componentId: "sc-1rj7kl0-6"
})(avatarStyle.image), Avatar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(46);
    let __unstable_hideInnerStroke, animateArrowFrom, arrowPositionProp, asProp, initials, onImageLoadError, restProps, src, t0, t1, t2, title;
    $[0] !== props ? ({ __unstable_hideInnerStroke, as: asProp, color: t0, src, title, initials, onImageLoadError, arrowPosition: arrowPositionProp, animateArrowFrom, status: t1, size: t2, ...restProps } = props, $[0] = props, $[1] = __unstable_hideInnerStroke, $[2] = animateArrowFrom, $[3] = arrowPositionProp, $[4] = asProp, $[5] = initials, $[6] = onImageLoadError, $[7] = restProps, $[8] = src, $[9] = t0, $[10] = t1, $[11] = t2, $[12] = title) : (__unstable_hideInnerStroke = $[1], animateArrowFrom = $[2], arrowPositionProp = $[3], asProp = $[4], initials = $[5], onImageLoadError = $[6], restProps = $[7], src = $[8], t0 = $[9], t1 = $[10], t2 = $[11], title = $[12]);
    const color = t0 === void 0 ? "gray" : t0, status = t1 === void 0 ? "online" : t1, sizeProp = t2 === void 0 ? 1 : t2, { avatar } = useTheme_v2(), as = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].isValidElementType(asProp) ? asProp : "div", size2 = _getArrayProp(sizeProp), _sizeRem = (avatar.sizes[size2[0]] || avatar.sizes[0]).size, _radius = _sizeRem / 2, elementId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(), [arrowPosition, setArrowPosition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(animateArrowFrom || arrowPositionProp || "inside"), [imageFailed, setImageFailed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), imageId = `avatar-image-${elementId}`;
    let t3, t4;
    $[13] !== arrowPosition || $[14] !== arrowPositionProp ? (t3 = ()=>{
        if (arrowPosition === arrowPositionProp) return;
        const raf = requestAnimationFrame(()=>setArrowPosition(arrowPositionProp));
        return ()=>cancelAnimationFrame(raf);
    }, t4 = [
        arrowPosition,
        arrowPositionProp
    ], $[13] = arrowPosition, $[14] = arrowPositionProp, $[15] = t3, $[16] = t4) : (t3 = $[15], t4 = $[16]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    let t5, t6;
    $[17] !== src ? (t5 = ()=>{
        src && setImageFailed(!1);
    }, t6 = [
        src
    ], $[17] = src, $[18] = t5, $[19] = t6) : (t5 = $[18], t6 = $[19]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    let t7;
    $[20] !== onImageLoadError ? (t7 = ()=>{
        setImageFailed(!0), onImageLoadError && onImageLoadError(new Error("Avatar: the image failed to load"));
    }, $[20] = onImageLoadError, $[21] = t7) : t7 = $[21];
    const handleImageError = t7, T0 = StyledAvatar, t8 = typeof as == "string" ? as : void 0, t9 = "Avatar";
    let t10;
    $[22] !== color ? (t10 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Arrow$1, {
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
            width: "11",
            height: "7",
            viewBox: "0 0 11 7",
            fill: "none",
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M6.67948 1.50115L11 7L0 7L4.32052 1.50115C4.92109 0.736796 6.07891 0.736795 6.67948 1.50115Z",
                fill: color
            })
        })
    }), $[22] = color, $[23] = t10) : t10 = $[23];
    let t11;
    $[24] !== __unstable_hideInnerStroke || $[25] !== _radius || $[26] !== _sizeRem || $[27] !== handleImageError || $[28] !== imageFailed || $[29] !== imageId || $[30] !== src ? (t11 = !imageFailed && src && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(AvatarImage, {
        viewBox: `0 0 ${_sizeRem} ${_sizeRem}`,
        fill: "none",
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("defs", {
                children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("pattern", {
                    id: imageId,
                    patternContentUnits: "objectBoundingBox",
                    width: "1",
                    height: "1",
                    children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("image", {
                        href: src,
                        width: "1",
                        height: "1",
                        onError: handleImageError
                    })
                })
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", {
                cx: _radius,
                cy: _radius,
                r: _radius,
                fill: `url(#${imageId})`
            }),
            !__unstable_hideInnerStroke && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(BgStroke, {
                cx: _radius,
                cy: _radius,
                rx: _radius,
                ry: _radius,
                vectorEffect: "non-scaling-stroke"
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Stroke, {
                cx: _radius,
                cy: _radius,
                rx: _radius,
                ry: _radius,
                vectorEffect: "non-scaling-stroke"
            })
        ]
    }), $[24] = __unstable_hideInnerStroke, $[25] = _radius, $[26] = _sizeRem, $[27] = handleImageError, $[28] = imageFailed, $[29] = imageId, $[30] = src, $[31] = t11) : t11 = $[31];
    const t12 = (imageFailed || !src) && initials && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Initials, {
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(InitialsLabel, {
                forwardedAs: "span",
                size: size2.map(_temp$a),
                weight: "medium",
                children: initials
            })
        })
    });
    let t13;
    return $[32] !== T0 || $[33] !== arrowPosition || $[34] !== as || $[35] !== color || $[36] !== ref || $[37] !== restProps || $[38] !== size2 || $[39] !== status || $[40] !== t10 || $[41] !== t11 || $[42] !== t12 || $[43] !== t8 || $[44] !== title ? (t13 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(T0, {
        as,
        "data-as": t8,
        "data-ui": t9,
        ...restProps,
        $color: color,
        $size: size2,
        "aria-label": title,
        "data-arrow-position": arrowPosition,
        "data-status": status,
        ref,
        title,
        children: [
            t10,
            t11,
            t12
        ]
    }), $[32] = T0, $[33] = arrowPosition, $[34] = as, $[35] = color, $[36] = ref, $[37] = restProps, $[38] = size2, $[39] = status, $[40] = t10, $[41] = t11, $[42] = t12, $[43] = t8, $[44] = title, $[45] = t13) : t13 = $[45], t13;
});
Avatar.displayName = "ForwardRef(Avatar)";
function _temp$a(s) {
    return s === 1 ? 1 : s === 2 ? 3 : s === 3 ? 5 : 0;
}
function _responsiveAvatarCounterSizeStyle(props) {
    const { avatar, media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$size, (size2)=>{
        const avatarSize = avatar.sizes[size2];
        return avatarSize ? {
            borderRadius: rem(avatarSize.size / 2),
            minWidth: rem(avatarSize.size),
            height: rem(avatarSize.size)
        } : EMPTY_RECORD;
    });
}
function _avatarCounterBaseStyle(props) {
    const { space } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    align-items: center;
    justify-content: center;
    box-sizing: border-box;
    user-select: none;
    color: inherit;
    color: var(--card-fg-color);
    background: var(--card-bg-color);
    box-shadow:
      0 0 0 1px var(--card-bg-color),
      inset 0 0 0 1px var(--card-hairline-hard-color);
    padding: 0 ${rem(space[2])};

    &:not([hidden]) {
      display: flex;
    }
  `;
}
const StyledAvatarCounter = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledAvatarCounter",
    componentId: "sc-1ydx86y-0"
})(_responsiveAvatarCounterSizeStyle, _avatarCounterBaseStyle), AvatarCounter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(20), { count, size: t0 } = props, sizeProp = t0 === void 0 ? 1 : t0;
    let T0, T1, t1, t2, t3, t4, t5;
    if ($[0] !== ref || $[1] !== sizeProp) {
        const size2 = _getArrayProp(sizeProp);
        T1 = StyledAvatarCounter, t3 = size2, t4 = "AvatarCounter", t5 = ref, T0 = Label, t1 = "span", t2 = size2.map(_temp$9), $[0] = ref, $[1] = sizeProp, $[2] = T0, $[3] = T1, $[4] = t1, $[5] = t2, $[6] = t3, $[7] = t4, $[8] = t5;
    } else T0 = $[2], T1 = $[3], t1 = $[4], t2 = $[5], t3 = $[6], t4 = $[7], t5 = $[8];
    let t6;
    $[9] !== T0 || $[10] !== count || $[11] !== t1 || $[12] !== t2 ? (t6 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(T0, {
        as: t1,
        size: t2,
        weight: "medium",
        children: count
    }), $[9] = T0, $[10] = count, $[11] = t1, $[12] = t2, $[13] = t6) : t6 = $[13];
    let t7;
    return $[14] !== T1 || $[15] !== t3 || $[16] !== t4 || $[17] !== t5 || $[18] !== t6 ? (t7 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(T1, {
        $size: t3,
        "data-ui": t4,
        ref: t5,
        children: t6
    }), $[14] = T1, $[15] = t3, $[16] = t4, $[17] = t5, $[18] = t6, $[19] = t7) : t7 = $[19], t7;
});
AvatarCounter.displayName = "ForwardRef(AvatarCounter)";
function _temp$9(s) {
    return s === 1 ? 1 : s === 2 ? 3 : s === 3 ? 5 : 0;
}
const BASE_STYLES = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
  white-space: nowrap;

  & > div {
    vertical-align: top;

    &:not([hidden]) {
      display: inline-block;
    }
  }
`;
function avatarStackStyle() {
    return BASE_STYLES;
}
function responsiveAvatarStackSizeStyle(props) {
    const { avatar, media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$size, (size2)=>{
        const avatarSize = avatar.sizes[size2];
        return avatarSize ? {
            "& > div + div": {
                marginLeft: rem(avatarSize.distance)
            }
        } : EMPTY_RECORD;
    });
}
const StyledAvatarStack = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledAvatarStack",
    componentId: "sc-cysmbb-0"
})(responsiveAvatarStackSizeStyle, avatarStackStyle), AvatarStack = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(38);
    let childrenProp, restProps, t0, t1;
    $[0] !== props ? ({ children: childrenProp, maxLength: t0, size: t1, ...restProps } = props, $[0] = props, $[1] = childrenProp, $[2] = restProps, $[3] = t0, $[4] = t1) : (childrenProp = $[1], restProps = $[2], t0 = $[3], t1 = $[4]);
    const maxLengthProp = t0 === void 0 ? 4 : t0, sizeProp = t1 === void 0 ? 1 : t1;
    let T0, t2, t3, t4, t5, t6, t7, t8;
    if ($[5] !== childrenProp || $[6] !== maxLengthProp || $[7] !== ref || $[8] !== restProps || $[9] !== sizeProp) {
        const children = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Children"].toArray(childrenProp).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"]), maxLength = Math.max(maxLengthProp, 0);
        let t92;
        $[18] !== sizeProp ? (t92 = _getArrayProp(sizeProp), $[18] = sizeProp, $[19] = t92) : t92 = $[19];
        const size2 = t92, len = children.length, visibleCount = maxLength - 1, extraCount = len - visibleCount, visibleChildren = extraCount > 1 ? children.slice(extraCount, len) : children;
        T0 = StyledAvatarStack, t2 = "AvatarStack", t3 = restProps, t4 = ref, t5 = size2, $[20] !== len || $[21] !== size2 ? (t6 = len === 0 && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(AvatarCounter, {
                count: len,
                size: size2
            })
        }), $[20] = len, $[21] = size2, $[22] = t6) : t6 = $[22], $[23] !== extraCount || $[24] !== len || $[25] !== size2 ? (t7 = len !== 0 && extraCount > 1 && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(AvatarCounter, {
                count: extraCount,
                size: size2
            })
        }), $[23] = extraCount, $[24] = len, $[25] = size2, $[26] = t7) : t7 = $[26];
        let t10;
        $[27] !== size2 ? (t10 = (child, childIndex)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"])(child, {
                    size: size2
                })
            }, String(childIndex)), $[27] = size2, $[28] = t10) : t10 = $[28], t8 = visibleChildren.map(t10), $[5] = childrenProp, $[6] = maxLengthProp, $[7] = ref, $[8] = restProps, $[9] = sizeProp, $[10] = T0, $[11] = t2, $[12] = t3, $[13] = t4, $[14] = t5, $[15] = t6, $[16] = t7, $[17] = t8;
    } else T0 = $[10], t2 = $[11], t3 = $[12], t4 = $[13], t5 = $[14], t6 = $[15], t7 = $[16], t8 = $[17];
    let t9;
    return $[29] !== T0 || $[30] !== t2 || $[31] !== t3 || $[32] !== t4 || $[33] !== t5 || $[34] !== t6 || $[35] !== t7 || $[36] !== t8 ? (t9 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(T0, {
        "data-ui": t2,
        ...t3,
        ref: t4,
        $size: t5,
        children: [
            t6,
            t7,
            t8
        ]
    }), $[29] = T0, $[30] = t2, $[31] = t3, $[32] = t4, $[33] = t5, $[34] = t6, $[35] = t7, $[36] = t8, $[37] = t9) : t9 = $[37], t9;
});
AvatarStack.displayName = "ForwardRef(AvatarStack)";
const StyledBox = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledBox",
    componentId: "sc-1hhky9f-0"
})(boxStyle, flexItemStyle, responsiveBoxStyle, responsiveGridItemStyle, responsiveMarginStyle, responsivePaddingStyle), Box = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(115);
    let deprecated_column, deprecated_columnEnd, deprecated_columnStart, deprecated_row, deprecated_rowEnd, deprecated_rowStart, flex, gridColumn, gridColumnEnd, gridColumnStart, gridRow, gridRowEnd, gridRowStart, height, marginBottom, marginLeft, marginRight, marginTop, marginX, marginY, overflow, paddingBottom, paddingLeft, paddingRight, paddingTop, paddingX, paddingY, restProps, sizing, t0, t1, t2, t3;
    $[0] !== props ? ({ as: t0, gridColumn, column: deprecated_column, gridColumnStart, columnStart: deprecated_columnStart, gridColumnEnd, columnEnd: deprecated_columnEnd, display: t1, flex, height, margin: t2, marginX, marginY, marginTop, marginRight, marginBottom, marginLeft, overflow, padding: t3, paddingX, paddingY, paddingTop, paddingRight, paddingBottom, paddingLeft, gridRow, row: deprecated_row, gridRowStart, rowStart: deprecated_rowStart, gridRowEnd, rowEnd: deprecated_rowEnd, sizing, ...restProps } = props, $[0] = props, $[1] = deprecated_column, $[2] = deprecated_columnEnd, $[3] = deprecated_columnStart, $[4] = deprecated_row, $[5] = deprecated_rowEnd, $[6] = deprecated_rowStart, $[7] = flex, $[8] = gridColumn, $[9] = gridColumnEnd, $[10] = gridColumnStart, $[11] = gridRow, $[12] = gridRowEnd, $[13] = gridRowStart, $[14] = height, $[15] = marginBottom, $[16] = marginLeft, $[17] = marginRight, $[18] = marginTop, $[19] = marginX, $[20] = marginY, $[21] = overflow, $[22] = paddingBottom, $[23] = paddingLeft, $[24] = paddingRight, $[25] = paddingTop, $[26] = paddingX, $[27] = paddingY, $[28] = restProps, $[29] = sizing, $[30] = t0, $[31] = t1, $[32] = t2, $[33] = t3) : (deprecated_column = $[1], deprecated_columnEnd = $[2], deprecated_columnStart = $[3], deprecated_row = $[4], deprecated_rowEnd = $[5], deprecated_rowStart = $[6], flex = $[7], gridColumn = $[8], gridColumnEnd = $[9], gridColumnStart = $[10], gridRow = $[11], gridRowEnd = $[12], gridRowStart = $[13], height = $[14], marginBottom = $[15], marginLeft = $[16], marginRight = $[17], marginTop = $[18], marginX = $[19], marginY = $[20], overflow = $[21], paddingBottom = $[22], paddingLeft = $[23], paddingRight = $[24], paddingTop = $[25], paddingX = $[26], paddingY = $[27], restProps = $[28], sizing = $[29], t0 = $[30], t1 = $[31], t2 = $[32], t3 = $[33]);
    const asProp = t0 === void 0 ? "div" : t0, display = t1 === void 0 ? "block" : t1, margin = t2 === void 0 ? 0 : t2, padding = t3 === void 0 ? 0 : t3, column = gridColumn === void 0 ? deprecated_column : gridColumn, columnStart = gridColumnStart === void 0 ? deprecated_columnStart : gridColumnStart, columnEnd = gridColumnEnd === void 0 ? deprecated_columnEnd : gridColumnEnd, row = gridRow === void 0 ? deprecated_row : gridRow, rowStart = gridRowStart === void 0 ? deprecated_rowStart : gridRowStart, rowEnd = gridRowEnd === void 0 ? deprecated_rowEnd : gridRowEnd, t4 = typeof asProp == "string" ? asProp : void 0;
    let t5;
    $[34] !== column ? (t5 = _getArrayProp(column), $[34] = column, $[35] = t5) : t5 = $[35];
    let t6;
    $[36] !== columnStart ? (t6 = _getArrayProp(columnStart), $[36] = columnStart, $[37] = t6) : t6 = $[37];
    let t7;
    $[38] !== columnEnd ? (t7 = _getArrayProp(columnEnd), $[38] = columnEnd, $[39] = t7) : t7 = $[39];
    let t8;
    $[40] !== display ? (t8 = _getArrayProp(display), $[40] = display, $[41] = t8) : t8 = $[41];
    let t9;
    $[42] !== flex ? (t9 = _getArrayProp(flex), $[42] = flex, $[43] = t9) : t9 = $[43];
    let t10;
    $[44] !== height ? (t10 = _getArrayProp(height), $[44] = height, $[45] = t10) : t10 = $[45];
    let t11;
    $[46] !== margin ? (t11 = _getArrayProp(margin), $[46] = margin, $[47] = t11) : t11 = $[47];
    let t12;
    $[48] !== marginX ? (t12 = _getArrayProp(marginX), $[48] = marginX, $[49] = t12) : t12 = $[49];
    let t13;
    $[50] !== marginY ? (t13 = _getArrayProp(marginY), $[50] = marginY, $[51] = t13) : t13 = $[51];
    let t14;
    $[52] !== marginTop ? (t14 = _getArrayProp(marginTop), $[52] = marginTop, $[53] = t14) : t14 = $[53];
    let t15;
    $[54] !== marginRight ? (t15 = _getArrayProp(marginRight), $[54] = marginRight, $[55] = t15) : t15 = $[55];
    let t16;
    $[56] !== marginBottom ? (t16 = _getArrayProp(marginBottom), $[56] = marginBottom, $[57] = t16) : t16 = $[57];
    let t17;
    $[58] !== marginLeft ? (t17 = _getArrayProp(marginLeft), $[58] = marginLeft, $[59] = t17) : t17 = $[59];
    let t18;
    $[60] !== overflow ? (t18 = _getArrayProp(overflow), $[60] = overflow, $[61] = t18) : t18 = $[61];
    let t19;
    $[62] !== padding ? (t19 = _getArrayProp(padding), $[62] = padding, $[63] = t19) : t19 = $[63];
    let t20;
    $[64] !== paddingX ? (t20 = _getArrayProp(paddingX), $[64] = paddingX, $[65] = t20) : t20 = $[65];
    let t21;
    $[66] !== paddingY ? (t21 = _getArrayProp(paddingY), $[66] = paddingY, $[67] = t21) : t21 = $[67];
    let t22;
    $[68] !== paddingTop ? (t22 = _getArrayProp(paddingTop), $[68] = paddingTop, $[69] = t22) : t22 = $[69];
    let t23;
    $[70] !== paddingRight ? (t23 = _getArrayProp(paddingRight), $[70] = paddingRight, $[71] = t23) : t23 = $[71];
    let t24;
    $[72] !== paddingBottom ? (t24 = _getArrayProp(paddingBottom), $[72] = paddingBottom, $[73] = t24) : t24 = $[73];
    let t25;
    $[74] !== paddingLeft ? (t25 = _getArrayProp(paddingLeft), $[74] = paddingLeft, $[75] = t25) : t25 = $[75];
    let t26;
    $[76] !== row ? (t26 = _getArrayProp(row), $[76] = row, $[77] = t26) : t26 = $[77];
    let t27;
    $[78] !== rowStart ? (t27 = _getArrayProp(rowStart), $[78] = rowStart, $[79] = t27) : t27 = $[79];
    let t28;
    $[80] !== rowEnd ? (t28 = _getArrayProp(rowEnd), $[80] = rowEnd, $[81] = t28) : t28 = $[81];
    let t29;
    $[82] !== sizing ? (t29 = _getArrayProp(sizing), $[82] = sizing, $[83] = t29) : t29 = $[83];
    let t30;
    return $[84] !== asProp || $[85] !== props.children || $[86] !== ref || $[87] !== restProps || $[88] !== t10 || $[89] !== t11 || $[90] !== t12 || $[91] !== t13 || $[92] !== t14 || $[93] !== t15 || $[94] !== t16 || $[95] !== t17 || $[96] !== t18 || $[97] !== t19 || $[98] !== t20 || $[99] !== t21 || $[100] !== t22 || $[101] !== t23 || $[102] !== t24 || $[103] !== t25 || $[104] !== t26 || $[105] !== t27 || $[106] !== t28 || $[107] !== t29 || $[108] !== t4 || $[109] !== t5 || $[110] !== t6 || $[111] !== t7 || $[112] !== t8 || $[113] !== t9 ? (t30 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledBox, {
        "data-as": t4,
        "data-ui": "Box",
        ...restProps,
        $column: t5,
        $columnStart: t6,
        $columnEnd: t7,
        $display: t8,
        $flex: t9,
        $height: t10,
        $margin: t11,
        $marginX: t12,
        $marginY: t13,
        $marginTop: t14,
        $marginRight: t15,
        $marginBottom: t16,
        $marginLeft: t17,
        $overflow: t18,
        $padding: t19,
        $paddingX: t20,
        $paddingY: t21,
        $paddingTop: t22,
        $paddingRight: t23,
        $paddingBottom: t24,
        $paddingLeft: t25,
        $row: t26,
        $rowStart: t27,
        $rowEnd: t28,
        $sizing: t29,
        as: asProp,
        ref,
        children: props.children
    }), $[84] = asProp, $[85] = props.children, $[86] = ref, $[87] = restProps, $[88] = t10, $[89] = t11, $[90] = t12, $[91] = t13, $[92] = t14, $[93] = t15, $[94] = t16, $[95] = t17, $[96] = t18, $[97] = t19, $[98] = t20, $[99] = t21, $[100] = t22, $[101] = t23, $[102] = t24, $[103] = t25, $[104] = t26, $[105] = t27, $[106] = t28, $[107] = t29, $[108] = t4, $[109] = t5, $[110] = t6, $[111] = t7, $[112] = t8, $[113] = t9, $[114] = t30) : t30 = $[114], t30;
});
Box.displayName = "ForwardRef(Box)";
function textBaseStyle(props) {
    const { $accent, $muted } = props, { font } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    color: var(--card-fg-color);

    ${$accent && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
      color: var(--card-accent-fg-color);
    `}

    ${$muted && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
      color: var(--card-muted-fg-color);
    `}

    & code {
      font-family: ${font.code.family};
      border-radius: 1px;
      background-color: var(--card-code-bg-color);
      color: var(--card-code-fg-color);
    }

    & a {
      text-decoration: none;
      border-radius: 1px;
      color: var(--card-link-color);
      outline: none;

      @media (hover: hover) {
        &:hover {
          text-decoration: underline;
        }
      }

      &:focus {
        box-shadow:
          0 0 0 1px var(--card-bg-color),
          0 0 0 3px var(--card-focus-ring-color);
      }

      &:focus:not(:focus-visible) {
        box-shadow: none;
      }
    }

    & strong {
      font-weight: ${font.text.weights.bold};
    }

    & svg {
      /* Certain popular CSS libraries changes the defaults for SVG display */
      /* Make sure SVGs are rendered as inline elements */
      display: inline;
    }

    & [data-sanity-icon] {
      vertical-align: baseline;
      color: var(--card-icon-color);

      & path {
        vector-effect: non-scaling-stroke !important;
      }
    }
  `;
}
const StyledText = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledText",
    componentId: "sc-11ov82j-0"
})(responsiveTextFont, responsiveTextAlignStyle, textBaseStyle), Text = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(26);
    let align, childrenProp, restProps, t0, t1, t2, textOverflow, weight;
    $[0] !== props ? ({ accent: t0, align, children: childrenProp, muted: t1, size: t2, textOverflow, weight, ...restProps } = props, $[0] = props, $[1] = align, $[2] = childrenProp, $[3] = restProps, $[4] = t0, $[5] = t1, $[6] = t2, $[7] = textOverflow, $[8] = weight) : (align = $[1], childrenProp = $[2], restProps = $[3], t0 = $[4], t1 = $[5], t2 = $[6], textOverflow = $[7], weight = $[8]);
    const accent = t0 === void 0 ? !1 : t0, muted = t1 === void 0 ? !1 : t1, size2 = t2 === void 0 ? 2 : t2;
    let children = childrenProp;
    if (textOverflow === "ellipsis") {
        let t32;
        $[9] !== children ? (t32 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(SpanWithTextOverflow, {
            children
        }), $[9] = children, $[10] = t32) : t32 = $[10], children = t32;
    }
    let t3;
    $[11] !== align ? (t3 = _getArrayProp(align), $[11] = align, $[12] = t3) : t3 = $[12];
    let t4;
    $[13] !== size2 ? (t4 = _getArrayProp(size2), $[13] = size2, $[14] = t4) : t4 = $[14];
    let t5;
    $[15] !== children ? (t5 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
        children
    }), $[15] = children, $[16] = t5) : t5 = $[16];
    let t6;
    return $[17] !== accent || $[18] !== muted || $[19] !== ref || $[20] !== restProps || $[21] !== t3 || $[22] !== t4 || $[23] !== t5 || $[24] !== weight ? (t6 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledText, {
        "data-ui": "Text",
        ...restProps,
        $accent: accent,
        $align: t3,
        $muted: muted,
        ref,
        $size: t4,
        $weight: weight,
        children: t5
    }), $[17] = accent, $[18] = muted, $[19] = ref, $[20] = restProps, $[21] = t3, $[22] = t4, $[23] = t5, $[24] = weight, $[25] = t6) : t6 = $[25], t6;
});
Text.displayName = "ForwardRef(Text)";
function badgeStyle(props) {
    const { $tone } = props;
    return {
        "--card-bg-color": `var(--card-badge-${$tone}-bg-color)`,
        "--card-fg-color": `var(--card-badge-${$tone}-fg-color)`,
        backgroundColor: "var(--card-bg-color)",
        cursor: "default",
        "&:not([hidden])": {
            display: "inline-block",
            verticalAlign: "top"
        }
    };
}
const StyledBadge = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Box).withConfig({
    displayName: "StyledBadge",
    componentId: "sc-5u140l-0"
})(responsiveRadiusStyle, badgeStyle), Badge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(21);
    let children, restProps, t0, t1, t2, t3;
    if ($[0] !== props) {
        const { children: t42, fontSize: t52, mode: _deprecated_mode, padding: t62, radius: t72, tone: t8, ...t9 } = props;
        children = t42, t0 = t52, t1 = t62, t2 = t72, t3 = t8, restProps = t9, $[0] = props, $[1] = children, $[2] = restProps, $[3] = t0, $[4] = t1, $[5] = t2, $[6] = t3;
    } else children = $[1], restProps = $[2], t0 = $[3], t1 = $[4], t2 = $[5], t3 = $[6];
    const fontSize2 = t0 === void 0 ? 1 : t0, padding = t1 === void 0 ? 1 : t1, radius = t2 === void 0 ? "full" : t2, tone = t3 === void 0 ? "default" : t3;
    let t4;
    $[7] !== radius ? (t4 = _getArrayProp(radius), $[7] = radius, $[8] = t4) : t4 = $[8];
    let t5;
    $[9] !== padding ? (t5 = _getArrayProp(padding), $[9] = padding, $[10] = t5) : t5 = $[10];
    let t6;
    $[11] !== children || $[12] !== fontSize2 ? (t6 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Text, {
        size: fontSize2,
        children
    }), $[11] = children, $[12] = fontSize2, $[13] = t6) : t6 = $[13];
    let t7;
    return $[14] !== ref || $[15] !== restProps || $[16] !== t4 || $[17] !== t5 || $[18] !== t6 || $[19] !== tone ? (t7 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledBadge, {
        "data-ui": "Badge",
        ...restProps,
        $tone: tone,
        $radius: t4,
        padding: t5,
        ref,
        children: t6
    }), $[14] = ref, $[15] = restProps, $[16] = t4, $[17] = t5, $[18] = t6, $[19] = tone, $[20] = t7) : t7 = $[20], t7;
});
Badge.displayName = "ForwardRef(Badge)";
const StyledFlex = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Box).withConfig({
    displayName: "StyledFlex",
    componentId: "sc-oxesg3-0"
})(flexItemStyle, responsiveFlexStyle), Flex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(27);
    let align, as, gap, justify, restProps, t0, wrap;
    $[0] !== props ? ({ align, as, direction: t0, gap, justify, wrap, ...restProps } = props, $[0] = props, $[1] = align, $[2] = as, $[3] = gap, $[4] = justify, $[5] = restProps, $[6] = t0, $[7] = wrap) : (align = $[1], as = $[2], gap = $[3], justify = $[4], restProps = $[5], t0 = $[6], wrap = $[7]);
    const direction = t0 === void 0 ? "row" : t0;
    let t1;
    $[8] !== align ? (t1 = _getArrayProp(align), $[8] = align, $[9] = t1) : t1 = $[9];
    let t2;
    $[10] !== direction ? (t2 = _getArrayProp(direction), $[10] = direction, $[11] = t2) : t2 = $[11];
    let t3;
    $[12] !== gap ? (t3 = _getArrayProp(gap), $[12] = gap, $[13] = t3) : t3 = $[13];
    let t4;
    $[14] !== justify ? (t4 = _getArrayProp(justify), $[14] = justify, $[15] = t4) : t4 = $[15];
    let t5;
    $[16] !== wrap ? (t5 = _getArrayProp(wrap), $[16] = wrap, $[17] = t5) : t5 = $[17];
    let t6;
    return $[18] !== as || $[19] !== ref || $[20] !== restProps || $[21] !== t1 || $[22] !== t2 || $[23] !== t3 || $[24] !== t4 || $[25] !== t5 ? (t6 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledFlex, {
        "data-ui": "Flex",
        ...restProps,
        $align: t1,
        $direction: t2,
        $gap: t3,
        $justify: t4,
        $wrap: t5,
        forwardedAs: as,
        ref
    }), $[18] = as, $[19] = ref, $[20] = restProps, $[21] = t1, $[22] = t2, $[23] = t3, $[24] = t4, $[25] = t5, $[26] = t6) : t6 = $[26], t6;
});
Flex.displayName = "ForwardRef(Flex)";
const rotate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["keyframes"]`
  from {
    transform: rotate(0deg);
  }

  to {
    transform: rotate(360deg);
  }
`, StyledSpinner = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Text).withConfig({
    displayName: "StyledSpinner",
    componentId: "sc-124hnd0-0"
})`& > span > svg{animation:${rotate} 500ms linear infinite;}`, Spinner = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    let t0;
    $[0] === Symbol.for("react.memo_cache_sentinel") ? (t0 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpinnerIcon"], {}), $[0] = t0) : t0 = $[0];
    let t1;
    return $[1] !== props || $[2] !== ref ? (t1 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledSpinner, {
        "data-ui": "Spinner",
        ...props,
        ref,
        children: t0
    }), $[1] = props, $[2] = ref, $[3] = t1) : t1 = $[3], t1;
});
Spinner.displayName = "ForwardRef(Spinner)";
function _cardColorStyle(base, color, checkered = !1) {
    return {
        // from base
        "--card-backdrop-color": base.backdrop,
        "--card-focus-ring-color": base.focusRing,
        "--card-shadow-outline-color": base.shadow.outline,
        "--card-shadow-umbra-color": base.shadow.umbra,
        "--card-shadow-penumbra-color": base.shadow.penumbra,
        "--card-shadow-ambient-color": base.shadow.ambient,
        // from state
        "--card-accent-fg-color": color.accent.fg,
        "--card-avatar-gray-bg-color": color.avatar.gray.bg,
        "--card-avatar-gray-fg-color": color.avatar.gray.fg,
        "--card-avatar-blue-bg-color": color.avatar.blue.bg,
        "--card-avatar-blue-fg-color": color.avatar.blue.fg,
        "--card-avatar-purple-bg-color": color.avatar.purple.bg,
        "--card-avatar-purple-fg-color": color.avatar.purple.fg,
        "--card-avatar-magenta-bg-color": color.avatar.magenta.bg,
        "--card-avatar-magenta-fg-color": color.avatar.magenta.fg,
        "--card-avatar-red-bg-color": color.avatar.red.bg,
        "--card-avatar-red-fg-color": color.avatar.red.fg,
        "--card-avatar-orange-bg-color": color.avatar.orange.bg,
        "--card-avatar-orange-fg-color": color.avatar.orange.fg,
        "--card-avatar-yellow-bg-color": color.avatar.yellow.bg,
        "--card-avatar-yellow-fg-color": color.avatar.yellow.fg,
        "--card-avatar-green-bg-color": color.avatar.green.bg,
        "--card-avatar-green-fg-color": color.avatar.green.fg,
        "--card-avatar-cyan-bg-color": color.avatar.cyan.bg,
        "--card-avatar-cyan-fg-color": color.avatar.cyan.fg,
        "--card-bg-color": color.bg,
        "--card-bg-image": checkered ? `repeating-conic-gradient(${color.bg} 0% 25%, ${color.muted.bg} 0% 50%)` : void 0,
        "--card-border-color": color.border,
        "--card-badge-default-bg-color": color.badge.default.bg,
        "--card-badge-default-dot-color": color.badge.default.dot,
        "--card-badge-default-fg-color": color.badge.default.fg,
        "--card-badge-default-icon-color": color.badge.default.icon,
        "--card-badge-neutral-bg-color": color.badge.neutral?.bg,
        "--card-badge-neutral-dot-color": color.badge.neutral?.dot,
        "--card-badge-neutral-fg-color": color.badge.neutral?.fg,
        "--card-badge-neutral-icon-color": color.badge.neutral?.icon,
        "--card-badge-primary-bg-color": color.badge.primary.bg,
        "--card-badge-primary-dot-color": color.badge.primary.dot,
        "--card-badge-primary-fg-color": color.badge.primary.fg,
        "--card-badge-primary-icon-color": color.badge.primary.icon,
        "--card-badge-suggest-bg-color": color.badge.suggest?.bg,
        "--card-badge-suggest-dot-color": color.badge.suggest?.dot,
        "--card-badge-suggest-fg-color": color.badge.suggest?.fg,
        "--card-badge-suggest-icon-color": color.badge.suggest?.icon,
        "--card-badge-positive-bg-color": color.badge.positive.bg,
        "--card-badge-positive-dot-color": color.badge.positive.dot,
        "--card-badge-positive-fg-color": color.badge.positive.fg,
        "--card-badge-positive-icon-color": color.badge.positive.icon,
        "--card-badge-caution-bg-color": color.badge.caution.bg,
        "--card-badge-caution-dot-color": color.badge.caution.dot,
        "--card-badge-caution-fg-color": color.badge.caution.fg,
        "--card-badge-caution-icon-color": color.badge.caution.icon,
        "--card-badge-critical-bg-color": color.badge.critical.bg,
        "--card-badge-critical-dot-color": color.badge.critical.dot,
        "--card-badge-critical-fg-color": color.badge.critical.fg,
        "--card-badge-critical-icon-color": color.badge.critical.icon,
        "--card-code-bg-color": color.code.bg,
        "--card-code-fg-color": color.code.fg,
        "--card-fg-color": color.fg,
        "--card-icon-color": color.icon,
        "--card-kbd-bg-color": color.kbd.bg,
        "--card-kbd-border-color": color.kbd.border,
        "--card-kbd-fg-color": color.kbd.fg,
        "--card-link-fg-color": color.link.fg,
        "--card-muted-bg-color": color.muted.bg,
        "--card-muted-fg-color": color.muted.fg,
        "--card-skeleton-color-from": color.skeleton.from,
        "--card-skeleton-color-to": color.skeleton.to,
        // deprecated variables (kept for legacy)
        "--card-bg2-color": color.muted.bg,
        "--card-link-color": color.link.fg,
        "--card-hairline-soft-color": color.border,
        "--card-hairline-hard-color": color.border
    };
}
function buttonBaseStyles(props) {
    const { $width } = props, { style } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    ${style?.button};

    -webkit-font-smoothing: inherit;
    appearance: none;
    display: inline-flex;
    align-items: center;
    font: inherit;
    border: 0;
    outline: none;
    user-select: none;
    text-decoration: none;
    border: 0;
    box-sizing: border-box;
    padding: 0;
    margin: 0;
    white-space: nowrap;
    text-align: left;
    position: relative;
    vertical-align: top;

    ${$width === "fill" && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
      width: -moz-available;
      width: -webkit-fill-available;
      width: stretch;
    `}

    & > span {
      display: block;
      flex: 1;
      min-width: 0;
      border-radius: inherit;
    }

    &::-moz-focus-inner {
      border: 0;
      padding: 0;
    }
  `;
}
function combineBoxShadow(...boxShadows) {
    return boxShadows.filter(Boolean).join(",");
}
function buttonColorStyles(props) {
    const { $mode } = props, { button, color: baseColor, style } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), shadow = props.$mode === "ghost", mode = baseColor.button[$mode] || baseColor.button.default, color = mode[props.$tone] || mode.default, border2 = {
        width: button.border.width,
        color: "var(--card-border-color)"
    }, defaultBoxShadow = void 0;
    return [
        _cardColorStyle(baseColor, color.enabled),
        {
            backgroundColor: "var(--card-bg-color)",
            color: "var(--card-fg-color)",
            boxShadow: focusRingBorderStyle(border2),
            '&:disabled, &[data-disabled="true"]': _cardColorStyle(baseColor, color.disabled),
            "&:not([data-disabled='true'])": {
                boxShadow: combineBoxShadow(focusRingBorderStyle(border2), shadow ? defaultBoxShadow : void 0),
                "&:focus": {
                    boxShadow: focusRingStyle({
                        base: baseColor,
                        border: {
                            width: 2,
                            color: baseColor.bg
                        },
                        focusRing: button.focusRing
                    })
                },
                "&:focus:not(:focus-visible)": {
                    boxShadow: combineBoxShadow(focusRingBorderStyle(border2), shadow ? defaultBoxShadow : void 0)
                },
                "@media (hover: hover)": {
                    "&:hover": _cardColorStyle(baseColor, color.hovered),
                    "&:active": _cardColorStyle(baseColor, color.pressed),
                    "&[data-hovered]": _cardColorStyle(baseColor, color.hovered)
                },
                "&[data-selected]": _cardColorStyle(baseColor, color.pressed)
            }
        },
        style?.button?.root
    ].filter(Boolean);
}
const StyledButton = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].button.withConfig({
    displayName: "StyledButton",
    componentId: "sc-aaekt4-0"
})(responsiveRadiusStyle, buttonBaseStyles, buttonColorStyles), LoadingBox = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "LoadingBox",
    componentId: "sc-aaekt4-1"
})`position:absolute;top:0;left:0;right:0;bottom:0;display:flex;align-items:center;justify-content:center;background-color:var(--card-bg-color);border-radius:inherit;z-index:1;box-shadow:inherit;`, Button = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(87);
    let IconComponent, IconRightComponent, children, disabled, gap, loading, paddingBottomProp, paddingLeftProp, paddingRightProp, paddingTopProp, paddingXProp, paddingYProp, restProps, selected, t0, t1, t2, t3, t4, t5, t6, t7, t8, text, textAlign, textWeight, width;
    $[0] !== props ? ({ children, disabled, fontSize: t0, icon: IconComponent, iconRight: IconRightComponent, justify: t1, loading, mode: t2, padding: t3, paddingX: paddingXProp, paddingY: paddingYProp, paddingTop: paddingTopProp, paddingBottom: paddingBottomProp, paddingLeft: paddingLeftProp, paddingRight: paddingRightProp, radius: t4, selected, gap, space: t5, text, textAlign, textWeight, tone: t6, type: t7, muted: t8, width, ...restProps } = props, $[0] = props, $[1] = IconComponent, $[2] = IconRightComponent, $[3] = children, $[4] = disabled, $[5] = gap, $[6] = loading, $[7] = paddingBottomProp, $[8] = paddingLeftProp, $[9] = paddingRightProp, $[10] = paddingTopProp, $[11] = paddingXProp, $[12] = paddingYProp, $[13] = restProps, $[14] = selected, $[15] = t0, $[16] = t1, $[17] = t2, $[18] = t3, $[19] = t4, $[20] = t5, $[21] = t6, $[22] = t7, $[23] = t8, $[24] = text, $[25] = textAlign, $[26] = textWeight, $[27] = width) : (IconComponent = $[1], IconRightComponent = $[2], children = $[3], disabled = $[4], gap = $[5], loading = $[6], paddingBottomProp = $[7], paddingLeftProp = $[8], paddingRightProp = $[9], paddingTopProp = $[10], paddingXProp = $[11], paddingYProp = $[12], restProps = $[13], selected = $[14], t0 = $[15], t1 = $[16], t2 = $[17], t3 = $[18], t4 = $[19], t5 = $[20], t6 = $[21], t7 = $[22], t8 = $[23], text = $[24], textAlign = $[25], textWeight = $[26], width = $[27]);
    const fontSize2 = t0 === void 0 ? 1 : t0, justifyProp = t1 === void 0 ? "center" : t1, mode = t2 === void 0 ? "default" : t2, paddingProp = t3 === void 0 ? 3 : t3, radiusProp = t4 === void 0 ? 2 : t4, deprecated_space = t5 === void 0 ? 3 : t5, tone = t6 === void 0 ? "default" : t6, type = t7 === void 0 ? "button" : t7, muted = t8 === void 0 ? !1 : t8, { button } = useTheme_v2();
    let t9;
    $[28] !== justifyProp ? (t9 = _getArrayProp(justifyProp), $[28] = justifyProp, $[29] = t9) : t9 = $[29];
    const justify = t9;
    let t10;
    $[30] !== paddingProp ? (t10 = _getArrayProp(paddingProp), $[30] = paddingProp, $[31] = t10) : t10 = $[31];
    const padding = t10;
    let t11;
    $[32] !== paddingXProp ? (t11 = _getArrayProp(paddingXProp), $[32] = paddingXProp, $[33] = t11) : t11 = $[33];
    const paddingX = t11;
    let t12;
    $[34] !== paddingYProp ? (t12 = _getArrayProp(paddingYProp), $[34] = paddingYProp, $[35] = t12) : t12 = $[35];
    const paddingY = t12;
    let t13;
    $[36] !== paddingTopProp ? (t13 = _getArrayProp(paddingTopProp), $[36] = paddingTopProp, $[37] = t13) : t13 = $[37];
    const paddingTop = t13;
    let t14;
    $[38] !== paddingBottomProp ? (t14 = _getArrayProp(paddingBottomProp), $[38] = paddingBottomProp, $[39] = t14) : t14 = $[39];
    const paddingBottom = t14;
    let t15;
    $[40] !== paddingLeftProp ? (t15 = _getArrayProp(paddingLeftProp), $[40] = paddingLeftProp, $[41] = t15) : t15 = $[41];
    const paddingLeft = t15;
    let t16;
    $[42] !== paddingRightProp ? (t16 = _getArrayProp(paddingRightProp), $[42] = paddingRightProp, $[43] = t16) : t16 = $[43];
    const paddingRight = t16;
    let t17;
    $[44] !== radiusProp ? (t17 = _getArrayProp(radiusProp), $[44] = radiusProp, $[45] = t17) : t17 = $[45];
    const radius = t17, t18 = gap === void 0 ? deprecated_space : gap;
    let t19;
    $[46] !== t18 ? (t19 = _getArrayProp(t18), $[46] = t18, $[47] = t19) : t19 = $[47];
    const spacing = t19;
    let t20;
    $[48] !== padding || $[49] !== paddingBottom || $[50] !== paddingLeft || $[51] !== paddingRight || $[52] !== paddingTop || $[53] !== paddingX || $[54] !== paddingY ? (t20 = {
        padding,
        paddingX,
        paddingY,
        paddingTop,
        paddingBottom,
        paddingLeft,
        paddingRight
    }, $[48] = padding, $[49] = paddingBottom, $[50] = paddingLeft, $[51] = paddingRight, $[52] = paddingTop, $[53] = paddingX, $[54] = paddingY, $[55] = t20) : t20 = $[55];
    const boxProps = t20, t21 = !!(loading || disabled), t22 = selected ? "" : void 0, t23 = !!(loading || disabled);
    let t24;
    $[56] !== loading ? (t24 = !!loading && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LoadingBox, {
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Spinner, {})
    }), $[56] = loading, $[57] = t24) : t24 = $[57];
    let t25;
    $[58] !== IconComponent || $[59] !== IconRightComponent || $[60] !== boxProps || $[61] !== button || $[62] !== fontSize2 || $[63] !== justify || $[64] !== muted || $[65] !== spacing || $[66] !== text || $[67] !== textAlign || $[68] !== textWeight ? (t25 = (IconComponent || text || IconRightComponent) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Box, {
        as: "span",
        ...boxProps,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Flex, {
            as: "span",
            justify,
            gap: spacing,
            children: [
                IconComponent && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Text, {
                    size: fontSize2,
                    children: [
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(IconComponent) && IconComponent,
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElementType"])(IconComponent) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(IconComponent, {})
                    ]
                }),
                text && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Box, {
                    children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Text, {
                        muted,
                        align: textAlign,
                        size: fontSize2,
                        textOverflow: "ellipsis",
                        weight: textWeight ?? button.textWeight,
                        children: text
                    })
                }),
                IconRightComponent && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Text, {
                    size: fontSize2,
                    children: [
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(IconRightComponent) && IconRightComponent,
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElementType"])(IconRightComponent) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(IconRightComponent, {})
                    ]
                })
            ]
        })
    }), $[58] = IconComponent, $[59] = IconRightComponent, $[60] = boxProps, $[61] = button, $[62] = fontSize2, $[63] = justify, $[64] = muted, $[65] = spacing, $[66] = text, $[67] = textAlign, $[68] = textWeight, $[69] = t25) : t25 = $[69];
    let t26;
    $[70] !== boxProps || $[71] !== children ? (t26 = children && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Box, {
        as: "span",
        ...boxProps,
        children
    }), $[70] = boxProps, $[71] = children, $[72] = t26) : t26 = $[72];
    let t27;
    return $[73] !== mode || $[74] !== radius || $[75] !== ref || $[76] !== restProps || $[77] !== t21 || $[78] !== t22 || $[79] !== t23 || $[80] !== t24 || $[81] !== t25 || $[82] !== t26 || $[83] !== tone || $[84] !== type || $[85] !== width ? (t27 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(StyledButton, {
        "data-ui": "Button",
        ...restProps,
        $mode: mode,
        $radius: radius,
        $tone: tone,
        "data-disabled": t21,
        "data-selected": t22,
        disabled: t23,
        ref,
        type,
        $width: width,
        children: [
            t24,
            t25,
            t26
        ]
    }), $[73] = mode, $[74] = radius, $[75] = ref, $[76] = restProps, $[77] = t21, $[78] = t22, $[79] = t23, $[80] = t24, $[81] = t25, $[82] = t26, $[83] = tone, $[84] = type, $[85] = width, $[86] = t27) : t27 = $[86], t27;
});
Button.displayName = "ForwardRef(Button)";
function cardStyle(props) {
    return [
        cardBaseStyle(props),
        cardColorStyle(props)
    ];
}
function cardBaseStyle(props) {
    const { $checkered } = props, { space } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    ${$checkered && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
      background-size: ${space[3]}px ${space[3]}px;
      background-position: 50% 50%;
      background-image: var(--card-bg-image);
    `}

    &[data-as='button'] {
      -webkit-font-smoothing: inherit;
      appearance: none;
      outline: none;
      font: inherit;
      text-align: inherit;
      border: 0;
      width: -moz-available;
      width: -webkit-fill-available;
      width: stretch;
    }

    /* &:is(a) */
    &[data-as='a'] {
      outline: none;
      text-decoration: none;
    }

    /* &:is(pre) */
    &[data-as='pre'] {
      font: inherit;
    }
  `;
}
function cardColorStyle(props) {
    const { $checkered, $focusRing, $muted } = props, { card, color, style } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), border2 = {
        width: card.border.width,
        color: "var(--card-border-color)"
    };
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    color-scheme: ${color._dark ? "dark" : "light"};

    ${_cardColorStyle(color, color, $checkered)}

    background-color: ${$muted ? "var(--card-muted-bg-color)" : "var(--card-bg-color)"};
    color: var(--card-fg-color);

    /* &:is(button) */
    &[data-as='button'] {
      --card-focus-ring-box-shadow: none;

      cursor: default;
      box-shadow: var(--card-focus-ring-box-shadow);

      &:disabled {
        ${_cardColorStyle(color, color.selectable.default.disabled, $checkered)}
      }

      &:not(:disabled) {
        &[data-pressed] {
          ${_cardColorStyle(color, color.selectable.default.pressed, $checkered)}
        }

        &[data-selected] {
          ${_cardColorStyle(color, color.selectable.default.selected, $checkered)}
        }

        @media (hover: hover) {
          &:not([data-pressed]):not([data-selected]) {
            &[data-hovered],
            &:hover {
              ${_cardColorStyle(color, color.selectable.default.hovered, $checkered)}
            }

            &:active {
              ${_cardColorStyle(color, color.selectable.default.pressed, $checkered)}
            }
          }
        }

        &:focus-visible {
          --card-focus-ring-box-shadow: ${$focusRing ? focusRingStyle({
        base: color,
        border: border2,
        focusRing: card.focusRing
    }) : void 0};
        }
      }
    }

    /* &:is(a) */
    &[data-as='a'] {
      cursor: pointer;
      box-shadow: var(--card-focus-ring-box-shadow);

      &[data-disabled] {
        ${_cardColorStyle(color, color.selectable.default.disabled, $checkered)}
      }

      &:not([data-disabled]) {
        &[data-pressed] {
          ${_cardColorStyle(color, color.selectable.default.pressed, $checkered)}
        }

        &[data-selected] {
          ${_cardColorStyle(color, color.selectable.default.selected, $checkered)}
        }

        @media (hover: hover) {
          &:not([data-pressed]):not([data-selected]) {
            &[data-hovered],
            &:hover {
              ${_cardColorStyle(color, color.selectable.default.hovered, $checkered)}
            }

            &:active {
              ${_cardColorStyle(color, color.selectable.default.pressed, $checkered)}
            }
          }
        }

        &:focus-visible {
          --card-focus-ring-box-shadow: ${$focusRing ? focusRingStyle({
        base: color,
        border: border2,
        focusRing: card.focusRing
    }) : void 0};
        }
      }
    }

    ${style?.card?.root}
  `;
}
const StyledCard = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Box).withConfig({
    displayName: "StyledCard",
    componentId: "sc-osnro2-0"
})(responsiveBorderStyle, responsiveRadiusStyle, responsiveShadowStyle, cardStyle), Card = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(56);
    let asProp, border2, borderBottom2, borderLeft2, borderRight2, borderTop2, muted, pressed, restProps, scheme, selected, shadow, t0, t1, t2, t3;
    $[0] !== props ? ({ __unstable_checkered: t0, __unstable_focusRing: t1, as: asProp, border: border2, borderTop: borderTop2, borderRight: borderRight2, borderBottom: borderBottom2, borderLeft: borderLeft2, muted, pressed, radius: t2, scheme, selected, shadow, tone: t3, ...restProps } = props, $[0] = props, $[1] = asProp, $[2] = border2, $[3] = borderBottom2, $[4] = borderLeft2, $[5] = borderRight2, $[6] = borderTop2, $[7] = muted, $[8] = pressed, $[9] = restProps, $[10] = scheme, $[11] = selected, $[12] = shadow, $[13] = t0, $[14] = t1, $[15] = t2, $[16] = t3) : (asProp = $[1], border2 = $[2], borderBottom2 = $[3], borderLeft2 = $[4], borderRight2 = $[5], borderTop2 = $[6], muted = $[7], pressed = $[8], restProps = $[9], scheme = $[10], selected = $[11], shadow = $[12], t0 = $[13], t1 = $[14], t2 = $[15], t3 = $[16]);
    const checkered = t0 === void 0 ? !1 : t0, focusRing = t1 === void 0 ? !1 : t1, radius = t2 === void 0 ? 0 : t2, toneProp = t3 === void 0 ? "default" : t3, as = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElementType"])(asProp) ? asProp : "div", rootTheme = useRootTheme(), tone = toneProp === "inherit" ? rootTheme.tone : toneProp, t4 = typeof as == "string" ? as : void 0, t5 = rootTheme.scheme;
    let t6;
    $[17] !== border2 ? (t6 = _getArrayProp(border2), $[17] = border2, $[18] = t6) : t6 = $[18];
    let t7;
    $[19] !== borderTop2 ? (t7 = _getArrayProp(borderTop2), $[19] = borderTop2, $[20] = t7) : t7 = $[20];
    let t8;
    $[21] !== borderRight2 ? (t8 = _getArrayProp(borderRight2), $[21] = borderRight2, $[22] = t8) : t8 = $[22];
    let t9;
    $[23] !== borderBottom2 ? (t9 = _getArrayProp(borderBottom2), $[23] = borderBottom2, $[24] = t9) : t9 = $[24];
    let t10;
    $[25] !== borderLeft2 ? (t10 = _getArrayProp(borderLeft2), $[25] = borderLeft2, $[26] = t10) : t10 = $[26];
    let t11;
    $[27] !== radius ? (t11 = _getArrayProp(radius), $[27] = radius, $[28] = t11) : t11 = $[28];
    let t12;
    $[29] !== shadow ? (t12 = _getArrayProp(shadow), $[29] = shadow, $[30] = t12) : t12 = $[30];
    const t13 = checkered ? "" : void 0, t14 = pressed ? "" : void 0, t15 = selected ? "" : void 0;
    let t16;
    $[31] !== as || $[32] !== checkered || $[33] !== focusRing || $[34] !== muted || $[35] !== ref || $[36] !== restProps || $[37] !== rootTheme.scheme || $[38] !== selected || $[39] !== t10 || $[40] !== t11 || $[41] !== t12 || $[42] !== t13 || $[43] !== t14 || $[44] !== t15 || $[45] !== t4 || $[46] !== t6 || $[47] !== t7 || $[48] !== t8 || $[49] !== t9 || $[50] !== tone ? (t16 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledCard, {
        "data-as": t4,
        "data-scheme": t5,
        "data-ui": "Card",
        "data-tone": tone,
        ...restProps,
        $border: t6,
        $borderTop: t7,
        $borderRight: t8,
        $borderBottom: t9,
        $borderLeft: t10,
        $checkered: checkered,
        $focusRing: focusRing,
        $muted: muted,
        $radius: t11,
        $shadow: t12,
        $tone: tone,
        "data-checkered": t13,
        "data-pressed": t14,
        "data-selected": t15,
        forwardedAs: as,
        ref,
        selected
    }), $[31] = as, $[32] = checkered, $[33] = focusRing, $[34] = muted, $[35] = ref, $[36] = restProps, $[37] = rootTheme.scheme, $[38] = selected, $[39] = t10, $[40] = t11, $[41] = t12, $[42] = t13, $[43] = t14, $[44] = t15, $[45] = t4, $[46] = t6, $[47] = t7, $[48] = t8, $[49] = t9, $[50] = tone, $[51] = t16) : t16 = $[51];
    let t17;
    return $[52] !== scheme || $[53] !== t16 || $[54] !== tone ? (t17 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ThemeColorProvider, {
        scheme,
        tone,
        children: t16
    }), $[52] = scheme, $[53] = t16, $[54] = tone, $[55] = t17) : t17 = $[55], t17;
});
Card.displayName = "ForwardRef(Card)";
function useClickOutsideEvent(listener, t0, boundaryElement) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9), elementsArg = t0 === void 0 ? _temp$8 : t0;
    let t1;
    $[0] !== boundaryElement || $[1] !== elementsArg || $[2] !== listener ? (t1 = (evt)=>{
        if (!listener) return;
        const target = evt.target;
        if (!(target instanceof Node)) return;
        const resolvedBoundaryElement = boundaryElement?.();
        if (resolvedBoundaryElement && !resolvedBoundaryElement.contains(target)) return;
        const elements = elementsArg().flat();
        for (const el of elements)if (el && (target === el || el.contains(target))) return;
        listener(evt);
    }, $[0] = boundaryElement, $[1] = elementsArg, $[2] = listener, $[3] = t1) : t1 = $[3];
    const onEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$effect$2d$event$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffectEvent"])(t1), hasListener = !!listener;
    let t2;
    $[4] !== hasListener || $[5] !== onEvent ? (t2 = ()=>{
        if (!hasListener) return;
        const handleEvent = (evt_0)=>onEvent(evt_0);
        return document.addEventListener("mousedown", handleEvent), ()=>{
            document.removeEventListener("mousedown", handleEvent);
        };
    }, $[4] = hasListener, $[5] = onEvent, $[6] = t2) : t2 = $[6];
    let t3;
    $[7] !== hasListener ? (t3 = [
        hasListener
    ], $[7] = hasListener, $[8] = t3) : t3 = $[8], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebugValue"])(listener ? "MouseDown On" : "MouseDown Off");
}
function _temp$8() {
    return EMPTY_ARRAY;
}
function useCustomValidity(ref, customValidity) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    let t0, t1;
    $[0] !== customValidity || $[1] !== ref ? (t0 = ()=>{
        ref.current?.setCustomValidity(customValidity || "");
    }, t1 = [
        customValidity,
        ref
    ], $[0] = customValidity, $[1] = ref, $[2] = t0, $[3] = t1) : (t0 = $[2], t1 = $[3]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
}
const _ResizeObserver = typeof document < "u" && typeof window < "u" && window.ResizeObserver ? window.ResizeObserver : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$juggle$2f$resize$2d$observer$2f$lib$2f$ResizeObserver$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResizeObserver"], _elementSizeObserver = _createElementSizeObserver();
function _createElementRectValueListener() {
    return {
        subscribe (element, subscriber) {
            const resizeObserver = new _ResizeObserver(([entry])=>{
                subscriber({
                    _contentRect: entry.contentRect,
                    border: {
                        width: entry.borderBoxSize[0].inlineSize,
                        height: entry.borderBoxSize[0].blockSize
                    },
                    content: {
                        width: entry.contentRect.width,
                        height: entry.contentRect.height
                    }
                });
            });
            return resizeObserver.observe(element), ()=>{
                resizeObserver.unobserve(element), resizeObserver.disconnect();
            };
        }
    };
}
function _createElementSizeObserver() {
    const disposeCache = /* @__PURE__ */ new WeakMap(), subscribersCache = /* @__PURE__ */ new WeakMap();
    return {
        subscribe (element, subscriber) {
            const subscribers = subscribersCache.get(element) || [];
            let dispose = disposeCache.get(element);
            return subscribersCache.has(element) || (subscribersCache.set(element, subscribers), dispose = _createElementRectValueListener().subscribe(element, (elementRect)=>{
                for (const sub of subscribers)sub(elementRect);
            })), subscribers.push(subscriber), ()=>{
                const idx = subscribers.indexOf(subscriber);
                idx > -1 && subscribers.splice(idx, 1), subscribers.length === 0 && dispose && dispose();
            };
        }
    };
}
function useElementSize(element) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3), [size2, setSize] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t0, t1;
    return $[0] !== element ? (t0 = ()=>{
        if (element) return _elementSizeObserver.subscribe(element, setSize);
    }, t1 = [
        element
    ], $[0] = element, $[1] = t0, $[2] = t1) : (t0 = $[1], t1 = $[2]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1), size2;
}
function useGlobalKeyDown(onKeyDown, options) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    let t0;
    $[0] !== onKeyDown ? (t0 = (event)=>onKeyDown(event), $[0] = onKeyDown, $[1] = t0) : t0 = $[1];
    const handleKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$effect$2d$event$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffectEvent"])(t0);
    let t1;
    $[2] !== handleKeyDown || $[3] !== options ? (t1 = ()=>{
        const handler = (event_0)=>handleKeyDown(event_0);
        return window.addEventListener("keydown", handler, options), ()=>window.removeEventListener("keydown", handler, options);
    }, $[2] = handleKeyDown, $[3] = options, $[4] = t1) : t1 = $[4];
    let t2;
    $[5] !== options ? (t2 = [
        options
    ], $[5] = options, $[6] = t2) : t2 = $[6], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
}
function useMatchMedia(mediaQueryString, getServerSnapshot2) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebugValue"])(mediaQueryString);
    let t0;
    $[0] !== mediaQueryString ? (t0 = (onStoreChange)=>{
        const media = window.matchMedia(mediaQueryString);
        return media.addEventListener("change", onStoreChange), ()=>media.removeEventListener("change", onStoreChange);
    }, $[0] = mediaQueryString, $[1] = t0) : t0 = $[1];
    let t1;
    return $[2] !== mediaQueryString ? (t1 = ()=>window.matchMedia(mediaQueryString).matches, $[2] = mediaQueryString, $[3] = t1) : t1 = $[3], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(t0, t1, getServerSnapshot2);
}
function _getMediaQuery(media, index) {
    return index === 0 ? `screen and (max-width: ${media[index] - 1}px)` : index === media.length ? `screen and (min-width: ${media[index - 1]}px)` : `screen and (min-width: ${media[index - 1]}px) and (max-width: ${media[index] - 1}px)`;
}
function _createMediaStore(media) {
    const mediaLen = media.length;
    let sizes;
    const getSizes = ()=>{
        if (!sizes) {
            sizes = [];
            for(let index = mediaLen; index > -1; index -= 1){
                const mediaQuery = _getMediaQuery(media, index);
                sizes.push({
                    index,
                    mq: window.matchMedia(mediaQuery)
                });
            }
        }
        return sizes;
    };
    return {
        getSnapshot: ()=>{
            for (const { index, mq } of getSizes())if (mq.matches) return index;
            return 0;
        },
        subscribe: (onStoreChange)=>{
            const disposeFns = [];
            for (const { mq } of getSizes()){
                const handleChange = ()=>{
                    mq.matches && onStoreChange();
                };
                mq.addEventListener("change", handleChange), disposeFns.push(()=>mq.removeEventListener("change", handleChange));
            }
            return ()=>{
                for (const disposeFn of disposeFns)disposeFn();
            };
        }
    };
}
function getServerSnapshot() {
    return 0;
}
function useMediaIndex() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2), { media } = useTheme_v2();
    let t0;
    $[0] !== media ? (t0 = _createMediaStore(media), $[0] = media, $[1] = t0) : t0 = $[1];
    const store = t0;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(store.subscribe, store.getSnapshot, getServerSnapshot);
}
function usePrefersDark(t0) {
    return useMatchMedia("(prefers-color-scheme: dark)", t0 === void 0 ? _temp$7 : t0);
}
function _temp$7() {
    return !1;
}
function usePrefersReducedMotion(t0) {
    return useMatchMedia("(prefers-reduced-motion: reduce)", t0 === void 0 ? _temp$6 : t0);
}
function _temp$6() {
    return !1;
}
function checkboxBaseStyles() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    position: relative;
    display: inline-block;
  `;
}
function inputElementStyles(props) {
    const { color, input, radius } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), { focusRing } = input.checkbox;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    outline: none;
    opacity: 0;
    z-index: 1;
    padding: 0;
    margin: 0;

    & + span {
      position: relative;
      display: block;
      height: ${rem(input.checkbox.size)};
      width: ${rem(input.checkbox.size)};
      box-sizing: border-box;
      box-shadow: ${focusRingBorderStyle({
        color: color.input.default.enabled.border,
        width: input.border.width
    })};
      border-radius: ${rem(radius[2])};
      line-height: 1;
      background-color: ${color.input.default.enabled.bg};

      & > svg {
        display: block;
        position: absolute;
        opacity: 0;
        height: 100%;
        width: 100%;

        & > path {
          vector-effect: non-scaling-stroke;
          stroke-width: 1.5px !important;
        }
      }
    }

    &:checked + span {
      background: ${color.input.default.enabled.fg};
      box-shadow: ${focusRingBorderStyle({
        color: color.input.default.enabled.fg,
        width: input.border.width
    })};
      color: ${color.input.default.enabled.bg};
    }

    /* focus */
    &:not(:disabled):focus:focus-visible + span {
      box-shadow: ${focusRingStyle({
        focusRing
    })};
    }

    /* focus when checked - uses a different offset */
    &:not(:disabled):focus:focus-visible&:checked + span {
      box-shadow: ${focusRingStyle({
        focusRing: {
            width: 1,
            offset: 1
        }
    })};
    }

    &[data-error] + span {
      background-color: ${color.input.invalid.enabled.border};
      box-shadow: ${focusRingBorderStyle({
        width: input.border.width,
        color: color.input.invalid.enabled.muted.bg
    })};
      color: ${color.input.default.disabled.fg};
    }
    &[data-error]&:checked + span {
      background-color: ${color.input.invalid.enabled.muted.bg};
      color: ${color.input.default.enabled.bg};
    }
    &[data-error]&:checked&:not(:disabled):focus:focus-visible + span {
      box-shadow: ${focusRingStyle({
        border: {
            width: input.border.width,
            color: color.input.invalid.readOnly.muted.bg
        },
        focusRing: {
            width: 1,
            offset: 1
        }
    })};
    }

    &:disabled + span {
      background-color: ${color.input.default.disabled.bg};
      box-shadow: ${focusRingBorderStyle({
        width: input.border.width,
        color: color.input.default.disabled.border
    })};
      color: ${color.input.default.disabled.fg};
    }
    &:disabled&:checked + span {
      background-color: ${color.input.default.disabled.muted.bg};
    }

    &[data-read-only] + span {
      background-color: ${color.input.default.readOnly.bg};
      box-shadow: ${focusRingBorderStyle({
        width: input.border.width,
        color: color.input.default.readOnly.border
    })};
      color: ${color.input.default.readOnly.fg};
    }

    &[data-read-only]&:checked + span {
      background-color: ${color.input.default.readOnly.muted.bg};
    }

    &:checked + span > svg:first-child {
      opacity: 1;
    }
    &:indeterminate + span > svg:last-child {
      opacity: 1;
    }
  `;
}
const StyledCheckbox = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledCheckbox",
    componentId: "sc-1l5mt2l-0"
})(checkboxBaseStyles), Input$5 = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].input.withConfig({
    displayName: "Input",
    componentId: "sc-1l5mt2l-1"
})(inputElementStyles), Checkbox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(25);
    let checked, className, customValidity, disabled, indeterminate, readOnly, restProps, style;
    $[0] !== props ? ({ checked, className, disabled, indeterminate, customValidity, readOnly, style, ...restProps } = props, $[0] = props, $[1] = checked, $[2] = className, $[3] = customValidity, $[4] = disabled, $[5] = indeterminate, $[6] = readOnly, $[7] = restProps, $[8] = style) : (checked = $[1], className = $[2], customValidity = $[3], disabled = $[4], indeterminate = $[5], readOnly = $[6], restProps = $[7], style = $[8]);
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t0;
    $[9] === Symbol.for("react.memo_cache_sentinel") ? (t0 = ()=>ref.current, $[9] = t0) : t0 = $[9], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t0);
    let t1, t2;
    $[10] !== indeterminate ? (t1 = ()=>{
        ref.current && (ref.current.indeterminate = indeterminate || !1);
    }, t2 = [
        indeterminate
    ], $[10] = indeterminate, $[11] = t1, $[12] = t2) : (t1 = $[11], t2 = $[12]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2), useCustomValidity(ref, customValidity);
    const t3 = !disabled && readOnly ? "" : void 0, t4 = customValidity ? "" : void 0, t5 = disabled || readOnly;
    let t6;
    $[13] !== checked || $[14] !== readOnly || $[15] !== restProps || $[16] !== t3 || $[17] !== t4 || $[18] !== t5 ? (t6 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Input$5, {
        "data-read-only": t3,
        "data-error": t4,
        ...restProps,
        checked,
        disabled: t5,
        type: "checkbox",
        readOnly,
        ref
    }), $[13] = checked, $[14] = readOnly, $[15] = restProps, $[16] = t3, $[17] = t4, $[18] = t5, $[19] = t6) : t6 = $[19];
    let t7;
    $[20] === Symbol.for("react.memo_cache_sentinel") ? (t7 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("span", {
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CheckmarkIcon"], {}),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RemoveIcon"], {})
        ]
    }), $[20] = t7) : t7 = $[20];
    let t8;
    return $[21] !== className || $[22] !== style || $[23] !== t6 ? (t8 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(StyledCheckbox, {
        className,
        "data-ui": "Checkbox",
        style,
        children: [
            t6,
            t7
        ]
    }), $[21] = className, $[22] = style, $[23] = t6, $[24] = t8) : t8 = $[24], t8;
});
Checkbox.displayName = "ForwardRef(Checkbox)";
function codeSyntaxHighlightingStyle({ theme }) {
    const { color: { syntax: color } } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(theme);
    return {
        "&.atrule": {
            color: color.atrule
        },
        "&.attr-name": {
            color: color.attrName
        },
        "&.attr-value": {
            color: color.attrValue
        },
        "&.attribute": {
            color: color.attribute
        },
        "&.boolean": {
            color: color.boolean
        },
        "&.builtin": {
            color: color.builtin
        },
        "&.cdata": {
            color: color.cdata
        },
        "&.char": {
            color: color.char
        },
        "&.class": {
            color: color.class
        },
        "&.class-name": {
            color: color.className
        },
        "&.comment": {
            color: color.comment
        },
        "&.constant": {
            color: color.constant
        },
        "&.deleted": {
            color: color.deleted
        },
        "&.doctype": {
            color: color.doctype
        },
        "&.entity": {
            color: color.entity
        },
        "&.function": {
            color: color.function
        },
        "&.hexcode": {
            color: color.hexcode
        },
        "&.id": {
            color: color.id
        },
        "&.important": {
            color: color.important
        },
        "&.inserted": {
            color: color.inserted
        },
        "&.keyword": {
            color: color.keyword
        },
        "&.number": {
            color: color.number
        },
        "&.operator": {
            color: color.operator
        },
        "&.prolog": {
            color: color.prolog
        },
        "&.property": {
            color: color.property
        },
        "&.pseudo-class": {
            color: color.pseudoClass
        },
        "&.pseudo-element": {
            color: color.pseudoElement
        },
        "&.punctuation": {
            color: color.punctuation
        },
        "&.regex": {
            color: color.regex
        },
        "&.selector": {
            color: color.selector
        },
        "&.string": {
            color: color.string
        },
        "&.symbol": {
            color: color.symbol
        },
        "&.tag": {
            color: color.tag
        },
        "&.unit": {
            color: color.unit
        },
        "&.url": {
            color: color.url
        },
        "&.variable": {
            color: color.variable
        }
    };
}
function codeBaseStyle() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    color: var(--card-code-fg-color);

    & code {
      font-family: inherit;

      &.refractor .token {
        ${codeSyntaxHighlightingStyle}
      }
    }

    & a {
      color: inherit;
      text-decoration: underline;
      border-radius: 1px;
    }

    & svg {
      /* Certain popular CSS libraries changes the defaults for SVG display */
      /* Make sure SVGs are rendered as inline elements */
      display: inline;
    }

    & [data-sanity-icon] {
      vertical-align: baseline;
    }
  `;
}
const LazyRefractor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"])(()=>__turbopack_context__.A("[project]/node_modules/@sanity/ui/dist/_chunks-es/refractor.mjs [app-client] (ecmascript, async loader)")), StyledCode = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].pre.withConfig({
    displayName: "StyledCode",
    componentId: "sc-4dymyn-0"
})(codeBaseStyle, responsiveCodeFontStyle), Code = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    let children, language, restProps, t0, weight;
    $[0] !== props ? ({ children, language, size: t0, weight, ...restProps } = props, $[0] = props, $[1] = children, $[2] = language, $[3] = restProps, $[4] = t0, $[5] = weight) : (children = $[1], language = $[2], restProps = $[3], t0 = $[4], weight = $[5]);
    const size2 = t0 === void 0 ? 2 : t0;
    let t1;
    $[6] !== size2 ? (t1 = _getArrayProp(size2), $[6] = size2, $[7] = t1) : t1 = $[7];
    let t2;
    $[8] !== children ? (t2 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("code", {
        children
    }), $[8] = children, $[9] = t2) : t2 = $[9];
    let t3;
    $[10] !== children || $[11] !== language ? (t3 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LazyRefractor, {
        language,
        value: children
    }), $[10] = children, $[11] = language, $[12] = t3) : t3 = $[12];
    let t4;
    $[13] !== t2 || $[14] !== t3 ? (t4 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: t2,
        children: t3
    }), $[13] = t2, $[14] = t3, $[15] = t4) : t4 = $[15];
    let t5;
    return $[16] !== ref || $[17] !== restProps || $[18] !== t1 || $[19] !== t4 || $[20] !== weight ? (t5 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledCode, {
        "data-ui": "Code",
        ...restProps,
        $size: t1,
        $weight: weight,
        ref,
        children: t4
    }), $[16] = ref, $[17] = restProps, $[18] = t1, $[19] = t4, $[20] = weight, $[21] = t5) : t5 = $[21], t5;
});
Code.displayName = "ForwardRef(Code)";
const BASE_STYLE$1 = {
    width: "100%",
    margin: "0 auto"
};
function containerBaseStyle() {
    return BASE_STYLE$1;
}
function responsiveContainerWidthStyle(props) {
    const { container, media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$width, (val)=>({
            maxWidth: val === "auto" ? "none" : rem(container[val])
        }));
}
const StyledContainer = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Box).withConfig({
    displayName: "StyledContainer",
    componentId: "sc-wyroop-0"
})(containerBaseStyle, responsiveContainerWidthStyle), Container = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(11);
    let as, restProps, t0;
    $[0] !== props ? ({ as, width: t0, ...restProps } = props, $[0] = props, $[1] = as, $[2] = restProps, $[3] = t0) : (as = $[1], restProps = $[2], t0 = $[3]);
    const width = t0 === void 0 ? 2 : t0;
    let t1;
    $[4] !== width ? (t1 = _getArrayProp(width), $[4] = width, $[5] = t1) : t1 = $[5];
    let t2;
    return $[6] !== as || $[7] !== ref || $[8] !== restProps || $[9] !== t1 ? (t2 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledContainer, {
        "data-ui": "Container",
        ...restProps,
        $width: t1,
        forwardedAs: as,
        ref
    }), $[6] = as, $[7] = ref, $[8] = restProps, $[9] = t1, $[10] = t2) : t2 = $[10], t2;
});
Container.displayName = "ForwardRef(Container)";
const StyledGrid = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Box).withConfig({
    displayName: "StyledGrid",
    componentId: "sc-v8t8oz-0"
})(responsiveGridStyle), Grid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(44);
    let as, autoCols, autoFlow, autoRows, children, columns, gap, gapX, gapY, gridTemplateColumns, gridTemplateRows, restProps, rows;
    $[0] !== props ? ({ as, autoRows, autoCols, autoFlow, columns, gridTemplateColumns, gap, gapX, gapY, rows, gridTemplateRows, children, ...restProps } = props, $[0] = props, $[1] = as, $[2] = autoCols, $[3] = autoFlow, $[4] = autoRows, $[5] = children, $[6] = columns, $[7] = gap, $[8] = gapX, $[9] = gapY, $[10] = gridTemplateColumns, $[11] = gridTemplateRows, $[12] = restProps, $[13] = rows) : (as = $[1], autoCols = $[2], autoFlow = $[3], autoRows = $[4], children = $[5], columns = $[6], gap = $[7], gapX = $[8], gapY = $[9], gridTemplateColumns = $[10], gridTemplateRows = $[11], restProps = $[12], rows = $[13]);
    const t0 = typeof as == "string" ? as : void 0;
    let t1;
    $[14] !== autoRows ? (t1 = _getArrayProp(autoRows), $[14] = autoRows, $[15] = t1) : t1 = $[15];
    let t2;
    $[16] !== autoCols ? (t2 = _getArrayProp(autoCols), $[16] = autoCols, $[17] = t2) : t2 = $[17];
    let t3;
    $[18] !== autoFlow ? (t3 = _getArrayProp(autoFlow), $[18] = autoFlow, $[19] = t3) : t3 = $[19];
    const t4 = gridTemplateColumns === void 0 ? columns : gridTemplateColumns;
    let t5;
    $[20] !== t4 ? (t5 = _getArrayProp(t4), $[20] = t4, $[21] = t5) : t5 = $[21];
    let t6;
    $[22] !== gap ? (t6 = _getArrayProp(gap), $[22] = gap, $[23] = t6) : t6 = $[23];
    let t7;
    $[24] !== gapX ? (t7 = _getArrayProp(gapX), $[24] = gapX, $[25] = t7) : t7 = $[25];
    let t8;
    $[26] !== gapY ? (t8 = _getArrayProp(gapY), $[26] = gapY, $[27] = t8) : t8 = $[27];
    const t9 = gridTemplateRows === void 0 ? rows : gridTemplateRows;
    let t10;
    $[28] !== t9 ? (t10 = _getArrayProp(t9), $[28] = t9, $[29] = t10) : t10 = $[29];
    let t11;
    return $[30] !== as || $[31] !== children || $[32] !== ref || $[33] !== restProps || $[34] !== t0 || $[35] !== t1 || $[36] !== t10 || $[37] !== t2 || $[38] !== t3 || $[39] !== t5 || $[40] !== t6 || $[41] !== t7 || $[42] !== t8 ? (t11 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledGrid, {
        "data-as": t0,
        "data-ui": "Grid",
        ...restProps,
        $autoRows: t1,
        $autoCols: t2,
        $autoFlow: t3,
        $columns: t5,
        $gap: t6,
        $gapX: t7,
        $gapY: t8,
        $rows: t10,
        forwardedAs: as,
        ref,
        children
    }), $[30] = as, $[31] = children, $[32] = ref, $[33] = restProps, $[34] = t0, $[35] = t1, $[36] = t10, $[37] = t2, $[38] = t3, $[39] = t5, $[40] = t6, $[41] = t7, $[42] = t8, $[43] = t11) : t11 = $[43], t11;
});
Grid.displayName = "ForwardRef(Grid)";
function headingBaseStyle(props) {
    const { $accent, $muted } = props, { font } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    ${$accent && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
      color: var(--card-accent-fg-color);
    `}

    ${$muted && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
      color: var(--card-muted-fg-color);
    `}

    & code {
      font-family: ${font.code.family};
      border-radius: 1px;
    }

    & a {
      text-decoration: none;
      border-radius: 1px;
      color: var(--card-link-color);
      outline: none;

      @media (hover: hover) {
        &:hover {
          text-decoration: underline;
        }
      }

      &:focus {
        box-shadow:
          0 0 0 1px var(--card-bg-color),
          0 0 0 3px var(--card-focus-ring-color);
      }

      &:focus:not(:focus-visible) {
        box-shadow: none;
      }
    }

    & strong {
      font-weight: ${font.heading.weights.bold};
    }

    & svg {
      /* Certain popular CSS libraries changes the defaults for SVG display */
      /* Make sure SVGs are rendered as inline elements */
      display: inline;
    }

    & [data-sanity-icon] {
      vertical-align: baseline;
    }
  `;
}
const StyledHeading = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledHeading",
    componentId: "sc-137lwim-0"
})(headingBaseStyle, responsiveTextAlignStyle, responsiveHeadingFont), Heading = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(26);
    let align, childrenProp, restProps, t0, t1, t2, textOverflow, weight;
    $[0] !== props ? ({ accent: t0, align, children: childrenProp, muted: t1, size: t2, textOverflow, weight, ...restProps } = props, $[0] = props, $[1] = align, $[2] = childrenProp, $[3] = restProps, $[4] = t0, $[5] = t1, $[6] = t2, $[7] = textOverflow, $[8] = weight) : (align = $[1], childrenProp = $[2], restProps = $[3], t0 = $[4], t1 = $[5], t2 = $[6], textOverflow = $[7], weight = $[8]);
    const accent = t0 === void 0 ? !1 : t0, muted = t1 === void 0 ? !1 : t1, size2 = t2 === void 0 ? 2 : t2;
    let children = childrenProp;
    if (textOverflow === "ellipsis") {
        let t32;
        $[9] !== children ? (t32 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(SpanWithTextOverflow, {
            children
        }), $[9] = children, $[10] = t32) : t32 = $[10], children = t32;
    }
    let t3;
    $[11] !== align ? (t3 = _getArrayProp(align), $[11] = align, $[12] = t3) : t3 = $[12];
    let t4;
    $[13] !== size2 ? (t4 = _getArrayProp(size2), $[13] = size2, $[14] = t4) : t4 = $[14];
    let t5;
    $[15] !== children ? (t5 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
        children
    }), $[15] = children, $[16] = t5) : t5 = $[16];
    let t6;
    return $[17] !== accent || $[18] !== muted || $[19] !== ref || $[20] !== restProps || $[21] !== t3 || $[22] !== t4 || $[23] !== t5 || $[24] !== weight ? (t6 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledHeading, {
        "data-ui": "Heading",
        ...restProps,
        $accent: accent,
        $align: t3,
        $muted: muted,
        $size: t4,
        $weight: weight,
        ref,
        children: t5
    }), $[17] = accent, $[18] = muted, $[19] = ref, $[20] = restProps, $[21] = t3, $[22] = t4, $[23] = t5, $[24] = weight, $[25] = t6) : t6 = $[25], t6;
});
Heading.displayName = "ForwardRef(Heading)";
function inlineBaseStyle() {
    return {
        lineHeight: "0",
        "&&:not([hidden])": {
            display: "block"
        },
        "& > div": {
            display: "inline-block",
            verticalAlign: "middle"
        }
    };
}
function inlineSpaceStyle(props) {
    const { media, space } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$space, (spaceIndex)=>{
        const _space = rem(spaceIndex === 0.5 ? space[1] / 2 : space[spaceIndex]);
        return {
            margin: `-${_space} 0 0 -${_space}`,
            "& > div": {
                padding: `${_space} 0 0 ${_space}`
            }
        };
    });
}
const StyledInline = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Box).withConfig({
    displayName: "StyledInline",
    componentId: "sc-1pkiy6j-0"
})(inlineBaseStyle, inlineSpaceStyle), Inline = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    let as, childrenProp, deprecated_space, gap, restProps;
    $[0] !== props ? ({ as, children: childrenProp, gap, space: deprecated_space, ...restProps } = props, $[0] = props, $[1] = as, $[2] = childrenProp, $[3] = deprecated_space, $[4] = gap, $[5] = restProps) : (as = $[1], childrenProp = $[2], deprecated_space = $[3], gap = $[4], restProps = $[5]);
    const spacing = gap === void 0 ? deprecated_space : gap;
    let t0;
    $[6] !== childrenProp ? (t0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Children"].map(childrenProp, _temp$5), $[6] = childrenProp, $[7] = t0) : t0 = $[7];
    const children = t0;
    let t1;
    $[8] !== spacing ? (t1 = _getArrayProp(spacing), $[8] = spacing, $[9] = t1) : t1 = $[9];
    const t2 = ref;
    let t3;
    return $[10] !== as || $[11] !== children || $[12] !== restProps || $[13] !== t1 || $[14] !== t2 ? (t3 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledInline, {
        "data-ui": "Inline",
        ...restProps,
        $space: t1,
        forwardedAs: as,
        ref: t2,
        children
    }), $[10] = as, $[11] = children, $[12] = restProps, $[13] = t1, $[14] = t2, $[15] = t3) : t3 = $[15], t3;
});
Inline.displayName = "ForwardRef(Inline)";
function _temp$5(child) {
    return child && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        children: child
    });
}
function kbdStyle() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    --card-bg-color: var(--card-kbd-bg-color);
    --card-border-color: var(--card-kbd-border-color);
    --card-fg-color: var(--card-kbd-fg-color);

    box-shadow: inset 0 0 0 1px var(--card-border-color);
    background: var(--card-bg-color);
    font: inherit;

    vertical-align: top;

    &:not([hidden]) {
      display: inline-block;
    }
  `;
}
const StyledKBD = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].kbd.withConfig({
    displayName: "StyledKBD",
    componentId: "sc-1w7yd8w-0"
})(responsiveRadiusStyle, kbdStyle), KBD = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19);
    let children, restProps, t0, t1, t2;
    $[0] !== props ? ({ children, fontSize: t0, padding: t1, radius: t2, ...restProps } = props, $[0] = props, $[1] = children, $[2] = restProps, $[3] = t0, $[4] = t1, $[5] = t2) : (children = $[1], restProps = $[2], t0 = $[3], t1 = $[4], t2 = $[5]);
    const fontSize2 = t0 === void 0 ? 0 : t0, padding = t1 === void 0 ? 1 : t1, radius = t2 === void 0 ? 2 : t2;
    let t3;
    $[6] !== radius ? (t3 = _getArrayProp(radius), $[6] = radius, $[7] = t3) : t3 = $[7];
    let t4;
    $[8] !== children || $[9] !== fontSize2 ? (t4 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Text, {
        as: "span",
        size: fontSize2,
        weight: "semibold",
        children
    }), $[8] = children, $[9] = fontSize2, $[10] = t4) : t4 = $[10];
    let t5;
    $[11] !== padding || $[12] !== t4 ? (t5 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Box, {
        as: "span",
        padding,
        children: t4
    }), $[11] = padding, $[12] = t4, $[13] = t5) : t5 = $[13];
    let t6;
    return $[14] !== ref || $[15] !== restProps || $[16] !== t3 || $[17] !== t5 ? (t6 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledKBD, {
        "data-ui": "KBD",
        ...restProps,
        $radius: t3,
        ref,
        children: t5
    }), $[14] = ref, $[15] = restProps, $[16] = t3, $[17] = t5, $[18] = t6) : t6 = $[18], t6;
});
KBD.displayName = "ForwardRef(KBD)";
const origin = {
    name: "@sanity/ui/origin",
    fn ({ middlewareData, placement, rects }) {
        const [side] = placement.split("-"), floatingWidth = rects.floating.width, floatingHeight = rects.floating.height, shiftX = middlewareData.shift?.x || 0, shiftY = middlewareData.shift?.y || 0;
        if (floatingWidth <= 0 || floatingHeight <= 0) return {};
        const isVerticalPlacement = [
            "bottom",
            "top"
        ].includes(side), { originX, originY } = isVerticalPlacement ? {
            originX: clamp(0.5 - shiftX / floatingWidth, 0, 1),
            originY: side === "bottom" ? 0 : 1
        } : {
            originX: side === "left" ? 1 : 0,
            originY: clamp(0.5 - shiftY / floatingHeight, 0, 1)
        };
        return {
            data: {
                originX,
                originY
            }
        };
    }
};
function clamp(num, min, max) {
    return Math.min(Math.max(num, min), max);
}
function moveTowardsLength(movingPoint, targetPoint, amount) {
    const width = targetPoint.x - movingPoint.x, height = targetPoint.y - movingPoint.y, distance = Math.sqrt(width * width + height * height);
    return moveTowardsFractional(movingPoint, targetPoint, Math.min(1, amount / distance));
}
function moveTowardsFractional(movingPoint, targetPoint, fraction) {
    return {
        x: movingPoint.x + (targetPoint.x - movingPoint.x) * fraction,
        y: movingPoint.y + (targetPoint.y - movingPoint.y) * fraction
    };
}
function getRoundedCommands(points) {
    const len = points.length, cmds = [];
    for(let i = 0; i < len; i += 1){
        const point = points[i], prevPoint = points[i - 1], nextPoint = points[i + 1];
        if (prevPoint && point.radius) {
            const curveStart = moveTowardsLength(point, prevPoint, point.radius), curveEnd = moveTowardsLength(point, nextPoint, point.radius), startControl = moveTowardsFractional(curveStart, point, 0.5), endControl = moveTowardsFractional(point, curveEnd, 0.5);
            cmds.push({
                type: "point",
                ...curveStart
            }), cmds.push({
                type: "curve",
                curveEnd,
                startControl,
                endControl
            });
        } else cmds.push({
            type: "point",
            ...point
        });
    }
    return cmds;
}
function compileCommands(cmds) {
    return cmds.map((n, idx)=>n.type === "point" ? `${idx === 0 ? "M" : "L"} ${n.x} ${n.y}` : n.type === "curve" ? `C ${n.startControl.x} ${n.startControl.y} ${n.endControl.x} ${n.endControl.y} ${n.curveEnd.x} ${n.curveEnd.y}` : "").join(" ");
}
const StyledArrow = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledArrow",
    componentId: "sc-12vzy6c-0"
})(({ $w: w })=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    position: absolute;
    width: ${w}px;
    height: ${w}px;

    :empty + & {
      display: none;
    }

    & > svg {
      display: block;
      line-height: 0;
      transform-origin: ${w / 2}px ${w / 2}px;
    }

    [data-placement^='top'] > & {
      bottom: -${w}px;

      & > svg {
        transform: rotate(0);
      }
    }

    [data-placement^='right'] > & {
      left: -${w}px;

      & > svg {
        transform: rotate(90deg);
      }
    }

    [data-placement^='left'] > & {
      right: -${w}px;

      & > svg {
        transform: rotate(-90deg);
      }
    }

    [data-placement^='bottom'] > & {
      top: -${w}px;

      & > svg {
        transform: rotate(180deg);
      }
    }
  `), StrokePath = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].path.withConfig({
    displayName: "StrokePath",
    componentId: "sc-12vzy6c-1"
})`stroke:var(--card-shadow-outline-color);`, ShapePath = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].path.withConfig({
    displayName: "ShapePath",
    componentId: "sc-12vzy6c-2"
})`fill:var(--card-bg-color);`, Arrow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(29);
    let h, restProps, t0, w;
    $[0] !== props ? ({ width: w, height: h, radius: t0, ...restProps } = props, $[0] = props, $[1] = h, $[2] = restProps, $[3] = t0, $[4] = w) : (h = $[1], restProps = $[2], t0 = $[3], w = $[4]);
    const radius = t0 === void 0 ? 0 : t0, { card } = useTheme_v2(), strokeWidth = card.shadow.outline, center = w / 2;
    let t1;
    if ($[5] !== center || $[6] !== h || $[7] !== radius || $[8] !== w) {
        const points = [
            {
                x: 0,
                y: 0
            },
            {
                x: radius,
                y: 0,
                radius
            },
            {
                x: center,
                y: h - 1,
                radius
            },
            {
                x: w - radius,
                y: 0,
                radius
            },
            {
                x: w,
                y: 0
            }
        ], cmds = getRoundedCommands(points);
        t1 = compileCommands(cmds), $[5] = center, $[6] = h, $[7] = radius, $[8] = w, $[9] = t1;
    } else t1 = $[9];
    const path = t1, strokePath = `${path}`, fillPath = `${path} M ${w} -1 M 0 -1 Z`, t2 = `0 0 ${w} ${w}`;
    let t3;
    $[10] !== strokeWidth || $[11] !== w ? (t3 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("mask", {
        id: "stroke-mask",
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
            x: 0,
            y: strokeWidth,
            width: w,
            height: w,
            fill: "white"
        })
    }), $[10] = strokeWidth, $[11] = w, $[12] = t3) : t3 = $[12];
    const t4 = strokeWidth * 2;
    let t5;
    $[13] !== strokePath || $[14] !== t4 ? (t5 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StrokePath, {
        d: strokePath,
        mask: "url(#stroke-mask)",
        strokeWidth: t4
    }), $[13] = strokePath, $[14] = t4, $[15] = t5) : t5 = $[15];
    let t6;
    $[16] !== fillPath ? (t6 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ShapePath, {
        d: fillPath
    }), $[16] = fillPath, $[17] = t6) : t6 = $[17];
    let t7;
    $[18] !== t2 || $[19] !== t3 || $[20] !== t5 || $[21] !== t6 || $[22] !== w ? (t7 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        width: w,
        height: w,
        viewBox: t2,
        children: [
            t3,
            t5,
            t6
        ]
    }), $[18] = t2, $[19] = t3, $[20] = t5, $[21] = t6, $[22] = w, $[23] = t7) : t7 = $[23];
    let t8;
    return $[24] !== ref || $[25] !== restProps || $[26] !== t7 || $[27] !== w ? (t8 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledArrow, {
        ...restProps,
        $w: w,
        ref,
        children: t7
    }), $[24] = ref, $[25] = restProps, $[26] = t7, $[27] = w, $[28] = t8) : t8 = $[28], t8;
});
Arrow.displayName = "ForwardRef(Arrow)";
const BoundaryElementContext = createGlobalScopedContext("@sanity/ui/context/boundaryElement", null);
function BoundaryElementProvider(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5), { children, element } = props;
    let t0;
    $[0] !== element ? (t0 = {
        version: 0,
        element
    }, $[0] = element, $[1] = t0) : t0 = $[1];
    const value = t0;
    let t1;
    return $[2] !== children || $[3] !== value ? (t1 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(BoundaryElementContext.Provider, {
        value,
        children
    }), $[2] = children, $[3] = value, $[4] = t1) : t1 = $[4], t1;
}
BoundaryElementProvider.displayName = "BoundaryElementProvider";
function isRecord(value) {
    return !!(value && typeof value == "object" && !Array.isArray(value));
}
const DEFAULT_VALUE = {
    version: 0,
    element: null
};
function useBoundaryElement() {
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(BoundaryElementContext);
    if (value && (!isRecord(value) || value.version !== 0)) throw new Error("useBoundaryElement(): the context value is not compatible");
    return value || DEFAULT_VALUE;
}
function ConditionalWrapper({ children, condition, wrapper }) {
    return condition ? wrapper(children) : children;
}
ConditionalWrapper.displayName = "ConditionalWrapper";
function findMaxBreakpoints(media, width) {
    const ret = [];
    for(let i = 0; i < media.length; i += 1)media[i] > width && ret.push(i);
    return ret;
}
function findMinBreakpoints(media, width) {
    const ret = [];
    for(let i = 0; i < media.length; i += 1)media[i] <= width && ret.push(i);
    return ret;
}
const ElementQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(18), theme = useTheme_v2();
    let _media, children, restProps;
    $[0] !== props ? ({ children, media: _media, ...restProps } = props, $[0] = props, $[1] = _media, $[2] = children, $[3] = restProps) : (_media = $[1], children = $[2], restProps = $[3]);
    const media = _media ?? theme.media, [element, setElement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), width = useElementSize(element)?.border.width ?? window.innerWidth;
    let t0;
    if ($[4] !== media || $[5] !== width) {
        const eq = findMaxBreakpoints(media, width);
        t0 = eq.length ? eq.join(" ") : void 0, $[4] = media, $[5] = width, $[6] = t0;
    } else t0 = $[6];
    const max = t0;
    let t1;
    if ($[7] !== media || $[8] !== width) {
        const eq_0 = findMinBreakpoints(media, width);
        t1 = eq_0.length ? eq_0.join(" ") : void 0, $[7] = media, $[8] = width, $[9] = t1;
    } else t1 = $[9];
    const min = t1;
    let t2, t3;
    $[10] !== element ? (t2 = ()=>element, t3 = [
        element
    ], $[10] = element, $[11] = t2, $[12] = t3) : (t2 = $[11], t3 = $[12]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t2, t3);
    let t4;
    return $[13] !== children || $[14] !== max || $[15] !== min || $[16] !== restProps ? (t4 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        "data-ui": "ElementQuery",
        ...restProps,
        "data-eq-max": max,
        "data-eq-min": min,
        ref: setElement,
        children
    }), $[13] = children, $[14] = max, $[15] = min, $[16] = restProps, $[17] = t4) : t4 = $[17], t4;
});
ElementQuery.displayName = "ForwardRef(ElementQuery)";
function getLayerContext(contextValue) {
    if (!isRecord(contextValue) || contextValue.version !== 0) throw new Error("the context value is not compatible");
    if (!contextValue) throw new Error("components using `useLayer()` should be wrapped in a <LayerProvider>.");
    if (contextValue.version === 0) return contextValue;
    throw new Error("could not get layer context");
}
const LayerContext = createGlobalScopedContext("@sanity/ui/context/layer", null);
function LayerProvider(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(21), { children, zOffset: t0 } = props, zOffsetProp = t0 === void 0 ? 0 : t0, parentContextValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(LayerContext);
    let t1;
    $[0] !== parentContextValue ? (t1 = parentContextValue && getLayerContext(parentContextValue), $[0] = parentContextValue, $[1] = t1) : t1 = $[1];
    const parent = t1, parentRegisterChild = parent?.registerChild, level = (parent?.level ?? 0) + 1;
    let t2;
    $[2] !== zOffsetProp ? (t2 = _getArrayProp(zOffsetProp), $[2] = zOffsetProp, $[3] = t2) : t2 = $[3];
    const zOffset = t2, maxMediaIndex = zOffset.length - 1, mediaIndex = Math.min(useMediaIndex(), maxMediaIndex), zIndex = parent ? parent.zIndex + zOffset[mediaIndex] : zOffset[mediaIndex];
    let t3;
    $[4] === Symbol.for("react.memo_cache_sentinel") ? (t3 = {}, $[4] = t3) : t3 = $[4];
    const [, setChildLayers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t3), [size2, setSize] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0), isTopLayer = size2 === 0;
    let t4;
    $[5] !== parentRegisterChild || $[6] !== setChildLayers ? (t4 = (childLevel)=>{
        const parentDispose = parentRegisterChild?.(childLevel);
        return childLevel !== void 0 ? setChildLayers((state)=>{
            const prevLen = state[childLevel] ?? 0, nextState = {
                ...state,
                [childLevel]: prevLen + 1
            };
            return setSize(Object.keys(nextState).length), nextState;
        }) : setSize(_temp$4), ()=>{
            childLevel !== void 0 ? setChildLayers((state_0)=>{
                const nextState_0 = {
                    ...state_0
                };
                return nextState_0[childLevel] === 1 ? (delete nextState_0[childLevel], setSize(Object.keys(nextState_0).length)) : nextState_0[childLevel] = nextState_0[childLevel] - 1, nextState_0;
            }) : setSize(_temp2$2), parentDispose?.();
        };
    }, $[5] = parentRegisterChild, $[6] = setChildLayers, $[7] = t4) : t4 = $[7];
    const registerChild = t4;
    let t5, t6;
    $[8] !== level || $[9] !== parentRegisterChild ? (t5 = ()=>parentRegisterChild?.(level), t6 = [
        level,
        parentRegisterChild
    ], $[8] = level, $[9] = parentRegisterChild, $[10] = t5, $[11] = t6) : (t5 = $[10], t6 = $[11]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    let t7;
    $[12] !== isTopLayer || $[13] !== level || $[14] !== registerChild || $[15] !== size2 || $[16] !== zIndex ? (t7 = {
        version: 0,
        isTopLayer,
        level,
        registerChild,
        size: size2,
        zIndex
    }, $[12] = isTopLayer, $[13] = level, $[14] = registerChild, $[15] = size2, $[16] = zIndex, $[17] = t7) : t7 = $[17];
    const value = t7;
    let t8;
    return $[18] !== children || $[19] !== value ? (t8 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LayerContext.Provider, {
        value,
        children
    }), $[18] = children, $[19] = value, $[20] = t8) : t8 = $[20], t8;
}
function _temp2$2(v_0) {
    return v_0 - 1;
}
function _temp$4(v) {
    return v + 1;
}
LayerProvider.displayName = "LayerProvider";
function useLayer() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2), value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(LayerContext);
    if (!value) throw new Error("useLayer(): missing context value");
    try {
        let t1;
        return $[0] !== value ? (t1 = getLayerContext(value), $[0] = value, $[1] = t1) : t1 = $[1], t1;
    } catch (t0) {
        const err = t0;
        throw err instanceof Error ? new Error(`useLayer(): ${err.message}`) : new Error(`useLayer(): ${err}`);
    }
}
const StyledLayer = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledLayer",
    componentId: "sc-16kojrv-0"
})({
    position: "relative"
}), LayerChildren = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    let children, onActivate, onFocus, restProps, t0;
    $[0] !== props ? ({ children, onActivate, onFocus, style: t0, ...restProps } = props, $[0] = props, $[1] = children, $[2] = onActivate, $[3] = onFocus, $[4] = restProps, $[5] = t0) : (children = $[1], onActivate = $[2], onFocus = $[3], restProps = $[4], t0 = $[5]);
    const style = t0 === void 0 ? EMPTY_RECORD : t0, { zIndex, isTopLayer } = useLayer(), lastFocusedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), isTopLayerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(isTopLayer);
    let t1;
    $[6] === Symbol.for("react.memo_cache_sentinel") ? (t1 = ()=>ref.current, $[6] = t1) : t1 = $[6], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t1);
    let t2, t3;
    $[7] !== isTopLayer || $[8] !== onActivate ? (t2 = ()=>{
        isTopLayerRef.current !== isTopLayer && isTopLayer && onActivate?.({
            activeElement: lastFocusedRef.current
        }), isTopLayerRef.current = isTopLayer;
    }, t3 = [
        isTopLayer,
        onActivate
    ], $[7] = isTopLayer, $[8] = onActivate, $[9] = t2, $[10] = t3) : (t2 = $[9], t3 = $[10]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
    let t4;
    $[11] !== isTopLayer || $[12] !== onFocus ? (t4 = (event)=>{
        onFocus?.(event);
        const rootElement = ref.current, target = document.activeElement;
        !isTopLayer || !rootElement || !target || isHTMLElement(target) && containsOrEqualsElement(rootElement, target) && (lastFocusedRef.current = target);
    }, $[11] = isTopLayer, $[12] = onFocus, $[13] = t4) : t4 = $[13];
    const handleFocus = t4;
    let t5;
    $[14] !== style || $[15] !== zIndex ? (t5 = {
        ...style,
        zIndex
    }, $[14] = style, $[15] = zIndex, $[16] = t5) : t5 = $[16];
    let t6;
    return $[17] !== children || $[18] !== handleFocus || $[19] !== restProps || $[20] !== t5 ? (t6 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledLayer, {
        ...restProps,
        "data-ui": "Layer",
        onFocus: handleFocus,
        ref,
        style: t5,
        children
    }), $[17] = children, $[18] = handleFocus, $[19] = restProps, $[20] = t5, $[21] = t6) : t6 = $[21], t6;
}), Layer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(11);
    let children, restProps, t0;
    $[0] !== props ? ({ children, zOffset: t0, ...restProps } = props, $[0] = props, $[1] = children, $[2] = restProps, $[3] = t0) : (children = $[1], restProps = $[2], t0 = $[3]);
    const zOffset = t0 === void 0 ? 1 : t0;
    let t1;
    $[4] !== children || $[5] !== ref || $[6] !== restProps ? (t1 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LayerChildren, {
        ...restProps,
        ref,
        children
    }), $[4] = children, $[5] = ref, $[6] = restProps, $[7] = t1) : t1 = $[7];
    let t2;
    return $[8] !== t1 || $[9] !== zOffset ? (t2 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LayerProvider, {
        zOffset,
        children: t1
    }), $[8] = t1, $[9] = zOffset, $[10] = t2) : t2 = $[10], t2;
});
Layer.displayName = "ForwardRef(Layer)";
const key = "@sanity/ui/context/portal", elementKey = Symbol.for(`${key}/element`);
globalScope[elementKey] = null;
const defaultContextValue = {
    version: 0,
    boundaryElement: null,
    get element () {
        return typeof document > "u" ? null : (globalScope[elementKey] || (globalScope[elementKey] = document.createElement("div"), globalScope[elementKey].setAttribute("data-portal", ""), document.body.appendChild(globalScope[elementKey])), globalScope[elementKey]);
    }
}, PortalContext = createGlobalScopedContext(key, defaultContextValue);
function usePortal() {
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(PortalContext);
    if (!value) throw new Error("usePortal(): missing context value");
    if (!isRecord(value) || value.version !== 0) throw new Error("usePortal(): the context value is not compatible");
    return value;
}
function Portal(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3), { children, __unstable_name: name } = props, portal = usePortal(), portalElement = (name ? portal.elements && portal.elements[name] : portal.element) || portal.elements?.default;
    if (!portalElement) return null;
    let t0;
    return $[0] !== children || $[1] !== portalElement ? (t0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(children, portalElement), $[0] = children, $[1] = portalElement, $[2] = t0) : t0 = $[2], t0;
}
Portal.displayName = "Portal";
function PortalProvider(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7), { boundaryElement, children, element, __unstable_elements: elements } = props, fallbackElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(emptySubscribe, _temp$3, _temp2$1), t0 = boundaryElement || null, t1 = element || fallbackElement;
    let t2;
    $[0] !== elements || $[1] !== t0 || $[2] !== t1 ? (t2 = {
        version: 0,
        boundaryElement: t0,
        element: t1,
        elements
    }, $[0] = elements, $[1] = t0, $[2] = t1, $[3] = t2) : t2 = $[3];
    const value = t2;
    let t3;
    return $[4] !== children || $[5] !== value ? (t3 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(PortalContext.Provider, {
        value,
        children
    }), $[4] = children, $[5] = value, $[6] = t3) : t3 = $[6], t3;
}
function _temp2$1() {
    return null;
}
function _temp$3() {
    return document.body;
}
PortalProvider.displayName = "PortalProvider";
const emptySubscribe = ()=>()=>{}, StyledSrOnly = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledSrOnly",
    componentId: "sc-mubr0c-0"
})`display:block;width:0;height:0;position:absolute;overflow:hidden;overflow:clip;`, SrOnly = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4), { as, children } = props;
    let t0;
    return $[0] !== as || $[1] !== children || $[2] !== ref ? (t0 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledSrOnly, {
        "aria-hidden": !0,
        as,
        "data-ui": "SrOnly",
        ref,
        children
    }), $[0] = as, $[1] = children, $[2] = ref, $[3] = t0) : t0 = $[3], t0;
});
SrOnly.displayName = "ForwardRef(SrOnly)";
const StyledVirtualList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledVirtualList",
    componentId: "sc-dlqsj4-0"
})`position:relative;`, ItemWrapper = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "ItemWrapper",
    componentId: "sc-dlqsj4-1"
})`position:absolute;left:0;right:0;`, VirtualList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(44);
    let getItemKey, onChange, renderItem, restProps, t0, t1, t2;
    $[0] !== props ? ({ as: t0, gap: t1, getItemKey, items: t2, onChange, renderItem, ...restProps } = props, $[0] = props, $[1] = getItemKey, $[2] = onChange, $[3] = renderItem, $[4] = restProps, $[5] = t0, $[6] = t1, $[7] = t2) : (getItemKey = $[1], onChange = $[2], renderItem = $[3], restProps = $[4], t0 = $[5], t1 = $[6], t2 = $[7]);
    const as = t0 === void 0 ? "div" : t0, gap = t1 === void 0 ? 0 : t1;
    let t3;
    $[8] !== t2 ? (t3 = t2 === void 0 ? [] : t2, $[8] = t2, $[9] = t3) : t3 = $[9];
    const items = t3, { space } = useTheme_v2(), ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), wrapperRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [scrollTop, setScrollTop] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0), [scrollHeight, setScrollHeight] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0), [itemHeight, setItemHeight] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    let t4;
    $[10] === Symbol.for("react.memo_cache_sentinel") ? (t4 = ()=>ref.current, $[10] = t4) : t4 = $[10], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t4);
    let t5;
    $[11] === Symbol.for("react.memo_cache_sentinel") ? (t5 = ()=>{
        if (!wrapperRef.current) return;
        const firstElement = wrapperRef.current.firstChild;
        firstElement instanceof HTMLElement && setItemHeight(firstElement.offsetHeight);
    }, $[11] = t5) : t5 = $[11];
    let t6;
    $[12] !== renderItem ? (t6 = [
        renderItem
    ], $[12] = renderItem, $[13] = t6) : t6 = $[13], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    let t7, t8;
    $[14] === Symbol.for("react.memo_cache_sentinel") ? (t7 = ()=>{
        if (!ref.current) return;
        const scrollEl = findScrollable(ref.current.parentNode);
        if (scrollEl) {
            if (!(scrollEl instanceof HTMLElement)) return;
            const handleScroll = ()=>{
                setScrollTop(scrollEl.scrollTop);
            };
            scrollEl.addEventListener("scroll", handleScroll, {
                passive: !0
            });
            const ro = new _ResizeObserver((entries)=>{
                setScrollHeight(entries[0].contentRect.height);
            });
            return ro.observe(scrollEl), handleScroll(), ()=>{
                scrollEl.removeEventListener("scroll", handleScroll), ro.unobserve(scrollEl), ro.disconnect();
            };
        }
        const handleScroll_0 = ()=>{
            setScrollTop(window.scrollY);
        }, handleResize = ()=>{
            setScrollHeight(window.innerHeight);
        };
        return window.addEventListener("scroll", handleScroll_0, {
            passive: !0
        }), window.addEventListener("resize", handleResize), setScrollHeight(window.innerHeight), handleScroll_0(), ()=>{
            window.removeEventListener("scroll", handleScroll_0), window.removeEventListener("resize", handleResize);
        };
    }, t8 = [], $[14] = t7, $[15] = t8) : (t7 = $[14], t8 = $[15]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t7, t8);
    const len = items.length, height = itemHeight ? len * (itemHeight + space[gap]) - space[gap] : 0, fromIndex = height ? Math.max(Math.floor(scrollTop / height * len) - 2, 0) : 0, toIndex = height ? Math.ceil((scrollTop + scrollHeight) / height * len) + 1 : 0;
    let t10, t9;
    $[16] !== fromIndex || $[17] !== gap || $[18] !== itemHeight || $[19] !== onChange || $[20] !== scrollHeight || $[21] !== scrollTop || $[22] !== space || $[23] !== toIndex ? (t9 = ()=>{
        onChange && onChange({
            fromIndex,
            gap: space[gap],
            itemHeight,
            scrollHeight,
            scrollTop,
            toIndex
        });
    }, t10 = [
        fromIndex,
        gap,
        itemHeight,
        onChange,
        scrollHeight,
        scrollTop,
        space,
        toIndex
    ], $[16] = fromIndex, $[17] = gap, $[18] = itemHeight, $[19] = onChange, $[20] = scrollHeight, $[21] = scrollTop, $[22] = space, $[23] = toIndex, $[24] = t10, $[25] = t9) : (t10 = $[24], t9 = $[25]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t9, t10);
    let t11;
    $[26] !== fromIndex || $[27] !== gap || $[28] !== getItemKey || $[29] !== itemHeight || $[30] !== items || $[31] !== renderItem || $[32] !== space || $[33] !== toIndex ? (t11 = {
        fromIndex,
        gap,
        itemHeight,
        space,
        toIndex,
        getItemKey,
        items,
        renderItem
    }, $[26] = fromIndex, $[27] = gap, $[28] = getItemKey, $[29] = itemHeight, $[30] = items, $[31] = renderItem, $[32] = space, $[33] = toIndex, $[34] = t11) : t11 = $[34];
    const children = useChildren(t11);
    let t12;
    $[35] !== height ? (t12 = {
        height
    }, $[35] = height, $[36] = t12) : t12 = $[36];
    let t13;
    $[37] !== children || $[38] !== t12 ? (t13 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        ref: wrapperRef,
        style: t12,
        children
    }), $[37] = children, $[38] = t12, $[39] = t13) : t13 = $[39];
    let t14;
    return $[40] !== as || $[41] !== restProps || $[42] !== t13 ? (t14 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledVirtualList, {
        as,
        "data-ui": "VirtualList",
        ...restProps,
        ref,
        children: t13
    }), $[40] = as, $[41] = restProps, $[42] = t13, $[43] = t14) : t14 = $[43], t14;
});
VirtualList.displayName = "ForwardRef(VirtualList)";
function useChildren(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(21), { fromIndex, gap, getItemKey, itemHeight, items, renderItem, space, toIndex } = t0;
    if (!renderItem || items.length === 0) return null;
    if (itemHeight === -1) {
        let t12;
        $[0] !== items[0] || $[1] !== renderItem ? (t12 = renderItem(items[0]), $[0] = items[0], $[1] = renderItem, $[2] = t12) : t12 = $[2];
        let t2;
        return $[3] !== t12 ? (t2 = [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ItemWrapper, {
                children: t12
            }, 0)
        ], $[3] = t12, $[4] = t2) : t2 = $[4], t2;
    }
    let t1;
    if ($[5] !== fromIndex || $[6] !== gap || $[7] !== getItemKey || $[8] !== itemHeight || $[9] !== items || $[10] !== renderItem || $[11] !== space || $[12] !== toIndex) {
        let t2;
        $[14] !== fromIndex || $[15] !== gap || $[16] !== getItemKey || $[17] !== itemHeight || $[18] !== renderItem || $[19] !== space ? (t2 = (item, _itemIndex)=>{
            const itemIndex = fromIndex + _itemIndex, node = renderItem(item), key2 = getItemKey ? getItemKey(item, itemIndex) : itemIndex;
            return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ItemWrapper, {
                style: {
                    top: itemIndex * (itemHeight + space[gap])
                },
                children: node
            }, key2);
        }, $[14] = fromIndex, $[15] = gap, $[16] = getItemKey, $[17] = itemHeight, $[18] = renderItem, $[19] = space, $[20] = t2) : t2 = $[20], t1 = items.slice(fromIndex, toIndex).map(t2), $[5] = fromIndex, $[6] = gap, $[7] = getItemKey, $[8] = itemHeight, $[9] = items, $[10] = renderItem, $[11] = space, $[12] = toIndex, $[13] = t1;
    } else t1 = $[13];
    return t1;
}
function findScrollable(parentNode) {
    let _scrollEl = parentNode;
    for(; _scrollEl && !_isScrollable(_scrollEl);)_scrollEl = _scrollEl.parentNode;
    return _scrollEl;
}
function getElementRef(element) {
    let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get, mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
    return mayWarn ? element.ref : (getter = Object.getOwnPropertyDescriptor(element, "ref")?.get, mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning, mayWarn ? element.props.ref : element.props.ref || element.ref);
}
const DEFAULT_POPOVER_DISTANCE = 4, DEFAULT_POPOVER_PADDING = 4, DEFAULT_POPOVER_ARROW_WIDTH = 19, DEFAULT_POPOVER_ARROW_HEIGHT = 8, DEFAULT_POPOVER_ARROW_RADIUS = 2, DEFAULT_POPOVER_MARGINS = [
    0,
    0,
    0,
    0
], DEFAULT_FALLBACK_PLACEMENTS$1 = {
    top: [
        "bottom",
        "left",
        "right"
    ],
    "top-start": [
        "bottom-start",
        "left-start",
        "right-start"
    ],
    "top-end": [
        "bottom-end",
        "left-end",
        "right-end"
    ],
    bottom: [
        "top",
        "left",
        "right"
    ],
    "bottom-start": [
        "top-start",
        "left-start",
        "right-start"
    ],
    "bottom-end": [
        "top-end",
        "left-end",
        "right-end"
    ],
    left: [
        "right",
        "top",
        "bottom"
    ],
    "left-start": [
        "right-start",
        "top-start",
        "bottom-start"
    ],
    "left-end": [
        "right-end",
        "top-end",
        "bottom-end"
    ],
    right: [
        "left",
        "top",
        "bottom"
    ],
    "right-start": [
        "left-start",
        "top-start",
        "bottom-start"
    ],
    "right-end": [
        "left-end",
        "top-end",
        "bottom-end"
    ]
};
function size(options) {
    const { constrainSize, margins, matchReferenceWidth, maxWidthRef, padding = 0, referenceWidthRef, setReferenceWidth, widthRef } = options;
    return {
        name: "@sanity/ui/size",
        async fn (args) {
            const { elements, placement, platform, rects } = args, { floating, reference } = rects, overflow = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["detectOverflow"])(args, {
                altBoundary: !0,
                boundary: options.boundaryElement || void 0,
                elementContext: "floating",
                padding,
                rootBoundary: "viewport"
            });
            let maxWidth = 1 / 0, maxHeight = 1 / 0;
            const floatingW = floating.width, floatingH = floating.height;
            placement.includes("top") && (maxWidth = floatingW - (overflow.left + overflow.right), maxHeight = floatingH - overflow.top), placement.includes("right") && (maxWidth = floatingW - overflow.right, maxHeight = floatingH - (overflow.top + overflow.bottom)), placement.includes("bottom") && (maxWidth = floatingW - (overflow.left + overflow.right), maxHeight = floatingH - overflow.bottom), placement.includes("left") && (maxWidth = floatingW - overflow.left, maxHeight = floatingH - (overflow.top + overflow.bottom));
            const availableWidth = maxWidth - margins[1] - margins[3], availableHeight = maxHeight - margins[0] - margins[2], referenceWidth = reference.width - margins[1] - margins[3];
            referenceWidthRef.current = referenceWidth, setReferenceWidth(referenceWidth), matchReferenceWidth ? elements.floating.style.width = `${referenceWidth}px` : widthRef.current !== void 0 && (elements.floating.style.width = `${widthRef.current}px`), constrainSize && (elements.floating.style.maxWidth = `${Math.min(availableWidth, maxWidthRef.current ?? 1 / 0)}px`, elements.floating.style.maxHeight = `${availableHeight}px`);
            const nextDimensions = await platform.getDimensions(elements.floating), targetH = nextDimensions.height, targetW = nextDimensions.width;
            return floatingW !== targetW || floatingH !== targetH ? {
                reset: {
                    rects: !0
                }
            } : {};
        }
    };
}
function calcCurrentWidth(params) {
    const { container, mediaIndex, width } = params, w = width[mediaIndex], currentWidth = w === void 0 ? width[width.length - 1] : w;
    return typeof currentWidth == "number" ? container[currentWidth] : void 0;
}
function calcMaxWidth(params) {
    const { boundaryWidth, currentWidth } = params;
    if (!(currentWidth === void 0 && boundaryWidth === void 0)) return Math.min(currentWidth ?? 1 / 0, (boundaryWidth || 1 / 0) - DEFAULT_POPOVER_PADDING * 2);
}
const MotionCard$1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].create(Card)).withConfig({
    displayName: "MotionCard",
    componentId: "sc-ihg31s-0"
})`&:not([hidden]){display:flex;}flex-direction:column;width:max-content;min-width:min-content;will-change:transform;`, MotionFlex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].create(Flex)).withConfig({
    displayName: "MotionFlex",
    componentId: "sc-ihg31s-1"
})`will-change:opacity;`, PopoverCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(66);
    let animate, arrow2, arrowRef, arrowX, arrowY, children, marginsProp, originX, originY, overflow, padding, placement, radius, restProps, scheme, shadow, strategy, style, tone, width, xProp, yProp;
    $[0] !== props ? ({ __unstable_margins: marginsProp, animate, arrow: arrow2, arrowRef, arrowX, arrowY, children, padding, placement, originX, originY, overflow, radius, scheme, shadow, strategy, style, tone, width, x: xProp, y: yProp, ...restProps } = props, $[0] = props, $[1] = animate, $[2] = arrow2, $[3] = arrowRef, $[4] = arrowX, $[5] = arrowY, $[6] = children, $[7] = marginsProp, $[8] = originX, $[9] = originY, $[10] = overflow, $[11] = padding, $[12] = placement, $[13] = radius, $[14] = restProps, $[15] = scheme, $[16] = shadow, $[17] = strategy, $[18] = style, $[19] = tone, $[20] = width, $[21] = xProp, $[22] = yProp) : (animate = $[1], arrow2 = $[2], arrowRef = $[3], arrowX = $[4], arrowY = $[5], children = $[6], marginsProp = $[7], originX = $[8], originY = $[9], overflow = $[10], padding = $[11], placement = $[12], radius = $[13], restProps = $[14], scheme = $[15], shadow = $[16], strategy = $[17], style = $[18], tone = $[19], width = $[20], xProp = $[21], yProp = $[22]);
    const { zIndex } = useLayer(), margins = marginsProp || DEFAULT_POPOVER_MARGINS, x = (xProp ?? 0) + margins[3], y = (yProp ?? 0) + margins[0], t0 = animate ? "transform" : void 0;
    let t1;
    $[23] !== originX || $[24] !== originY || $[25] !== strategy || $[26] !== style || $[27] !== t0 || $[28] !== width || $[29] !== x || $[30] !== y || $[31] !== zIndex ? (t1 = {
        left: x,
        originX,
        originY,
        position: strategy,
        top: y,
        width,
        zIndex,
        willChange: t0,
        ...style
    }, $[23] = originX, $[24] = originY, $[25] = strategy, $[26] = style, $[27] = t0, $[28] = width, $[29] = x, $[30] = y, $[31] = zIndex, $[32] = t1) : t1 = $[32];
    const rootStyle2 = t1, t2 = arrowX !== null ? arrowX : void 0, t3 = arrowY !== null ? arrowY : void 0;
    let t4;
    $[33] !== t2 || $[34] !== t3 ? (t4 = {
        left: t2,
        top: t3,
        right: void 0,
        bottom: void 0
    }, $[33] = t2, $[34] = t3, $[35] = t4) : t4 = $[35];
    const arrowStyle = t4, t5 = restProps;
    let t6;
    $[36] !== animate ? (t6 = animate ? [
        "hidden",
        "initial"
    ] : void 0, $[36] = animate, $[37] = t6) : t6 = $[37];
    let t7;
    $[38] !== animate ? (t7 = animate ? [
        "visible",
        "scaleIn"
    ] : void 0, $[38] = animate, $[39] = t7) : t7 = $[39];
    let t8;
    $[40] !== animate ? (t8 = animate ? [
        "hidden",
        "scaleOut"
    ] : void 0, $[40] = animate, $[41] = t8) : t8 = $[41];
    let t9;
    $[42] !== children || $[43] !== padding ? (t9 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Flex, {
        direction: "column",
        flex: 1,
        padding,
        children
    }), $[42] = children, $[43] = padding, $[44] = t9) : t9 = $[44];
    let t10;
    $[45] !== overflow || $[46] !== t9 ? (t10 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(MotionFlex, {
        "data-ui": "Popover__wrapper",
        direction: "column",
        flex: 1,
        overflow,
        variants: POPOVER_MOTION_PROPS.children,
        transition: POPOVER_MOTION_PROPS.transition,
        children: t9
    }), $[45] = overflow, $[46] = t9, $[47] = t10) : t10 = $[47];
    let t11;
    $[48] !== arrow2 || $[49] !== arrowRef || $[50] !== arrowStyle ? (t11 = arrow2 && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Arrow, {
        ref: arrowRef,
        style: arrowStyle,
        width: DEFAULT_POPOVER_ARROW_WIDTH,
        height: DEFAULT_POPOVER_ARROW_HEIGHT,
        radius: DEFAULT_POPOVER_ARROW_RADIUS
    }), $[48] = arrow2, $[49] = arrowRef, $[50] = arrowStyle, $[51] = t11) : t11 = $[51];
    let t12;
    return $[52] !== placement || $[53] !== radius || $[54] !== ref || $[55] !== rootStyle2 || $[56] !== scheme || $[57] !== shadow || $[58] !== t10 || $[59] !== t11 || $[60] !== t5 || $[61] !== t6 || $[62] !== t7 || $[63] !== t8 || $[64] !== tone ? (t12 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(MotionCard$1, {
        "data-ui": "Popover",
        ...t5,
        "data-placement": placement,
        radius,
        ref,
        scheme,
        shadow,
        sizing: "border",
        style: rootStyle2,
        tone,
        variants: POPOVER_MOTION_PROPS.card,
        transition: POPOVER_MOTION_PROPS.transition,
        initial: t6,
        animate: t7,
        exit: t8,
        children: [
            t10,
            t11
        ]
    }), $[52] = placement, $[53] = radius, $[54] = ref, $[55] = rootStyle2, $[56] = scheme, $[57] = shadow, $[58] = t10, $[59] = t11, $[60] = t5, $[61] = t6, $[62] = t7, $[63] = t8, $[64] = tone, $[65] = t12) : t12 = $[65], t12;
});
PopoverCard.displayName = "ForwardRef(PopoverCard)";
const ViewportOverlay = ()=>{
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2), { zIndex } = useLayer();
    let t0;
    return $[0] !== zIndex ? (t0 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        style: {
            height: "100vh",
            inset: 0,
            position: "fixed",
            width: "100vw",
            zIndex
        }
    }), $[0] = zIndex, $[1] = t0) : t0 = $[1], t0;
}, Popover = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(126), { container, layer } = useTheme_v2(), boundaryElementContext = useBoundaryElement();
    let _boundaryElement, _fallbackPlacements, _floatingBoundary, _referenceBoundary, _zOffsetProp, childProp, content, disabled, matchReferenceWidth, modal, open, paddingProp, portal, referenceElement, restProps, scheme, t0, t1, t10, t11, t2, t3, t4, t5, t6, t7, t8, t9, updateRef;
    if ($[0] !== props) {
        const { __unstable_margins: t122, animate: t132, arrow: t142, boundaryElement: t152, children: t162, constrainSize: t172, content: t182, disabled: t192, fallbackPlacements: t202, matchReferenceWidth: t212, floatingBoundary: t222, modal: t232, onActivate, open: t242, overflow: t252, padding: t262, placement: t272, placementStrategy: t282, portal: t292, preventOverflow: t302, radius: t312, referenceBoundary: t322, referenceElement: t332, scheme: t342, shadow: t352, tone: t362, width: t372, zOffset: t382, updateRef: t392, ...t402 } = props;
        t0 = t122, t1 = t132, t2 = t142, _boundaryElement = t152, childProp = t162, t3 = t172, content = t182, disabled = t192, _fallbackPlacements = t202, matchReferenceWidth = t212, _floatingBoundary = t222, modal = t232, open = t242, t4 = t252, paddingProp = t262, t5 = t272, t6 = t282, portal = t292, t7 = t302, t8 = t312, _referenceBoundary = t322, referenceElement = t332, scheme = t342, t9 = t352, t10 = t362, t11 = t372, _zOffsetProp = t382, updateRef = t392, restProps = t402, $[0] = props, $[1] = _boundaryElement, $[2] = _fallbackPlacements, $[3] = _floatingBoundary, $[4] = _referenceBoundary, $[5] = _zOffsetProp, $[6] = childProp, $[7] = content, $[8] = disabled, $[9] = matchReferenceWidth, $[10] = modal, $[11] = open, $[12] = paddingProp, $[13] = portal, $[14] = referenceElement, $[15] = restProps, $[16] = scheme, $[17] = t0, $[18] = t1, $[19] = t10, $[20] = t11, $[21] = t2, $[22] = t3, $[23] = t4, $[24] = t5, $[25] = t6, $[26] = t7, $[27] = t8, $[28] = t9, $[29] = updateRef;
    } else _boundaryElement = $[1], _fallbackPlacements = $[2], _floatingBoundary = $[3], _referenceBoundary = $[4], _zOffsetProp = $[5], childProp = $[6], content = $[7], disabled = $[8], matchReferenceWidth = $[9], modal = $[10], open = $[11], paddingProp = $[12], portal = $[13], referenceElement = $[14], restProps = $[15], scheme = $[16], t0 = $[17], t1 = $[18], t10 = $[19], t11 = $[20], t2 = $[21], t3 = $[22], t4 = $[23], t5 = $[24], t6 = $[25], t7 = $[26], t8 = $[27], t9 = $[28], updateRef = $[29];
    const margins = t0 === void 0 ? DEFAULT_POPOVER_MARGINS : t0, _animate = t1 === void 0 ? !1 : t1, arrowProp = t2 === void 0 ? !1 : t2, constrainSize = t3 === void 0 ? !1 : t3, overflow = t4 === void 0 ? "hidden" : t4, placementProp = t5 === void 0 ? "bottom" : t5, placementStrategy = t6 === void 0 ? "flip" : t6, preventOverflow = t7 === void 0 ? !0 : t7, radiusProp = t8 === void 0 ? 3 : t8, shadowProp = t9 === void 0 ? 3 : t9, tone = t10 === void 0 ? "inherit" : t10, widthProp = t11 === void 0 ? "auto" : t11, boundaryElement = _boundaryElement ?? boundaryElementContext?.element, fallbackPlacements = _fallbackPlacements ?? DEFAULT_FALLBACK_PLACEMENTS$1[props.placement ?? "bottom"], floatingBoundary = _floatingBoundary ?? props.boundaryElement ?? boundaryElementContext.element, referenceBoundary = _referenceBoundary ?? props.boundaryElement ?? boundaryElementContext.element, zOffsetProp = _zOffsetProp ?? layer.popover.zOffset, animate = usePrefersReducedMotion() ? !1 : _animate, boundarySize = useElementSize(boundaryElement)?.border;
    let t12;
    $[30] !== paddingProp ? (t12 = _getArrayProp(paddingProp), $[30] = paddingProp, $[31] = t12) : t12 = $[31];
    const padding = t12;
    let t13;
    $[32] !== radiusProp ? (t13 = _getArrayProp(radiusProp), $[32] = radiusProp, $[33] = t13) : t13 = $[33];
    const radius = t13;
    let t14;
    $[34] !== shadowProp ? (t14 = _getArrayProp(shadowProp), $[34] = shadowProp, $[35] = t14) : t14 = $[35];
    const shadow = t14, widthArrayProp = _getArrayProp(widthProp);
    let t15;
    $[36] !== zOffsetProp ? (t15 = _getArrayProp(zOffsetProp), $[36] = zOffsetProp, $[37] = t15) : t15 = $[37];
    const zOffset = t15, ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), arrowRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t16;
    $[38] === Symbol.for("react.memo_cache_sentinel") ? (t16 = ()=>ref.current, $[38] = t16) : t16 = $[38], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t16);
    const mediaIndex = useMediaIndex(), boundaryWidth = constrainSize || preventOverflow ? boundarySize?.width : void 0, width = calcCurrentWidth({
        container,
        mediaIndex,
        width: widthArrayProp
    }), widthRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(width);
    let t17, t18;
    $[39] !== width ? (t17 = ()=>{
        widthRef.current = width;
    }, t18 = [
        width
    ], $[39] = width, $[40] = t17, $[41] = t18) : (t17 = $[40], t18 = $[41]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t17, t18);
    let t19;
    $[42] !== boundaryWidth || $[43] !== width ? (t19 = calcMaxWidth({
        boundaryWidth,
        currentWidth: width
    }), $[42] = boundaryWidth, $[43] = width, $[44] = t19) : t19 = $[44];
    const maxWidth = t19, maxWidthRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(maxWidth);
    let t20, t21;
    $[45] !== maxWidth ? (t20 = ()=>{
        maxWidthRef.current = maxWidth;
    }, t21 = [
        maxWidth
    ], $[45] = maxWidth, $[46] = t20, $[47] = t21) : (t20 = $[46], t21 = $[47]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t20, t21);
    const referenceWidthRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(void 0);
    let t22, t23;
    $[48] !== matchReferenceWidth || $[49] !== maxWidth || $[50] !== open || $[51] !== width ? (t22 = ()=>{
        const floatingElement = ref.current;
        if (!open || !floatingElement) return;
        const referenceWidth = referenceWidthRef.current;
        matchReferenceWidth ? referenceWidth !== void 0 && (floatingElement.style.width = `${referenceWidth}px`) : width !== void 0 && (floatingElement.style.width = `${width}px`), typeof maxWidth == "number" && (floatingElement.style.maxWidth = `${maxWidth}px`);
    }, t23 = [
        width,
        matchReferenceWidth,
        maxWidth,
        open
    ], $[48] = matchReferenceWidth, $[49] = maxWidth, $[50] = open, $[51] = width, $[52] = t22, $[53] = t23) : (t22 = $[52], t23 = $[53]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t22, t23);
    const [referenceWidth_0, setReferenceWidth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(void 0);
    let t24;
    $[54] !== animate || $[55] !== arrowProp || $[56] !== constrainSize || $[57] !== fallbackPlacements || $[58] !== floatingBoundary || $[59] !== margins || $[60] !== matchReferenceWidth || $[61] !== placementProp || $[62] !== placementStrategy || $[63] !== preventOverflow || $[64] !== referenceBoundary ? (t24 = {
        animate,
        arrowProp,
        arrowRef,
        constrainSize,
        fallbackPlacements,
        floatingBoundary,
        margins,
        matchReferenceWidth,
        maxWidthRef,
        placementProp,
        placementStrategy,
        preventOverflow,
        referenceBoundary,
        referenceWidthRef,
        rootBoundary: "viewport",
        setReferenceWidth,
        widthRef
    }, $[54] = animate, $[55] = arrowProp, $[56] = constrainSize, $[57] = fallbackPlacements, $[58] = floatingBoundary, $[59] = margins, $[60] = matchReferenceWidth, $[61] = placementProp, $[62] = placementStrategy, $[63] = preventOverflow, $[64] = referenceBoundary, $[65] = t24) : t24 = $[65];
    const middleware = useMiddleware$1(t24);
    let t25;
    $[66] !== referenceElement ? (t25 = referenceElement ? {
        reference: referenceElement
    } : void 0, $[66] = referenceElement, $[67] = t25) : t25 = $[67];
    let t26;
    $[68] !== middleware || $[69] !== placementProp || $[70] !== t25 ? (t26 = {
        middleware,
        placement: placementProp,
        whileElementsMounted: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["autoUpdate"],
        elements: t25
    }, $[68] = middleware, $[69] = placementProp, $[70] = t25, $[71] = t26) : t26 = $[71];
    const { x, y, middlewareData, placement, refs, strategy, update } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFloating"])(t26), referenceHidden = middlewareData.hide?.referenceHidden, arrowX = middlewareData.arrow?.x, arrowY = middlewareData.arrow?.y, originX = middlewareData["@sanity/ui/origin"]?.originX, originY = middlewareData["@sanity/ui/origin"]?.originY;
    let t27;
    $[72] === Symbol.for("react.memo_cache_sentinel") ? (t27 = (arrowEl)=>{
        arrowRef.current = arrowEl;
    }, $[72] = t27) : t27 = $[72];
    const setArrow = t27;
    let t28;
    $[73] !== refs ? (t28 = (node)=>{
        ref.current = node, refs.setFloating(node);
    }, $[73] = refs, $[74] = t28) : t28 = $[74];
    const setFloating = t28;
    let t29;
    $[75] !== childProp ? (t29 = childProp ? getElementRef(childProp) : null, $[75] = childProp, $[76] = t29) : t29 = $[76];
    let t30;
    $[77] !== refs.reference.current ? (t30 = ()=>refs.reference.current, $[77] = refs.reference.current, $[78] = t30) : t30 = $[78], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(t29, t30);
    let t31;
    bb0: {
        if (referenceElement) {
            t31 = childProp;
            break bb0;
        }
        if (!childProp) {
            t31 = null;
            break bb0;
        }
        let t322;
        $[79] !== childProp || $[80] !== refs.setReference ? (t322 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"])(childProp, {
            ref: refs.setReference
        }), $[79] = childProp, $[80] = refs.setReference, $[81] = t322) : t322 = $[81], t31 = t322;
    }
    const child = t31;
    let t32, t33;
    if ($[82] !== update ? (t32 = ()=>update, t33 = [
        update
    ], $[82] = update, $[83] = t32, $[84] = t33) : (t32 = $[83], t33 = $[84]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(updateRef, t32, t33), disabled) {
        let t342;
        return $[85] !== childProp ? (t342 = childProp || /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {}), $[85] = childProp, $[86] = t342) : t342 = $[86], t342;
    }
    let t34;
    $[87] !== modal ? (t34 = modal && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ViewportOverlay, {}), $[87] = modal, $[88] = t34) : t34 = $[88];
    const t35 = matchReferenceWidth ? referenceWidth_0 : width;
    let t36;
    $[89] !== animate || $[90] !== arrowProp || $[91] !== arrowX || $[92] !== arrowY || $[93] !== content || $[94] !== margins || $[95] !== originX || $[96] !== originY || $[97] !== overflow || $[98] !== padding || $[99] !== placement || $[100] !== radius || $[101] !== referenceHidden || $[102] !== restProps || $[103] !== scheme || $[104] !== setFloating || $[105] !== shadow || $[106] !== strategy || $[107] !== t35 || $[108] !== tone || $[109] !== x || $[110] !== y ? (t36 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(PopoverCard, {
        ...restProps,
        __unstable_margins: margins,
        animate,
        arrow: arrowProp,
        arrowRef: setArrow,
        arrowX,
        arrowY,
        hidden: referenceHidden,
        overflow,
        padding,
        placement,
        radius,
        ref: setFloating,
        scheme,
        shadow,
        originX,
        originY,
        strategy,
        tone,
        width: t35,
        x,
        y,
        children: content
    }), $[89] = animate, $[90] = arrowProp, $[91] = arrowX, $[92] = arrowY, $[93] = content, $[94] = margins, $[95] = originX, $[96] = originY, $[97] = overflow, $[98] = padding, $[99] = placement, $[100] = radius, $[101] = referenceHidden, $[102] = restProps, $[103] = scheme, $[104] = setFloating, $[105] = shadow, $[106] = strategy, $[107] = t35, $[108] = tone, $[109] = x, $[110] = y, $[111] = t36) : t36 = $[111];
    let t37;
    $[112] !== t34 || $[113] !== t36 || $[114] !== zOffset ? (t37 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(LayerProvider, {
        zOffset,
        children: [
            t34,
            t36
        ]
    }), $[112] = t34, $[113] = t36, $[114] = zOffset, $[115] = t37) : t37 = $[115];
    const popover = t37;
    let t38;
    $[116] !== open || $[117] !== popover || $[118] !== portal ? (t38 = open && (portal ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Portal, {
        __unstable_name: typeof portal == "string" ? portal : void 0,
        children: popover
    }) : popover), $[116] = open, $[117] = popover, $[118] = portal, $[119] = t38) : t38 = $[119];
    const children = t38;
    let t39;
    $[120] !== animate || $[121] !== children ? (t39 = animate ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
        children
    }) : children, $[120] = animate, $[121] = children, $[122] = t39) : t39 = $[122];
    let t40;
    return $[123] !== child || $[124] !== t39 ? (t40 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            t39,
            child
        ]
    }), $[123] = child, $[124] = t39, $[125] = t40) : t40 = $[125], t40;
});
Popover.displayName = "ForwardRef(Popover)";
function useMiddleware$1(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(42), { animate, arrowProp, arrowRef, constrainSize, fallbackPlacements, floatingBoundary, margins, matchReferenceWidth, maxWidthRef, placementProp, placementStrategy, preventOverflow, referenceBoundary, referenceWidthRef, rootBoundary, setReferenceWidth, widthRef } = t0;
    let ret;
    if ($[0] !== animate || $[1] !== arrowProp || $[2] !== arrowRef || $[3] !== constrainSize || $[4] !== fallbackPlacements || $[5] !== floatingBoundary || $[6] !== margins || $[7] !== matchReferenceWidth || $[8] !== maxWidthRef || $[9] !== placementProp || $[10] !== placementStrategy || $[11] !== preventOverflow || $[12] !== referenceBoundary || $[13] !== referenceWidthRef || $[14] !== rootBoundary || $[15] !== setReferenceWidth || $[16] !== widthRef) {
        if (ret = [], constrainSize || preventOverflow) if (placementStrategy === "autoPlacement") {
            let t12;
            $[18] !== fallbackPlacements || $[19] !== placementProp ? (t12 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["autoPlacement"])({
                allowedPlacements: [
                    placementProp
                ].concat(fallbackPlacements)
            }), $[18] = fallbackPlacements, $[19] = placementProp, $[20] = t12) : t12 = $[20], ret.push(t12);
        } else {
            const t12 = floatingBoundary || void 0;
            let t22;
            $[21] !== fallbackPlacements || $[22] !== rootBoundary || $[23] !== t12 ? (t22 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["flip"])({
                boundary: t12,
                fallbackPlacements,
                padding: DEFAULT_POPOVER_PADDING,
                rootBoundary
            }), $[21] = fallbackPlacements, $[22] = rootBoundary, $[23] = t12, $[24] = t22) : t22 = $[24], ret.push(t22);
        }
        let t1;
        if ($[25] === Symbol.for("react.memo_cache_sentinel") ? (t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["offset"])({
            mainAxis: DEFAULT_POPOVER_DISTANCE
        }), $[25] = t1) : t1 = $[25], ret.push(t1), constrainSize || matchReferenceWidth) {
            const t22 = floatingBoundary || void 0;
            let t32;
            $[26] !== constrainSize || $[27] !== margins || $[28] !== matchReferenceWidth || $[29] !== maxWidthRef || $[30] !== referenceWidthRef || $[31] !== setReferenceWidth || $[32] !== t22 || $[33] !== widthRef ? (t32 = size({
                boundaryElement: t22,
                constrainSize,
                margins,
                matchReferenceWidth,
                maxWidthRef,
                padding: DEFAULT_POPOVER_PADDING,
                referenceWidthRef,
                setReferenceWidth,
                widthRef
            }), $[26] = constrainSize, $[27] = margins, $[28] = matchReferenceWidth, $[29] = maxWidthRef, $[30] = referenceWidthRef, $[31] = setReferenceWidth, $[32] = t22, $[33] = widthRef, $[34] = t32) : t32 = $[34], ret.push(t32);
        }
        if (preventOverflow) {
            const t22 = floatingBoundary || void 0;
            let t32;
            $[35] !== rootBoundary || $[36] !== t22 ? (t32 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["shift"])({
                boundary: t22,
                rootBoundary,
                padding: DEFAULT_POPOVER_PADDING
            }), $[35] = rootBoundary, $[36] = t22, $[37] = t32) : t32 = $[37], ret.push(t32);
        }
        if (arrowProp) {
            let t22;
            $[38] !== arrowRef ? (t22 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["arrow"])({
                element: arrowRef,
                padding: DEFAULT_POPOVER_PADDING
            }), $[38] = arrowRef, $[39] = t22) : t22 = $[39], ret.push(t22);
        }
        animate && ret.push(origin);
        const t2 = referenceBoundary || void 0;
        let t3;
        $[40] !== t2 ? (t3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["hide"])({
            boundary: t2,
            padding: DEFAULT_POPOVER_PADDING,
            strategy: "referenceHidden"
        }), $[40] = t2, $[41] = t3) : t3 = $[41], ret.push(t3), $[0] = animate, $[1] = arrowProp, $[2] = arrowRef, $[3] = constrainSize, $[4] = fallbackPlacements, $[5] = floatingBoundary, $[6] = margins, $[7] = matchReferenceWidth, $[8] = maxWidthRef, $[9] = placementProp, $[10] = placementStrategy, $[11] = preventOverflow, $[12] = referenceBoundary, $[13] = referenceWidthRef, $[14] = rootBoundary, $[15] = setReferenceWidth, $[16] = widthRef, $[17] = ret;
    } else ret = $[17];
    return ret;
}
function radioBaseStyle() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    position: relative;

    &:not([hidden]) {
      display: inline-block;
    }

    &[data-read-only] {
      outline: 1px solid red;
    }
  `;
}
function inputElementStyle(props) {
    const { color, input } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), dist = (input.radio.size - input.radio.markSize) / 2;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    appearance: none;
    position: absolute;
    top: 0;
    left: 0;
    opacity: 0;
    height: 100%;
    width: 100%;
    outline: none;
    z-index: 1;
    padding: 0;
    margin: 0;
    border-radius: ${rem(input.radio.size / 2)};
    border: none;

    /* enabled */
    & + span {
      display: block;
      position: relative;
      height: ${rem(input.radio.size)};
      width: ${rem(input.radio.size)};
      border-radius: ${rem(input.radio.size / 2)};
      background: ${color.input.default.enabled.bg};
      box-shadow: ${focusRingBorderStyle({
        color: color.input.default.enabled.border,
        width: input.border.width
    })};

      &::after {
        content: '';
        position: absolute;
        top: ${rem(dist)};
        left: ${rem(dist)};
        height: ${rem(input.radio.markSize)};
        width: ${rem(input.radio.markSize)};
        border-radius: ${rem(input.radio.markSize / 2)};
        background: ${color.input.default.enabled.fg};
        opacity: 0;
      }
    }

    /* focused */
    &:not(:disabled):focus + span {
      box-shadow: ${focusRingStyle({
        border: {
            width: input.border.width,
            color: color.input.default.enabled.border
        },
        focusRing: input.radio.focusRing
    })};
    }

    &:not(:disabled):focus:not(:focus-visible) + span {
      box-shadow: ${focusRingBorderStyle({
        color: color.input.default.enabled.border,
        width: input.border.width
    })};
    }

    &:checked + span::after {
      opacity: 1;
    }

    /* customValidity */
    &[data-error] + span {
      background-color: ${color.input.invalid.enabled.border};
      box-shadow: ${focusRingBorderStyle({
        width: input.border.width,
        color: color.input.invalid.enabled.muted.bg
    })};
      &::after {
        background: ${color.input.invalid.enabled.muted.bg};
      }
    }

    /* read only */
    &[data-read-only] + span {
      box-shadow: 0 0 0 1px ${color.input.default.readOnly.border};
      background: ${color.input.default.readOnly.bg};

      &::after {
        background: ${color.input.default.readOnly.border};
      }
    }

    /* disabled */
    &:not([data-read-only]):disabled + span {
      box-shadow: 0 0 0 1px ${color.input.default.disabled.border};
      background: ${color.input.default.disabled.bg};

      &::after {
        background: ${color.input.default.disabled.border};
      }
    }
  `;
}
const StyledRadio = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledRadio",
    componentId: "sc-ccrwkf-0"
})(radioBaseStyle), Input$4 = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].input.withConfig({
    displayName: "Input",
    componentId: "sc-ccrwkf-1"
})(inputElementStyle), Radio = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19);
    let className, customValidity, disabled, readOnly, restProps, style;
    $[0] !== props ? ({ className, disabled, style, customValidity, readOnly, ...restProps } = props, $[0] = props, $[1] = className, $[2] = customValidity, $[3] = disabled, $[4] = readOnly, $[5] = restProps, $[6] = style) : (className = $[1], customValidity = $[2], disabled = $[3], readOnly = $[4], restProps = $[5], style = $[6]);
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t0;
    $[7] === Symbol.for("react.memo_cache_sentinel") ? (t0 = ()=>ref.current, $[7] = t0) : t0 = $[7], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t0), useCustomValidity(ref, customValidity);
    const t1 = !disabled && readOnly ? "" : void 0, t2 = customValidity ? "" : void 0, t3 = disabled || readOnly;
    let t4;
    $[8] !== readOnly || $[9] !== restProps || $[10] !== t1 || $[11] !== t2 || $[12] !== t3 ? (t4 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Input$4, {
        "data-read-only": t1,
        "data-error": t2,
        ...restProps,
        disabled: t3,
        readOnly,
        ref,
        type: "radio"
    }), $[8] = readOnly, $[9] = restProps, $[10] = t1, $[11] = t2, $[12] = t3, $[13] = t4) : t4 = $[13];
    let t5;
    $[14] === Symbol.for("react.memo_cache_sentinel") ? (t5 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {}), $[14] = t5) : t5 = $[14];
    let t6;
    return $[15] !== className || $[16] !== style || $[17] !== t4 ? (t6 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(StyledRadio, {
        className,
        "data-ui": "Radio",
        style,
        children: [
            t4,
            t5
        ]
    }), $[15] = className, $[16] = style, $[17] = t4, $[18] = t6) : t6 = $[18], t6;
});
Radio.displayName = "ForwardRef(Radio)";
function rootStyle() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    position: relative;
    width: -moz-available;
    width: -webkit-fill-available;
    width: stretch;

    &:not([hidden]) {
      display: inline-block;
    }
  `;
}
function inputBaseStyle(props) {
    const { font } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    -webkit-font-smoothing: antialiased;
    appearance: none;
    border: 0;
    font-family: ${font.text.family};
    color: inherit;
    width: 100%;
    outline: none;
    margin: 0;

    &:disabled {
      opacity: 1;
    }
  `;
}
function inputColorStyle(props) {
    const { color, input } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    /* enabled */
    background-color: ${color.input.default.enabled.bg};
    color: ${color.input.default.enabled.fg};
    box-shadow: ${focusRingBorderStyle({
        color: color.input.default.enabled.border,
        width: input.border.width
    })};

    /* hovered */
    @media (hover: hover) {
      &:not(:disabled):hover {
        background-color: ${color.input.default.hovered.bg};
        color: ${color.input.default.hovered.fg};
        box-shadow: ${focusRingBorderStyle({
        color: color.input.default.hovered.border,
        width: input.border.width
    })};
      }
    }

    /* focused */
    &:not(:disabled):focus {
      box-shadow: ${focusRingStyle({
        border: {
            width: input.border.width,
            color: color.input.default.enabled.border
        },
        focusRing: input.select.focusRing
    })};
    }

    /* read-only */
    &[data-read-only] {
      background-color: ${color.input.default.readOnly.bg};
      color: ${color.input.default.readOnly.fg};
      box-shadow: ${focusRingBorderStyle({
        color: color.input.default.readOnly.border,
        width: input.border.width
    })};
    }

    /* disabled */
    &:not([data-read-only]):disabled {
      background-color: ${color.input.default.disabled.bg};
      color: ${color.input.default.disabled.fg};
      box-shadow: ${focusRingBorderStyle({
        color: color.input.default.disabled.border,
        width: input.border.width
    })};
    }
  `;
}
function textSize(size2) {
    return {
        fontSize: rem(size2.fontSize),
        lineHeight: `${rem(size2.lineHeight)}`
    };
}
function inputTextSizeStyle(props) {
    const { $fontSize } = props, { font, media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, $fontSize, (sizeIndex)=>textSize(font.text.sizes[sizeIndex] || font.text.sizes[2]));
}
function inputStyle() {
    return [
        responsiveRadiusStyle,
        inputBaseStyle,
        inputColorStyle,
        inputTextSizeStyle,
        responsiveInputPaddingIconRightStyle
    ];
}
function iconBoxStyle(props) {
    const { color } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    pointer-events: none;
    position: absolute;
    top: 0;
    right: 0;

    /* enabled */
    --card-fg-color: ${color.input.default.enabled.fg};

    /* hover */
    @media (hover: hover) {
      select:not(disabled):not(:read-only):hover + && {
        --card-fg-color: ${color.input.default.hovered.fg};
      }
    }

    /* disabled */
    select:disabled + && {
      --card-fg-color: ${color.input.default.disabled.fg};
    }

    /* read-only */
    select[data-read-only] + && {
      --card-fg-color: ${color.input.default.readOnly.fg};
    }
  `;
}
const selectStyle = {
    root: rootStyle,
    input: inputStyle,
    iconBox: iconBoxStyle
}, StyledSelect = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledSelect",
    componentId: "sc-5mxno7-0"
})(selectStyle.root), Input$3 = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].select.withConfig({
    displayName: "Input",
    componentId: "sc-5mxno7-1"
})(selectStyle.input), IconBox = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Box).withConfig({
    displayName: "IconBox",
    componentId: "sc-5mxno7-2"
})(selectStyle.iconBox), Select = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(38);
    let children, customValidity, disabled, gap, readOnly, restProps, t0, t1, t2, t3;
    $[0] !== props ? ({ children, customValidity, disabled, fontSize: t0, gap, padding: t1, radius: t2, readOnly, space: t3, ...restProps } = props, $[0] = props, $[1] = children, $[2] = customValidity, $[3] = disabled, $[4] = gap, $[5] = readOnly, $[6] = restProps, $[7] = t0, $[8] = t1, $[9] = t2, $[10] = t3) : (children = $[1], customValidity = $[2], disabled = $[3], gap = $[4], readOnly = $[5], restProps = $[6], t0 = $[7], t1 = $[8], t2 = $[9], t3 = $[10]);
    const fontSize2 = t0 === void 0 ? 2 : t0, padding = t1 === void 0 ? 3 : t1, radius = t2 === void 0 ? 2 : t2, spacing = gap === void 0 ? t3 === void 0 ? 3 : t3 : gap, ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t4;
    $[11] === Symbol.for("react.memo_cache_sentinel") ? (t4 = ()=>ref.current, $[11] = t4) : t4 = $[11], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t4), useCustomValidity(ref, customValidity);
    const t5 = !disabled && readOnly ? "" : void 0;
    let t6;
    $[12] !== fontSize2 ? (t6 = _getArrayProp(fontSize2), $[12] = fontSize2, $[13] = t6) : t6 = $[13];
    let t7;
    $[14] !== padding ? (t7 = _getArrayProp(padding), $[14] = padding, $[15] = t7) : t7 = $[15];
    let t8;
    $[16] !== radius ? (t8 = _getArrayProp(radius), $[16] = radius, $[17] = t8) : t8 = $[17];
    let t9;
    $[18] !== spacing ? (t9 = _getArrayProp(spacing), $[18] = spacing, $[19] = t9) : t9 = $[19];
    const t10 = disabled || readOnly;
    let t11;
    $[20] !== children || $[21] !== restProps || $[22] !== t10 || $[23] !== t5 || $[24] !== t6 || $[25] !== t7 || $[26] !== t8 || $[27] !== t9 ? (t11 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Input$3, {
        "data-read-only": t5,
        "data-ui": "Select",
        ...restProps,
        $fontSize: t6,
        $padding: t7,
        $radius: t8,
        $space: t9,
        disabled: t10,
        ref,
        children
    }), $[20] = children, $[21] = restProps, $[22] = t10, $[23] = t5, $[24] = t6, $[25] = t7, $[26] = t8, $[27] = t9, $[28] = t11) : t11 = $[28];
    let t12;
    $[29] === Symbol.for("react.memo_cache_sentinel") ? (t12 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChevronDownIcon"], {}), $[29] = t12) : t12 = $[29];
    let t13;
    $[30] !== fontSize2 ? (t13 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Text, {
        size: fontSize2,
        children: t12
    }), $[30] = fontSize2, $[31] = t13) : t13 = $[31];
    let t14;
    $[32] !== padding || $[33] !== t13 ? (t14 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(IconBox, {
        padding,
        children: t13
    }), $[32] = padding, $[33] = t13, $[34] = t14) : t14 = $[34];
    let t15;
    return $[35] !== t11 || $[36] !== t14 ? (t15 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(StyledSelect, {
        "data-ui": "Select",
        children: [
            t11,
            t14
        ]
    }), $[35] = t11, $[36] = t14, $[37] = t15) : t15 = $[37], t15;
});
Select.displayName = "ForwardRef(Select)";
const BASE_STYLE = {
    "&&:not([hidden])": {
        display: "grid"
    },
    '&[data-as="ul"],&[data-as="ol"]': {
        listStyle: "none"
    },
    gridTemplateColumns: "minmax(0, 1fr)",
    gridAutoRows: "min-content"
};
function stackBaseStyle() {
    return BASE_STYLE;
}
function responsiveStackSpaceStyle(props) {
    const { media, space } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return _responsive(media, props.$space, (spaceIndex)=>({
            gridGap: rem(space[spaceIndex])
        }));
}
const StyledStack = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Box).withConfig({
    displayName: "StyledStack",
    componentId: "sc-8dpfq2-0"
})(stackBaseStyle, responsiveStackSpaceStyle), Stack = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    let as, deprecated_space, gap, restProps;
    $[0] !== props ? ({ as, gap, space: deprecated_space, ...restProps } = props, $[0] = props, $[1] = as, $[2] = deprecated_space, $[3] = gap, $[4] = restProps) : (as = $[1], deprecated_space = $[2], gap = $[3], restProps = $[4]);
    const spacing = gap === void 0 ? deprecated_space : gap, t0 = typeof as == "string" ? as : void 0;
    let t1;
    $[5] !== spacing ? (t1 = _getArrayProp(spacing), $[5] = spacing, $[6] = t1) : t1 = $[6];
    let t2;
    return $[7] !== as || $[8] !== ref || $[9] !== restProps || $[10] !== t0 || $[11] !== t1 ? (t2 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledStack, {
        "data-as": t0,
        "data-ui": "Stack",
        ...restProps,
        $space: t1,
        forwardedAs: as,
        ref
    }), $[7] = as, $[8] = ref, $[9] = restProps, $[10] = t0, $[11] = t1, $[12] = t2) : t2 = $[12], t2;
});
Stack.displayName = "ForwardRef(Stack)";
function switchBaseStyles() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    position: relative;
    &:not([hidden]) {
      display: inline-block;
    }
  `;
}
function switchInputStyles() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    opacity: 0;
    height: 100%;
    width: 100%;
    outline: none;
    padding: 0;
    margin: 0;

    /* Place the input element above the representation element */
    z-index: 1;
  `;
}
function switchRepresentationStyles(props) {
    const { color, input } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    --switch-bg-color: ${color.input.default.enabled.border};
    --switch-fg-color: ${color.input.default.enabled.bg};
    --switch-box-shadow: none;

    &:not([hidden]) {
      display: block;
    }
    position: relative;
    width: ${rem(input.switch.width)};
    height: ${rem(input.switch.height)};
    border-radius: ${rem(input.switch.height / 2)};

    /* Make sure it’s not possible to interact with the wrapper element */
    pointer-events: none;

    &:after {
      content: '';
      display: block;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      z-index: 1;
      box-shadow: var(--switch-box-shadow);
      border-radius: inherit;
    }

    /* Focus styles */
    input:focus + && {
      --switch-box-shadow: ${focusRingStyle({
        focusRing: input.switch.focusRing
    })};
    }

    input:focus:not(:focus-visible) + && {
      --switch-box-shadow: none;
    }

    input:checked + && {
      --switch-bg-color: ${color.input.default.enabled.fg};
      --switch-fg-color: ${color.input.default.enabled.bg};
    }

    @media (hover: hover) {
      input:not(:disabled):hover + && {
        --switch-bg-color: ${color.input.default.hovered.border};
        --switch-fg-color: ${color.input.default.hovered.bg};
      }

      input:not(:disabled):checked:hover + && {
        --switch-bg-color: ${color.input.default.enabled.fg};
        --switch-fg-color: ${color.input.default.enabled.bg};
      }
    }

    input:not([data-read-only]):disabled + && {
      --switch-bg-color: ${color.input.default.disabled.border};
      --switch-fg-color: ${color.input.default.disabled.bg};
    }

    input[data-read-only]:disabled + && {
      --switch-bg-color: ${color.input.default.readOnly.border};
      --switch-fg-color: ${color.input.default.readOnly.bg};
    }

    input:checked[data-read-only]:disabled + && {
      --switch-bg-color: ${color.input.default.readOnly.fg};
      --switch-fg-color: ${color.input.default.readOnly.bg};
    }
  `;
}
function switchTrackStyles(props) {
    const { input } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    &:not([hidden]) {
      display: block;
    }
    background-color: var(--switch-bg-color);
    position: absolute;
    left: 0;
    top: 0;
    width: ${rem(input.switch.width)};
    height: ${rem(input.switch.height)};
    border-radius: ${rem(input.switch.height / 2)};
  `;
}
function switchThumbStyles(props) {
    const { $indeterminate } = props, { input } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), trackWidth = input.switch.width, trackHeight = input.switch.height, trackPadding = input.switch.padding, size2 = trackHeight - input.switch.padding * 2, checkedOffset = trackWidth - trackPadding * 2 - size2, indeterminateOffset = trackWidth / 2 - size2 / 2 - trackPadding, checked = $indeterminate !== !0 && props.$checked === !0;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    &:not([hidden]) {
      display: block;
    }
    position: absolute;
    left: ${rem(trackPadding)};
    top: ${rem(trackPadding)};
    height: ${rem(size2)};
    width: ${rem(size2)};
    border-radius: ${rem(size2 / 2)};
    transition-property: transform;
    transition-duration: ${input.switch.transitionDurationMs}ms;
    transition-timing-function: ${input.switch.transitionTimingFunction};
    background: var(--switch-fg-color);
    transform: translate3d(0, 0, 0);
    box-shadow: 0px 1px 0px 0px rgba(0, 0, 0, 0.05);

    ${checked && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
      transform: translate3d(${checkedOffset}px, 0, 0);
    `}

    ${$indeterminate && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
      transform: translate3d(${indeterminateOffset}px, 0, 0);
    `}
  `;
}
const StyledSwitch = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].span.withConfig({
    displayName: "StyledSwitch",
    componentId: "sc-dw1foe-0"
})(switchBaseStyles), Input$2 = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].input.withConfig({
    displayName: "Input",
    componentId: "sc-dw1foe-1"
})(switchInputStyles), Representation = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].span.withConfig({
    displayName: "Representation",
    componentId: "sc-dw1foe-2"
})(switchRepresentationStyles), Track = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].span.withConfig({
    displayName: "Track",
    componentId: "sc-dw1foe-3"
})(switchTrackStyles), Thumb = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].span.withConfig({
    displayName: "Thumb",
    componentId: "sc-dw1foe-4"
})(switchThumbStyles), Switch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(26);
    let checked, className, disabled, indeterminate, readOnly, restProps, style;
    $[0] !== props ? ({ checked, className, disabled, indeterminate, readOnly, style, ...restProps } = props, $[0] = props, $[1] = checked, $[2] = className, $[3] = disabled, $[4] = indeterminate, $[5] = readOnly, $[6] = restProps, $[7] = style) : (checked = $[1], className = $[2], disabled = $[3], indeterminate = $[4], readOnly = $[5], restProps = $[6], style = $[7]);
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t0;
    $[8] === Symbol.for("react.memo_cache_sentinel") ? (t0 = ()=>ref.current, $[8] = t0) : t0 = $[8], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t0);
    let t1, t2;
    $[9] !== indeterminate ? (t1 = ()=>{
        ref.current && (ref.current.indeterminate = indeterminate || !1);
    }, t2 = [
        indeterminate
    ], $[9] = indeterminate, $[10] = t1, $[11] = t2) : (t1 = $[10], t2 = $[11]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    const t3 = !disabled && readOnly ? "" : void 0, t4 = indeterminate !== !0 && checked, t5 = disabled || readOnly;
    let t6;
    $[12] !== restProps || $[13] !== t3 || $[14] !== t4 || $[15] !== t5 ? (t6 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Input$2, {
        "data-read-only": t3,
        ...restProps,
        checked: t4,
        disabled: t5,
        type: "checkbox",
        ref
    }), $[12] = restProps, $[13] = t3, $[14] = t4, $[15] = t5, $[16] = t6) : t6 = $[16];
    let t7;
    $[17] === Symbol.for("react.memo_cache_sentinel") ? (t7 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Track, {}), $[17] = t7) : t7 = $[17];
    let t8;
    $[18] !== checked || $[19] !== indeterminate ? (t8 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Representation, {
        "aria-hidden": !0,
        "data-name": "representation",
        children: [
            t7,
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Thumb, {
                $checked: checked,
                $indeterminate: indeterminate
            })
        ]
    }), $[18] = checked, $[19] = indeterminate, $[20] = t8) : t8 = $[20];
    let t9;
    return $[21] !== className || $[22] !== style || $[23] !== t6 || $[24] !== t8 ? (t9 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(StyledSwitch, {
        className,
        "data-ui": "Switch",
        style,
        children: [
            t6,
            t8
        ]
    }), $[21] = className, $[22] = style, $[23] = t6, $[24] = t8, $[25] = t9) : t9 = $[25], t9;
});
Switch.displayName = "ForwardRef(Switch)";
const StyledTextArea = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].span.withConfig({
    displayName: "StyledTextArea",
    componentId: "sc-1d6h1o8-0"
})(textInputRootStyle), InputRoot$1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].span.withConfig({
    displayName: "InputRoot",
    componentId: "sc-1d6h1o8-1"
})`flex:1;min-width:0;display:block;position:relative;`, Input$1 = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].textarea.withConfig({
    displayName: "Input",
    componentId: "sc-1d6h1o8-2"
})(responsiveInputPaddingStyle, textInputBaseStyle, textInputFontSizeStyle), Presentation$1 = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "Presentation",
    componentId: "sc-1d6h1o8-3"
})(responsiveRadiusStyle, textInputRepresentationStyle), TextArea = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(35);
    let __unstable_disableFocusRing, customValidity, restProps, t0, t1, t2, t3, t4, weight;
    $[0] !== props ? ({ border: t0, customValidity, disabled: t1, fontSize: t2, padding: t3, radius: t4, weight, __unstable_disableFocusRing, ...restProps } = props, $[0] = props, $[1] = __unstable_disableFocusRing, $[2] = customValidity, $[3] = restProps, $[4] = t0, $[5] = t1, $[6] = t2, $[7] = t3, $[8] = t4, $[9] = weight) : (__unstable_disableFocusRing = $[1], customValidity = $[2], restProps = $[3], t0 = $[4], t1 = $[5], t2 = $[6], t3 = $[7], t4 = $[8], weight = $[9]);
    const border2 = t0 === void 0 ? !0 : t0, disabled = t1 === void 0 ? !1 : t1, fontSize2 = t2 === void 0 ? 2 : t2, padding = t3 === void 0 ? 3 : t3, radius = t4 === void 0 ? 2 : t4, ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), rootTheme = useRootTheme();
    let t5;
    $[10] === Symbol.for("react.memo_cache_sentinel") ? (t5 = ()=>ref.current, $[10] = t5) : t5 = $[10], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t5), useCustomValidity(ref, customValidity);
    const t6 = rootTheme.scheme, t7 = rootTheme.tone;
    let t8;
    $[11] !== fontSize2 ? (t8 = _getArrayProp(fontSize2), $[11] = fontSize2, $[12] = t8) : t8 = $[12];
    let t9;
    $[13] !== padding ? (t9 = _getArrayProp(padding), $[13] = padding, $[14] = t9) : t9 = $[14];
    const t10 = rootTheme.scheme;
    let t11;
    $[15] === Symbol.for("react.memo_cache_sentinel") ? (t11 = _getArrayProp(0), $[15] = t11) : t11 = $[15];
    let t12;
    $[16] !== disabled || $[17] !== restProps || $[18] !== rootTheme.scheme || $[19] !== rootTheme.tone || $[20] !== t8 || $[21] !== t9 || $[22] !== weight ? (t12 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Input$1, {
        "data-as": "textarea",
        "data-scheme": t6,
        "data-tone": t7,
        ...restProps,
        $fontSize: t8,
        $padding: t9,
        $scheme: t10,
        $space: t11,
        $tone: rootTheme.tone,
        $weight: weight,
        disabled,
        ref
    }), $[16] = disabled, $[17] = restProps, $[18] = rootTheme.scheme, $[19] = rootTheme.tone, $[20] = t8, $[21] = t9, $[22] = weight, $[23] = t12) : t12 = $[23];
    let t13;
    $[24] !== radius ? (t13 = _getArrayProp(radius), $[24] = radius, $[25] = t13) : t13 = $[25];
    const t14 = border2 ? "" : void 0;
    let t15;
    $[26] !== __unstable_disableFocusRing || $[27] !== rootTheme.scheme || $[28] !== rootTheme.tone || $[29] !== t13 || $[30] !== t14 ? (t15 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Presentation$1, {
        $radius: t13,
        $unstableDisableFocusRing: __unstable_disableFocusRing,
        $scheme: rootTheme.scheme,
        $tone: rootTheme.tone,
        "data-border": t14,
        "data-scheme": rootTheme.scheme,
        "data-tone": rootTheme.tone
    }), $[26] = __unstable_disableFocusRing, $[27] = rootTheme.scheme, $[28] = rootTheme.tone, $[29] = t13, $[30] = t14, $[31] = t15) : t15 = $[31];
    let t16;
    return $[32] !== t12 || $[33] !== t15 ? (t16 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledTextArea, {
        "data-ui": "TextArea",
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(InputRoot$1, {
            children: [
                t12,
                t15
            ]
        })
    }), $[32] = t12, $[33] = t15, $[34] = t16) : t16 = $[34], t16;
});
TextArea.displayName = "ForwardRef(TextArea)";
const CLEAR_BUTTON_BOX_STYLE = {
    zIndex: 2
}, StyledTextInput = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Card).attrs({
    forwardedAs: "span"
}).withConfig({
    displayName: "StyledTextInput",
    componentId: "sc-h62wco-0"
})(textInputRootStyle), InputRoot = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].span.withConfig({
    displayName: "InputRoot",
    componentId: "sc-h62wco-1"
})`flex:1;min-width:0;display:block;position:relative;`, Prefix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Card).attrs({
    forwardedAs: "span"
}).withConfig({
    displayName: "Prefix",
    componentId: "sc-h62wco-2"
})`border-top-right-radius:0;border-bottom-right-radius:0;& > span{display:block;margin:-1px;}`, Suffix = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Card).attrs({
    forwardedAs: "span"
}).withConfig({
    displayName: "Suffix",
    componentId: "sc-h62wco-3"
})`border-top-left-radius:0;border-bottom-left-radius:0;& > span{display:block;margin:-1px;}`, Input = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].input.withConfig({
    displayName: "Input",
    componentId: "sc-h62wco-4"
})(responsiveInputPaddingStyle, textInputBaseStyle, textInputFontSizeStyle), Presentation = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].span.withConfig({
    displayName: "Presentation",
    componentId: "sc-h62wco-5"
})(responsiveRadiusStyle, textInputRepresentationStyle), LeftBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Box).withConfig({
    displayName: "LeftBox",
    componentId: "sc-h62wco-6"
})`position:absolute;top:0;left:0;`, RightBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Box).withConfig({
    displayName: "RightBox",
    componentId: "sc-h62wco-7"
})`position:absolute;top:0;right:0;`, RightCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Card).withConfig({
    displayName: "RightCard",
    componentId: "sc-h62wco-8"
})`background-color:transparent;position:absolute;top:0;right:0;`, TextInputClearButton = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Button).withConfig({
    displayName: "TextInputClearButton",
    componentId: "sc-h62wco-9"
})({
    "&:not([hidden])": {
        display: "block"
    }
}), TextInput = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(93);
    let IconComponent, IconRightComponent, __unstable_disableFocusRing, clearButton, customValidity, gap, onClear, prefix, readOnly, restProps, suffix, t0, t1, t2, t3, t4, t5, t6, weight;
    $[0] !== props ? ({ __unstable_disableFocusRing, border: t0, clearButton, disabled: t1, fontSize: t2, gap, icon: IconComponent, iconRight: IconRightComponent, onClear, padding: t3, prefix, radius: t4, readOnly, space: t5, suffix, customValidity, type: t6, weight, ...restProps } = props, $[0] = props, $[1] = IconComponent, $[2] = IconRightComponent, $[3] = __unstable_disableFocusRing, $[4] = clearButton, $[5] = customValidity, $[6] = gap, $[7] = onClear, $[8] = prefix, $[9] = readOnly, $[10] = restProps, $[11] = suffix, $[12] = t0, $[13] = t1, $[14] = t2, $[15] = t3, $[16] = t4, $[17] = t5, $[18] = t6, $[19] = weight) : (IconComponent = $[1], IconRightComponent = $[2], __unstable_disableFocusRing = $[3], clearButton = $[4], customValidity = $[5], gap = $[6], onClear = $[7], prefix = $[8], readOnly = $[9], restProps = $[10], suffix = $[11], t0 = $[12], t1 = $[13], t2 = $[14], t3 = $[15], t4 = $[16], t5 = $[17], t6 = $[18], weight = $[19]);
    const border2 = t0 === void 0 ? !0 : t0, disabled = t1 === void 0 ? !1 : t1, fontSizeProp = t2 === void 0 ? 2 : t2, paddingProp = t3 === void 0 ? 3 : t3, radiusProp = t4 === void 0 ? 2 : t4, deprecated_space = t5 === void 0 ? 3 : t5, type = t6 === void 0 ? "text" : t6, ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), rootTheme = useRootTheme();
    let t7;
    $[20] !== fontSizeProp ? (t7 = _getArrayProp(fontSizeProp), $[20] = fontSizeProp, $[21] = t7) : t7 = $[21];
    const fontSize2 = t7;
    let t8;
    $[22] !== paddingProp ? (t8 = _getArrayProp(paddingProp), $[22] = paddingProp, $[23] = t8) : t8 = $[23];
    const padding = t8;
    let t9;
    $[24] !== radiusProp ? (t9 = _getArrayProp(radiusProp), $[24] = radiusProp, $[25] = t9) : t9 = $[25];
    const radius = t9, t10 = gap === void 0 ? deprecated_space : gap;
    let t11;
    $[26] !== t10 ? (t11 = _getArrayProp(t10), $[26] = t10, $[27] = t11) : t11 = $[27];
    const space = t11, $hasClearButton = !!clearButton, $hasIcon = !!IconComponent, $hasIconRight = !!IconRightComponent, $hasSuffix = !!suffix, $hasPrefix = !!prefix;
    let t12;
    $[28] === Symbol.for("react.memo_cache_sentinel") ? (t12 = ()=>ref.current, $[28] = t12) : t12 = $[28], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t12), useCustomValidity(ref, customValidity);
    const handleClearMouseDown = _temp$2;
    let t13;
    $[29] !== onClear ? (t13 = (event_0)=>{
        event_0.preventDefault(), event_0.stopPropagation(), onClear && onClear(), ref.current?.focus();
    }, $[29] = onClear, $[30] = t13) : t13 = $[30];
    const handleClearClick = t13;
    let t14;
    $[31] !== prefix || $[32] !== radius ? (t14 = prefix && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Prefix, {
        borderTop: !0,
        borderLeft: !0,
        borderBottom: !0,
        radius,
        sizing: "border",
        tone: "inherit",
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
            children: prefix
        })
    }), $[31] = prefix, $[32] = radius, $[33] = t14) : t14 = $[33];
    const prefixNode = t14, t15 = border2 ? "" : void 0;
    let t16;
    $[34] !== IconComponent || $[35] !== fontSize2 || $[36] !== padding ? (t16 = IconComponent && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LeftBox, {
        padding,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Text, {
            size: fontSize2,
            children: [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(IconComponent) && IconComponent,
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElementType"])(IconComponent) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(IconComponent, {})
            ]
        })
    }), $[34] = IconComponent, $[35] = fontSize2, $[36] = padding, $[37] = t16) : t16 = $[37];
    let t17;
    $[38] !== $hasClearButton || $[39] !== IconRightComponent || $[40] !== fontSize2 || $[41] !== padding ? (t17 = !$hasClearButton && IconRightComponent && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(RightBox, {
        padding,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Text, {
            size: fontSize2,
            children: [
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(IconRightComponent) && IconRightComponent,
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElementType"])(IconRightComponent) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(IconRightComponent, {})
            ]
        })
    }), $[38] = $hasClearButton, $[39] = IconRightComponent, $[40] = fontSize2, $[41] = padding, $[42] = t17) : t17 = $[42];
    let t18;
    $[43] !== $hasPrefix || $[44] !== $hasSuffix || $[45] !== __unstable_disableFocusRing || $[46] !== radius || $[47] !== rootTheme.scheme || $[48] !== rootTheme.tone || $[49] !== t15 || $[50] !== t16 || $[51] !== t17 ? (t18 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Presentation, {
        $hasPrefix,
        $unstableDisableFocusRing: __unstable_disableFocusRing,
        $hasSuffix,
        $radius: radius,
        $scheme: rootTheme.scheme,
        $tone: rootTheme.tone,
        "data-border": t15,
        "data-scheme": rootTheme.scheme,
        "data-tone": rootTheme.tone,
        children: [
            t16,
            t17
        ]
    }), $[43] = $hasPrefix, $[44] = $hasSuffix, $[45] = __unstable_disableFocusRing, $[46] = radius, $[47] = rootTheme.scheme, $[48] = rootTheme.tone, $[49] = t15, $[50] = t16, $[51] = t17, $[52] = t18) : t18 = $[52];
    const presentationNode = t18;
    let t19;
    $[53] !== padding ? (t19 = padding.map(_temp2), $[53] = padding, $[54] = t19) : t19 = $[54];
    const clearButtonBoxPadding = t19;
    let t20;
    $[55] !== padding ? (t20 = padding.map(_temp3), $[55] = padding, $[56] = t20) : t20 = $[56];
    const clearButtonPadding = t20, clearButtonProps = typeof clearButton == "object" ? clearButton : EMPTY_RECORD;
    let t21;
    $[57] !== clearButton || $[58] !== clearButtonBoxPadding || $[59] !== clearButtonPadding || $[60] !== clearButtonProps || $[61] !== customValidity || $[62] !== disabled || $[63] !== fontSize2 || $[64] !== handleClearClick || $[65] !== radius || $[66] !== readOnly ? (t21 = !disabled && !readOnly && clearButton && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(RightCard, {
        forwardedAs: "span",
        padding: clearButtonBoxPadding,
        style: CLEAR_BUTTON_BOX_STYLE,
        tone: customValidity ? "critical" : "inherit",
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TextInputClearButton, {
            "aria-label": "Clear",
            "data-qa": "clear-button",
            fontSize: fontSize2,
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CloseIcon"],
            mode: "bleed",
            padding: clearButtonPadding,
            radius,
            ...clearButtonProps,
            onClick: handleClearClick,
            onMouseDown: handleClearMouseDown
        })
    }), $[57] = clearButton, $[58] = clearButtonBoxPadding, $[59] = clearButtonPadding, $[60] = clearButtonProps, $[61] = customValidity, $[62] = disabled, $[63] = fontSize2, $[64] = handleClearClick, $[65] = radius, $[66] = readOnly, $[67] = t21) : t21 = $[67];
    const clearButtonNode = t21;
    let t22;
    $[68] !== radius || $[69] !== suffix ? (t22 = suffix && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Suffix, {
        borderTop: !0,
        borderRight: !0,
        borderBottom: !0,
        radius,
        sizing: "border",
        tone: "inherit",
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
            children: suffix
        })
    }), $[68] = radius, $[69] = suffix, $[70] = t22) : t22 = $[70];
    const suffixNode = t22, t23 = $hasIconRight || $hasClearButton;
    let t24;
    $[71] !== $hasIcon || $[72] !== disabled || $[73] !== fontSize2 || $[74] !== padding || $[75] !== readOnly || $[76] !== restProps || $[77] !== rootTheme.scheme || $[78] !== rootTheme.tone || $[79] !== space || $[80] !== t23 || $[81] !== type || $[82] !== weight ? (t24 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Input, {
        "data-as": "input",
        "data-scheme": rootTheme.scheme,
        "data-tone": rootTheme.tone,
        ...restProps,
        $fontSize: fontSize2,
        $iconLeft: $hasIcon,
        $iconRight: t23,
        $padding: padding,
        $scheme: rootTheme.scheme,
        $space: space,
        $tone: rootTheme.tone,
        $weight: weight,
        disabled,
        readOnly,
        ref,
        type
    }), $[71] = $hasIcon, $[72] = disabled, $[73] = fontSize2, $[74] = padding, $[75] = readOnly, $[76] = restProps, $[77] = rootTheme.scheme, $[78] = rootTheme.tone, $[79] = space, $[80] = t23, $[81] = type, $[82] = weight, $[83] = t24) : t24 = $[83];
    let t25;
    $[84] !== clearButtonNode || $[85] !== presentationNode || $[86] !== t24 ? (t25 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(InputRoot, {
        children: [
            t24,
            presentationNode,
            clearButtonNode
        ]
    }), $[84] = clearButtonNode, $[85] = presentationNode, $[86] = t24, $[87] = t25) : t25 = $[87];
    let t26;
    return $[88] !== prefixNode || $[89] !== rootTheme.tone || $[90] !== suffixNode || $[91] !== t25 ? (t26 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(StyledTextInput, {
        "data-ui": "TextInput",
        tone: rootTheme.tone,
        children: [
            prefixNode,
            t25,
            suffixNode
        ]
    }), $[88] = prefixNode, $[89] = rootTheme.tone, $[90] = suffixNode, $[91] = t25, $[92] = t26) : t26 = $[92], t26;
});
TextInput.displayName = "ForwardRef(TextInput)";
function _temp$2(event) {
    event.preventDefault(), event.stopPropagation();
}
function _temp2(v) {
    return v === 0 ? 0 : v === 1 || v === 2 ? 1 : v - 2;
}
function _temp3(v_0) {
    return v_0 === 0 || v_0 === 1 ? 0 : v_0 === 2 ? 1 : v_0 - 1;
}
function useDelayedState(initialState) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5), [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialState), delayedAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(void 0);
    let t0;
    $[0] === Symbol.for("react.memo_cache_sentinel") ? (t0 = (nextState, delay)=>{
        const action = ()=>{
            setState(nextState);
        };
        if (delayedAction.current && (clearTimeout(delayedAction.current), delayedAction.current = void 0), !delay) return action();
        delayedAction.current = setTimeout(action, delay);
    }, $[0] = t0) : t0 = $[0];
    const onStateChange = t0;
    let t1, t2;
    $[1] === Symbol.for("react.memo_cache_sentinel") ? (t1 = ()=>()=>{
            delayedAction.current && clearTimeout(delayedAction.current);
        }, t2 = [], $[1] = t1, $[2] = t2) : (t1 = $[1], t2 = $[2]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    return $[3] !== state ? (t3 = [
        state,
        onStateChange
    ], $[3] = state, $[4] = t3) : t3 = $[4], t3;
}
const DEFAULT_TOOLTIP_ARROW_WIDTH = 15, DEFAULT_TOOLTIP_ARROW_HEIGHT = 6, DEFAULT_TOOLTIP_ARROW_RADIUS = 2, DEFAULT_TOOLTIP_DISTANCE = 4, DEFAULT_TOOLTIP_PADDING = 4, DEFAULT_FALLBACK_PLACEMENTS = {
    top: [
        "top-end",
        "top-start",
        "bottom",
        "left",
        "right"
    ],
    "top-start": [
        "top",
        "top-end",
        "bottom-start",
        "left-start",
        "right-start"
    ],
    "top-end": [
        "top",
        "top-start",
        "bottom-end",
        "left-end",
        "right-end"
    ],
    bottom: [
        "bottom-end",
        "bottom-start",
        "top",
        "left",
        "right"
    ],
    "bottom-start": [
        "bottom",
        "bottom-end",
        "top-start",
        "left-start",
        "right-start"
    ],
    "bottom-end": [
        "bottom",
        "bottom-start",
        "top-end",
        "left-end",
        "right-end"
    ],
    left: [
        "left-end",
        "left-start",
        "right",
        "top",
        "bottom"
    ],
    "left-start": [
        "left",
        "left-end",
        "right-start",
        "top-start",
        "bottom-start"
    ],
    "left-end": [
        "left",
        "left-start",
        "right-end",
        "top-end",
        "bottom-end"
    ],
    right: [
        "right-end",
        "right-start",
        "left",
        "top",
        "bottom"
    ],
    "right-start": [
        "right",
        "right-end",
        "left-start",
        "top-start",
        "bottom-start"
    ],
    "right-end": [
        "right",
        "right-start",
        "left-end",
        "top-end",
        "bottom-end"
    ]
}, MotionCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].create(Card)).withConfig({
    displayName: "MotionCard",
    componentId: "sc-1xn138w-0"
})`will-change:transform;`, TooltipCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(48);
    let animate, arrow2, arrowRef, arrowX, arrowY, children, originX, originY, padding, placement, radius, restProps, scheme, shadow, style;
    $[0] !== props ? ({ animate, arrow: arrow2, arrowRef, arrowX, arrowY, children, originX, originY, padding, placement, radius, scheme, shadow, style, ...restProps } = props, $[0] = props, $[1] = animate, $[2] = arrow2, $[3] = arrowRef, $[4] = arrowX, $[5] = arrowY, $[6] = children, $[7] = originX, $[8] = originY, $[9] = padding, $[10] = placement, $[11] = radius, $[12] = restProps, $[13] = scheme, $[14] = shadow, $[15] = style) : (animate = $[1], arrow2 = $[2], arrowRef = $[3], arrowX = $[4], arrowY = $[5], children = $[6], originX = $[7], originY = $[8], padding = $[9], placement = $[10], radius = $[11], restProps = $[12], scheme = $[13], shadow = $[14], style = $[15]);
    const t0 = animate ? "transform" : void 0;
    let t1;
    $[16] !== originX || $[17] !== originY || $[18] !== style || $[19] !== t0 ? (t1 = {
        originX,
        originY,
        willChange: t0,
        ...style
    }, $[16] = originX, $[17] = originY, $[18] = style, $[19] = t0, $[20] = t1) : t1 = $[20];
    const rootStyle2 = t1, t2 = arrowX !== null ? arrowX : void 0, t3 = arrowY !== null ? arrowY : void 0;
    let t4;
    $[21] !== t2 || $[22] !== t3 ? (t4 = {
        left: t2,
        top: t3,
        right: void 0,
        bottom: void 0
    }, $[21] = t2, $[22] = t3, $[23] = t4) : t4 = $[23];
    const arrowStyle = t4, t5 = restProps;
    let t6;
    $[24] !== animate ? (t6 = animate ? [
        "hidden",
        "initial"
    ] : void 0, $[24] = animate, $[25] = t6) : t6 = $[25];
    let t7;
    $[26] !== animate ? (t7 = animate ? [
        "visible",
        "scaleIn"
    ] : void 0, $[26] = animate, $[27] = t7) : t7 = $[27];
    let t8;
    $[28] !== animate ? (t8 = animate ? [
        "hidden",
        "scaleOut"
    ] : void 0, $[28] = animate, $[29] = t8) : t8 = $[29];
    let t9;
    $[30] !== arrow2 || $[31] !== arrowRef || $[32] !== arrowStyle ? (t9 = arrow2 && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Arrow, {
        ref: arrowRef,
        style: arrowStyle,
        width: DEFAULT_TOOLTIP_ARROW_WIDTH,
        height: DEFAULT_TOOLTIP_ARROW_HEIGHT,
        radius: DEFAULT_TOOLTIP_ARROW_RADIUS
    }), $[30] = arrow2, $[31] = arrowRef, $[32] = arrowStyle, $[33] = t9) : t9 = $[33];
    let t10;
    return $[34] !== children || $[35] !== padding || $[36] !== placement || $[37] !== radius || $[38] !== ref || $[39] !== rootStyle2 || $[40] !== scheme || $[41] !== shadow || $[42] !== t5 || $[43] !== t6 || $[44] !== t7 || $[45] !== t8 || $[46] !== t9 ? (t10 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(MotionCard, {
        "data-ui": "Tooltip__card",
        ...t5,
        "data-placement": placement,
        padding,
        radius,
        ref,
        scheme,
        shadow,
        style: rootStyle2,
        variants: POPOVER_MOTION_PROPS.card,
        transition: POPOVER_MOTION_PROPS.transition,
        initial: t6,
        animate: t7,
        exit: t8,
        children: [
            children,
            t9
        ]
    }), $[34] = children, $[35] = padding, $[36] = placement, $[37] = radius, $[38] = ref, $[39] = rootStyle2, $[40] = scheme, $[41] = shadow, $[42] = t5, $[43] = t6, $[44] = t7, $[45] = t8, $[46] = t9, $[47] = t10) : t10 = $[47], t10;
});
TooltipCard.displayName = "ForwardRef(TooltipCard)";
const TooltipDelayGroupContext = createGlobalScopedContext("@sanity/ui/context/tooltipDelayGroup", null);
function TooltipDelayGroupProvider(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9), { children, delay } = props, [isGroupActive, setIsGroupActive] = useDelayedState(!1), [openTooltipId, setOpenTooltipId] = useDelayedState(null), openDelay = typeof delay == "number" ? delay : delay?.open || 0, closeDelay = typeof delay == "number" ? delay : delay?.close || 0, t0 = isGroupActive ? 1 : openDelay;
    let t1;
    $[0] !== closeDelay || $[1] !== openTooltipId || $[2] !== setIsGroupActive || $[3] !== setOpenTooltipId || $[4] !== t0 ? (t1 = {
        setIsGroupActive,
        openTooltipId,
        setOpenTooltipId,
        openDelay: t0,
        closeDelay
    }, $[0] = closeDelay, $[1] = openTooltipId, $[2] = setIsGroupActive, $[3] = setOpenTooltipId, $[4] = t0, $[5] = t1) : t1 = $[5];
    const value = t1;
    let t2;
    return $[6] !== children || $[7] !== value ? (t2 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TooltipDelayGroupContext.Provider, {
        value,
        children
    }), $[6] = children, $[7] = value, $[8] = t2) : t2 = $[8], t2;
}
TooltipDelayGroupProvider.displayName = "TooltipDelayGroupProvider";
function useTooltipDelayGroup() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(TooltipDelayGroupContext);
}
const StyledTooltip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Layer).withConfig({
    displayName: "StyledTooltip",
    componentId: "sc-13f2zvh-0"
})`pointer-events:none;`, Tooltip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(137), boundaryElementContext = useBoundaryElement(), { layer } = useTheme_v2();
    let _boundaryElement, _fallbackPlacementsProp, _zOffset, childProp, content, delay, disabled, portalProp, restProps, scheme, t0, t1, t2, t3, t4, t5;
    $[0] !== props ? ({ animate: t0, arrow: t1, boundaryElement: _boundaryElement, children: childProp, content, disabled, fallbackPlacements: _fallbackPlacementsProp, padding: t2, placement: t3, portal: portalProp, radius: t4, scheme, shadow: t5, zOffset: _zOffset, delay, ...restProps } = props, $[0] = props, $[1] = _boundaryElement, $[2] = _fallbackPlacementsProp, $[3] = _zOffset, $[4] = childProp, $[5] = content, $[6] = delay, $[7] = disabled, $[8] = portalProp, $[9] = restProps, $[10] = scheme, $[11] = t0, $[12] = t1, $[13] = t2, $[14] = t3, $[15] = t4, $[16] = t5) : (_boundaryElement = $[1], _fallbackPlacementsProp = $[2], _zOffset = $[3], childProp = $[4], content = $[5], delay = $[6], disabled = $[7], portalProp = $[8], restProps = $[9], scheme = $[10], t0 = $[11], t1 = $[12], t2 = $[13], t3 = $[14], t4 = $[15], t5 = $[16]);
    const _animate = t0 === void 0 ? !1 : t0, arrowProp = t1 === void 0 ? !1 : t1, padding = t2 === void 0 ? 2 : t2, placementProp = t3 === void 0 ? "bottom" : t3, radius = t4 === void 0 ? 2 : t4, shadow = t5 === void 0 ? 2 : t5, boundaryElement = _boundaryElement ?? boundaryElementContext?.element, fallbackPlacementsProp = _fallbackPlacementsProp ?? DEFAULT_FALLBACK_PLACEMENTS[props.placement ?? "bottom"], zOffset = _zOffset ?? layer.tooltip.zOffset, animate = usePrefersReducedMotion() ? !1 : _animate;
    let t6;
    $[17] !== fallbackPlacementsProp ? (t6 = _getArrayProp(fallbackPlacementsProp), $[17] = fallbackPlacementsProp, $[18] = t6) : t6 = $[18];
    const fallbackPlacements = t6, ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [referenceElement, setReferenceElement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), arrowRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [tooltipMaxWidth, setTooltipMaxWidth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    let t7;
    $[19] === Symbol.for("react.memo_cache_sentinel") ? (t7 = ()=>ref.current, $[19] = t7) : t7 = $[19], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t7);
    const portal = usePortal(), portalElement = typeof portalProp == "string" ? portal.elements?.[portalProp] || null : portal.element;
    let t8;
    $[20] !== animate || $[21] !== arrowProp || $[22] !== boundaryElement || $[23] !== fallbackPlacements ? (t8 = {
        animate,
        arrowProp,
        arrowRef,
        boundaryElement,
        fallbackPlacements,
        rootBoundary: "viewport"
    }, $[20] = animate, $[21] = arrowProp, $[22] = boundaryElement, $[23] = fallbackPlacements, $[24] = t8) : t8 = $[24];
    const middleware = useMiddleware(t8);
    let t9;
    $[25] !== referenceElement ? (t9 = {
        reference: referenceElement
    }, $[25] = referenceElement, $[26] = t9) : t9 = $[26];
    let t10;
    $[27] !== middleware || $[28] !== placementProp || $[29] !== t9 ? (t10 = {
        middleware,
        placement: placementProp,
        whileElementsMounted: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["autoUpdate"],
        elements: t9
    }, $[27] = middleware, $[28] = placementProp, $[29] = t9, $[30] = t10) : t10 = $[30];
    const { floatingStyles, placement, middlewareData, refs, update } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFloating"])(t10), arrowX = middlewareData.arrow?.x, arrowY = middlewareData.arrow?.y, originX = middlewareData["@sanity/ui/origin"]?.originX, originY = middlewareData["@sanity/ui/origin"]?.originY, tooltipId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(), [isOpen, setIsOpen] = useDelayedState(!1), delayGroupContext = useTooltipDelayGroup();
    let t11;
    $[31] !== delayGroupContext ? (t11 = delayGroupContext || {}, $[31] = delayGroupContext, $[32] = t11) : t11 = $[32];
    const { setIsGroupActive, setOpenTooltipId } = t11, showTooltip = isOpen || delayGroupContext?.openTooltipId === tooltipId, isInsideGroup = delayGroupContext !== null, openDelayProp = typeof delay == "number" ? delay : delay?.open || 0, closeDelayProp = typeof delay == "number" ? delay : delay?.close || 0, openDelay = isInsideGroup ? delayGroupContext.openDelay : openDelayProp, closeDelay = isInsideGroup ? delayGroupContext.closeDelay : closeDelayProp;
    let t12;
    $[33] !== closeDelay || $[34] !== isInsideGroup || $[35] !== openDelay || $[36] !== setIsGroupActive || $[37] !== setIsOpen || $[38] !== setOpenTooltipId || $[39] !== tooltipId ? (t12 = (open, immediate)=>{
        if (isInsideGroup) if (open) {
            const groupedOpenDelay = immediate ? 0 : openDelay;
            setIsGroupActive?.(open, groupedOpenDelay), setOpenTooltipId?.(tooltipId, groupedOpenDelay);
        } else {
            const groupDeactivateDelay = closeDelay > 200 ? closeDelay : 200;
            setIsGroupActive?.(open, groupDeactivateDelay), setOpenTooltipId?.(null, immediate ? 0 : closeDelay);
        }
        else setIsOpen(open, immediate ? 0 : open ? openDelay : closeDelay);
    }, $[33] = closeDelay, $[34] = isInsideGroup, $[35] = openDelay, $[36] = setIsGroupActive, $[37] = setIsOpen, $[38] = setOpenTooltipId, $[39] = tooltipId, $[40] = t12) : t12 = $[40];
    const handleIsOpenChange = t12;
    let t13;
    $[41] !== childProp?.props || $[42] !== handleIsOpenChange ? (t13 = (e)=>{
        handleIsOpenChange(!1), childProp?.props?.onBlur?.(e);
    }, $[41] = childProp?.props, $[42] = handleIsOpenChange, $[43] = t13) : t13 = $[43];
    const handleBlur = t13;
    let t14;
    $[44] !== childProp?.props || $[45] !== handleIsOpenChange ? (t14 = (e_0)=>{
        handleIsOpenChange(!1, !0), childProp?.props.onClick?.(e_0);
    }, $[44] = childProp?.props, $[45] = handleIsOpenChange, $[46] = t14) : t14 = $[46];
    const handleClick = t14;
    let t15;
    $[47] !== childProp?.props || $[48] !== handleIsOpenChange ? (t15 = (e_1)=>{
        handleIsOpenChange(!1, !0), childProp?.props.onContextMenu?.(e_1);
    }, $[47] = childProp?.props, $[48] = handleIsOpenChange, $[49] = t15) : t15 = $[49];
    const handleContextMenu = t15;
    let t16;
    $[50] !== childProp?.props || $[51] !== handleIsOpenChange ? (t16 = (e_2)=>{
        handleIsOpenChange(!0), childProp?.props?.onFocus?.(e_2);
    }, $[50] = childProp?.props, $[51] = handleIsOpenChange, $[52] = t16) : t16 = $[52];
    const handleFocus = t16;
    let t17;
    $[53] !== childProp?.props || $[54] !== handleIsOpenChange ? (t17 = (e_3)=>{
        handleIsOpenChange(!0), childProp?.props?.onMouseEnter?.(e_3);
    }, $[53] = childProp?.props, $[54] = handleIsOpenChange, $[55] = t17) : t17 = $[55];
    const handleMouseEnter = t17;
    let t18;
    $[56] !== childProp?.props || $[57] !== handleIsOpenChange ? (t18 = (e_4)=>{
        handleIsOpenChange(!1), childProp?.props?.onMouseLeave?.(e_4);
    }, $[56] = childProp?.props, $[57] = handleIsOpenChange, $[58] = t18) : t18 = $[58];
    const handleMouseLeave = t18;
    let t19;
    $[59] !== handleIsOpenChange || $[60] !== isInsideGroup || $[61] !== referenceElement || $[62] !== showTooltip ? (t19 = {
        handleIsOpenChange,
        referenceElement,
        showTooltip,
        isInsideGroup
    }, $[59] = handleIsOpenChange, $[60] = isInsideGroup, $[61] = referenceElement, $[62] = showTooltip, $[63] = t19) : t19 = $[63], useCloseOnMouseLeave(t19);
    let t20, t21;
    $[64] !== disabled || $[65] !== handleIsOpenChange || $[66] !== showTooltip ? (t20 = ()=>{
        disabled && showTooltip && handleIsOpenChange(!1);
    }, t21 = [
        disabled,
        handleIsOpenChange,
        showTooltip
    ], $[64] = disabled, $[65] = handleIsOpenChange, $[66] = showTooltip, $[67] = t20, $[68] = t21) : (t20 = $[67], t21 = $[68]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t20, t21);
    let t22, t23;
    $[69] !== content || $[70] !== handleIsOpenChange || $[71] !== showTooltip ? (t22 = ()=>{
        !content && showTooltip && handleIsOpenChange(!1);
    }, t23 = [
        content,
        handleIsOpenChange,
        showTooltip
    ], $[69] = content, $[70] = handleIsOpenChange, $[71] = showTooltip, $[72] = t22, $[73] = t23) : (t22 = $[72], t23 = $[73]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t22, t23);
    let t24, t25;
    $[74] !== handleIsOpenChange || $[75] !== showTooltip ? (t24 = ()=>{
        if (!showTooltip) return;
        const handleWindowKeyDown = function(event) {
            event.key === "Escape" && handleIsOpenChange(!1, !0);
        };
        return window.addEventListener("keydown", handleWindowKeyDown), ()=>{
            window.removeEventListener("keydown", handleWindowKeyDown);
        };
    }, t25 = [
        handleIsOpenChange,
        showTooltip
    ], $[74] = handleIsOpenChange, $[75] = showTooltip, $[76] = t24, $[77] = t25) : (t24 = $[76], t25 = $[77]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t24, t25);
    let t26;
    $[78] !== boundaryElement || $[79] !== portalElement?.offsetWidth ? (t26 = ()=>{
        const availableWidths = [
            ...boundaryElement ? [
                boundaryElement.offsetWidth
            ] : [],
            portalElement?.offsetWidth || document.body.offsetWidth
        ];
        setTooltipMaxWidth(Math.min(...availableWidths) - DEFAULT_TOOLTIP_PADDING * 2);
    }, $[78] = boundaryElement, $[79] = portalElement?.offsetWidth, $[80] = t26) : t26 = $[80];
    let t27;
    $[81] !== boundaryElement || $[82] !== portalElement ? (t27 = [
        boundaryElement,
        portalElement
    ], $[81] = boundaryElement, $[82] = portalElement, $[83] = t27) : t27 = $[83], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])(t26, t27);
    let t28;
    $[84] !== update ? (t28 = (arrowEl)=>{
        arrowRef.current = arrowEl, update();
    }, $[84] = update, $[85] = t28) : t28 = $[85];
    const setArrow = t28;
    let t29;
    $[86] !== refs ? (t29 = (node)=>{
        ref.current = node, refs.setFloating(node);
    }, $[86] = refs, $[87] = t29) : t29 = $[87];
    const setFloating = t29;
    let t30;
    bb0: {
        if (!childProp) {
            t30 = null;
            break bb0;
        }
        let t312;
        $[88] !== childProp || $[89] !== handleBlur || $[90] !== handleClick || $[91] !== handleContextMenu || $[92] !== handleFocus || $[93] !== handleMouseEnter || $[94] !== handleMouseLeave ? (t312 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"])(childProp, {
            onBlur: handleBlur,
            onFocus: handleFocus,
            onMouseEnter: handleMouseEnter,
            onMouseLeave: handleMouseLeave,
            onClick: handleClick,
            onContextMenu: handleContextMenu,
            ref: setReferenceElement
        }), $[88] = childProp, $[89] = handleBlur, $[90] = handleClick, $[91] = handleContextMenu, $[92] = handleFocus, $[93] = handleMouseEnter, $[94] = handleMouseLeave, $[95] = t312) : t312 = $[95], t30 = t312;
    }
    const child = t30;
    let t31;
    $[96] !== childProp ? (t31 = childProp ? getElementRef(childProp) : null, $[96] = childProp, $[97] = t31) : t31 = $[97];
    let t32, t33;
    if ($[98] !== referenceElement ? (t32 = ()=>referenceElement, t33 = [
        referenceElement
    ], $[98] = referenceElement, $[99] = t32, $[100] = t33) : (t32 = $[99], t33 = $[100]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(t31, t32, t33), !child) {
        let t342;
        return $[101] === Symbol.for("react.memo_cache_sentinel") ? (t342 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {}), $[101] = t342) : t342 = $[101], t342;
    }
    if (disabled) return child;
    const t34 = tooltipMaxWidth > 0 ? `${tooltipMaxWidth}px` : void 0;
    let t35;
    $[102] !== floatingStyles || $[103] !== t34 ? (t35 = {
        ...floatingStyles,
        maxWidth: t34
    }, $[102] = floatingStyles, $[103] = t34, $[104] = t35) : t35 = $[104];
    let t36;
    $[105] !== animate || $[106] !== arrowProp || $[107] !== arrowX || $[108] !== arrowY || $[109] !== content || $[110] !== originX || $[111] !== originY || $[112] !== padding || $[113] !== placement || $[114] !== radius || $[115] !== restProps || $[116] !== scheme || $[117] !== setArrow || $[118] !== setFloating || $[119] !== shadow ? (t36 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TooltipCard, {
        ...restProps,
        animate,
        arrow: arrowProp,
        arrowRef: setArrow,
        arrowX,
        arrowY,
        originX,
        originY,
        padding,
        placement,
        radius,
        ref: setFloating,
        scheme,
        shadow,
        children: content
    }), $[105] = animate, $[106] = arrowProp, $[107] = arrowX, $[108] = arrowY, $[109] = content, $[110] = originX, $[111] = originY, $[112] = padding, $[113] = placement, $[114] = radius, $[115] = restProps, $[116] = scheme, $[117] = setArrow, $[118] = setFloating, $[119] = shadow, $[120] = t36) : t36 = $[120];
    let t37;
    $[121] !== restProps || $[122] !== setFloating || $[123] !== t35 || $[124] !== t36 || $[125] !== zOffset ? (t37 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledTooltip, {
        "data-ui": "Tooltip",
        ...restProps,
        ref: setFloating,
        style: t35,
        zOffset,
        children: t36
    }), $[121] = restProps, $[122] = setFloating, $[123] = t35, $[124] = t36, $[125] = zOffset, $[126] = t37) : t37 = $[126];
    const tooltip = t37;
    let t38;
    $[127] !== portalProp || $[128] !== showTooltip || $[129] !== tooltip ? (t38 = showTooltip && (portalProp ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Portal, {
        __unstable_name: typeof portalProp == "string" ? portalProp : void 0,
        children: tooltip
    }) : tooltip), $[127] = portalProp, $[128] = showTooltip, $[129] = tooltip, $[130] = t38) : t38 = $[130];
    const children = t38;
    let t39;
    $[131] !== animate || $[132] !== children ? (t39 = animate ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
        children
    }) : children, $[131] = animate, $[132] = children, $[133] = t39) : t39 = $[133];
    let t40;
    return $[134] !== child || $[135] !== t39 ? (t40 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            t39,
            child
        ]
    }), $[134] = child, $[135] = t39, $[136] = t40) : t40 = $[136], t40;
});
Tooltip.displayName = "ForwardRef(Tooltip)";
function useMiddleware(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17), { animate, arrowProp, arrowRef, boundaryElement, fallbackPlacements, rootBoundary } = t0;
    let ret;
    if ($[0] !== animate || $[1] !== arrowProp || $[2] !== arrowRef || $[3] !== boundaryElement || $[4] !== fallbackPlacements || $[5] !== rootBoundary) {
        ret = [];
        const t1 = boundaryElement || void 0;
        let t2;
        $[7] !== fallbackPlacements || $[8] !== rootBoundary || $[9] !== t1 ? (t2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["flip"])({
            boundary: t1,
            fallbackPlacements,
            padding: DEFAULT_TOOLTIP_PADDING,
            rootBoundary
        }), $[7] = fallbackPlacements, $[8] = rootBoundary, $[9] = t1, $[10] = t2) : t2 = $[10], ret.push(t2);
        let t3;
        $[11] === Symbol.for("react.memo_cache_sentinel") ? (t3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["offset"])({
            mainAxis: DEFAULT_TOOLTIP_DISTANCE
        }), $[11] = t3) : t3 = $[11], ret.push(t3);
        const t4 = boundaryElement || void 0;
        let t5;
        if ($[12] !== rootBoundary || $[13] !== t4 ? (t5 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["shift"])({
            boundary: t4,
            rootBoundary,
            padding: DEFAULT_TOOLTIP_PADDING
        }), $[12] = rootBoundary, $[13] = t4, $[14] = t5) : t5 = $[14], ret.push(t5), arrowProp) {
            let t6;
            $[15] !== arrowRef ? (t6 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["arrow"])({
                element: arrowRef,
                padding: DEFAULT_TOOLTIP_PADDING
            }), $[15] = arrowRef, $[16] = t6) : t6 = $[16], ret.push(t6);
        }
        animate && ret.push(origin), $[0] = animate, $[1] = arrowProp, $[2] = arrowRef, $[3] = boundaryElement, $[4] = fallbackPlacements, $[5] = rootBoundary, $[6] = ret;
    } else ret = $[6];
    return ret;
}
function useCloseOnMouseLeave(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(10), { handleIsOpenChange, referenceElement, showTooltip, isInsideGroup } = t0;
    let t1;
    $[0] !== handleIsOpenChange || $[1] !== referenceElement ? (t1 = (target, teardown)=>{
        referenceElement && (referenceElement === target || target instanceof Node && referenceElement.contains(target) || (handleIsOpenChange(!1), teardown()));
    }, $[0] = handleIsOpenChange, $[1] = referenceElement, $[2] = t1) : t1 = $[2];
    const onMouseMove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$effect$2d$event$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffectEvent"])(t1);
    let t2;
    $[3] !== isInsideGroup || $[4] !== onMouseMove || $[5] !== showTooltip ? (t2 = ()=>{
        if (!showTooltip || isInsideGroup) return;
        const handleMouseMove = (event)=>{
            onMouseMove(event.target, ()=>window.removeEventListener("mousemove", handleMouseMove));
        };
        return window.addEventListener("mousemove", handleMouseMove), ()=>window.removeEventListener("mousemove", handleMouseMove);
    }, $[3] = isInsideGroup, $[4] = onMouseMove, $[5] = showTooltip, $[6] = t2) : t2 = $[6];
    let t3;
    $[7] !== isInsideGroup || $[8] !== showTooltip ? (t3 = [
        isInsideGroup,
        showTooltip
    ], $[7] = isInsideGroup, $[8] = showTooltip, $[9] = t3) : t3 = $[9], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
}
const StyledHotkeys = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].kbd.withConfig({
    displayName: "StyledHotkeys",
    componentId: "sc-b37mge-0"
})`font:inherit;padding:1px;&:not([hidden]){display:block;}`, Key = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(KBD).withConfig({
    displayName: "Key",
    componentId: "sc-b37mge-1"
})`&:not([hidden]){display:block;}`, Hotkeys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(27);
    let fontSize2, gap, keys, padding, radius, restProps, t0;
    $[0] !== props ? ({ fontSize: fontSize2, gap, keys, padding, radius, space: t0, ...restProps } = props, $[0] = props, $[1] = fontSize2, $[2] = gap, $[3] = keys, $[4] = padding, $[5] = radius, $[6] = restProps, $[7] = t0) : (fontSize2 = $[1], gap = $[2], keys = $[3], padding = $[4], radius = $[5], restProps = $[6], t0 = $[7]);
    const t1 = gap === void 0 ? t0 === void 0 ? 0.5 : t0 : gap;
    let t2;
    $[8] !== t1 ? (t2 = _getArrayProp(t1), $[8] = t1, $[9] = t2) : t2 = $[9];
    const spacing = t2;
    if (!keys || keys.length === 0) {
        let t32;
        return $[10] === Symbol.for("react.memo_cache_sentinel") ? (t32 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {}), $[10] = t32) : t32 = $[10], t32;
    }
    let t3;
    if ($[11] !== fontSize2 || $[12] !== keys || $[13] !== padding || $[14] !== radius) {
        let t42;
        $[16] !== fontSize2 || $[17] !== padding || $[18] !== radius ? (t42 = (key2, i)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Key, {
                fontSize: fontSize2,
                padding,
                radius,
                children: key2
            }, i), $[16] = fontSize2, $[17] = padding, $[18] = radius, $[19] = t42) : t42 = $[19], t3 = keys.map(t42), $[11] = fontSize2, $[12] = keys, $[13] = padding, $[14] = radius, $[15] = t3;
    } else t3 = $[15];
    let t4;
    $[20] !== spacing || $[21] !== t3 ? (t4 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Inline, {
        as: "span",
        gap: spacing,
        children: t3
    }), $[20] = spacing, $[21] = t3, $[22] = t4) : t4 = $[22];
    let t5;
    return $[23] !== ref || $[24] !== restProps || $[25] !== t4 ? (t5 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledHotkeys, {
        "data-ui": "Hotkeys",
        ...restProps,
        ref,
        children: t4
    }), $[23] = ref, $[24] = restProps, $[25] = t4, $[26] = t5) : t5 = $[26], t5;
});
Hotkeys.displayName = "ForwardRef(Hotkeys)";
const MenuContext = createGlobalScopedContext("@sanity/ui/context/menu", null);
function _isFocusable(element) {
    return isHTMLAnchorElement(element) && element.getAttribute("data-disabled") !== "true" || isHTMLButtonElement(element) && !element.disabled;
}
function _getFocusableElements(elements) {
    return elements.filter(_isFocusable);
}
function _getDOMPath(rootElement, el) {
    const path = [];
    let e = el;
    for(; e !== rootElement;){
        const parentElement = e.parentElement;
        if (!parentElement) return path;
        const index = Array.from(parentElement.childNodes).indexOf(e);
        if (path.unshift(index), parentElement === rootElement) return path;
        e = parentElement;
    }
    return path;
}
const EMPTY_PATH = [];
function _sortElements(rootElement, elements) {
    if (!rootElement) return;
    const map = /* @__PURE__ */ new WeakMap();
    for (const el of elements)map.set(el, _getDOMPath(rootElement, el));
    const _sort = (a, b)=>{
        const _a = map.get(a) || EMPTY_PATH, _b = map.get(b) || EMPTY_PATH, len = Math.max(_a.length, _b.length);
        for(let i = 0; i < len; i += 1){
            const aIndex = _a[i] || -1, bIndex = _b[i] || -1;
            if (aIndex !== bIndex) return aIndex - bIndex;
        }
        return 0;
    };
    elements.sort(_sort);
}
function useMenuController(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(21), { onKeyDown, originElement, shouldFocus, rootElementRef } = props;
    let t0;
    $[0] === Symbol.for("react.memo_cache_sentinel") ? (t0 = [], $[0] = t0) : t0 = $[0];
    const elementsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(t0), [activeIndex, _setActiveIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1), activeIndexRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(activeIndex), [activeElement, setActiveElement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t1;
    $[1] === Symbol.for("react.memo_cache_sentinel") ? (t1 = (nextActiveIndex)=>{
        _setActiveIndex(nextActiveIndex), activeIndexRef.current = nextActiveIndex, setActiveElement(elementsRef.current[nextActiveIndex] || null);
    }, $[1] = t1) : t1 = $[1];
    const setActiveIndex = t1;
    let t2;
    $[2] !== rootElementRef ? (t2 = (element, selected)=>{
        if (!element) return _temp$1;
        if (elementsRef.current.indexOf(element) === -1 && (elementsRef.current.push(element), _sortElements(rootElementRef.current, elementsRef.current)), selected) {
            const selectedIndex = elementsRef.current.indexOf(element);
            setActiveIndex(selectedIndex);
        }
        return ()=>{
            const idx = elementsRef.current.indexOf(element);
            idx > -1 && elementsRef.current.splice(idx, 1);
        };
    }, $[2] = rootElementRef, $[3] = t2) : t2 = $[3];
    const mount = t2;
    let t3;
    $[4] !== onKeyDown || $[5] !== originElement ? (t3 = (event)=>{
        if (event.key === "Tab") {
            originElement && originElement.focus();
            return;
        }
        if (event.key === "Home") {
            event.preventDefault(), event.stopPropagation();
            const el = _getFocusableElements(elementsRef.current)[0];
            if (!el) return;
            const currentIndex = elementsRef.current.indexOf(el);
            setActiveIndex(currentIndex);
            return;
        }
        if (event.key === "End") {
            event.preventDefault(), event.stopPropagation();
            const focusableElements_0 = _getFocusableElements(elementsRef.current), el_0 = focusableElements_0[focusableElements_0.length - 1];
            if (!el_0) return;
            const currentIndex_0 = elementsRef.current.indexOf(el_0);
            setActiveIndex(currentIndex_0);
            return;
        }
        if (event.key === "ArrowUp") {
            event.preventDefault(), event.stopPropagation();
            const focusableElements_1 = _getFocusableElements(elementsRef.current), focusableLen = focusableElements_1.length;
            if (focusableLen === 0) return;
            const focusedElement = elementsRef.current[activeIndexRef.current];
            let focusedIndex = focusableElements_1.indexOf(focusedElement);
            focusedIndex = (focusedIndex - 1 + focusableLen) % focusableLen;
            const el_1 = focusableElements_1[focusedIndex], currentIndex_1 = elementsRef.current.indexOf(el_1);
            setActiveIndex(currentIndex_1);
            return;
        }
        if (event.key === "ArrowDown") {
            event.preventDefault(), event.stopPropagation();
            const focusableElements_2 = _getFocusableElements(elementsRef.current), focusableLen_0 = focusableElements_2.length;
            if (focusableLen_0 === 0) return;
            const focusedElement_0 = elementsRef.current[activeIndexRef.current];
            let focusedIndex_0 = focusableElements_2.indexOf(focusedElement_0);
            focusedIndex_0 = (focusedIndex_0 + 1) % focusableLen_0;
            const el_2 = focusableElements_2[focusedIndex_0], currentIndex_2 = elementsRef.current.indexOf(el_2);
            setActiveIndex(currentIndex_2);
            return;
        }
        onKeyDown && onKeyDown(event);
    }, $[4] = onKeyDown, $[5] = originElement, $[6] = t3) : t3 = $[6];
    const handleKeyDown = t3;
    let t4;
    $[7] === Symbol.for("react.memo_cache_sentinel") ? (t4 = (event_0)=>{
        const element_0 = event_0.currentTarget, currentIndex_3 = elementsRef.current.indexOf(element_0);
        setActiveIndex(currentIndex_3);
    }, $[7] = t4) : t4 = $[7];
    const handleItemMouseEnter = t4;
    let t5;
    $[8] !== rootElementRef ? (t5 = ()=>{
        setActiveIndex(-2), rootElementRef.current?.focus();
    }, $[8] = rootElementRef, $[9] = t5) : t5 = $[9];
    const handleItemMouseLeave = t5;
    let t6, t7;
    $[10] !== activeIndex || $[11] !== rootElementRef || $[12] !== shouldFocus ? (t6 = ()=>{
        if (!rootElementRef.current) return;
        const rafId = requestAnimationFrame(()=>{
            if (activeIndex === -1) {
                if (shouldFocus === "first") {
                    const el_3 = _getFocusableElements(elementsRef.current)[0];
                    if (el_3) {
                        const currentIndex_4 = elementsRef.current.indexOf(el_3);
                        setActiveIndex(currentIndex_4);
                    }
                }
                if (shouldFocus === "last") {
                    const focusableElements_4 = _getFocusableElements(elementsRef.current), el_4 = focusableElements_4[focusableElements_4.length - 1];
                    if (el_4) {
                        const currentIndex_5 = elementsRef.current.indexOf(el_4);
                        setActiveIndex(currentIndex_5);
                    }
                }
                return;
            }
            (elementsRef.current[activeIndex] || null)?.focus();
        });
        return ()=>cancelAnimationFrame(rafId);
    }, t7 = [
        activeIndex,
        rootElementRef,
        setActiveIndex,
        shouldFocus
    ], $[10] = activeIndex, $[11] = rootElementRef, $[12] = shouldFocus, $[13] = t6, $[14] = t7) : (t6 = $[13], t7 = $[14]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t6, t7);
    let t8;
    return $[15] !== activeElement || $[16] !== activeIndex || $[17] !== handleItemMouseLeave || $[18] !== handleKeyDown || $[19] !== mount ? (t8 = {
        activeElement,
        activeIndex,
        handleItemMouseEnter,
        handleItemMouseLeave,
        handleKeyDown,
        mount
    }, $[15] = activeElement, $[16] = activeIndex, $[17] = handleItemMouseLeave, $[18] = handleKeyDown, $[19] = mount, $[20] = t8) : t8 = $[20], t8;
}
function _temp$1() {}
const StyledMenu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Box).withConfig({
    displayName: "StyledMenu",
    componentId: "sc-xt0tnv-0"
})`outline:none;overflow:auto;`, Menu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(50);
    let _shouldFocus, children, gap, onClickOutside, onEscape, onItemClick, onItemSelect, onKeyDown, originElement, registerElement, restProps, t0, t1;
    if ($[0] !== props) {
        const { children: t22, focusFirst, focusLast, onClickOutside: t32, onEscape: t42, onItemClick: t52, onItemSelect: t62, onKeyDown: t72, originElement: t82, padding: t92, registerElement: t102, shouldFocus: t112, gap: t122, space: t13, ...t14 } = props;
        children = t22, onClickOutside = t32, onEscape = t42, onItemClick = t52, onItemSelect = t62, onKeyDown = t72, originElement = t82, t0 = t92, registerElement = t102, _shouldFocus = t112, gap = t122, t1 = t13, restProps = t14, $[0] = props, $[1] = _shouldFocus, $[2] = children, $[3] = gap, $[4] = onClickOutside, $[5] = onEscape, $[6] = onItemClick, $[7] = onItemSelect, $[8] = onKeyDown, $[9] = originElement, $[10] = registerElement, $[11] = restProps, $[12] = t0, $[13] = t1;
    } else _shouldFocus = $[1], children = $[2], gap = $[3], onClickOutside = $[4], onEscape = $[5], onItemClick = $[6], onItemSelect = $[7], onKeyDown = $[8], originElement = $[9], registerElement = $[10], restProps = $[11], t0 = $[12], t1 = $[13];
    const padding = t0 === void 0 ? 1 : t0, spacing = gap === void 0 ? t1 === void 0 ? 1 : t1 : gap, shouldFocus = _shouldFocus ?? (props.focusFirst && "first" || props.focusLast && "last" || null), ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t2;
    $[14] === Symbol.for("react.memo_cache_sentinel") ? (t2 = ()=>ref.current, $[14] = t2) : t2 = $[14], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t2);
    const { isTopLayer } = useLayer();
    let t3;
    $[15] !== onKeyDown || $[16] !== originElement || $[17] !== shouldFocus ? (t3 = {
        onKeyDown,
        originElement,
        shouldFocus,
        rootElementRef: ref
    }, $[15] = onKeyDown, $[16] = originElement, $[17] = shouldFocus, $[18] = t3) : t3 = $[18];
    const { activeElement, activeIndex, handleItemMouseEnter, handleItemMouseLeave, handleKeyDown, mount } = useMenuController(t3), unregisterElementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t4;
    $[19] !== registerElement ? (t4 = (el)=>{
        unregisterElementRef.current && (unregisterElementRef.current(), unregisterElementRef.current = null), ref.current = el, ref.current && registerElement && (unregisterElementRef.current = registerElement(ref.current));
    }, $[19] = registerElement, $[20] = t4) : t4 = $[20];
    const handleRefChange = t4;
    let t5, t6;
    $[21] !== activeIndex || $[22] !== onItemSelect ? (t5 = ()=>{
        onItemSelect && onItemSelect(activeIndex);
    }, t6 = [
        activeIndex,
        onItemSelect
    ], $[21] = activeIndex, $[22] = onItemSelect, $[23] = t5, $[24] = t6) : (t5 = $[23], t6 = $[24]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    let t7;
    $[25] === Symbol.for("react.memo_cache_sentinel") ? (t7 = ()=>[
            ref.current
        ], $[25] = t7) : t7 = $[25], useClickOutsideEvent(isTopLayer && onClickOutside, t7);
    let t8;
    $[26] !== isTopLayer || $[27] !== onEscape ? (t8 = (event)=>{
        isTopLayer && event.key === "Escape" && (event.stopPropagation(), onEscape && onEscape());
    }, $[26] = isTopLayer, $[27] = onEscape, $[28] = t8) : t8 = $[28], useGlobalKeyDown(t8);
    let t9;
    $[29] !== activeElement || $[30] !== handleItemMouseEnter || $[31] !== handleItemMouseLeave || $[32] !== mount || $[33] !== onClickOutside || $[34] !== onEscape || $[35] !== onItemClick || $[36] !== registerElement ? (t9 = {
        version: 2,
        activeElement,
        mount,
        onClickOutside,
        onEscape,
        onItemClick,
        onItemMouseEnter: handleItemMouseEnter,
        onItemMouseLeave: handleItemMouseLeave,
        registerElement
    }, $[29] = activeElement, $[30] = handleItemMouseEnter, $[31] = handleItemMouseLeave, $[32] = mount, $[33] = onClickOutside, $[34] = onEscape, $[35] = onItemClick, $[36] = registerElement, $[37] = t9) : t9 = $[37];
    const value = t9;
    let t10;
    $[38] !== children || $[39] !== spacing ? (t10 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Stack, {
        gap: spacing,
        children
    }), $[38] = children, $[39] = spacing, $[40] = t10) : t10 = $[40];
    let t11;
    $[41] !== handleKeyDown || $[42] !== handleRefChange || $[43] !== padding || $[44] !== restProps || $[45] !== t10 ? (t11 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledMenu, {
        "data-ui": "Menu",
        ...restProps,
        onKeyDown: handleKeyDown,
        padding,
        ref: handleRefChange,
        role: "menu",
        tabIndex: -1,
        children: t10
    }), $[41] = handleKeyDown, $[42] = handleRefChange, $[43] = padding, $[44] = restProps, $[45] = t10, $[46] = t11) : t11 = $[46];
    let t12;
    return $[47] !== t11 || $[48] !== value ? (t12 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(MenuContext.Provider, {
        value,
        children: t11
    }), $[47] = t11, $[48] = value, $[49] = t12) : t12 = $[49], t12;
});
Menu.displayName = "ForwardRef(Menu)";
const MenuDivider = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].hr.withConfig({
    displayName: "MenuDivider",
    componentId: "sc-uhoxwu-0"
})`height:1px;border:0;background:var(--card-hairline-soft-color);margin:0;`;
MenuDivider.displayName = "MenuDivider";
function selectableBaseStyle() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    background-color: inherit;
    color: inherit;

    &[data-as='button'] {
      -webkit-font-smoothing: inherit;
      appearance: none;
      outline: none;
      font: inherit;
      text-align: inherit;
      border: 0;
      width: -moz-available;
      width: -webkit-fill-available;
      width: stretch;
    }

    /* &:is(a) */
    &[data-as='a'] {
      text-decoration: none;
    }
  `;
}
function selectableColorStyle(props) {
    const { $tone } = props, { color, style } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), tone = color.selectable[$tone];
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    ${_cardColorStyle(color, tone.enabled)}

    background-color: var(--card-bg-color);
    color: var(--card-fg-color);
    outline: none;

    /* &:is(button) */
    &[data-as='button'] {
      &:disabled {
        ${_cardColorStyle(color, tone.disabled)}
      }

      &:not(:disabled) {
        &[aria-pressed='true'] {
          ${_cardColorStyle(color, tone.pressed)}
        }

        &[data-selected],
        &[aria-selected='true'] > & {
          ${_cardColorStyle(color, tone.selected)}
        }

        @media (hover: hover) {
          &:not([data-selected]) {
            &[data-hovered],
            &:hover {
              ${_cardColorStyle(color, tone.hovered)}
            }

            &:active {
              ${_cardColorStyle(color, tone.pressed)}
            }
          }
        }
      }
    }

    /* &:is(a) */
    &[data-as='a'] {
      &[data-disabled] {
        ${_cardColorStyle(color, tone.disabled)}
      }

      &:not([data-disabled]) {
        &[data-pressed] {
          ${_cardColorStyle(color, tone.pressed)}
        }

        &[data-selected] {
          ${_cardColorStyle(color, tone.selected)}
        }

        @media (hover: hover) {
          &:not([data-selected]) {
            &[data-hovered],
            &:hover {
              ${_cardColorStyle(color, tone.hovered)}
            }
            &:active {
              ${_cardColorStyle(color, tone.pressed)}
            }
          }
        }
      }
    }

    ${style?.card?.root}
  `;
}
const Selectable = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Box).withConfig({
    displayName: "Selectable",
    componentId: "sc-1w01ang-0"
})(responsiveRadiusStyle, selectableBaseStyle, selectableColorStyle);
Selectable.displayName = "Selectable";
function useMenu() {
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(MenuContext);
    if (!value) throw new Error("useMenu(): missing context value");
    if (!isRecord(value) || value.version !== 2) throw new Error("useMenu(): the context value is not compatible");
    return value;
}
function MenuGroup(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(82);
    let IconComponent, children, gap, menuProps, onClick, popover, restProps, t0, t1, t2, t3, t4, t5, text;
    $[0] !== props ? ({ as: t0, children, fontSize: t1, icon: IconComponent, menu: menuProps, onClick, padding: t2, popover, radius: t3, gap, space: t4, text, tone: t5, ...restProps } = props, $[0] = props, $[1] = IconComponent, $[2] = children, $[3] = gap, $[4] = menuProps, $[5] = onClick, $[6] = popover, $[7] = restProps, $[8] = t0, $[9] = t1, $[10] = t2, $[11] = t3, $[12] = t4, $[13] = t5, $[14] = text) : (IconComponent = $[1], children = $[2], gap = $[3], menuProps = $[4], onClick = $[5], popover = $[6], restProps = $[7], t0 = $[8], t1 = $[9], t2 = $[10], t3 = $[11], t4 = $[12], t5 = $[13], text = $[14]);
    const as = t0 === void 0 ? "button" : t0, fontSize2 = t1 === void 0 ? 1 : t1, padding = t2 === void 0 ? 3 : t2, radius = t3 === void 0 ? 2 : t3, deprecated_space = t4 === void 0 ? 3 : t4, tone = t5 === void 0 ? "default" : t5, spacing = gap === void 0 ? deprecated_space : gap, menu = useMenu(), { scheme } = useRootTheme(), { activeElement, mount, onClickOutside, onEscape, onItemClick, onItemMouseEnter: _onItemMouseEnter, registerElement } = menu, onItemMouseEnter = _onItemMouseEnter ?? menu.onItemMouseEnter, [rootElement, setRootElement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), [shouldFocus, setShouldFocus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), active = !!activeElement && activeElement === rootElement, [withinMenu, setWithinMenu] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1);
    let t6;
    $[15] !== onItemMouseEnter ? (t6 = (event)=>{
        setWithinMenu(!1), onItemMouseEnter(event), setOpen(!0);
    }, $[15] = onItemMouseEnter, $[16] = t6) : t6 = $[16];
    const handleMouseEnter = t6;
    let t7;
    $[17] !== rootElement ? (t7 = (event_0)=>{
        event_0.key === "ArrowLeft" && (event_0.stopPropagation(), setOpen(!1), requestAnimationFrame(()=>{
            rootElement?.focus();
        }));
    }, $[17] = rootElement, $[18] = t7) : t7 = $[18];
    const handleMenuKeyDown = t7;
    let t8;
    $[19] !== onClick ? (t8 = (event_1)=>{
        onClick?.(event_1), setShouldFocus("first"), setOpen(!0);
    }, $[19] = onClick, $[20] = t8) : t8 = $[20];
    const handleClick = t8;
    let t9;
    $[21] !== onItemClick ? (t9 = ()=>{
        setOpen(!1), onItemClick?.();
    }, $[21] = onItemClick, $[22] = t9) : t9 = $[22];
    const handleChildItemClick = t9;
    let t10;
    $[23] === Symbol.for("react.memo_cache_sentinel") ? (t10 = ()=>setWithinMenu(!0), $[23] = t10) : t10 = $[23];
    const handleMenuMouseEnter = t10;
    let t11, t12;
    $[24] !== mount || $[25] !== rootElement ? (t11 = ()=>mount(rootElement), t12 = [
        mount,
        rootElement
    ], $[24] = mount, $[25] = rootElement, $[26] = t11, $[27] = t12) : (t11 = $[26], t12 = $[27]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t11, t12);
    let t13, t14;
    $[28] !== active ? (t13 = ()=>{
        active || setOpen(!1);
    }, t14 = [
        active
    ], $[28] = active, $[29] = t13, $[30] = t14) : (t13 = $[29], t14 = $[30]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t13, t14);
    let t15, t16;
    $[31] !== open ? (t15 = ()=>{
        open || setWithinMenu(!1);
    }, t16 = [
        open
    ], $[31] = open, $[32] = t15, $[33] = t16) : (t15 = $[32], t16 = $[33]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t15, t16);
    let t17, t18;
    $[34] !== shouldFocus ? (t17 = ()=>{
        if (!shouldFocus) return;
        const rafId = requestAnimationFrame(()=>setShouldFocus(null));
        return ()=>cancelAnimationFrame(rafId);
    }, t18 = [
        shouldFocus
    ], $[34] = shouldFocus, $[35] = t17, $[36] = t18) : (t17 = $[35], t18 = $[36]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t17, t18);
    let t19;
    $[37] !== children || $[38] !== handleChildItemClick || $[39] !== handleMenuKeyDown || $[40] !== menuProps || $[41] !== onClickOutside || $[42] !== onEscape || $[43] !== registerElement || $[44] !== shouldFocus ? (t19 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Menu, {
        ...menuProps,
        onClickOutside,
        onEscape,
        onItemClick: handleChildItemClick,
        onKeyDown: handleMenuKeyDown,
        onMouseEnter: handleMenuMouseEnter,
        registerElement,
        shouldFocus,
        children
    }), $[37] = children, $[38] = handleChildItemClick, $[39] = handleMenuKeyDown, $[40] = menuProps, $[41] = onClickOutside, $[42] = onEscape, $[43] = registerElement, $[44] = shouldFocus, $[45] = t19) : t19 = $[45];
    const childMenu = t19;
    let t20;
    $[46] === Symbol.for("react.memo_cache_sentinel") ? (t20 = (event_2)=>{
        const target = event_2.currentTarget;
        if (document.activeElement === target && event_2.key === "ArrowRight") {
            setShouldFocus("first"), setOpen(!0), setWithinMenu(!0);
            return;
        }
    }, $[46] = t20) : t20 = $[46];
    const handleKeyDown = t20, t21 = as === "button" ? withinMenu : void 0, t22 = as !== "button" ? withinMenu : void 0, t23 = !withinMenu && active ? "" : void 0;
    let t24;
    $[47] !== radius ? (t24 = _getArrayProp(radius), $[47] = radius, $[48] = t24) : t24 = $[48];
    const t25 = as === "button" ? "button" : void 0;
    let t26;
    $[49] !== IconComponent || $[50] !== fontSize2 ? (t26 = IconComponent && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Text, {
        size: fontSize2,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(IconComponent) && IconComponent,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElementType"])(IconComponent) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(IconComponent, {})
        ]
    }), $[49] = IconComponent, $[50] = fontSize2, $[51] = t26) : t26 = $[51];
    let t27;
    $[52] !== fontSize2 || $[53] !== text ? (t27 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Box, {
        flex: 1,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Text, {
            size: fontSize2,
            textOverflow: "ellipsis",
            weight: "medium",
            children: text
        })
    }), $[52] = fontSize2, $[53] = text, $[54] = t27) : t27 = $[54];
    let t28;
    $[55] === Symbol.for("react.memo_cache_sentinel") ? (t28 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChevronRightIcon"], {}), $[55] = t28) : t28 = $[55];
    let t29;
    $[56] !== fontSize2 ? (t29 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Text, {
        size: fontSize2,
        children: t28
    }), $[56] = fontSize2, $[57] = t29) : t29 = $[57];
    let t30;
    $[58] !== padding || $[59] !== spacing || $[60] !== t26 || $[61] !== t27 || $[62] !== t29 ? (t30 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Flex, {
        gap: spacing,
        padding,
        children: [
            t26,
            t27,
            t29
        ]
    }), $[58] = padding, $[59] = spacing, $[60] = t26, $[61] = t27, $[62] = t29, $[63] = t30) : t30 = $[63];
    let t31;
    $[64] !== as || $[65] !== handleClick || $[66] !== handleMouseEnter || $[67] !== restProps || $[68] !== scheme || $[69] !== t21 || $[70] !== t22 || $[71] !== t23 || $[72] !== t24 || $[73] !== t25 || $[74] !== t30 || $[75] !== tone ? (t31 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Selectable, {
        "data-as": as,
        "data-ui": "MenuGroup",
        forwardedAs: as,
        ...restProps,
        "aria-pressed": t21,
        "data-pressed": t22,
        "data-selected": t23,
        $radius: t24,
        $tone: tone,
        $scheme: scheme,
        onClick: handleClick,
        onKeyDown: handleKeyDown,
        onMouseEnter: handleMouseEnter,
        ref: setRootElement,
        tabIndex: -1,
        type: t25,
        children: t30
    }), $[64] = as, $[65] = handleClick, $[66] = handleMouseEnter, $[67] = restProps, $[68] = scheme, $[69] = t21, $[70] = t22, $[71] = t23, $[72] = t24, $[73] = t25, $[74] = t30, $[75] = tone, $[76] = t31) : t31 = $[76];
    let t32;
    return $[77] !== childMenu || $[78] !== open || $[79] !== popover || $[80] !== t31 ? (t32 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Popover, {
        ...popover,
        content: childMenu,
        "data-ui": "MenuGroup__popover",
        open,
        children: t31
    }), $[77] = childMenu, $[78] = open, $[79] = popover, $[80] = t31, $[81] = t32) : t32 = $[81], t32;
}
MenuGroup.displayName = "MenuGroup";
const MenuItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(76);
    let IconComponent, IconRightComponent, children, disabled, gap, hotkeys, onClick, paddingBottom, paddingLeft, paddingRight, paddingTop, paddingX, paddingY, pressed, restProps, selectedProp, t0, t1, t2, t3, t4, t5, text;
    $[0] !== props ? ({ as: t0, children, disabled, fontSize: t1, hotkeys, icon: IconComponent, iconRight: IconRightComponent, onClick, padding: t2, paddingX, paddingY, paddingTop, paddingRight, paddingBottom, paddingLeft, pressed, radius: t3, selected: selectedProp, gap, space: t4, text, tone: t5, ...restProps } = props, $[0] = props, $[1] = IconComponent, $[2] = IconRightComponent, $[3] = children, $[4] = disabled, $[5] = gap, $[6] = hotkeys, $[7] = onClick, $[8] = paddingBottom, $[9] = paddingLeft, $[10] = paddingRight, $[11] = paddingTop, $[12] = paddingX, $[13] = paddingY, $[14] = pressed, $[15] = restProps, $[16] = selectedProp, $[17] = t0, $[18] = t1, $[19] = t2, $[20] = t3, $[21] = t4, $[22] = t5, $[23] = text) : (IconComponent = $[1], IconRightComponent = $[2], children = $[3], disabled = $[4], gap = $[5], hotkeys = $[6], onClick = $[7], paddingBottom = $[8], paddingLeft = $[9], paddingRight = $[10], paddingTop = $[11], paddingX = $[12], paddingY = $[13], pressed = $[14], restProps = $[15], selectedProp = $[16], t0 = $[17], t1 = $[18], t2 = $[19], t3 = $[20], t4 = $[21], t5 = $[22], text = $[23]);
    const as = t0 === void 0 ? "button" : t0, fontSize2 = t1 === void 0 ? 1 : t1, padding = t2 === void 0 ? 3 : t2, radius = t3 === void 0 ? 2 : t3, deprecated_space = t4 === void 0 ? 3 : t4, tone = t5 === void 0 ? "default" : t5, spacing = gap === void 0 ? deprecated_space : gap, { scheme } = useRootTheme(), menu = useMenu(), { activeElement, mount, onItemClick, onItemMouseEnter: _onItemMouseEnter, onItemMouseLeave: _onItemMouseLeave } = menu, onItemMouseEnter = _onItemMouseEnter ?? menu.onItemMouseEnter, onItemMouseLeave = _onItemMouseLeave ?? menu.onItemMouseLeave, [rootElement, setRootElement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), active = !!activeElement && activeElement === rootElement, ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t6;
    $[24] === Symbol.for("react.memo_cache_sentinel") ? (t6 = ()=>ref.current, $[24] = t6) : t6 = $[24], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t6);
    let t7, t8;
    $[25] !== mount || $[26] !== rootElement || $[27] !== selectedProp ? (t7 = ()=>mount(rootElement, selectedProp), t8 = [
        mount,
        rootElement,
        selectedProp
    ], $[25] = mount, $[26] = rootElement, $[27] = selectedProp, $[28] = t7, $[29] = t8) : (t7 = $[28], t8 = $[29]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t7, t8);
    let t9;
    $[30] !== disabled || $[31] !== onClick || $[32] !== onItemClick ? (t9 = (event)=>{
        disabled || (onClick && onClick(event), onItemClick && onItemClick());
    }, $[30] = disabled, $[31] = onClick, $[32] = onItemClick, $[33] = t9) : t9 = $[33];
    const handleClick = t9;
    let t10;
    $[34] !== padding || $[35] !== paddingBottom || $[36] !== paddingLeft || $[37] !== paddingRight || $[38] !== paddingTop || $[39] !== paddingX || $[40] !== paddingY ? (t10 = {
        padding,
        paddingX,
        paddingY,
        paddingTop,
        paddingRight,
        paddingBottom,
        paddingLeft
    }, $[34] = padding, $[35] = paddingBottom, $[36] = paddingLeft, $[37] = paddingRight, $[38] = paddingTop, $[39] = paddingX, $[40] = paddingY, $[41] = t10) : t10 = $[41];
    const paddingProps = t10;
    let t11;
    $[42] !== fontSize2 ? (t11 = _getArrayProp(fontSize2).map(_temp), $[42] = fontSize2, $[43] = t11) : t11 = $[43];
    const hotkeysFontSize = t11;
    let t12;
    $[44] === Symbol.for("react.memo_cache_sentinel") ? (t12 = (el)=>{
        ref.current = el, setRootElement(el);
    }, $[44] = t12) : t12 = $[44];
    const setRef = t12, t13 = as !== "button" && pressed ? "" : void 0, t14 = active ? "" : void 0, t15 = disabled ? "" : void 0;
    let t16;
    $[45] !== radius ? (t16 = _getArrayProp(radius), $[45] = radius, $[46] = t16) : t16 = $[46];
    let t17;
    $[47] === Symbol.for("react.memo_cache_sentinel") ? (t17 = _getArrayProp(0), $[47] = t17) : t17 = $[47];
    const t18 = disabled ? "default" : tone, t19 = as === "button" ? "button" : void 0;
    let t20;
    $[48] !== IconComponent || $[49] !== IconRightComponent || $[50] !== fontSize2 || $[51] !== hotkeys || $[52] !== hotkeysFontSize || $[53] !== paddingProps || $[54] !== spacing || $[55] !== text ? (t20 = (IconComponent || text || IconRightComponent) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Flex, {
        as: "span",
        gap: spacing,
        align: "center",
        ...paddingProps,
        children: [
            IconComponent && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Text, {
                size: fontSize2,
                children: [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(IconComponent) && IconComponent,
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElementType"])(IconComponent) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(IconComponent, {})
                ]
            }),
            text && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Box, {
                flex: 1,
                children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Text, {
                    size: fontSize2,
                    textOverflow: "ellipsis",
                    weight: "medium",
                    children: text
                })
            }),
            hotkeys && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Hotkeys, {
                fontSize: hotkeysFontSize,
                keys: hotkeys,
                style: {
                    marginTop: -4,
                    marginBottom: -4
                }
            }),
            IconRightComponent && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Text, {
                size: fontSize2,
                children: [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"])(IconRightComponent) && IconRightComponent,
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$is$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElementType"])(IconRightComponent) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(IconRightComponent, {})
                ]
            })
        ]
    }), $[48] = IconComponent, $[49] = IconRightComponent, $[50] = fontSize2, $[51] = hotkeys, $[52] = hotkeysFontSize, $[53] = paddingProps, $[54] = spacing, $[55] = text, $[56] = t20) : t20 = $[56];
    let t21;
    $[57] !== children || $[58] !== paddingProps ? (t21 = children && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Box, {
        as: "span",
        ...paddingProps,
        children
    }), $[57] = children, $[58] = paddingProps, $[59] = t21) : t21 = $[59];
    let t22;
    return $[60] !== as || $[61] !== disabled || $[62] !== handleClick || $[63] !== onItemMouseEnter || $[64] !== onItemMouseLeave || $[65] !== restProps || $[66] !== scheme || $[67] !== t13 || $[68] !== t14 || $[69] !== t15 || $[70] !== t16 || $[71] !== t18 || $[72] !== t19 || $[73] !== t20 || $[74] !== t21 ? (t22 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Selectable, {
        "data-ui": "MenuItem",
        role: "menuitem",
        ...restProps,
        "data-pressed": t13,
        "data-selected": t14,
        "data-disabled": t15,
        forwardedAs: as,
        $radius: t16,
        $padding: t17,
        $tone: t18,
        $scheme: scheme,
        disabled,
        onClick: handleClick,
        onMouseEnter: onItemMouseEnter,
        onMouseLeave: onItemMouseLeave,
        ref: setRef,
        tabIndex: -1,
        type: t19,
        children: [
            t20,
            t21
        ]
    }), $[60] = as, $[61] = disabled, $[62] = handleClick, $[63] = onItemMouseEnter, $[64] = onItemMouseLeave, $[65] = restProps, $[66] = scheme, $[67] = t13, $[68] = t14, $[69] = t15, $[70] = t16, $[71] = t18, $[72] = t19, $[73] = t20, $[74] = t21, $[75] = t22) : t22 = $[75], t22;
});
MenuItem.displayName = "ForwardRef(MenuItem)";
function _temp(s) {
    return s - 1;
}
const CustomButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Button).withConfig({
    displayName: "CustomButton",
    componentId: "sc-1kns779-0"
})`max-width:100%;`, Tab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(30);
    let focused, icon, id, label, onClick, onFocus, restProps, selected, t0, t1;
    $[0] !== props ? ({ icon, id, focused, fontSize: t0, label, onClick, onFocus, padding: t1, selected, ...restProps } = props, $[0] = props, $[1] = focused, $[2] = icon, $[3] = id, $[4] = label, $[5] = onClick, $[6] = onFocus, $[7] = restProps, $[8] = selected, $[9] = t0, $[10] = t1) : (focused = $[1], icon = $[2], id = $[3], label = $[4], onClick = $[5], onFocus = $[6], restProps = $[7], selected = $[8], t0 = $[9], t1 = $[10]);
    const fontSize2 = t0 === void 0 ? 1 : t0, padding = t1 === void 0 ? 2 : t1, ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), focusedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1);
    let t2;
    $[11] === Symbol.for("react.memo_cache_sentinel") ? (t2 = ()=>ref.current, $[11] = t2) : t2 = $[11], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t2);
    let t3;
    $[12] === Symbol.for("react.memo_cache_sentinel") ? (t3 = ()=>{
        focusedRef.current = !1;
    }, $[12] = t3) : t3 = $[12];
    const handleBlur = t3;
    let t4;
    $[13] !== onFocus ? (t4 = (event)=>{
        focusedRef.current = !0, onFocus && onFocus(event);
    }, $[13] = onFocus, $[14] = t4) : t4 = $[14];
    const handleFocus = t4;
    let t5, t6;
    $[15] !== focused ? (t5 = ()=>{
        focused && !focusedRef.current && (ref.current && ref.current.focus(), focusedRef.current = !0);
    }, t6 = [
        focused
    ], $[15] = focused, $[16] = t5, $[17] = t6) : (t5 = $[16], t6 = $[17]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    const t7 = selected ? "true" : "false", t8 = selected ? 0 : -1;
    let t9;
    return $[18] !== fontSize2 || $[19] !== handleFocus || $[20] !== icon || $[21] !== id || $[22] !== label || $[23] !== onClick || $[24] !== padding || $[25] !== restProps || $[26] !== selected || $[27] !== t7 || $[28] !== t8 ? (t9 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(CustomButton, {
        "data-ui": "Tab",
        ...restProps,
        "aria-selected": t7,
        fontSize: fontSize2,
        icon,
        id,
        mode: "bleed",
        onClick,
        onBlur: handleBlur,
        onFocus: handleFocus,
        padding,
        ref,
        role: "tab",
        selected,
        tabIndex: t8,
        text: label,
        type: "button"
    }), $[18] = fontSize2, $[19] = handleFocus, $[20] = icon, $[21] = id, $[22] = label, $[23] = onClick, $[24] = padding, $[25] = restProps, $[26] = selected, $[27] = t7, $[28] = t8, $[29] = t9) : t9 = $[29], t9;
});
Tab.displayName = "ForwardRef(Tab)";
const CustomInline = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Inline).withConfig({
    displayName: "CustomInline",
    componentId: "sc-5cm04m-0"
})`& > div{display:inline-block;vertical-align:middle;max-width:100%;box-sizing:border-box;}`, TabList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(15);
    let childrenProp, restProps;
    $[0] !== props ? ({ children: childrenProp, ...restProps } = props, $[0] = props, $[1] = childrenProp, $[2] = restProps) : (childrenProp = $[1], restProps = $[2]);
    const [focusedIndex, setFocusedIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    let t0;
    if ($[3] !== childrenProp || $[4] !== focusedIndex) {
        const children = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Children"].toArray(childrenProp).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"]);
        let t12;
        $[6] !== focusedIndex ? (t12 = (child, childIndex)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"])(child, {
                focused: focusedIndex === childIndex,
                key: childIndex,
                onFocus: ()=>setFocusedIndex(childIndex)
            }), $[6] = focusedIndex, $[7] = t12) : t12 = $[7], t0 = children.map(t12), $[3] = childrenProp, $[4] = focusedIndex, $[5] = t0;
    } else t0 = $[5];
    const tabs = t0, numTabs = tabs.length;
    let t1;
    $[8] !== numTabs ? (t1 = (event)=>{
        event.key === "ArrowLeft" && setFocusedIndex((prevIndex)=>(prevIndex + numTabs - 1) % numTabs), event.key === "ArrowRight" && setFocusedIndex((prevIndex_0)=>(prevIndex_0 + 1) % numTabs);
    }, $[8] = numTabs, $[9] = t1) : t1 = $[9];
    const handleKeyDown = t1;
    let t2;
    return $[10] !== handleKeyDown || $[11] !== ref || $[12] !== restProps || $[13] !== tabs ? (t2 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(CustomInline, {
        "data-ui": "TabList",
        ...restProps,
        onKeyDown: handleKeyDown,
        ref,
        role: "tablist",
        children: tabs
    }), $[10] = handleKeyDown, $[11] = ref, $[12] = restProps, $[13] = tabs, $[14] = t2) : t2 = $[14], t2;
});
TabList.displayName = "ForwardRef(TabList)";
;
}),
"[project]/node_modules/@sanity/ui/dist/index.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Autocomplete",
    ()=>Autocomplete,
    "Breadcrumbs",
    ()=>Breadcrumbs,
    "CodeSkeleton",
    ()=>CodeSkeleton,
    "Dialog",
    ()=>Dialog,
    "DialogContext",
    ()=>DialogContext,
    "DialogProvider",
    ()=>DialogProvider,
    "ErrorBoundary",
    ()=>ErrorBoundary,
    "HeadingSkeleton",
    ()=>HeadingSkeleton,
    "LabelSkeleton",
    ()=>LabelSkeleton,
    "MenuButton",
    ()=>MenuButton,
    "Skeleton",
    ()=>Skeleton,
    "TabPanel",
    ()=>TabPanel,
    "TextSkeleton",
    ()=>TextSkeleton,
    "Toast",
    ()=>Toast,
    "ToastProvider",
    ()=>ToastProvider,
    "Tree",
    ()=>Tree,
    "TreeItem",
    ()=>TreeItem,
    "_hasFocus",
    ()=>_hasFocus,
    "_raf",
    ()=>_raf,
    "_raf2",
    ()=>_raf2,
    "attemptFocus",
    ()=>attemptFocus,
    "focusFirstDescendant",
    ()=>focusFirstDescendant,
    "focusLastDescendant",
    ()=>focusLastDescendant,
    "isFocusable",
    ()=>isFocusable,
    "useArrayProp",
    ()=>useArrayProp,
    "useClickOutside",
    ()=>useClickOutside,
    "useDialog",
    ()=>useDialog,
    "useElementRect",
    ()=>useElementRect,
    "useForwardedRef",
    ()=>useForwardedRef,
    "useToast",
    ()=>useToast,
    "useTree",
    ()=>useTree
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/dist/_chunks-es/_visual-editing.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/react-compiler-runtime/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/icons/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-components/dist/styled-components.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/dist/theme.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sanity/ui/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
function _raf(fn) {
    const frameId = requestAnimationFrame(fn);
    return ()=>{
        cancelAnimationFrame(frameId);
    };
}
function _raf2(fn) {
    let innerDispose = null;
    const outerDispose = _raf(()=>{
        innerDispose = _raf(fn);
    });
    return ()=>{
        innerDispose && innerDispose(), outerDispose();
    };
}
function _hasFocus(element) {
    return !!document.activeElement && element.contains(document.activeElement);
}
function isFocusable(element) {
    return element.tabIndex > 0 || element.tabIndex === 0 && element.getAttribute("tabIndex") !== null ? !0 : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLAnchorElement"])(element) ? !!element.href && element.rel !== "ignore" : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLInputElement"])(element) ? element.type !== "hidden" && element.type !== "file" && !element.disabled : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLButtonElement"])(element) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLSelectElement"])(element) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLTextAreaElement"])(element) ? !element.disabled : !1;
}
function attemptFocus(element) {
    if (!isFocusable(element)) return !1;
    try {
        element.focus();
    } catch  {}
    return document.activeElement === element;
}
function focusFirstDescendant(element) {
    for(let i = 0; i < element.childNodes.length; i++){
        const child = element.childNodes[i];
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(child) && (attemptFocus(child) || focusFirstDescendant(child))) return !0;
    }
    return !1;
}
function focusLastDescendant(element) {
    for(let i = element.childNodes.length - 1; i >= 0; i--){
        const child = element.childNodes[i];
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(child) && (attemptFocus(child) || focusLastDescendant(child))) return !0;
    }
    return !1;
}
function useArrayProp(val, defaultVal) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3);
    let t0;
    return $[0] !== defaultVal || $[1] !== val ? (t0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(val, defaultVal), $[0] = defaultVal, $[1] = val, $[2] = t0) : t0 = $[2], t0;
}
function _getElements(element, elementsArg) {
    const ret = [
        element
    ];
    for (const el of elementsArg)Array.isArray(el) ? ret.push(...el) : ret.push(el);
    return ret.filter(Boolean);
}
function useClickOutside(listener, t0, boundaryElement) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12), elementsArg = t0 === void 0 ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"] : t0, [element, setElement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t1;
    $[0] !== element || $[1] !== elementsArg ? (t1 = ()=>_getElements(element, elementsArg), $[0] = element, $[1] = elementsArg, $[2] = t1) : t1 = $[2];
    const [elements, setElements] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1), elementsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(elements);
    let t2, t3;
    $[3] !== element || $[4] !== elementsArg ? (t2 = ()=>{
        const prevElements = elementsRef.current, nextElements = _getElements(element, elementsArg);
        if (prevElements.length !== nextElements.length) {
            setElements(nextElements), elementsRef.current = nextElements;
            return;
        }
        for (const el of prevElements)if (!nextElements.includes(el)) {
            setElements(nextElements), elementsRef.current = nextElements;
            return;
        }
        for (const el_0 of nextElements)if (!prevElements.includes(el_0)) {
            setElements(nextElements), elementsRef.current = nextElements;
            return;
        }
    }, t3 = [
        element,
        elementsArg
    ], $[3] = element, $[4] = elementsArg, $[5] = t2, $[6] = t3) : (t2 = $[5], t3 = $[6]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
    let t4, t5;
    return $[7] !== boundaryElement || $[8] !== elements || $[9] !== listener ? (t4 = ()=>{
        if (!listener) return;
        const handleWindowMouseDown = (evt)=>{
            const target = evt.target;
            if (target instanceof Node && !(boundaryElement && !boundaryElement.contains(target))) {
                for (const el_1 of elements)if (target === el_1 || el_1.contains(target)) return;
                listener(evt);
            }
        };
        return window.addEventListener("mousedown", handleWindowMouseDown), ()=>{
            window.removeEventListener("mousedown", handleWindowMouseDown);
        };
    }, t5 = [
        boundaryElement,
        listener,
        elements
    ], $[7] = boundaryElement, $[8] = elements, $[9] = listener, $[10] = t4, $[11] = t5) : (t4 = $[10], t5 = $[11]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t4, t5), setElement;
}
function useElementRect(element) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useElementSize"])(element)?._contentRect || null;
}
function useForwardedRef(ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1), innerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t0;
    return $[0] === Symbol.for("react.memo_cache_sentinel") ? (t0 = ()=>innerRef.current, $[0] = t0) : t0 = $[0], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(ref, t0), innerRef;
}
class ErrorBoundary extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Component"] {
    state = {
        error: null
    };
    static getDerivedStateFromError(error) {
        return {
            error
        };
    }
    componentDidCatch(error, info) {
        this.props.onCatch({
            error,
            info
        });
    }
    render() {
        const { error } = this.state;
        if (error) {
            const message = typeof error?.message == "string" ? error.message : "Error";
            return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Code"], {
                children: message
            });
        }
        return this.props.children;
    }
}
const StyledAutocomplete = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "StyledAutocomplete",
    componentId: "sc-1igauft-0"
})`line-height:0;`, ListBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"]).withConfig({
    displayName: "ListBox",
    componentId: "sc-1igauft-1"
})`& > ul{list-style:none;padding:0;margin:0;}`, rotate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["keyframes"]`
  from {
    transform: rotate(0deg);
  }

  to {
    transform: rotate(360deg);
  }
`, AnimatedSpinnerIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SpinnerIcon"]).withConfig({
    displayName: "AnimatedSpinnerIcon",
    componentId: "sc-1igauft-2"
})`animation:${rotate} 500ms linear infinite;`;
function AutocompleteOption(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(11), { children, id, onSelect, selected, value } = props;
    let t0;
    $[0] !== onSelect || $[1] !== value ? (t0 = ()=>{
        setTimeout(()=>{
            onSelect(value);
        }, 0);
    }, $[0] = onSelect, $[1] = value, $[2] = t0) : t0 = $[2];
    const handleClick = t0;
    let t1;
    $[3] !== handleClick ? (t1 = (event)=>{
        event.key === "Enter" && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_isEnterToClickElement"])(event.currentTarget) && handleClick();
    }, $[3] = handleClick, $[4] = t1) : t1 = $[4];
    const handleKeyDown = t1;
    let t2;
    return $[5] !== children || $[6] !== handleClick || $[7] !== handleKeyDown || $[8] !== id || $[9] !== selected ? (t2 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("li", {
        "aria-selected": selected,
        "data-ui": "AutocompleteOption",
        id,
        role: "option",
        onClick: handleClick,
        onKeyDown: handleKeyDown,
        children
    }), $[5] = children, $[6] = handleClick, $[7] = handleKeyDown, $[8] = id, $[9] = selected, $[10] = t2) : t2 = $[10], t2;
}
function autocompleteReducer(state, msg) {
    return msg.type === "input/change" ? {
        ...state,
        activeValue: null,
        focused: !0,
        query: msg.query
    } : msg.type === "input/focus" ? {
        ...state,
        focused: !0
    } : msg.type === "root/blur" ? {
        ...state,
        focused: !1,
        query: null
    } : msg.type === "root/clear" ? {
        ...state,
        activeValue: null,
        query: null,
        value: null
    } : msg.type === "root/escape" ? {
        ...state,
        focused: !1,
        query: null
    } : msg.type === "root/open" ? {
        ...state,
        query: state.query || msg.query
    } : msg.type === "root/setActiveValue" ? {
        ...state,
        activeValue: msg.value,
        listFocused: msg.listFocused || state.listFocused
    } : msg.type === "root/setListFocused" ? {
        ...state,
        listFocused: msg.listFocused
    } : msg.type === "value/change" ? {
        ...state,
        activeValue: msg.value,
        query: null,
        value: msg.value
    } : state;
}
const AUTOCOMPLETE_LISTBOX_IGNORE_KEYS = [
    "Control",
    "Shift",
    "Alt",
    "Enter",
    "Home",
    "End",
    "PageUp",
    "PageDown",
    "Meta",
    "Tab",
    "CapsLock"
], AUTOCOMPLETE_POPOVER_PLACEMENT = "bottom-start", AUTOCOMPLETE_POPOVER_FALLBACK_PLACEMENTS = [
    "bottom-start",
    "top-start"
], DEFAULT_RENDER_VALUE = (value, option)=>option ? option.value : value, DEFAULT_FILTER_OPTION = (query, option)=>option.value.toLowerCase().indexOf(query.toLowerCase()) > -1, InnerAutocomplete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(181);
    let customValidity, disabled, filterOptionProp, icon, id, loading, onBlur, onChange, onFocus, onQueryChange, onSelect, openButton, openOnFocus, optionsProp, prefix, readOnly, relatedElements, renderOptionProp, renderPopover, restProps, suffix, t0, t1, t2, t3, t4, t5, t6, valueProp;
    $[0] !== props ? ({ border: t0, customValidity, disabled, filterOption: filterOptionProp, fontSize: t1, icon, id, listBox: t2, loading, onBlur, onChange, onFocus, onQueryChange, onSelect, openButton, openOnFocus, options: optionsProp, padding: t3, popover: t4, prefix, radius: t5, readOnly, relatedElements, renderOption: renderOptionProp, renderPopover, renderValue: t6, suffix, value: valueProp, ...restProps } = props, $[0] = props, $[1] = customValidity, $[2] = disabled, $[3] = filterOptionProp, $[4] = icon, $[5] = id, $[6] = loading, $[7] = onBlur, $[8] = onChange, $[9] = onFocus, $[10] = onQueryChange, $[11] = onSelect, $[12] = openButton, $[13] = openOnFocus, $[14] = optionsProp, $[15] = prefix, $[16] = readOnly, $[17] = relatedElements, $[18] = renderOptionProp, $[19] = renderPopover, $[20] = restProps, $[21] = suffix, $[22] = t0, $[23] = t1, $[24] = t2, $[25] = t3, $[26] = t4, $[27] = t5, $[28] = t6, $[29] = valueProp) : (customValidity = $[1], disabled = $[2], filterOptionProp = $[3], icon = $[4], id = $[5], loading = $[6], onBlur = $[7], onChange = $[8], onFocus = $[9], onQueryChange = $[10], onSelect = $[11], openButton = $[12], openOnFocus = $[13], optionsProp = $[14], prefix = $[15], readOnly = $[16], relatedElements = $[17], renderOptionProp = $[18], renderPopover = $[19], restProps = $[20], suffix = $[21], t0 = $[22], t1 = $[23], t2 = $[24], t3 = $[25], t4 = $[26], t5 = $[27], t6 = $[28], valueProp = $[29]);
    const border = t0 === void 0 ? !0 : t0, fontSize = t1 === void 0 ? 2 : t1, listBox = t2 === void 0 ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_RECORD"] : t2, paddingProp = t3 === void 0 ? 3 : t3, popover = t4 === void 0 ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_RECORD"] : t4, radius = t5 === void 0 ? 2 : t5, renderValue = t6 === void 0 ? DEFAULT_RENDER_VALUE : t6, t7 = valueProp || null, t8 = valueProp || null;
    let t9;
    $[30] !== t7 || $[31] !== t8 ? (t9 = {
        activeValue: t7,
        focused: !1,
        listFocused: !1,
        query: null,
        value: t8
    }, $[30] = t7, $[31] = t8, $[32] = t9) : t9 = $[32];
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(autocompleteReducer, t9), { activeValue, focused, listFocused, query, value } = state;
    let t10;
    $[33] !== fontSize || $[34] !== paddingProp ? (t10 = (t112)=>{
        const { value: value_0 } = t112;
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
            "data-as": "button",
            padding: paddingProp,
            radius: 2,
            tone: "inherit",
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                size: fontSize,
                textOverflow: "ellipsis",
                children: value_0
            })
        });
    }, $[33] = fontSize, $[34] = paddingProp, $[35] = t10) : t10 = $[35];
    const renderOption = typeof renderOptionProp == "function" ? renderOptionProp : t10, filterOption = typeof filterOptionProp == "function" ? filterOptionProp : DEFAULT_FILTER_OPTION, rootElementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), resultsPopoverElementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), inputElementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), listBoxElementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [inputElement, _setInputElement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t11;
    $[36] === Symbol.for("react.memo_cache_sentinel") ? (t11 = (node)=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startTransition"])(()=>_setInputElement(node));
    }, $[36] = t11) : t11 = $[36];
    const setInputElement = t11, listFocusedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1), valueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(value), valuePropRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(valueProp), popoverMouseWithinRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!1);
    let t12, t13;
    $[37] !== inputElement ? (t12 = ()=>inputElement, t13 = [
        inputElement
    ], $[37] = inputElement, $[38] = t12, $[39] = t13) : (t12 = $[38], t13 = $[39]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(inputElementRef, t12, t13);
    let t14, t15;
    $[40] !== inputElement ? (t14 = ()=>inputElement, t15 = [
        inputElement
    ], $[40] = inputElement, $[41] = t14, $[42] = t15) : (t14 = $[41], t15 = $[42]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t14, t15);
    const listBoxId = `${id}-listbox`, options = Array.isArray(optionsProp) ? optionsProp : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"], padding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(paddingProp);
    let t16;
    $[43] !== options || $[44] !== value ? (t16 = value !== null ? options.find((o)=>o.value === value) : void 0, $[43] = options, $[44] = value, $[45] = t16) : t16 = $[45];
    const currentOption = t16;
    let t17;
    if ($[46] !== filterOption || $[47] !== options || $[48] !== query) {
        let t182;
        $[50] !== filterOption || $[51] !== query ? (t182 = (option)=>query ? filterOption(query, option) : !0, $[50] = filterOption, $[51] = query, $[52] = t182) : t182 = $[52], t17 = options.filter(t182), $[46] = filterOption, $[47] = options, $[48] = query, $[49] = t17;
    } else t17 = $[49];
    const filteredOptions = t17, filteredOptionsLen = filteredOptions.length, activeItemId = activeValue ? `${id}-option-${activeValue}` : void 0, expanded = query !== null && loading || focused && query !== null;
    let t18;
    $[53] !== onBlur || $[54] !== onQueryChange || $[55] !== relatedElements ? (t18 = (event)=>{
        setTimeout(()=>{
            if (popoverMouseWithinRef.current) return;
            const elements = (relatedElements || []).concat(rootElementRef.current ? [
                rootElementRef.current
            ] : [], resultsPopoverElementRef.current ? [
                resultsPopoverElementRef.current
            ] : []);
            let focusInside = !1;
            if (document.activeElement) {
                for (const e of elements)if (e === document.activeElement || e.contains(document.activeElement)) {
                    focusInside = !0;
                    break;
                }
            }
            focusInside === !1 && (dispatch({
                type: "root/blur"
            }), popoverMouseWithinRef.current = !1, onQueryChange && onQueryChange(null), onBlur && onBlur(event));
        }, 0);
    }, $[53] = onBlur, $[54] = onQueryChange, $[55] = relatedElements, $[56] = t18) : t18 = $[56];
    const handleRootBlur = t18;
    let t19;
    $[57] === Symbol.for("react.memo_cache_sentinel") ? (t19 = (event_0)=>{
        const listBoxElement = listBoxElementRef.current, focusedElement = event_0.target instanceof HTMLElement ? event_0.target : null, listFocused_0 = listBoxElement?.contains(focusedElement) || !1;
        listFocused_0 !== listFocusedRef.current && (listFocusedRef.current = listFocused_0, dispatch({
            type: "root/setListFocused",
            listFocused: listFocused_0
        }));
    }, $[57] = t19) : t19 = $[57];
    const handleRootFocus = t19;
    let t20;
    $[58] !== onChange || $[59] !== onQueryChange || $[60] !== onSelect ? (t20 = (v)=>{
        dispatch({
            type: "value/change",
            value: v
        }), popoverMouseWithinRef.current = !1, onSelect && onSelect(v), valueRef.current = v, onChange && onChange(v), onQueryChange && onQueryChange(null), inputElementRef.current?.focus();
    }, $[58] = onChange, $[59] = onQueryChange, $[60] = onSelect, $[61] = t20) : t20 = $[61];
    const handleOptionSelect = t20;
    let t21;
    $[62] !== activeValue || $[63] !== filteredOptions || $[64] !== filteredOptionsLen || $[65] !== onQueryChange ? (t21 = (event_1)=>{
        if (event_1.key === "ArrowDown") {
            if (event_1.preventDefault(), !filteredOptionsLen) return;
            const activeOption = filteredOptions.find((o_0)=>o_0.value === activeValue), activeIndex = activeOption ? filteredOptions.indexOf(activeOption) : -1, nextActiveOption = filteredOptions[(activeIndex + 1) % filteredOptionsLen];
            nextActiveOption && dispatch({
                type: "root/setActiveValue",
                value: nextActiveOption.value,
                listFocused: !0
            });
            return;
        }
        if (event_1.key === "ArrowUp") {
            if (event_1.preventDefault(), !filteredOptionsLen) return;
            const activeOption_0 = filteredOptions.find((o_1)=>o_1.value === activeValue), activeIndex_0 = activeOption_0 ? filteredOptions.indexOf(activeOption_0) : -1, nextActiveOption_0 = filteredOptions[activeIndex_0 === -1 ? filteredOptionsLen - 1 : (filteredOptionsLen + activeIndex_0 - 1) % filteredOptionsLen];
            nextActiveOption_0 && dispatch({
                type: "root/setActiveValue",
                value: nextActiveOption_0.value,
                listFocused: !0
            });
            return;
        }
        if (event_1.key === "Escape") {
            dispatch({
                type: "root/escape"
            }), popoverMouseWithinRef.current = !1, onQueryChange && onQueryChange(null), inputElementRef.current?.focus();
            return;
        }
        const target = event_1.target, listEl = listBoxElementRef.current;
        if ((listEl === target || listEl?.contains(target)) && !AUTOCOMPLETE_LISTBOX_IGNORE_KEYS.includes(event_1.key)) {
            inputElementRef.current?.focus();
            return;
        }
    }, $[62] = activeValue, $[63] = filteredOptions, $[64] = filteredOptionsLen, $[65] = onQueryChange, $[66] = t21) : t21 = $[66];
    const handleRootKeyDown = t21;
    let t22;
    $[67] !== onQueryChange ? (t22 = (event_2)=>{
        const nextQuery = event_2.currentTarget.value;
        dispatch({
            type: "input/change",
            query: nextQuery
        }), onQueryChange && onQueryChange(nextQuery);
    }, $[67] = onQueryChange, $[68] = t22) : t22 = $[68];
    const handleInputChange = t22;
    let t23;
    $[69] !== currentOption || $[70] !== renderValue || $[71] !== value ? (t23 = ()=>{
        dispatch({
            type: "root/open",
            query: value ? renderValue(value, currentOption) : ""
        });
    }, $[69] = currentOption, $[70] = renderValue, $[71] = value, $[72] = t23) : t23 = $[72];
    const dispatchOpen = t23;
    let t24;
    $[73] !== dispatchOpen || $[74] !== focused || $[75] !== onFocus || $[76] !== openOnFocus ? (t24 = (event_3)=>{
        focused || (dispatch({
            type: "input/focus"
        }), onFocus && onFocus(event_3), openOnFocus && dispatchOpen());
    }, $[73] = dispatchOpen, $[74] = focused, $[75] = onFocus, $[76] = openOnFocus, $[77] = t24) : t24 = $[77];
    const handleInputFocus = t24;
    let t25;
    $[78] === Symbol.for("react.memo_cache_sentinel") ? (t25 = ()=>{
        popoverMouseWithinRef.current = !0;
    }, $[78] = t25) : t25 = $[78];
    const handlePopoverMouseEnter = t25;
    let t26;
    $[79] === Symbol.for("react.memo_cache_sentinel") ? (t26 = ()=>{
        popoverMouseWithinRef.current = !1;
    }, $[79] = t26) : t26 = $[79];
    const handlePopoverMouseLeave = t26;
    let t27;
    $[80] !== onChange || $[81] !== onQueryChange ? (t27 = ()=>{
        dispatch({
            type: "root/clear"
        }), valueRef.current = "", onChange && onChange(""), onQueryChange && onQueryChange(null), inputElementRef.current?.focus();
    }, $[80] = onChange, $[81] = onQueryChange, $[82] = t27) : t27 = $[82];
    const handleClearButtonClick = t27;
    let t28;
    $[83] === Symbol.for("react.memo_cache_sentinel") ? (t28 = ()=>{
        dispatch({
            type: "input/focus"
        });
    }, $[83] = t28) : t28 = $[83];
    const handleClearButtonFocus = t28;
    let t29, t30;
    $[84] !== valueProp ? (t29 = ()=>{
        if (valueProp !== valuePropRef.current) {
            valuePropRef.current = valueProp, valueProp !== void 0 && (dispatch({
                type: "value/change",
                value: valueProp
            }), valueRef.current = valueProp);
            return;
        }
        valueProp !== valueRef.current && (valueRef.current = valueProp || null, dispatch({
            type: "value/change",
            value: valueProp || null
        }));
    }, t30 = [
        valueProp
    ], $[84] = valueProp, $[85] = t29, $[86] = t30) : (t29 = $[85], t30 = $[86]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t29, t30);
    let t31, t32;
    $[87] !== focused ? (t31 = ()=>{
        !focused && valueRef.current && dispatch({
            type: "root/setActiveValue",
            value: valueRef.current
        });
    }, t32 = [
        focused
    ], $[87] = focused, $[88] = t31, $[89] = t32) : (t31 = $[88], t32 = $[89]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t31, t32);
    let t33, t34;
    $[90] !== activeValue || $[91] !== filteredOptions ? (t33 = ()=>{
        const listElement = listBoxElementRef.current;
        if (!listElement) return;
        const activeOption_1 = filteredOptions.find((o_2)=>o_2.value === activeValue);
        if (activeOption_1) {
            const activeIndex_1 = filteredOptions.indexOf(activeOption_1), activeItemElement = listElement.childNodes[activeIndex_1];
            if (activeItemElement) {
                if (_hasFocus(activeItemElement)) return;
                focusFirstDescendant(activeItemElement);
            }
        }
    }, t34 = [
        activeValue,
        filteredOptions
    ], $[90] = activeValue, $[91] = filteredOptions, $[92] = t33, $[93] = t34) : (t33 = $[92], t34 = $[93]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t33, t34);
    let t35;
    bb0: {
        if (!loading && !disabled && value) {
            let t362;
            $[94] === Symbol.for("react.memo_cache_sentinel") ? (t362 = {
                "aria-label": "Clear",
                onFocus: handleClearButtonFocus
            }, $[94] = t362) : t362 = $[94], t35 = t362;
            break bb0;
        }
        t35 = void 0;
    }
    const clearButton = t35, openButtonBoxPadding = padding.map(_temp$3), openButtonPadding = padding.map(_temp2$1), openButtonProps = typeof openButton == "object" ? openButton : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_RECORD"];
    let t36;
    $[95] !== dispatchOpen || $[96] !== openButtonProps ? (t36 = (event_4)=>{
        dispatchOpen(), openButtonProps.onClick && openButtonProps.onClick(event_4), _raf(()=>inputElementRef.current?.focus());
    }, $[95] = dispatchOpen, $[96] = openButtonProps, $[97] = t36) : t36 = $[97];
    const handleOpenClick = t36;
    let t37;
    $[98] !== disabled || $[99] !== expanded || $[100] !== fontSize || $[101] !== handleOpenClick || $[102] !== openButton || $[103] !== openButtonBoxPadding || $[104] !== openButtonPadding || $[105] !== openButtonProps || $[106] !== readOnly ? (t37 = !disabled && !readOnly && openButton ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
        "aria-hidden": expanded,
        padding: openButtonBoxPadding,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
            "aria-label": "Open",
            disabled: expanded,
            fontSize,
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChevronDownIcon"],
            mode: "bleed",
            padding: openButtonPadding,
            ...openButtonProps,
            onClick: handleOpenClick
        })
    }) : void 0, $[98] = disabled, $[99] = expanded, $[100] = fontSize, $[101] = handleOpenClick, $[102] = openButton, $[103] = openButtonBoxPadding, $[104] = openButtonPadding, $[105] = openButtonProps, $[106] = readOnly, $[107] = t37) : t37 = $[107];
    const openButtonNode = t37;
    let t38;
    bb1: {
        if (query === null) {
            if (value !== null) {
                let t392;
                $[108] !== currentOption || $[109] !== renderValue || $[110] !== value ? (t392 = renderValue(value, currentOption), $[108] = currentOption, $[109] = renderValue, $[110] = value, $[111] = t392) : t392 = $[111], t38 = t392;
                break bb1;
            }
            t38 = "";
            break bb1;
        }
        t38 = query;
    }
    const inputValue = t38;
    let t39;
    $[112] !== listFocused ? (t39 = (event_5)=>{
        event_5.key === "Tab" && listFocused && inputElementRef.current?.focus();
    }, $[112] = listFocused, $[113] = t39) : t39 = $[113];
    const handleListBoxKeyDown = t39;
    let t40;
    bb2: {
        if (filteredOptions.length === 0) {
            t40 = null;
            break bb2;
        }
        let t412;
        if ($[114] !== activeValue || $[115] !== currentOption || $[116] !== filteredOptions || $[117] !== handleOptionSelect || $[118] !== id || $[119] !== listFocused || $[120] !== loading || $[121] !== renderOption) {
            let t423;
            $[123] !== activeValue || $[124] !== currentOption || $[125] !== handleOptionSelect || $[126] !== id || $[127] !== listFocused || $[128] !== loading || $[129] !== renderOption ? (t423 = (option_0)=>{
                const active = activeValue !== null ? option_0.value === activeValue : currentOption === option_0;
                return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(AutocompleteOption, {
                    id: `${id}-option-${option_0.value}`,
                    onSelect: handleOptionSelect,
                    selected: active,
                    value: option_0.value,
                    children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"])(renderOption(option_0), {
                        disabled: loading,
                        selected: active,
                        tabIndex: listFocused && active ? 0 : -1
                    })
                }, option_0.value);
            }, $[123] = activeValue, $[124] = currentOption, $[125] = handleOptionSelect, $[126] = id, $[127] = listFocused, $[128] = loading, $[129] = renderOption, $[130] = t423) : t423 = $[130], t412 = filteredOptions.map(t423), $[114] = activeValue, $[115] = currentOption, $[116] = filteredOptions, $[117] = handleOptionSelect, $[118] = id, $[119] = listFocused, $[120] = loading, $[121] = renderOption, $[122] = t412;
        } else t412 = $[122];
        let t422;
        $[131] !== listBoxId || $[132] !== t412 ? (t422 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stack"], {
            as: "ul",
            "aria-multiselectable": !1,
            "data-ui": "AutoComplete__resultsList",
            id: listBoxId,
            ref: listBoxElementRef,
            role: "listbox",
            space: 1,
            children: t412
        }), $[131] = listBoxId, $[132] = t412, $[133] = t422) : t422 = $[133];
        let t432;
        $[134] !== handleListBoxKeyDown || $[135] !== listBox || $[136] !== t422 ? (t432 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ListBox, {
            "data-ui": "AutoComplete__results",
            onKeyDown: handleListBoxKeyDown,
            padding: 1,
            ...listBox,
            tabIndex: -1,
            children: t422
        }), $[134] = handleListBoxKeyDown, $[135] = listBox, $[136] = t422, $[137] = t432) : t432 = $[137], t40 = t432;
    }
    const content2 = t40;
    let t41;
    bb3: {
        if (renderPopover) {
            const t423 = !expanded;
            let t432;
            $[138] !== content2 || $[139] !== handlePopoverMouseEnter || $[140] !== handlePopoverMouseLeave || $[141] !== inputElement || $[142] !== renderPopover || $[143] !== t423 ? (t432 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(RenderPopover, {
                content: content2,
                hidden: t423,
                inputElement,
                onMouseEnter: handlePopoverMouseEnter,
                onMouseLeave: handlePopoverMouseLeave,
                resultsPopoverElementRef,
                renderPopover
            }), $[138] = content2, $[139] = handlePopoverMouseEnter, $[140] = handlePopoverMouseLeave, $[141] = inputElement, $[142] = renderPopover, $[143] = t423, $[144] = t432) : t432 = $[144], t41 = t432;
            break bb3;
        }
        if (filteredOptionsLen === 0) {
            t41 = null;
            break bb3;
        }
        let t422;
        $[145] !== content2 || $[146] !== expanded || $[147] !== handlePopoverMouseEnter || $[148] !== handlePopoverMouseLeave || $[149] !== inputElement || $[150] !== popover || $[151] !== radius ? (t422 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popover"], {
            arrow: !1,
            constrainSize: !0,
            content: content2,
            fallbackPlacements: AUTOCOMPLETE_POPOVER_FALLBACK_PLACEMENTS,
            matchReferenceWidth: !0,
            onMouseEnter: handlePopoverMouseEnter,
            onMouseLeave: handlePopoverMouseLeave,
            open: expanded,
            overflow: "auto",
            placement: AUTOCOMPLETE_POPOVER_PLACEMENT,
            portal: !0,
            radius,
            ref: resultsPopoverElementRef,
            referenceElement: inputElement,
            ...popover
        }), $[145] = content2, $[146] = expanded, $[147] = handlePopoverMouseEnter, $[148] = handlePopoverMouseLeave, $[149] = inputElement, $[150] = popover, $[151] = radius, $[152] = t422) : t422 = $[152], t41 = t422;
    }
    const results = t41, t42 = loading && AnimatedSpinnerIcon, t43 = suffix || openButtonNode;
    let t44;
    $[153] !== activeItemId || $[154] !== border || $[155] !== clearButton || $[156] !== customValidity || $[157] !== disabled || $[158] !== expanded || $[159] !== fontSize || $[160] !== handleClearButtonClick || $[161] !== handleInputChange || $[162] !== handleInputFocus || $[163] !== icon || $[164] !== id || $[165] !== inputValue || $[166] !== listBoxId || $[167] !== padding || $[168] !== prefix || $[169] !== radius || $[170] !== readOnly || $[171] !== restProps || $[172] !== t42 || $[173] !== t43 ? (t44 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextInput"], {
        ...restProps,
        "aria-activedescendant": activeItemId,
        "aria-autocomplete": "list",
        "aria-expanded": expanded,
        "aria-owns": listBoxId,
        autoCapitalize: "off",
        autoComplete: "off",
        autoCorrect: "off",
        border,
        clearButton,
        customValidity,
        disabled,
        fontSize,
        icon,
        iconRight: t42,
        id,
        inputMode: "search",
        onChange: handleInputChange,
        onClear: handleClearButtonClick,
        onFocus: handleInputFocus,
        padding,
        prefix,
        radius,
        readOnly,
        ref: setInputElement,
        role: "combobox",
        spellCheck: !1,
        suffix: t43,
        value: inputValue
    }), $[153] = activeItemId, $[154] = border, $[155] = clearButton, $[156] = customValidity, $[157] = disabled, $[158] = expanded, $[159] = fontSize, $[160] = handleClearButtonClick, $[161] = handleInputChange, $[162] = handleInputFocus, $[163] = icon, $[164] = id, $[165] = inputValue, $[166] = listBoxId, $[167] = padding, $[168] = prefix, $[169] = radius, $[170] = readOnly, $[171] = restProps, $[172] = t42, $[173] = t43, $[174] = t44) : t44 = $[174];
    let t45;
    return $[175] !== handleRootBlur || $[176] !== handleRootFocus || $[177] !== handleRootKeyDown || $[178] !== results || $[179] !== t44 ? (t45 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(StyledAutocomplete, {
        "data-ui": "Autocomplete",
        onBlur: handleRootBlur,
        onFocus: handleRootFocus,
        onKeyDown: handleRootKeyDown,
        ref: rootElementRef,
        children: [
            t44,
            results
        ]
    }), $[175] = handleRootBlur, $[176] = handleRootFocus, $[177] = handleRootKeyDown, $[178] = results, $[179] = t44, $[180] = t45) : t45 = $[180], t45;
});
function RenderPopover({ renderPopover, content: content2, hidden, inputElement, onMouseEnter, onMouseLeave, resultsPopoverElementRef }) {
    return renderPopover({
        content: content2,
        hidden,
        inputElement,
        onMouseEnter,
        onMouseLeave
    }, resultsPopoverElementRef);
}
InnerAutocomplete.displayName = "ForwardRef(Autocomplete)";
const Autocomplete = InnerAutocomplete;
function _temp$3(v_0) {
    return v_0 === 0 ? 0 : v_0 === 1 || v_0 === 2 ? 1 : v_0 - 2;
}
function _temp2$1(v_1) {
    return Math.max(v_1 - 1, 0);
}
const StyledBreadcrumbs = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].ol.withConfig({
    displayName: "StyledBreadcrumbs",
    componentId: "sc-1es8h8q-0"
})`margin:0;padding:0;display:flex;list-style:none;align-items:center;white-space:nowrap;line-height:0;`, ExpandButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"]).withConfig({
    displayName: "ExpandButton",
    componentId: "sc-1es8h8q-1"
})`appearance:none;margin:-4px;`, Breadcrumbs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(30);
    let children, gap, maxLength, restProps, separator, t0;
    $[0] !== props ? ({ children, gap, maxLength, separator, space: t0, ...restProps } = props, $[0] = props, $[1] = children, $[2] = gap, $[3] = maxLength, $[4] = restProps, $[5] = separator, $[6] = t0) : (children = $[1], gap = $[2], maxLength = $[3], restProps = $[4], separator = $[5], t0 = $[6]);
    const t1 = gap === void 0 ? t0 === void 0 ? 2 : t0 : gap;
    let t2;
    $[7] !== t1 ? (t2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(t1), $[7] = t1, $[8] = t2) : t2 = $[8];
    const space = t2, [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), expandElementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), popoverElementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t3;
    $[9] === Symbol.for("react.memo_cache_sentinel") ? (t3 = ()=>setOpen(!1), $[9] = t3) : t3 = $[9];
    const collapse = t3;
    let t4;
    $[10] === Symbol.for("react.memo_cache_sentinel") ? (t4 = ()=>setOpen(!0), $[10] = t4) : t4 = $[10];
    const expand = t4;
    let t5;
    $[11] === Symbol.for("react.memo_cache_sentinel") ? (t5 = ()=>[
            expandElementRef.current,
            popoverElementRef.current
        ], $[11] = t5) : t5 = $[11], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClickOutsideEvent"])(collapse, t5);
    let t6;
    $[12] !== children ? (t6 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Children"].toArray(children).filter(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"]), $[12] = children, $[13] = t6) : t6 = $[13];
    const rawItems = t6;
    let t7;
    $[14] !== maxLength || $[15] !== open || $[16] !== rawItems || $[17] !== space ? (t7 = {
        collapse,
        expand,
        expandElementRef,
        maxLength,
        open,
        popoverElementRef,
        rawItems,
        space
    }, $[14] = maxLength, $[15] = open, $[16] = rawItems, $[17] = space, $[18] = t7) : t7 = $[18];
    const items = useItems(t7);
    let t8;
    if ($[19] !== items || $[20] !== separator || $[21] !== space) {
        let t92;
        $[23] !== separator || $[24] !== space ? (t92 = (item, itemIndex)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    itemIndex > 0 && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
                        "aria-hidden": !0,
                        as: "li",
                        paddingX: space,
                        children: separator || /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                            muted: !0,
                            children: "/"
                        })
                    }),
                    /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
                        as: "li",
                        children: item
                    })
                ]
            }, itemIndex), $[23] = separator, $[24] = space, $[25] = t92) : t92 = $[25], t8 = items.map(t92), $[19] = items, $[20] = separator, $[21] = space, $[22] = t8;
    } else t8 = $[22];
    let t9;
    return $[26] !== ref || $[27] !== restProps || $[28] !== t8 ? (t9 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledBreadcrumbs, {
        "data-ui": "Breadcrumbs",
        ...restProps,
        ref,
        children: t8
    }), $[26] = ref, $[27] = restProps, $[28] = t8, $[29] = t9) : t9 = $[29], t9;
});
Breadcrumbs.displayName = "ForwardRef(Breadcrumbs)";
function useItems(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(28), { collapse, expand, expandElementRef, maxLength, open, popoverElementRef, rawItems, space } = t0, len = rawItems.length;
    if (maxLength && len > maxLength) {
        const beforeLength = Math.ceil(maxLength / 2), afterLength = Math.floor(maxLength / 2);
        let t1;
        if ($[0] !== afterLength || $[1] !== beforeLength || $[2] !== collapse || $[3] !== expand || $[4] !== expandElementRef || $[5] !== len || $[6] !== open || $[7] !== popoverElementRef || $[8] !== rawItems || $[9] !== space) {
            const t2 = rawItems.slice(0, beforeLength - 1);
            let t3;
            $[11] !== afterLength || $[12] !== beforeLength || $[13] !== len || $[14] !== rawItems ? (t3 = rawItems.slice(beforeLength - 1, len - afterLength), $[11] = afterLength, $[12] = beforeLength, $[13] = len, $[14] = rawItems, $[15] = t3) : t3 = $[15];
            let t4;
            $[16] !== space || $[17] !== t3 ? (t4 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stack"], {
                as: "ol",
                overflow: "auto",
                padding: space,
                gap: space,
                children: t3
            }), $[16] = space, $[17] = t3, $[18] = t4) : t4 = $[18];
            const t5 = open ? collapse : expand;
            let t6;
            $[19] !== expandElementRef || $[20] !== open || $[21] !== t5 ? (t6 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ExpandButton, {
                fontSize: 1,
                mode: "bleed",
                onClick: t5,
                padding: 1,
                ref: expandElementRef,
                selected: open,
                text: "\u2026"
            }), $[19] = expandElementRef, $[20] = open, $[21] = t5, $[22] = t6) : t6 = $[22];
            let t7;
            $[23] !== open || $[24] !== popoverElementRef || $[25] !== t4 || $[26] !== t6 ? (t7 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popover"], {
                constrainSize: !0,
                content: t4,
                open,
                placement: "top",
                portal: !0,
                ref: popoverElementRef,
                children: t6
            }, "button"), $[23] = open, $[24] = popoverElementRef, $[25] = t4, $[26] = t6, $[27] = t7) : t7 = $[27], t1 = [
                ...t2,
                t7,
                ...rawItems.slice(len - afterLength)
            ], $[0] = afterLength, $[1] = beforeLength, $[2] = collapse, $[3] = expand, $[4] = expandElementRef, $[5] = len, $[6] = open, $[7] = popoverElementRef, $[8] = rawItems, $[9] = space, $[10] = t1;
        } else t1 = $[10];
        return t1;
    }
    return rawItems;
}
function dialogStyle({ theme }) {
    const { color } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(theme);
    return {
        "&:not([hidden])": {
            display: "flex"
        },
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        alignItems: "center",
        justifyContent: "center",
        outline: "none",
        background: color.backdrop
    };
}
function responsiveDialogPositionStyle(props) {
    const { media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_responsive"])(media, props.$position, (position)=>({
            "&&": {
                position
            }
        }));
}
function animationDialogStyle(props) {
    return props.$animate ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    @keyframes zoomIn {
      from {
        opacity: 0;
        transform: scale(0.95);
      }
      to {
        opacity: 1;
        transform: scale(1);
      }
    }
    @keyframes fadeIn {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }

    animation: fadeIn 200ms ease-out;
    // Animates the dialog card.
    & > [data-ui='DialogCard'] {
      animation: zoomIn 200ms ease-out;
    }
  ` : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]``;
}
const DialogContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createGlobalScopedContext"])("@sanity/ui/context/dialog", {
    version: 0
});
function useDialog() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(DialogContext);
}
function isTargetWithinScope(boundaryElement, portalElement, target) {
    return !boundaryElement || !portalElement ? !0 : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["containsOrEqualsElement"])(boundaryElement, target) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["containsOrEqualsElement"])(portalElement, target);
}
const StyledDialog = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Layer"]).withConfig({
    displayName: "StyledDialog",
    componentId: "sc-4n4xb3-0"
})(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["responsivePaddingStyle"], dialogStyle, responsiveDialogPositionStyle, animationDialogStyle), DialogContainer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Container"]).withConfig({
    displayName: "DialogContainer",
    componentId: "sc-4n4xb3-1"
})`&:not([hidden]){display:flex;}width:100%;height:100%;flex-direction:column;align-items:center;justify-content:center;`, DialogCardRoot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"]).withConfig({
    displayName: "DialogCardRoot",
    componentId: "sc-4n4xb3-2"
})`&:not([hidden]){display:flex;}width:100%;min-height:0;max-height:100%;overflow:hidden;overflow:clip;`, DialogLayout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Flex"]).withConfig({
    displayName: "DialogLayout",
    componentId: "sc-4n4xb3-3"
})`flex:1;min-height:0;width:100%;`, DialogHeader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"]).withConfig({
    displayName: "DialogHeader",
    componentId: "sc-4n4xb3-4"
})`position:relative;z-index:2;`, DialogContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"]).withConfig({
    displayName: "DialogContent",
    componentId: "sc-4n4xb3-5"
})`position:relative;z-index:1;overflow:auto;outline:none;`, DialogFooter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"]).withConfig({
    displayName: "DialogFooter",
    componentId: "sc-4n4xb3-6"
})`position:relative;z-index:3;`, DialogCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(44), { __unstable_autoFocus: autoFocus, __unstable_hideCloseButton: hideCloseButton, children, contentRef: forwardedContentRef, footer, header, id, onClickOutside, onClose, portal: portalProp, radius: radiusProp, scheme, shadow: shadowProp, width: widthProp } = props, portal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePortal"])(), portalElement = portalProp ? portal.elements?.[portalProp] || null : portal.element, boundaryElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBoundaryElement"])().element;
    let t0;
    $[0] !== radiusProp ? (t0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(radiusProp), $[0] = radiusProp, $[1] = t0) : t0 = $[1];
    const radius = t0;
    let t1;
    $[2] !== shadowProp ? (t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(shadowProp), $[2] = shadowProp, $[3] = t1) : t1 = $[3];
    const shadow = t1;
    let t2;
    $[4] !== widthProp ? (t2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(widthProp), $[4] = widthProp, $[5] = t2) : t2 = $[5];
    const width = t2, ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), contentRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), layer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayer"])(), { isTopLayer } = layer, labelId = `${id}_label`, showCloseButton = !!onClose && hideCloseButton === !1, showHeader = !!header || showCloseButton;
    let t3;
    $[6] === Symbol.for("react.memo_cache_sentinel") ? (t3 = ()=>ref.current, $[6] = t3) : t3 = $[6], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t3);
    let t4;
    $[7] === Symbol.for("react.memo_cache_sentinel") ? (t4 = ()=>contentRef.current, $[7] = t4) : t4 = $[7], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedContentRef, t4);
    let t5, t6;
    $[8] !== autoFocus ? (t5 = ()=>{
        autoFocus && ref.current && focusFirstDescendant(ref.current);
    }, t6 = [
        autoFocus,
        ref
    ], $[8] = autoFocus, $[9] = t5, $[10] = t6) : (t5 = $[9], t6 = $[10]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    let t7;
    $[11] !== boundaryElement || $[12] !== isTopLayer || $[13] !== onClose || $[14] !== portalElement ? (t7 = (event)=>{
        if (!isTopLayer || !onClose) return;
        const target = document.activeElement;
        target && !isTargetWithinScope(boundaryElement, portalElement, target) || event.key === "Escape" && (event.preventDefault(), event.stopPropagation(), onClose());
    }, $[11] = boundaryElement, $[12] = isTopLayer, $[13] = onClose, $[14] = portalElement, $[15] = t7) : t7 = $[15], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGlobalKeyDown"])(t7);
    let t8;
    $[16] !== boundaryElement || $[17] !== isTopLayer || $[18] !== onClickOutside || $[19] !== portalElement ? (t8 = isTopLayer && onClickOutside && ((event_0)=>{
        const target_0 = event_0.target;
        target_0 && !isTargetWithinScope(boundaryElement, portalElement, target_0) || onClickOutside();
    }), $[16] = boundaryElement, $[17] = isTopLayer, $[18] = onClickOutside, $[19] = portalElement, $[20] = t8) : t8 = $[20];
    let t9;
    $[21] === Symbol.for("react.memo_cache_sentinel") ? (t9 = ()=>[
            ref.current
        ], $[21] = t9) : t9 = $[21], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClickOutsideEvent"])(t8, t9);
    let t10;
    $[22] !== header || $[23] !== labelId || $[24] !== onClose || $[25] !== showCloseButton || $[26] !== showHeader ? (t10 = showHeader && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(DialogHeader, {
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Flex"], {
            align: "flex-start",
            padding: 3,
            children: [
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
                    flex: 1,
                    padding: 2,
                    children: header && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                        id: labelId,
                        size: 1,
                        weight: "semibold",
                        children: header
                    })
                }),
                showCloseButton && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
                    flex: "none",
                    children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        "aria-label": "Close dialog",
                        disabled: !onClose,
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CloseIcon"],
                        mode: "bleed",
                        onClick: onClose,
                        padding: 2
                    })
                })
            ]
        })
    }), $[22] = header, $[23] = labelId, $[24] = onClose, $[25] = showCloseButton, $[26] = showHeader, $[27] = t10) : t10 = $[27];
    let t11;
    $[28] !== children ? (t11 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(DialogContent, {
        flex: 1,
        ref: contentRef,
        tabIndex: -1,
        children
    }), $[28] = children, $[29] = t11) : t11 = $[29];
    let t12;
    $[30] !== footer ? (t12 = footer && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(DialogFooter, {
        children: footer
    }), $[30] = footer, $[31] = t12) : t12 = $[31];
    let t13;
    $[32] !== t10 || $[33] !== t11 || $[34] !== t12 ? (t13 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(DialogLayout, {
        direction: "column",
        children: [
            t10,
            t11,
            t12
        ]
    }), $[32] = t10, $[33] = t11, $[34] = t12, $[35] = t13) : t13 = $[35];
    let t14;
    $[36] !== radius || $[37] !== scheme || $[38] !== shadow || $[39] !== t13 ? (t14 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(DialogCardRoot, {
        radius,
        ref,
        scheme,
        shadow,
        children: t13
    }), $[36] = radius, $[37] = scheme, $[38] = shadow, $[39] = t13, $[40] = t14) : t14 = $[40];
    let t15;
    return $[41] !== t14 || $[42] !== width ? (t15 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(DialogContainer, {
        "data-ui": "DialogCard",
        width,
        children: t14
    }), $[41] = t14, $[42] = width, $[43] = t15) : t15 = $[43], t15;
});
DialogCard.displayName = "ForwardRef(DialogCard)";
const Dialog = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(70), dialog = useDialog(), { layer } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme_v2"])();
    let _positionProp, _zOffsetProp, children, contentRef, footer, header, id, onActivate, onClickOutside, onClose, onFocus, portalProp, restProps, scheme, t0, t1, t2, t3, t4, t5, t6;
    $[0] !== props ? ({ __unstable_autoFocus: t0, __unstable_hideCloseButton: t1, cardRadius: t2, cardShadow: t3, children, contentRef, footer, header, id, onActivate, onClickOutside, onClose, onFocus, padding: t4, portal: portalProp, position: _positionProp, scheme, width: t5, zOffset: _zOffsetProp, animate: t6, ...restProps } = props, $[0] = props, $[1] = _positionProp, $[2] = _zOffsetProp, $[3] = children, $[4] = contentRef, $[5] = footer, $[6] = header, $[7] = id, $[8] = onActivate, $[9] = onClickOutside, $[10] = onClose, $[11] = onFocus, $[12] = portalProp, $[13] = restProps, $[14] = scheme, $[15] = t0, $[16] = t1, $[17] = t2, $[18] = t3, $[19] = t4, $[20] = t5, $[21] = t6) : (_positionProp = $[1], _zOffsetProp = $[2], children = $[3], contentRef = $[4], footer = $[5], header = $[6], id = $[7], onActivate = $[8], onClickOutside = $[9], onClose = $[10], onFocus = $[11], portalProp = $[12], restProps = $[13], scheme = $[14], t0 = $[15], t1 = $[16], t2 = $[17], t3 = $[18], t4 = $[19], t5 = $[20], t6 = $[21]);
    const autoFocus = t0 === void 0 ? !0 : t0, hideCloseButton = t1 === void 0 ? !1 : t1, cardRadiusProp = t2 === void 0 ? 4 : t2, cardShadow = t3 === void 0 ? 3 : t3, paddingProp = t4 === void 0 ? 3 : t4, widthProp = t5 === void 0 ? 0 : t5, _animate = t6 === void 0 ? !1 : t6, positionProp = _positionProp ?? (dialog.position || "fixed"), zOffsetProp = _zOffsetProp ?? (dialog.zOffset || layer.dialog.zOffset), animate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePrefersReducedMotion"])() ? !1 : _animate, portal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePortal"])(), portalElement = portalProp ? portal.elements?.[portalProp] || null : portal.element, boundaryElement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBoundaryElement"])().element;
    let t7;
    $[22] !== cardRadiusProp ? (t7 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(cardRadiusProp), $[22] = cardRadiusProp, $[23] = t7) : t7 = $[23];
    const cardRadius = t7;
    let t8;
    $[24] !== paddingProp ? (t8 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(paddingProp), $[24] = paddingProp, $[25] = t8) : t8 = $[25];
    const padding = t8;
    let t9;
    $[26] !== positionProp ? (t9 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(positionProp), $[26] = positionProp, $[27] = t9) : t9 = $[27];
    const position = t9;
    let t10;
    $[28] !== widthProp ? (t10 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(widthProp), $[28] = widthProp, $[29] = t10) : t10 = $[29];
    const width = t10;
    let t11;
    $[30] !== zOffsetProp ? (t11 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(zOffsetProp), $[30] = zOffsetProp, $[31] = t11) : t11 = $[31];
    const zOffset = t11, preDivRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), postDivRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), cardRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), focusedElementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t12;
    $[32] !== onFocus ? (t12 = (event)=>{
        onFocus?.(event);
        const target = event.target, cardElement = cardRef.current;
        if (cardElement && target === preDivRef.current) {
            focusLastDescendant(cardElement);
            return;
        }
        if (cardElement && target === postDivRef.current) {
            focusFirstDescendant(cardElement);
            return;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(event.target) && (focusedElementRef.current = event.target);
    }, $[32] = onFocus, $[33] = t12) : t12 = $[33];
    const handleFocus = t12, labelId = `${id}_label`, rootClickTimeoutRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(void 0);
    let t13;
    $[34] !== boundaryElement || $[35] !== portalElement ? (t13 = ()=>{
        rootClickTimeoutRef.current && clearTimeout(rootClickTimeoutRef.current), rootClickTimeoutRef.current = setTimeout(()=>{
            const activeElement = document.activeElement;
            if (activeElement && !isTargetWithinScope(boundaryElement, portalElement, activeElement)) {
                const target_0 = focusedElementRef.current;
                if (!target_0 || !document.body.contains(target_0)) {
                    const cardElement_0 = cardRef.current;
                    cardElement_0 && focusFirstDescendant(cardElement_0);
                    return;
                }
                target_0.focus();
            }
        }, 0);
    }, $[34] = boundaryElement, $[35] = portalElement, $[36] = t13) : t13 = $[36];
    const handleRootClick = t13;
    let t14;
    $[37] === Symbol.for("react.memo_cache_sentinel") ? (t14 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        ref: preDivRef,
        tabIndex: 0
    }), $[37] = t14) : t14 = $[37];
    let t15;
    $[38] !== autoFocus || $[39] !== cardRadius || $[40] !== cardShadow || $[41] !== children || $[42] !== contentRef || $[43] !== footer || $[44] !== header || $[45] !== hideCloseButton || $[46] !== id || $[47] !== onClickOutside || $[48] !== onClose || $[49] !== portalProp || $[50] !== scheme || $[51] !== width ? (t15 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(DialogCard, {
        __unstable_autoFocus: autoFocus,
        __unstable_hideCloseButton: hideCloseButton,
        contentRef,
        footer,
        header,
        id,
        onClickOutside,
        onClose,
        portal: portalProp,
        radius: cardRadius,
        ref: cardRef,
        scheme,
        shadow: cardShadow,
        width,
        children
    }), $[38] = autoFocus, $[39] = cardRadius, $[40] = cardShadow, $[41] = children, $[42] = contentRef, $[43] = footer, $[44] = header, $[45] = hideCloseButton, $[46] = id, $[47] = onClickOutside, $[48] = onClose, $[49] = portalProp, $[50] = scheme, $[51] = width, $[52] = t15) : t15 = $[52];
    let t16;
    $[53] === Symbol.for("react.memo_cache_sentinel") ? (t16 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        ref: postDivRef,
        tabIndex: 0
    }), $[53] = t16) : t16 = $[53];
    let t17;
    $[54] !== animate || $[55] !== handleFocus || $[56] !== handleRootClick || $[57] !== id || $[58] !== labelId || $[59] !== onActivate || $[60] !== padding || $[61] !== position || $[62] !== ref || $[63] !== restProps || $[64] !== t15 || $[65] !== zOffset ? (t17 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(StyledDialog, {
        ...restProps,
        $animate: animate,
        $padding: padding,
        $position: position,
        "aria-labelledby": labelId,
        "aria-modal": !0,
        "data-ui": "Dialog",
        id,
        onActivate,
        onClick: handleRootClick,
        onFocus: handleFocus,
        ref,
        role: "dialog",
        zOffset,
        children: [
            t14,
            t15,
            t16
        ]
    }), $[54] = animate, $[55] = handleFocus, $[56] = handleRootClick, $[57] = id, $[58] = labelId, $[59] = onActivate, $[60] = padding, $[61] = position, $[62] = ref, $[63] = restProps, $[64] = t15, $[65] = zOffset, $[66] = t17) : t17 = $[66];
    let t18;
    return $[67] !== portalProp || $[68] !== t17 ? (t18 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Portal"], {
        __unstable_name: portalProp,
        children: t17
    }), $[67] = portalProp, $[68] = t17, $[69] = t18) : t18 = $[69], t18;
});
Dialog.displayName = "ForwardRef(Dialog)";
function DialogProvider(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6), { children, position, zOffset } = props;
    let t0;
    $[0] !== position || $[1] !== zOffset ? (t0 = {
        version: 0,
        position,
        zOffset
    }, $[0] = position, $[1] = zOffset, $[2] = t0) : t0 = $[2];
    const contextValue = t0;
    let t1;
    return $[3] !== children || $[4] !== contextValue ? (t1 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(DialogContext.Provider, {
        value: contextValue,
        children
    }), $[3] = children, $[4] = contextValue, $[5] = t1) : t1 = $[5], t1;
}
DialogProvider.displayName = "DialogProvider";
const MenuButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(62), { __unstable_disableRestoreFocusOnClose: t0, boundaryElement: deprecated_boundaryElement, button: buttonProp, id, menu: menuProp, onClose, onOpen, placement: deprecated_placement, popoverScheme: deprecated_popoverScheme, portal: t1, popover, popoverRadius: deprecated_popoverRadius, preventOverflow: deprecated_preventOverflow } = props, disableRestoreFocusOnClose = t0 === void 0 ? !1 : t0, deprecated_portal = t1 === void 0 ? !0 : t1, [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!1), [shouldFocus, setShouldFocus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), [buttonElement, setButtonElement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t2;
    $[0] === Symbol.for("react.memo_cache_sentinel") ? (t2 = [], $[0] = t2) : t2 = $[0];
    const [menuElements, setChildMenuElements] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2), openRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(open);
    let t3, t4;
    $[1] !== onOpen || $[2] !== open ? (t3 = ()=>{
        onOpen && open && !openRef.current && onOpen();
    }, t4 = [
        onOpen,
        open
    ], $[1] = onOpen, $[2] = open, $[3] = t3, $[4] = t4) : (t3 = $[3], t4 = $[4]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    let t5, t6;
    $[5] !== onClose || $[6] !== open ? (t5 = ()=>{
        onClose && !open && openRef.current && onClose();
    }, t6 = [
        onClose,
        open
    ], $[5] = onClose, $[6] = open, $[7] = t5, $[8] = t6) : (t5 = $[7], t6 = $[8]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    let t7, t8;
    $[9] !== open ? (t7 = ()=>{
        openRef.current = open;
    }, t8 = [
        open
    ], $[9] = open, $[10] = t7, $[11] = t8) : (t7 = $[10], t8 = $[11]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t7, t8);
    let t9;
    $[12] === Symbol.for("react.memo_cache_sentinel") ? (t9 = ()=>{
        setOpen(_temp$2), setShouldFocus(null);
    }, $[12] = t9) : t9 = $[12];
    const handleButtonClick = t9;
    let t10;
    $[13] !== open ? (t10 = (event)=>{
        open && event.preventDefault();
    }, $[13] = open, $[14] = t10) : t10 = $[14];
    const handleMouseDown = t10;
    let t11;
    $[15] === Symbol.for("react.memo_cache_sentinel") ? (t11 = (event_0)=>{
        if (event_0.key === "ArrowDown" || event_0.key === "Enter" || event_0.key === " ") {
            event_0.preventDefault(), setOpen(!0), setShouldFocus("first");
            return;
        }
        if (event_0.key === "ArrowUp") {
            event_0.preventDefault(), setOpen(!0), setShouldFocus("last");
            return;
        }
    }, $[15] = t11) : t11 = $[15];
    const handleButtonKeyDown = t11;
    let t12;
    $[16] !== buttonElement || $[17] !== menuElements ? (t12 = (event_1)=>{
        const target = event_1.target;
        if (target instanceof Node && !(buttonElement && (target === buttonElement || buttonElement.contains(target)))) {
            for (const el of menuElements)if (target === el || el.contains(target)) return;
            setOpen(!1);
        }
    }, $[16] = buttonElement, $[17] = menuElements, $[18] = t12) : t12 = $[18];
    const handleMenuClickOutside = t12;
    let t13;
    $[19] !== buttonElement || $[20] !== disableRestoreFocusOnClose ? (t13 = ()=>{
        setOpen(!1), !disableRestoreFocusOnClose && buttonElement && buttonElement.focus();
    }, $[19] = buttonElement, $[20] = disableRestoreFocusOnClose, $[21] = t13) : t13 = $[21];
    const handleMenuEscape = t13;
    let t14;
    $[22] !== menuElements ? (t14 = (event_2)=>{
        const target_0 = event_2.relatedTarget;
        if (target_0 instanceof Node) {
            for (const el_0 of menuElements)if (el_0 === target_0 || el_0.contains(target_0)) return;
            setOpen(!1);
        }
    }, $[22] = menuElements, $[23] = t14) : t14 = $[23];
    const handleBlur = t14;
    let t15;
    $[24] !== buttonElement || $[25] !== disableRestoreFocusOnClose ? (t15 = ()=>{
        setOpen(!1), !disableRestoreFocusOnClose && buttonElement && buttonElement.focus();
    }, $[24] = buttonElement, $[25] = disableRestoreFocusOnClose, $[26] = t15) : t15 = $[26];
    const handleItemClick = t15;
    let t16;
    $[27] === Symbol.for("react.memo_cache_sentinel") ? (t16 = (el_1)=>(setChildMenuElements((els)=>els.concat([
                el_1
            ])), ()=>setChildMenuElements((els_0)=>els_0.filter((_el)=>_el !== el_1))), $[27] = t16) : t16 = $[27];
    const registerElement = t16;
    let t17;
    $[28] !== buttonElement || $[29] !== handleBlur || $[30] !== handleItemClick || $[31] !== handleMenuClickOutside || $[32] !== handleMenuEscape || $[33] !== id || $[34] !== menuProp || $[35] !== shouldFocus ? (t17 = menuProp && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"])(menuProp, {
        "aria-labelledby": id,
        onBlurCapture: handleBlur,
        onClickOutside: handleMenuClickOutside,
        onEscape: handleMenuEscape,
        onItemClick: handleItemClick,
        originElement: buttonElement,
        registerElement,
        shouldFocus
    }), $[28] = buttonElement, $[29] = handleBlur, $[30] = handleItemClick, $[31] = handleMenuClickOutside, $[32] = handleMenuEscape, $[33] = id, $[34] = menuProp, $[35] = shouldFocus, $[36] = t17) : t17 = $[36];
    const menu = t17;
    let t18;
    $[37] !== buttonProp || $[38] !== handleMouseDown || $[39] !== id || $[40] !== open ? (t18 = buttonProp && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"])(buttonProp, {
        "data-ui": "MenuButton",
        id,
        onClick: handleButtonClick,
        onKeyDown: handleButtonKeyDown,
        onMouseDown: handleMouseDown,
        "aria-haspopup": !0,
        "aria-expanded": open,
        ref: setButtonElement,
        selected: buttonProp.props.selected ?? open
    }), $[37] = buttonProp, $[38] = handleMouseDown, $[39] = id, $[40] = open, $[41] = t18) : t18 = $[41];
    const button = t18;
    let t19, t20;
    $[42] !== buttonElement ? (t19 = ()=>buttonElement, t20 = [
        buttonElement
    ], $[42] = buttonElement, $[43] = t19, $[44] = t20) : (t19 = $[43], t20 = $[44]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t19, t20);
    let t21;
    $[45] !== popover ? (t21 = popover || {}, $[45] = popover, $[46] = t21) : t21 = $[46];
    let t22;
    $[47] !== deprecated_boundaryElement || $[48] !== deprecated_placement || $[49] !== deprecated_popoverRadius || $[50] !== deprecated_popoverScheme || $[51] !== deprecated_portal || $[52] !== deprecated_preventOverflow || $[53] !== t21 ? (t22 = {
        boundaryElement: deprecated_boundaryElement,
        overflow: "auto",
        placement: deprecated_placement,
        portal: deprecated_portal,
        preventOverflow: deprecated_preventOverflow,
        radius: deprecated_popoverRadius,
        scheme: deprecated_popoverScheme,
        ...t21
    }, $[47] = deprecated_boundaryElement, $[48] = deprecated_placement, $[49] = deprecated_popoverRadius, $[50] = deprecated_popoverScheme, $[51] = deprecated_portal, $[52] = deprecated_preventOverflow, $[53] = t21, $[54] = t22) : t22 = $[54];
    const popoverProps = t22;
    let t23;
    $[55] !== button ? (t23 = button || /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {}), $[55] = button, $[56] = t23) : t23 = $[56];
    let t24;
    return $[57] !== menu || $[58] !== open || $[59] !== popoverProps || $[60] !== t23 ? (t24 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popover"], {
        "data-ui": "MenuButton__popover",
        ...popoverProps,
        content: menu,
        open,
        children: t23
    }), $[57] = menu, $[58] = open, $[59] = popoverProps, $[60] = t23, $[61] = t24) : t24 = $[61], t24;
});
MenuButton.displayName = "ForwardRef(MenuButton)";
function _temp$2(v) {
    return !v;
}
const keyframe = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["keyframes"]`
  0% {
    background-position: 100%;
  }
  100% {
    background-position: -100%;
  }
`, animation = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
  background-image: linear-gradient(
    to right,
    var(--card-skeleton-color-from),
    var(--card-skeleton-color-to),
    var(--card-skeleton-color-from),
    var(--card-skeleton-color-from),
    var(--card-skeleton-color-from)
  );
  background-position: 100%;
  background-size: 200% 100%;
  background-attachment: fixed;
  animation-name: ${keyframe};
  animation-timing-function: ease-in-out;
  animation-iteration-count: infinite;
  animation-duration: 2000ms;
`, skeletonStyle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
  opacity: ${({ $visible })=>$visible ? 1 : 0};
  transition: opacity 200ms ease-in;

  @media screen and (prefers-reduced-motion: no-preference) {
    ${({ $animated })=>$animated ? animation : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
            background-color: var(--card-skeleton-color-from);
          `}
  }

  @media screen and (prefers-reduced-motion: reduce) {
    background-color: var(--card-skeleton-color-from);
  }
`, StyledSkeleton$1 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"]).withConfig({
    displayName: "StyledSkeleton",
    componentId: "sc-ebtpni-0"
})(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["responsiveRadiusStyle"], skeletonStyle), Skeleton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    let delay, radius, restProps, t0;
    $[0] !== props ? ({ animated: t0, delay, radius, ...restProps } = props, $[0] = props, $[1] = delay, $[2] = radius, $[3] = restProps, $[4] = t0) : (delay = $[1], radius = $[2], restProps = $[3], t0 = $[4]);
    const animated = t0 === void 0 ? !1 : t0, [visible, setVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(!delay);
    let t1, t2;
    $[5] !== delay ? (t1 = ()=>{
        if (!delay) return;
        const timeout = setTimeout(()=>{
            setVisible(!0);
        }, delay);
        return ()=>{
            clearTimeout(timeout);
        };
    }, t2 = [
        delay
    ], $[5] = delay, $[6] = t1, $[7] = t2) : (t1 = $[6], t2 = $[7]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    $[8] !== radius ? (t3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(radius), $[8] = radius, $[9] = t3) : t3 = $[9];
    const t4 = delay ? visible : !0;
    let t5;
    return $[10] !== animated || $[11] !== ref || $[12] !== restProps || $[13] !== t3 || $[14] !== t4 ? (t5 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledSkeleton$1, {
        ...restProps,
        $animated: animated,
        $radius: t3,
        $visible: t4,
        ref
    }), $[10] = animated, $[11] = ref, $[12] = restProps, $[13] = t3, $[14] = t4, $[15] = t5) : t5 = $[15], t5;
});
Skeleton.displayName = "ForwardRef(Skeleton)";
const StyledSkeleton = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(Skeleton).withConfig({
    displayName: "StyledSkeleton",
    componentId: "sc-2p7a1v-0"
})((props)=>{
    const { $size, $style } = props, { font, media } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), fontStyle = font[$style];
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_responsive"])(media, $size, (sizeIndex)=>{
        const fontSize = fontStyle.sizes[sizeIndex];
        return {
            height: fontSize.lineHeight - fontSize.ascenderHeight - fontSize.descenderHeight
        };
    });
}), TextSkeleton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    let restProps, t0;
    $[0] !== props ? ({ size: t0, ...restProps } = props, $[0] = props, $[1] = restProps, $[2] = t0) : (restProps = $[1], t0 = $[2]);
    const size = t0 === void 0 ? 2 : t0;
    let t1;
    $[3] !== size ? (t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(size), $[3] = size, $[4] = t1) : t1 = $[4];
    const $size = t1;
    let t2;
    return $[5] !== $size || $[6] !== ref || $[7] !== restProps ? (t2 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledSkeleton, {
        ...restProps,
        $size,
        ref,
        $style: "text"
    }), $[5] = $size, $[6] = ref, $[7] = restProps, $[8] = t2) : t2 = $[8], t2;
});
TextSkeleton.displayName = "ForwardRef(TextSkeleton)";
const LabelSkeleton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    let restProps, t0;
    $[0] !== props ? ({ size: t0, ...restProps } = props, $[0] = props, $[1] = restProps, $[2] = t0) : (restProps = $[1], t0 = $[2]);
    const size = t0 === void 0 ? 2 : t0;
    let t1;
    $[3] !== size ? (t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(size), $[3] = size, $[4] = t1) : t1 = $[4];
    const $size = t1;
    let t2;
    return $[5] !== $size || $[6] !== ref || $[7] !== restProps ? (t2 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledSkeleton, {
        ...restProps,
        $size,
        ref,
        $style: "label"
    }), $[5] = $size, $[6] = ref, $[7] = restProps, $[8] = t2) : t2 = $[8], t2;
});
LabelSkeleton.displayName = "ForwardRef(LabelSkeleton)";
const HeadingSkeleton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    let restProps, t0;
    $[0] !== props ? ({ size: t0, ...restProps } = props, $[0] = props, $[1] = restProps, $[2] = t0) : (restProps = $[1], t0 = $[2]);
    const size = t0 === void 0 ? 2 : t0;
    let t1;
    $[3] !== size ? (t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(size), $[3] = size, $[4] = t1) : t1 = $[4];
    const $size = t1;
    let t2;
    return $[5] !== $size || $[6] !== ref || $[7] !== restProps ? (t2 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledSkeleton, {
        ...restProps,
        $size,
        ref,
        $style: "heading"
    }), $[5] = $size, $[6] = ref, $[7] = restProps, $[8] = t2) : t2 = $[8], t2;
});
HeadingSkeleton.displayName = "ForwardRef(HeadingSkeleton)";
const CodeSkeleton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    let restProps, t0;
    $[0] !== props ? ({ size: t0, ...restProps } = props, $[0] = props, $[1] = restProps, $[2] = t0) : (restProps = $[1], t0 = $[2]);
    const size = t0 === void 0 ? 2 : t0;
    let t1;
    $[3] !== size ? (t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_getArrayProp"])(size), $[3] = size, $[4] = t1) : t1 = $[4];
    const $size = t1;
    let t2;
    return $[5] !== $size || $[6] !== ref || $[7] !== restProps ? (t2 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledSkeleton, {
        ...restProps,
        $size,
        ref,
        $style: "code"
    }), $[5] = $size, $[6] = ref, $[7] = restProps, $[8] = t2) : t2 = $[8], t2;
});
CodeSkeleton.displayName = "ForwardRef(CodeSkeleton)";
const TabPanel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, ref) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    let flex, restProps;
    $[0] !== props ? ({ flex, ...restProps } = props, $[0] = props, $[1] = flex, $[2] = restProps) : (flex = $[1], restProps = $[2]);
    const t0 = props.tabIndex === void 0 ? 0 : props.tabIndex;
    let t1;
    return $[3] !== flex || $[4] !== props.children || $[5] !== ref || $[6] !== restProps || $[7] !== t0 ? (t1 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
        "data-ui": "TabPanel",
        ...restProps,
        flex,
        ref,
        role: "tabpanel",
        tabIndex: t0,
        children: props.children
    }), $[3] = flex, $[4] = props.children, $[5] = ref, $[6] = restProps, $[7] = t0, $[8] = t1) : t1 = $[8], t1;
});
TabPanel.displayName = "ForwardRef(TabPanel)";
const LOADING_BAR_HEIGHT = 2, STATUS_CARD_TONE = {
    error: "critical",
    warning: "caution",
    success: "positive",
    info: "neutral"
}, BUTTON_TONE = {
    error: "critical",
    warning: "caution",
    success: "positive",
    info: "neutral"
}, TextBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Flex"]).withConfig({
    displayName: "TextBox",
    componentId: "sc-1rr7rxo-0"
})`overflow-x:auto;`, StyledToast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"]).withConfig({
    displayName: "StyledToast",
    componentId: "sc-1rr7rxo-1"
})`pointer-events:all;width:100%;position:relative;overflow:hidden;overflow:clip;&[data-has-duration]{padding-bottom:calc(${LOADING_BAR_HEIGHT}px / 2);}`, LoadingBar = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].div.withConfig({
    displayName: "LoadingBar",
    componentId: "sc-1rr7rxo-2"
})`display:flex;position:absolute;bottom:0px;top:0px;left:0px;right:0px;pointer-events:none;z-index:-1;overflow:hidden;overflow:clip;background:transparent;align-items:flex-end;will-change:opacity;`, LoadingBarMask = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"]).withConfig({
    displayName: "LoadingBarMask",
    componentId: "sc-1rr7rxo-3"
})`position:absolute;top:0;left:-${LOADING_BAR_HEIGHT}px;right:-${LOADING_BAR_HEIGHT}px;bottom:${LOADING_BAR_HEIGHT}px;z-index:1;`, LoadingBarProgress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"]).withConfig({
    displayName: "LoadingBarProgress",
    componentId: "sc-1rr7rxo-4"
})`display:block;height:100%;width:100%;transform-origin:0% 50%;background-color:${(props)=>{
    const { color } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return color.button.default[props.tone].enabled.bg;
}};`, ROLES = {
    error: "alert",
    warning: "alert",
    success: "alert",
    info: "alert"
}, LONG_ENOUGH_BUT_NOT_TOO_LONG = 1e3 * 60 * 60 * 24 * 24;
function Toast(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(50);
    let closable, description, duration, onClose, restProps, status, t0, title, updatedAt;
    $[0] !== props ? ({ closable, description, duration, onClose, radius: t0, title, status, updatedAt, ...restProps } = props, $[0] = props, $[1] = closable, $[2] = description, $[3] = duration, $[4] = onClose, $[5] = restProps, $[6] = status, $[7] = t0, $[8] = title, $[9] = updatedAt) : (closable = $[1], description = $[2], duration = $[3], onClose = $[4], restProps = $[5], status = $[6], t0 = $[7], title = $[8], updatedAt = $[9]);
    const radius = t0 === void 0 ? 3 : t0, cardTone = status ? STATUS_CARD_TONE[status] : "default", buttonTone = status ? BUTTON_TONE[status] : "default", role = status ? ROLES[status] : "status", visualDuration = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePrefersReducedMotion"])() ? 0 : 0.26;
    let t1;
    $[10] !== visualDuration ? (t1 = visualDuration ? {
        type: "spring",
        visualDuration,
        bounce: 0.25
    } : {
        duration: 0
    }, $[10] = visualDuration, $[11] = t1) : t1 = $[11];
    const transition = t1, hasDuration = duration && isFinite(duration) && duration < LONG_ENOUGH_BUT_NOT_TOO_LONG;
    let t2;
    $[12] === Symbol.for("react.memo_cache_sentinel") ? (t2 = [
        "hidden",
        "initial"
    ], $[12] = t2) : t2 = $[12];
    const initial = t2;
    let t3;
    $[13] === Symbol.for("react.memo_cache_sentinel") ? (t3 = [
        "visible",
        "slideIn"
    ], $[13] = t3) : t3 = $[13];
    const animate = t3;
    let t4;
    $[14] === Symbol.for("react.memo_cache_sentinel") ? (t4 = [
        "hidden",
        "slideOut"
    ], $[14] = t4) : t4 = $[14];
    const exit = t4, t5 = hasDuration ? "" : void 0;
    let t6;
    $[15] !== title ? (t6 = title && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
        size: 1,
        weight: "medium",
        children: title
    }), $[15] = title, $[16] = t6) : t6 = $[16];
    let t7;
    $[17] !== description || $[18] !== transition ? (t7 = description && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(MotionText, {
        muted: !0,
        size: 1,
        variants: content,
        transition,
        children: description
    }), $[17] = description, $[18] = transition, $[19] = t7) : t7 = $[19];
    let t8;
    $[20] !== t6 || $[21] !== t7 ? (t8 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TextBox, {
        flex: 1,
        padding: 3,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stack"], {
            space: 3,
            children: [
                t6,
                t7
            ]
        })
    }), $[20] = t6, $[21] = t7, $[22] = t8) : t8 = $[22];
    let t9;
    $[23] !== buttonTone || $[24] !== closable || $[25] !== onClose ? (t9 = closable && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
        padding: 1,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
            as: "button",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CloseIcon"],
            mode: "bleed",
            padding: 2,
            tone: buttonTone,
            onClick: onClose,
            style: {
                verticalAlign: "top"
            }
        })
    }), $[23] = buttonTone, $[24] = closable, $[25] = onClose, $[26] = t9) : t9 = $[26];
    let t10;
    $[27] !== t8 || $[28] !== t9 || $[29] !== transition ? (t10 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(MotionFlex, {
        align: "flex-start",
        variants: content,
        transition,
        children: [
            t8,
            t9
        ]
    }), $[27] = t8, $[28] = t9, $[29] = transition, $[30] = t10) : t10 = $[30];
    let t11;
    $[31] !== cardTone || $[32] !== duration || $[33] !== hasDuration || $[34] !== onClose || $[35] !== radius || $[36] !== transition || $[37] !== updatedAt || $[38] !== visualDuration ? (t11 = hasDuration && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(MotionLoadingBar, {
        variants: content,
        transition,
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LoadingBarMask, {
                tone: cardTone,
                radius
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(MotionLoadingBarProgress, {
                tone: cardTone,
                initial: {
                    scaleX: 0
                },
                animate: {
                    scaleX: 1
                },
                transition: {
                    delay: visualDuration,
                    duration: duration / 1e3,
                    ease: "linear"
                },
                onAnimationComplete: onClose
            }, `progress-${updatedAt}`)
        ]
    }), $[31] = cardTone, $[32] = duration, $[33] = hasDuration, $[34] = onClose, $[35] = radius, $[36] = transition, $[37] = updatedAt, $[38] = visualDuration, $[39] = t11) : t11 = $[39];
    let t12;
    return $[40] !== cardTone || $[41] !== radius || $[42] !== restProps || $[43] !== role || $[44] !== t10 || $[45] !== t11 || $[46] !== t5 || $[47] !== transition || $[48] !== visualDuration ? (t12 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(MotionToast, {
        "data-ui": "Toast",
        role,
        ...restProps,
        "data-has-duration": t5,
        custom: visualDuration,
        radius,
        shadow: 2,
        tone: cardTone,
        forwardedAs: "li",
        layout: "position",
        variants: container,
        initial,
        animate,
        exit,
        transition,
        children: [
            t10,
            t11
        ]
    }), $[40] = cardTone, $[41] = radius, $[42] = restProps, $[43] = role, $[44] = t10, $[45] = t11, $[46] = t5, $[47] = transition, $[48] = visualDuration, $[49] = t12) : t12 = $[49], t12;
}
Toast.displayName = "Toast";
const container = {
    initial: {
        y: 32,
        scale: 0.5,
        zIndex: 1
    },
    hidden: {
        opacity: 0
    },
    visible: (visualDuration)=>visualDuration ? {
            opacity: 1,
            transition: {
                when: "beforeChildren",
                staggerChildren: visualDuration / 3,
                duration: visualDuration / 3
            }
        } : {
            opacity: 1
        },
    slideIn: {
        y: 0,
        scale: 1
    },
    slideOut: {
        zIndex: 0,
        scale: 0.75
    }
}, content = {
    initial: {
        willChange: "transform"
    },
    hidden: {
        opacity: 0
    },
    visible: {
        opacity: 1
    }
}, MotionToast = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].create(StyledToast), MotionFlex = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].create(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Flex"]), MotionText = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].create(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"]), MotionLoadingBar = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].create(LoadingBar), MotionLoadingBarProgress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].create(LoadingBarProgress);
function useMounted() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribe, _temp$1, _temp2);
}
function _temp2() {
    return !1;
}
function _temp$1() {
    return !0;
}
const subscribe = ()=>()=>{}, ToastContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createGlobalScopedContext"])("@sanity/ui/context/toast", null);
function ToastLayer(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9), { children, padding: t0, paddingX, paddingY, gap: t1 } = props, padding = t0 === void 0 ? 4 : t0, gap = t1 === void 0 ? 3 : t1, { zIndex } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayer"])();
    let t2;
    $[0] !== zIndex ? (t2 = {
        zIndex
    }, $[0] = zIndex, $[1] = t2) : t2 = $[1];
    let t3;
    return $[2] !== children || $[3] !== gap || $[4] !== padding || $[5] !== paddingX || $[6] !== paddingY || $[7] !== t2 ? (t3 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledLayer, {
        forwardedAs: "ul",
        "data-ui": "ToastProvider",
        padding,
        paddingX,
        paddingY,
        gap,
        columns: 1,
        style: t2,
        children
    }), $[2] = children, $[3] = gap, $[4] = padding, $[5] = paddingX, $[6] = paddingY, $[7] = t2, $[8] = t3) : t3 = $[8], t3;
}
ToastLayer.displayName = "ToastLayer";
const StyledLayer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Grid"]).withConfig({
    displayName: "StyledLayer",
    componentId: "sc-1tbwn58-0"
})`box-sizing:border-box;position:fixed;right:0;bottom:0;list-style:none;pointer-events:none;max-width:420px;width:100%;`;
let toastId = 0;
function generateToastId() {
    return String(toastId++);
}
function ToastProvider(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13), { children, padding, paddingX, paddingY, gap, zOffset: t0 } = props, zOffset = t0 === void 0 ? 1 : t0;
    let t1;
    $[0] === Symbol.for("react.memo_cache_sentinel") ? (t1 = [], $[0] = t1) : t1 = $[0];
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1), mounted = useMounted();
    let t2;
    $[1] === Symbol.for("react.memo_cache_sentinel") ? (t2 = {
        version: 0,
        push: (params)=>{
            const id = params.id || generateToastId(), duration = params.duration || 5e3;
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startTransition"])(()=>{
                setState((prevState)=>{
                    if (duration === 0.01) return prevState.filter((toast)=>toast.id !== id);
                    const dismiss = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startTransition"])(()=>setState((currentState)=>currentState.filter((toast_0)=>toast_0.id !== id)));
                    return [
                        ...prevState.filter((toast_1)=>toast_1.id !== id),
                        {
                            dismiss,
                            id,
                            updatedAt: Date.now(),
                            params: {
                                ...params,
                                duration
                            }
                        }
                    ];
                });
            }), id;
        }
    }, $[1] = t2) : t2 = $[1];
    const value = t2;
    let t3;
    $[2] !== gap || $[3] !== mounted || $[4] !== padding || $[5] !== paddingX || $[6] !== paddingY || $[7] !== state || $[8] !== zOffset ? (t3 = mounted && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LayerProvider"], {
        zOffset,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ToastLayer, {
            padding,
            paddingX,
            paddingY,
            gap,
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                initial: !1,
                mode: "popLayout",
                children: state.map(_temp)
            })
        })
    }), $[2] = gap, $[3] = mounted, $[4] = padding, $[5] = paddingX, $[6] = paddingY, $[7] = state, $[8] = zOffset, $[9] = t3) : t3 = $[9];
    let t4;
    return $[10] !== children || $[11] !== t3 ? (t4 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(ToastContext.Provider, {
        value,
        children: [
            children,
            t3
        ]
    }), $[10] = children, $[11] = t3, $[12] = t4) : t4 = $[12], t4;
}
function _temp(t0) {
    const { dismiss: dismiss_0, id: id_0, params: params_0, updatedAt } = t0;
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Toast, {
        closable: params_0.closable,
        description: params_0.description,
        onClose: dismiss_0,
        status: params_0.status,
        title: params_0.title,
        duration: params_0.duration,
        updatedAt
    }, id_0);
}
ToastProvider.displayName = "ToastProvider";
function useToast() {
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ToastContext);
    if (!value) throw new Error("useToast(): missing context value");
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isRecord"])(value) || value.version !== 0) throw new Error("useToast(): the context value is not compatible");
    return value;
}
function _findPrevItemElement(state, itemElements, focusedElement) {
    const idx = itemElements.indexOf(focusedElement), els = itemElements.slice(0, idx), len = els.length;
    for(let i = len - 1; i >= 0; i -= 1){
        const itemKey = els[i].getAttribute("data-tree-key");
        if (!itemKey) continue;
        const segments = itemKey.split("/");
        segments.pop();
        const p = [];
        let expanded = !0;
        for(let j = 0; j < segments.length; j += 1){
            p.push(segments[j]);
            const k = p.join("/");
            if (!state[k]?.expanded) {
                expanded = !1;
                break;
            }
        }
        if (expanded) return els[i];
    }
    return null;
}
function _findNextItemElement(state, itemElements, focusedElement) {
    const idx = itemElements.indexOf(focusedElement), els = itemElements.slice(idx), len = itemElements.length;
    for(let i = 1; i < len; i += 1){
        if (!els[i]) continue;
        const itemKey = els[i].getAttribute("data-tree-key");
        if (!itemKey) continue;
        const segments = itemKey.split("/");
        segments.pop();
        const p = [];
        let expanded = !0;
        for(let j = 0; j < segments.length; j += 1){
            p.push(segments[j]);
            const k = p.join("/");
            if (!state[k]?.expanded) {
                expanded = !1;
                break;
            }
        }
        if (expanded) return els[i];
    }
    return null;
}
function _focusItemElement(el) {
    if (el.getAttribute("role") === "treeitem" && el.focus(), el.getAttribute("role") === "none") {
        const firstChild = el.firstChild;
        firstChild && firstChild instanceof HTMLElement && firstChild.focus();
    }
}
const TreeContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createGlobalScopedContext"])("@sanity/ui/context/tree", null), Tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function(props, forwardedRef) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(38);
    let children, gap, onFocus, restProps, t0;
    $[0] !== props ? ({ children, gap, space: t0, onFocus, ...restProps } = props, $[0] = props, $[1] = children, $[2] = gap, $[3] = onFocus, $[4] = restProps, $[5] = t0) : (children = $[1], gap = $[2], onFocus = $[3], restProps = $[4], t0 = $[5]);
    const spacing = gap === void 0 ? t0 === void 0 ? 1 : t0 : gap, ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), [focusedElement, setFocusedElement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null), focusedElementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(focusedElement);
    let t1;
    $[6] === Symbol.for("react.memo_cache_sentinel") ? (t1 = [], $[6] = t1) : t1 = $[6];
    const path = t1;
    let t2;
    $[7] === Symbol.for("react.memo_cache_sentinel") ? (t2 = [], $[7] = t2) : t2 = $[7];
    const [itemElements, setItemElements] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t2);
    let t3;
    $[8] === Symbol.for("react.memo_cache_sentinel") ? (t3 = {}, $[8] = t3) : t3 = $[8];
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t3), stateRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(state);
    let t4;
    $[9] === Symbol.for("react.memo_cache_sentinel") ? (t4 = ()=>ref.current, $[9] = t4) : t4 = $[9], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"])(forwardedRef, t4);
    let t5, t6;
    $[10] !== focusedElement ? (t5 = ()=>{
        focusedElementRef.current = focusedElement;
    }, t6 = [
        focusedElement
    ], $[10] = focusedElement, $[11] = t5, $[12] = t6) : (t5 = $[11], t6 = $[12]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    let t7, t8;
    $[13] !== state ? (t7 = ()=>{
        stateRef.current = state;
    }, t8 = [
        state
    ], $[13] = state, $[14] = t7, $[15] = t8) : (t7 = $[14], t8 = $[15]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t7, t8);
    let t9;
    $[16] === Symbol.for("react.memo_cache_sentinel") ? (t9 = (element, path_0, expanded, selected)=>(setState((s)=>({
                ...s,
                [path_0]: {
                    element,
                    expanded
                }
            })), selected && setFocusedElement(element), ()=>{
            setState((s_0)=>{
                const newState = {
                    ...s_0
                };
                return delete newState[path_0], newState;
            });
        }), $[16] = t9) : t9 = $[16];
    const registerItem = t9;
    let t10;
    $[17] === Symbol.for("react.memo_cache_sentinel") ? (t10 = (path_1, expanded_0)=>{
        setState((s_1)=>{
            const itemState = s_1[path_1];
            return itemState ? {
                ...s_1,
                [path_1]: {
                    ...itemState,
                    expanded: expanded_0
                }
            } : s_1;
        });
    }, $[17] = t10) : t10 = $[17];
    const setExpanded = t10, t11 = focusedElement || itemElements[0] || null;
    let t12;
    $[18] !== spacing || $[19] !== state || $[20] !== t11 ? (t12 = {
        version: 0,
        focusedElement: t11,
        level: 0,
        path,
        registerItem,
        setExpanded,
        setFocusedElement,
        gap: spacing,
        space: spacing,
        state
    }, $[18] = spacing, $[19] = state, $[20] = t11, $[21] = t12) : t12 = $[21];
    const contextValue = t12;
    let t13;
    $[22] !== itemElements ? (t13 = (event)=>{
        if (focusedElementRef.current) {
            if (event.key === "ArrowDown") {
                event.preventDefault();
                const nextEl = _findNextItemElement(stateRef.current, itemElements, focusedElementRef.current);
                nextEl && (_focusItemElement(nextEl), setFocusedElement(nextEl));
                return;
            }
            if (event.key === "ArrowUp") {
                event.preventDefault();
                const prevEl = _findPrevItemElement(stateRef.current, itemElements, focusedElementRef.current);
                prevEl && (_focusItemElement(prevEl), setFocusedElement(prevEl));
                return;
            }
            if (event.key === "ArrowLeft") {
                event.preventDefault();
                const itemKey = focusedElementRef.current.getAttribute("data-tree-key");
                if (!itemKey) return;
                const itemState_0 = stateRef.current[itemKey];
                if (!itemState_0) return;
                if (itemState_0.expanded) setState((s_2)=>{
                    const itemState_1 = s_2[itemKey];
                    return itemState_1 ? {
                        ...s_2,
                        [itemKey]: {
                            ...itemState_1,
                            expanded: !1
                        }
                    } : s_2;
                });
                else {
                    const itemPath = itemKey.split("/");
                    itemPath.pop();
                    const parentKey = itemPath.join("/"), parentState = parentKey && stateRef.current[parentKey];
                    parentState && (parentState.element.focus(), setFocusedElement(parentState.element));
                }
                return;
            }
            if (event.key === "ArrowRight") {
                event.preventDefault();
                const focusedKey = focusedElementRef.current.getAttribute("data-tree-key");
                if (!focusedKey) return;
                stateRef.current[focusedKey]?.expanded || setState((s_3)=>{
                    const itemState_2 = s_3[focusedKey];
                    return itemState_2 ? {
                        ...s_3,
                        [focusedKey]: {
                            ...itemState_2,
                            expanded: !0
                        }
                    } : s_3;
                });
                return;
            }
        }
    }, $[22] = itemElements, $[23] = t13) : t13 = $[23];
    const handleKeyDown = t13;
    let t14;
    $[24] !== onFocus ? (t14 = (event_0)=>{
        setFocusedElement(event_0.target), onFocus?.(event_0);
    }, $[24] = onFocus, $[25] = t14) : t14 = $[25];
    const handleFocus = t14;
    let t15;
    $[26] === Symbol.for("react.memo_cache_sentinel") ? (t15 = ()=>{
        if (!ref.current) return;
        const _itemElements = Array.from(ref.current.querySelectorAll('[data-ui="TreeItem"]'));
        setItemElements(_itemElements);
    }, $[26] = t15) : t15 = $[26];
    let t16;
    $[27] !== children ? (t16 = [
        children
    ], $[27] = children, $[28] = t16) : t16 = $[28], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t15, t16);
    let t17;
    $[29] !== children || $[30] !== handleFocus || $[31] !== handleKeyDown || $[32] !== restProps || $[33] !== spacing ? (t17 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stack"], {
        as: "ul",
        "data-ui": "Tree",
        ...restProps,
        onFocus: handleFocus,
        onKeyDown: handleKeyDown,
        ref,
        role: "tree",
        gap: spacing,
        children
    }), $[29] = children, $[30] = handleFocus, $[31] = handleKeyDown, $[32] = restProps, $[33] = spacing, $[34] = t17) : t17 = $[34];
    let t18;
    return $[35] !== contextValue || $[36] !== t17 ? (t18 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TreeContext.Provider, {
        value: contextValue,
        children: t17
    }), $[35] = contextValue, $[36] = t17, $[37] = t18) : t18 = $[37], t18;
});
Tree.displayName = "ForwardRef(Tree)";
function treeItemRootStyle() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    &[role='none'] > [role='treeitem'] {
      outline: none;
      cursor: default;
      border-radius: 3px;

      background-color: var(--card-bg-color);
      color: var(--treeitem-fg-color);

      &:focus {
        position: relative;
      }
    }

    &[role='treeitem'] {
      outline: none;

      & > div {
        cursor: default;
        border-radius: 3px;

        background-color: var(--card-bg-color);
        color: var(--treeitem-fg-color);
      }

      &:focus > div {
        position: relative;
      }
    }
  `;
}
function treeItemRootColorStyle(props) {
    const $tone = "default", { color } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme), tone = color.selectable[$tone];
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    &[role='none'] {
      & > [role='treeitem'] {
        ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_cardColorStyle"])(color, tone.enabled)}
      }

      &[data-selected] > [role='treeitem'] {
        ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_cardColorStyle"])(color, tone.pressed)}
      }

      @media (hover: hover) {
        &:not([data-selected]) > [role='treeitem']:not(:focus):hover {
          ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_cardColorStyle"])(color, tone.hovered)}
        }

        & > [role='treeitem']:focus {
          ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_cardColorStyle"])(color, tone.selected)}
        }
      }
    }

    &[role='treeitem'] {
      & > [data-ui='TreeItem__box'] {
        ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_cardColorStyle"])(color, tone.enabled)}
      }

      &[data-selected] > [data-ui='TreeItem__box'] {
        ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_cardColorStyle"])(color, tone.pressed)}
      }

      @media (hover: hover) {
        &:not([data-selected]):not(:focus) > [data-ui='TreeItem__box']:hover {
          ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_cardColorStyle"])(color, tone.hovered)}
        }

        &:focus > [data-ui='TreeItem__box'] {
          ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_cardColorStyle"])(color, tone.selected)}
        }
      }
    }
  `;
}
function treeItemBoxStyle(props) {
    const { $level } = props, { space } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$theme$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTheme_v2"])(props.theme);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"]`
    padding-left: ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rem"])(space[2] * $level)};

    &[data-as='a'] {
      text-decoration: none;
    }
  `;
}
function useTree() {
    const tree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(TreeContext);
    if (!tree) throw new Error("Tree: missing context value");
    return tree;
}
function TreeGroup(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    let children, restProps, t0;
    $[0] !== props ? ({ children, expanded: t0, ...restProps } = props, $[0] = props, $[1] = children, $[2] = restProps, $[3] = t0) : (children = $[1], restProps = $[2], t0 = $[3]);
    const expanded = t0 === void 0 ? !1 : t0, tree = useTree(), t1 = !expanded;
    let t2;
    return $[4] !== children || $[5] !== restProps || $[6] !== t1 || $[7] !== tree.gap ? (t2 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stack"], {
        as: "ul",
        "data-ui": "TreeGroup",
        ...restProps,
        hidden: t1,
        marginTop: tree.gap,
        role: "group",
        gap: tree.gap,
        children
    }), $[4] = children, $[5] = restProps, $[6] = t1, $[7] = tree.gap, $[8] = t2) : t2 = $[8], t2;
}
const StyledTreeItem = /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"].li.withConfig({
    displayName: "StyledTreeItem",
    componentId: "sc-iiskig-0"
})(treeItemRootStyle, treeItemRootColorStyle), TreeItemBox = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"]).attrs({
    forwardedAs: "a"
}).withConfig({
    displayName: "TreeItemBox",
    componentId: "sc-iiskig-1"
})(treeItemBoxStyle), ToggleArrowText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$components$2f$dist$2f$styled$2d$components$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"]).withConfig({
    displayName: "ToggleArrowText",
    componentId: "sc-iiskig-2"
})`& > svg{transition:transform 100ms;}`;
function TreeItem(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$node_modules$2f$react$2d$compiler$2d$runtime$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(114);
    let IconComponent, children, gap, href, idProp, linkAs, muted, onClick, restProps, t0, t1, t2, t3, t4, text, weight;
    $[0] !== props ? ({ children, expanded: t0, fontSize: t1, href, icon: IconComponent, id: idProp, linkAs, muted, onClick, padding: t2, selected: t3, gap, space: t4, text, weight, ...restProps } = props, $[0] = props, $[1] = IconComponent, $[2] = children, $[3] = gap, $[4] = href, $[5] = idProp, $[6] = linkAs, $[7] = muted, $[8] = onClick, $[9] = restProps, $[10] = t0, $[11] = t1, $[12] = t2, $[13] = t3, $[14] = t4, $[15] = text, $[16] = weight) : (IconComponent = $[1], children = $[2], gap = $[3], href = $[4], idProp = $[5], linkAs = $[6], muted = $[7], onClick = $[8], restProps = $[9], t0 = $[10], t1 = $[11], t2 = $[12], t3 = $[13], t4 = $[14], text = $[15], weight = $[16]);
    const expandedProp = t0 === void 0 ? !1 : t0, fontSize = t1 === void 0 ? 1 : t1, padding = t2 === void 0 ? 2 : t2, selected = t3 === void 0 ? !1 : t3, spacing = gap === void 0 ? t4 === void 0 ? 2 : t4 : gap, [rootElement, _setRootElement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t5;
    $[17] === Symbol.for("react.memo_cache_sentinel") ? (t5 = (node)=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startTransition"])(()=>_setRootElement(node));
    }, $[17] = t5) : t5 = $[17];
    const setRootElement = t5, treeitemRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), tree = useTree(), { path, registerItem, setExpanded, setFocusedElement } = tree, _id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])(), id = idProp || _id;
    let t6, t7;
    if ($[18] !== id || $[19] !== path) {
        const itemPath = path.concat([
            id || ""
        ]);
        t6 = itemPath, t7 = itemPath.join("/"), $[18] = id, $[19] = path, $[20] = t6, $[21] = t7;
    } else t6 = $[20], t7 = $[21];
    let t8;
    $[22] !== t6 || $[23] !== t7 ? (t8 = [
        t6,
        t7
    ], $[22] = t6, $[23] = t7, $[24] = t8) : t8 = $[24];
    const [itemPath_0, itemKey] = t8, itemState = tree.state[itemKey], focused = tree.focusedElement === rootElement, expanded = itemState?.expanded === void 0 ? expandedProp : itemState?.expanded || !1, tabIndex = tree.focusedElement && tree.focusedElement === rootElement ? 0 : -1, t9 = tree.level + 1;
    let t10;
    $[25] !== itemPath_0 || $[26] !== t9 || $[27] !== tree ? (t10 = {
        ...tree,
        level: t9,
        path: itemPath_0
    }, $[25] = itemPath_0, $[26] = t9, $[27] = tree, $[28] = t10) : t10 = $[28];
    const contextValue = t10;
    let t11;
    $[29] !== expanded || $[30] !== itemKey || $[31] !== onClick || $[32] !== rootElement || $[33] !== setExpanded || $[34] !== setFocusedElement ? (t11 = (event)=>{
        onClick && onClick(event);
        const target = event.target;
        target instanceof HTMLElement && (target.getAttribute("data-ui") === "TreeItem" || target.closest('[data-ui="TreeItem__box"]')) && (event.stopPropagation(), setExpanded(itemKey, !expanded), setFocusedElement(rootElement));
    }, $[29] = expanded, $[30] = itemKey, $[31] = onClick, $[32] = rootElement, $[33] = setExpanded, $[34] = setFocusedElement, $[35] = t11) : t11 = $[35];
    const handleClick = t11;
    let t12;
    $[36] !== focused || $[37] !== rootElement ? (t12 = (event_0)=>{
        focused && event_0.key === "Enter" && (treeitemRef.current || rootElement)?.click();
    }, $[36] = focused, $[37] = rootElement, $[38] = t12) : t12 = $[38];
    const handleKeyDown = t12;
    let t13, t14;
    $[39] !== expanded || $[40] !== itemKey || $[41] !== registerItem || $[42] !== rootElement || $[43] !== selected ? (t13 = ()=>{
        if (rootElement) return registerItem(rootElement, itemKey, expanded, selected);
    }, t14 = [
        expanded,
        itemKey,
        registerItem,
        rootElement,
        selected
    ], $[39] = expanded, $[40] = itemKey, $[41] = registerItem, $[42] = rootElement, $[43] = selected, $[44] = t13, $[45] = t14) : (t13 = $[44], t14 = $[45]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t13, t14);
    const t15 = IconComponent || children ? "visible" : "hidden";
    let t16;
    $[46] !== t15 ? (t16 = {
        visibility: t15,
        pointerEvents: "none"
    }, $[46] = t15, $[47] = t16) : t16 = $[47];
    let t17;
    $[48] !== IconComponent || $[49] !== fontSize || $[50] !== muted || $[51] !== weight ? (t17 = IconComponent && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
        muted,
        size: fontSize,
        weight,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(IconComponent, {})
    }), $[48] = IconComponent, $[49] = fontSize, $[50] = muted, $[51] = weight, $[52] = t17) : t17 = $[52];
    let t18;
    $[53] !== IconComponent || $[54] !== expanded || $[55] !== fontSize || $[56] !== muted || $[57] !== weight ? (t18 = !IconComponent && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ToggleArrowText, {
        muted,
        size: fontSize,
        weight,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToggleArrowRightIcon"], {
            style: {
                transform: expanded ? "rotate(90deg)" : void 0
            }
        })
    }), $[53] = IconComponent, $[54] = expanded, $[55] = fontSize, $[56] = muted, $[57] = weight, $[58] = t18) : t18 = $[58];
    let t19;
    $[59] !== spacing || $[60] !== t16 || $[61] !== t17 || $[62] !== t18 ? (t19 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
        marginRight: spacing,
        style: t16,
        children: [
            t17,
            t18
        ]
    }), $[59] = spacing, $[60] = t16, $[61] = t17, $[62] = t18, $[63] = t19) : t19 = $[63];
    let t20;
    $[64] !== fontSize || $[65] !== muted || $[66] !== text || $[67] !== weight ? (t20 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Box"], {
        flex: 1,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
            muted,
            size: fontSize,
            textOverflow: "ellipsis",
            weight,
            children: text
        })
    }), $[64] = fontSize, $[65] = muted, $[66] = text, $[67] = weight, $[68] = t20) : t20 = $[68];
    let t21;
    $[69] !== padding || $[70] !== t19 || $[71] !== t20 ? (t21 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sanity$2f$ui$2f$dist$2f$_chunks$2d$es$2f$_visual$2d$editing$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Flex"], {
        padding,
        children: [
            t19,
            t20
        ]
    }), $[69] = padding, $[70] = t19, $[71] = t20, $[72] = t21) : t21 = $[72];
    const content2 = t21;
    if (href) {
        const t222 = selected ? "" : void 0;
        let t232;
        $[73] !== content2 || $[74] !== expanded || $[75] !== href || $[76] !== linkAs || $[77] !== tabIndex || $[78] !== tree.level ? (t232 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TreeItemBox, {
            $level: tree.level,
            "aria-expanded": expanded,
            as: linkAs,
            "data-ui": "TreeItem__box",
            href,
            ref: treeitemRef,
            role: "treeitem",
            tabIndex,
            children: content2
        }), $[73] = content2, $[74] = expanded, $[75] = href, $[76] = linkAs, $[77] = tabIndex, $[78] = tree.level, $[79] = t232) : t232 = $[79];
        let t242;
        $[80] !== children || $[81] !== expanded ? (t242 = children && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TreeGroup, {
            hidden: !expanded,
            children
        }), $[80] = children, $[81] = expanded, $[82] = t242) : t242 = $[82];
        let t252;
        $[83] !== contextValue || $[84] !== t242 ? (t252 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TreeContext.Provider, {
            value: contextValue,
            children: t242
        }), $[83] = contextValue, $[84] = t242, $[85] = t252) : t252 = $[85];
        let t262;
        return $[86] !== handleClick || $[87] !== id || $[88] !== itemKey || $[89] !== restProps || $[90] !== t222 || $[91] !== t232 || $[92] !== t252 ? (t262 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(StyledTreeItem, {
            "data-selected": t222,
            "data-tree-id": id,
            "data-tree-key": itemKey,
            "data-ui": "TreeItem",
            ...restProps,
            onClick: handleClick,
            ref: setRootElement,
            role: "none",
            children: [
                t232,
                t252
            ]
        }), $[86] = handleClick, $[87] = id, $[88] = itemKey, $[89] = restProps, $[90] = t222, $[91] = t232, $[92] = t252, $[93] = t262) : t262 = $[93], t262;
    }
    const t22 = selected ? "" : void 0;
    let t23;
    $[94] !== content2 || $[95] !== tree.level ? (t23 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TreeItemBox, {
        $level: tree.level,
        as: "div",
        "data-ui": "TreeItem__box",
        children: content2
    }), $[94] = content2, $[95] = tree.level, $[96] = t23) : t23 = $[96];
    let t24;
    $[97] !== children || $[98] !== expanded ? (t24 = children && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TreeGroup, {
        expanded,
        children
    }), $[97] = children, $[98] = expanded, $[99] = t24) : t24 = $[99];
    let t25;
    $[100] !== contextValue || $[101] !== t24 ? (t25 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TreeContext.Provider, {
        value: contextValue,
        children: t24
    }), $[100] = contextValue, $[101] = t24, $[102] = t25) : t25 = $[102];
    let t26;
    return $[103] !== expanded || $[104] !== handleClick || $[105] !== handleKeyDown || $[106] !== id || $[107] !== itemKey || $[108] !== restProps || $[109] !== t22 || $[110] !== t23 || $[111] !== t25 || $[112] !== tabIndex ? (t26 = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(StyledTreeItem, {
        "data-selected": t22,
        "data-ui": "TreeItem",
        "data-tree-id": id,
        "data-tree-key": itemKey,
        ...restProps,
        "aria-expanded": expanded,
        onClick: handleClick,
        onKeyDown: handleKeyDown,
        ref: setRootElement,
        role: "treeitem",
        tabIndex,
        children: [
            t23,
            t25
        ]
    }), $[103] = expanded, $[104] = handleClick, $[105] = handleKeyDown, $[106] = id, $[107] = itemKey, $[108] = restProps, $[109] = t22, $[110] = t23, $[111] = t25, $[112] = tabIndex, $[113] = t26) : t26 = $[113], t26;
}
TreeItem.displayName = "TreeItem";
;
}),
]);

//# debugId=393a6bd2-097b-956d-a8e5-547d586586b7
//# sourceMappingURL=node_modules_%40sanity_ui_dist_0~jmjfv._.js.map