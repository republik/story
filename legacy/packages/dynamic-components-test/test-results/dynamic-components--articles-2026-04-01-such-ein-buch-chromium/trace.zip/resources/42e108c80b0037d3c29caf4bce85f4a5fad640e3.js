;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="7e29ab75-275d-4307-cd42-9faea244af6a")}catch(e){}}();
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/packages/theme/__generated__/recipes/create-recipe.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createRecipe",
    ()=>createRecipe,
    "mergeRecipes",
    ()=>mergeRecipes
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$conditions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/conditions.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cva$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/cva.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/cx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
;
;
;
;
;
const createRecipe = (name, defaultVariants, compoundVariants)=>{
    const getVariantProps = (variants)=>{
        return {
            [name]: '__ignore__',
            ...defaultVariants,
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(variants)
        };
    };
    const recipeFn = (variants, withCompoundVariants = true)=>{
        const transform = (prop, value)=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cva$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assertCompoundVariant"])(name, compoundVariants, variants, prop);
            if (value === '__ignore__') {
                return {
                    className: name
                };
            }
            value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["withoutSpace"])(value);
            return {
                className: `${name}--${prop}_${value}`
            };
        };
        const recipeCss = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCss"])({
            conditions: {
                shift: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$conditions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortConditions"],
                finalize: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$conditions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeConditions"],
                breakpoints: {
                    keys: [
                        "base",
                        "sm",
                        "md",
                        "lg"
                    ]
                }
            },
            utility: {
                prefix: "r",
                toHash: (path, hashFn)=>hashFn(path.join(":")),
                transform
            }
        });
        const recipeStyles = getVariantProps(variants);
        if (withCompoundVariants) {
            const compoundVariantStyles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cva$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCompoundVariantCss"])(compoundVariants, recipeStyles);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cx"])(recipeCss(recipeStyles), (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(compoundVariantStyles));
        }
        return recipeCss(recipeStyles);
    };
    return {
        recipeFn,
        getVariantProps,
        __getCompoundVariantCss__: (variants)=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cva$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCompoundVariantCss"])(compoundVariants, getVariantProps(variants));
        }
    };
};
const mergeRecipes = (recipeA, recipeB)=>{
    if (recipeA && !recipeB) return recipeA;
    if (!recipeA && recipeB) return recipeB;
    const recipeFn = (...args)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cx"])(recipeA(...args), recipeB(...args));
    const variantKeys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniq"])(recipeA.variantKeys, recipeB.variantKeys);
    const variantMap = variantKeys.reduce((acc, key)=>{
        acc[key] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniq"])(recipeA.variantMap[key], recipeB.variantMap[key]);
        return acc;
    }, {});
    return Object.assign(recipeFn, {
        __recipe__: true,
        __name__: `${recipeA.__name__} ${recipeB.__name__}`,
        raw: (props)=>props,
        variantKeys,
        variantMap,
        splitVariantProps (props) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["splitProps"])(props, variantKeys);
        }
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/recipes/button.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "button",
    ()=>button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$recipes$2f$create$2d$recipe$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/recipes/create-recipe.mjs [app-client] (ecmascript)");
;
;
const buttonFn = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$recipes$2f$create$2d$recipe$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecipe"])('button', {
    "variant": "default",
    "size": "default"
}, [
    {
        "variant": "link",
        "size": "default",
        "css": {
            "p": "0"
        }
    },
    {
        "variant": "link",
        "size": "full",
        "css": {
            "p": "0",
            "width": "auto"
        }
    }
]);
const buttonVariantMap = {
    "variant": [
        "default",
        "link",
        "outline"
    ],
    "size": [
        "default",
        "small",
        "large",
        "full"
    ]
};
const buttonVariantKeys = Object.keys(buttonVariantMap);
const button = /* @__PURE__ */ Object.assign((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(buttonFn.recipeFn), {
    __recipe__: true,
    __name__: 'button',
    __getCompoundVariantCss__: buttonFn.__getCompoundVariantCss__,
    raw: (props)=>props,
    variantKeys: buttonVariantKeys,
    variantMap: buttonVariantMap,
    merge (recipe) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$recipes$2f$create$2d$recipe$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeRecipes"])(this, recipe);
    },
    splitVariantProps (props) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["splitProps"])(props, buttonVariantKeys);
    },
    getVariantProps: buttonFn.getVariantProps
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/recipes/editorial-content.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "editorialContent",
    ()=>editorialContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$recipes$2f$create$2d$recipe$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/recipes/create-recipe.mjs [app-client] (ecmascript)");
;
;
const editorialContentFn = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$recipes$2f$create$2d$recipe$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRecipe"])('editorial-content', {
    "theme": "editorial"
}, []);
const editorialContentVariantMap = {
    "theme": [
        "editorial",
        "meta"
    ]
};
const editorialContentVariantKeys = Object.keys(editorialContentVariantMap);
const editorialContent = /* @__PURE__ */ Object.assign((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(editorialContentFn.recipeFn), {
    __recipe__: true,
    __name__: 'editorialContent',
    __getCompoundVariantCss__: editorialContentFn.__getCompoundVariantCss__,
    raw: (props)=>props,
    variantKeys: editorialContentVariantKeys,
    variantMap: editorialContentVariantMap,
    merge (recipe) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$recipes$2f$create$2d$recipe$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeRecipes"])(this, recipe);
    },
    splitVariantProps (props) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["splitProps"])(props, editorialContentVariantKeys);
    },
    getVariantProps: editorialContentFn.getVariantProps
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/recipes/index.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$recipes$2f$button$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/recipes/button.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$recipes$2f$editorial$2d$content$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/recipes/editorial-content.mjs [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# debugId=7e29ab75-275d-4307-cd42-9faea244af6a
//# sourceMappingURL=packages_theme___generated___recipes_0~fea3.._.js.map