;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="4a10a907-55f5-a504-4c2c-a6612f2cff2a")}catch(e){}}();
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/www/src/app/lib/hooks/useScrollDirection.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useScrollDirection",
    ()=>useScrollDirection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
function useScrollDirection({ threshold = 5, downThreshold = threshold, upThreshold = threshold } = {}) {
    _s();
    const [scrollDirection, setScrollDirection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useScrollDirection.useEffect": ()=>{
            let lastScrollY = window.scrollY;
            let previousScrollY = window.scrollY;
            const updateScrollDirection = {
                "useScrollDirection.useEffect.updateScrollDirection": ()=>{
                    const scrollY = window.scrollY;
                    const direction = scrollY > lastScrollY ? 'down' : 'up';
                    // When suddenly scrolling in the opposite direction, reset the lastScrollY
                    // to ensure the thresholds are applied from that point on.
                    if (direction === 'down' && scrollY < previousScrollY || direction === 'up' && scrollY > previousScrollY) {
                        lastScrollY = scrollY > 0 ? scrollY : 0;
                    }
                    if (direction !== scrollDirection && (scrollY - lastScrollY > downThreshold || scrollY - lastScrollY < -1 * upThreshold)) {
                        setScrollDirection(direction);
                        lastScrollY = scrollY > 0 ? scrollY : 0;
                    }
                    previousScrollY = scrollY;
                }
            }["useScrollDirection.useEffect.updateScrollDirection"];
            window.addEventListener('scroll', updateScrollDirection); // add event listener
            return ({
                "useScrollDirection.useEffect": ()=>{
                    window.removeEventListener('scroll', updateScrollDirection); // clean up
                }
            })["useScrollDirection.useEffect"];
        }
    }["useScrollDirection.useEffect"], [
        scrollDirection,
        downThreshold,
        upThreshold
    ]);
    return scrollDirection;
}
_s(useScrollDirection, "wOqEq/0qzHTM+eZxoGcTM6raMBY=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/icons/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IconAccountBox",
    ()=>Hi,
    "IconAdd",
    ()=>Li,
    "IconArrowBack",
    ()=>Bi,
    "IconArrowDownward",
    ()=>Ni,
    "IconArrowDropDown",
    ()=>Ei,
    "IconArrowDropUp",
    ()=>Ii,
    "IconArrowForward",
    ()=>Qi,
    "IconArrowLeft",
    ()=>Fi,
    "IconArrowRight",
    ()=>Ri,
    "IconArrowUpward",
    ()=>Oi,
    "IconArticle",
    ()=>Di,
    "IconAudio",
    ()=>Ui,
    "IconAutopause",
    ()=>Ki,
    "IconAutoplay",
    ()=>Wi,
    "IconBack",
    ()=>Yi,
    "IconBlockquote",
    ()=>Xi,
    "IconBookmark",
    ()=>Ji,
    "IconBookmarkBorder",
    ()=>_i,
    "IconBreak",
    ()=>$i,
    "IconCalendar",
    ()=>ji,
    "IconCallReceived",
    ()=>pi,
    "IconCallSplit",
    ()=>e4,
    "IconCallToActionOutline",
    ()=>l4,
    "IconCancel",
    ()=>i4,
    "IconCancelOutline",
    ()=>t4,
    "IconChart",
    ()=>n4,
    "IconCheck",
    ()=>d4,
    "IconCheckCircle",
    ()=>m4,
    "IconCheckSmall",
    ()=>s4,
    "IconChevronLeft",
    ()=>o4,
    "IconChevronRight",
    ()=>g4,
    "IconClap",
    ()=>a4,
    "IconClapFilled",
    ()=>h4,
    "IconClose",
    ()=>v4,
    "IconCode",
    ()=>r4,
    "IconComputer",
    ()=>c4,
    "IconContentCopy",
    ()=>w4,
    "IconContentCopyOutline",
    ()=>y4,
    "IconDarkMode",
    ()=>S4,
    "IconDeleteOutline",
    ()=>f4,
    "IconDesktopMac",
    ()=>V4,
    "IconDevices",
    ()=>q4,
    "IconDiscussion",
    ()=>G4,
    "IconDoNotDisturbOn",
    ()=>u4,
    "IconDone",
    ()=>z4,
    "IconDownload",
    ()=>b4,
    "IconDragHandle",
    ()=>x4,
    "IconEdit",
    ()=>Z4,
    "IconEditCircle",
    ()=>C4,
    "IconError",
    ()=>k4,
    "IconErrorOutline",
    ()=>T4,
    "IconEtiquette",
    ()=>P4,
    "IconExpandLess",
    ()=>M4,
    "IconExpandMore",
    ()=>H4,
    "IconFavorite",
    ()=>L4,
    "IconFeatured",
    ()=>B4,
    "IconFilter",
    ()=>N4,
    "IconFilterList",
    ()=>E4,
    "IconFlag",
    ()=>I4,
    "IconFlagFilled",
    ()=>Q4,
    "IconFolder",
    ()=>R4,
    "IconFollow",
    ()=>O4,
    "IconFontSize",
    ()=>D4,
    "IconFormatBlockquote",
    ()=>U4,
    "IconFormatBold",
    ()=>K4,
    "IconFormatColorText",
    ()=>W4,
    "IconFormatItalic",
    ()=>X4,
    "IconFormatListBulleted",
    ()=>J4,
    "IconFormatListNumbered",
    ()=>_4,
    "IconFormatQuote",
    ()=>$4,
    "IconFormatStrikethrough",
    ()=>j4,
    "IconFormatSubscript",
    ()=>p4,
    "IconFormatSuperscript",
    ()=>e6,
    "IconForward",
    ()=>l6,
    "IconForward30",
    ()=>i6,
    "IconFullscreen",
    ()=>t6,
    "IconFullscreenExit",
    ()=>n6,
    "IconGallery",
    ()=>d6,
    "IconGears",
    ()=>m6,
    "IconGrade",
    ()=>s6,
    "IconHearing",
    ()=>o6,
    "IconHighlightOff",
    ()=>g6,
    "IconHome",
    ()=>a6,
    "IconImage",
    ()=>h6,
    "IconImageOutline",
    ()=>v6,
    "IconInfoOutline",
    ()=>r6,
    "IconInstagram",
    ()=>c6,
    "IconKeyboardArrowDown",
    ()=>w6,
    "IconKeyboardArrowLeft",
    ()=>y6,
    "IconKeyboardArrowRight",
    ()=>S6,
    "IconKeyboardArrowUp",
    ()=>f6,
    "IconKeyboardReturn",
    ()=>V6,
    "IconLanguage",
    ()=>q6,
    "IconLaptopMac",
    ()=>G6,
    "IconLens",
    ()=>u6,
    "IconLightMode",
    ()=>z6,
    "IconLink",
    ()=>b6,
    "IconList",
    ()=>x6,
    "IconLock",
    ()=>Z6,
    "IconLockOpen",
    ()=>C6,
    "IconLogoApple",
    ()=>A6,
    "IconLogoBluesky",
    ()=>T6,
    "IconLogoFacebook",
    ()=>P6,
    "IconLogoGoogle",
    ()=>H6,
    "IconLogoLinkedIn",
    ()=>B6,
    "IconLogoMastodon",
    ()=>N6,
    "IconLogoSignal",
    ()=>E6,
    "IconLogoTelegram",
    ()=>I6,
    "IconLogoThreema",
    ()=>Q6,
    "IconLogoTwitter",
    ()=>F6,
    "IconLogoVimeo",
    ()=>O6,
    "IconLogoWhatsApp",
    ()=>U6,
    "IconLogoX",
    ()=>W6,
    "IconLogoYouTube",
    ()=>Y6,
    "IconMail",
    ()=>J6,
    "IconMailOutline",
    ()=>_6,
    "IconMarkdown",
    ()=>$6,
    "IconMemo",
    ()=>p6,
    "IconMic",
    ()=>e3,
    "IconMood",
    ()=>l3,
    "IconMoreHorizontal",
    ()=>i3,
    "IconMoreVertical",
    ()=>t3,
    "IconNoteAdd",
    ()=>n3,
    "IconNotifications",
    ()=>d3,
    "IconNotificationsActive",
    ()=>m3,
    "IconNotificationsNone",
    ()=>s3,
    "IconNotificationsOff",
    ()=>o3,
    "IconNotificationsOn",
    ()=>g3,
    "IconOpenInNew",
    ()=>a3,
    "IconOpensource",
    ()=>h3,
    "IconOrderedList",
    ()=>v3,
    "IconParagraph",
    ()=>c3,
    "IconPause",
    ()=>w3,
    "IconPauseCircle",
    ()=>y3,
    "IconPauseCircleOutline",
    ()=>S3,
    "IconPdf",
    ()=>r3,
    "IconPerson",
    ()=>f3,
    "IconPersonOutline",
    ()=>V3,
    "IconPhoneIPhone",
    ()=>q3,
    "IconPlay",
    ()=>G3,
    "IconPlayCircleOutline",
    ()=>u3,
    "IconPlayListAddCheck",
    ()=>z3,
    "IconPlaylistAdd",
    ()=>b3,
    "IconPlaylistRemove",
    ()=>x3,
    "IconPodcast",
    ()=>Z3,
    "IconPodcasts",
    ()=>C3,
    "IconPrint",
    ()=>A3,
    "IconPublic",
    ()=>k3,
    "IconPunchline",
    ()=>T3,
    "IconQuiz",
    ()=>P3,
    "IconQuizOutline",
    ()=>M3,
    "IconRadioButtonChecked",
    ()=>H3,
    "IconRadioButtonUnchecked",
    ()=>L3,
    "IconRadioChecked",
    ()=>B3,
    "IconRadioUnchecked",
    ()=>N3,
    "IconRateReview",
    ()=>E3,
    "IconRead",
    ()=>I3,
    "IconReadTime",
    ()=>Q3,
    "IconRefresh",
    ()=>F3,
    "IconRemove",
    ()=>R3,
    "IconRemoveCircle",
    ()=>O3,
    "IconRemoveOutline",
    ()=>D3,
    "IconReplay",
    ()=>U3,
    "IconReplay10",
    ()=>K3,
    "IconReply",
    ()=>W3,
    "IconReport",
    ()=>X3,
    "IconRevert",
    ()=>J3,
    "IconRewind",
    ()=>_3,
    "IconRotateLeftOutline",
    ()=>$3,
    "IconRssFeed",
    ()=>j3,
    "IconSchedule",
    ()=>p3,
    "IconSearch",
    ()=>et,
    "IconSearchMenu",
    ()=>lt,
    "IconSearchMenuBold",
    ()=>tt,
    "IconShare",
    ()=>dt,
    "IconSkipNext",
    ()=>mt,
    "IconSkipPrevious",
    ()=>st,
    "IconSmsFailedOutline",
    ()=>ot,
    "IconSpotify",
    ()=>gt,
    "IconStar",
    ()=>ht,
    "IconStars",
    ()=>vt,
    "IconSubdirectoryArrowLeft",
    ()=>rt,
    "IconSubdirectoryArrowRight",
    ()=>ct,
    "IconSubject",
    ()=>wt,
    "IconTabletMac",
    ()=>yt,
    "IconTag",
    ()=>St,
    "IconTelegram",
    ()=>ft,
    "IconTerminal",
    ()=>qt,
    "IconThreema",
    ()=>Gt,
    "IconTitle",
    ()=>zt,
    "IconTrendingFlat",
    ()=>bt,
    "IconUnfoldLess",
    ()=>xt,
    "IconUnfoldMore",
    ()=>Zt,
    "IconUnorderedList",
    ()=>Ct,
    "IconUnpublish",
    ()=>At,
    "IconVerticalAlignBottom",
    ()=>kt,
    "IconVerticalAlignTop",
    ()=>Tt,
    "IconViewHeadline",
    ()=>Pt,
    "IconViewQuilt",
    ()=>Mt,
    "IconVisibilityOff",
    ()=>Ht,
    "IconVolumeUp",
    ()=>Lt,
    "IconVpnKey",
    ()=>Bt,
    "IconWarning",
    ()=>Nt,
    "IconWifiOff",
    ()=>Et,
    "IconWrapText",
    ()=>It
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
var t = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M482 655q58 0 98-40t40-98q0-58-40-98t-98-40q-58 0-98 40t-40 98q0 58 40 98t98 40ZM180 936q-24 0-42-18t-18-42V276q0-24 18-42t42-18h600q24 0 42 18t18 42v600q0 24-18 42t-42 18H180Zm0-60h600v-37q-60-56-136-90.5T480 714q-88 0-164 34.5T180 839v37Z"
        })
    });
t.displayName = "SvgAccountBox";
var Hi = t;
;
var d = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M22.5 38V25.5H10v-3h12.5V10h3v12.5H38v3H25.5V38Z"
        })
    });
d.displayName = "SvgAdd";
var Li = d;
;
var s = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 896 160 576l320-320 42 42-248 248h526v60H274l248 248-42 42Z"
        })
    });
s.displayName = "SvgArrowBack";
var Bi = s;
;
var g = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M24 40 8 24l2.1-2.1 12.4 12.4V8h3v26.3l12.4-12.4L40 24Z"
        })
    });
g.displayName = "SvgArrowDownward";
var Ni = g;
;
var h = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m24 30-10-9.95h20Z"
        })
    });
h.displayName = "SvgArrowDropDown";
var Ei = h;
;
var r = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m14 28 10-10.05L34 28Z"
        })
    });
r.displayName = "SvgArrowDropUp";
var Ii = r;
;
var w = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m480 896-42-43 247-247H160v-60h525L438 299l42-43 320 320-320 320Z"
        })
    });
w.displayName = "SvgArrowForward";
var Qi = w;
;
var S = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M24 40 8 24 24 8l2.1 2.1-12.4 12.4H40v3H13.7l12.4 12.4Z"
        })
    });
_c = S;
S.displayName = "SvgArrowLeft";
var Fi = S;
;
var V = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m24 40-2.1-2.15L34.25 25.5H8v-3h26.25L21.9 10.15 24 8l16 16Z"
        })
    });
_c1 = V;
V.displayName = "SvgArrowRight";
var Ri = V;
;
var G = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M22.5 40V13.7L10.1 26.1 8 24 24 8l16 16-2.1 2.1-12.4-12.4V40Z"
        })
    });
_c2 = G;
G.displayName = "SvgArrowUpward";
var Oi = G;
;
var z = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M160 856v-60h386v60H160Zm0-166v-60h640v60H160Zm0-167v-60h640v60H160Zm0-167v-60h640v60H160Z"
        })
    });
z.displayName = "SvgArticle";
var Di = z;
;
var x = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M560 925v-62q97-28 158.5-107.5T780 575q0-101-61-181T560 287v-62q124 28 202 125.5T840 575q0 127-78 224.5T560 925ZM120 696V456h160l200-200v640L280 696H120Zm420 48V407q55 17 87.5 64T660 576q0 57-33 104t-87 64Z"
        })
    });
x.displayName = "SvgAudio";
var Ui = x;
;
var C = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M370 696V456h60v240h-60Zm160 0V456h60v240h-60Zm-43 320q-121 0-221-56.5T100 799v136H40V696h238v60H144q57 95 147 147.5T487 956q121 0 218-70.5T840 700l59 13q-43 136-156.5 219.5T487 1016ZM42 536q7-68 32-128.5T142 295l43 43q-35 45-56 95t-27 103H42Zm199-254-42-44q54-44 115-69t128-31v60q-52 5-101 25.5T241 282Zm478 0q-45-36-95-57.5T520 198v-60q68 6 128.5 31T761 238l-42 44Zm139 254q-5-51-28-103t-59-97l42-44q46 54 73 116.5T918 536h-60Z"
        })
    });
_c3 = C;
C.displayName = "SvgAutopause";
var Ki = C;
;
var k = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M390 738V414l252 162-252 162Zm97 278q-121 0-221-56.5T100 799v136H40V696h238v60H144q57 95 147 147.5T487 956q121 0 218-70.5T840 700l59 13q-43 136-156.5 219.5T487 1016ZM42 536q7-68 32-128.5T142 295l43 43q-35 45-56 95t-27 103H42Zm199-254-42-44q54-44 115-69t128-31v60q-52 5-101 25.5T241 282Zm478 0q-45-36-95-57.5T520 198v-60q68 6 128.5 31T761 238l-42 44Zm139 254q-5-51-28-103t-59-97l42-44q46 54 73 116.5T918 536h-60Z"
        })
    });
k.displayName = "SvgAutoplay";
var Wi = k;
;
var P = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        viewBox: "0 0 24 24",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M11.67 3.87L9.9 2.1 0 12l9.9 9.9 1.77-1.77L3.54 12z"
        })
    });
_c4 = P;
P.displayName = "SvgBack";
var Yi = P;
;
var H = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        className: "bi bi-blockquote-left",
        viewBox: "0 0 16 16",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M2.5 3a.5.5 0 0 0 0 1h11a.5.5 0 0 0 0-1h-11zm5 3a.5.5 0 0 0 0 1h6a.5.5 0 0 0 0-1h-6zm0 3a.5.5 0 0 0 0 1h6a.5.5 0 0 0 0-1h-6zm-5 3a.5.5 0 0 0 0 1h11a.5.5 0 0 0 0-1h-11zm.79-5.373c.112-.078.26-.17.444-.275L3.524 6c-.122.074-.272.17-.452.287-.18.117-.35.26-.51.428a2.425 2.425 0 0 0-.398.562c-.11.207-.164.438-.164.692 0 .36.072.65.217.873.144.219.385.328.72.328.215 0 .383-.07.504-.211a.697.697 0 0 0 .188-.463c0-.23-.07-.404-.211-.521-.137-.121-.326-.182-.568-.182h-.282c.024-.203.065-.37.123-.498a1.38 1.38 0 0 1 .252-.37 1.94 1.94 0 0 1 .346-.298zm2.167 0c.113-.078.262-.17.445-.275L5.692 6c-.122.074-.272.17-.452.287-.18.117-.35.26-.51.428a2.425 2.425 0 0 0-.398.562c-.11.207-.164.438-.164.692 0 .36.072.65.217.873.144.219.385.328.72.328.215 0 .383-.07.504-.211a.697.697 0 0 0 .188-.463c0-.23-.07-.404-.211-.521-.137-.121-.326-.182-.568-.182h-.282a1.75 1.75 0 0 1 .118-.492c.058-.13.144-.254.257-.375a1.94 1.94 0 0 1 .346-.3z"
        })
    });
_c5 = H;
H.displayName = "SvgBlockquote";
var Xi = H;
;
var B = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M200 936V271q0-24 18-42t42-18h440q24 0 42 18t18 42v665L480 816 200 936Z"
        })
    });
_c6 = B;
B.displayName = "SvgBookmark";
var Ji = B;
;
var E = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M200 936V271q0-24 18-42t42-18h440q24 0 42 18t18 42v665L480 816 200 936Zm60-91 220-93 220 93V271H260v574Zm0-574h440-440Z"
        })
    });
_c7 = E;
E.displayName = "SvgBookmarkBorder";
var _i = E;
;
var Q = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M360 816 121 577l239-239 43 43-167 167h544V376h60v231H237l166 166-43 43Z"
        })
    });
_c8 = Q;
Q.displayName = "SvgBreak";
var $i = Q;
;
var R = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 -960 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M212.309-100.001q-30.308 0-51.308-21t-21-51.308v-535.382q0-30.308 21-51.308t51.308-21h55.385v-84.615h61.537v84.615h303.076v-84.615h59.999v84.615h55.385q30.308 0 51.308 21t21 51.308v535.382q0 30.308-21 51.308t-51.308 21H212.309Zm0-59.999h535.382q4.616 0 8.463-3.846 3.846-3.847 3.846-8.463v-375.382H200v375.382q0 4.616 3.846 8.463 3.847 3.846 8.463 3.846ZM200-607.69h560v-100.001q0-4.616-3.846-8.463-3.847-3.846-8.463-3.846H212.309q-4.616 0-8.463 3.846-3.846 3.847-3.846 8.463v100.001Zm0 0V-720v112.31Z"
        })
    });
_c9 = R;
R.displayName = "SvgCalendar";
var ji = R;
;
var D = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M186.434 869.566V453.782h79.784v280.434l487.825-487.825 55.566 56.566-486.825 486.825h279.434v79.784H186.434Z"
        })
    });
_c10 = D;
D.displayName = "SvgCallReceived";
var pi = D;
;
var K = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M22.6 40V24.7L11 13.1v6.15H8V8h11.25v3h-6.1L25.6 23.45V40Zm5.65-18.2-2.1-2.1 8.7-8.7h-6.1V8H40v11.25h-3V13.1Z"
        })
    });
_c11 = K;
K.displayName = "SvgCallSplit";
var e4 = K;
;
var Y = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M236 782h488V677H236v105Zm-96 114q-24 0-42-18t-18-42V316q0-24 18-42t42-18h680q24 0 42 18t18 42v520q0 24-18 42t-42 18H140Zm0-60h680V316H140v520Zm0 0V316v520Z"
        })
    });
_c12 = Y;
Y.displayName = "SvgCallToActionOutline";
var l4 = Y;
;
var J = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m330 768 150-150 150 150 42-42-150-150 150-150-42-42-150 150-150-150-42 42 150 150-150 150 42 42Zm150 208q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Zm0-60q142 0 241-99.5T820 576q0-142-99-241t-241-99q-141 0-240.5 99T140 576q0 141 99.5 240.5T480 916Zm0-340Z"
        })
    });
_c13 = J;
J.displayName = "SvgCancel";
var i4 = J;
;
var $ = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m330 768 150-150 150 150 42-42-150-150 150-150-42-42-150 150-150-150-42 42 150 150-150 150 42 42Zm150 208q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Zm0-60q142 0 241-99.5T820 576q0-142-99-241t-241-99q-141 0-240.5 99T140 576q0 141 99.5 240.5T480 916Zm0-340Z"
        })
    });
$.displayName = "SvgCancelOutline";
var t4 = $;
;
var p = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        viewBox: "0 0 24 24",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4zm2.5 2.1h-15V5h15v14.1zm0-16.1h-15c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h15c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"
        })
    });
p.displayName = "SvgChart";
var n4 = p;
;
var l1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M378 810 154 586l43-43 181 181 384-384 43 43-427 427Z"
        })
    });
l1.displayName = "SvgCheck";
var d4 = l1;
;
var t1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m421 758 283-283-46-45-237 237-120-120-45 45 165 166Zm59 218q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Z"
        })
    });
t1.displayName = "SvgCheckCircle";
var m4 = t1;
;
var d1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        viewBox: "0 0 24 24",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M16.59 7.58L10 14.17l-3.59-3.58L5 12l5 5 8-8z"
        })
    });
d1.displayName = "SvgCheckSmall";
var s4 = d1;
;
var s1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M561 816 320 575l241-241 43 43-198 198 198 198-43 43Z"
        })
    });
s1.displayName = "SvgChevronLeft";
var o4 = s1;
;
var g1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m375 816-43-43 198-198-198-198 43-43 241 241-241 241Z"
        })
    });
g1.displayName = "SvgChevronRight";
var g4 = g1;
;
var h1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M11.23 5.15c.53.05 1.03.31 1.42.69l1.9 1.9s0 0 .01-.01c.37-.35.88-.5 1.4-.45.23.02.45.08.66.18.02-.04.05-.08.09-.12.37-.35.88-.5 1.4-.45.51.05 1 .29 1.38.66.38.37.64.85.72 1.36 0 .01 0 .03 0 .04l.38 5.53c.16 1.74-.39 3.39-1.84 4.84l-.55.55c-.6.6-1.77 1.17-2.94 1.57-1.17.4-2.48.68-3.39.59-.02 0-.04 0-.06-.01-.17 0-.34 0-.51-.02-1.73-.17-3.45-1.02-4.77-2.34l-3.54-3.54c-.39-.39-.64-.89-.69-1.42-.05-.53.11-1.06.48-1.43.22-.22.5-.37.8-.44-.29-.36-.49-.79-.53-1.24-.05-.53.11-1.06.48-1.43.22-.22.5-.37.8-.44-.29-.36-.49-.79-.53-1.24-.05-.53.11-1.06.48-1.43.38-.38.9-.53 1.43-.48.24.02.47.09.69.19.06-.35.21-.67.47-.93.38-.37.9-.53 1.43-.48.46.05.91.25 1.27.55.06-.09.13-.17.21-.25.38-.38.9-.53 1.43-.48ZM8.22 6.32c-.27-.03-.49.06-.63.19-.14.14-.22.35-.19.63.02.22.12.46.28.66h0s.03.04.04.06c.02.03.05.06.08.08l4.22 4.23c.2.2.2.51 0 .71-.2.19-.51.19-.71 0l-4.22-4.23c-.06-.06-.12-.13-.17-.2l-.49-.52c-.24-.24-.53-.37-.81-.4-.27-.03-.49.06-.62.19-.14.14-.22.35-.19.62.03.28.17.57.41.81l3.54 3.54c.19.2.19.51 0 .71-.2.2-.51.19-.71 0l-2.35-2.35s0 0 0 0c-.24-.24-.54-.38-.81-.41-.27-.03-.49.06-.62.19-.14.14-.22.35-.19.62.03.28.17.57.41.81l2.95 2.95c.2.2.2.51 0 .71-.2.2-.51.2-.71 0l-1.76-1.77s0 0 0 0c-.24-.24-.54-.38-.81-.41-.27-.03-.49.06-.62.19-.14.14-.22.35-.19.63.03.28.17.57.41.81l3.54 3.54c1.18 1.18 2.68 1.91 4.16 2.06 1.45.14 3.01-.51 3.94-1.44l.55-.55c1.25-1.25 1.69-2.61 1.55-4.05h0s-.38-5.51-.38-5.51c-.04-.27-.19-.55-.42-.77-.24-.23-.52-.36-.79-.38-.26-.03-.47.05-.61.18-.12.11-.2.28-.21.5v.09l.07 1.24.07 1.24c0 .14-.04.27-.13.36-.02.03-.04.05-.06.08-.2.2-.51.2-.71 0l-5.25-5.24c-.24-.24-.54-.38-.81-.41ZM18.01 7.89c-.24-.02-.44.04-.57.15.33.35.56.79.63 1.26 0 .01 0 .03 0 .04l.38 5.53c.16 1.74-.39 3.39-1.84 4.84l-.15.14c.45-.23.82-.47 1.03-.69l.55-.55c1.25-1.25 1.69-2.61 1.55-4.05h0s-.38-5.51-.38-5.51c-.04-.27-.19-.55-.42-.77-.24-.23-.52-.36-.79-.38ZM11.13 6.14c-.27-.03-.49.06-.62.19-.09.09-.11.13-.12.17 0 .03-.01.08-.01.15l3.74 3.74v-.05s-.07-1.24-.07-1.24h0s0-.19 0-.19c0-.08.01-.16.03-.23l-2.13-2.13c-.24-.24-.54-.38-.81-.41ZM15 2.92c.21-.18.53-.15.7.06.18.21.15.53-.06.7l-1.18.99c-.21.18-.53.15-.7-.06-.18-.21-.15-.53.06-.7l1.19-.99ZM12.54 1.84c.09-.26.38-.4.64-.3.26.09.39.38.3.64l-.52 1.46c-.09.26-.38.4-.64.3-.26-.09-.4-.38-.3-.64l.52-1.46ZM10.33 1.32c.27-.03.52.17.55.45l.16 1.54c.03.27-.17.52-.45.55-.27.03-.52-.17-.55-.45l-.16-1.54c-.03-.27.17-.52.45-.55Z"
        })
    });
h1.displayName = "SvgClap";
var a4 = h1;
;
var r1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M4.81 14.53c-.27-.27-.6-.43-.91-.46-.31-.03-.55.06-.7.22-.15.15-.25.4-.22.7.03.31.19.64.46.91l3.78 3.78c1.32 1.32 3.01 2.15 4.68 2.31 1.62.16 3.39-.57 4.43-1.62l.62-.62c1.41-1.41 1.9-2.94 1.74-4.55h0s-.43-6.19-.43-6.19c-.05-.3-.21-.62-.47-.87-.27-.25-.59-.4-.89-.43-.3-.03-.53.06-.69.2-.13.13-.23.32-.24.56v.11l.08 1.39.08 1.39c0 .16-.05.3-.14.41-.02.03-.04.06-.07.09-.22.22-.57.22-.79 0l-5.89-5.89c-.27-.27-.6-.43-.91-.46-.31-.03-.55.06-.7.22-.15.15-.25.4-.22.7.02.25.13.51.31.75h.01s.03.05.04.07c.03.03.06.06.09.1l4.75 4.75c.22.22.22.58 0 .79-.22.22-.58.22-.79 0l-4.75-4.75c-.07-.07-.13-.14-.2-.22l-.55-.58c-.27-.26-.6-.42-.91-.45-.31-.03-.55.06-.7.22-.15.15-.25.4-.22.7.03.31.19.64.46.91l3.97 3.97c.22.22.22.58 0 .79-.22.22-.58.22-.79 0l-2.64-2.64s0 0 0 0c-.27-.27-.6-.43-.91-.46-.31-.03-.55.06-.7.22-.15.15-.25.4-.22.7.03.31.19.64.46.91l3.31 3.31c.22.22.22.58 0 .79-.22.22-.58.22-.79 0M19.3 7.28c-.27-.03-.49.04-.64.17.37.4.63.89.71 1.42 0 .01 0 .03 0 .04l.43 6.21c.18 1.96-.44 3.81-2.07 5.44l-.16.16c.51-.26.92-.53 1.16-.77l.62-.62c1.41-1.41 1.9-2.94 1.74-4.55h0s-.43-6.19-.43-6.19c-.05-.3-.21-.62-.47-.87-.27-.25-.59-.4-.89-.43ZM11.57 5.31c-.31-.03-.55.06-.7.22-.1.1-.12.15-.13.19 0 .03-.01.09-.01.17l4.2 4.2v-.05s-.08-1.39-.08-1.39h0s0-.22 0-.22c0-.09.01-.18.03-.26l-2.39-2.39c-.27-.27-.6-.43-.91-.46ZM14.99 3.13c.23-.15.54-.1.69.13.15.23.09.54-.13.69l-1.28.87c-.23.16-.54.1-.69-.13-.15-.23-.1-.54.13-.69l1.28-.87ZM12.66 1.81c.12-.25.42-.36.67-.24.25.12.35.42.24.67l-.66 1.4c-.12.25-.42.36-.67.24-.25-.12-.36-.42-.24-.67l.66-1.4ZM10.51 1.07c.28 0 .5.22.5.5v1.55c0 .28-.22.5-.5.5-.28 0-.5-.22-.5-.5v-1.54c0-.28.22-.5.5-.5Z"
        })
    });
r1.displayName = "SvgClapFilled";
var h4 = r1;
;
var w1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m12.45 37.65-2.1-2.1L21.9 24 10.35 12.45l2.1-2.1L24 21.9l11.55-11.55 2.1 2.1L26.1 24l11.55 11.55-2.1 2.1L24 26.1Z"
        })
    });
w1.displayName = "SvgClose";
var v4 = w1;
;
var S1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m16 35.9-12-12 12.1-12.1 2.15 2.15L8.3 23.9l9.85 9.85Zm15.9.1-2.15-2.15 9.95-9.95-9.85-9.85L32 11.9l12 12Z"
        })
    });
_c14 = S1;
S1.displayName = "SvgCode";
var r4 = S1;
;
var V1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 -960 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M40-120v-80h880v80H40Zm120-120q-33 0-56.5-23.5T80-320v-440q0-33 23.5-56.5T160-840h640q33 0 56.5 23.5T880-760v440q0 33-23.5 56.5T800-240H160Zm0-80h640v-440H160v440Zm0 0v-440 440Z"
        })
    });
_c15 = V1;
V1.displayName = "SvgComputer";
var c4 = V1;
;
var G1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M9 43.95q-1.2 0-2.1-.9-.9-.9-.9-2.1V10.8h3v30.15h23.7v3Zm6-6q-1.2 0-2.1-.9-.9-.9-.9-2.1v-28q0-1.2.9-2.1.9-.9 2.1-.9h22q1.2 0 2.1.9.9.9.9 2.1v28q0 1.2-.9 2.1-.9.9-2.1.9Zm0-3h22v-28H15v28Zm0 0v-28 28Z"
        })
    });
_c16 = G1;
G1.displayName = "SvgContentCopy";
var w4 = G1;
;
var z1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M180 975q-24 0-42-18t-18-42V312h60v603h474v60H180Zm120-120q-24 0-42-18t-18-42V235q0-24 18-42t42-18h440q24 0 42 18t18 42v560q0 24-18 42t-42 18H300Zm0-60h440V235H300v560Zm0 0V235v560Z"
        })
    });
z1.displayName = "SvgContentCopyOutline";
var y4 = z1;
;
var x1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 936q-150 0-255-105T120 576q0-150 105-255t255-105q8 0 17 .5t23 1.5q-36 32-56 79t-20 99q0 90 63 153t153 63q52 0 99-18.5t79-51.5q1 12 1.5 19.5t.5 14.5q0 150-105 255T480 936Z"
        })
    });
x1.displayName = "SvgDarkMode";
var S4 = x1;
;
var C1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M261 936q-24.75 0-42.375-17.625T201 876V306h-41v-60h188v-30h264v30h188v60h-41v570q0 24-18 42t-42 18H261Zm438-630H261v570h438V306ZM367 790h60V391h-60v399Zm166 0h60V391h-60v399ZM261 306v570-570Z"
        })
    });
_c17 = C1;
C1.displayName = "SvgDeleteOutline";
var f4 = C1;
;
var k1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M336 936v-35l84-85H140q-24 0-42-18t-18-42V276q0-24 18-42t42-18h680q24 0 42 18t18 42v480q0 24-18 42t-42 18H540l84 85v35H336ZM140 660h680V276H140v384Zm0 0V276v384Z"
        })
    });
k1.displayName = "SvgDesktopMac";
var V4 = k1;
;
var P1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M80 896v-90h86V316q0-24.75 17.625-42.375T226 256h620v60H226v490h234v90H80Zm479 0q-16.575 0-27.787-13.5Q520 869 520 852V415q0-16.575 11.213-27.787Q542.425 376 559 376h271.751Q850 376 865 386.5q15 10.5 15 28.5v437.273q0 18.584-14.5 31.155Q851 896 831 896H559Zm21-90h240V436H580v370Z"
        })
    });
_c18 = P1;
P1.displayName = "SvgDevices";
var q4 = P1;
;
var H1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M80 976V236q0-23 18-41.5t42-18.5h680q23 0 41.5 18.5T880 236v520q0 23-18.5 41.5T820 816H240L80 976Zm60-145 75-75h605V236H140v595Zm0-595v595-595Z"
        })
    });
_c19 = H1;
H1.displayName = "SvgDiscussion";
var G4 = H1;
;
var B1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M280 603h400v-60H280v60Zm200 373q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Zm0-60q142 0 241-99.5T820 576q0-142-99-241t-241-99q-141 0-240.5 99T140 576q0 141 99.5 240.5T480 916Zm0-340Z"
        })
    });
_c20 = B1;
B1.displayName = "SvgDoNotDisturbOn";
var u4 = B1;
;
var E1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M378 823.566 140.434 586l57.131-57.131L378 709.304l383.435-383.435L818.566 383 378 823.566Z"
        })
    });
_c21 = E1;
E1.displayName = "SvgDone";
var z4 = E1;
;
var Q1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M220 896q-24 0-42-18t-18-42V693h60v143h520V693h60v143q0 24-18 42t-42 18H220Zm260-153L287 550l43-43 120 120V256h60v371l120-120 43 43-193 193Z"
        })
    });
_c22 = Q1;
Q1.displayName = "SvgDownload";
var b4 = Q1;
;
var R1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M160 666v-60h640v60H160Zm0-120v-60h640v60H160Z"
        })
    });
_c23 = R1;
R1.displayName = "SvgDragHandle";
var x4 = R1;
;
var D1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M794 390 666 262l42-42q17-17 42.5-16.5T793 221l43 43q17 17 17 42t-17 42l-42 42Zm-42 42L248 936H120V808l504-504 128 128Z"
        })
    });
_c24 = D1;
D1.displayName = "SvgEdit";
var Z4 = D1;
;
var K1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 0 24 24",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", {
                fill: "currentColor",
                cx: 12,
                cy: 12,
                r: 12
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M6,15.5003472 L6,18 L8.49965283,18 L15.8719622,10.6276906 L13.3723094,8.12803777 L6,15.5003472 Z M17.8050271,8.69462575 C18.064991,8.43466185 18.064991,8.01472018 17.8050271,7.75475628 L16.2452437,6.19497292 C15.9852798,5.93500903 15.5653381,5.93500903 15.3053743,6.19497292 L14.0855437,7.4148035 L16.5851965,9.91445633 L17.8050271,8.69462575 Z",
                fill: "white"
            })
        ]
    });
_c25 = K1;
K1.displayName = "SvgEditCircle";
var C4 = K1;
;
var Y1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M479.854 790.131q19.798 0 32.69-12.462 12.891-12.463 12.891-32.262 0-19.798-12.745-32.973-12.745-13.174-32.544-13.174-19.798 0-32.69 13.157-12.891 13.156-12.891 32.955t12.745 32.279q12.745 12.48 32.544 12.48Zm-36.463-166.566h79.218V360.956h-79.218v262.609Zm36.953 366.566q-86.203 0-161.506-32.395-75.302-32.395-131.741-88.833-56.438-56.439-88.833-131.738-32.395-75.299-32.395-161.587 0-86.288 32.395-161.665t88.745-131.345q56.349-55.968 131.69-88.616 75.34-32.648 161.676-32.648 86.335 0 161.779 32.604t131.37 88.497q55.926 55.893 88.549 131.452 32.623 75.559 32.623 161.877 0 86.281-32.648 161.575-32.648 75.293-88.616 131.478-55.968 56.186-131.426 88.765-75.459 32.579-161.662 32.579Z"
        })
    });
_c26 = Y1;
Y1.displayName = "SvgError";
var k4 = Y1;
;
var J1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M479.982 776q14.018 0 23.518-9.482 9.5-9.483 9.5-23.5 0-14.018-9.482-23.518-9.483-9.5-23.5-9.5-14.018 0-23.518 9.482-9.5 9.483-9.5 23.5 0 14.018 9.482 23.518 9.483 9.5 23.5 9.5ZM453 623h60V370h-60v253Zm27.266 353q-82.734 0-155.5-31.5t-127.266-86q-54.5-54.5-86-127.341Q80 658.319 80 575.5q0-82.819 31.5-155.659Q143 347 197.5 293t127.341-85.5Q397.681 176 480.5 176q82.819 0 155.659 31.5Q709 239 763 293t85.5 127Q880 493 880 575.734q0 82.734-31.5 155.5T763 858.316q-54 54.316-127 86Q563 976 480.266 976Zm.234-60Q622 916 721 816.5t99-241Q820 434 721.188 335 622.375 236 480 236q-141 0-240.5 98.812Q140 433.625 140 576q0 141 99.5 240.5t241 99.5Zm-.5-340Z"
        })
    });
_c27 = J1;
J1.displayName = "SvgErrorOutline";
var T4 = J1;
;
var $1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M450 547h60V296h-60v251Zm29.982 142q14.018 0 23.518-9.482 9.5-9.483 9.5-23.5 0-14.018-9.482-23.518-9.483-9.5-23.5-9.5-14.018 0-23.518 9.482-9.5 9.483-9.5 23.5 0 14.018 9.482 23.518 9.483 9.5 23.5 9.5ZM80 976V236q0-23 18-41.5t42-18.5h680q23 0 41.5 18.5T880 236v520q0 23-18.5 41.5T820 816H240L80 976Zm60-145 75-75h605V236H140v595Zm0-595v595-595Z"
        })
    });
$1.displayName = "SvgEtiquette";
var P4 = $1;
;
var p1 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m283 711-43-43 240-240 240 239-43 43-197-197-197 198Z"
        })
    });
p1.displayName = "SvgExpandLess";
var M4 = p1;
;
var l2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 711 240 471l43-43 197 198 197-197 43 43-240 239Z"
        })
    });
l2.displayName = "SvgExpandMore";
var H4 = l2;
;
var t2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m480 935-41-37q-106-97-175-167.5t-110-126Q113 549 96.5 504T80 413q0-90 60.5-150.5T290 202q57 0 105.5 27t84.5 78q42-54 89-79.5T670 202q89 0 149.5 60.5T880 413q0 46-16.5 91T806 604.5q-41 55.5-110 126T521 898l-41 37Z"
        })
    });
t2.displayName = "SvgFavorite";
var L4 = t2;
;
var d2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m323 851 157-94 157 95-42-178 138-120-182-16-71-168-71 167-182 16 138 120-42 178Zm-90 125 65-281L80 506l288-25 112-265 112 265 288 25-218 189 65 281-247-149-247 149Zm247-355Z"
        })
    });
d2.displayName = "SvgFeatured";
var B4 = d2;
;
var s2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M17.25 29.15H36.8l-6.35-8.55-5.15 6.75L21.9 23ZM13 38q-1.2 0-2.1-.9-.9-.9-.9-2.1V7q0-1.2.9-2.1.9-.9 2.1-.9h28q1.2 0 2.1.9.9.9.9 2.1v28q0 1.2-.9 2.1-.9.9-2.1.9Zm0-3h28V7H13v28Zm-6 9q-1.2 0-2.1-.9Q4 42.2 4 41V10h3v31h31v3Zm6-37v28V7Z"
        })
    });
s2.displayName = "SvgFilter";
var N4 = s2;
;
var g2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M400 816v-60h160v60H400ZM240 606v-60h480v60H240ZM120 396v-60h720v60H120Z"
        })
    });
g2.displayName = "SvgFilterList";
var E4 = g2;
;
var h2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M200 936V256h343l19 86h238v370H544l-19-85H260v309h-60Z"
        })
    });
h2.displayName = "SvgFlag";
var I4 = h2;
;
var r2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 0 17 16",
        fill: "currentColor",
        xmlns: "http://www.w3.org/2000/svg",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.83862 14.6667V2.66667C2.83862 2.56317 2.86272 2.46109 2.909 2.36852C2.95529 2.27595 3.02249 2.19543 3.10529 2.13333C3.79767 1.61404 4.63981 1.33333 5.50529 1.33333C7.50529 1.33333 8.83862 2.66667 10.394 2.66667C11.2828 2.66667 11.9644 2.48889 12.4386 2.13333C12.5377 2.05905 12.6554 2.01381 12.7788 2.00269C12.9021 1.99157 13.026 2.01501 13.1368 2.07038C13.2475 2.12575 13.3406 2.21086 13.4057 2.31618C13.4708 2.4215 13.5053 2.54286 13.5053 2.66667V9.33333C13.5053 9.43683 13.4812 9.5389 13.4349 9.63147C13.3886 9.72404 13.3214 9.80457 13.2386 9.86666C12.5462 10.386 11.7041 10.6667 10.8386 10.6667C8.83862 10.6667 7.50529 9.33333 5.50529 9.33333C4.52137 9.33336 3.57197 9.69603 2.83862 10.352",
                fill: "currentColor"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M2.83862 14.6667V2.66667C2.83862 2.56317 2.86272 2.46109 2.909 2.36852C2.95529 2.27595 3.02249 2.19543 3.10529 2.13333C3.79767 1.61404 4.63981 1.33333 5.50529 1.33333C7.50529 1.33333 8.83862 2.66667 10.394 2.66667C11.2828 2.66667 11.9644 2.48889 12.4386 2.13333C12.5377 2.05905 12.6554 2.01381 12.7788 2.00269C12.9021 1.99157 13.026 2.01501 13.1368 2.07038C13.2475 2.12575 13.3406 2.21086 13.4057 2.31618C13.4708 2.4215 13.5053 2.54286 13.5053 2.66667V9.33333C13.5053 9.43683 13.4812 9.5389 13.4349 9.63147C13.3886 9.72404 13.3214 9.80457 13.2386 9.86667C12.5462 10.386 11.7041 10.6667 10.8386 10.6667C8.83862 10.6667 7.50529 9.33333 5.50529 9.33333C4.52137 9.33336 3.57197 9.69603 2.83862 10.352",
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    });
r2.displayName = "SvgFlagFilled";
var Q4 = r2;
;
var w2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M141 896q-24 0-42-18.5T81 836V316q0-23 18-41.5t42-18.5h280l60 60h340q23 0 41.5 18.5T881 376v460q0 23-18.5 41.5T821 896H141Z"
        })
    });
w2.displayName = "SvgFolder";
var R4 = w2;
;
var S2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M124 489q0-81 34-153.5T255 212l41 45q-53 43-82.5 103.5T184 489h-60Zm653 0q0-68-28-128.5T668 257l41-45q62 52 95 124t33 153h-60ZM160 856v-60h84V490q0-84 49.5-149.5T424 258v-29q0-23 16.5-38t39.5-15q23 0 39.5 15t16.5 38v29q81 17 131 82.5T717 490v306h83v60H160Zm320 120q-32 0-56-23.5T400 896h160q0 33-23.5 56.5T480 976Z"
        })
    });
_c28 = S2;
S2.displayName = "SvgFollow";
var O4 = S2;
;
var V2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        viewBox: "0 0 24 24",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M6.78666 17.1563H3.87349L3.20283 19H1.83008L4.59654 12H6.06361L8.83008 19H7.45732L6.78666 17.1563ZM6.43736 16.1901 5.56411 13.8239C5.47027 13.5799 5.3967 13.3294 5.34405 13.0746H5.32309C5.27044 13.3294 5.19687 13.5799 5.10303 13.8239L4.22978 16.1901H6.43736ZM18.7433 15.3127H12.9216L11.5756 19H8.83008L14.363 5H17.2971L22.8301 19H20.0846L18.7433 15.3127ZM18.0307 13.3803 16.2912 8.64789C16.1035 8.15981 15.9563 7.65878 15.851 7.1493H15.8091C15.7038 7.65878 15.5567 8.15981 15.369 8.64789L13.6295 13.3803H18.0307Z"
        })
    });
_c29 = V2;
V2.displayName = "SvgFontSize";
var D4 = V2;
;
var G2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        className: "bi bi-blockquote-left",
        viewBox: "0 0 16 16",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M2.5 3a.5.5 0 0 0 0 1h11a.5.5 0 0 0 0-1h-11zm5 3a.5.5 0 0 0 0 1h6a.5.5 0 0 0 0-1h-6zm0 3a.5.5 0 0 0 0 1h6a.5.5 0 0 0 0-1h-6zm-5 3a.5.5 0 0 0 0 1h11a.5.5 0 0 0 0-1h-11zm.79-5.373c.112-.078.26-.17.444-.275L3.524 6c-.122.074-.272.17-.452.287-.18.117-.35.26-.51.428a2.425 2.425 0 0 0-.398.562c-.11.207-.164.438-.164.692 0 .36.072.65.217.873.144.219.385.328.72.328.215 0 .383-.07.504-.211a.697.697 0 0 0 .188-.463c0-.23-.07-.404-.211-.521-.137-.121-.326-.182-.568-.182h-.282c.024-.203.065-.37.123-.498a1.38 1.38 0 0 1 .252-.37 1.94 1.94 0 0 1 .346-.298zm2.167 0c.113-.078.262-.17.445-.275L5.692 6c-.122.074-.272.17-.452.287-.18.117-.35.26-.51.428a2.425 2.425 0 0 0-.398.562c-.11.207-.164.438-.164.692 0 .36.072.65.217.873.144.219.385.328.72.328.215 0 .383-.07.504-.211a.697.697 0 0 0 .188-.463c0-.23-.07-.404-.211-.521-.137-.121-.326-.182-.568-.182h-.282a1.75 1.75 0 0 1 .118-.492c.058-.13.144-.254.257-.375a1.94 1.94 0 0 1 .346-.3z"
        })
    });
_c30 = G2;
G2.displayName = "SvgFormatBlockquote";
var U4 = G2;
;
var z2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M13.75 38V10h11.4q3.3 0 5.725 2.1t2.425 5.3q0 1.9-1.05 3.5t-2.8 2.45v.3q2.15.7 3.475 2.5 1.325 1.8 1.325 4.05 0 3.4-2.625 5.6Q29 38 25.5 38Zm4.3-3.8h7.2q1.9 0 3.3-1.25t1.4-3.15q0-1.85-1.4-3.1t-3.3-1.25h-7.2Zm0-12.35h6.8q1.75 0 3.025-1.15t1.275-2.9q0-1.75-1.275-2.925Q26.6 13.7 24.85 13.7h-6.8Z"
        })
    });
z2.displayName = "SvgFormatBold";
var K4 = z2;
;
var x2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        viewBox: "0 0 24 24",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        xmlns: "http://www.w3.org/2000/svg",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "none",
                d: "M0 0h24v24H0z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M5 17v2h14v-2H5zm4.5-4.2h5l.9 2.2h2.1L12.75 4h-1.5L6.5 15h2.1l.9-2.2zM12 5.98L13.87 11h-3.74L12 5.98z"
            })
        ]
    });
x2.displayName = "SvgFormatColorText";
var W4 = x2;
;
var C2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M11.2 38.05v-4h6.7l6.95-20.45H16.9v-4h19v4h-6.7l-6.95 20.45h7.95v4Z"
        })
    });
_c31 = C2;
C2.displayName = "SvgFormatItalic";
var X4 = C2;
;
var k2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M377 858v-60h463v60H377Zm0-252v-60h463v60H377Zm0-253v-60h463v60H377ZM189 895q-28.05 0-48.025-19Q121 857 121 828.5t19.5-48q19.5-19.5 48-19.5t47.5 19.975Q255 800.95 255 829q0 27.225-19.387 46.612Q216.225 895 189 895Zm0-252q-28.05 0-48.025-19.681Q121 603.638 121 576t19.975-47.319Q160.95 509 189 509q27.225 0 46.613 19.681Q255 548.362 255 576t-19.387 47.319Q216.225 643 189 643Zm-1-253q-27.637 0-47.319-19.681Q121 350.638 121 323t19.681-47.319Q160.363 256 188 256q27.637 0 47.319 19.681Q255 295.362 255 323t-19.681 47.319Q215.637 390 188 390Z"
        })
    });
k2.displayName = "SvgFormatListBulleted";
var J4 = k2;
;
var P2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M120 976v-60h100v-30h-60v-60h60v-30H120v-60h120q17 0 28.5 11.5T280 776v40q0 17-11.5 28.5T240 856q17 0 28.5 11.5T280 896v40q0 17-11.5 28.5T240 976H120Zm0-280V586q0-17 11.5-28.5T160 546h60v-30H120v-60h120q17 0 28.5 11.5T280 496v70q0 17-11.5 28.5T240 606h-60v30h100v60H120Zm60-280V236h-60v-60h120v240h-60Zm189 431v-60h471v60H369Zm0-243v-60h471v60H369Zm0-243v-60h471v60H369Z"
        })
    });
_c32 = P2;
P2.displayName = "SvgFormatListNumbered";
var _4 = P2;
;
var H2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m626 776 80-160H520V336h280v288l-76 152h-98Zm-360 0 80-160H160V336h280v288l-76 152h-98Z"
        })
    });
_c33 = H2;
H2.displayName = "SvgFormatQuote";
var $4 = H2;
;
var B2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M25.2 40q-3.9 0-7.1-2.075-3.2-2.075-4.65-5.575l3.45-1.45q1 2.4 3.25 3.85 2.25 1.45 5.05 1.45 2.6 0 4.15-1.35 1.55-1.35 1.55-3.65 0-1.15-.475-2.425T29.1 26.5h4.2q.7 1.15 1.05 2.3.35 1.15.35 2.4 0 3.9-2.65 6.35Q29.4 40 25.2 40ZM4 23.5v-3h40v3ZM23.7 7.7q3.3 0 5.85 1.55t3.75 4.3l-3.45 1.55q-.7-1.7-2.325-2.65-1.625-.95-3.825-.95-2.45 0-3.95 1.2t-1.5 3.3q0 .4.05.75t.15.75h-3.7q-.1-.4-.15-.8-.05-.4-.05-.8 0-3.65 2.55-5.925T23.7 7.7Z"
        })
    });
_c34 = B2;
B2.displayName = "SvgFormatStrikethrough";
var j4 = B2;
;
var E2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 48 48",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M38.5 40v-4.25q0-.7.4-1.1.4-.4 1.1-.4h4.5V31.5h-6V30h6q.7 0 1.1.4.4.4.4 1.1v2.75q0 .7-.4 1.1-.4.4-1.1.4H40v2.75h6V40Zm-26.75-4L21 21.45 12.4 8h4.3l6.75 10.65L30.2 8h4.3l-8.6 13.45L35.15 36H30.9l-7.45-11.7L16 36Z"
        })
    });
_c35 = E2;
E2.displayName = "SvgFormatSubscript";
var p4 = E2;
;
var Q2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 48 48",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M38.5 18v-4.25q0-.7.4-1.1.4-.4 1.1-.4h4.5V9.5h-6V8h6q.7 0 1.1.4.4.4.4 1.1v2.75q0 .7-.4 1.1-.4.4-1.1.4H40v2.75h6V18ZM11.75 40 21 25.45 12.4 12h4.3l6.75 10.65L30.2 12h4.3l-8.6 13.45L35.15 40H30.9l-7.45-11.7L16 40Z"
        })
    });
_c36 = Q2;
Q2.displayName = "SvgFormatSuperscript";
var e6 = Q2;
;
var R2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M281 746v-50h121v-56h-82v-49h82v-57H281v-49h127q18.7 0 31.35 12.65Q452 510.3 452 529v173q0 18.7-12.65 31.35Q426.7 746 408 746H281Zm272 0q-18.7 0-31.35-12.65Q509 720.7 509 702V529q0-18.7 12.65-31.35Q534.3 485 553 485h83q18.7 0 31.35 12.65Q680 510.3 680 529v173q0 18.7-12.65 31.35Q654.7 746 636 746h-83Zm6-50h71V534h-71v162Zm-79 280q-75 0-140.5-28T225 871q-49-49-77-114.5T120 616q0-75 28-140.5T225 361q49-49 114.5-77T480 256h21l-78-78 41-41 147 147-147 147-41-41 74-74h-17q-125.357 0-212.679 87.321Q180 490.643 180 616t87.321 212.679Q354.643 916 480 916t212.679-87.321Q780 741.357 780 616h60q0 75-28 140.5T735 871q-49 49-114.5 77T480 976Z"
        })
    });
_c37 = R2;
R2.displayName = "SvgForward";
var l6 = R2;
;
var D2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M281 746v-50h121v-56h-82v-49h82v-57H281v-49h127q18.7 0 31.35 12.65Q452 510.3 452 529v173q0 18.7-12.65 31.35Q426.7 746 408 746H281Zm272 0q-18.7 0-31.35-12.65Q509 720.7 509 702V529q0-18.7 12.65-31.35Q534.3 485 553 485h83q18.7 0 31.35 12.65Q680 510.3 680 529v173q0 18.7-12.65 31.35Q654.7 746 636 746h-83Zm6-50h71V534h-71v162Zm-79 280q-75 0-140.5-28T225 871q-49-49-77-114.5T120 616q0-75 28-140.5T225 361q49-49 114.5-77T480 256h21l-78-78 41-41 147 147-147 147-41-41 74-74h-17q-125.357 0-212.679 87.321Q180 490.643 180 616t87.321 212.679Q354.643 916 480 916t212.679-87.321Q780 741.357 780 616h60q0 75-28 140.5T735 871q-49 49-114.5 77T480 976Z"
        })
    });
_c38 = D2;
D2.displayName = "SvgForward30";
var i6 = D2;
;
var K2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M200 856V663h60v133h133v60H200Zm0-367V296h193v60H260v133h-60Zm367 367v-60h133V663h60v193H567Zm133-367V356H567v-60h193v193h-60Z"
        })
    });
_c39 = K2;
K2.displayName = "SvgFullscreen";
var t6 = K2;
;
var Y2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M333 856V723H200v-60h193v193h-60Zm234 0V663h193v60H627v133h-60ZM200 489v-60h133V296h60v193H200Zm367 0V296h60v133h133v60H567Z"
        })
    });
_c40 = Y2;
Y2.displayName = "SvgFullscreenExit";
var n6 = Y2;
;
var J2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M17.25 29.15H36.8l-6.35-8.55-5.15 6.75L21.9 23ZM13 38q-1.2 0-2.1-.9-.9-.9-.9-2.1V7q0-1.2.9-2.1.9-.9 2.1-.9h28q1.2 0 2.1.9.9.9.9 2.1v28q0 1.2-.9 2.1-.9.9-2.1.9Zm0-3h28V7H13v28Zm-6 9q-1.2 0-2.1-.9Q4 42.2 4 41V10h3v31h31v3Zm6-37v28V7Z"
        })
    });
_c41 = J2;
J2.displayName = "SvgGallery";
var d6 = J2;
;
var $2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 640 512",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M305.5 135.3c7.1-6.3 9.9-16.2 6.2-25c-2.3-5.3-4.8-10.5-7.6-15.5L301 89.4c-3-5-6.3-9.9-9.8-14.6c-5.7-7.6-15.7-10.1-24.7-7.1l-28.2 9.3c-10.7-8.8-23-16-36.2-20.9L196 27.1c-1.9-9.3-9.1-16.7-18.5-17.8C170.9 8.4 164.2 8 157.4 8h-.7c-6.8 0-13.5 .4-20.1 1.2c-9.4 1.1-16.6 8.6-18.5 17.8L112 56.1c-13.3 5-25.5 12.1-36.2 20.9L47.5 67.8c-9-3-19-.5-24.7 7.1c-3.5 4.7-6.8 9.6-9.9 14.6l-3 5.3c-2.8 5-5.3 10.2-7.6 15.6c-3.7 8.7-.9 18.6 6.2 25l22.2 19.8C29.6 161.9 29 168.9 29 176s.6 14.1 1.7 20.9L8.5 216.7c-7.1 6.3-9.9 16.2-6.2 25c2.3 5.3 4.8 10.5 7.6 15.6l3 5.2c3 5.1 6.3 9.9 9.9 14.6c5.7 7.6 15.7 10.1 24.7 7.1l28.2-9.3c10.7 8.8 23 16 36.2 20.9l6.1 29.1c1.9 9.3 9.1 16.7 18.5 17.8c6.7 .8 13.5 1.2 20.4 1.2s13.7-.4 20.4-1.2c9.4-1.1 16.6-8.6 18.5-17.8l6.1-29.1c13.3-5 25.5-12.1 36.2-20.9l28.2 9.3c9 3 19 .5 24.7-7.1c3.5-4.7 6.8-9.5 9.8-14.6l3.1-5.4c2.8-5 5.3-10.2 7.6-15.5c3.7-8.7 .9-18.6-6.2-25l-22.2-19.8c1.1-6.8 1.7-13.8 1.7-20.9s-.6-14.1-1.7-20.9l22.2-19.8zM109 176a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zM501.7 500.5c6.3 7.1 16.2 9.9 25 6.2c5.3-2.3 10.5-4.8 15.5-7.6l5.4-3.1c5-3 9.9-6.3 14.6-9.8c7.6-5.7 10.1-15.7 7.1-24.7l-9.3-28.2c8.8-10.7 16-23 20.9-36.2l29.1-6.1c9.3-1.9 16.7-9.1 17.8-18.5c.8-6.7 1.2-13.5 1.2-20.4s-.4-13.7-1.2-20.4c-1.1-9.4-8.6-16.6-17.8-18.5L580.9 307c-5-13.3-12.1-25.5-20.9-36.2l9.3-28.2c3-9 .5-19-7.1-24.7c-4.7-3.5-9.6-6.8-14.6-9.9l-5.3-3c-5-2.8-10.2-5.3-15.6-7.6c-8.7-3.7-18.6-.9-25 6.2l-19.8 22.2c-6.8-1.1-13.8-1.7-20.9-1.7s-14.1 .6-20.9 1.7l-19.8-22.2c-6.3-7.1-16.2-9.9-25-6.2c-5.3 2.3-10.5 4.8-15.6 7.6l-5.2 3c-5.1 3-9.9 6.3-14.6 9.9c-7.6 5.7-10.1 15.7-7.1 24.7l9.3 28.2c-8.8 10.7-16 23-20.9 36.2L312.1 313c-9.3 1.9-16.7 9.1-17.8 18.5c-.8 6.7-1.2 13.5-1.2 20.4s.4 13.7 1.2 20.4c1.1 9.4 8.6 16.6 17.8 18.5l29.1 6.1c5 13.3 12.1 25.5 20.9 36.2l-9.3 28.2c-3 9-.5 19 7.1 24.7c4.7 3.5 9.5 6.8 14.6 9.8l5.4 3.1c5 2.8 10.2 5.3 15.5 7.6c8.7 3.7 18.6 .9 25-6.2l19.8-22.2c6.8 1.1 13.8 1.7 20.9 1.7s14.1-.6 20.9-1.7l19.8 22.2zM461 304a48 48 0 1 1 0 96 48 48 0 1 1 0-96z"
        })
    });
$2.displayName = "SvgGears";
var m6 = $2;
;
var p2 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m11.65 44 3.25-14.05L4 20.5l14.4-1.25L24 6l5.6 13.25L44 20.5l-10.9 9.45L36.35 44 24 36.55Z"
        })
    });
p2.displayName = "SvgGrade";
var s6 = p2;
;
var l0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M688 975q-57 0-99-31t-62-82q-20-51-39.5-79.5T414 711q-66-53-95-113t-29-146q0-120 76-196.5T562 179q118 0 195.5 73.5T840 440h-60q-5-88-65.5-144.5T562 239q-90 0-151 61.5T350 452q0 72 28 124.5T471 678q39 29 62.5 63t44.5 84q17 42 44.5 66t65.5 24q35 0 60.5-24t30.5-59h60q-5 60-48 101.5T688 975ZM239 754q-57-63-88-141.5T120 448q0-85 29.5-164.5T239 143l45 40q-52 53-78 121.5T180 448q0 74 26.5 142.5T284 713l-45 41Zm323-209q-39 0-66-27t-27-66q0-39 27-67t66-28q39 0 67 28t28 67q0 39-28 66t-67 27Z"
        })
    });
l0.displayName = "SvgHearing";
var o6 = l0;
;
var t0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m330 768 150-150 150 150 42-42-150-150 150-150-42-42-150 150-150-150-42 42 150 150-150 150 42 42Zm150 208q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Zm0-60q142 0 241-99.5T820 576q0-142-99-241t-241-99q-141 0-240.5 99T140 576q0 141 99.5 240.5T480 916Zm0-340Z"
        })
    });
t0.displayName = "SvgHighlightOff";
var g6 = t0;
;
var d0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M220 876h150V626h220v250h150V486L480 291 220 486v390Zm-60 60V456l320-240 320 240v480H530V686H430v250H160Zm320-353Z"
        })
    });
d0.displayName = "SvgHome";
var a6 = d0;
;
var s0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M180 936q-24 0-42-18t-18-42V276q0-24 18-42t42-18h600q24 0 42 18t18 42v600q0 24-18 42t-42 18H180Zm0-60h600V276H180v600Zm56-97h489L578 583 446 754l-93-127-117 152Zm-56 97V276v600Z"
        })
    });
s0.displayName = "SvgImage";
var h6 = s0;
;
var g0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M180 936q-24 0-42-18t-18-42V276q0-24 18-42t42-18h600q24 0 42 18t18 42v600q0 24-18 42t-42 18H180Zm0-60h600V276H180v600Zm56-97h489L578 583 446 754l-93-127-117 152Zm-56 97V276v600Z"
        })
    });
g0.displayName = "SvgImageOutline";
var v6 = g0;
;
var h0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M22.65 34h3V22h-3ZM24 18.3q.7 0 1.175-.45.475-.45.475-1.15t-.475-1.2Q24.7 15 24 15q-.7 0-1.175.5-.475.5-.475 1.2t.475 1.15q.475.45 1.175.45ZM24 44q-4.1 0-7.75-1.575-3.65-1.575-6.375-4.3-2.725-2.725-4.3-6.375Q4 28.1 4 23.95q0-4.1 1.575-7.75 1.575-3.65 4.3-6.35 2.725-2.7 6.375-4.275Q19.9 4 24.05 4q4.1 0 7.75 1.575 3.65 1.575 6.35 4.275 2.7 2.7 4.275 6.35Q44 19.85 44 24q0 4.1-1.575 7.75-1.575 3.65-4.275 6.375t-6.35 4.3Q28.15 44 24 44Zm.05-3q7.05 0 12-4.975T41 23.95q0-7.05-4.95-12T24 7q-7.05 0-12.025 4.95Q7 16.9 7 24q0 7.05 4.975 12.025Q16.95 41 24.05 41ZM24 24Z"
        })
    });
h0.displayName = "SvgInfoOutline";
var r6 = h0;
;
var r0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 448 512",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"
        })
    });
r0.displayName = "SvgInstagram";
var c6 = r0;
;
var w0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 712 240 472l43-43 197 197 197-197 43 43-240 240Z"
        })
    });
w0.displayName = "SvgKeyboardArrowDown";
var w6 = w0;
;
var S0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M561 816 320 575l241-241 43 43-198 198 198 198-43 43Z"
        })
    });
_c42 = S0;
S0.displayName = "SvgKeyboardArrowLeft";
var y6 = S0;
;
var V0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m375 816-43-43 198-198-198-198 43-43 241 241-241 241Z"
        })
    });
_c43 = V0;
V0.displayName = "SvgKeyboardArrowRight";
var S6 = V0;
;
var G0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m283 699-43-43 240-240 240 240-43 43-197-197-197 197Z"
        })
    });
_c44 = G0;
G0.displayName = "SvgKeyboardArrowUp";
var f6 = G0;
;
var z0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M360 816 121 577l239-239 43 43-167 167h544V376h60v231H237l166 166-43 43Z"
        })
    });
z0.displayName = "SvgKeyboardReturn";
var V6 = z0;
;
var x0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 976q-84 0-157-31.5T196 859q-54-54-85-127.5T80 574q0-84 31-156.5T196 291q54-54 127-84.5T480 176q84 0 157 30.5T764 291q54 54 85 126.5T880 574q0 84-31 157.5T764 859q-54 54-127 85.5T480 976Zm0-58q35-36 58.5-82.5T577 725H384q14 60 37.5 108t58.5 85Zm-85-12q-25-38-43-82t-30-99H172q38 71 88 111.5T395 906Zm171-1q72-23 129.5-69T788 725H639q-13 54-30.5 98T566 905ZM152 665h159q-3-27-3.5-48.5T307 574q0-25 1-44.5t4-43.5H152q-7 24-9.5 43t-2.5 45q0 26 2.5 46.5T152 665Zm221 0h215q4-31 5-50.5t1-40.5q0-20-1-38.5t-5-49.5H373q-4 31-5 49.5t-1 38.5q0 21 1 40.5t5 50.5Zm275 0h160q7-24 9.5-44.5T820 574q0-26-2.5-45t-9.5-43H649q3 35 4 53.5t1 34.5q0 22-1.5 41.5T648 665Zm-10-239h150q-33-69-90.5-115T565 246q25 37 42.5 80T638 426Zm-254 0h194q-11-53-37-102.5T480 236q-32 27-54 71t-42 119Zm-212 0h151q11-54 28-96.5t43-82.5q-75 19-131 64t-91 115Z"
        })
    });
x0.displayName = "SvgLanguage";
var q6 = x0;
;
var C0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M57 896q-23.513 0-40.256-17.625Q0 860.75 0 836h141q-24 0-42-18t-18-42V276q0-24 18-42t42-18h678q24 0 42 18t18 42v500q0 24-18 42t-42 18h141q0 25-17.625 42.5T900 896H57Zm423-22q14.45 0 24.225-9.775Q514 854.45 514 840q0-14.45-9.775-24.225Q494.45 806 480 806q-14.45 0-24.225 9.775Q446 825.55 446 840q0 14.45 9.775 24.225Q465.55 874 480 874Zm-339-98h678V276H141v500Zm0 0V276v500Z"
        })
    });
_c45 = C0;
C0.displayName = "SvgLaptopMac";
var G6 = C0;
;
var k0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M24 44q-4.1 0-7.75-1.575-3.65-1.575-6.375-4.3-2.725-2.725-4.3-6.375Q4 28.1 4 24q0-4.15 1.575-7.8 1.575-3.65 4.3-6.35 2.725-2.7 6.375-4.275Q19.9 4 24 4q4.15 0 7.8 1.575 3.65 1.575 6.35 4.275 2.7 2.7 4.275 6.35Q44 19.85 44 24q0 4.1-1.575 7.75-1.575 3.65-4.275 6.375t-6.35 4.3Q28.15 44 24 44Z"
        })
    });
k0.displayName = "SvgLens";
var u6 = k0;
;
var P0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 776q-83 0-141.5-58.5T280 576q0-83 58.5-141.5T480 376q83 0 141.5 58.5T680 576q0 83-58.5 141.5T480 776ZM70 606q-12.75 0-21.375-8.675Q40 588.649 40 575.825 40 563 48.625 554.5T70 546h100q12.75 0 21.375 8.675 8.625 8.676 8.625 21.5 0 12.825-8.625 21.325T170 606H70Zm720 0q-12.75 0-21.375-8.675-8.625-8.676-8.625-21.5 0-12.825 8.625-21.325T790 546h100q12.75 0 21.375 8.675 8.625 8.676 8.625 21.5 0 12.825-8.625 21.325T890 606H790ZM479.825 296Q467 296 458.5 287.375T450 266V166q0-12.75 8.675-21.375 8.676-8.625 21.5-8.625 12.825 0 21.325 8.625T510 166v100q0 12.75-8.675 21.375-8.676 8.625-21.5 8.625Zm0 720q-12.825 0-21.325-8.62-8.5-8.63-8.5-21.38V886q0-12.75 8.675-21.375 8.676-8.625 21.5-8.625 12.825 0 21.325 8.625T510 886v100q0 12.75-8.675 21.38-8.676 8.62-21.5 8.62ZM240 378l-57-56q-9-9-8.629-21.603.37-12.604 8.526-21.5 8.896-8.897 21.5-8.897Q217 270 226 279l56 57q8 9 8 21t-8 20.5q-8 8.5-20.5 8.5t-21.5-8Zm494 495-56-57q-8-9-8-21.375T678.5 774q8.5-9 20.5-9t21 9l57 56q9 9 8.629 21.603-.37 12.604-8.526 21.5-8.896 8.897-21.5 8.897Q743 882 734 873Zm-56-495q-9-9-9-21t9-21l56-57q9-9 21.603-8.629 12.604.37 21.5 8.526 8.897 8.896 8.897 21.5Q786 313 777 322l-57 56q-8 8-20.364 8-12.363 0-21.636-8ZM182.897 873.103q-8.897-8.896-8.897-21.5Q174 839 183 830l57-56q8.8-9 20.9-9 12.1 0 20.709 9Q291 783 291 795t-9 21l-56 57q-9 9-21.603 8.629-12.604-.37-21.5-8.526Z"
        })
    });
_c46 = P0;
P0.displayName = "SvgLightMode";
var z6 = P0;
;
var H0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 640 512",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M562.8 267.7c56.5-56.5 56.5-148 0-204.5c-50-50-128.8-56.5-186.3-15.4l-1.6 1.1c-14.4 10.3-17.7 30.3-7.4 44.6s30.3 17.7 44.6 7.4l1.6-1.1c32.1-22.9 76-19.3 103.8 8.6c31.5 31.5 31.5 82.5 0 114L405.3 334.8c-31.5 31.5-82.5 31.5-114 0c-27.9-27.9-31.5-71.8-8.6-103.8l1.1-1.6c10.3-14.4 6.9-34.4-7.4-44.6s-34.4-6.9-44.6 7.4l-1.1 1.6C189.5 251.2 196 330 246 380c56.5 56.5 148 56.5 204.5 0L562.8 267.7zM43.2 244.3c-56.5 56.5-56.5 148 0 204.5c50 50 128.8 56.5 186.3 15.4l1.6-1.1c14.4-10.3 17.7-30.3 7.4-44.6s-30.3-17.7-44.6-7.4l-1.6 1.1c-32.1 22.9-76 19.3-103.8-8.6C57 372 57 321 88.5 289.5L200.7 177.2c31.5-31.5 82.5-31.5 114 0c27.9 27.9 31.5 71.8 8.6 103.9l-1.1 1.6c-10.3 14.4-6.9 34.4 7.4 44.6s34.4 6.9 44.6-7.4l1.1-1.6C416.5 260.8 410 182 360 132c-56.5-56.5-148-56.5-204.5 0L43.2 244.3z"
        })
    });
_c47 = H0;
H0.displayName = "SvgLink";
var b6 = H0;
;
var B0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M149.825 776Q137 776 128.5 767.325q-8.5-8.676-8.5-21.5 0-12.825 8.675-21.325 8.676-8.5 21.5-8.5 12.825 0 21.325 8.675 8.5 8.676 8.5 21.5 0 12.825-8.675 21.325-8.676 8.5-21.5 8.5Zm0-170Q137 606 128.5 597.325q-8.5-8.676-8.5-21.5 0-12.825 8.675-21.325 8.676-8.5 21.5-8.5 12.825 0 21.325 8.675 8.5 8.676 8.5 21.5 0 12.825-8.675 21.325-8.676 8.5-21.5 8.5Zm0-170Q137 436 128.5 427.325q-8.5-8.676-8.5-21.5 0-12.825 8.675-21.325 8.676-8.5 21.5-8.5 12.825 0 21.325 8.675 8.5 8.676 8.5 21.5 0 12.825-8.675 21.325-8.676 8.5-21.5 8.5ZM290 776v-60h550v60H290Zm0-170v-60h550v60H290Zm0-170v-60h550v60H290Z"
        })
    });
_c48 = B0;
B0.displayName = "SvgList";
var x6 = B0;
;
var E0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M11 44q-1.25 0-2.125-.875T8 41V19.3q0-1.25.875-2.125T11 16.3h3.5v-4.8q0-3.95 2.775-6.725Q20.05 2 24 2q3.95 0 6.725 2.775Q33.5 7.55 33.5 11.5v4.8H37q1.25 0 2.125.875T40 19.3V41q0 1.25-.875 2.125T37 44Zm0-3h26V19.3H11V41Zm13-7q1.6 0 2.725-1.1t1.125-2.65q0-1.5-1.125-2.725T24 26.3q-1.6 0-2.725 1.225T20.15 30.25q0 1.55 1.125 2.65Q22.4 34 24 34Zm-6.5-17.7h13v-4.8q0-2.7-1.9-4.6Q26.7 5 24 5q-2.7 0-4.6 1.9-1.9 1.9-1.9 4.6ZM11 41V19.3 41Z"
        })
    });
_c49 = E0;
E0.displayName = "SvgLock";
var Z6 = E0;
;
var Q0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M11 16.3h19.5v-4.8q0-2.7-1.9-4.6Q26.7 5 24 5q-2.7 0-4.6 1.9-1.9 1.9-1.9 4.6h-3q0-3.95 2.775-6.725Q20.05 2 24 2q3.95 0 6.725 2.775Q33.5 7.55 33.5 11.5v4.8H37q1.25 0 2.125.875T40 19.3V41q0 1.25-.875 2.125T37 44H11q-1.25 0-2.125-.875T8 41V19.3q0-1.25.875-2.125T11 16.3ZM11 41h26V19.3H11V41Zm13-7q1.6 0 2.725-1.1t1.125-2.65q0-1.5-1.125-2.725T24 26.3q-1.6 0-2.725 1.225T20.15 30.25q0 1.55 1.125 2.65Q22.4 34 24 34Zm-13 7V19.3 41Z"
        })
    });
_c50 = Q0;
Q0.displayName = "SvgLockOpen";
var C6 = Q0;
;
var F0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: "ionicon",
        viewBox: "0 0 512 512",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("title", {
                children: "Logo Apple"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M349.13 136.86c-40.32 0-57.36 19.24-85.44 19.24-28.79 0-50.75-19.1-85.69-19.1-34.2 0-70.67 20.88-93.83 56.45-32.52 50.16-27 144.63 25.67 225.11 18.84 28.81 44 61.12 77 61.47h.6c28.68 0 37.2-18.78 76.67-19h.6c38.88 0 46.68 18.89 75.24 18.89h.6c33-.35 59.51-36.15 78.35-64.85 13.56-20.64 18.6-31 29-54.35-76.19-28.92-88.43-136.93-13.08-178.34-23-28.8-55.32-45.48-85.79-45.48z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M340.25 32c-24 1.63-52 16.91-68.4 36.86-14.88 18.08-27.12 44.9-22.32 70.91h1.92c25.56 0 51.72-15.39 67-35.11 14.72-18.77 25.88-45.37 21.8-72.66z"
            })
        ]
    });
_c51 = F0;
F0.displayName = "SvgLogoApple";
var A6 = F0;
;
var O0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        xmlns: "http://www.w3.org/2000/svg",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M24 21.7768C22.1883 18.2535 17.2567 11.6885 12.67 8.45179C8.27667 5.35012 6.60167 5.88679 5.50333 6.38512C4.23167 6.95679 4 8.91012 4 10.0568C4 11.2068 4.63 19.4735 5.04 20.8551C6.39833 25.4151 11.2283 26.9551 15.6783 26.4618C15.905 26.4285 16.1367 26.3968 16.37 26.3685C16.14 26.4051 15.91 26.4351 15.6783 26.4618C9.15833 27.4285 3.36667 29.8035 10.9617 38.2585C19.3167 46.9085 22.4117 36.4035 24 31.0785C25.5883 36.4035 27.4167 46.5301 36.8883 38.2585C44 31.0785 38.8417 27.4285 32.3217 26.4618C32.0904 26.4362 31.8598 26.4051 31.63 26.3685C31.8633 26.3968 32.095 26.4285 32.3217 26.4618C36.7717 26.9568 41.6017 25.4151 42.96 20.8551C43.37 19.4751 44 11.2051 44 10.0585C44 8.90846 43.7683 6.95679 42.4967 6.38179C41.3983 5.88512 39.7233 5.34846 35.33 8.44846C30.7433 11.6901 25.8117 18.2551 24 21.7768Z",
            fill: "currentColor"
        })
    });
_c52 = O0;
O0.displayName = "SvgLogoBluesky";
var T6 = O0;
;
var U0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: "ionicon",
        viewBox: "0 0 512 512",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("title", {
                children: "Logo Facebook"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M480 257.35c0-123.7-100.3-224-224-224s-224 100.3-224 224c0 111.8 81.9 204.47 189 221.29V322.12h-56.89v-64.77H221V208c0-56.13 33.45-87.16 84.61-87.16 24.51 0 50.15 4.38 50.15 4.38v55.13H327.5c-27.81 0-36.51 17.26-36.51 35v42h62.12l-9.92 64.77H291v156.54c107.1-16.81 189-109.48 189-221.31z",
                fillRule: "evenodd"
            })
        ]
    });
_c53 = U0;
U0.displayName = "SvgLogoFacebook";
var P6 = U0;
;
var W0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: "ionicon",
        viewBox: "0 0 512 512",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("title", {
                children: "Logo Google"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M473.16 221.48l-2.26-9.59H262.46v88.22H387c-12.93 61.4-72.93 93.72-121.94 93.72-35.66 0-73.25-15-98.13-39.11a140.08 140.08 0 01-41.8-98.88c0-37.16 16.7-74.33 41-98.78s61-38.13 97.49-38.13c41.79 0 71.74 22.19 82.94 32.31l62.69-62.36C390.86 72.72 340.34 32 261.6 32c-60.75 0-119 23.27-161.58 65.71C58 139.5 36.25 199.93 36.25 256s20.58 113.48 61.3 155.6c43.51 44.92 105.13 68.4 168.58 68.4 57.73 0 112.45-22.62 151.45-63.66 38.34-40.4 58.17-96.3 58.17-154.9 0-24.67-2.48-39.32-2.59-39.96z"
            })
        ]
    });
_c54 = W0;
W0.displayName = "SvgLogoGoogle";
var H6 = W0;
;
var X0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        xmlns: "http://www.w3.org/2000/svg",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M13.8454 15.1831H6.21686C5.87829 15.1831 5.60396 15.4576 5.60396 15.796V40.3033C5.60396 40.6419 5.87829 40.9162 6.21686 40.9162H13.8454C14.184 40.9162 14.4583 40.6419 14.4583 40.3033V15.796C14.4583 15.4576 14.184 15.1831 13.8454 15.1831ZM10.0339 3C7.25818 3 5 5.25573 5 8.02838 5 10.8023 7.25818 13.0588 10.0339 13.0588 12.8074 13.0588 15.0637 10.8021 15.0637 8.02838 15.0639 5.25573 12.8074 3 10.0339 3ZM33.2492 14.5741C30.1853 14.5741 27.9204 15.8912 26.5466 17.3878V15.7961C26.5466 15.4577 26.2723 15.1832 25.9337 15.1832H18.628C18.2895 15.1832 18.0151 15.4577 18.0151 15.7961V40.3034C18.0151 40.642 18.2895 40.9163 18.628 40.9163H26.2399C26.5785 40.9163 26.8528 40.642 26.8528 40.3034V28.178C26.8528 24.092 27.9627 22.5002 30.811 22.5002 33.913 22.5002 34.1595 25.052 34.1595 28.3882V40.3035C34.1595 40.6421 34.4338 40.9164 34.7724 40.9164H42.3871C42.7257 40.9164 43 40.6421 43 40.3035V26.8608C43 20.7851 41.8415 14.5741 33.2492 14.5741Z",
            fill: "currentColor"
        })
    });
_c55 = X0;
X0.displayName = "SvgLogoLinkedIn";
var B6 = X0;
;
var _0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        xmlns: "http://www.w3.org/2000/svg",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M42.7125 14.855C42.1292 10.5583 38.3509 7.17167 33.8725 6.515C33.1158 6.40333 30.2525 6 23.6208 6H23.5708C16.9375 6 15.5125 6.40333 14.7575 6.515C10.4025 7.15334 6.42578 10.1967 5.46078 14.545C4.99911 16.6867 4.94911 19.0617 5.03411 21.2384C5.15745 24.3617 5.18078 27.48 5.46745 30.59C5.66412 32.6567 6.00912 34.7067 6.50078 36.7234C7.41745 40.4517 11.1291 43.5534 14.7675 44.8184C18.6608 46.1384 22.8492 46.3567 26.8608 45.4517C27.3025 45.3501 27.7392 45.2317 28.1708 45.0967C29.1458 44.7901 30.2875 44.4467 31.1275 43.8417C31.1388 43.8334 31.1481 43.8226 31.1547 43.8102C31.1613 43.7978 31.1651 43.7841 31.1658 43.7701V40.7551C31.1658 40.7419 31.1628 40.7289 31.1571 40.7171C31.1513 40.7052 31.1429 40.6948 31.1325 40.6867C31.1219 40.6782 31.1094 40.6723 31.0961 40.6694C31.0828 40.6665 31.069 40.6668 31.0558 40.6701C28.4842 41.2786 25.8501 41.5834 23.2075 41.5784C18.6575 41.5784 17.4358 39.4384 17.0841 38.5484C16.8027 37.7791 16.624 36.9761 16.5525 36.1601C16.5518 36.1463 16.5543 36.1325 16.56 36.1198C16.5656 36.1072 16.5741 36.0961 16.5848 36.0873C16.5955 36.0785 16.6081 36.0724 16.6216 36.0694C16.6351 36.0664 16.6491 36.0667 16.6625 36.0701C19.1908 36.6751 21.7825 36.9801 24.3825 36.9801C25.0092 36.9801 25.6325 36.9801 26.2575 36.9634C28.8742 36.8901 31.6308 36.7567 34.2042 36.2601C34.2675 36.2467 34.3325 36.2351 34.3875 36.2201C38.4459 35.4467 42.3092 33.0201 42.7025 26.88C42.7159 26.6384 42.7525 24.3467 42.7525 24.0967C42.7559 23.2434 43.0309 18.0467 42.7125 14.855ZM36.4658 30.1801H32.1975V19.8167C32.1975 17.635 31.2808 16.5234 29.4142 16.5234C27.3642 16.5234 26.3375 17.84 26.3375 20.44V26.1117H22.0942V20.4384C22.0942 17.8384 21.0658 16.5217 19.0141 16.5217C17.1608 16.5217 16.2341 17.635 16.2308 19.8167V30.1801H11.9691V19.5034C11.9691 17.32 12.5308 15.5867 13.6541 14.3034C14.8141 13.02 16.3341 12.3633 18.2208 12.3633C20.4058 12.3633 22.0575 13.1967 23.1575 14.86L24.2208 16.6267L25.2842 14.86C26.3842 13.195 28.0342 12.3633 30.2175 12.3633C32.1008 12.3633 33.6225 13.0217 34.7842 14.3034C35.9092 15.5867 36.4708 17.32 36.4708 19.5034L36.4658 30.1801Z",
            fill: "currentColor"
        })
    });
_0.displayName = "SvgLogoMastodon";
var N6 = _0;
;
var j0 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        viewBox: "0 0 1024 1024",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M427.5,170.3l7.9,32A319.6,319.6,0,0,0,347,238.9l-16.9-28.3A347.6,347.6,0,0,1,427.5,170.3Zm169,0-7.9,32A319.6,319.6,0,0,1,677,238.9l17.1-28.3A350.1,350.1,0,0,0,596.5,170.3ZM210.6,330a349.5,349.5,0,0,0-40.3,97.5l32,7.9A319.6,319.6,0,0,1,238.9,347ZM193,512a318.5,318.5,0,0,1,3.6-47.8l-32.6-5a352,352,0,0,0,0,105.5l32.6-4.9A319.5,319.5,0,0,1,193,512ZM693.9,813.3,677,785.1a317.8,317.8,0,0,1-88.3,36.6l7.9,32A350.3,350.3,0,0,0,693.9,813.3ZM831,512a319.5,319.5,0,0,1-3.6,47.8l32.6,4.9a352,352,0,0,0,0-105.5l-32.6,5A318.5,318.5,0,0,1,831,512Zm22.7,84.4-32-7.9A319,319,0,0,1,785.1,677l28.3,17A348.9,348.9,0,0,0,853.7,596.4Zm-293.9,231a319.1,319.1,0,0,1-95.6,0L459.3,860a351.3,351.3,0,0,0,105.4,0Zm209-126.2a318.1,318.1,0,0,1-67.6,67.5l19.6,26.6A355.1,355.1,0,0,0,795.4,721Zm-67.6-446a318.6,318.6,0,0,1,67.6,67.6L795.4,303A354.6,354.6,0,0,0,721,228.6Zm-446,67.6a318.6,318.6,0,0,1,67.6-67.6L303,228.6A354.6,354.6,0,0,0,228.6,303ZM813.4,330l-28.3,17a317.8,317.8,0,0,1,36.6,88.3l32-7.9A348.9,348.9,0,0,0,813.4,330ZM464.2,196.6a319.1,319.1,0,0,1,95.6,0l4.9-32.6a351.3,351.3,0,0,0-105.4,0ZM272.1,804.1,204,819.9l15.9-68.1-32.1-7.5-15.9,68.1a33,33,0,0,0,24.6,39.7,34.5,34.5,0,0,0,15,0l68.1-15.7Zm-77.5-89.2,32.2,7.4,11-47.2a316.2,316.2,0,0,1-35.5-86.6l-32,7.9a353.3,353.3,0,0,0,32.4,83.7Zm154,71.4-47.2,11,7.5,32.2,34.7-8.1a349,349,0,0,0,83.7,32.4l7.9-32a316.7,316.7,0,0,1-86.3-35.7ZM512,226c-158,.1-285.9,128.2-285.9,286.1a286.7,286.7,0,0,0,43.9,152L242.5,781.5,359.8,754c133.7,84.1,310.3,44,394.4-89.6S798.3,354.2,664.7,270A286.7,286.7,0,0,0,512,226s"
        })
    });
j0.displayName = "SvgLogoSignal";
var E6 = j0;
;
var e5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        xmlns: "http://www.w3.org/2000/svg",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M23.9066 4.00005C18.6185 4.02473 13.5554 6.14276 9.82482 9.89081C6.09426 13.6389 3.99994 18.7118 4 24C4 29.3043 6.10713 34.3914 9.85786 38.1421C13.6086 41.8929 18.6957 44 24 44C29.3043 44 34.3914 41.8929 38.1421 38.1421C41.8928 34.3914 43.9999 29.3043 43.9999 24C43.9999 18.6957 41.8928 13.6086 38.1421 9.85791C34.3914 6.10719 29.3043 4.00005 24 4.00005C23.9689 3.99998 23.9378 3.99998 23.9066 4.00005ZM32.1766 16.04C32.3433 16.0367 32.7116 16.0784 32.9516 16.2734C33.1111 16.4119 33.2128 16.6052 33.2366 16.815C33.2633 16.97 33.2966 17.325 33.27 17.6017C32.97 20.765 31.6666 28.4384 31.0033 31.98C30.7233 33.48 30.1716 33.9817 29.6366 34.03C28.4766 34.1383 27.595 33.2633 26.47 32.5267C24.71 31.3717 23.715 30.6534 22.0066 29.5267C20.0316 28.2267 21.3116 27.51 22.4366 26.3434C22.7316 26.0367 27.8483 21.3817 27.9483 20.96C27.96 20.9067 27.9716 20.71 27.855 20.6067C27.7383 20.5034 27.565 20.5384 27.44 20.5667C27.2633 20.6067 24.4516 22.4667 19.005 26.1417C18.205 26.6917 17.4833 26.9584 16.835 26.9417C16.1217 26.9284 14.7483 26.54 13.7267 26.2084C12.4733 25.8 11.4783 25.585 11.565 24.8934C11.61 24.5334 12.1067 24.165 13.0533 23.7884C18.8833 21.2484 22.77 19.5734 24.7166 18.765C30.27 16.455 31.425 16.0534 32.1766 16.04Z",
            fill: "currentColor"
        })
    });
e5.displayName = "SvgLogoTelegram";
var I6 = e5;
;
var i5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        xmlns: "http://www.w3.org/2000/svg",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M24.2 40.1433C24.9766 40.1433 25.7215 40.4519 26.2706 41.001C26.8198 41.5502 27.1283 42.295 27.1283 43.0717C27.1283 43.8483 26.8198 44.5931 26.2706 45.1423C25.7215 45.6915 24.9766 46 24.2 46C23.4234 46 22.6785 45.6915 22.1294 45.1423C21.5802 44.5931 21.2717 43.8483 21.2717 43.0717C21.2717 42.295 21.5802 41.5502 22.1294 41.001C22.6785 40.4519 23.4234 40.1433 24.2 40.1433ZM13.6417 40.1433C14.4183 40.1433 15.1631 40.4519 15.7123 41.001C16.2615 41.5502 16.57 42.295 16.57 43.0717C16.57 43.8483 16.2615 44.5931 15.7123 45.1423C15.1631 45.6915 14.4183 46 13.6417 46C12.865 46 12.1202 45.6915 11.571 45.1423C11.0219 44.5931 10.7133 43.8483 10.7133 43.0717C10.7133 42.295 11.0219 41.5502 11.571 41.001C12.1202 40.4519 12.865 40.1433 13.6417 40.1433ZM34.76 40.1433C35.5366 40.1433 36.2815 40.4519 36.8306 41.001C37.3798 41.5502 37.6883 42.295 37.6883 43.0717C37.6883 43.8483 37.3798 44.5931 36.8306 45.1423C36.2815 45.6915 35.5366 46 34.76 46C33.9834 46 33.2385 45.6915 32.6894 45.1423C32.1402 44.5931 31.8317 43.8483 31.8317 43.0717C31.8317 42.295 32.1402 41.5502 32.6894 41.001C33.2385 40.4519 33.9834 40.1433 34.76 40.1433ZM24.2033 6C33.7033 6 41.4067 12.7767 41.4067 21.1367C41.4067 29.4967 33.7033 36.275 24.2033 36.275C21.6129 36.2825 19.048 35.7625 16.665 34.7467L8.04667 36.9017L9.88833 29.535C8.065 27.1317 7 24.2433 7 21.1367C7 12.7767 14.7033 6 24.2033 6ZM24.2017 13.0583C23.5613 13.0581 22.9271 13.184 22.3353 13.4289C21.7436 13.6738 21.2058 14.0328 20.7529 14.4855C20.2999 14.9382 19.9405 15.4757 19.6952 16.0672C19.4499 16.6588 19.3236 17.2929 19.3233 17.9333V19.8833H19.1317C19.0288 19.8833 18.9269 19.9036 18.8319 19.943C18.7369 19.9823 18.6505 20.04 18.5778 20.1128C18.505 20.1855 18.4473 20.2719 18.408 20.3669C18.3686 20.4619 18.3483 20.5638 18.3483 20.6667V27.5433C18.3483 27.9767 18.6983 28.3283 19.1317 28.3283H29.275C29.7083 28.3283 30.0583 27.9783 30.0583 27.545V20.6633C30.0583 20.4556 29.9758 20.2563 29.8289 20.1094C29.682 19.9625 29.4828 19.88 29.275 19.88H29.0833V17.93C29.0827 17.2894 28.9558 16.6551 28.7101 16.0635C28.4643 15.4719 28.1044 14.9345 27.651 14.482C27.1975 14.0294 26.6594 13.6706 26.0672 13.4261C25.4751 13.1815 24.8406 13.056 24.2 13.0567L24.2017 13.0583ZM24.2017 15.0083C25.8217 15.0083 27.1317 16.3183 27.1317 17.9317V19.8817H21.275V17.9317C21.275 16.3183 22.585 15.0083 24.2017 15.0083Z",
            fill: "currentColor"
        })
    });
i5.displayName = "SvgLogoThreema";
var Q6 = i5;
;
var n5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: "ionicon",
        viewBox: "0 0 512 512",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("title", {
                children: "Logo Twitter"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M496 109.5a201.8 201.8 0 01-56.55 15.3 97.51 97.51 0 0043.33-53.6 197.74 197.74 0 01-62.56 23.5A99.14 99.14 0 00348.31 64c-54.42 0-98.46 43.4-98.46 96.9a93.21 93.21 0 002.54 22.1 280.7 280.7 0 01-203-101.3A95.69 95.69 0 0036 130.4c0 33.6 17.53 63.3 44 80.7A97.5 97.5 0 0135.22 199v1.2c0 47 34 86.1 79 95a100.76 100.76 0 01-25.94 3.4 94.38 94.38 0 01-18.51-1.8c12.51 38.5 48.92 66.5 92.05 67.3A199.59 199.59 0 0139.5 405.6a203 203 0 01-23.5-1.4A278.68 278.68 0 00166.74 448c181.36 0 280.44-147.7 280.44-275.8 0-4.2-.11-8.4-.31-12.5A198.48 198.48 0 00496 109.5z"
            })
        ]
    });
n5.displayName = "SvgLogoTwitter";
var F6 = n5;
;
var m5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: "ionicon",
        viewBox: "0 0 512 512",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("title", {
                children: "Logo Vimeo"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M476.9 114c-5-23.39-17.51-38.78-40.61-46.27s-64.92-4.5-94.12 16.79c-26.79 19.51-46.26 54.42-54 78.28a4 4 0 005.13 5c10.77-3.8 21.72-7.1 34-6.45 15 .8 24.51 12 24.91 25.29.3 9.79-.2 18.69-3.6 27.68-10.74 28.68-27.61 56.46-47.55 80.75a72.49 72.49 0 01-10 9.89c-10.21 8.29-18.81 6.1-25.41-5.2-5.4-9.29-9-18.88-12.2-29.08-12.4-39.67-16.81-80.84-23.81-121.52-3.3-19.48-7-39.77-18-56.86-11.6-17.79-28.61-24.58-50-22-14.7 1.8-36.91 17.49-47.81 26.39 0 0-56 46.87-81.82 71.35l21.2 27s17.91-12.49 27.51-18.29c5.7-3.39 12.4-4.09 17.2.2 4.51 3.9 9.61 9 12.31 14.1 5.7 10.69 11.2 21.88 14.7 33.37 13.2 44.27 25.51 88.64 37.81 133.22 6.3 22.78 13.9 44.17 28 63.55 19.31 26.59 39.61 32.68 70.92 21.49 25.41-9.09 46.61-26.18 66-43.87 33.11-30.18 59.12-65.36 85.52-101.14 20.41-27.67 37.31-55.67 51.41-86.95C478.5 179.74 484 147.26 476.9 114z"
            })
        ]
    });
m5.displayName = "SvgLogoVimeo";
var O6 = m5;
;
var o5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: "ionicon",
        viewBox: "0 0 512 512",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("title", {
                children: "Logo Whatsapp"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M414.73 97.1A222.14 222.14 0 00256.94 32C134 32 33.92 131.58 33.87 254a220.61 220.61 0 0029.78 111L32 480l118.25-30.87a223.63 223.63 0 00106.6 27h.09c122.93 0 223-99.59 223.06-222A220.18 220.18 0 00414.73 97.1zM256.94 438.66h-.08a185.75 185.75 0 01-94.36-25.72l-6.77-4-70.17 18.32 18.73-68.09-4.41-7A183.46 183.46 0 0171.53 254c0-101.73 83.21-184.5 185.48-184.5a185 185 0 01185.33 184.64c-.04 101.74-83.21 184.52-185.4 184.52zm101.69-138.19c-5.57-2.78-33-16.2-38.08-18.05s-8.83-2.78-12.54 2.78-14.4 18-17.65 21.75-6.5 4.16-12.07 1.38-23.54-8.63-44.83-27.53c-16.57-14.71-27.75-32.87-31-38.42s-.35-8.56 2.44-11.32c2.51-2.49 5.57-6.48 8.36-9.72s3.72-5.56 5.57-9.26.93-6.94-.46-9.71-12.54-30.08-17.18-41.19c-4.53-10.82-9.12-9.35-12.54-9.52-3.25-.16-7-.2-10.69-.2a20.53 20.53 0 00-14.86 6.94c-5.11 5.56-19.51 19-19.51 46.28s20 53.68 22.76 57.38 39.3 59.73 95.21 83.76a323.11 323.11 0 0031.78 11.68c13.35 4.22 25.5 3.63 35.1 2.2 10.71-1.59 33-13.42 37.63-26.38s4.64-24.06 3.25-26.37-5.11-3.71-10.69-6.48z",
                fillRule: "evenodd"
            })
        ]
    });
o5.displayName = "SvgLogoWhatsApp";
var U6 = o5;
;
var a5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        xmlns: "http://www.w3.org/2000/svg",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M35.5023 6H41.6355L28.2358 21.3156L44 42.1562H31.6563L21.9892 29.5162L10.9273 42.1562H4.78977L19.1222 25.7747L4 6H16.6562L25.395 17.5531L35.5023 6ZM33.3495 38.4848H36.7483L14.8096 9.47867H11.1627L33.3495 38.4848Z",
            fill: "currentColor"
        })
    });
a5.displayName = "SvgLogoX";
var W6 = a5;
;
var v5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: "ionicon",
        viewBox: "0 0 512 512",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("title", {
                children: "Logo Youtube"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M508.64 148.79c0-45-33.1-81.2-74-81.2C379.24 65 322.74 64 265 64h-18c-57.6 0-114.2 1-169.6 3.6C36.6 67.6 3.5 104 3.5 149 1 184.59-.06 220.19 0 255.79q-.15 53.4 3.4 106.9c0 45 33.1 81.5 73.9 81.5 58.2 2.7 117.9 3.9 178.6 3.8q91.2.3 178.6-3.8c40.9 0 74-36.5 74-81.5 2.4-35.7 3.5-71.3 3.4-107q.34-53.4-3.26-106.9zM207 353.89v-196.5l145 98.2z"
            })
        ]
    });
v5.displayName = "SvgLogoYouTube";
var Y6 = v5;
;
var c5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M140 896q-24 0-42-18t-18-42V316q0-24 18-42t42-18h680q24 0 42 18t18 42v520q0 24-18 42t-42 18H140Zm340-302 340-223v-55L480 534 140 316v55l340 223Z"
        })
    });
c5.displayName = "SvgMail";
var J6 = c5;
;
var y5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M140 896q-24 0-42-18t-18-42V316q0-24 18-42t42-18h680q24 0 42 18t18 42v520q0 24-18 42t-42 18H140Zm340-302L140 371v465h680V371L480 594Zm0-60 336-218H145l335 218ZM140 371v-55 520-465Z"
        })
    });
y5.displayName = "SvgMailOutline";
var _6 = y5;
;
var f5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        role: "img",
        viewBox: "0 0 24 24",
        xmlns: "http://www.w3.org/2000/svg",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("title", {
                children: "Markdown"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M22.27 19.385H1.73A1.73 1.73 0 010 17.655V6.345a1.73 1.73 0 011.73-1.73h20.54A1.73 1.73 0 0124 6.345v11.308a1.73 1.73 0 01-1.73 1.731zM5.769 15.923v-4.5l2.308 2.885 2.307-2.885v4.5h2.308V8.078h-2.308l-2.307 2.885-2.308-2.885H3.46v7.847zM21.232 12h-2.309V8.077h-2.307V12h-2.308l3.461 4.039z"
            })
        ]
    });
f5.displayName = "SvgMarkdown";
var $6 = f5;
;
var q5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M405 656h315v-60H465l-60 60Zm-165 0h79l252-249q6-6 6-15t-6-15l-55-50q-5-5-12.5-5t-12.5 5L240 582v74ZM80 976V236q0-23 18-41.5t42-18.5h680q23 0 41.5 18.5T880 236v520q0 23-18.5 41.5T820 816H240L80 976Z"
        })
    });
q5.displayName = "SvgMemo";
var p6 = q5;
;
var u5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 633q-43 0-72-30.917-29-30.916-29-75.083V276q0-41.667 29.441-70.833Q437.882 176 479.941 176t71.559 29.167Q581 234.333 581 276v251q0 44.167-29 75.083Q523 633 480 633Zm-30 303V800q-106-11-178-89t-72-184h60q0 91 64.288 153t155.5 62Q571 742 635.5 680 700 618 700 527h60q0 106-72 184t-178 89v136h-60Z"
        })
    });
u5.displayName = "SvgMic";
var e3 = u5;
;
var b5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M626 523q22.5 0 38.25-15.75T680 469q0-22.5-15.75-38.25T626 415q-22.5 0-38.25 15.75T572 469q0 22.5 15.75 38.25T626 523Zm-292 0q22.5 0 38.25-15.75T388 469q0-22.5-15.75-38.25T334 415q-22.5 0-38.25 15.75T280 469q0 22.5 15.75 38.25T334 523Zm146 272q66 0 121.5-35.5T682 663H278q26 61 81 96.5T480 795Zm0 181q-83 0-156-31.5T197 859q-54-54-85.5-127T80 576q0-83 31.5-156T197 293q54-54 127-85.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 83-31.5 156T763 859q-54 54-127 85.5T480 976Zm0-400Zm0 340q142.375 0 241.188-98.812Q820 718.375 820 576t-98.812-241.188Q622.375 236 480 236t-241.188 98.812Q140 433.625 140 576t98.812 241.188Q337.625 916 480 916Z"
        })
    });
b5.displayName = "SvgMood";
var l3 = b5;
;
var Z5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M184.783 635Q161 635 143.5 617.7T126 576.106Q126 551 143.373 534t41.769-17q23.458 0 41.658 16.894 18.2 16.894 18.2 41.5T226.783 617.5q-18.217 17.5-42 17.5Zm295.823 0Q456 635 438.5 617.7T421 576.106Q421 551 438.3 534t41.594-17Q505 517 522 533.894t17 41.5Q539 600 522.106 617.5t-41.5 17.5Zm294.288 0q-24.823 0-42.359-17.3Q715 600.4 715 576.106 715 551 732.677 534t42.5-17Q800 517 817.5 533.894t17.5 41.5Q835 600 817.358 617.5 799.717 635 774.894 635Z"
        })
    });
_c56 = Z5;
Z5.displayName = "SvgMoreHorizontal";
var i3 = Z5;
;
var A5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480.606 930Q456 930 438.5 912.627T421 870.858q0-23.458 17.3-41.658 17.3-18.2 41.594-18.2Q505 811 522 829.217t17 42Q539 895 522.106 912.5t-41.5 17.5Zm0-295Q456 635 438.5 617.7T421 576.106Q421 551 438.3 534t41.594-17Q505 517 522 533.894t17 41.5Q539 600 522.106 617.5t-41.5 17.5Zm0-294Q456 341 438.5 323.323t-17.5-42.5Q421 256 438.3 238.5t41.594-17.5Q505 221 522 238.642q17 17.641 17 42.464t-16.894 42.359Q505.212 341 480.606 341Z"
        })
    });
_c57 = A5;
A5.displayName = "SvgMoreVertical";
var t3 = A5;
;
var T5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M450 822h60V693h130v-60H510V503h-60v130H320v60h130v129ZM220 976q-24 0-42-18t-18-42V236q0-24 18-42t42-18h361l219 219v521q0 24-18 42t-42 18H220Zm331-554h189L551 236v186Z"
        })
    });
_c58 = T5;
T5.displayName = "SvgNoteAdd";
var n3 = T5;
;
var M5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M160 856v-60h84V490q0-84 49.5-149.5T424 258v-29q0-23 16.5-38t39.5-15q23 0 39.5 15t16.5 38v29q81 17 131 82.5T717 490v306h83v60H160Zm320 120q-32 0-56-23.5T400 896h160q0 33-23.5 56.5T480 976Z"
        })
    });
_c59 = M5;
M5.displayName = "SvgNotifications";
var d3 = M5;
;
var L5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M124 489q0-81 34-153.5T255 212l41 45q-53 43-82.5 103.5T184 489h-60Zm653 0q0-68-28-128.5T668 257l41-45q62 52 95 124t33 153h-60ZM160 856v-60h84V490q0-84 49.5-149.5T424 258v-29q0-23 16.5-38t39.5-15q23 0 39.5 15t16.5 38v29q81 17 131 82.5T717 490v306h83v60H160Zm320 120q-32 0-56-23.5T400 896h160q0 33-23.5 56.5T480 976Z"
        })
    });
_c60 = L5;
L5.displayName = "SvgNotificationsActive";
var m3 = L5;
;
var N5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M160 856v-60h84V490q0-84 49.5-149.5T424 258v-29q0-23 16.5-38t39.5-15q23 0 39.5 15t16.5 38v29q81 17 131 82.5T717 490v306h83v60H160Zm320-295Zm0 415q-32 0-56-23.5T400 896h160q0 33-23.5 56.5T480 976ZM304 796h353V490q0-74-51-126t-125-52q-74 0-125.5 52T304 490v306Z"
        })
    });
_c61 = N5;
N5.displayName = "SvgNotificationsNone";
var s3 = N5;
;
var I5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M717 724 313 320q27-26 54.5-40.5T424 258v-26q0-23 16.5-39.5T480 176q23 0 39.5 16.5T536 232v26q78 17 129.5 82T717 490v234ZM160 856v-60h84V481q0-14 1.5-27t5.5-26L75 251l42-42 726 727-42 42-122-122H160Zm320 120q-33 0-56.5-23.5T400 896h160q0 33-23.5 56.5T480 976Z"
        })
    });
_c62 = I5;
I5.displayName = "SvgNotificationsOff";
var o3 = I5;
;
var F5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M160 856v-60h84V490q0-84 49.5-149.5T424 258v-29q0-23 16.5-38t39.5-15q23 0 39.5 15t16.5 38v29q81 17 131 82.5T717 490v306h83v60H160Zm320 120q-32 0-56-23.5T400 896h160q0 33-23.5 56.5T480 976Z"
        })
    });
_c63 = F5;
F5.displayName = "SvgNotificationsOn";
var g3 = F5;
;
var O5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M180 936q-24 0-42-18t-18-42V276q0-24 18-42t42-18h279v60H180v600h600V597h60v279q0 24-18 42t-42 18H180Zm202-219-42-43 398-398H519v-60h321v321h-60V319L382 717Z"
        })
    });
_c64 = O5;
O5.displayName = "SvgOpenInNew";
var a3 = O5;
;
var U5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        stroke: "currentColor",
        fill: "currentColor",
        strokeWidth: 0,
        viewBox: "0 0 32 32",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        xmlns: "http://www.w3.org/2000/svg",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M16 5.559c-6.118 0-11.078 4.96-11.078 11.079 0 4.749 2.989 8.799 7.188 10.374l2.553-6.808c-1.444-0.541-2.471-1.934-2.471-3.566 0-2.103 1.705-3.808 3.808-3.808s3.808 1.705 3.808 3.808c0 1.633-1.028 3.025-2.471 3.566l2.553 6.808c4.199-1.575 7.188-5.625 7.188-10.374-0-6.119-4.96-11.079-11.079-11.079z"
        })
    });
_c65 = U5;
U5.displayName = "SvgOpensource";
var h3 = U5;
;
var W5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M120 976v-60h100v-30h-60v-60h60v-30H120v-60h120q17 0 28.5 11.5T280 776v40q0 17-11.5 28.5T240 856q17 0 28.5 11.5T280 896v40q0 17-11.5 28.5T240 976H120Zm0-280V586q0-17 11.5-28.5T160 546h60v-30H120v-60h120q17 0 28.5 11.5T280 496v70q0 17-11.5 28.5T240 606h-60v30h100v60H120Zm60-280V236h-60v-60h120v240h-60Zm189 431v-60h471v60H369Zm0-243v-60h471v60H369Zm0-243v-60h471v60H369Z"
        })
    });
_c66 = W5;
W5.displayName = "SvgOrderedList";
var v3 = W5;
;
var X5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M331 625h37v-83h48q15.725 0 26.362-10.638Q453 520.725 453 505v-48q0-15.725-10.638-26.362Q431.725 420 416 420h-85v205Zm37-120v-48h48v48h-48Zm129 120h84q15 0 26-10.638 11-10.637 11-26.362V457q0-15.725-11-26.362Q596 420 581 420h-84v205Zm37-37V457h47v131h-47Zm133 37h37v-83h50v-37h-50v-48h50v-37h-87v205ZM260 856q-24 0-42-18t-18-42V236q0-24 18-42t42-18h560q24 0 42 18t18 42v560q0 24-18 42t-42 18H260ZM140 976q-24 0-42-18t-18-42V296h60v620h620v60H140Z"
        })
    });
_c67 = X5;
X5.displayName = "SvgPdf";
var r3 = X5;
;
var _5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 0 24 24",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        fill: "currentColor",
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M9 16h2v4h2V6h2v14h2V6h3V4H9c-3.309 0-6 2.691-6 6s2.691 6 6 6zM9 6h2v8H9c-2.206 0-4-1.794-4-4s1.794-4 4-4z"
        })
    });
_5.displayName = "SvgParagraph";
var c3 = _5;
;
var j5 = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M565 856V296h155v560H565Zm-325 0V296h155v560H240Z"
        })
    });
j5.displayName = "SvgPause";
var w3 = j5;
;
var ee = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M370 736h60V416h-60v320Zm160 0h60V416h-60v320Zm-50 240q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Zm0-60q142 0 241-99.5T820 576q0-142-99-241t-241-99q-141 0-240.5 99T140 576q0 141 99.5 240.5T480 916Zm0-340Z"
        })
    });
ee.displayName = "SvgPauseCircle";
var y3 = ee;
;
var ie = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M370 736h60V416h-60v320Zm160 0h60V416h-60v320Zm-50 240q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Zm0-60q142 0 241-99.5T820 576q0-142-99-241t-241-99q-141 0-240.5 99T140 576q0 141 99.5 240.5T480 916Zm0-340Z"
        })
    });
ie.displayName = "SvgPauseCircleOutline";
var S3 = ie;
;
var ne = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 575q-66 0-108-42t-42-108q0-66 42-108t108-42q66 0 108 42t42 108q0 66-42 108t-108 42ZM160 896v-94q0-38 19-65t49-41q67-30 128.5-45T480 636q62 0 123 15.5T731 696q31 14 50 41t19 65v94H160Z"
        })
    });
ne.displayName = "SvgPerson";
var f3 = ne;
;
var me = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 575q-66 0-108-42t-42-108q0-66 42-108t108-42q66 0 108 42t42 108q0 66-42 108t-108 42ZM160 896v-94q0-38 19-65t49-41q67-30 128.5-45T480 636q62 0 123 15.5t127.921 44.694q31.301 14.126 50.19 40.966Q800 764 800 802v94H160Zm60-60h520v-34q0-16-9.5-30.5T707 750q-64-31-117-42.5T480 696q-57 0-111 11.5T252 750q-14 7-23 21.5t-9 30.5v34Zm260-321q39 0 64.5-25.5T570 425q0-39-25.5-64.5T480 335q-39 0-64.5 25.5T390 425q0 39 25.5 64.5T480 515Zm0-90Zm0 411Z"
        })
    });
me.displayName = "SvgPersonOutline";
var V3 = me;
;
var oe = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M260 1016q-24 0-42-18t-18-42V196q0-24 18-42t42-18h440q24 0 42 18t18 42v760q0 24-18 42t-42 18H260Zm220-75q13 0 21.5-8.5T510 911q0-13-8.5-21.5T480 881q-13 0-21.5 8.5T450 911q0 13 8.5 21.5T480 941ZM260 806h440V286H260v520Z"
        })
    });
oe.displayName = "SvgPhoneIPhone";
var q3 = oe;
;
var ae = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M320 853V293l440 280-440 280Z"
        })
    });
ae.displayName = "SvgPlay";
var G3 = ae;
;
var ve = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m383 746 267-170-267-170v340Zm97 230q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Zm0-60q142 0 241-99.5T820 576q0-142-99-241t-241-99q-141 0-240.5 99T140 576q0 141 99.5 240.5T480 916Zm0-340Z"
        })
    });
ve.displayName = "SvgPlayCircleOutline";
var u3 = ve;
;
var ce = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M120 725v-60h306v60H120Zm0-165v-60h473v60H120Zm0-165v-60h473v60H120Zm532 460L516 719l42-43 94 93 185-185 43 43-228 228Z"
        })
    });
ce.displayName = "SvgPlayListAddCheck";
var z3 = ce;
;
var ye = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M120 726v-60h300v60H120Zm0-165v-60h470v60H120Zm0-165v-60h470v60H120Zm530 500V726H480v-60h170V496h60v170h170v60H710v170h-60Z"
        })
    });
ye.displayName = "SvgPlaylistAdd";
var b3 = ye;
;
var fe = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M120 725v-60h306v60H120Zm0-165v-60h473v60H120Zm0-165v-60h473v60H120Zm532 460L516 719l42-43 94 93 185-185 43 43-228 228Z"
        })
    });
fe.displayName = "SvgPlaylistRemove";
var x3 = fe;
;
var qe = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M450 976V650q-22-9-36-29t-14-45q0-33 23.5-56.5T480 496q33 0 56.5 23.5T560 576q0 25-14 45t-36 29v326h-60ZM204 866q-57-55-90.5-129.5T80 576q0-83 31.5-156T197 293q54-54 127-85.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 86-33.5 160.5T756 866l-43-43q50-47 78.5-110T820 576q0-142-99-241t-241-99q-142 0-241 99t-99 241q0 74 28.5 137T247 823l-43 43Zm113-113q-35-33-56-78.5T240 576q0-100 70-170t170-70q100 0 170 70t70 170q0 53-21 98.5T643 753l-43-43q28-25 44-59t16-75q0-75-52.5-127.5T480 396q-75 0-127.5 52.5T300 576q0 41 16 75t44 59l-43 43Z"
        })
    });
qe.displayName = "SvgPodcast";
var Z3 = qe;
;
var ue = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M450 976V650q-22-9-36-29t-14-45q0-33 23.5-56.5T480 496q33 0 56.5 23.5T560 576q0 25-14 45t-36 29v326h-60ZM204 866q-57-55-90.5-129.5T80 576q0-83 31.5-156T197 293q54-54 127-85.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 86-33.5 160.5T756 866l-43-43q50-47 78.5-110T820 576q0-142-99-241t-241-99q-142 0-241 99t-99 241q0 74 28.5 137T247 823l-43 43Zm113-113q-35-33-56-78.5T240 576q0-100 70-170t170-70q100 0 170 70t70 170q0 53-21 98.5T643 753l-43-43q28-25 44-59t16-75q0-75-52.5-127.5T480 396q-75 0-127.5 52.5T300 576q0 41 16 75t44 59l-43 43Z"
        })
    });
ue.displayName = "SvgPodcasts";
var C3 = ue;
;
var be = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 -960 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M640-640v-120H320v120h-80v-200h480v200h-80Zm-480 80h640-640Zm560 100q17 0 28.5-11.5T760-500q0-17-11.5-28.5T720-540q-17 0-28.5 11.5T680-500q0 17 11.5 28.5T720-460Zm-80 260v-160H320v160h320Zm80 80H240v-160H80v-240q0-51 35-85.5t85-34.5h560q51 0 85.5 34.5T880-520v240H720v160Zm80-240v-160q0-17-11.5-28.5T760-560H200q-17 0-28.5 11.5T160-520v160h80v-80h480v80h80Z"
        })
    });
be.displayName = "SvgPrint";
var A3 = be;
;
var Ze = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M24 44q-4.15 0-7.8-1.575-3.65-1.575-6.35-4.275-2.7-2.7-4.275-6.35Q4 28.15 4 24t1.575-7.8Q7.15 12.55 9.85 9.85q2.7-2.7 6.35-4.275Q19.85 4 24 4t7.8 1.575q3.65 1.575 6.35 4.275 2.7 2.7 4.275 6.35Q44 19.85 44 24t-1.575 7.8q-1.575 3.65-4.275 6.35-2.7 2.7-6.35 4.275Q28.15 44 24 44Zm-2.15-3.05v-4.1q-1.75 0-2.95-1.3-1.2-1.3-1.2-3.05v-2.2L7.45 20.05q-.25 1-.35 1.975Q7 23 7 24q0 6.5 4.225 11.35t10.625 5.6Zm14.7-5.4q1.1-1.2 1.925-2.55.825-1.35 1.4-2.825t.85-3.025Q41 25.6 41 24q0-5.3-2.9-9.625T30.35 8.05v.9q0 1.75-1.2 3.05-1.2 1.3-2.95 1.3h-4.35v4.35q0 .85-.675 1.4-.675.55-1.525.55H15.5V24h12.9q.85 0 1.4.65.55.65.55 1.5v6.35h2.15q1.45 0 2.55.85 1.1.85 1.5 2.2Z"
        })
    });
_c68 = Ze;
Ze.displayName = "SvgPublic";
var k3 = Ze;
;
var Ae = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M160 666v-60h640v60H160Zm0-120v-60h640v60H160Z"
        })
    });
_c69 = Ae;
Ae.displayName = "SvgPunchline";
var T3 = Ae;
;
var Te = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M543 716q16.595 0 28.798-12.202Q584 691.595 584 675t-12.202-28.798Q559.595 634 543 634t-28.798 12.202Q502 658.405 502 675t12.202 28.798Q526.405 716 543 716Zm-25-126h47q2-29 8.5-43t32.5-39q27-26 37.5-45.395Q654 443.21 654 417q0-45.882-31.5-74.941Q591 313 540 313q-38 0-68 20.5T428 391l45 19q11-25 27.5-38t39.5-13q29.778 0 48.389 17Q607 393 607 419q0 20-9 35t-32 32q-32 29-40 46.5t-8 57.5ZM260 856q-24 0-42-18t-18-42V236q0-24 18-42t42-18h560q24 0 42 18t18 42v560q0 24-18 42t-42 18H260Zm0-60h560V236H260v560ZM140 976q-24 0-42-18t-18-42V296h60v620h620v60H140Zm120-740v560-560Z"
        })
    });
_c70 = Te;
Te.displayName = "SvgQuiz";
var P3 = Te;
;
var Me = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M543 716q16.595 0 28.798-12.202Q584 691.595 584 675t-12.202-28.798Q559.595 634 543 634t-28.798 12.202Q502 658.405 502 675t12.202 28.798Q526.405 716 543 716Zm-25-126h47q2-29 8.5-43t32.5-39q27-26 37.5-45.395Q654 443.21 654 417q0-45.882-31.5-74.941Q591 313 540 313q-38 0-68 20.5T428 391l45 19q11-25 27.5-38t39.5-13q29.778 0 48.389 17Q607 393 607 419q0 20-9 35t-32 32q-32 29-40 46.5t-8 57.5ZM260 856q-24 0-42-18t-18-42V236q0-24 18-42t42-18h560q24 0 42 18t18 42v560q0 24-18 42t-42 18H260Zm0-60h560V236H260v560ZM140 976q-24 0-42-18t-18-42V296h60v620h620v60H140Zm120-740v560-560Z"
        })
    });
_c71 = Me;
Me.displayName = "SvgQuizOutline";
var M3 = Me;
;
var Le = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 762q78 0 132-54t54-132q0-78-54-132t-132-54q-78 0-132 54t-54 132q0 78 54 132t132 54Zm0 214q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Zm0-60q142 0 241-99.5T820 576q0-142-99-241t-241-99q-141 0-240.5 99T140 576q0 141 99.5 240.5T480 916Zm0-340Z"
        })
    });
_c72 = Le;
Le.displayName = "SvgRadioButtonChecked";
var H3 = Le;
;
var Ne = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 976q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Zm0-60q142 0 241-99.5T820 576q0-142-99-241t-241-99q-141 0-240.5 99T140 576q0 141 99.5 240.5T480 916Zm0-340Z"
        })
    });
_c73 = Ne;
Ne.displayName = "SvgRadioButtonUnchecked";
var L3 = Ne;
;
var Ie = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 762q78 0 132-54t54-132q0-78-54-132t-132-54q-78 0-132 54t-54 132q0 78 54 132t132 54Zm0 214q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Zm0-60q142 0 241-99.5T820 576q0-142-99-241t-241-99q-141 0-240.5 99T140 576q0 141 99.5 240.5T480 916Zm0-340Z"
        })
    });
_c74 = Ie;
Ie.displayName = "SvgRadioChecked";
var B3 = Ie;
;
var Fe = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 976q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Zm0-60q142 0 241-99.5T820 576q0-142-99-241t-241-99q-141 0-240.5 99T140 576q0 141 99.5 240.5T480 916Zm0-340Z"
        })
    });
_c75 = Fe;
Fe.displayName = "SvgRadioUnchecked";
var N3 = Fe;
;
var Oe = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M405 656h315v-60H465l-60 60Zm-165 0h79l252-249q6-6 6-15t-6-15l-55-50q-5-5-12.5-5t-12.5 5L240 582v74ZM80 976V236q0-23 18-41.5t42-18.5h680q23 0 41.5 18.5T880 236v520q0 23-18.5 41.5T820 816H240L80 976Z"
        })
    });
_c76 = Oe;
Oe.displayName = "SvgRateReview";
var E3 = Oe;
;
var Ue = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m421 758 283-283-46-45-237 237-120-120-45 45 165 166Zm59 218q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Zm0-60q142 0 241-99.5T820 576q0-142-99-241t-241-99q-141 0-240.5 99T140 576q0 141 99.5 240.5T480 916Zm0-340Z"
        })
    });
_c77 = Ue;
Ue.displayName = "SvgRead";
var I3 = Ue;
;
var We = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m627 769 45-45-159-160V363h-60v225l174 181ZM480 976q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-82 31.5-155t86-127.5Q252 239 325 207.5T480 176q82 0 155 31.5t127.5 86Q817 348 848.5 421T880 576q0 82-31.5 155t-86 127.5Q708 913 635 944.5T480 976Zm0-400Zm0 340q140 0 240-100t100-240q0-140-100-240T480 236q-140 0-240 100T140 576q0 140 100 240t240 100Z"
        })
    });
_c78 = We;
We.displayName = "SvgReadTime";
var Q3 = We;
;
var Xe = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 -960 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M481.662-180.001q-124.748 0-212.435-87.67-87.687-87.669-87.687-212.268t87.687-212.329q87.687-87.731 212.312-87.731 81.922 0 145.153 35.654 63.231 35.654 106.384 97.578v-133.232h45.384v225.537H552.924v-45.384h157.999q-36.077-60.769-94.692-97.769-58.616-37-134.692-37-106.757 0-180.686 73.916t-73.929 180.654q0 106.737 73.971 180.699 73.971 73.961 180.787 73.961 81.318 0 148.395-46.538 67.077-46.539 93.692-123h46.999q-27.846 96.922-107.964 155.922-80.117 59-181.142 59Z"
        })
    });
_c79 = Xe;
Xe.displayName = "SvgRefresh";
var F3 = Xe;
;
var _e = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M200 606v-60h560v60H200Z"
        })
    });
_e.displayName = "SvgRemove";
var R3 = _e;
;
var je = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M280 603h400v-60H280v60Zm200 373q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Zm0-60q142 0 241-99.5T820 576q0-142-99-241t-241-99q-141 0-240.5 99T140 576q0 141 99.5 240.5T480 916Zm0-340Z"
        })
    });
je.displayName = "SvgRemoveCircle";
var O3 = je;
;
var el = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M200 606v-60h560v60H200Z"
        })
    });
el.displayName = "SvgRemoveOutline";
var D3 = el;
;
var il = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 976q-75 0-140.5-28T225 871q-49-49-77-114.5T120 616h60q0 125 87.321 212.5Q354.643 916 480 916t212.679-87.321Q780 741.357 780 616t-85-212.679Q610 316 485 316h-22l73 73-42 42-147-147 147-147 41 41-78 78h23q75 0 140.5 28T735 361q49 49 77 114.5T840 616q0 75-28 140.5T735 871q-49 49-114.5 77T480 976ZM360 746V534h-54v-49h104v261h-50Zm147 0q-18.7 0-31.35-12.65Q463 720.7 463 702V529q0-18.7 12.65-31.35Q488.3 485 507 485h83q18.7 0 31.35 12.65Q634 510.3 634 529v173q0 18.7-12.65 31.35Q608.7 746 590 746h-83Zm6-50h71V534h-71v162Z"
        })
    });
il.displayName = "SvgReplay";
var U3 = il;
;
var nl = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 976q-75 0-140.5-28T225 871q-49-49-77-114.5T120 616h60q0 125 87.321 212.5Q354.643 916 480 916t212.679-87.321Q780 741.357 780 616t-85-212.679Q610 316 485 316h-22l73 73-42 42-147-147 147-147 41 41-78 78h23q75 0 140.5 28T735 361q49 49 77 114.5T840 616q0 75-28 140.5T735 871q-49 49-114.5 77T480 976ZM360 746V534h-54v-49h104v261h-50Zm147 0q-18.7 0-31.35-12.65Q463 720.7 463 702V529q0-18.7 12.65-31.35Q488.3 485 507 485h83q18.7 0 31.35 12.65Q634 510.3 634 529v173q0 18.7-12.65 31.35Q608.7 746 590 746h-83Zm6-50h71V534h-71v162Z"
        })
    });
nl.displayName = "SvgReplay10";
var K3 = nl;
;
var ml = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        stroke: "currentColor",
        fill: "currentColor",
        strokeWidth: 0,
        viewBox: "0 0 24 24",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        xmlns: "http://www.w3.org/2000/svg",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "none",
                d: "M0 0h24v24H0z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M10 9V5l-7 7 7 7v-4.1c5 0 8.5 1.6 11 5.1-1-5-4-10-11-11z"
            })
        ]
    });
ml.displayName = "SvgReply";
var W3 = ml;
;
var ol = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M200 936V256h343l19 86h238v370H544l-19-85H260v309h-60Z"
        })
    });
ol.displayName = "SvgReport";
var X3 = ol;
;
var al = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M435 976q-48-7-93-25t-85-48l43-44q32 24 66 37.5t69 19.5v60Zm90 0v-60q110-21 182.5-103.5T780 613q0-127-86.5-213.5T480 313h-20l79 79-44 44-153-153 153-153 44 44-79 79h20q75 0 140.5 28T735 358q49 49 77 114.5T840 613q0 140-89 241T525 976ZM194 840q-28-38-46.5-84.5T122 658h61q5 38 18.5 73t36.5 65l-44 44Zm-72-272q7-50 25-95.5t47-85.5l44 43q-23 33-36.5 68T183 568h-61Z"
        })
    });
al.displayName = "SvgRevert";
var J3 = al;
;
var vl = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M220 816V336h60v480h-60Zm520 0L394 576l346-240v480Z"
        })
    });
vl.displayName = "SvgRewind";
var _3 = vl;
;
var cl = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M435 976q-48-7-93-25t-85-48l43-44q32 24 66 37.5t69 19.5v60Zm90 0v-60q110-21 182.5-103.5T780 613q0-127-86.5-213.5T480 313h-20l79 79-44 44-153-153 153-153 44 44-79 79h20q75 0 140.5 28T735 358q49 49 77 114.5T840 613q0 140-89 241T525 976ZM194 840q-28-38-46.5-84.5T122 658h61q5 38 18.5 73t36.5 65l-44 44Zm-72-272q7-50 25-95.5t47-85.5l44 43q-23 33-36.5 68T183 568h-61Z"
        })
    });
cl.displayName = "SvgRotateLeftOutline";
var $3 = cl;
;
var yl = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M218 936q-41 0-69.5-28.5T120 838q0-41 28.5-69.5T218 740q41 0 69.5 28.5T316 838q0 41-28.5 69.5T218 936Zm492 0q0-122-46.5-229.5T537 519q-80-80-187.5-126.5T120 346v-90q141 0 264.5 53.5t216 146q92.5 92.5 146 216T800 936h-90Zm-238 0q0-158-97-259T120 576v-90q97 0 178 34t139.5 94Q496 674 529 756.5T562 936h-90Z"
        })
    });
yl.displayName = "SvgRssFeed";
var j3 = yl;
;
var fl = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m627 769 45-45-159-160V363h-60v225l174 181ZM480 976q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-82 31.5-155t86-127.5Q252 239 325 207.5T480 176q82 0 155 31.5t127.5 86Q817 348 848.5 421T880 576q0 82-31.5 155t-86 127.5Q708 913 635 944.5T480 976Zm0-400Zm0 340q140 0 240-100t100-240q0-140-100-240T480 236q-140 0-240 100T140 576q0 140 100 240t240 100Z"
        })
    });
fl.displayName = "SvgSchedule";
var p3 = fl;
;
var ql = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
        })
    });
ql.displayName = "SvgSearch";
var et = ql;
;
var ul = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        viewBox: "0 0 26 18",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fillRule: "evenodd",
                d: "M6.22222 10.4444C8.55409 10.4444 10.4444 8.55409 10.4444 6.22222C10.4444 3.89035 8.55409 2 6.22222 2C3.89035 2 2 3.89035 2 6.22222C2 8.55409 3.89035 10.4444 6.22222 10.4444ZM6.22222 12.4444C9.65866 12.4444 12.4444 9.65866 12.4444 6.22222C12.4444 2.78578 9.65866 0 6.22222 0C2.78578 0 0 2.78578 0 6.22222C0 9.65866 2.78578 12.4444 6.22222 12.4444Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fillRule: "evenodd",
                d: "M8.92868 9.57158C9.37051 9.24021 9.99155 9.32207 10.3158 9.75442L15.0129 16.0172C15.3371 16.4495 15.2418 17.0686 14.8 17.4 14.3582 17.7314 13.7371 17.6495 13.4129 17.2172L8.71582 10.9544C8.39155 10.5221 8.48686 9.90295 8.92868 9.57158ZM14 1C14 .447715 14.4477 0 15 0H25C25.5523 0 26 .447715 26 1 26 1.55228 25.5523 2 25 2H15C14.4477 2 14 1.55228 14 1ZM16 7C16 6.44772 16.4477 6 17 6L25 6C25.5523 6 26 6.44772 26 7 26 7.55228 25.5523 8 25 8L17 8C16.4477 8 16 7.55228 16 7ZM18 13C18 12.4477 18.4477 12 19 12L25 12C25.5523 12 26 12.4477 26 13 26 13.5523 25.5523 14 25 14L19 14C18.4477 14 18 13.5523 18 13Z"
            })
        ]
    });
ul.displayName = "SvgSearchMenu";
var lt = ul;
;
var bl = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        viewBox: "0 0 24 24",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M6.01025 13.0665C8.16275 13.0665 9.64 11.5883 9.64 9.43582 9.64 7.28332 8.16275 5.79985 6.01025 5.79985 3.85776 5.79985 2.37333 7.28332 2.37333 9.43582 2.37333 11.5883 3.85776 13.0665 6.01025 13.0665ZM6.01025 15.4401C9.18235 15.4401 12.0267 12.6079 12.0267 9.43582 12.0267 6.26372 9.18235 3.42651 6.01025 3.42651 2.83816 3.42651 0 6.26372 0 9.43582 0 12.6079 2.83816 15.4401 6.01025 15.4401ZM12.9231 4.94572C12.9231 4.25352 13.3364 3.69238 13.8462 3.69238H23.0769C23.5868 3.69238 24 4.25352 24 4.94572 24 5.63791 23.5868 6.19905 23.0769 6.19905H13.8462C13.3364 6.19905 12.9231 5.63791 12.9231 4.94572ZM14.7692 10.484C14.7692 9.79186 15.1824 9.23071 15.6922 9.23071H23.0769C23.5867 9.23071 23.9999 9.79186 23.9999 10.484 23.9999 11.1762 23.5867 11.7374 23.0769 11.7374H15.6922C15.1824 11.7374 14.7692 11.1762 14.7692 10.484Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M8.84523 12.5475C9.39804 12.1309 10.0867 12.1124 10.3834 12.5062L14.6815 18.2099C14.9782 18.6037 14.7706 19.2606 14.2178 19.6771 13.665 20.0937 12.9763 20.1122 12.6796 19.7185L8.38154 14.0147C8.08481 13.621 8.29243 12.9641 8.84523 12.5475ZM16.6154 16.0226C16.6154 15.3304 17.0286 14.7693 17.5384 14.7693H23.0769C23.5867 14.7693 24 15.3304 24 16.0226 24 16.7148 23.5867 17.276 23.0769 17.276H17.5384C17.0286 17.276 16.6154 16.7148 16.6154 16.0226Z"
            })
        ]
    });
bl.displayName = "SvgSearchMenuBold";
var tt = bl;
;
var Zl = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M220 1016q-24 0-42-18t-18-42V447q0-24 18-42t42-18h169v60H220v509h520V447H569v-60h171q24 0 42 18t18 42v509q0 24-18 42t-42 18H220Zm229-307V252l-88 88-43-43 161-161 161 161-43 43-88-88v457h-60Z"
        })
    });
_c80 = Zl;
Zl.displayName = "SvgShare";
var dt = Zl;
;
var Al = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M680 816V336h60v480h-60Zm-460 0V336l346 240-346 240Z"
        })
    });
_c81 = Al;
Al.displayName = "SvgSkipNext";
var mt = Al;
;
var Tl = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M220 816V336h60v480h-60Zm520 0L394 576l346-240v480Z"
        })
    });
_c82 = Tl;
Tl.displayName = "SvgSkipPrevious";
var st = Tl;
;
var Ml = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M450 547h60V296h-60v251Zm29.982 142q14.018 0 23.518-9.482 9.5-9.483 9.5-23.5 0-14.018-9.482-23.518-9.483-9.5-23.5-9.5-14.018 0-23.518 9.482-9.5 9.483-9.5 23.5 0 14.018 9.482 23.518 9.483 9.5 23.5 9.5ZM80 976V236q0-23 18-41.5t42-18.5h680q23 0 41.5 18.5T880 236v520q0 23-18.5 41.5T820 816H240L80 976Zm60-145 75-75h605V236H140v595Zm0-595v595-595Z"
        })
    });
_c83 = Ml;
Ml.displayName = "SvgSmsFailedOutline";
var ot = Ml;
;
var Ll = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        role: "img",
        viewBox: "0 0 24 24",
        xmlns: "http://www.w3.org/2000/svg",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("title", {
                children: "Spotify"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"
            })
        ]
    });
_c84 = Ll;
Ll.displayName = "SvgSpotify";
var gt = Ll;
;
var Nl = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m323 851 157-94 157 95-42-178 138-120-182-16-71-168-71 167-182 16 138 120-42 178Zm-90 125 65-281L80 506l288-25 112-265 112 265 288 25-218 189 65 281-247-149-247 149Zm247-355Z"
        })
    });
_c85 = Nl;
Nl.displayName = "SvgStar";
var ht = Nl;
;
var Il = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m320 816 160-122 160 122-64-197 160-113H541l-61-203-62 203H223l160 113-63 197Zm160 160q-82 0-155-31.5t-127.5-86Q143 804 111.5 731T80 576q0-83 31.5-156t86-127Q252 239 325 207.5T480 176q83 0 156 31.5T763 293q54 54 85.5 127T880 576q0 82-31.5 155T763 858.5q-54 54.5-127 86T480 976Z"
        })
    });
_c86 = Il;
Il.displayName = "SvgStars";
var vt = Il;
;
var Fl = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M394 936 160 699l233-233 43 43-162 162h426V256h60v475H275l162 162-43 43Z"
        })
    });
_c87 = Fl;
Fl.displayName = "SvgSubdirectoryArrowLeft";
var rt = Fl;
;
var Ol = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m566 936-43-43 162-162H200V256h60v415h426L524 509l43-43 233 233-234 237Z"
        })
    });
_c88 = Ol;
Ol.displayName = "SvgSubdirectoryArrowRight";
var ct = Ol;
;
var Ul = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M160 856v-60h386v60H160Zm0-166v-60h640v60H160Zm0-167v-60h640v60H160Zm0-167v-60h640v60H160Z"
        })
    });
_c89 = Ul;
Ul.displayName = "SvgSubject";
var wt = Ul;
;
var Wl = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M490.175 941q12.825 0 21.325-8.675 8.5-8.676 8.5-21.5 0-12.825-8.675-21.325-8.676-8.5-21.5-8.5-12.825 0-21.325 8.675-8.5 8.676-8.5 21.5 0 12.825 8.675 21.325 8.676 8.5 21.5 8.5ZM180 1016q-24.75 0-42.375-17.625T120 956V196q0-24.75 17.625-42.375T180 136h600q24.75 0 42.375 17.625T840 196v760q0 24.75-17.625 42.375T780 1016H180Zm0-210h600V286H180v520Z"
        })
    });
_c90 = Wl;
Wl.displayName = "SvgTabletMac";
var yt = Wl;
;
var Xl = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M27.95 43.15q-.9.9-2.175.9t-2.175-.9L4.85 24.4q-.5-.5-.675-1.05Q4 22.8 4 22.2V7q0-1.3.85-2.15Q5.7 4 7 4h15.2q.6 0 1.2.175t1.1.675L43.15 23.5q.95.95.95 2.225 0 1.275-.95 2.225ZM12.25 14.8q1.05 0 1.825-.775.775-.775.775-1.825 0-1.05-.775-1.825Q13.3 9.6 12.25 9.6q-1.05 0-1.825.775-.775.775-.775 1.825 0 1.05.775 1.825.775.775 1.825.775Z"
        })
    });
_c91 = Xl;
Xl.displayName = "SvgTag";
var St = Xl;
;
var _l = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        role: "img",
        viewBox: "0 0 24 24",
        xmlns: "http://www.w3.org/2000/svg",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("title", {
                children: "Telegram"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"
            })
        ]
    });
_l.displayName = "SvgTelegram";
var ft = _l;
;
var jl = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M140 896q-24 0-42-18t-18-42V316q0-24 18-42t42-18h680q24 0 42 18t18 42v520q0 24-18 42t-42 18H140Zm0-60h680V400H140v436Zm160-72-42-42 103-104-104-104 43-42 146 146-146 146Zm190 4v-60h220v60H490Z"
        })
    });
jl.displayName = "SvgTerminal";
var qt = jl;
;
var ei = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        role: "img",
        viewBox: "0 0 24 24",
        xmlns: "http://www.w3.org/2000/svg",
        width: e.width ?? e.size ?? "1em",
        height: e.height ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("title", {
                children: "Threema"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                d: "M11.998 20.486a1.757 1.757 0 1 1 0 3.514 1.757 1.757 0 0 1 0-3.514zm-6.335 0a1.757 1.757 0 1 1 0 3.514 1.757 1.757 0 0 1 0-3.514zm12.671 0a1.757 1.757 0 1 1 0 3.514 1.757 1.757 0 0 1 0-3.514zM12 0c5.7 0 10.322 4.066 10.322 9.082 0 5.016-4.622 9.083-10.322 9.083a11.45 11.45 0 0 1-4.523-.917l-5.171 1.293 1.105-4.42c-1.094-1.442-1.733-3.175-1.733-5.039C1.678 4.066 6.3 0 12 0zm-.001 4.235A2.926 2.926 0 0 0 9.072 7.16v1.17h-.115a.47.47 0 0 0-.47.47v4.126c0 .26.21.471.47.471h6.086c.26 0 .47-.21.47-.47V8.798a.47.47 0 0 0-.47-.47h-.115v-1.17a2.927 2.927 0 0 0-2.93-2.924zm0 1.17c.972 0 1.758.786 1.758 1.754v1.17h-3.514v-1.17c0-.968.786-1.754 1.756-1.754z"
            })
        ]
    });
ei.displayName = "SvgThreema";
var Gt = ei;
;
var ii = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M430 896V356H200V256h560v100H530v540H430Z"
        })
    });
ii.displayName = "SvgTitle";
var zt = ii;
;
var ni = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m702 755-43-42 106-106H120v-60h646L660 441l42-42 178 178-178 178Z"
        })
    });
ni.displayName = "SvgTrendingFlat";
var bt = ni;
;
var mi = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m343 896-43-43 180-180 180 180-43 43-137-137-137 137Zm137-417L300 299l43-43 137 137 137-137 43 43-180 180Z"
        })
    });
mi.displayName = "SvgUnfoldLess";
var xt = mi;
;
var oi = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M480 936 300 756l44-44 136 136 136-136 44 44-180 180ZM344 444l-44-44 180-180 180 180-44 44-136-136-136 136Z"
        })
    });
oi.displayName = "SvgUnfoldMore";
var Zt = oi;
;
var ai = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M377 858v-60h463v60H377Zm0-252v-60h463v60H377Zm0-253v-60h463v60H377ZM189 895q-28.05 0-48.025-19Q121 857 121 828.5t19.5-48q19.5-19.5 48-19.5t47.5 19.975Q255 800.95 255 829q0 27.225-19.387 46.612Q216.225 895 189 895Zm0-252q-28.05 0-48.025-19.681Q121 603.638 121 576t19.975-47.319Q160.95 509 189 509q27.225 0 46.613 19.681Q255 548.362 255 576t-19.387 47.319Q216.225 643 189 643Zm-1-253q-27.637 0-47.319-19.681Q121 350.638 121 323t19.681-47.319Q160.363 256 188 256q27.637 0 47.319 19.681Q255 295.362 255 323t-19.681 47.319Q215.637 390 188 390Z"
        })
    });
ai.displayName = "SvgUnorderedList";
var Ct = ai;
;
var vi = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M816 992 648 827q-35 14-79 21.5t-89 7.5q-146 0-265-81.5T40 556q20-52 55.5-101.5T182 360L56 234l42-43 757 757-39 44ZM480 726q14 0 30-2.5t27-7.5L320 499q-5 12-7.5 27t-2.5 30q0 72 50 121t120 49Zm278 40L629 637q10-16 15.5-37.5T650 556q0-71-49.5-120.5T480 386q-22 0-43 5t-38 16L289 296q35-16 89.5-28T485 256q143 0 261.5 81.5T920 556q-26 64-67 117t-95 93ZM585 593 443 451q29-11 60-4.5t54 28.5q23 23 32 51.5t-4 66.5Z"
        })
    });
vi.displayName = "SvgUnpublish";
var At = vi;
;
var ci = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M8 42v-3h32v3Zm16-6-9.7-9.7 2.15-2.15 6.05 6.05V6h3v24.2l5.85-5.85 2.15 2.15Z"
        })
    });
ci.displayName = "SvgVerticalAlignBottom";
var kt = ci;
;
var yi = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M22.5 41.9V17.7l-5.9 5.9-2.1-2.1L24 12l9.5 9.5-2.1 2.1-5.9-5.9v24.2ZM8 9V6h32v3Z"
        })
    });
yi.displayName = "SvgVerticalAlignTop";
var Tt = yi;
;
var fi = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M160 684v-60h640v60H160Zm0 160v-60h640v60H160Zm0-316v-60h640v60H160Zm0-160v-60h640v60H160Z"
        })
    });
fi.displayName = "SvgViewHeadline";
var Pt = fi;
;
var qi = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M403 296h437v265H403V296Zm437 295v265H637V591h203Zm-437 0h204v265H403V591ZM120 856V296h253v560H120Z"
        })
    });
qi.displayName = "SvgViewQuilt";
var Mt = qi;
;
var ui = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M816 992 648 827q-35 14-79 21.5t-89 7.5q-146 0-265-81.5T40 556q20-52 55.5-101.5T182 360L56 234l42-43 757 757-39 44ZM480 726q14 0 30-2.5t27-7.5L320 499q-5 12-7.5 27t-2.5 30q0 72 50 121t120 49Zm278 40L629 637q10-16 15.5-37.5T650 556q0-71-49.5-120.5T480 386q-22 0-43 5t-38 16L289 296q35-16 89.5-28T485 256q143 0 261.5 81.5T920 556q-26 64-67 117t-95 93ZM585 593 443 451q29-11 60-4.5t54 28.5q23 23 32 51.5t-4 66.5Z"
        })
    });
ui.displayName = "SvgVisibilityOff";
var Ht = ui;
;
var bi = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M560 925v-62q97-28 158.5-107.5T780 575q0-101-61-181T560 287v-62q124 28 202 125.5T840 575q0 127-78 224.5T560 925ZM120 696V456h160l200-200v640L280 696H120Zm420 48V407q55 17 87.5 64T660 576q0 57-33 104t-87 64Z"
        })
    });
bi.displayName = "SvgVolumeUp";
var Lt = bi;
;
var Zi = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        viewBox: "0 96 960 960",
        width: e.width ?? e.size ?? "1em",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M280 816q-100 0-170-70T40 576q0-100 70-170t170-70q86 0 146.5 49T510 503h410v146H814v167H688V649H510q-23 69-83.5 118T280 816Zm0-172q29 0 48.5-19.5T348 576q0-29-19.5-48.5T280 508q-29 0-48.5 19.5T212 576q0 29 19.5 48.5T280 644Z"
        })
    });
_c92 = Zi;
Zi.displayName = "SvgVpnKey";
var Bt = Zi;
;
var Ai = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M2 42 24 4l22 38Zm22.2-5.85q.65 0 1.075-.425.425-.425.425-1.075 0-.65-.425-1.075-.425-.425-1.075-.425-.65 0-1.075.425Q22.7 34 22.7 34.65q0 .65.425 1.075.425.425 1.075.425Zm-1.5-5.55h3V19.4h-3Z"
        })
    });
_c93 = Ai;
Ai.displayName = "SvgWarning";
var Nt = Ai;
;
var Ti = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "M44.85 21.7q-4.4-4.2-9.625-6.7T24 12.5q-1.85 0-3.55.225-1.7.225-2.85.625L13.95 9.7q2.2-.8 4.775-1.25Q21.3 8 24 8q7 0 13.175 2.9Q43.35 13.8 48 18.55Zm-8.45 8.45q-1.65-1.6-3-2.575-1.35-.975-3.45-1.925L24.3 20q4.75.1 8.375 1.95Q36.3 23.8 39.55 27Zm3.85 14.4-19.7-19.7q-2.7.65-4.975 2.1-2.275 1.45-3.975 3.2L8.45 27q1.85-1.85 3.825-3.25T17 21.25l-5.55-5.55Q9.1 16.85 7 18.425 4.9 20 3.15 21.7L0 18.55q1.8-1.85 3.85-3.45t4.2-2.75l-4.6-4.6L5.6 5.6l36.8 36.8Zm-16.25-2-7.4-7.45q1.45-1.45 3.325-2.275Q21.8 32 24 32t4.075.825q1.875.825 3.325 2.275Z"
        })
    });
_c94 = Ti;
Ti.displayName = "SvgWifiOff";
var Et = Ti;
;
var Mi = (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: e.height ?? e.size ?? "1em",
        width: e.width ?? e.size ?? "1em",
        viewBox: "0 0 48 48",
        fill: "currentColor",
        style: e.style ? {
            verticalAlign: "middle",
            display: "inline-block",
            ...e.style
        } : {
            verticalAlign: "middle",
            display: "inline-block"
        },
        ...e,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
            d: "m29.6 41.4-6.95-6.95 6.95-6.95 2.1 2.15L28.35 33h6.55q1.75 0 2.925-1.275Q39 30.45 39 28.7t-1.175-3q-1.175-1.25-2.925-1.25H8v-3h26.9q3 0 5.05 2.125T42 28.7q0 3-2.05 5.15Q37.9 36 34.9 36h-6.55l3.35 3.25ZM8 36v-3h11.9v3Zm0-23v-3h32v3Z"
        })
    });
_c95 = Mi;
Mi.displayName = "SvgWrapText";
var It = Mi;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20, _c21, _c22, _c23, _c24, _c25, _c26, _c27, _c28, _c29, _c30, _c31, _c32, _c33, _c34, _c35, _c36, _c37, _c38, _c39, _c40, _c41, _c42, _c43, _c44, _c45, _c46, _c47, _c48, _c49, _c50, _c51, _c52, _c53, _c54, _c55, _c56, _c57, _c58, _c59, _c60, _c61, _c62, _c63, _c64, _c65, _c66, _c67, _c68, _c69, _c70, _c71, _c72, _c73, _c74, _c75, _c76, _c77, _c78, _c79, _c80, _c81, _c82, _c83, _c84, _c85, _c86, _c87, _c88, _c89, _c90, _c91, _c92, _c93, _c94, _c95;
__turbopack_context__.k.register(_c, "S");
__turbopack_context__.k.register(_c1, "V");
__turbopack_context__.k.register(_c2, "G");
__turbopack_context__.k.register(_c3, "C");
__turbopack_context__.k.register(_c4, "P");
__turbopack_context__.k.register(_c5, "H");
__turbopack_context__.k.register(_c6, "B");
__turbopack_context__.k.register(_c7, "E");
__turbopack_context__.k.register(_c8, "Q");
__turbopack_context__.k.register(_c9, "R");
__turbopack_context__.k.register(_c10, "D");
__turbopack_context__.k.register(_c11, "K");
__turbopack_context__.k.register(_c12, "Y");
__turbopack_context__.k.register(_c13, "J");
__turbopack_context__.k.register(_c14, "S1");
__turbopack_context__.k.register(_c15, "V1");
__turbopack_context__.k.register(_c16, "G1");
__turbopack_context__.k.register(_c17, "C1");
__turbopack_context__.k.register(_c18, "P1");
__turbopack_context__.k.register(_c19, "H1");
__turbopack_context__.k.register(_c20, "B1");
__turbopack_context__.k.register(_c21, "E1");
__turbopack_context__.k.register(_c22, "Q1");
__turbopack_context__.k.register(_c23, "R1");
__turbopack_context__.k.register(_c24, "D1");
__turbopack_context__.k.register(_c25, "K1");
__turbopack_context__.k.register(_c26, "Y1");
__turbopack_context__.k.register(_c27, "J1");
__turbopack_context__.k.register(_c28, "S2");
__turbopack_context__.k.register(_c29, "V2");
__turbopack_context__.k.register(_c30, "G2");
__turbopack_context__.k.register(_c31, "C2");
__turbopack_context__.k.register(_c32, "P2");
__turbopack_context__.k.register(_c33, "H2");
__turbopack_context__.k.register(_c34, "B2");
__turbopack_context__.k.register(_c35, "E2");
__turbopack_context__.k.register(_c36, "Q2");
__turbopack_context__.k.register(_c37, "R2");
__turbopack_context__.k.register(_c38, "D2");
__turbopack_context__.k.register(_c39, "K2");
__turbopack_context__.k.register(_c40, "Y2");
__turbopack_context__.k.register(_c41, "J2");
__turbopack_context__.k.register(_c42, "S0");
__turbopack_context__.k.register(_c43, "V0");
__turbopack_context__.k.register(_c44, "G0");
__turbopack_context__.k.register(_c45, "C0");
__turbopack_context__.k.register(_c46, "P0");
__turbopack_context__.k.register(_c47, "H0");
__turbopack_context__.k.register(_c48, "B0");
__turbopack_context__.k.register(_c49, "E0");
__turbopack_context__.k.register(_c50, "Q0");
__turbopack_context__.k.register(_c51, "F0");
__turbopack_context__.k.register(_c52, "O0");
__turbopack_context__.k.register(_c53, "U0");
__turbopack_context__.k.register(_c54, "W0");
__turbopack_context__.k.register(_c55, "X0");
__turbopack_context__.k.register(_c56, "Z5");
__turbopack_context__.k.register(_c57, "A5");
__turbopack_context__.k.register(_c58, "T5");
__turbopack_context__.k.register(_c59, "M5");
__turbopack_context__.k.register(_c60, "L5");
__turbopack_context__.k.register(_c61, "N5");
__turbopack_context__.k.register(_c62, "I5");
__turbopack_context__.k.register(_c63, "F5");
__turbopack_context__.k.register(_c64, "O5");
__turbopack_context__.k.register(_c65, "U5");
__turbopack_context__.k.register(_c66, "W5");
__turbopack_context__.k.register(_c67, "X5");
__turbopack_context__.k.register(_c68, "Ze");
__turbopack_context__.k.register(_c69, "Ae");
__turbopack_context__.k.register(_c70, "Te");
__turbopack_context__.k.register(_c71, "Me");
__turbopack_context__.k.register(_c72, "Le");
__turbopack_context__.k.register(_c73, "Ne");
__turbopack_context__.k.register(_c74, "Ie");
__turbopack_context__.k.register(_c75, "Fe");
__turbopack_context__.k.register(_c76, "Oe");
__turbopack_context__.k.register(_c77, "Ue");
__turbopack_context__.k.register(_c78, "We");
__turbopack_context__.k.register(_c79, "Xe");
__turbopack_context__.k.register(_c80, "Zl");
__turbopack_context__.k.register(_c81, "Al");
__turbopack_context__.k.register(_c82, "Tl");
__turbopack_context__.k.register(_c83, "Ml");
__turbopack_context__.k.register(_c84, "Ll");
__turbopack_context__.k.register(_c85, "Nl");
__turbopack_context__.k.register(_c86, "Il");
__turbopack_context__.k.register(_c87, "Fl");
__turbopack_context__.k.register(_c88, "Ol");
__turbopack_context__.k.register(_c89, "Ul");
__turbopack_context__.k.register(_c90, "Wl");
__turbopack_context__.k.register(_c91, "Xl");
__turbopack_context__.k.register(_c92, "Zi");
__turbopack_context__.k.register(_c93, "Ai");
__turbopack_context__.k.register(_c94, "Ti");
__turbopack_context__.k.register(_c95, "Mi");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/box.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "box",
    ()=>box,
    "getBoxStyle",
    ()=>getBoxStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const boxConfig = {
    transform (props) {
        return props;
    }
};
const getBoxStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(boxConfig, styles);
    return boxConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const box = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getBoxStyle(styles));
box.raw = getBoxStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/flex.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "flex",
    ()=>flex,
    "getFlexStyle",
    ()=>getFlexStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const flexConfig = {
    transform (props) {
        const { direction, align, justify, wrap: wrap2, basis, grow, shrink, ...rest } = props;
        return {
            display: "flex",
            flexDirection: direction,
            alignItems: align,
            justifyContent: justify,
            flexWrap: wrap2,
            flexBasis: basis,
            flexGrow: grow,
            flexShrink: shrink,
            ...rest
        };
    }
};
const getFlexStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(flexConfig, styles);
    return flexConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const flex = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getFlexStyle(styles));
flex.raw = getFlexStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/stack.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getStackStyle",
    ()=>getStackStyle,
    "stack",
    ()=>stack
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const stackConfig = {
    transform (props) {
        const { align, justify, direction, gap, ...rest } = props;
        return {
            display: "flex",
            flexDirection: direction,
            alignItems: align,
            justifyContent: justify,
            gap,
            ...rest
        };
    },
    defaultValues: {
        direction: 'column',
        gap: '8px'
    }
};
const getStackStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(stackConfig, styles);
    return stackConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const stack = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getStackStyle(styles));
stack.raw = getStackStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/vstack.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getVstackStyle",
    ()=>getVstackStyle,
    "vstack",
    ()=>vstack
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const vstackConfig = {
    transform (props) {
        const { justify, gap, ...rest } = props;
        return {
            display: "flex",
            alignItems: "center",
            justifyContent: justify,
            gap,
            flexDirection: "column",
            ...rest
        };
    },
    defaultValues: {
        gap: '8px'
    }
};
const getVstackStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(vstackConfig, styles);
    return vstackConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const vstack = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getVstackStyle(styles));
vstack.raw = getVstackStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/hstack.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getHstackStyle",
    ()=>getHstackStyle,
    "hstack",
    ()=>hstack
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const hstackConfig = {
    transform (props) {
        const { justify, gap, ...rest } = props;
        return {
            display: "flex",
            alignItems: "center",
            justifyContent: justify,
            gap,
            flexDirection: "row",
            ...rest
        };
    },
    defaultValues: {
        gap: '8px'
    }
};
const getHstackStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(hstackConfig, styles);
    return hstackConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const hstack = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getHstackStyle(styles));
hstack.raw = getHstackStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/spacer.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSpacerStyle",
    ()=>getSpacerStyle,
    "spacer",
    ()=>spacer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const spacerConfig = {
    transform (props, { map, isCssUnit, isCssVar }) {
        const { size, ...rest } = props;
        return {
            alignSelf: "stretch",
            justifySelf: "stretch",
            flex: map(size, (v)=>{
                if (v == null) return "1";
                const val = isCssUnit(v) || isCssVar(v) ? v : `token(spacing.${v}, ${v})`;
                return `0 0 ${val}`;
            }),
            ...rest
        };
    }
};
const getSpacerStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(spacerConfig, styles);
    return spacerConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const spacer = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getSpacerStyle(styles));
spacer.raw = getSpacerStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/square.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSquareStyle",
    ()=>getSquareStyle,
    "square",
    ()=>square
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const squareConfig = {
    transform (props) {
        const { size, ...rest } = props;
        return {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flex: "0 0 auto",
            width: size,
            height: size,
            ...rest
        };
    }
};
const getSquareStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(squareConfig, styles);
    return squareConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const square = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getSquareStyle(styles));
square.raw = getSquareStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/circle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "circle",
    ()=>circle,
    "getCircleStyle",
    ()=>getCircleStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const circleConfig = {
    transform (props) {
        const { size, ...rest } = props;
        return {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flex: "0 0 auto",
            width: size,
            height: size,
            borderRadius: "9999px",
            ...rest
        };
    }
};
const getCircleStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(circleConfig, styles);
    return circleConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const circle = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getCircleStyle(styles));
circle.raw = getCircleStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/center.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "center",
    ()=>center,
    "getCenterStyle",
    ()=>getCenterStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const centerConfig = {
    transform (props) {
        const { inline, ...rest } = props;
        return {
            display: inline ? "inline-flex" : "flex",
            alignItems: "center",
            justifyContent: "center",
            ...rest
        };
    }
};
const getCenterStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(centerConfig, styles);
    return centerConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const center = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getCenterStyle(styles));
center.raw = getCenterStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/link-overlay.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getLinkOverlayStyle",
    ()=>getLinkOverlayStyle,
    "linkOverlay",
    ()=>linkOverlay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const linkOverlayConfig = {
    transform (props) {
        return {
            _before: {
                content: '""',
                position: "absolute",
                inset: "0",
                zIndex: "0",
                ...props["_before"]
            },
            ...props
        };
    }
};
const getLinkOverlayStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(linkOverlayConfig, styles);
    return linkOverlayConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const linkOverlay = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getLinkOverlayStyle(styles));
linkOverlay.raw = getLinkOverlayStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/aspect-ratio.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "aspectRatio",
    ()=>aspectRatio,
    "getAspectRatioStyle",
    ()=>getAspectRatioStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const aspectRatioConfig = {
    transform (props, { map }) {
        const { ratio = 4 / 3, ...rest } = props;
        return {
            position: "relative",
            _before: {
                content: `""`,
                display: "block",
                height: "0",
                paddingBottom: map(ratio, (r)=>`${1 / r * 100}%`)
            },
            "&>*": {
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                overflow: "hidden",
                position: "absolute",
                inset: "0",
                width: "100%",
                height: "100%"
            },
            "&>img, &>video": {
                objectFit: "cover"
            },
            ...rest
        };
    }
};
const getAspectRatioStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(aspectRatioConfig, styles);
    return aspectRatioConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const aspectRatio = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getAspectRatioStyle(styles));
aspectRatio.raw = getAspectRatioStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/grid.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getGridStyle",
    ()=>getGridStyle,
    "grid",
    ()=>grid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const gridConfig = {
    transform (props, { map, isCssUnit }) {
        const { columnGap, rowGap, gap, columns, minChildWidth, ...rest } = props;
        const getValue = (v)=>isCssUnit(v) ? v : `token(sizes.${v}, ${v})`;
        return {
            display: "grid",
            gridTemplateColumns: columns != null ? map(columns, (v)=>`repeat(${v}, minmax(0, 1fr))`) : minChildWidth != null ? map(minChildWidth, (v)=>`repeat(auto-fit, minmax(${getValue(v)}, 1fr))`) : void 0,
            gap,
            columnGap,
            rowGap,
            ...rest
        };
    },
    defaultValues (props) {
        return {
            gap: props.columnGap || props.rowGap ? void 0 : "8px"
        };
    }
};
const getGridStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(gridConfig, styles);
    return gridConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const grid = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getGridStyle(styles));
grid.raw = getGridStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/grid-item.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getGridItemStyle",
    ()=>getGridItemStyle,
    "gridItem",
    ()=>gridItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const gridItemConfig = {
    transform (props, { map }) {
        const { colSpan, rowSpan, colStart, rowStart, colEnd, rowEnd, ...rest } = props;
        const spanFn = (v)=>v === "auto" ? v : `span ${v}`;
        return {
            gridColumn: colSpan != null ? map(colSpan, spanFn) : void 0,
            gridRow: rowSpan != null ? map(rowSpan, spanFn) : void 0,
            gridColumnStart: colStart,
            gridColumnEnd: colEnd,
            gridRowStart: rowStart,
            gridRowEnd: rowEnd,
            ...rest
        };
    }
};
const getGridItemStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(gridItemConfig, styles);
    return gridItemConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const gridItem = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getGridItemStyle(styles));
gridItem.raw = getGridItemStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/wrap.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getWrapStyle",
    ()=>getWrapStyle,
    "wrap",
    ()=>wrap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const wrapConfig = {
    transform (props) {
        const { columnGap, rowGap, gap = columnGap || rowGap ? void 0 : "8px", align, justify, ...rest } = props;
        return {
            display: "flex",
            flexWrap: "wrap",
            alignItems: align,
            justifyContent: justify,
            gap,
            columnGap,
            rowGap,
            ...rest
        };
    }
};
const getWrapStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(wrapConfig, styles);
    return wrapConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const wrap = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getWrapStyle(styles));
wrap.raw = getWrapStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/container.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "container",
    ()=>container,
    "getContainerStyle",
    ()=>getContainerStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const containerConfig = {
    transform (props) {
        return {
            position: "relative",
            maxWidth: "8xl",
            mx: "auto",
            px: {
                base: "4",
                md: "6",
                lg: "8"
            },
            ...props
        };
    }
};
const getContainerStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(containerConfig, styles);
    return containerConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const container = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getContainerStyle(styles));
container.raw = getContainerStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/divider.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "divider",
    ()=>divider,
    "getDividerStyle",
    ()=>getDividerStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const dividerConfig = {
    transform (props, { map }) {
        const { orientation, thickness, color, ...rest } = props;
        return {
            "--thickness": thickness,
            width: map(orientation, (v)=>v === "vertical" ? void 0 : "100%"),
            height: map(orientation, (v)=>v === "horizontal" ? void 0 : "100%"),
            borderBlockEndWidth: map(orientation, (v)=>v === "horizontal" ? "var(--thickness)" : void 0),
            borderInlineEndWidth: map(orientation, (v)=>v === "vertical" ? "var(--thickness)" : void 0),
            borderColor: color,
            ...rest
        };
    },
    defaultValues: {
        orientation: 'horizontal',
        thickness: '1px'
    }
};
const getDividerStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(dividerConfig, styles);
    return dividerConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const divider = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getDividerStyle(styles));
divider.raw = getDividerStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/float.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "float",
    ()=>float,
    "getFloatStyle",
    ()=>getFloatStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const floatConfig = {
    transform (props, { map }) {
        const { offset, offsetX, offsetY, placement, ...rest } = props;
        return {
            display: "inline-flex",
            justifyContent: "center",
            alignItems: "center",
            position: "absolute",
            insetBlockStart: map(placement, (v)=>{
                const [side] = v.split("-");
                const map2 = {
                    top: offsetY,
                    middle: "50%",
                    bottom: "auto"
                };
                return map2[side];
            }),
            insetBlockEnd: map(placement, (v)=>{
                const [side] = v.split("-");
                const map2 = {
                    top: "auto",
                    middle: "50%",
                    bottom: offsetY
                };
                return map2[side];
            }),
            insetInlineStart: map(placement, (v)=>{
                const [, align] = v.split("-");
                const map2 = {
                    start: offsetX,
                    center: "50%",
                    end: "auto"
                };
                return map2[align];
            }),
            insetInlineEnd: map(placement, (v)=>{
                const [, align] = v.split("-");
                const map2 = {
                    start: "auto",
                    center: "50%",
                    end: offsetX
                };
                return map2[align];
            }),
            translate: map(placement, (v)=>{
                const [side, align] = v.split("-");
                const mapX = {
                    start: "-50%",
                    center: "-50%",
                    end: "50%"
                };
                const mapY = {
                    top: "-50%",
                    middle: "-50%",
                    bottom: "50%"
                };
                return `${mapX[align]} ${mapY[side]}`;
            }),
            ...rest
        };
    },
    defaultValues (props) {
        const offset = props.offset || "0";
        return {
            offset,
            offsetX: offset,
            offsetY: offset,
            placement: "top-end"
        };
    }
};
const getFloatStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(floatConfig, styles);
    return floatConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const float = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getFloatStyle(styles));
float.raw = getFloatStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/bleed.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bleed",
    ()=>bleed,
    "getBleedStyle",
    ()=>getBleedStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const bleedConfig = {
    transform (props, { map, isCssUnit, isCssVar }) {
        const { inline, block, ...rest } = props;
        const valueFn = (v)=>isCssUnit(v) || isCssVar(v) ? v : `token(spacing.${v}, ${v})`;
        return {
            "--bleed-x": map(inline, valueFn),
            "--bleed-y": map(block, valueFn),
            marginInline: "calc(var(--bleed-x, 0) * -1)",
            marginBlock: "calc(var(--bleed-y, 0) * -1)",
            ...rest
        };
    },
    defaultValues: {
        inline: '0',
        block: '0'
    }
};
const getBleedStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(bleedConfig, styles);
    return bleedConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const bleed = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getBleedStyle(styles));
bleed.raw = getBleedStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/visually-hidden.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getVisuallyHiddenStyle",
    ()=>getVisuallyHiddenStyle,
    "visuallyHidden",
    ()=>visuallyHidden
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const visuallyHiddenConfig = {
    transform (props) {
        return {
            srOnly: true,
            ...props
        };
    }
};
const getVisuallyHiddenStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(visuallyHiddenConfig, styles);
    return visuallyHiddenConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const visuallyHidden = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getVisuallyHiddenStyle(styles));
visuallyHidden.raw = getVisuallyHiddenStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/cq.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cq",
    ()=>cq,
    "getCqStyle",
    ()=>getCqStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const cqConfig = {
    transform (props) {
        const { name, type, ...rest } = props;
        return {
            containerType: type,
            containerName: name,
            ...rest
        };
    },
    defaultValues: {
        type: 'inline-size'
    }
};
const getCqStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(cqConfig, styles);
    return cqConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const cq = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getCqStyle(styles));
cq.raw = getCqStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/index.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$flex$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/flex.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$stack$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/stack.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$vstack$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/vstack.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$hstack$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/hstack.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$spacer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/spacer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$square$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/square.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/circle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$center$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/center.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$link$2d$overlay$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/link-overlay.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$aspect$2d$ratio$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/aspect-ratio.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$grid$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/grid.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$grid$2d$item$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/grid-item.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$wrap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/wrap.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$container$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/container.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$divider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/divider.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$float$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/float.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$bleed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/bleed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$visually$2d$hidden$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/visually-hidden.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$cq$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/cq.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/logo.json.[json].cjs [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = {
    "BRAND_MARK_PATH": "M115.667 115.595L95.393 72.228c-15.316.61-28.904-2.242-28.904-2.242V67.81c24.692-4.344 47.487-12.462 47.487-34.28C113.977 5.92 88.8.136 59.822.007L59.816 0H0v4.7l11.6 6.24 2.26 4.6v95.456l-2.26 4.6L0 121.832v4.702h62.816v-4.702l-11.598-6.238-2.44-4.6V80.77l10.07-8.575 22.035 54.34h46.38v-4.702l-11.596-6.238zM62.3 7.325c8.183 1.527 14.355 8.964 14.355 27.578 0 21.176-8.317 27.912-21.95 27.912h-5.928V17.07L62.3 7.325z",
    "BRAND_MARK_VIEWBOX": "0 0 127.264 127.264",
    "LOGO_PATH": "M721.463 133.73v-4.7l11.6-6.24 2.26-4.6V22.735l-2.26-4.6-11.6-6.238v-4.7h62.818v4.7l-11.6 6.238-2.438 4.6v95.457l2.44 4.6 11.6 6.24v4.7h-62.82zM424.22 136.78c34.81 0 46.53-20.452 46.53-46.696V26.59l2.438-4.6 17.783-10.094v-4.7h-51.005v4.7l17.963 10.095 2.26 4.6v63.132c0 23.71-10.033 34.027-25.08 34.027-15.55 0-24.078-11.403-24.078-34.753l.002-66.262 2.44-4.6 11.6-6.24v-4.7h-62.82v4.7l11.6 6.24 2.26 4.6V89.54c0 33.305 18.02 47.24 48.107 47.24zM715.02 87.195l-28.378 36.894h-23.156V22.733l2.442-4.6 11.597-6.24v-4.7H614.71v4.7l11.6 6.24 2.258 4.6v95.457l-2.26 4.6-11.6 6.24v4.7h98.6l6.415-46.535M309.033 7.208l-.012-.013h-59.817v4.7l11.6 6.238 2.26 4.6v95.458l-2.26 4.6-11.6 6.24v4.7h62.817v-4.7l-11.6-6.24-2.44-4.6V86.456l5.496-4.836 19.513 7.26c21.39-2.392 40.19-19.536 40.19-39.93 0-28.612-22.613-41.47-54.147-41.742zm-3.012 68.08h-8.04V24.324l13.608-9.857c8.34 2.882 14.27 11.627 14.27 29.56 0 22.694-11.044 31.263-19.837 31.263zM233.688 87.193l-28.71 36.896h-26.224V73.983h11.035l4.4 3.65 10.2 16.22h5v-49.2h-5l-10.2 16.22-4.4 3.65h-11.036V25.97l12.73-9.136h12.03l28.024 34.896h4.983L229.19 0h-5.213l-5.788 7.195h-88.214v4.7l11.6 6.24 2.26 4.6v95.456l-2.26 4.6-10.184 6.24v4.7h100.163l7.117-46.537M913.52 122.79L875.7 50.81l34.8-34.314 9.282-4.6v-4.7H874.5v30.59l-24.884 24.382h-6.826V22.732l2.44-4.6 11.6-6.24v-4.7H794.01v4.7l11.6 6.24 2.26 4.6v95.46l-2.26 4.6-11.6 6.237v4.7h62.817v-4.7l-11.6-6.24-2.44-4.6V83.26l5.61-5.534 30.407 56.004h46.31v-4.7M115.67 122.79L95.395 79.423c-15.315.61-28.903-2.24-28.903-2.24V75c24.693-4.342 47.487-12.46 47.487-34.276 0-27.613-25.178-33.396-54.154-33.525l-.006-.005H.003v4.7l11.6 6.24 2.26 4.6v95.456l-2.26 4.6-11.6 6.24v4.7H62.82v-4.7l-11.6-6.24-2.44-4.6V87.965l10.07-8.575 22.035 54.34h46.382v-4.7l-11.598-6.24zM62.302 14.52c8.184 1.527 14.354 8.963 14.354 27.578 0 21.176-8.315 27.912-21.948 27.912h-5.93V24.266l13.523-9.747zM568.615 69.232v-2.136c22.137-4.47 36.877-13.75 36.877-30.26 0-18.82-16.657-29.642-45.396-29.642h-66.903v4.7l11.6 6.24 2.26 4.6v95.456l-2.26 4.6-11.6 6.24v4.7h68.4c26.272-.708 47.42-10.087 47.42-33.62 0-21.525-17.542-28.874-40.398-30.878zM555.74 14.34c7.565 2.452 13.404 9.734 13.404 25.316 0 19.984-8.392 26.342-21.886 26.342h-5.288V24.266l13.77-9.927zm-7.75 109.75h-6.02V83.983l14.292-10.232c10.236 2.52 16.403 9.83 16.403 25.322 0 20.04-9.634 25.015-24.676 25.015z",
    "LOGO_VIEWBOX": "0 0 925.115 136.781",
    "LOGO_GRADIENT": ""
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/layout/header/logo.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Logo",
    ()=>Logo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$logo$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/logo.json.[json].cjs [app-client] (ecmascript)");
;
;
;
const Logo = ({ inverted })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$logo$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].LOGO_VIEWBOX,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            width: 'full',
            fill: 'text',
            height: 'header.logoHeight'
        }),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$logo$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].LOGO_PATH
        }, void 0, false, {
            fileName: "[project]/apps/www/src/app/components/layout/header/logo.tsx",
            lineNumber: 14,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/components/layout/header/logo.tsx",
        lineNumber: 6,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Logo;
var _c;
__turbopack_context__.k.register(_c, "Logo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/layout/header/nav-link.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NavLink",
    ()=>NavLink
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function NavLink({ href, children }) {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: href,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            textDecoration: 'none',
            color: 'text',
            fontSize: 's',
            lineHeight: 'pageNav',
            px: {
                base: '2.5',
                md: '3.5'
            },
            _hover: {
                textDecoration: 'underline'
            },
            '&[aria-current="page"]': {
                fontWeight: 500
            }
        }),
        "aria-current": href === pathname ? 'page' : undefined,
        children: children
    }, href, false, {
        fileName: "[project]/apps/www/src/app/components/layout/header/nav-link.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
_s(NavLink, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = NavLink;
var _c;
__turbopack_context__.k.register(_c, "NavLink");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/layout/header/index.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PageHeader",
    ()=>PageHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useScrollDirection$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/lib/hooks/useScrollDirection.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/icons/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$hstack$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/hstack.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$layout$2f$header$2f$logo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/layout/header/logo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$layout$2f$header$2f$nav$2d$link$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/layout/header/nav-link.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
const getInitials = (name, email)=>(name && name.trim() ? name.split(' ').filter((n, i, all)=>i === 0 || all.length - 1 === i) : email.split('@')[0].split(/\.|-|_/).slice(0, 2)).slice(0, 2).filter(Boolean).map((s)=>s[0]).join('').toUpperCase();
const Avatar = ({ portrait, name, email })=>{
    const style = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        position: 'relative',
        display: 'inline-block',
        width: 'header.avatar',
        height: 'header.avatar',
        objectFit: 'cover',
        color: 'text'
    });
    return portrait ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        src: portrait,
        height: 32,
        width: 32,
        className: style,
        alt: "Portrait"
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: style,
        children: getInitials(name, email)
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Avatar;
const MAX_HEADER_HEIGHT = 100;
function PageHeader({ isLoggedIn, hasActiveMembership, portrait }) {
    _s();
    const headerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const scrollDirection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useScrollDirection$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollDirection"])({
        upThreshold: 25,
        downThreshold: MAX_HEADER_HEIGHT
    });
    const navLinks = [
        {
            href: '/',
            label: 'Magazin'
        },
        {
            href: '/feed',
            label: 'Feed'
        },
        {
            href: '/dialog',
            label: 'Dialog'
        },
        {
            href: '/suche',
            label: 'Suche',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconSearchMenu"], {
                size: 18
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                lineNumber: 78,
                columnNumber: 45
            }, this)
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: headerRef,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            bg: 'pageBackground',
            position: 'sticky',
            top: 0,
            transition: 'transform 0.3s ease-out',
            zIndex: 100
        }),
        style: {
            transform: `translateY(${scrollDirection === 'down' ? -(MAX_HEADER_HEIGHT - 1) : 0}px)`
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                }),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                            p: 'header.avatarMargin',
                            md: {
                                width: '100%'
                            }
                        }),
                        children: isLoggedIn ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/meine-republik",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Avatar, {
                                ...portrait
                            }, void 0, false, {
                                fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                                lineNumber: 109,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                            lineNumber: 108,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/anmelden",
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                                display: 'flex',
                                flexDirection: 'row',
                                alignItems: 'center',
                                textDecoration: 'none',
                                gap: '5px',
                                color: 'text'
                            }),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconAccountBox"], {
                                    "aria-label": "Anmelden",
                                    size: 32
                                }, void 0, false, {
                                    fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                                    lineNumber: 123,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                                        display: 'none',
                                        md: {
                                            display: 'inline-block'
                                        }
                                    }),
                                    children: "Anmelden"
                                }, void 0, false, {
                                    fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                                    lineNumber: 124,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                            lineNumber: 112,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                        lineNumber: 104,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                            m: 'header.logoMargin',
                            md: {
                                width: '100%'
                            }
                        }),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$layout$2f$header$2f$logo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Logo"], {}, void 0, false, {
                                fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                                lineNumber: 139,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                            lineNumber: 138,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                        lineNumber: 137,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                            alignSelf: 'stretch',
                            md: {
                                width: '100%'
                            },
                            display: 'flex',
                            flexDirection: 'row',
                            justifyContent: 'flex-end'
                        }),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                                width: 'header.avatar',
                                height: 'header.avatar',
                                m: 'header.avatarMargin',
                                display: 'flex',
                                placeContent: 'center center'
                            }),
                            children: hasActiveMembership ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                disabled: true,
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                                    p: '0'
                                }),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconMic"], {
                                    size: 28
                                }, void 0, false, {
                                    fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                                    lineNumber: 163,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                                lineNumber: 162,
                                columnNumber: 17
                            }, this) : null
                        }, void 0, false, {
                            fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                            lineNumber: 151,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                        lineNumber: 142,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                lineNumber: 97,
                columnNumber: 7
            }, this),
            hasActiveMembership ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$hstack$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hstack"])({
                    gap: '0',
                    justifyContent: 'center',
                    borderTop: '1px solid',
                    borderTopColor: 'divider'
                }),
                children: navLinks.map(({ href, label, icon })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$layout$2f$header$2f$nav$2d$link$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavLink"], {
                        href: href,
                        children: icon || label
                    }, href, false, {
                        fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                        lineNumber: 223,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                lineNumber: 214,
                columnNumber: 9
            }, this) : null,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    left: 0,
                    right: 0,
                    height: '3px',
                    color: 'divider',
                    backgroundColor: 'var(--page-theme-accent-color)',
                    borderTopColor: 'var(--page-theme-accent-color)',
                    borderTopWidth: 1,
                    borderTopStyle: 'solid'
                })
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
                lineNumber: 229,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/components/layout/header/index.tsx",
        lineNumber: 82,
        columnNumber: 5
    }, this);
}
_s(PageHeader, "y59Q43WzIkVTw5H0fP2GFUW7cTM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useScrollDirection$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useScrollDirection"]
    ];
});
_c1 = PageHeader;
var _c, _c1;
__turbopack_context__.k.register(_c, "Avatar");
__turbopack_context__.k.register(_c1, "PageHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/layout/header/draft-mode-indicator.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DraftModeIndicator",
    ()=>DraftModeIndicator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const DraftModeIndicator = ()=>{
    _s();
    const { refresh } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            p: '2',
            backgroundColor: '#ffbc50',
            color: '#000',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            gap: '2'
        }),
        children: [
            "Entwurfs-Vorschau",
            ' ',
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    py: '1',
                    px: '3',
                    borderRadius: 'full',
                    backgroundColor: '#000',
                    fontSize: 's',
                    color: '#ffbc50',
                    cursor: 'pointer'
                }),
                onClick: ()=>{
                    fetch('/api/draft/disable').then(()=>refresh());
                },
                children: "Ausschalten"
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/layout/header/draft-mode-indicator.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/components/layout/header/draft-mode-indicator.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(DraftModeIndicator, "sxTeP7hZ54jUyUtzFY7msT1uY2o=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = DraftModeIndicator;
var _c;
__turbopack_context__.k.register(_c, "DraftModeIndicator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/cta-banner/basic-banner.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CTABasicBanner",
    ()=>CTABasicBanner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/icons/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
'use client';
;
;
;
;
function CTABasicBanner({ id, payload, handleAcknowledge }) {
    const { text, linkHref, linkLabel } = payload;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            backgroundColor: 'text',
            color: 'pageBackground'
        }),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                display: 'flex',
                flexDirection: 'row',
                alignItems: 'flexStart',
                gap: '1rem',
                margin: '0 auto',
                maxWidth: '60ch',
                padding: '2rem 1rem'
            }),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                        flexGrow: 1,
                        '& > p': {
                            margin: 0,
                            marginBottom: '0.5em'
                        },
                        '& > a': {
                            color: 'pageBackground',
                            textDecoration: 'underline'
                        }
                    }),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: text
                        }, void 0, false, {
                            fileName: "[project]/apps/www/src/app/components/cta-banner/basic-banner.tsx",
                            lineNumber: 54,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: linkHref,
                            onClick: ()=>handleAcknowledge(id),
                            children: linkLabel
                        }, void 0, false, {
                            fileName: "[project]/apps/www/src/app/components/cta-banner/basic-banner.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/www/src/app/components/cta-banner/basic-banner.tsx",
                    lineNumber: 41,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                        height: '2rem',
                        width: '2rem',
                        cursor: 'pointer'
                    }),
                    onClick: ()=>handleAcknowledge(id),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconClose"], {
                        size: "1.5rem",
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                            fill: 'pageBackground'
                        })
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/components/cta-banner/basic-banner.tsx",
                        lineNumber: 67,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/components/cta-banner/basic-banner.tsx",
                    lineNumber: 59,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/www/src/app/components/cta-banner/basic-banner.tsx",
            lineNumber: 30,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/components/cta-banner/basic-banner.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
}
_c = CTABasicBanner;
var _c;
__turbopack_context__.k.register(_c, "CTABasicBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/cta-banner/cta-renderer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CTARenderer",
    ()=>CTARenderer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hooks/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$cta$2d$banner$2f$basic$2d$banner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/cta-banner/basic-banner.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/graphql/republik-api/__generated__/gql/graphql.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function CTARenderer({ cta }) {
    _s();
    const [acknowledged, setAcknowledged] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [acknowledge] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AcknowledgeCtaDocument"]);
    async function acknowledgeCTA() {
        setAcknowledged(true);
        await acknowledge({
            variables: {
                id: cta.id,
                response: undefined
            }
        });
    }
    if (acknowledged) {
        return null;
    }
    if (cta.payload.__typename === 'CallToActionBasicPayload') {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$cta$2d$banner$2f$basic$2d$banner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CTABasicBanner"], {
            id: cta.id,
            payload: cta.payload,
            handleAcknowledge: ()=>acknowledgeCTA()
        }, void 0, false, {
            fileName: "[project]/apps/www/src/app/components/cta-banner/cta-renderer.tsx",
            lineNumber: 35,
            columnNumber: 7
        }, this);
    }
    console.log("Can't render CTA of type ", cta.payload.__typename);
    return null;
}
_s(CTARenderer, "qutbr2s2+e+egZDHn6F/JfR/hdg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
_c = CTARenderer;
var _c;
__turbopack_context__.k.register(_c, "CTARenderer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/lightswitch.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LightSwitch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/icons/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-themes/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function LightSwitch() {
    _s();
    const { theme, setTheme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"])();
    const [currentTheme, setCurrentTheme] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LightSwitch.useEffect": ()=>{
            setCurrentTheme(theme);
        }
    }["LightSwitch.useEffect"], [
        theme,
        setCurrentTheme
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            color: 'textSoft',
            transition: 'all 0.2s ease',
            backgroundColor: 'transparent',
            maxWidth: 'max-content',
            '&:hover': {
                borderRadius: '9999px',
                backgroundColor: 'rgba(255,255,255,0.05)'
            }
        }),
        role: "radiogroup",
        children: [
            {
                Icon: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconComputer"],
                theme: 'system'
            },
            {
                Icon: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconLightMode"],
                theme: 'light'
            },
            {
                Icon: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconDarkMode"],
                theme: 'dark'
            }
        ].map(({ theme, Icon })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setTheme(theme),
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: '2',
                    borderRadius: '9999px',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    backgroundColor: 'transparent',
                    '&:hover': {
                        color: 'text',
                        backgroundColor: 'rgba(255,255,255,0.2)'
                    },
                    '&[aria-checked="true"]': {
                        color: 'text'
                    }
                }),
                role: "radio",
                "aria-checked": currentTheme === theme,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {}, void 0, false, {
                    fileName: "[project]/apps/www/src/app/components/lightswitch.tsx",
                    lineNumber: 70,
                    columnNumber: 11
                }, this)
            }, theme, false, {
                fileName: "[project]/apps/www/src/app/components/lightswitch.tsx",
                lineNumber: 47,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/components/lightswitch.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_s(LightSwitch, "g4rnxfrTkHzWju/tVohjXFbDjDc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
    ];
});
_c = LightSwitch;
var _c;
__turbopack_context__.k.register(_c, "LightSwitch");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/hooks/use-persisted-state/createGlobalState.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const globalState = {};
const createGlobalState = (key, thisCallback, initialValue)=>{
    if (!globalState[key]) {
        globalState[key] = {
            callbacks: [],
            value: initialValue
        };
    }
    globalState[key].callbacks.push(thisCallback);
    return {
        deregister () {
            const arr = globalState[key].callbacks;
            const index = arr.indexOf(thisCallback);
            if (index > -1) {
                arr.splice(index, 1);
            }
        },
        emit (value) {
            if (globalState[key].value !== value) {
                globalState[key].value = value;
                globalState[key].callbacks.forEach((callback)=>{
                    if (thisCallback !== callback) {
                        callback(value);
                    }
                });
            }
        }
    };
};
const __TURBOPACK__default__export__ = createGlobalState;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/hooks/use-persisted-state/usePersistedState.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$use$2d$it$2f$event$2d$listener$2f$dist$2f$event$2d$listener$2e$m$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@use-it/event-listener/dist/event-listener.m.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$hooks$2f$use$2d$persisted$2d$state$2f$createGlobalState$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/hooks/use-persisted-state/createGlobalState.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
const usePersistedState = (initialState, key, { get, set })=>{
    _s();
    const globalState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const storageEventValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [persisted, setPersisted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "usePersistedState.useState": ()=>{
            let state;
            try {
                state = get(key, initialState);
            } catch (e) {
                state = initialState;
                setPersisted(false);
            }
            return state;
        }
    }["usePersistedState.useState"]);
    // subscribe to `storage` change events
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$use$2d$it$2f$event$2d$listener$2f$dist$2f$event$2d$listener$2e$m$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('storage', {
        "usePersistedState.useEventListener": ({ key: k, newValue })=>{
            if (k === key) {
                const newState = newValue === null ? initialState : JSON.parse(newValue);
                if (state !== newState) {
                    storageEventValue.current = newState;
                    setState(newState);
                }
            }
        }
    }["usePersistedState.useEventListener"]);
    // only called on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePersistedState.useEffect": ()=>{
            // register a listener that calls `setState` when another instance emits
            globalState.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$hooks$2f$use$2d$persisted$2d$state$2f$createGlobalState$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(key, setState, initialState);
            return ({
                "usePersistedState.useEffect": ()=>{
                    globalState.current.deregister();
                }
            })["usePersistedState.useEffect"];
        }
    }["usePersistedState.useEffect"], []);
    // Only persist to storage if state changes.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePersistedState.useEffect": ()=>{
            // do not write data recieved from storage event
            if (state !== null && storageEventValue.current === state) {
                return;
            }
            // persist to localStorage
            try {
                set(key, state);
            } catch (e) {
                setPersisted(false);
            }
            // inform all of the other instances in this tab
            globalState.current.emit(state);
        }
    }["usePersistedState.useEffect"], [
        state
    ]);
    return [
        state,
        setState,
        persisted
    ];
};
_s(usePersistedState, "NKNUeRpXX5YWrVk5/6+YVRae2zg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$use$2d$it$2f$event$2d$listener$2f$dist$2f$event$2d$listener$2e$m$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
const __TURBOPACK__default__export__ = usePersistedState;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/hooks/use-persisted-state/createStorage.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/**
 * Create a storage provider that can be used to persist state across sessions.
 */ function createStorage(provider) {
    return {
        // todo: ensure t can be a both a fixed default value or a Supplier<T>
        get (key, defaultValue) {
            const json = provider.getItem(key);
            if (json) {
                return JSON.parse(json);
            }
            return typeof defaultValue === 'function' ? defaultValue() // typescript fix to prevent not callable typescript error
             : defaultValue;
        },
        set (key, value) {
            if (value === undefined) {
                provider.removeItem(key);
            } else {
                provider.setItem(key, JSON.stringify(value));
            }
        }
    };
}
const __TURBOPACK__default__export__ = createStorage;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/hooks/use-persisted-state/index.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$hooks$2f$use$2d$persisted$2d$state$2f$usePersistedState$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/hooks/use-persisted-state/usePersistedState.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$hooks$2f$use$2d$persisted$2d$state$2f$createStorage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/hooks/use-persisted-state/createStorage.ts [app-client] (ecmascript)");
;
;
;
const createPersistedState = (key, customProvider)=>{
    let provider = customProvider;
    if (customProvider === undefined) {
        try {
            provider = /*TURBOPACK member replacement*/ __turbopack_context__.g.localStorage;
        } catch (e) {}
    }
    if (provider) {
        var _s = __turbopack_context__.k.signature();
        const storage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$hooks$2f$use$2d$persisted$2d$state$2f$createStorage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(provider);
        return _s((initialState)=>{
            _s();
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$hooks$2f$use$2d$persisted$2d$state$2f$usePersistedState$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(initialState, key, storage);
        }, "yrCtgCB4ASLACCmBhXOsE1pXsI8=", false, function() {
            return [
                __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$hooks$2f$use$2d$persisted$2d$state$2f$usePersistedState$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
            ];
        });
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"];
};
const __TURBOPACK__default__export__ = createPersistedState;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/context/UserAgentContext.tsx [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useUserAgent",
    ()=>useUserAgent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/parse-useragent.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
const UserAgentContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const useUserAgent = ()=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(UserAgentContext);
};
_s(useUserAgent, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
const UserAgentProvider = ({ children, providedValue })=>{
    _s1();
    const [userAgent, setUserAgent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(providedValue);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "UserAgentProvider.useEffect": ()=>{
            setUserAgent(navigator.userAgent);
        }
    }["UserAgentProvider.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(UserAgentContext.Provider, {
        value: {
            userAgent,
            isIOS: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchIOSUserAgent"])(userAgent),
            isAndroid: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchAndroidUserAgent"])(userAgent),
            isFirefox: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchFirefoxUserAgent"])(userAgent),
            isSearchBot: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchSearchBotUserAgent"])(userAgent)
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/apps/www/src/lib/context/UserAgentContext.tsx",
        lineNumber: 42,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s1(UserAgentProvider, "PjixeP/sW7phN343MM+7LhEEpXw=");
_c = UserAgentProvider;
const __TURBOPACK__default__export__ = UserAgentProvider;
var _c;
__turbopack_context__.k.register(_c, "UserAgentProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/safeJSON.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parseJSONObject",
    ()=>parseJSONObject
]);
const parseJSONObject = (json)=>{
    let object;
    try {
        object = JSON.parse(json);
    } catch (error) {}
    // handle null and undefined
    // - remember that typeof null === 'object'
    if (!object) {
        object = {};
    }
    return object;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/withInNativeApp.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NativeAppHelpers",
    ()=>NativeAppHelpers,
    "default",
    ()=>__TURBOPACK__default__export__,
    "inNativeAppBrowser",
    ()=>inNativeAppBrowser,
    "inNativeAppBrowserAppVersion",
    ()=>inNativeAppBrowserAppVersion,
    "inNativeAppBrowserLegacy",
    ()=>inNativeAppBrowserLegacy,
    "inNativeIOSAppBrowser",
    ()=>inNativeIOSAppBrowser,
    "postMessage",
    ()=>postMessage,
    "useInNativeApp",
    ()=>useInNativeApp
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/router.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$UserAgentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/apps/www/src/lib/context/UserAgentContext.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/parse-useragent.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$safeJSON$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/safeJSON.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
const inNativeAppBrowserAppVersion = ("TURBOPACK compile-time truthy", 1) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNativeAppVersion"])(navigator.userAgent) : "TURBOPACK unreachable";
const isLegacyApp = (version)=>parseFloat(version) < 2;
const isNewerVersion = (oldVer, newVer)=>{
    if (!oldVer || !newVer) return true;
    const oldParts = oldVer.split('.');
    const newParts = newVer.split('.');
    for(var i = 0; i < newParts.length; i++){
        const a = ~~newParts[i] // parse int
        ;
        const b = ~~oldParts[i] // parse int
        ;
        if (a > b) return true;
        if (a < b) return false;
    }
    // if versions are equal, the loop above never returns
    // so we return true. equals to "same version or above"
    return true;
};
const inNativeAppBrowserLegacy = isLegacyApp(inNativeAppBrowserAppVersion);
const inNativeAppBrowser = !!inNativeAppBrowserAppVersion;
const inNativeIOSAppBrowser = inNativeAppBrowser && (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchIOSUserAgent"])(navigator.userAgent);
const runInNativeAppBrowser = inNativeAppBrowser ? (callback)=>callback() : ()=>{};
runInNativeAppBrowser(()=>{
    if (!inNativeAppBrowserLegacy) {
        return;
    }
    const orgUrl = window.location.pathname + window.location.search + window.location.hash;
    const orgTime = Date.now();
    // Accept push-route and scroll-to-top from app
    document.addEventListener('message', function(event) {
        const message = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$safeJSON$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseJSONObject"])(event.data);
        if (message.type === 'scroll-to-top') {
            window.scrollTo(0, 0);
        } else if (message.type === 'push-route') {
            // ignore push back loop from app
            // - while booting the app a bunch of race conditions lead to a loop
            // example
            // - save url on fs /feed
            // - app start loading webview with /feed
            // - deep services sets new url /rubriken
            // - app sends push-route /rubriken
            // - webview finishes loading, report /feed is now the url
            // - app saves /feed as url again
            // - app sends push-route /feed again <- this one we want to ignore
            if (message.url === orgUrl && Date.now() - orgTime < 10000) {
                return;
            }
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].push(message.url).then(()=>{
                window.scrollTo(0, 0);
            });
        }
    });
    // Monkey patch window.postMessage to fix native app webview issues
    // Ref: https://github.com/facebook/react-native/issues/11594
    let isReactNativePostMessageReady = !!window.originalPostMessage;
    const queue = [];
    let currentPostMessageFn = (message)=>{
        queue.push(message);
    };
    if (!isReactNativePostMessageReady) {
        Object.defineProperty(window, 'postMessage', {
            configurable: true,
            enumerable: true,
            get () {
                return currentPostMessageFn;
            },
            set (fn) {
                currentPostMessageFn = fn;
                isReactNativePostMessageReady = true;
                setTimeout(sendQueue, 0);
            }
        });
    }
    function sendQueue() {
        while(queue.length > 0)window.postMessage(queue.shift());
    }
});
const postMessage = !inNativeAppBrowser ? ()=>{} // does nothing outside of app, e.g. gallery full screen message
 : inNativeAppBrowserLegacy ? (msg)=>window.postMessage(typeof msg === 'string' ? msg : JSON.stringify(msg), '*') : window.ReactNativeWebView && window.ReactNativeWebView.postMessage ? (msg)=>window.ReactNativeWebView.postMessage(typeof msg === 'string' ? msg : JSON.stringify(msg)) : (msg)=>console.warn('postMessage unavailable', msg);
const getIOSVersion = (userAgent)=>{
    const matches = userAgent.match(/ OS ([\d_]+) /);
    return matches ? parseFloat(matches[1]) : undefined;
};
const NativeAppHelpers = {
    getNativeAppVersion: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNativeAppVersion"],
    getIOSVersion,
    isNewerVersion
};
const useInNativeApp = ()=>{
    _s();
    const { userAgent, isIOS, isAndroid } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$UserAgentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useUserAgent"])() ?? {};
    const inNativeAppVersion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNativeAppVersion"])(userAgent);
    const inNativeAppBuildId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNativeAppBuildId"])(userAgent);
    const inNativeApp = !!inNativeAppVersion;
    return {
        inNativeApp,
        inNativeAppLegacy: isLegacyApp(inNativeAppVersion),
        inNativeAppVersion,
        inNativeAppBuildId,
        isMinimalNativeAppVersion: (minVersion)=>isNewerVersion(minVersion, inNativeAppVersion),
        inIOS: isIOS,
        isAndroid: isAndroid,
        inIOSVersion: isIOS ? getIOSVersion(userAgent) : undefined,
        inNativeIOSApp: inNativeApp && isIOS,
        inNativeAndroidApp: inNativeApp && isAndroid
    };
};
_s(useInNativeApp, "ue/oZivxnHhvmsmfnHwvjujF2zg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$UserAgentContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useUserAgent"]
    ];
});
const withInNativeApp = (WrappedComponent)=>{
    var _s = __turbopack_context__.k.signature();
    const WithInNativeApp = (props)=>{
        _s();
        const inProps = useInNativeApp();
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WrappedComponent, {
            ...inProps,
            ...props
        }, void 0, false, {
            fileName: "[project]/apps/www/src/lib/withInNativeApp.js",
            lineNumber: 156,
            columnNumber: 12
        }, ("TURBOPACK compile-time value", void 0));
    };
    _s(WithInNativeApp, "tR8Wpllreb1JCkNSGVW3l3E6oDg=", false, function() {
        return [
            useInNativeApp
        ];
    });
    return WithInNativeApp;
};
const __TURBOPACK__default__export__ = withInNativeApp;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/helpers/AbstractApolloGQLHooks.helper.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "makeLazyQueryHook",
    ()=>makeLazyQueryHook,
    "makeMutationHook",
    ()=>makeMutationHook,
    "makeQueryHook",
    ()=>makeQueryHook
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useLazyQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hooks/useLazyQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hooks/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hooks/useQuery.js [app-client] (ecmascript)");
;
function makeQueryHook(query) {
    var _s = __turbopack_context__.k.signature();
    return _s((options)=>{
        _s();
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(query, options);
    }, "4ZpngI1uv+Uo3WQHEZmTQ5FNM+k=", false, function() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
        ];
    });
}
function makeLazyQueryHook(query) {
    var _s = __turbopack_context__.k.signature();
    return _s((options)=>{
        _s();
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useLazyQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLazyQuery"])(query, options);
    }, "On+3mFuZjiEOS3MQLgFXtHkppJ4=", false, function() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useLazyQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLazyQuery"]
        ];
    });
}
function makeMutationHook(mutation) {
    var _s = __turbopack_context__.k.signature();
    return _s((options)=>{
        _s();
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(mutation, options);
    }, "wwwtpB20p0aLiHIvSy5P98MwIUg=", false, function() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
        ];
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/components/Audio/hooks/useUpsertMediaProgress.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$graphql$2d$tag$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/graphql-tag/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$helpers$2f$AbstractApolloGQLHooks$2e$helper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/helpers/AbstractApolloGQLHooks.helper.ts [app-client] (ecmascript)");
;
;
const UPSERT_MEDIA_PROGRESS_MUTATION = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$graphql$2d$tag$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gql"]`
  mutation upsertMediaProgress($mediaId: ID!, $secs: Float!) {
    upsertMediaProgress(mediaId: $mediaId, secs: $secs) {
      id
      mediaId
      secs
    }
  }
`;
const useUpsertMediaProgress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$helpers$2f$AbstractApolloGQLHooks$2e$helper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["makeMutationHook"])(UPSERT_MEDIA_PROGRESS_MUTATION);
const __TURBOPACK__default__export__ = useUpsertMediaProgress;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/components/Audio/hooks/useMediaProgressQuery.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMediaProgressLazyQuery",
    ()=>useMediaProgressLazyQuery
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$graphql$2d$tag$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/graphql-tag/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$helpers$2f$AbstractApolloGQLHooks$2e$helper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/helpers/AbstractApolloGQLHooks.helper.ts [app-client] (ecmascript)");
;
;
const MEDIA_PROGRESS_QUERY = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$graphql$2d$tag$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gql"]`
  query mediaProgress($mediaId: ID!) {
    mediaProgress(mediaId: $mediaId) {
      id
      mediaId
      secs
    }
  }
`;
const useMediaProgressLazyQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$helpers$2f$AbstractApolloGQLHooks$2e$helper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["makeLazyQueryHook"])(MEDIA_PROGRESS_QUERY);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/components/Audio/MediaProgress.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "useMediaProgress",
    ()=>useMediaProgress
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$debounce$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lodash/debounce.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$throttle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lodash/throttle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/context/MeContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$hooks$2f$useUpsertMediaProgress$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/components/Audio/hooks/useUpsertMediaProgress.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$hooks$2f$useMediaProgressQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/components/Audio/hooks/useMediaProgressQuery.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
const MediaProgressContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    getMediaProgress: ()=>{
        throw new Error('not implemented');
    },
    saveMediaProgress: ()=>{
        throw new Error('not implemented');
    }
});
const useMediaProgress = ()=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(MediaProgressContext);
};
_s(useMediaProgress, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
const localStorageKey = 'republik-progress-media';
let fallbackStore;
const getLocalMediaProgress = ()=>{
    let value = fallbackStore;
    try {
        value = JSON.parse(window.localStorage.getItem(localStorageKey));
    } catch (e) {}
    return value;
};
const setLocalMediaProgress = async (data)=>{
    fallbackStore = data;
    try {
        window.localStorage.setItem(localStorageKey, JSON.stringify(data));
    } catch (e) {}
};
const MediaProgressProvider = ({ children })=>{
    _s1();
    const { progressConsent } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMe"])();
    const [queryMediaProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$hooks$2f$useMediaProgressQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMediaProgressLazyQuery"])({
        fetchPolicy: 'network-only',
        ssr: false
    });
    const [upsertMediaProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$hooks$2f$useUpsertMediaProgress$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const saveMediaProgressNotPlaying = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "MediaProgressProvider.useMemo[saveMediaProgressNotPlaying]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$debounce$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                "MediaProgressProvider.useMemo[saveMediaProgressNotPlaying]": (mediaId, currentTime)=>{
                    // Fires on pause, on scrub, on end of video.
                    if (progressConsent) {
                        return upsertMediaProgress({
                            variables: {
                                mediaId,
                                secs: currentTime
                            }
                        }).catch({
                            "MediaProgressProvider.useMemo[saveMediaProgressNotPlaying]": ()=>{}
                        }["MediaProgressProvider.useMemo[saveMediaProgressNotPlaying]"]);
                    } else {
                        return setLocalMediaProgress({
                            mediaId,
                            currentTime
                        });
                    }
                }
            }["MediaProgressProvider.useMemo[saveMediaProgressNotPlaying]"], 300)
    }["MediaProgressProvider.useMemo[saveMediaProgressNotPlaying]"], [
        progressConsent,
        upsertMediaProgress,
        setLocalMediaProgress
    ]);
    const saveMediaProgressWhilePlaying = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "MediaProgressProvider.useMemo[saveMediaProgressWhilePlaying]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$throttle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                "MediaProgressProvider.useMemo[saveMediaProgressWhilePlaying]": (mediaId, currentTime)=>{
                    // Fires every 5 seconds while playing.
                    if (progressConsent) {
                        return upsertMediaProgress({
                            variables: {
                                mediaId,
                                secs: currentTime
                            }
                        }).catch({
                            "MediaProgressProvider.useMemo[saveMediaProgressWhilePlaying]": ()=>{}
                        }["MediaProgressProvider.useMemo[saveMediaProgressWhilePlaying]"]);
                    } else {
                        return setLocalMediaProgress({
                            mediaId,
                            currentTime
                        });
                    }
                }
            }["MediaProgressProvider.useMemo[saveMediaProgressWhilePlaying]"], 5000, {
                trailing: true
            })
    }["MediaProgressProvider.useMemo[saveMediaProgressWhilePlaying]"], [
        progressConsent,
        upsertMediaProgress,
        setLocalMediaProgress
    ]);
    const saveMediaProgress = (mediaId, currentTime, isPlaying)=>{
        if (!mediaId) {
            return Promise.resolve();
        }
        if (isPlaying) {
            return saveMediaProgressWhilePlaying(mediaId, currentTime);
        } else {
            return saveMediaProgressNotPlaying(mediaId, currentTime);
        }
    };
    const getMediaProgress = ({ mediaId, durationMs } = {})=>{
        if (!mediaId) {
            return Promise.resolve();
        }
        if (progressConsent) {
            return queryMediaProgress({
                variables: {
                    mediaId
                }
            }).then(({ data: { mediaProgress } })=>{
                // mediaProgress can be null
                const { secs } = mediaProgress || {};
                if (secs) {
                    if (durationMs && Math.round(secs) === Math.round(durationMs / 1000)) {
                        return;
                    }
                    return secs - 2;
                }
            })// eslint-disable-next-line @typescript-eslint/no-empty-function
            .catch(()=>{}); // silently fail media progress upsert
        } else {
            const localMediaProgress = getLocalMediaProgress();
            if (localMediaProgress?.mediaId === mediaId) {
                return Promise.resolve(localMediaProgress.currentTime - 2);
            }
        }
        return Promise.resolve();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MediaProgressContext.Provider, {
        value: {
            getMediaProgress,
            saveMediaProgress
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/apps/www/src/components/Audio/MediaProgress.tsx",
        lineNumber: 149,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s1(MediaProgressProvider, "TlsNKJtFEZqm5JQhbBVoJ1RbZYs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMe"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$hooks$2f$useMediaProgressQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMediaProgressLazyQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$hooks$2f$useUpsertMediaProgress$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = MediaProgressProvider;
const __TURBOPACK__default__export__ = MediaProgressProvider;
var _c;
__turbopack_context__.k.register(_c, "MediaProgressProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/react-native/CompareVersion.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
function validateVersion(version) {
    const regex = /^\d+\.\d+\.\d+$/;
    return regex.test(version);
}
function parseVersion(version) {
    if (!validateVersion(version)) {
        throw new Error(`Invalid version: ${version}`);
    }
    const parts = version.split('.').map(Number);
    return {
        major: parts[0],
        minor: parts[1],
        patch: parts[2]
    };
}
/**
 * Compare to version1 to version2.
 * Versions must be provided as strings in the following pattern: `{major}.{minor}.{patch}`.
 * @param version1
 * @param version2
 * @return value < 0 if version1 < version2
 * @return value = 0 if version1 = version2
 * @return value > 0 if version1 > version2
 */ function compareVersion(version1, version2) {
    const thisVersion = parseVersion(version1);
    const thatVersion = parseVersion(version2);
    if (thisVersion.major !== thatVersion.major) {
        return thisVersion.major - thatVersion.major;
    }
    if (thisVersion.minor !== thatVersion.minor) {
        return thisVersion.minor - thatVersion.minor;
    }
    return thisVersion.patch - thatVersion.patch;
}
const __TURBOPACK__default__export__ = compareVersion;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/components/Audio/constants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Version that introduced the new Audio API introduced with 'Hört hört'
__turbopack_context__.s([
    "NEW_AUDIO_API_VERSION",
    ()=>NEW_AUDIO_API_VERSION
]);
const NEW_AUDIO_API_VERSION = '2.2.0';
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/components/Audio/helpers/OptimisticQueueResponseHelper.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/constants.js [app-client] (ecmascript)");
;
const OptimisticQueueResponseHelper = {
    makeMoveQueueItemResponse: (queue, movedItemId, newPosition)=>{
        const currentIndexOfMovedItem = queue.findIndex((item)=>item.id === movedItemId);
        if (newPosition !== 1 || currentIndexOfMovedItem === -1) {
            if (__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDev"] && newPosition !== 1) {
                console.warn('Opttimistic queue response only implements moving to position 1');
            }
            return undefined;
        }
        const updatedQueue = [
            ...queue
        ].filter((item)=>item.id !== movedItemId);
        const itemToMoveBefore = updatedQueue.find((item, index)=>item.sequence <= newPosition);
        const nextIndex = updatedQueue.findIndex((item)=>item.id === itemToMoveBefore?.id);
        updatedQueue.splice(nextIndex, 0, queue[currentIndexOfMovedItem]);
        return {
            audioQueueItems: updatedQueue.map((item, index)=>({
                    sequence: index + 1,
                    ...item
                }))
        };
    }
};
const __TURBOPACK__default__export__ = OptimisticQueueResponseHelper;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/graphql/cms/__generated__/gql/fragment-masking.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* eslint-disable */ __turbopack_context__.s([
    "getFragmentData",
    ()=>getFragmentData,
    "isFragmentReady",
    ()=>isFragmentReady,
    "makeFragmentData",
    ()=>makeFragmentData
]);
function getFragmentData(_documentNode, fragmentType) {
    return fragmentType;
}
function makeFragmentData(data, _fragment) {
    return data;
}
function isFragmentReady(queryNode, fragmentNode, data) {
    const deferredFields = queryNode.__meta__?.deferredFields;
    if (!deferredFields) return true;
    const fragDef = fragmentNode.definitions[0];
    const fragName = fragDef?.name?.value;
    const fields = fragName && deferredFields[fragName] || [];
    return fields.length > 0 && fields.every((field)=>data && field in data);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/graphql/cms/__generated__/gql/graphql.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* eslint-disable */ __turbopack_context__.s([
    "ChallengeAcceptedArticleModelOrderBy",
    ()=>ChallengeAcceptedArticleModelOrderBy,
    "ChallengeAcceptedHubDocument",
    ()=>ChallengeAcceptedHubDocument,
    "ChallengeAcceptedHubMetaDocument",
    ()=>ChallengeAcceptedHubMetaDocument,
    "ChallengeAcceptedNewsletterModelOrderBy",
    ()=>ChallengeAcceptedNewsletterModelOrderBy,
    "ChallengeAcceptedPersonListDocument",
    ()=>ChallengeAcceptedPersonListDocument,
    "ChallengeAcceptedPersonModelOrderBy",
    ()=>ChallengeAcceptedPersonModelOrderBy,
    "CockpitDocument",
    ()=>CockpitDocument,
    "ColorBucketType",
    ()=>ColorBucketType,
    "EmployeeModelOrderBy",
    ()=>EmployeeModelOrderBy,
    "EmployeeRecordFieldsFragmentDoc",
    ()=>EmployeeRecordFieldsFragmentDoc,
    "EmployeesDocument",
    ()=>EmployeesDocument,
    "EventDocument",
    ()=>EventDocument,
    "EventMetaDocument",
    ()=>EventMetaDocument,
    "EventModelFieldsReferencingTagModel",
    ()=>EventModelFieldsReferencingTagModel,
    "EventModelOrderBy",
    ()=>EventModelOrderBy,
    "EventRecordFieldsFragmentDoc",
    ()=>EventRecordFieldsFragmentDoc,
    "EventsDocument",
    ()=>EventsDocument,
    "FaqDocument",
    ()=>FaqDocument,
    "FaviconType",
    ()=>FaviconType,
    "ImgixParamsAuto",
    ()=>ImgixParamsAuto,
    "ImgixParamsBgRemoveFgType",
    ()=>ImgixParamsBgRemoveFgType,
    "ImgixParamsBlendAlign",
    ()=>ImgixParamsBlendAlign,
    "ImgixParamsBlendCrop",
    ()=>ImgixParamsBlendCrop,
    "ImgixParamsBlendFit",
    ()=>ImgixParamsBlendFit,
    "ImgixParamsBlendMode",
    ()=>ImgixParamsBlendMode,
    "ImgixParamsBlendSize",
    ()=>ImgixParamsBlendSize,
    "ImgixParamsCh",
    ()=>ImgixParamsCh,
    "ImgixParamsCrop",
    ()=>ImgixParamsCrop,
    "ImgixParamsCs",
    ()=>ImgixParamsCs,
    "ImgixParamsFill",
    ()=>ImgixParamsFill,
    "ImgixParamsFillGenPos",
    ()=>ImgixParamsFillGenPos,
    "ImgixParamsFillGradientCs",
    ()=>ImgixParamsFillGradientCs,
    "ImgixParamsFillGradientLinearDirection",
    ()=>ImgixParamsFillGradientLinearDirection,
    "ImgixParamsFillGradientType",
    ()=>ImgixParamsFillGradientType,
    "ImgixParamsFit",
    ()=>ImgixParamsFit,
    "ImgixParamsFlip",
    ()=>ImgixParamsFlip,
    "ImgixParamsFm",
    ()=>ImgixParamsFm,
    "ImgixParamsIptc",
    ()=>ImgixParamsIptc,
    "ImgixParamsMarkAlign",
    ()=>ImgixParamsMarkAlign,
    "ImgixParamsMarkFit",
    ()=>ImgixParamsMarkFit,
    "ImgixParamsMarkTile",
    ()=>ImgixParamsMarkTile,
    "ImgixParamsPalette",
    ()=>ImgixParamsPalette,
    "ImgixParamsRotType",
    ()=>ImgixParamsRotType,
    "ImgixParamsTransparency",
    ()=>ImgixParamsTransparency,
    "ImgixParamsTrim",
    ()=>ImgixParamsTrim,
    "ImgixParamsTxtAlign",
    ()=>ImgixParamsTxtAlign,
    "ImgixParamsTxtClip",
    ()=>ImgixParamsTxtClip,
    "ImgixParamsTxtFit",
    ()=>ImgixParamsTxtFit,
    "ItemStatus",
    ()=>ItemStatus,
    "LinkingLocale",
    ()=>LinkingLocale,
    "MuxThumbnailFitMode",
    ()=>MuxThumbnailFitMode,
    "MuxThumbnailFormatType",
    ()=>MuxThumbnailFormatType,
    "MuxThumbnailRotation",
    ()=>MuxThumbnailRotation,
    "NewsletterCourseDocument",
    ()=>NewsletterCourseDocument,
    "NewsletterCourseModelOrderBy",
    ()=>NewsletterCourseModelOrderBy,
    "NewsletterCoursesDocument",
    ()=>NewsletterCoursesDocument,
    "PaynotesDocument",
    ()=>PaynotesDocument,
    "PersonDetailDocument",
    ()=>PersonDetailDocument,
    "RankemQuestionModelOrderBy",
    ()=>RankemQuestionModelOrderBy,
    "ResolutionType",
    ()=>ResolutionType,
    "SchemaMigrationModelOrderBy",
    ()=>SchemaMigrationModelOrderBy,
    "SiteLocale",
    ()=>SiteLocale,
    "TagModelOrderBy",
    ()=>TagModelOrderBy,
    "UploadOrderBy",
    ()=>UploadOrderBy,
    "UploadOrientation",
    ()=>UploadOrientation,
    "UploadType",
    ()=>UploadType,
    "VideoMp4Res",
    ()=>VideoMp4Res
]);
var ChallengeAcceptedArticleModelOrderBy = /*#__PURE__*/ function(ChallengeAcceptedArticleModelOrderBy) {
    ChallengeAcceptedArticleModelOrderBy["CreatedAtAsc"] = "_createdAt_ASC";
    ChallengeAcceptedArticleModelOrderBy["CreatedAtDesc"] = "_createdAt_DESC";
    ChallengeAcceptedArticleModelOrderBy["FirstPublishedAtAsc"] = "_firstPublishedAt_ASC";
    ChallengeAcceptedArticleModelOrderBy["FirstPublishedAtDesc"] = "_firstPublishedAt_DESC";
    ChallengeAcceptedArticleModelOrderBy["IsValidAsc"] = "_isValid_ASC";
    ChallengeAcceptedArticleModelOrderBy["IsValidDesc"] = "_isValid_DESC";
    ChallengeAcceptedArticleModelOrderBy["PublicationScheduledAtAsc"] = "_publicationScheduledAt_ASC";
    ChallengeAcceptedArticleModelOrderBy["PublicationScheduledAtDesc"] = "_publicationScheduledAt_DESC";
    ChallengeAcceptedArticleModelOrderBy["PublishedAtAsc"] = "_publishedAt_ASC";
    ChallengeAcceptedArticleModelOrderBy["PublishedAtDesc"] = "_publishedAt_DESC";
    ChallengeAcceptedArticleModelOrderBy["StatusAsc"] = "_status_ASC";
    ChallengeAcceptedArticleModelOrderBy["StatusDesc"] = "_status_DESC";
    ChallengeAcceptedArticleModelOrderBy["UnpublishingScheduledAtAsc"] = "_unpublishingScheduledAt_ASC";
    ChallengeAcceptedArticleModelOrderBy["UnpublishingScheduledAtDesc"] = "_unpublishingScheduledAt_DESC";
    ChallengeAcceptedArticleModelOrderBy["UpdatedAtAsc"] = "_updatedAt_ASC";
    ChallengeAcceptedArticleModelOrderBy["UpdatedAtDesc"] = "_updatedAt_DESC";
    ChallengeAcceptedArticleModelOrderBy["IdAsc"] = "id_ASC";
    ChallengeAcceptedArticleModelOrderBy["IdDesc"] = "id_DESC";
    ChallengeAcceptedArticleModelOrderBy["PathAsc"] = "path_ASC";
    ChallengeAcceptedArticleModelOrderBy["PathDesc"] = "path_DESC";
    return ChallengeAcceptedArticleModelOrderBy;
}({});
var ChallengeAcceptedNewsletterModelOrderBy = /*#__PURE__*/ function(ChallengeAcceptedNewsletterModelOrderBy) {
    ChallengeAcceptedNewsletterModelOrderBy["CreatedAtAsc"] = "_createdAt_ASC";
    ChallengeAcceptedNewsletterModelOrderBy["CreatedAtDesc"] = "_createdAt_DESC";
    ChallengeAcceptedNewsletterModelOrderBy["FirstPublishedAtAsc"] = "_firstPublishedAt_ASC";
    ChallengeAcceptedNewsletterModelOrderBy["FirstPublishedAtDesc"] = "_firstPublishedAt_DESC";
    ChallengeAcceptedNewsletterModelOrderBy["IsValidAsc"] = "_isValid_ASC";
    ChallengeAcceptedNewsletterModelOrderBy["IsValidDesc"] = "_isValid_DESC";
    ChallengeAcceptedNewsletterModelOrderBy["PublicationScheduledAtAsc"] = "_publicationScheduledAt_ASC";
    ChallengeAcceptedNewsletterModelOrderBy["PublicationScheduledAtDesc"] = "_publicationScheduledAt_DESC";
    ChallengeAcceptedNewsletterModelOrderBy["PublishedAtAsc"] = "_publishedAt_ASC";
    ChallengeAcceptedNewsletterModelOrderBy["PublishedAtDesc"] = "_publishedAt_DESC";
    ChallengeAcceptedNewsletterModelOrderBy["StatusAsc"] = "_status_ASC";
    ChallengeAcceptedNewsletterModelOrderBy["StatusDesc"] = "_status_DESC";
    ChallengeAcceptedNewsletterModelOrderBy["UnpublishingScheduledAtAsc"] = "_unpublishingScheduledAt_ASC";
    ChallengeAcceptedNewsletterModelOrderBy["UnpublishingScheduledAtDesc"] = "_unpublishingScheduledAt_DESC";
    ChallengeAcceptedNewsletterModelOrderBy["UpdatedAtAsc"] = "_updatedAt_ASC";
    ChallengeAcceptedNewsletterModelOrderBy["UpdatedAtDesc"] = "_updatedAt_DESC";
    ChallengeAcceptedNewsletterModelOrderBy["IdAsc"] = "id_ASC";
    ChallengeAcceptedNewsletterModelOrderBy["IdDesc"] = "id_DESC";
    ChallengeAcceptedNewsletterModelOrderBy["PathAsc"] = "path_ASC";
    ChallengeAcceptedNewsletterModelOrderBy["PathDesc"] = "path_DESC";
    return ChallengeAcceptedNewsletterModelOrderBy;
}({});
var ChallengeAcceptedPersonModelOrderBy = /*#__PURE__*/ function(ChallengeAcceptedPersonModelOrderBy) {
    ChallengeAcceptedPersonModelOrderBy["CreatedAtAsc"] = "_createdAt_ASC";
    ChallengeAcceptedPersonModelOrderBy["CreatedAtDesc"] = "_createdAt_DESC";
    ChallengeAcceptedPersonModelOrderBy["FirstPublishedAtAsc"] = "_firstPublishedAt_ASC";
    ChallengeAcceptedPersonModelOrderBy["FirstPublishedAtDesc"] = "_firstPublishedAt_DESC";
    ChallengeAcceptedPersonModelOrderBy["IsValidAsc"] = "_isValid_ASC";
    ChallengeAcceptedPersonModelOrderBy["IsValidDesc"] = "_isValid_DESC";
    ChallengeAcceptedPersonModelOrderBy["PublicationScheduledAtAsc"] = "_publicationScheduledAt_ASC";
    ChallengeAcceptedPersonModelOrderBy["PublicationScheduledAtDesc"] = "_publicationScheduledAt_DESC";
    ChallengeAcceptedPersonModelOrderBy["PublishedAtAsc"] = "_publishedAt_ASC";
    ChallengeAcceptedPersonModelOrderBy["PublishedAtDesc"] = "_publishedAt_DESC";
    ChallengeAcceptedPersonModelOrderBy["StatusAsc"] = "_status_ASC";
    ChallengeAcceptedPersonModelOrderBy["StatusDesc"] = "_status_DESC";
    ChallengeAcceptedPersonModelOrderBy["UnpublishingScheduledAtAsc"] = "_unpublishingScheduledAt_ASC";
    ChallengeAcceptedPersonModelOrderBy["UnpublishingScheduledAtDesc"] = "_unpublishingScheduledAt_DESC";
    ChallengeAcceptedPersonModelOrderBy["UpdatedAtAsc"] = "_updatedAt_ASC";
    ChallengeAcceptedPersonModelOrderBy["UpdatedAtDesc"] = "_updatedAt_DESC";
    ChallengeAcceptedPersonModelOrderBy["CatchPhraseAsc"] = "catchPhrase_ASC";
    ChallengeAcceptedPersonModelOrderBy["CatchPhraseDesc"] = "catchPhrase_DESC";
    ChallengeAcceptedPersonModelOrderBy["IdAsc"] = "id_ASC";
    ChallengeAcceptedPersonModelOrderBy["IdDesc"] = "id_DESC";
    ChallengeAcceptedPersonModelOrderBy["NameAsc"] = "name_ASC";
    ChallengeAcceptedPersonModelOrderBy["NameDesc"] = "name_DESC";
    ChallengeAcceptedPersonModelOrderBy["SizeAsc"] = "size_ASC";
    ChallengeAcceptedPersonModelOrderBy["SizeDesc"] = "size_DESC";
    return ChallengeAcceptedPersonModelOrderBy;
}({});
var ColorBucketType = /*#__PURE__*/ function(ColorBucketType) {
    ColorBucketType["Black"] = "black";
    ColorBucketType["Blue"] = "blue";
    ColorBucketType["Brown"] = "brown";
    ColorBucketType["Cyan"] = "cyan";
    ColorBucketType["Green"] = "green";
    ColorBucketType["Grey"] = "grey";
    ColorBucketType["Orange"] = "orange";
    ColorBucketType["Pink"] = "pink";
    ColorBucketType["Purple"] = "purple";
    ColorBucketType["Red"] = "red";
    ColorBucketType["White"] = "white";
    ColorBucketType["Yellow"] = "yellow";
    return ColorBucketType;
}({});
var EmployeeModelOrderBy = /*#__PURE__*/ function(EmployeeModelOrderBy) {
    EmployeeModelOrderBy["CreatedAtAsc"] = "_createdAt_ASC";
    EmployeeModelOrderBy["CreatedAtDesc"] = "_createdAt_DESC";
    EmployeeModelOrderBy["FirstPublishedAtAsc"] = "_firstPublishedAt_ASC";
    EmployeeModelOrderBy["FirstPublishedAtDesc"] = "_firstPublishedAt_DESC";
    EmployeeModelOrderBy["IsValidAsc"] = "_isValid_ASC";
    EmployeeModelOrderBy["IsValidDesc"] = "_isValid_DESC";
    EmployeeModelOrderBy["PublicationScheduledAtAsc"] = "_publicationScheduledAt_ASC";
    EmployeeModelOrderBy["PublicationScheduledAtDesc"] = "_publicationScheduledAt_DESC";
    EmployeeModelOrderBy["PublishedAtAsc"] = "_publishedAt_ASC";
    EmployeeModelOrderBy["PublishedAtDesc"] = "_publishedAt_DESC";
    EmployeeModelOrderBy["StatusAsc"] = "_status_ASC";
    EmployeeModelOrderBy["StatusDesc"] = "_status_DESC";
    EmployeeModelOrderBy["UnpublishingScheduledAtAsc"] = "_unpublishingScheduledAt_ASC";
    EmployeeModelOrderBy["UnpublishingScheduledAtDesc"] = "_unpublishingScheduledAt_DESC";
    EmployeeModelOrderBy["UpdatedAtAsc"] = "_updatedAt_ASC";
    EmployeeModelOrderBy["UpdatedAtDesc"] = "_updatedAt_DESC";
    EmployeeModelOrderBy["EmployeeAsc"] = "employee_ASC";
    EmployeeModelOrderBy["EmployeeDesc"] = "employee_DESC";
    EmployeeModelOrderBy["FamousAsc"] = "famous_ASC";
    EmployeeModelOrderBy["FamousDesc"] = "famous_DESC";
    EmployeeModelOrderBy["GenderAsc"] = "gender_ASC";
    EmployeeModelOrderBy["GenderDesc"] = "gender_DESC";
    EmployeeModelOrderBy["GreetingAsc"] = "greeting_ASC";
    EmployeeModelOrderBy["GreetingDesc"] = "greeting_DESC";
    EmployeeModelOrderBy["GroupAsc"] = "group_ASC";
    EmployeeModelOrderBy["GroupDesc"] = "group_DESC";
    EmployeeModelOrderBy["IdAsc"] = "id_ASC";
    EmployeeModelOrderBy["IdDesc"] = "id_DESC";
    EmployeeModelOrderBy["NameAsc"] = "name_ASC";
    EmployeeModelOrderBy["NameDesc"] = "name_DESC";
    EmployeeModelOrderBy["PitchAsc"] = "pitch_ASC";
    EmployeeModelOrderBy["PitchDesc"] = "pitch_DESC";
    EmployeeModelOrderBy["PositionAsc"] = "position_ASC";
    EmployeeModelOrderBy["PositionDesc"] = "position_DESC";
    EmployeeModelOrderBy["PromotedAuthorAsc"] = "promotedAuthor_ASC";
    EmployeeModelOrderBy["PromotedAuthorDesc"] = "promotedAuthor_DESC";
    EmployeeModelOrderBy["SubgroupAsc"] = "subgroup_ASC";
    EmployeeModelOrderBy["SubgroupDesc"] = "subgroup_DESC";
    EmployeeModelOrderBy["TitleAsc"] = "title_ASC";
    EmployeeModelOrderBy["TitleDesc"] = "title_DESC";
    EmployeeModelOrderBy["UserIdAsc"] = "userId_ASC";
    EmployeeModelOrderBy["UserIdDesc"] = "userId_DESC";
    return EmployeeModelOrderBy;
}({});
var EventModelFieldsReferencingTagModel = /*#__PURE__*/ function(EventModelFieldsReferencingTagModel) {
    EventModelFieldsReferencingTagModel["EventTags"] = "event_tags";
    return EventModelFieldsReferencingTagModel;
}({});
var EventModelOrderBy = /*#__PURE__*/ function(EventModelOrderBy) {
    EventModelOrderBy["CreatedAtAsc"] = "_createdAt_ASC";
    EventModelOrderBy["CreatedAtDesc"] = "_createdAt_DESC";
    EventModelOrderBy["FirstPublishedAtAsc"] = "_firstPublishedAt_ASC";
    EventModelOrderBy["FirstPublishedAtDesc"] = "_firstPublishedAt_DESC";
    EventModelOrderBy["IsValidAsc"] = "_isValid_ASC";
    EventModelOrderBy["IsValidDesc"] = "_isValid_DESC";
    EventModelOrderBy["PublicationScheduledAtAsc"] = "_publicationScheduledAt_ASC";
    EventModelOrderBy["PublicationScheduledAtDesc"] = "_publicationScheduledAt_DESC";
    EventModelOrderBy["PublishedAtAsc"] = "_publishedAt_ASC";
    EventModelOrderBy["PublishedAtDesc"] = "_publishedAt_DESC";
    EventModelOrderBy["StatusAsc"] = "_status_ASC";
    EventModelOrderBy["StatusDesc"] = "_status_DESC";
    EventModelOrderBy["UnpublishingScheduledAtAsc"] = "_unpublishingScheduledAt_ASC";
    EventModelOrderBy["UnpublishingScheduledAtDesc"] = "_unpublishingScheduledAt_DESC";
    EventModelOrderBy["UpdatedAtAsc"] = "_updatedAt_ASC";
    EventModelOrderBy["UpdatedAtDesc"] = "_updatedAt_DESC";
    EventModelOrderBy["EndAtAsc"] = "endAt_ASC";
    EventModelOrderBy["EndAtDesc"] = "endAt_DESC";
    EventModelOrderBy["FullyBookedAsc"] = "fullyBooked_ASC";
    EventModelOrderBy["FullyBookedDesc"] = "fullyBooked_DESC";
    EventModelOrderBy["IdAsc"] = "id_ASC";
    EventModelOrderBy["IdDesc"] = "id_DESC";
    EventModelOrderBy["LocationLinkAsc"] = "locationLink_ASC";
    EventModelOrderBy["LocationLinkDesc"] = "locationLink_DESC";
    EventModelOrderBy["LocationAsc"] = "location_ASC";
    EventModelOrderBy["LocationDesc"] = "location_DESC";
    EventModelOrderBy["MembersOnlyAsc"] = "membersOnly_ASC";
    EventModelOrderBy["MembersOnlyDesc"] = "membersOnly_DESC";
    EventModelOrderBy["SignUpLinkAsc"] = "signUpLink_ASC";
    EventModelOrderBy["SignUpLinkDesc"] = "signUpLink_DESC";
    EventModelOrderBy["StartAtAsc"] = "startAt_ASC";
    EventModelOrderBy["StartAtDesc"] = "startAt_DESC";
    EventModelOrderBy["TicketPriceAsc"] = "ticketPrice_ASC";
    EventModelOrderBy["TicketPriceDesc"] = "ticketPrice_DESC";
    EventModelOrderBy["TitleAsc"] = "title_ASC";
    EventModelOrderBy["TitleDesc"] = "title_DESC";
    EventModelOrderBy["UnlistedAsc"] = "unlisted_ASC";
    EventModelOrderBy["UnlistedDesc"] = "unlisted_DESC";
    return EventModelOrderBy;
}({});
var FaviconType = /*#__PURE__*/ function(FaviconType) {
    FaviconType["AppleTouchIcon"] = "appleTouchIcon";
    FaviconType["Icon"] = "icon";
    FaviconType["MsApplication"] = "msApplication";
    return FaviconType;
}({});
var ImgixParamsAuto = /*#__PURE__*/ function(ImgixParamsAuto) {
    ImgixParamsAuto["Compress"] = "compress";
    ImgixParamsAuto["Enhance"] = "enhance";
    ImgixParamsAuto["Format"] = "format";
    ImgixParamsAuto["Redeye"] = "redeye";
    return ImgixParamsAuto;
}({});
var ImgixParamsBgRemoveFgType = /*#__PURE__*/ function(ImgixParamsBgRemoveFgType) {
    ImgixParamsBgRemoveFgType["Auto"] = "auto";
    ImgixParamsBgRemoveFgType["Car"] = "car";
    return ImgixParamsBgRemoveFgType;
}({});
var ImgixParamsBlendAlign = /*#__PURE__*/ function(ImgixParamsBlendAlign) {
    ImgixParamsBlendAlign["Bottom"] = "bottom";
    ImgixParamsBlendAlign["Center"] = "center";
    ImgixParamsBlendAlign["Left"] = "left";
    ImgixParamsBlendAlign["Middle"] = "middle";
    ImgixParamsBlendAlign["Right"] = "right";
    ImgixParamsBlendAlign["Top"] = "top";
    return ImgixParamsBlendAlign;
}({});
var ImgixParamsBlendCrop = /*#__PURE__*/ function(ImgixParamsBlendCrop) {
    ImgixParamsBlendCrop["Bottom"] = "bottom";
    ImgixParamsBlendCrop["Faces"] = "faces";
    ImgixParamsBlendCrop["Left"] = "left";
    ImgixParamsBlendCrop["Right"] = "right";
    ImgixParamsBlendCrop["Top"] = "top";
    return ImgixParamsBlendCrop;
}({});
var ImgixParamsBlendFit = /*#__PURE__*/ function(ImgixParamsBlendFit) {
    ImgixParamsBlendFit["Clamp"] = "clamp";
    ImgixParamsBlendFit["Clip"] = "clip";
    ImgixParamsBlendFit["Crop"] = "crop";
    ImgixParamsBlendFit["Max"] = "max";
    ImgixParamsBlendFit["Scale"] = "scale";
    return ImgixParamsBlendFit;
}({});
var ImgixParamsBlendMode = /*#__PURE__*/ function(ImgixParamsBlendMode) {
    ImgixParamsBlendMode["Burn"] = "burn";
    ImgixParamsBlendMode["Color"] = "color";
    ImgixParamsBlendMode["Darken"] = "darken";
    ImgixParamsBlendMode["Difference"] = "difference";
    ImgixParamsBlendMode["Dodge"] = "dodge";
    ImgixParamsBlendMode["Exclusion"] = "exclusion";
    ImgixParamsBlendMode["Hardlight"] = "hardlight";
    ImgixParamsBlendMode["Hue"] = "hue";
    ImgixParamsBlendMode["Lighten"] = "lighten";
    ImgixParamsBlendMode["Luminosity"] = "luminosity";
    ImgixParamsBlendMode["Multiply"] = "multiply";
    ImgixParamsBlendMode["Normal"] = "normal";
    ImgixParamsBlendMode["Overlay"] = "overlay";
    ImgixParamsBlendMode["Saturation"] = "saturation";
    ImgixParamsBlendMode["Screen"] = "screen";
    ImgixParamsBlendMode["Softlight"] = "softlight";
    return ImgixParamsBlendMode;
}({});
var ImgixParamsBlendSize = /*#__PURE__*/ function(ImgixParamsBlendSize) {
    ImgixParamsBlendSize["Inherit"] = "inherit";
    return ImgixParamsBlendSize;
}({});
var ImgixParamsCh = /*#__PURE__*/ function(ImgixParamsCh) {
    ImgixParamsCh["Dpr"] = "dpr";
    ImgixParamsCh["SaveData"] = "saveData";
    ImgixParamsCh["Width"] = "width";
    return ImgixParamsCh;
}({});
var ImgixParamsCrop = /*#__PURE__*/ function(ImgixParamsCrop) {
    ImgixParamsCrop["Bottom"] = "bottom";
    ImgixParamsCrop["Edges"] = "edges";
    ImgixParamsCrop["Entropy"] = "entropy";
    ImgixParamsCrop["Faces"] = "faces";
    ImgixParamsCrop["Focalpoint"] = "focalpoint";
    ImgixParamsCrop["Left"] = "left";
    ImgixParamsCrop["Right"] = "right";
    ImgixParamsCrop["Top"] = "top";
    return ImgixParamsCrop;
}({});
var ImgixParamsCs = /*#__PURE__*/ function(ImgixParamsCs) {
    ImgixParamsCs["Adobergb1998"] = "adobergb1998";
    ImgixParamsCs["Origin"] = "origin";
    ImgixParamsCs["Srgb"] = "srgb";
    ImgixParamsCs["Strip"] = "strip";
    ImgixParamsCs["Tinysrgb"] = "tinysrgb";
    return ImgixParamsCs;
}({});
var ImgixParamsFill = /*#__PURE__*/ function(ImgixParamsFill) {
    ImgixParamsFill["Blur"] = "blur";
    ImgixParamsFill["Gen"] = "gen";
    ImgixParamsFill["Generative"] = "generative";
    ImgixParamsFill["Gradient"] = "gradient";
    ImgixParamsFill["Solid"] = "solid";
    return ImgixParamsFill;
}({});
var ImgixParamsFillGenPos = /*#__PURE__*/ function(ImgixParamsFillGenPos) {
    ImgixParamsFillGenPos["Bottom"] = "bottom";
    ImgixParamsFillGenPos["Center"] = "center";
    ImgixParamsFillGenPos["Left"] = "left";
    ImgixParamsFillGenPos["Middle"] = "middle";
    ImgixParamsFillGenPos["Right"] = "right";
    ImgixParamsFillGenPos["Top"] = "top";
    return ImgixParamsFillGenPos;
}({});
var ImgixParamsFillGradientCs = /*#__PURE__*/ function(ImgixParamsFillGradientCs) {
    ImgixParamsFillGradientCs["Hsl"] = "hsl";
    ImgixParamsFillGradientCs["Lch"] = "lch";
    ImgixParamsFillGradientCs["Linear"] = "linear";
    ImgixParamsFillGradientCs["Oklab"] = "oklab";
    ImgixParamsFillGradientCs["Srgb"] = "srgb";
    return ImgixParamsFillGradientCs;
}({});
var ImgixParamsFillGradientLinearDirection = /*#__PURE__*/ function(ImgixParamsFillGradientLinearDirection) {
    ImgixParamsFillGradientLinearDirection["Bottom"] = "bottom";
    ImgixParamsFillGradientLinearDirection["Left"] = "left";
    ImgixParamsFillGradientLinearDirection["Right"] = "right";
    ImgixParamsFillGradientLinearDirection["Top"] = "top";
    return ImgixParamsFillGradientLinearDirection;
}({});
var ImgixParamsFillGradientType = /*#__PURE__*/ function(ImgixParamsFillGradientType) {
    ImgixParamsFillGradientType["Linear"] = "linear";
    ImgixParamsFillGradientType["Radial"] = "radial";
    return ImgixParamsFillGradientType;
}({});
var ImgixParamsFit = /*#__PURE__*/ function(ImgixParamsFit) {
    ImgixParamsFit["Clamp"] = "clamp";
    ImgixParamsFit["Clip"] = "clip";
    ImgixParamsFit["Crop"] = "crop";
    ImgixParamsFit["Facearea"] = "facearea";
    ImgixParamsFit["Fill"] = "fill";
    ImgixParamsFit["Fillmax"] = "fillmax";
    ImgixParamsFit["Max"] = "max";
    ImgixParamsFit["Min"] = "min";
    ImgixParamsFit["Scale"] = "scale";
    return ImgixParamsFit;
}({});
var ImgixParamsFlip = /*#__PURE__*/ function(ImgixParamsFlip) {
    ImgixParamsFlip["H"] = "h";
    ImgixParamsFlip["Hv"] = "hv";
    ImgixParamsFlip["V"] = "v";
    return ImgixParamsFlip;
}({});
var ImgixParamsFm = /*#__PURE__*/ function(ImgixParamsFm) {
    ImgixParamsFm["Avif"] = "avif";
    ImgixParamsFm["Blurhash"] = "blurhash";
    ImgixParamsFm["Gif"] = "gif";
    ImgixParamsFm["Jp2"] = "jp2";
    ImgixParamsFm["Jpg"] = "jpg";
    ImgixParamsFm["Json"] = "json";
    ImgixParamsFm["Jxr"] = "jxr";
    ImgixParamsFm["Mp4"] = "mp4";
    ImgixParamsFm["Pjpg"] = "pjpg";
    ImgixParamsFm["Png"] = "png";
    ImgixParamsFm["Png8"] = "png8";
    ImgixParamsFm["Png32"] = "png32";
    ImgixParamsFm["Webm"] = "webm";
    ImgixParamsFm["Webp"] = "webp";
    return ImgixParamsFm;
}({});
var ImgixParamsIptc = /*#__PURE__*/ function(ImgixParamsIptc) {
    ImgixParamsIptc["Allow"] = "allow";
    ImgixParamsIptc["Block"] = "block";
    return ImgixParamsIptc;
}({});
var ImgixParamsMarkAlign = /*#__PURE__*/ function(ImgixParamsMarkAlign) {
    ImgixParamsMarkAlign["Bottom"] = "bottom";
    ImgixParamsMarkAlign["Center"] = "center";
    ImgixParamsMarkAlign["Left"] = "left";
    ImgixParamsMarkAlign["Middle"] = "middle";
    ImgixParamsMarkAlign["Right"] = "right";
    ImgixParamsMarkAlign["Top"] = "top";
    return ImgixParamsMarkAlign;
}({});
var ImgixParamsMarkFit = /*#__PURE__*/ function(ImgixParamsMarkFit) {
    ImgixParamsMarkFit["Clip"] = "clip";
    ImgixParamsMarkFit["Crop"] = "crop";
    ImgixParamsMarkFit["Fill"] = "fill";
    ImgixParamsMarkFit["Max"] = "max";
    ImgixParamsMarkFit["Scale"] = "scale";
    return ImgixParamsMarkFit;
}({});
var ImgixParamsMarkTile = /*#__PURE__*/ function(ImgixParamsMarkTile) {
    ImgixParamsMarkTile["Grid"] = "grid";
    return ImgixParamsMarkTile;
}({});
var ImgixParamsPalette = /*#__PURE__*/ function(ImgixParamsPalette) {
    ImgixParamsPalette["Css"] = "css";
    ImgixParamsPalette["Json"] = "json";
    return ImgixParamsPalette;
}({});
var ImgixParamsRotType = /*#__PURE__*/ function(ImgixParamsRotType) {
    ImgixParamsRotType["Pivot"] = "pivot";
    ImgixParamsRotType["Straighten"] = "straighten";
    return ImgixParamsRotType;
}({});
var ImgixParamsTransparency = /*#__PURE__*/ function(ImgixParamsTransparency) {
    ImgixParamsTransparency["Grid"] = "grid";
    return ImgixParamsTransparency;
}({});
var ImgixParamsTrim = /*#__PURE__*/ function(ImgixParamsTrim) {
    ImgixParamsTrim["Alpha"] = "alpha";
    ImgixParamsTrim["Auto"] = "auto";
    ImgixParamsTrim["Color"] = "color";
    return ImgixParamsTrim;
}({});
var ImgixParamsTxtAlign = /*#__PURE__*/ function(ImgixParamsTxtAlign) {
    ImgixParamsTxtAlign["Bottom"] = "bottom";
    ImgixParamsTxtAlign["Center"] = "center";
    ImgixParamsTxtAlign["Left"] = "left";
    ImgixParamsTxtAlign["Middle"] = "middle";
    ImgixParamsTxtAlign["Right"] = "right";
    ImgixParamsTxtAlign["Top"] = "top";
    return ImgixParamsTxtAlign;
}({});
var ImgixParamsTxtClip = /*#__PURE__*/ function(ImgixParamsTxtClip) {
    ImgixParamsTxtClip["Ellipsis"] = "ellipsis";
    ImgixParamsTxtClip["End"] = "end";
    ImgixParamsTxtClip["Middle"] = "middle";
    ImgixParamsTxtClip["Start"] = "start";
    return ImgixParamsTxtClip;
}({});
var ImgixParamsTxtFit = /*#__PURE__*/ function(ImgixParamsTxtFit) {
    ImgixParamsTxtFit["Max"] = "max";
    return ImgixParamsTxtFit;
}({});
var ItemStatus = /*#__PURE__*/ function(ItemStatus) {
    ItemStatus["Draft"] = "draft";
    ItemStatus["Published"] = "published";
    ItemStatus["Updated"] = "updated";
    return ItemStatus;
}({});
var LinkingLocale = /*#__PURE__*/ function(LinkingLocale) {
    LinkingLocale["NonLocalized"] = "_nonLocalized";
    LinkingLocale["DeCh"] = "de_CH";
    return LinkingLocale;
}({});
var MuxThumbnailFitMode = /*#__PURE__*/ function(MuxThumbnailFitMode) {
    MuxThumbnailFitMode["Crop"] = "crop";
    MuxThumbnailFitMode["Pad"] = "pad";
    MuxThumbnailFitMode["Preserve"] = "preserve";
    MuxThumbnailFitMode["Smartcrop"] = "smartcrop";
    MuxThumbnailFitMode["Stretch"] = "stretch";
    return MuxThumbnailFitMode;
}({});
var MuxThumbnailFormatType = /*#__PURE__*/ function(MuxThumbnailFormatType) {
    MuxThumbnailFormatType["Gif"] = "gif";
    MuxThumbnailFormatType["Jpg"] = "jpg";
    MuxThumbnailFormatType["Png"] = "png";
    return MuxThumbnailFormatType;
}({});
var MuxThumbnailRotation = /*#__PURE__*/ function(MuxThumbnailRotation) {
    /** Rotate 90° clockwise */ MuxThumbnailRotation["Rotate_90"] = "ROTATE_90";
    /** Rotate 180° clockwise */ MuxThumbnailRotation["Rotate_180"] = "ROTATE_180";
    /** Rotate 270° clockwise */ MuxThumbnailRotation["Rotate_270"] = "ROTATE_270";
    return MuxThumbnailRotation;
}({});
var NewsletterCourseModelOrderBy = /*#__PURE__*/ function(NewsletterCourseModelOrderBy) {
    NewsletterCourseModelOrderBy["CreatedAtAsc"] = "_createdAt_ASC";
    NewsletterCourseModelOrderBy["CreatedAtDesc"] = "_createdAt_DESC";
    NewsletterCourseModelOrderBy["FirstPublishedAtAsc"] = "_firstPublishedAt_ASC";
    NewsletterCourseModelOrderBy["FirstPublishedAtDesc"] = "_firstPublishedAt_DESC";
    NewsletterCourseModelOrderBy["IsValidAsc"] = "_isValid_ASC";
    NewsletterCourseModelOrderBy["IsValidDesc"] = "_isValid_DESC";
    NewsletterCourseModelOrderBy["PublicationScheduledAtAsc"] = "_publicationScheduledAt_ASC";
    NewsletterCourseModelOrderBy["PublicationScheduledAtDesc"] = "_publicationScheduledAt_DESC";
    NewsletterCourseModelOrderBy["PublishedAtAsc"] = "_publishedAt_ASC";
    NewsletterCourseModelOrderBy["PublishedAtDesc"] = "_publishedAt_DESC";
    NewsletterCourseModelOrderBy["StatusAsc"] = "_status_ASC";
    NewsletterCourseModelOrderBy["StatusDesc"] = "_status_DESC";
    NewsletterCourseModelOrderBy["UnpublishingScheduledAtAsc"] = "_unpublishingScheduledAt_ASC";
    NewsletterCourseModelOrderBy["UnpublishingScheduledAtDesc"] = "_unpublishingScheduledAt_DESC";
    NewsletterCourseModelOrderBy["UpdatedAtAsc"] = "_updatedAt_ASC";
    NewsletterCourseModelOrderBy["UpdatedAtDesc"] = "_updatedAt_DESC";
    NewsletterCourseModelOrderBy["IdAsc"] = "id_ASC";
    NewsletterCourseModelOrderBy["IdDesc"] = "id_DESC";
    NewsletterCourseModelOrderBy["NewsletterIdAsc"] = "newsletterId_ASC";
    NewsletterCourseModelOrderBy["NewsletterIdDesc"] = "newsletterId_DESC";
    NewsletterCourseModelOrderBy["NumberOfParticipantsAsc"] = "numberOfParticipants_ASC";
    NewsletterCourseModelOrderBy["NumberOfParticipantsDesc"] = "numberOfParticipants_DESC";
    NewsletterCourseModelOrderBy["PromiseAsc"] = "promise_ASC";
    NewsletterCourseModelOrderBy["PromiseDesc"] = "promise_DESC";
    NewsletterCourseModelOrderBy["SlugAsc"] = "slug_ASC";
    NewsletterCourseModelOrderBy["SlugDesc"] = "slug_DESC";
    NewsletterCourseModelOrderBy["TitleAsc"] = "title_ASC";
    NewsletterCourseModelOrderBy["TitleDesc"] = "title_DESC";
    return NewsletterCourseModelOrderBy;
}({});
var RankemQuestionModelOrderBy = /*#__PURE__*/ function(RankemQuestionModelOrderBy) {
    RankemQuestionModelOrderBy["CreatedAtAsc"] = "_createdAt_ASC";
    RankemQuestionModelOrderBy["CreatedAtDesc"] = "_createdAt_DESC";
    RankemQuestionModelOrderBy["FirstPublishedAtAsc"] = "_firstPublishedAt_ASC";
    RankemQuestionModelOrderBy["FirstPublishedAtDesc"] = "_firstPublishedAt_DESC";
    RankemQuestionModelOrderBy["IsValidAsc"] = "_isValid_ASC";
    RankemQuestionModelOrderBy["IsValidDesc"] = "_isValid_DESC";
    RankemQuestionModelOrderBy["PublicationScheduledAtAsc"] = "_publicationScheduledAt_ASC";
    RankemQuestionModelOrderBy["PublicationScheduledAtDesc"] = "_publicationScheduledAt_DESC";
    RankemQuestionModelOrderBy["PublishedAtAsc"] = "_publishedAt_ASC";
    RankemQuestionModelOrderBy["PublishedAtDesc"] = "_publishedAt_DESC";
    RankemQuestionModelOrderBy["StatusAsc"] = "_status_ASC";
    RankemQuestionModelOrderBy["StatusDesc"] = "_status_DESC";
    RankemQuestionModelOrderBy["UnpublishingScheduledAtAsc"] = "_unpublishingScheduledAt_ASC";
    RankemQuestionModelOrderBy["UnpublishingScheduledAtDesc"] = "_unpublishingScheduledAt_DESC";
    RankemQuestionModelOrderBy["UpdatedAtAsc"] = "_updatedAt_ASC";
    RankemQuestionModelOrderBy["UpdatedAtDesc"] = "_updatedAt_DESC";
    RankemQuestionModelOrderBy["DateAsc"] = "date_ASC";
    RankemQuestionModelOrderBy["DateDesc"] = "date_DESC";
    RankemQuestionModelOrderBy["IdAsc"] = "id_ASC";
    RankemQuestionModelOrderBy["IdDesc"] = "id_DESC";
    RankemQuestionModelOrderBy["InstructionAsc"] = "instruction_ASC";
    RankemQuestionModelOrderBy["InstructionDesc"] = "instruction_DESC";
    RankemQuestionModelOrderBy["QuestionAsc"] = "question_ASC";
    RankemQuestionModelOrderBy["QuestionDesc"] = "question_DESC";
    return RankemQuestionModelOrderBy;
}({});
var ResolutionType = /*#__PURE__*/ function(ResolutionType) {
    ResolutionType["Icon"] = "icon";
    ResolutionType["Large"] = "large";
    ResolutionType["Medium"] = "medium";
    ResolutionType["Small"] = "small";
    return ResolutionType;
}({});
var SchemaMigrationModelOrderBy = /*#__PURE__*/ function(SchemaMigrationModelOrderBy) {
    SchemaMigrationModelOrderBy["CreatedAtAsc"] = "_createdAt_ASC";
    SchemaMigrationModelOrderBy["CreatedAtDesc"] = "_createdAt_DESC";
    SchemaMigrationModelOrderBy["FirstPublishedAtAsc"] = "_firstPublishedAt_ASC";
    SchemaMigrationModelOrderBy["FirstPublishedAtDesc"] = "_firstPublishedAt_DESC";
    SchemaMigrationModelOrderBy["IsValidAsc"] = "_isValid_ASC";
    SchemaMigrationModelOrderBy["IsValidDesc"] = "_isValid_DESC";
    SchemaMigrationModelOrderBy["PublicationScheduledAtAsc"] = "_publicationScheduledAt_ASC";
    SchemaMigrationModelOrderBy["PublicationScheduledAtDesc"] = "_publicationScheduledAt_DESC";
    SchemaMigrationModelOrderBy["PublishedAtAsc"] = "_publishedAt_ASC";
    SchemaMigrationModelOrderBy["PublishedAtDesc"] = "_publishedAt_DESC";
    SchemaMigrationModelOrderBy["StatusAsc"] = "_status_ASC";
    SchemaMigrationModelOrderBy["StatusDesc"] = "_status_DESC";
    SchemaMigrationModelOrderBy["UnpublishingScheduledAtAsc"] = "_unpublishingScheduledAt_ASC";
    SchemaMigrationModelOrderBy["UnpublishingScheduledAtDesc"] = "_unpublishingScheduledAt_DESC";
    SchemaMigrationModelOrderBy["UpdatedAtAsc"] = "_updatedAt_ASC";
    SchemaMigrationModelOrderBy["UpdatedAtDesc"] = "_updatedAt_DESC";
    SchemaMigrationModelOrderBy["IdAsc"] = "id_ASC";
    SchemaMigrationModelOrderBy["IdDesc"] = "id_DESC";
    SchemaMigrationModelOrderBy["NameAsc"] = "name_ASC";
    SchemaMigrationModelOrderBy["NameDesc"] = "name_DESC";
    return SchemaMigrationModelOrderBy;
}({});
var SiteLocale = /*#__PURE__*/ function(SiteLocale) {
    SiteLocale["DeCh"] = "de_CH";
    return SiteLocale;
}({});
var TagModelOrderBy = /*#__PURE__*/ function(TagModelOrderBy) {
    TagModelOrderBy["CreatedAtAsc"] = "_createdAt_ASC";
    TagModelOrderBy["CreatedAtDesc"] = "_createdAt_DESC";
    TagModelOrderBy["FirstPublishedAtAsc"] = "_firstPublishedAt_ASC";
    TagModelOrderBy["FirstPublishedAtDesc"] = "_firstPublishedAt_DESC";
    TagModelOrderBy["IsValidAsc"] = "_isValid_ASC";
    TagModelOrderBy["IsValidDesc"] = "_isValid_DESC";
    TagModelOrderBy["PublicationScheduledAtAsc"] = "_publicationScheduledAt_ASC";
    TagModelOrderBy["PublicationScheduledAtDesc"] = "_publicationScheduledAt_DESC";
    TagModelOrderBy["PublishedAtAsc"] = "_publishedAt_ASC";
    TagModelOrderBy["PublishedAtDesc"] = "_publishedAt_DESC";
    TagModelOrderBy["StatusAsc"] = "_status_ASC";
    TagModelOrderBy["StatusDesc"] = "_status_DESC";
    TagModelOrderBy["UnpublishingScheduledAtAsc"] = "_unpublishingScheduledAt_ASC";
    TagModelOrderBy["UnpublishingScheduledAtDesc"] = "_unpublishingScheduledAt_DESC";
    TagModelOrderBy["UpdatedAtAsc"] = "_updatedAt_ASC";
    TagModelOrderBy["UpdatedAtDesc"] = "_updatedAt_DESC";
    TagModelOrderBy["IdAsc"] = "id_ASC";
    TagModelOrderBy["IdDesc"] = "id_DESC";
    TagModelOrderBy["LabelAsc"] = "label_ASC";
    TagModelOrderBy["LabelDesc"] = "label_DESC";
    return TagModelOrderBy;
}({});
var UploadOrderBy = /*#__PURE__*/ function(UploadOrderBy) {
    UploadOrderBy["CreatedAtAsc"] = "_createdAt_ASC";
    UploadOrderBy["CreatedAtDesc"] = "_createdAt_DESC";
    UploadOrderBy["UpdatedAtAsc"] = "_updatedAt_ASC";
    UploadOrderBy["UpdatedAtDesc"] = "_updatedAt_DESC";
    UploadOrderBy["BasenameAsc"] = "basename_ASC";
    UploadOrderBy["BasenameDesc"] = "basename_DESC";
    UploadOrderBy["FilenameAsc"] = "filename_ASC";
    UploadOrderBy["FilenameDesc"] = "filename_DESC";
    UploadOrderBy["FormatAsc"] = "format_ASC";
    UploadOrderBy["FormatDesc"] = "format_DESC";
    UploadOrderBy["IdAsc"] = "id_ASC";
    UploadOrderBy["IdDesc"] = "id_DESC";
    UploadOrderBy["MimeTypeAsc"] = "mimeType_ASC";
    UploadOrderBy["MimeTypeDesc"] = "mimeType_DESC";
    UploadOrderBy["ResolutionAsc"] = "resolution_ASC";
    UploadOrderBy["ResolutionDesc"] = "resolution_DESC";
    UploadOrderBy["SizeAsc"] = "size_ASC";
    UploadOrderBy["SizeDesc"] = "size_DESC";
    return UploadOrderBy;
}({});
var UploadOrientation = /*#__PURE__*/ function(UploadOrientation) {
    UploadOrientation["Landscape"] = "landscape";
    UploadOrientation["Portrait"] = "portrait";
    UploadOrientation["Square"] = "square";
    return UploadOrientation;
}({});
var UploadType = /*#__PURE__*/ function(UploadType) {
    UploadType["Archive"] = "archive";
    UploadType["Audio"] = "audio";
    UploadType["Image"] = "image";
    UploadType["Pdfdocument"] = "pdfdocument";
    UploadType["Presentation"] = "presentation";
    UploadType["Richtext"] = "richtext";
    UploadType["Spreadsheet"] = "spreadsheet";
    UploadType["Video"] = "video";
    return UploadType;
}({});
var VideoMp4Res = /*#__PURE__*/ function(VideoMp4Res) {
    VideoMp4Res["High"] = "high";
    VideoMp4Res["Low"] = "low";
    VideoMp4Res["Medium"] = "medium";
    return VideoMp4Res;
}({});
const EmployeeRecordFieldsFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "EmployeeRecordFields"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "EmployeeRecord"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "employee"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "name"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "gender"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "greeting"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "group"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "pitch"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "promotedAuthor"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "subgroup"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "title"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "userId"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "famous"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "_updatedAt"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "profile"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "url"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "imgixParams"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "sat"
                                                        },
                                                        "value": {
                                                            "kind": "IntValue",
                                                            "value": "-100"
                                                        }
                                                    },
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "w"
                                                        },
                                                        "value": {
                                                            "kind": "IntValue",
                                                            "value": "384"
                                                        }
                                                    },
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "h"
                                                        },
                                                        "value": {
                                                            "kind": "IntValue",
                                                            "value": "384"
                                                        }
                                                    },
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "fit"
                                                        },
                                                        "value": {
                                                            "kind": "EnumValue",
                                                            "value": "crop"
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const EventRecordFieldsFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "EventRecordFields"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "EventRecord"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "title"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "slug"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "description"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "value"
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "membersOnly"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "nonMemberCta"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "value"
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "fullyBooked"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "ticketPrice"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "signUpLink"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "location"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "locationLink"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "startAt"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "endAt"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "_updatedAt"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "_status"
                        }
                    }
                ]
            }
        }
    ]
};
const ChallengeAcceptedHubMetaDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "ChallengeAcceptedHubMeta"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "hub"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "challengeAcceptedHub"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "metadata"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "description"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "image"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "url"
                                                            },
                                                            "arguments": [
                                                                {
                                                                    "kind": "Argument",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "imgixParams"
                                                                    },
                                                                    "value": {
                                                                        "kind": "ObjectValue",
                                                                        "fields": [
                                                                            {
                                                                                "kind": "ObjectField",
                                                                                "name": {
                                                                                    "kind": "Name",
                                                                                    "value": "w"
                                                                                },
                                                                                "value": {
                                                                                    "kind": "StringValue",
                                                                                    "value": "1500",
                                                                                    "block": false
                                                                                }
                                                                            }
                                                                        ]
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const ChallengeAcceptedHubDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "ChallengeAcceptedHub"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "hub"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "challengeAcceptedHub"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "logo"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "url"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "introduction"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "value"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "outro"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "value"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "newsletterSignupIntro"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "newsletterSignupTagline"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "newsletterSignupBenefits"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "value"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "items"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "__typename"
                                                }
                                            },
                                            {
                                                "kind": "InlineFragment",
                                                "typeCondition": {
                                                    "kind": "NamedType",
                                                    "name": {
                                                        "kind": "Name",
                                                        "value": "EventRecord"
                                                    }
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "title"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "slug"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "description"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "value"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "membersOnly"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "nonMemberCta"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "value"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "fullyBooked"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "signUpLink"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "location"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "locationLink"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "startAt"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "endAt"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "_updatedAt"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "_status"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "InlineFragment",
                                                "typeCondition": {
                                                    "kind": "NamedType",
                                                    "name": {
                                                        "kind": "Name",
                                                        "value": "ChallengeAcceptedArticleRecord"
                                                    }
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "path"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "image"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "url"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "width"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "height"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "InlineFragment",
                                                "typeCondition": {
                                                    "kind": "NamedType",
                                                    "name": {
                                                        "kind": "Name",
                                                        "value": "ChallengeAcceptedNewsletterRecord"
                                                    }
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "path"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "people"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "allChallengeAcceptedPeople"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "first"
                                },
                                "value": {
                                    "kind": "IntValue",
                                    "value": "50"
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "slug"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "name"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "portrait"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "url"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "height"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "width"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "challengeAcceptedTag"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "tag"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "filter"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "slug"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "eq"
                                                        },
                                                        "value": {
                                                            "kind": "StringValue",
                                                            "value": "challenge-accepted",
                                                            "block": false
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "alias": {
                                        "kind": "Name",
                                        "value": "events"
                                    },
                                    "name": {
                                        "kind": "Name",
                                        "value": "_allReferencingEvents"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "orderBy"
                                            },
                                            "value": {
                                                "kind": "EnumValue",
                                                "value": "startAt_DESC"
                                            }
                                        },
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "first"
                                            },
                                            "value": {
                                                "kind": "IntValue",
                                                "value": "100"
                                            }
                                        }
                                    ],
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "__typename"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "slug"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "description"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "value"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "membersOnly"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "nonMemberCta"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "value"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "fullyBooked"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "signUpLink"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "location"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "locationLink"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "startAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "endAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "_updatedAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "_status"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "allNewsletters"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "allChallengeAcceptedNewsletters"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "orderBy"
                                },
                                "value": {
                                    "kind": "EnumValue",
                                    "value": "path_DESC"
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "first"
                                },
                                "value": {
                                    "kind": "IntValue",
                                    "value": "100"
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "__typename"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "path"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const ChallengeAcceptedPersonListDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "ChallengeAcceptedPersonList"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "hub"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "challengeAcceptedHub"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "logo"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "url"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "people"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "allChallengeAcceptedPeople"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "first"
                                },
                                "value": {
                                    "kind": "IntValue",
                                    "value": "50"
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "orderBy"
                                },
                                "value": {
                                    "kind": "EnumValue",
                                    "value": "size_ASC"
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "slug"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "name"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "size"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "portrait"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "url"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "height"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "width"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const CockpitDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "Cockpit"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "cockpit"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "intro"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "value"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "membershipsCountChart"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "value"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "membershipsChangeChart"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "value"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "ourCommunity"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "value"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "activeMembers"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "value"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const EmployeesDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "Employees"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "employees"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "allEmployees"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "first"
                                },
                                "value": {
                                    "kind": "IntValue",
                                    "value": "100"
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "FragmentSpread",
                                    "name": {
                                        "kind": "Name",
                                        "value": "EmployeeRecordFields"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "EmployeeRecordFields"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "EmployeeRecord"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "employee"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "name"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "gender"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "greeting"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "group"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "pitch"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "promotedAuthor"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "subgroup"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "title"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "userId"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "famous"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "_updatedAt"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "profile"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "url"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "imgixParams"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "sat"
                                                        },
                                                        "value": {
                                                            "kind": "IntValue",
                                                            "value": "-100"
                                                        }
                                                    },
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "w"
                                                        },
                                                        "value": {
                                                            "kind": "IntValue",
                                                            "value": "384"
                                                        }
                                                    },
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "h"
                                                        },
                                                        "value": {
                                                            "kind": "IntValue",
                                                            "value": "384"
                                                        }
                                                    },
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "fit"
                                                        },
                                                        "value": {
                                                            "kind": "EnumValue",
                                                            "value": "crop"
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const EventMetaDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "EventMeta"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "slug"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "String"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "event"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "filter"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "slug"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "eq"
                                                        },
                                                        "value": {
                                                            "kind": "Variable",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "slug"
                                                            }
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "title"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "location"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "locationLink"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "startAt"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "endAt"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "description"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "value"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "signUpLink"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "membersOnly"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "fullyBooked"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "ticketPrice"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "seo"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "description"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "image"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "url"
                                                            },
                                                            "arguments": [
                                                                {
                                                                    "kind": "Argument",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "imgixParams"
                                                                    },
                                                                    "value": {
                                                                        "kind": "ObjectValue",
                                                                        "fields": [
                                                                            {
                                                                                "kind": "ObjectField",
                                                                                "name": {
                                                                                    "kind": "Name",
                                                                                    "value": "w"
                                                                                },
                                                                                "value": {
                                                                                    "kind": "StringValue",
                                                                                    "value": "1500",
                                                                                    "block": false
                                                                                }
                                                                            }
                                                                        ]
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const EventDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "Event"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "slug"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "String"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "event"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "filter"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "slug"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "eq"
                                                        },
                                                        "value": {
                                                            "kind": "Variable",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "slug"
                                                            }
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "FragmentSpread",
                                    "name": {
                                        "kind": "Name",
                                        "value": "EventRecordFields"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "EventRecordFields"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "EventRecord"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "title"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "slug"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "description"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "value"
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "membersOnly"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "nonMemberCta"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "value"
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "fullyBooked"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "ticketPrice"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "signUpLink"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "location"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "locationLink"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "startAt"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "endAt"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "_updatedAt"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "_status"
                        }
                    }
                ]
            }
        }
    ]
};
const EventsDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "Events"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "today"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "DateTime"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "events"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "allEvents"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "filter"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "AND"
                                            },
                                            "value": {
                                                "kind": "ListValue",
                                                "values": [
                                                    {
                                                        "kind": "ObjectValue",
                                                        "fields": [
                                                            {
                                                                "kind": "ObjectField",
                                                                "name": {
                                                                    "kind": "Name",
                                                                    "value": "unlisted"
                                                                },
                                                                "value": {
                                                                    "kind": "ObjectValue",
                                                                    "fields": [
                                                                        {
                                                                            "kind": "ObjectField",
                                                                            "name": {
                                                                                "kind": "Name",
                                                                                "value": "eq"
                                                                            },
                                                                            "value": {
                                                                                "kind": "BooleanValue",
                                                                                "value": false
                                                                            }
                                                                        }
                                                                    ]
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "kind": "ObjectValue",
                                                        "fields": [
                                                            {
                                                                "kind": "ObjectField",
                                                                "name": {
                                                                    "kind": "Name",
                                                                    "value": "OR"
                                                                },
                                                                "value": {
                                                                    "kind": "ListValue",
                                                                    "values": [
                                                                        {
                                                                            "kind": "ObjectValue",
                                                                            "fields": [
                                                                                {
                                                                                    "kind": "ObjectField",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "startAt"
                                                                                    },
                                                                                    "value": {
                                                                                        "kind": "ObjectValue",
                                                                                        "fields": [
                                                                                            {
                                                                                                "kind": "ObjectField",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "gte"
                                                                                                },
                                                                                                "value": {
                                                                                                    "kind": "Variable",
                                                                                                    "name": {
                                                                                                        "kind": "Name",
                                                                                                        "value": "today"
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        },
                                                                        {
                                                                            "kind": "ObjectValue",
                                                                            "fields": [
                                                                                {
                                                                                    "kind": "ObjectField",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "endAt"
                                                                                    },
                                                                                    "value": {
                                                                                        "kind": "ObjectValue",
                                                                                        "fields": [
                                                                                            {
                                                                                                "kind": "ObjectField",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "gte"
                                                                                                },
                                                                                                "value": {
                                                                                                    "kind": "Variable",
                                                                                                    "name": {
                                                                                                        "kind": "Name",
                                                                                                        "value": "today"
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    ]
                                                                }
                                                            }
                                                        ]
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "orderBy"
                                },
                                "value": {
                                    "kind": "EnumValue",
                                    "value": "startAt_ASC"
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "FragmentSpread",
                                    "name": {
                                        "kind": "Name",
                                        "value": "EventRecordFields"
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "pastEvents"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "allEvents"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "filter"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "AND"
                                            },
                                            "value": {
                                                "kind": "ListValue",
                                                "values": [
                                                    {
                                                        "kind": "ObjectValue",
                                                        "fields": [
                                                            {
                                                                "kind": "ObjectField",
                                                                "name": {
                                                                    "kind": "Name",
                                                                    "value": "unlisted"
                                                                },
                                                                "value": {
                                                                    "kind": "ObjectValue",
                                                                    "fields": [
                                                                        {
                                                                            "kind": "ObjectField",
                                                                            "name": {
                                                                                "kind": "Name",
                                                                                "value": "eq"
                                                                            },
                                                                            "value": {
                                                                                "kind": "BooleanValue",
                                                                                "value": false
                                                                            }
                                                                        }
                                                                    ]
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "kind": "ObjectValue",
                                                        "fields": [
                                                            {
                                                                "kind": "ObjectField",
                                                                "name": {
                                                                    "kind": "Name",
                                                                    "value": "AND"
                                                                },
                                                                "value": {
                                                                    "kind": "ListValue",
                                                                    "values": [
                                                                        {
                                                                            "kind": "ObjectValue",
                                                                            "fields": [
                                                                                {
                                                                                    "kind": "ObjectField",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "startAt"
                                                                                    },
                                                                                    "value": {
                                                                                        "kind": "ObjectValue",
                                                                                        "fields": [
                                                                                            {
                                                                                                "kind": "ObjectField",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "lt"
                                                                                                },
                                                                                                "value": {
                                                                                                    "kind": "Variable",
                                                                                                    "name": {
                                                                                                        "kind": "Name",
                                                                                                        "value": "today"
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        },
                                                                        {
                                                                            "kind": "ObjectValue",
                                                                            "fields": [
                                                                                {
                                                                                    "kind": "ObjectField",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "OR"
                                                                                    },
                                                                                    "value": {
                                                                                        "kind": "ListValue",
                                                                                        "values": [
                                                                                            {
                                                                                                "kind": "ObjectValue",
                                                                                                "fields": [
                                                                                                    {
                                                                                                        "kind": "ObjectField",
                                                                                                        "name": {
                                                                                                            "kind": "Name",
                                                                                                            "value": "endAt"
                                                                                                        },
                                                                                                        "value": {
                                                                                                            "kind": "ObjectValue",
                                                                                                            "fields": [
                                                                                                                {
                                                                                                                    "kind": "ObjectField",
                                                                                                                    "name": {
                                                                                                                        "kind": "Name",
                                                                                                                        "value": "lt"
                                                                                                                    },
                                                                                                                    "value": {
                                                                                                                        "kind": "Variable",
                                                                                                                        "name": {
                                                                                                                            "kind": "Name",
                                                                                                                            "value": "today"
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            ]
                                                                                                        }
                                                                                                    }
                                                                                                ]
                                                                                            },
                                                                                            {
                                                                                                "kind": "ObjectValue",
                                                                                                "fields": [
                                                                                                    {
                                                                                                        "kind": "ObjectField",
                                                                                                        "name": {
                                                                                                            "kind": "Name",
                                                                                                            "value": "endAt"
                                                                                                        },
                                                                                                        "value": {
                                                                                                            "kind": "ObjectValue",
                                                                                                            "fields": [
                                                                                                                {
                                                                                                                    "kind": "ObjectField",
                                                                                                                    "name": {
                                                                                                                        "kind": "Name",
                                                                                                                        "value": "exists"
                                                                                                                    },
                                                                                                                    "value": {
                                                                                                                        "kind": "BooleanValue",
                                                                                                                        "value": false
                                                                                                                    }
                                                                                                                }
                                                                                                            ]
                                                                                                        }
                                                                                                    }
                                                                                                ]
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    ]
                                                                }
                                                            }
                                                        ]
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "orderBy"
                                },
                                "value": {
                                    "kind": "EnumValue",
                                    "value": "startAt_DESC"
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "FragmentSpread",
                                    "name": {
                                        "kind": "Name",
                                        "value": "EventRecordFields"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "EventRecordFields"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "EventRecord"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "title"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "slug"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "description"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "value"
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "membersOnly"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "nonMemberCta"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "value"
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "fullyBooked"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "ticketPrice"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "signUpLink"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "location"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "locationLink"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "startAt"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "endAt"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "_updatedAt"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "_status"
                        }
                    }
                ]
            }
        }
    ]
};
const FaqDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "FAQ"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "faq"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "title"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "introduction"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "value"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "entries"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "answer"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "value"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "question"
                                                },
                                                "arguments": [
                                                    {
                                                        "kind": "Argument",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "markdown"
                                                        },
                                                        "value": {
                                                            "kind": "BooleanValue",
                                                            "value": false
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "category"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const NewsletterCourseDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "NewsletterCourse"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "slug"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "String"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "newsletterCourse"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "filter"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "slug"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "eq"
                                                        },
                                                        "value": {
                                                            "kind": "Variable",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "slug"
                                                            }
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "title"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "newsletterId"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "promise"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "content"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "slug"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "heroBackgroundColor"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "hex"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "heroTextColor"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "hex"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "accentColor"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "hex"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "accentTextColor"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "hex"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "images"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "url"
                                                },
                                                "arguments": [
                                                    {
                                                        "kind": "Argument",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "imgixParams"
                                                        },
                                                        "value": {
                                                            "kind": "ObjectValue",
                                                            "fields": [
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "w"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "900"
                                                                    }
                                                                },
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "fit"
                                                                    },
                                                                    "value": {
                                                                        "kind": "EnumValue",
                                                                        "value": "crop"
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "width"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "height"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "alt"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "entries"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "description"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "numberOfParticipants"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "testimonials"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "testimonial"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "reasons"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "testimonial"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "credits"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "InlineFragment",
                                                "typeCondition": {
                                                    "kind": "NamedType",
                                                    "name": {
                                                        "kind": "Name",
                                                        "value": "NewsletterCourseContributorRecord"
                                                    }
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "name"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "role"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "url"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "mainContributor"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "image"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "url"
                                                                        },
                                                                        "arguments": [
                                                                            {
                                                                                "kind": "Argument",
                                                                                "name": {
                                                                                    "kind": "Name",
                                                                                    "value": "imgixParams"
                                                                                },
                                                                                "value": {
                                                                                    "kind": "ObjectValue",
                                                                                    "fields": [
                                                                                        {
                                                                                            "kind": "ObjectField",
                                                                                            "name": {
                                                                                                "kind": "Name",
                                                                                                "value": "w"
                                                                                            },
                                                                                            "value": {
                                                                                                "kind": "IntValue",
                                                                                                "value": "900"
                                                                                            }
                                                                                        },
                                                                                        {
                                                                                            "kind": "ObjectField",
                                                                                            "name": {
                                                                                                "kind": "Name",
                                                                                                "value": "fit"
                                                                                            },
                                                                                            "value": {
                                                                                                "kind": "EnumValue",
                                                                                                "value": "crop"
                                                                                            }
                                                                                        }
                                                                                    ]
                                                                                }
                                                                            }
                                                                        ]
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "width"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "height"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "alt"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const NewsletterCoursesDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "NewsletterCourses"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "allNewsletterCourses"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "title"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "promise"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "slug"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "heroBackgroundColor"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "hex"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "heroTextColor"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "hex"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "accentColor"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "hex"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "accentTextColor"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "hex"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "images"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "url"
                                                },
                                                "arguments": [
                                                    {
                                                        "kind": "Argument",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "imgixParams"
                                                        },
                                                        "value": {
                                                            "kind": "ObjectValue",
                                                            "fields": [
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "w"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "900"
                                                                    }
                                                                },
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "fit"
                                                                    },
                                                                    "value": {
                                                                        "kind": "EnumValue",
                                                                        "value": "crop"
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "width"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "height"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "alt"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const PaynotesDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "Paynotes"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "paynoteConfig"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "paynotes"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "message"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "value"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "author"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "name"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "description"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "portrait"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "url"
                                                                        },
                                                                        "arguments": [
                                                                            {
                                                                                "kind": "Argument",
                                                                                "name": {
                                                                                    "kind": "Name",
                                                                                    "value": "imgixParams"
                                                                                },
                                                                                "value": {
                                                                                    "kind": "ObjectValue",
                                                                                    "fields": [
                                                                                        {
                                                                                            "kind": "ObjectField",
                                                                                            "name": {
                                                                                                "kind": "Name",
                                                                                                "value": "ar"
                                                                                            },
                                                                                            "value": {
                                                                                                "kind": "StringValue",
                                                                                                "value": "1:1",
                                                                                                "block": false
                                                                                            }
                                                                                        },
                                                                                        {
                                                                                            "kind": "ObjectField",
                                                                                            "name": {
                                                                                                "kind": "Name",
                                                                                                "value": "fit"
                                                                                            },
                                                                                            "value": {
                                                                                                "kind": "EnumValue",
                                                                                                "value": "crop"
                                                                                            }
                                                                                        },
                                                                                        {
                                                                                            "kind": "ObjectField",
                                                                                            "name": {
                                                                                                "kind": "Name",
                                                                                                "value": "w"
                                                                                            },
                                                                                            "value": {
                                                                                                "kind": "IntValue",
                                                                                                "value": "160"
                                                                                            }
                                                                                        },
                                                                                        {
                                                                                            "kind": "ObjectField",
                                                                                            "name": {
                                                                                                "kind": "Name",
                                                                                                "value": "h"
                                                                                            },
                                                                                            "value": {
                                                                                                "kind": "IntValue",
                                                                                                "value": "160"
                                                                                            }
                                                                                        }
                                                                                    ]
                                                                                }
                                                                            }
                                                                        ]
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "miniPaynotes"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "message"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const PersonDetailDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "PersonDetail"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "slug"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "hub"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "challengeAcceptedHub"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "logo"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "url"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "newsletterSignupTagline"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "newsletterSignupIntro"
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "person"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "challengeAcceptedPerson"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "filter"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "slug"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "eq"
                                                        },
                                                        "value": {
                                                            "kind": "Variable",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "slug"
                                                            }
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "name"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "slug"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "portrait"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "alt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "url"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "width"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "height"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "catchPhrase"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "bio"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "value"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "items"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "__typename"
                                                }
                                            },
                                            {
                                                "kind": "InlineFragment",
                                                "typeCondition": {
                                                    "kind": "NamedType",
                                                    "name": {
                                                        "kind": "Name",
                                                        "value": "EventRecord"
                                                    }
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "title"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "slug"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "description"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "value"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "membersOnly"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "nonMemberCta"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "value"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "fullyBooked"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "signUpLink"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "location"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "locationLink"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "startAt"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "endAt"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "_updatedAt"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "_status"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "InlineFragment",
                                                "typeCondition": {
                                                    "kind": "NamedType",
                                                    "name": {
                                                        "kind": "Name",
                                                        "value": "ChallengeAcceptedArticleRecord"
                                                    }
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "path"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "image"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "url"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "width"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "height"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "InlineFragment",
                                                "typeCondition": {
                                                    "kind": "NamedType",
                                                    "name": {
                                                        "kind": "Name",
                                                        "value": "ChallengeAcceptedNewsletterRecord"
                                                    }
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "path"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/graphql/cms/__generated__/gql/gql.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "gql",
    ()=>gql
]);
/* eslint-disable */ var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/graphql/cms/__generated__/gql/graphql.ts [app-client] (ecmascript)");
;
/**
 * Map of all GraphQL operations in the project.
 *
 * This map has several performance disadvantages:
 * 1. It is not tree-shakeable, so it will include all operations in the project.
 * 2. It is not minifiable, so the string of a GraphQL query will be multiple times inside the bundle.
 * 3. It does not support dead code elimination, so it will add unused operations.
 *
 * Therefore it is highly recommended to use the babel or swc plugin for production.
 */ const documents = {
    "fragment EmployeeRecordFields on EmployeeRecord {\n  employee\n  name\n  gender\n  greeting\n  group\n  pitch\n  promotedAuthor\n  subgroup\n  title\n  userId\n  famous\n  _updatedAt\n  profile {\n    url(imgixParams: {sat: -100, w: 384, h: 384, fit: crop})\n  }\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EmployeeRecordFieldsFragmentDoc"],
    "fragment EventRecordFields on EventRecord {\n  id\n  title\n  slug\n  description {\n    value\n  }\n  membersOnly\n  nonMemberCta {\n    value\n  }\n  fullyBooked\n  ticketPrice\n  signUpLink\n  location\n  locationLink\n  startAt\n  endAt\n  _updatedAt\n  _status\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EventRecordFieldsFragmentDoc"],
    "query ChallengeAcceptedHubMeta {\n  hub: challengeAcceptedHub {\n    id\n    metadata {\n      title\n      description\n      image {\n        url(imgixParams: {w: \"1500\"})\n      }\n    }\n  }\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChallengeAcceptedHubMetaDocument"],
    "query ChallengeAcceptedHub {\n  hub: challengeAcceptedHub {\n    id\n    logo {\n      url\n    }\n    introduction {\n      value\n    }\n    outro {\n      value\n    }\n    newsletterSignupIntro\n    newsletterSignupTagline\n    newsletterSignupBenefits {\n      value\n    }\n    items {\n      __typename\n      ... on EventRecord {\n        id\n        title\n        slug\n        description {\n          value\n        }\n        membersOnly\n        nonMemberCta {\n          value\n        }\n        fullyBooked\n        signUpLink\n        location\n        locationLink\n        startAt\n        endAt\n        _updatedAt\n        _status\n      }\n      ... on ChallengeAcceptedArticleRecord {\n        id\n        path\n        image {\n          url\n          width\n          height\n        }\n      }\n      ... on ChallengeAcceptedNewsletterRecord {\n        id\n        path\n      }\n    }\n  }\n  people: allChallengeAcceptedPeople(first: 50) {\n    id\n    slug\n    name\n    portrait {\n      url\n      height\n      width\n    }\n  }\n  challengeAcceptedTag: tag(filter: {slug: {eq: \"challenge-accepted\"}}) {\n    events: _allReferencingEvents(orderBy: startAt_DESC, first: 100) {\n      __typename\n      id\n      title\n      slug\n      description {\n        value\n      }\n      membersOnly\n      nonMemberCta {\n        value\n      }\n      fullyBooked\n      signUpLink\n      location\n      locationLink\n      startAt\n      endAt\n      _updatedAt\n      _status\n    }\n  }\n  allNewsletters: allChallengeAcceptedNewsletters(orderBy: path_DESC, first: 100) {\n    __typename\n    id\n    path\n  }\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChallengeAcceptedHubDocument"],
    "query ChallengeAcceptedPersonList {\n  hub: challengeAcceptedHub {\n    id\n    logo {\n      url\n    }\n  }\n  people: allChallengeAcceptedPeople(first: 50, orderBy: size_ASC) {\n    id\n    slug\n    name\n    size\n    portrait {\n      url\n      height\n      width\n    }\n  }\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChallengeAcceptedPersonListDocument"],
    "query Cockpit {\n  cockpit {\n    id\n    intro {\n      value\n    }\n    membershipsCountChart {\n      value\n    }\n    membershipsChangeChart {\n      value\n    }\n    ourCommunity {\n      value\n    }\n    activeMembers {\n      value\n    }\n  }\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CockpitDocument"],
    "query Employees {\n  employees: allEmployees(first: 100) {\n    ...EmployeeRecordFields\n  }\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EmployeesDocument"],
    "query EventMeta($slug: String) {\n  event(filter: {slug: {eq: $slug}}) {\n    id\n    title\n    location\n    locationLink\n    startAt\n    endAt\n    description {\n      value\n    }\n    signUpLink\n    membersOnly\n    fullyBooked\n    ticketPrice\n    seo {\n      title\n      description\n      image {\n        url(imgixParams: {w: \"1500\"})\n      }\n    }\n  }\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EventMetaDocument"],
    "query Event($slug: String) {\n  event(filter: {slug: {eq: $slug}}) {\n    ...EventRecordFields\n  }\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EventDocument"],
    "query Events($today: DateTime!) {\n  events: allEvents(\n    filter: {AND: [{unlisted: {eq: false}}, {OR: [{startAt: {gte: $today}}, {endAt: {gte: $today}}]}]}\n    orderBy: startAt_ASC\n  ) {\n    ...EventRecordFields\n  }\n  pastEvents: allEvents(\n    filter: {AND: [{unlisted: {eq: false}}, {AND: [{startAt: {lt: $today}}, {OR: [{endAt: {lt: $today}}, {endAt: {exists: false}}]}]}]}\n    orderBy: startAt_DESC\n  ) {\n    ...EventRecordFields\n  }\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EventsDocument"],
    "query FAQ {\n  faq {\n    title\n    introduction {\n      value\n    }\n    entries {\n      answer {\n        value\n      }\n      question(markdown: false)\n      category\n    }\n  }\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaqDocument"],
    "query NewsletterCourse($slug: String) {\n  newsletterCourse(filter: {slug: {eq: $slug}}) {\n    title\n    newsletterId\n    promise\n    content\n    slug\n    heroBackgroundColor {\n      hex\n    }\n    heroTextColor {\n      hex\n    }\n    accentColor {\n      hex\n    }\n    accentTextColor {\n      hex\n    }\n    images {\n      url(imgixParams: {w: 900, fit: crop})\n      width\n      height\n      alt\n    }\n    entries {\n      title\n      description\n    }\n    numberOfParticipants\n    testimonials {\n      testimonial\n    }\n    reasons {\n      testimonial\n    }\n    credits {\n      ... on NewsletterCourseContributorRecord {\n        name\n        role\n        url\n        mainContributor\n        image {\n          url(imgixParams: {w: 900, fit: crop})\n          width\n          height\n          alt\n        }\n      }\n    }\n  }\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NewsletterCourseDocument"],
    "query NewsletterCourses {\n  allNewsletterCourses {\n    title\n    promise\n    slug\n    heroBackgroundColor {\n      hex\n    }\n    heroTextColor {\n      hex\n    }\n    accentColor {\n      hex\n    }\n    accentTextColor {\n      hex\n    }\n    images {\n      url(imgixParams: {w: 900, fit: crop})\n      width\n      height\n      alt\n    }\n  }\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NewsletterCoursesDocument"],
    "query Paynotes {\n  paynoteConfig {\n    id\n    paynotes {\n      id\n      title\n      message {\n        value\n      }\n      author {\n        name\n        description\n        portrait {\n          url(imgixParams: {ar: \"1:1\", fit: crop, w: 160, h: 160})\n        }\n      }\n    }\n    miniPaynotes {\n      id\n      message\n    }\n  }\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaynotesDocument"],
    "query PersonDetail($slug: String!) {\n  hub: challengeAcceptedHub {\n    id\n    logo {\n      url\n    }\n    newsletterSignupTagline\n    newsletterSignupIntro\n  }\n  person: challengeAcceptedPerson(filter: {slug: {eq: $slug}}) {\n    id\n    name\n    slug\n    portrait {\n      alt\n      url\n      width\n      height\n      title\n    }\n    catchPhrase\n    bio {\n      value\n    }\n    items {\n      __typename\n      ... on EventRecord {\n        id\n        title\n        slug\n        description {\n          value\n        }\n        membersOnly\n        nonMemberCta {\n          value\n        }\n        fullyBooked\n        signUpLink\n        location\n        locationLink\n        startAt\n        endAt\n        _updatedAt\n        _status\n      }\n      ... on ChallengeAcceptedArticleRecord {\n        id\n        path\n        image {\n          url\n          width\n          height\n        }\n      }\n      ... on ChallengeAcceptedNewsletterRecord {\n        id\n        path\n      }\n    }\n  }\n}": __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PersonDetailDocument"]
};
function gql(source) {
    return documents[source] ?? {};
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/graphql/cms/__generated__/gql/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$fragment$2d$masking$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/graphql/cms/__generated__/gql/fragment-masking.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$gql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/graphql/cms/__generated__/gql/gql.ts [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/components/Audio/hooks/useAudioQueue.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withInNativeApp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/apps/www/src/lib/withInNativeApp.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$react$2d$native$2f$CompareVersion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/react-native/CompareVersion.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/components/Audio/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/context/MeContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$hooks$2f$use$2d$persisted$2d$state$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/hooks/use-persisted-state/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hooks/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hooks/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$helpers$2f$OptimisticQueueResponseHelper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/components/Audio/helpers/OptimisticQueueResponseHelper.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$errors$2f$reportError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/errors/reportError.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__ = __turbopack_context__.i("[project]/node_modules/uuid/dist/esm-browser/v4.js [app-client] (ecmascript) <export default as v4>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/graphql/republik-api/__generated__/gql/graphql.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/apps/www/graphql/cms/__generated__/gql/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$fragment$2d$masking$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/graphql/cms/__generated__/gql/fragment-masking.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
const usePersistedAudioState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$hooks$2f$use$2d$persisted$2d$state$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('audio-player-local-state');
const MAX_QUEUE_SIZE = 20;
/**
 * useAudioQueue acts as a provider for the audio queue and all it's mutations.
 * Additionally, it provides the user-progress for all queued audio-items.
 *d
 * For users with an active membership, the queue is synchronized with the server.
 * For users without an active membership, the queue is persisted in local storage.
 * The local storage however doesn't allow for more than one item to be saved.
 */ const useAudioQueue = ()=>{
    _s();
    const { inNativeApp, inNativeAppVersion } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withInNativeApp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useInNativeApp"])();
    const { meLoading, me } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMe"])();
    const { data: meWithAudioQueue, loading: audioQueueIsLoading, error: audioQueueHasError, refetch: refetchAudioQueue } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AudioQueueQueryDocument"], {
        skip: meLoading || !me,
        errorPolicy: 'all'
    });
    const audioQueueItems = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$cms$2f$_$5f$generated_$5f2f$gql$2f$fragment$2d$masking$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFragmentData"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AudioQueueItemFragmentDoc"], meWithAudioQueue?.me?.audioQueue || []);
    const isLoading = meLoading || audioQueueIsLoading;
    const [localAudioItem, setLocalAudioItem] = usePersistedAudioState(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAudioQueue.useEffect": ()=>{
            if (audioQueueHasError) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$errors$2f$reportError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reportError"])('useAudioQueue', audioQueueHasError);
            }
        }
    }["useAudioQueue.useEffect"], [
        audioQueueHasError
    ]);
    /**
   *
   * @param cache
   * @param audioQueueItems
   */ const modifyApolloCacheWithUpdatedPlaylist = (cache, { data: { audioQueueItems } })=>{
        const data = cache.readQuery({
            query: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AudioQueueQueryDocument"]
        });
        if (data?.me) {
            cache.writeQuery({
                query: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AudioQueueQueryDocument"],
                data: {
                    me: {
                        ...data.me,
                        audioQueue: audioQueueItems
                    }
                }
            });
        }
    };
    /**
   * Cache update for mutations that only return Id's and sequence
   * Creates an updated audioqueue from the server response without
   * fetching the full audioqueue data from the server.
   */ const updateCacheWithMinimalData = (cache, { data: { audioQueueItems } })=>{
        const data = cache.readQuery({
            query: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AudioQueueQueryDocument"]
        });
        if (!data?.me) return;
        const cachedItemsById = new Map((data.me.audioQueue || []).map((item)=>[
                item.id,
                item
            ]));
        const updatedQueue = audioQueueItems.map((serverItem)=>cachedItemsById.get(serverItem.id)).filter(Boolean) // Remove any items not found in cache
        ;
        cache.writeQuery({
            query: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AudioQueueQueryDocument"],
            data: {
                me: {
                    ...data.me,
                    audioQueue: updatedQueue
                }
            }
        });
    };
    const [addAudioQueueItem] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AddAudioQueueItemsDocument"], {
        update: modifyApolloCacheWithUpdatedPlaylist
    });
    const [removeAudioQueueItem] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RemoveAudioQueueItemDocument"], {
        update: updateCacheWithMinimalData
    });
    const [moveAudioQueueItem] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MoveAudioQueueItemDocument"], {
        update: updateCacheWithMinimalData
    });
    const [clearAudioQueue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ClearAudioQueueDocument"], {
        update: updateCacheWithMinimalData
    });
    const [reorderAudioQueue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ReorderAudioQueueDocument"], {
        update: updateCacheWithMinimalData
    });
    /**
   * Add an audio item to the queue or to the local storage if the user is not a member.
   * @param item partial of a document with all the required meta fields
   * @param position position in the queue. To push to front of queue, pass 1
   */ const handleAddQueueItem = async (item, position)=>{
        if (me) {
            // Enforce queue limit by removing oldest item (end of queue) before adding
            if (audioQueueItems.length >= MAX_QUEUE_SIZE) {
                const lastItem = audioQueueItems[audioQueueItems.length - 1];
                await removeAudioQueueItem({
                    variables: {
                        id: lastItem.id
                    }
                });
            }
            return addAudioQueueItem({
                variables: {
                    entity: {
                        id: item.id,
                        type: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AudioQueueEntityType"].Document
                    },
                    sequence: position
                }
            });
        } else {
            const mockAudioQueueItem = {
                id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uuid$2f$dist$2f$esm$2d$browser$2f$v4$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__v4$3e$__["v4"])(),
                document: item,
                sequence: 0
            };
            setLocalAudioItem(mockAudioQueueItem);
            return Promise.resolve({
                data: {
                    audioQueueItems: [
                        mockAudioQueueItem
                    ]
                }
            });
        }
    };
    /**
   * Remove an item from the queue or from the local storage if the user is not a member.
   * @param audioItemId
   */ const handleRemoveQueueItem = async (audioItemId)=>{
        if (me) {
            return removeAudioQueueItem({
                variables: {
                    id: audioItemId
                },
                optimisticResponse: {
                    audioQueueItems: audioQueueItems.filter((item)=>item.id !== audioItemId)
                }
            });
        } else {
            setLocalAudioItem(null);
            return Promise.resolve({
                data: {
                    audioQueueItems: []
                }
            });
        }
    };
    const handleMoveQueueItem = async (audioItemId, position)=>{
        if (me) {
            return moveAudioQueueItem({
                variables: {
                    id: audioItemId,
                    sequence: position
                },
                optimisticResponse: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$helpers$2f$OptimisticQueueResponseHelper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].makeMoveQueueItemResponse(audioQueueItems, audioItemId, position)
            });
        } else {
            return Promise.resolve({
                data: {
                    audioQueueItems: [
                        localAudioItem
                    ].filter(Boolean)
                }
            });
        }
    };
    const handleClearQueue = async ()=>{
        if (me) {
            return clearAudioQueue({
                optimisticResponse: {
                    audioQueueItems: []
                }
            });
        } else {
            setLocalAudioItem(null);
            return Promise.resolve({
                data: {
                    audioQueueItems: []
                }
            });
        }
    };
    const handleQueueReorder = async (reorderedQueue)=>{
        if (me) {
            return reorderAudioQueue({
                variables: {
                    ids: reorderedQueue.map(({ id })=>id)
                },
                optimisticResponse: {
                    audioQueueItems: reorderedQueue.map((item, index)=>({
                            ...item,
                            sequence: index + 1,
                            __typename: 'AudioQueueItem'
                        }))
                }
            });
        }
        return Promise.resolve({
            data: {
                audioQueueItems: [
                    localAudioItem
                ].filter(Boolean)
            }
        });
    };
    function checkIfHeadOfQueue(documentId) {
        if (!me && localAudioItem?.document?.id === documentId) {
            return localAudioItem;
        }
        if (audioQueueItems[0]?.document?.id === documentId) {
            return audioQueueItems[0];
        }
    }
    function checkIfInQueue(documentId) {
        if (!me && localAudioItem?.document?.id === documentId) {
            return localAudioItem;
        }
        return audioQueueItems.find((audioQueueItem)=>audioQueueItem.document?.id === documentId);
    }
    function getAudioQueueItemIndex(documentId) {
        if (!me && localAudioItem?.document?.id === documentId) {
            return 0;
        }
        return audioQueueItems.findIndex((item)=>item.document?.id === documentId);
    }
    const resolvedQueue = !me ? [
        localAudioItem
    ].filter(Boolean) : meWithAudioQueue ? audioQueueItems ?? [] : null;
    // In case faulty audio queue items are in the queue, remove them
    resolvedQueue?.filter((item)=>!item.document?.meta?.audioSource).forEach((item)=>handleRemoveQueueItem(item.id));
    return {
        audioQueue: resolvedQueue?.filter((item)=>item.document?.meta?.audioSource),
        audioQueueIsLoading: isLoading,
        audioQueueHasError: !me ? null : audioQueueHasError,
        refetchAudioQueue: !me ? ()=>null : refetchAudioQueue,
        addAudioQueueItem: handleAddQueueItem,
        removeAudioQueueItem: handleRemoveQueueItem,
        moveAudioQueueItem: handleMoveQueueItem,
        clearAudioQueue: handleClearQueue,
        reorderAudioQueue: handleQueueReorder,
        isAudioQueueAvailable: !inNativeApp || inNativeApp && // in app with non legacy version
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$react$2d$native$2f$CompareVersion$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(inNativeAppVersion, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NEW_AUDIO_API_VERSION"]) >= 0,
        checkIfHeadOfQueue,
        checkIfInQueue,
        getAudioQueueItemIndex
    };
};
_s(useAudioQueue, "Y+t2Aa5rKwK00m+T/lTJl9CnzdA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withInNativeApp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useInNativeApp"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMe"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"],
        usePersistedAudioState,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const __TURBOPACK__default__export__ = useAudioQueue;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/components/Audio/types/AudioActionTracking.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * All player action locations to track
 */ __turbopack_context__.s([
    "AudioPlayerActions",
    ()=>AudioPlayerActions,
    "AudioPlayerLocations",
    ()=>AudioPlayerLocations
]);
var AudioPlayerLocations = /*#__PURE__*/ function(AudioPlayerLocations) {
    AudioPlayerLocations["AUDIO_PLAYER"] = "AudioPlayer";
    AudioPlayerLocations["FRONT"] = "Front";
    AudioPlayerLocations["ACTION_BAR"] = "ActionBar";
    AudioPlayerLocations["ARTICLE"] = "Article";
    AudioPlayerLocations["ARTICLE_PLAYER"] = "ArticlePlayer";
    return AudioPlayerLocations;
}({});
var AudioPlayerActions = /*#__PURE__*/ function(AudioPlayerActions) {
    AudioPlayerActions["PLAY_TRACK"] = "playTrack";
    AudioPlayerActions["PLAY_SYNTHETIC"] = "playSynthetic";
    AudioPlayerActions["ADD_QUEUE_ITEM"] = "addQueueItem";
    AudioPlayerActions["REMOVE_QUEUE_ITEM"] = "removeQueueItem";
    AudioPlayerActions["ADD_QUEUE_HEAD_ITEM"] = "addQueueHeadItem";
    AudioPlayerActions["ADD_NEXT_QUEUE_ITEM"] = "addQueueNextItem";
    AudioPlayerActions["QUEUE_ADVANCE"] = "queueAdvance";
    AudioPlayerActions["QUEUE_ENDED"] = "queueEnded";
    AudioPlayerActions["SKIP_TO_NEXT"] = "trackSkipped";
    AudioPlayerActions["PLAYBACK_RATE_CHANGED"] = "playbackRateChanged";
    AudioPlayerActions["ERROR"] = "error";
    AudioPlayerActions["ILLEGAL_PROGRESS_UPDATE"] = "illegalProgressUpdate";
    AudioPlayerActions["DOWNLOAD_TRACK"] = "downloadTrack";
    AudioPlayerActions["SUBSCRIBE_READ_ALOUD"] = "subscribeReadAloud";
    AudioPlayerActions["UNSUBSCRIBE_READ_ALOUD"] = "unsubscribeReadAloud";
    return AudioPlayerActions;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/components/Audio/AudioProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AudioContext",
    ()=>AudioContext,
    "AudioContextEvent",
    ()=>AudioContextEvent,
    "AudioEventEmitter",
    ()=>AudioEventEmitter,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useAudioContext",
    ()=>useAudioContext,
    "useAudioContextEvent",
    ()=>useAudioContextEvent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$hooks$2f$use$2d$persisted$2d$state$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/hooks/use-persisted-state/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withInNativeApp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/apps/www/src/lib/withInNativeApp.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$MediaProgress$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/components/Audio/MediaProgress.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$hooks$2f$useAudioQueue$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/components/Audio/hooks/useAudioQueue.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$events$2f$events$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/events/events.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$types$2f$AudioActionTracking$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/components/Audio/types/AudioActionTracking.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
var AudioContextEvent = /*#__PURE__*/ function(AudioContextEvent) {
    AudioContextEvent["TOGGLE_PLAYER"] = "togglePlayer";
    AudioContextEvent["TOGGLE_PLAYBACK"] = "togglePlayback";
    AudioContextEvent["ADD_AUDIO_QUEUE_ITEM"] = "addAudioQueueItem";
    AudioContextEvent["REMOVE_AUDIO_QUEUE_ITEM"] = "removeAudioQueueItem";
    return AudioContextEvent;
}({});
const AudioEventEmitter = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$events$2f$events$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]();
function useAudioContextEvent(eventName, callback) {
    _s();
    const savedCallback = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(callback);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAudioContextEvent.useEffect": ()=>{
            savedCallback.current = callback;
        }
    }["useAudioContextEvent.useEffect"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAudioContextEvent.useEffect": ()=>{
            const handler = {
                "useAudioContextEvent.useEffect.handler": (eventData)=>{
                    return savedCallback?.current(eventData);
                }
            }["useAudioContextEvent.useEffect.handler"];
            AudioEventEmitter.addListener(eventName, handler);
            return ({
                "useAudioContextEvent.useEffect": ()=>{
                    AudioEventEmitter.removeListener(eventName, handler);
                }
            })["useAudioContextEvent.useEffect"];
        }
    }["useAudioContextEvent.useEffect"], [
        eventName
    ]);
}
_s(useAudioContextEvent, "dqNZMqbncP+HtqBlD20aSNv0Ugk=");
const notImplemented = ()=>{
    throw new Error('Not implemented');
};
const AudioContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    audioPlayerVisible: false,
    isExpanded: false,
    isPlaying: false,
    setAudioPlayerVisible: notImplemented,
    setIsExpanded: notImplemented,
    setIsPlaying: notImplemented,
    toggleAudioPlayer: notImplemented,
    toggleAudioPlayback: notImplemented,
    checkIfActivePlayerItem: notImplemented,
    addAudioQueueItem: notImplemented,
    removeAudioQueueItem: notImplemented,
    onCloseAudioPlayer: notImplemented,
    activePlayerItem: null,
    setActivePlayerItem: notImplemented,
    legacyPlayerItem: undefined,
    autoPlayActive: false
});
const useAudioContext = ()=>{
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AudioContext);
};
_s1(useAudioContext, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
const usePersistedLegacyPlayerItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$hooks$2f$use$2d$persisted$2d$state$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('republik-audioplayer-audiostate');
const AudioProvider = ({ children })=>{
    _s2();
    const { inNativeApp, inNativeIOSApp } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withInNativeApp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useInNativeApp"])();
    const [activePlayerItem, setActivePlayerItem] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [legacyPlayerItem, setLegacyPlayerItem] = usePersistedLegacyPlayerItem(undefined);
    const [autoPlayAudioPlayerItem, setAutoPlayAudioPlayerItem] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [audioPlayerVisible, setAudioPlayerVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isExpanded, setIsExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isPlaying, setIsPlaying] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const clearTimeoutId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { isAudioQueueAvailable } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$hooks$2f$useAudioQueue$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const { getMediaProgress } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$MediaProgress$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMediaProgress"])();
    const toggleAudioPlayer = async (playerItem, location)=>{
        const { meta: { audioSource, path, title } } = playerItem;
        const url = (inNativeIOSApp && audioSource.aac || audioSource.mp3 || audioSource.ogg)?.trim();
        if (!url) {
            return;
        }
        const mediaId = audioSource.mediaId;
        if (isAudioQueueAvailable) {
            AudioEventEmitter.emit("togglePlayer", {
                item: playerItem,
                location: location || __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$types$2f$AudioActionTracking$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AudioPlayerLocations"].AUDIO_PLAYER
            });
        } else {
            if (inNativeApp) {
                let currentTime;
                if (mediaId) {
                    currentTime = await getMediaProgress({
                        mediaId
                    });
                }
                // The below constructed payload is required by the legacy in-app
                // audio player.
                const payload = {
                    audioSource,
                    url,
                    title,
                    sourcePath: path,
                    mediaId
                };
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withInNativeApp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["postMessage"])({
                    type: 'play-audio',
                    payload: {
                        ...payload,
                        currentTime
                    }
                });
            }
            setLegacyPlayerItem(playerItem);
            setAutoPlayAudioPlayerItem(playerItem);
        }
        clearTimeout(clearTimeoutId.current);
    };
    const onCloseAudioPlayer = ()=>{
        setAudioPlayerVisible(false);
        clearTimeoutId.current = setTimeout(()=>{
            setActivePlayerItem(undefined);
            setLegacyPlayerItem(undefined);
        }, 300);
    };
    const addAudioQueueItem = (item, position)=>{
        AudioEventEmitter.emit("addAudioQueueItem", {
            item,
            position
        });
    };
    const removeAudioQueueItem = (audioQueueItemId)=>{
        AudioEventEmitter.emit("removeAudioQueueItem", audioQueueItemId);
    };
    const toggleAudioPlayback = ()=>{
        AudioEventEmitter.emit("togglePlayback");
    };
    const checkIfActivePlayerItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "AudioProvider.useMemo[checkIfActivePlayerItem]": ()=>({
                "AudioProvider.useMemo[checkIfActivePlayerItem]": (documentId)=>{
                    return activePlayerItem?.document?.id === documentId;
                }
            })["AudioProvider.useMemo[checkIfActivePlayerItem]"]
    }["AudioProvider.useMemo[checkIfActivePlayerItem]"], [
        activePlayerItem
    ]);
    // Legacy in-app audio player this will open up the player for the last played element
    // This may be deleted sometime in the future once every app version below v2.2.0 is discontinued
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AudioProvider.useEffect": ()=>{
            setAudioPlayerVisible(!!legacyPlayerItem);
        }
    }["AudioProvider.useEffect"], [
        legacyPlayerItem
    ]);
    // This clears the persisted active-player state in the browser or the native app.
    // If a value was persisted the above effect kept on opening the player.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AudioProvider.useEffect": ()=>{
            if (isAudioQueueAvailable) {
                setLegacyPlayerItem(null);
            }
        }
    }["AudioProvider.useEffect"], [
        isAudioQueueAvailable
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AudioContext.Provider, {
        value: {
            activePlayerItem,
            setActivePlayerItem,
            legacyPlayerItem,
            audioPlayerVisible,
            setAudioPlayerVisible,
            isExpanded,
            setIsExpanded,
            isPlaying,
            setIsPlaying,
            autoPlayActive: autoPlayAudioPlayerItem?.id === activePlayerItem?.document.id,
            toggleAudioPlayer,
            toggleAudioPlayback,
            checkIfActivePlayerItem,
            addAudioQueueItem,
            removeAudioQueueItem,
            onCloseAudioPlayer
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/apps/www/src/components/Audio/AudioProvider.tsx",
        lineNumber: 228,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s2(AudioProvider, "JdhgUIgMykpZ4+23mCqIb2OLMpI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$withInNativeApp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useInNativeApp"],
        usePersistedLegacyPlayerItem,
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$hooks$2f$useAudioQueue$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$MediaProgress$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMediaProgress"]
    ];
});
_c = AudioProvider;
const __TURBOPACK__default__export__ = AudioProvider;
var _c;
__turbopack_context__.k.register(_c, "AudioProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/layout/pull-to-refresh/index.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PullToRefresh",
    ()=>PullToRefresh
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/icons/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$AudioProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/components/Audio/AudioProvider.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
// eslint-disable-next-line no-unused-vars
var IndicatorState = /*#__PURE__*/ function(IndicatorState) {
    IndicatorState[IndicatorState["HIDDEN"] = 0] = "HIDDEN";
    IndicatorState[IndicatorState["PULLING"] = 1] = "PULLING";
    IndicatorState[IndicatorState["TRIGGERED"] = 2] = "TRIGGERED";
    IndicatorState[IndicatorState["LOADING"] = 3] = "LOADING";
    return IndicatorState;
}(IndicatorState || {});
/**
 * Hook to add a pull-to-refresh behavior to a container.
 * @param ref elementRef of the container
 * @param callback that is called when the user pulls down the container
 * @returns
 *
 * This hooks is based on the following article:
 * https://www.strictmode.io/articles/react-pull-to-refresh
 */ function usePullToRefresh(ref, callback, options = {
    maxPullDistance: 240,
    triggerThreshold: 240,
    pullResistance: 0.4,
    isDisabled: false
}) {
    _s();
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    const callbackRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        "usePullToRefresh.useRef[callbackRef]": ()=>{}
    }["usePullToRefresh.useRef[callbackRef]"]);
    const { maxPullDistance, triggerThreshold, pullResistance, isDisabled } = options;
    const appr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "usePullToRefresh.useMemo[appr]": ()=>({
                "usePullToRefresh.useMemo[appr]": (x)=>{
                    return maxPullDistance * (1 - Math.exp(-pullResistance * x / maxPullDistance));
                }
            })["usePullToRefresh.useMemo[appr]"]
    }["usePullToRefresh.useMemo[appr]"], [
        maxPullDistance,
        pullResistance
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePullToRefresh.useEffect": ()=>{
            callbackRef.current = callback;
        }
    }["usePullToRefresh.useEffect"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePullToRefresh.useEffect": ()=>{
            const element = ref.current;
            if (!element) {
                return;
            }
            function handleTouchStart(startEvent) {
                const el = ref.current;
                if (!el || window.scrollY !== 0 || isDisabled) return;
                // get the initial Y position
                const initialY = startEvent.touches[0].clientY;
                el.style.transition = null;
                el.addEventListener('touchmove', handleTouchMove, {
                    passive: true
                });
                el.addEventListener('touchend', handleTouchEnd);
                document.documentElement.style.overscrollBehaviorY = 'none';
                document.documentElement.style.setProperty('--pull-to-refresh-progress', '0');
                function handleTouchMove(moveEvent) {
                    const el = ref.current;
                    if (!el) return;
                    // get the current Y position
                    const currentY = moveEvent.touches[0].clientY;
                    const dy = currentY - initialY;
                    if (dy < 0) {
                        return;
                    }
                    const progress = Math.min(1, dy / triggerThreshold);
                    document.documentElement.style.setProperty('--pull-to-refresh-progress', progress.toString());
                    if (dy > triggerThreshold * 0.1) {
                        document.documentElement.setAttribute('data-pull-to-refresh-state', 'pulling');
                    }
                    if (dy <= triggerThreshold) {
                        el.style.transform = `translateY(${appr(dy)}px)`;
                    }
                }
                function resetState() {
                    const el = ref.current;
                    if (!el) return;
                    // Return pulled element to original position
                    el.style.transform = 'translateY(0)';
                    el.style.transition = 'transform 0.2s ease-in-out';
                    // Clean up attributes on <html> element
                    document.documentElement.removeAttribute('data-pull-to-refresh-state');
                    document.documentElement.style.overscrollBehaviorY = null;
                    document.documentElement.style.setProperty('--pull-to-refresh-progress', '');
                }
                function handleTouchEnd(endEvent) {
                    const el = ref.current;
                    if (!el) return;
                    const currentY = endEvent.changedTouches[0].clientY;
                    const dy = currentY - initialY;
                    if (dy > triggerThreshold) {
                        document.documentElement.setAttribute('data-pull-to-refresh-state', 'loading');
                        // Trigger refresh
                        callbackRef?.current();
                        // Let animation run for 1s
                        setTimeout(resetState, 1000);
                    } else {
                        resetState();
                    }
                    // cleanup
                    el.removeEventListener('touchmove', handleTouchMove);
                    el.removeEventListener('touchend', handleTouchEnd);
                }
            }
            window.addEventListener('touchstart', handleTouchStart, {
                passive: true
            });
            return ({
                "usePullToRefresh.useEffect": ()=>{
                    window.removeEventListener('touchstart', handleTouchStart);
                }
            })["usePullToRefresh.useEffect"];
        }
    }["usePullToRefresh.useEffect"], [
        ref.current,
        callbackRef,
        appr,
        triggerThreshold,
        isDisabled
    ]);
}
_s(usePullToRefresh, "bLOGAcjXnl6jE78Ysohq9wwiNrU=");
function PullToRefresh({ children, ...props }) {
    _s1();
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { isExpanded: audioPlayerExpanded } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$AudioProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAudioContext"])();
    const { refresh } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const pullToRefresh = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PullToRefresh.useCallback[pullToRefresh]": ()=>{
            refresh();
        }
    }["PullToRefresh.useCallback[pullToRefresh]"], [
        refresh
    ]);
    usePullToRefresh(ref, pullToRefresh, {
        isDisabled: audioPlayerExpanded
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            position: 'relative'
        }),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    position: 'absolute',
                    top: '0',
                    left: '0',
                    width: '100%',
                    py: '4',
                    backgroundColor: 'transparent',
                    touchAction: 'none',
                    pointerEvents: 'none',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: 'opacity 0.2s ease-in-out',
                    zIndex: 10
                }),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconRefresh"], {
                    size: "2rem",
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                        transform: 'scale(0.5) rotate(0deg)',
                        opacity: 0,
                        '[data-pull-to-refresh-state="pulling"] &': {
                            opacity: `calc(var(--pull-to-refresh-progress, 0) * 100%)`,
                            transform: `scale(calc(0.5 + calc(var(--pull-to-refresh-progress, 0) * 0.5))) rotate(calc(var(--pull-to-refresh-progress, 0) * 360deg))`,
                            transition: 'transform 0.1s ease-out'
                        },
                        '[data-pull-to-refresh-state="loading"] &': {
                            animation: 'spin',
                            opacity: 1
                        }
                    })
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/components/layout/pull-to-refresh/index.tsx",
                    lineNumber: 198,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/layout/pull-to-refresh/index.tsx",
                lineNumber: 181,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: ref,
                ...props,
                children: children
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/layout/pull-to-refresh/index.tsx",
                lineNumber: 215,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/components/layout/pull-to-refresh/index.tsx",
        lineNumber: 180,
        columnNumber: 5
    }, this);
}
_s1(PullToRefresh, "XUi5rLZucEHbbypzg4nS+eZ9Im8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$components$2f$Audio$2f$AudioProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAudioContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        usePullToRefresh
    ];
});
_c = PullToRefresh;
var _c;
__turbopack_context__.k.register(_c, "PullToRefresh");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# debugId=4a10a907-55f5-a504-4c2c-a6612f2cff2a
//# sourceMappingURL=_0~i_fc9._.js.map