;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="17b6eba5-3d25-da89-f058-61ebbbb8110c")}catch(e){}}();
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/www/graphql/republik-api/__generated__/gql/graphql.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* eslint-disable */ __turbopack_context__.s([
    "AccessRole",
    ()=>AccessRole,
    "AccessTokenScope",
    ()=>AccessTokenScope,
    "AcknowledgeCtaDocument",
    ()=>AcknowledgeCtaDocument,
    "Action",
    ()=>Action,
    "ActiveMagazineSubscriptionDocument",
    ()=>ActiveMagazineSubscriptionDocument,
    "AddAudioQueueItemsDocument",
    ()=>AddAudioQueueItemsDocument,
    "ArticleTeaserDocument",
    ()=>ArticleTeaserDocument,
    "AudioQueueEntityType",
    ()=>AudioQueueEntityType,
    "AudioQueueItemFragmentDoc",
    ()=>AudioQueueItemFragmentDoc,
    "AudioQueueQueryDocument",
    ()=>AudioQueueQueryDocument,
    "AudioSourceKind",
    ()=>AudioSourceKind,
    "AuthorizeSessionDocument",
    ()=>AuthorizeSessionDocument,
    "Badge",
    ()=>Badge,
    "CaNewsletterDocument",
    ()=>CaNewsletterDocument,
    "CampaignReferralsDocument",
    ()=>CampaignReferralsDocument,
    "CancelMagazineSubscriptionDocument",
    ()=>CancelMagazineSubscriptionDocument,
    "CancelUpgradeMagazineSubscriptionDocument",
    ()=>CancelUpgradeMagazineSubscriptionDocument,
    "CancellationCategoriesDocument",
    ()=>CancellationCategoriesDocument,
    "CancellationCategoryType",
    ()=>CancellationCategoryType,
    "CheckoutSessionStatus",
    ()=>CheckoutSessionStatus,
    "CheckoutUiMode",
    ()=>CheckoutUiMode,
    "ClearAudioQueueDocument",
    ()=>ClearAudioQueueDocument,
    "ClearProgressDocument",
    ()=>ClearProgressDocument,
    "CommentFeaturedTarget",
    ()=>CommentFeaturedTarget,
    "CommentVote",
    ()=>CommentVote,
    "CompanyName",
    ()=>CompanyName,
    "ContributorOrderField",
    ()=>ContributorOrderField,
    "CreateStripeCustomerPortalSessionDocument",
    ()=>CreateStripeCustomerPortalSessionDocument,
    "DerivativeStatus",
    ()=>DerivativeStatus,
    "DerivativeType",
    ()=>DerivativeType,
    "DiscussionNotificationOption",
    ()=>DiscussionNotificationOption,
    "DiscussionOrder",
    ()=>DiscussionOrder,
    "DocumenSchemaType",
    ()=>DocumenSchemaType,
    "DocumentRecommendationsDocument",
    ()=>DocumentRecommendationsDocument,
    "DocumentTextLengths",
    ()=>DocumentTextLengths,
    "EmbedType",
    ()=>EmbedType,
    "EventObjectType",
    ()=>EventObjectType,
    "Field",
    ()=>Field,
    "FollowableAuthorDocument",
    ()=>FollowableAuthorDocument,
    "FollowableDocumentDocument",
    ()=>FollowableDocumentDocument,
    "GenderEnum",
    ()=>GenderEnum,
    "GetCompleteFrontOverviewDocument",
    ()=>GetCompleteFrontOverviewDocument,
    "GetDocumentProgressDocument",
    ()=>GetDocumentProgressDocument,
    "GetFrontOverviewYearDocument",
    ()=>GetFrontOverviewYearDocument,
    "LatestArticlesDocument",
    ()=>LatestArticlesDocument,
    "MagazineSubscriptionStatus",
    ()=>MagazineSubscriptionStatus,
    "MagazineSubscriptionType",
    ()=>MagazineSubscriptionType,
    "MeDocument",
    ()=>MeDocument,
    "MembershipPeriodKind",
    ()=>MembershipPeriodKind,
    "MembershipTypeInterval",
    ()=>MembershipTypeInterval,
    "MoveAudioQueueItemDocument",
    ()=>MoveAudioQueueItemDocument,
    "MutationType",
    ()=>MutationType,
    "MyBelongingsDocument",
    ()=>MyBelongingsDocument,
    "MyCallToActionsDocument",
    ()=>MyCallToActionsDocument,
    "NewsletterName",
    ()=>NewsletterName,
    "NewsletterSettingsDocument",
    ()=>NewsletterSettingsDocument,
    "NewslettersResubscribeDocument",
    ()=>NewslettersResubscribeDocument,
    "NextReadDocumentFieldsFragmentDoc",
    ()=>NextReadDocumentFieldsFragmentDoc,
    "NextReadsBookmarksDocument",
    ()=>NextReadsBookmarksDocument,
    "NextReadsDocument",
    ()=>NextReadsDocument,
    "NotificationChannel",
    ()=>NotificationChannel,
    "OfferAvailability",
    ()=>OfferAvailability,
    "OnboardingDocumentsDocument",
    ()=>OnboardingDocumentsDocument,
    "OrderDirection",
    ()=>OrderDirection,
    "OsType",
    ()=>OsType,
    "PackageGroup",
    ()=>PackageGroup,
    "PastAccessGrantsDocument",
    ()=>PastAccessGrantsDocument,
    "PaymentMethod",
    ()=>PaymentMethod,
    "PaymentSourceStatus",
    ()=>PaymentSourceStatus,
    "PaymentSourceWallet",
    ()=>PaymentSourceWallet,
    "PaymentStatus",
    ()=>PaymentStatus,
    "PaynoteMode",
    ()=>PaynoteMode,
    "PendingAppSignInDocument",
    ()=>PendingAppSignInDocument,
    "Permission",
    ()=>Permission,
    "PledgeStatus",
    ()=>PledgeStatus,
    "PortraitSize",
    ()=>PortraitSize,
    "ProgressState",
    ()=>ProgressState,
    "QrCodeErrorCorrectionLevel",
    ()=>QrCodeErrorCorrectionLevel,
    "QuestionTypeRangeKind",
    ()=>QuestionTypeRangeKind,
    "QuestionnaireDocument",
    ()=>QuestionnaireDocument,
    "ReactivateMagazineSubscriptionDocument",
    ()=>ReactivateMagazineSubscriptionDocument,
    "ReferralCodeValidationResult",
    ()=>ReferralCodeValidationResult,
    "RemoveAudioQueueItemDocument",
    ()=>RemoveAudioQueueItemDocument,
    "RemoveDocumentProgressDocument",
    ()=>RemoveDocumentProgressDocument,
    "ReorderAudioQueueDocument",
    ()=>ReorderAudioQueueDocument,
    "RepoChangeMutationType",
    ()=>RepoChangeMutationType,
    "RepoFileStatus",
    ()=>RepoFileStatus,
    "RepoOrderField",
    ()=>RepoOrderField,
    "RepoPhaseKey",
    ()=>RepoPhaseKey,
    "RequestAccessDocument",
    ()=>RequestAccessDocument,
    "RevokeConsentDocument",
    ()=>RevokeConsentDocument,
    "RssFeedDocument",
    ()=>RssFeedDocument,
    "SearchProcessor",
    ()=>SearchProcessor,
    "SearchSortKey",
    ()=>SearchSortKey,
    "SearchTypes",
    ()=>SearchTypes,
    "SetDiscussionPreferencesDocument",
    ()=>SetDiscussionPreferencesDocument,
    "SetOnboardedDocument",
    ()=>SetOnboardedDocument,
    "Sex",
    ()=>Sex,
    "SignInDocument",
    ()=>SignInDocument,
    "SignInTokenType",
    ()=>SignInTokenType,
    "SignUpForNewsletterDocument",
    ()=>SignUpForNewsletterDocument,
    "SitemapByYearDocument",
    ()=>SitemapByYearDocument,
    "SubmissionsSortBy",
    ()=>SubmissionsSortBy,
    "SubmitConsentDocument",
    ()=>SubmitConsentDocument,
    "SubmitQuestionnaireAnswerDocument",
    ()=>SubmitQuestionnaireAnswerDocument,
    "SubscribeDocument",
    ()=>SubscribeDocument,
    "SubscriptionFieldsFragmentDoc",
    ()=>SubscriptionFieldsFragmentDoc,
    "SubscriptionObjectType",
    ()=>SubscriptionObjectType,
    "TransactionsDocument",
    ()=>TransactionsDocument,
    "UnauthorizedSessionDocument",
    ()=>UnauthorizedSessionDocument,
    "UnsubscribeDocument",
    ()=>UnsubscribeDocument,
    "UpdateMagazineSubscriptionDonationDocument",
    ()=>UpdateMagazineSubscriptionDonationDocument,
    "UpdateNewsletterSubscriptionDocument",
    ()=>UpdateNewsletterSubscriptionDocument,
    "UpdateNewsletterSubscriptionWithMacDocument",
    ()=>UpdateNewsletterSubscriptionWithMacDocument,
    "UpsertDocumentProgressDocument",
    ()=>UpsertDocumentProgressDocument
]);
var AccessRole = /*#__PURE__*/ function(AccessRole) {
    AccessRole["Admin"] = "ADMIN";
    AccessRole["Editor"] = "EDITOR";
    AccessRole["Member"] = "MEMBER";
    AccessRole["Public"] = "PUBLIC";
    return AccessRole;
}({});
var AccessTokenScope = /*#__PURE__*/ function(AccessTokenScope) {
    /** A token authorize a session (TTL: 5 days) */ AccessTokenScope["AuthorizeSession"] = "AUTHORIZE_SESSION";
    /** A token to use mutation claimCard (TTL: 90 days) */ AccessTokenScope["ClaimCard"] = "CLAIM_CARD";
    /** A token to access me.customPackages (TTL: 90 days) */ AccessTokenScope["CustomPledge"] = "CUSTOM_PLEDGE";
    /** A token to access me.customPackages (TTL: 120 days) */ AccessTokenScope["CustomPledgeExtended"] = "CUSTOM_PLEDGE_EXTENDED";
    /** A token access a invoices (TTL: 5 days) */ AccessTokenScope["Invoice"] = "INVOICE";
    /** A token to access a users name and portrait (TTL: 30 days) */ AccessTokenScope["NowYouSeeMe"] = "NOW_YOU_SEE_ME";
    return AccessTokenScope;
}({});
var Action = /*#__PURE__*/ function(Action) {
    Action["Create"] = "create";
    Action["Delete"] = "delete";
    return Action;
}({});
var AudioQueueEntityType = /*#__PURE__*/ function(AudioQueueEntityType) {
    AudioQueueEntityType["Document"] = "Document";
    return AudioQueueEntityType;
}({});
var AudioSourceKind = /*#__PURE__*/ function(AudioSourceKind) {
    AudioSourceKind["Podcast"] = "podcast";
    AudioSourceKind["ReadAloud"] = "readAloud";
    AudioSourceKind["SyntheticReadAloud"] = "syntheticReadAloud";
    return AudioSourceKind;
}({});
var Badge = /*#__PURE__*/ function(Badge) {
    Badge["Crowdfunder"] = "CROWDFUNDER";
    Badge["Freelancer"] = "FREELANCER";
    Badge["Patron"] = "PATRON";
    Badge["Staff"] = "STAFF";
    return Badge;
}({});
var CancellationCategoryType = /*#__PURE__*/ function(CancellationCategoryType) {
    CancellationCategoryType["CrowfundingOnly"] = "CROWFUNDING_ONLY";
    CancellationCategoryType["EditoralNarcissistic"] = "EDITORAL_NARCISSISTIC";
    CancellationCategoryType["Editorial"] = "EDITORIAL";
    CancellationCategoryType["Expections"] = "EXPECTIONS";
    CancellationCategoryType["LoginTech"] = "LOGIN_TECH";
    CancellationCategoryType["NoAutoPay"] = "NO_AUTO_PAY";
    CancellationCategoryType["NoMoney"] = "NO_MONEY";
    CancellationCategoryType["NoTime"] = "NO_TIME";
    CancellationCategoryType["Other"] = "OTHER";
    CancellationCategoryType["Paper"] = "PAPER";
    CancellationCategoryType["RarelyRead"] = "RARELY_READ";
    CancellationCategoryType["SeveralReasons"] = "SEVERAL_REASONS";
    CancellationCategoryType["System"] = "SYSTEM";
    CancellationCategoryType["TooExpensive"] = "TOO_EXPENSIVE";
    CancellationCategoryType["TooMuchToRead"] = "TOO_MUCH_TO_READ";
    CancellationCategoryType["UncertainFuture"] = "UNCERTAIN_FUTURE";
    CancellationCategoryType["Void"] = "VOID";
    return CancellationCategoryType;
}({});
var CheckoutSessionStatus = /*#__PURE__*/ function(CheckoutSessionStatus) {
    CheckoutSessionStatus["Complete"] = "complete";
    CheckoutSessionStatus["Expired"] = "expired";
    CheckoutSessionStatus["Open"] = "open";
    return CheckoutSessionStatus;
}({});
var CheckoutUiMode = /*#__PURE__*/ function(CheckoutUiMode) {
    CheckoutUiMode["Custom"] = "CUSTOM";
    CheckoutUiMode["Embedded"] = "EMBEDDED";
    CheckoutUiMode["Hosted"] = "HOSTED";
    return CheckoutUiMode;
}({});
var CommentFeaturedTarget = /*#__PURE__*/ function(CommentFeaturedTarget) {
    CommentFeaturedTarget["Default"] = "DEFAULT";
    CommentFeaturedTarget["Marketing"] = "MARKETING";
    return CommentFeaturedTarget;
}({});
var CommentVote = /*#__PURE__*/ function(CommentVote) {
    CommentVote["Down"] = "DOWN";
    CommentVote["Up"] = "UP";
    return CommentVote;
}({});
var CompanyName = /*#__PURE__*/ function(CompanyName) {
    CompanyName["ProjectR"] = "PROJECT_R";
    CompanyName["Republik"] = "REPUBLIK";
    return CompanyName;
}({});
var ContributorOrderField = /*#__PURE__*/ function(ContributorOrderField) {
    ContributorOrderField["CreatedAt"] = "createdAt";
    ContributorOrderField["Name"] = "name";
    ContributorOrderField["UpdatedAt"] = "updatedAt";
    return ContributorOrderField;
}({});
var DerivativeStatus = /*#__PURE__*/ function(DerivativeStatus) {
    DerivativeStatus["Destroyed"] = "Destroyed";
    DerivativeStatus["Failure"] = "Failure";
    DerivativeStatus["Pending"] = "Pending";
    DerivativeStatus["Ready"] = "Ready";
    return DerivativeStatus;
}({});
var DerivativeType = /*#__PURE__*/ function(DerivativeType) {
    DerivativeType["SyntheticReadAloud"] = "SyntheticReadAloud";
    return DerivativeType;
}({});
var DiscussionNotificationOption = /*#__PURE__*/ function(DiscussionNotificationOption) {
    DiscussionNotificationOption["All"] = "ALL";
    DiscussionNotificationOption["MyChildren"] = "MY_CHILDREN";
    DiscussionNotificationOption["None"] = "NONE";
    return DiscussionNotificationOption;
}({});
var DiscussionOrder = /*#__PURE__*/ function(DiscussionOrder) {
    DiscussionOrder["Auto"] = "AUTO";
    DiscussionOrder["Date"] = "DATE";
    DiscussionOrder["FeaturedAt"] = "FEATURED_AT";
    DiscussionOrder["Hot"] = "HOT";
    DiscussionOrder["Replies"] = "REPLIES";
    DiscussionOrder["Votes"] = "VOTES";
    return DiscussionOrder;
}({});
var DocumenSchemaType = /*#__PURE__*/ function(DocumenSchemaType) {
    DocumenSchemaType["Mdast"] = "mdast";
    /** @deprecated Not used anymore */ DocumenSchemaType["Slate"] = "slate";
    return DocumenSchemaType;
}({});
var DocumentTextLengths = /*#__PURE__*/ function(DocumentTextLengths) {
    DocumentTextLengths["Long"] = "LONG";
    DocumentTextLengths["Medium"] = "MEDIUM";
    DocumentTextLengths["Short"] = "SHORT";
    return DocumentTextLengths;
}({});
var EmbedType = /*#__PURE__*/ function(EmbedType) {
    EmbedType["TwitterEmbed"] = "TwitterEmbed";
    EmbedType["VimeoEmbed"] = "VimeoEmbed";
    EmbedType["YoutubeEmbed"] = "YoutubeEmbed";
    return EmbedType;
}({});
var EventObjectType = /*#__PURE__*/ function(EventObjectType) {
    EventObjectType["Comment"] = "Comment";
    EventObjectType["Document"] = "Document";
    EventObjectType["ReadAloud"] = "ReadAloud";
    return EventObjectType;
}({});
var Field = /*#__PURE__*/ function(Field) {
    Field["Avisierungstext"] = "avisierungstext";
    Field["Buchungsdatum"] = "buchungsdatum";
    Field["CreatedAt"] = "createdAt";
    Field["DueDate"] = "dueDate";
    Field["Email"] = "email";
    Field["FirstName"] = "firstName";
    Field["Gutschrift"] = "gutschrift";
    Field["Hidden"] = "hidden";
    Field["Hrid"] = "hrid";
    Field["LastName"] = "lastName";
    Field["Matched"] = "matched";
    Field["Method"] = "method";
    Field["Mitteilung"] = "mitteilung";
    Field["PaperInvoice"] = "paperInvoice";
    Field["Status"] = "status";
    Field["Total"] = "total";
    Field["UpdatedAt"] = "updatedAt";
    Field["Valuta"] = "valuta";
    Field["Verified"] = "verified";
    return Field;
}({});
var GenderEnum = /*#__PURE__*/ function(GenderEnum) {
    GenderEnum["D"] = "d";
    GenderEnum["F"] = "f";
    GenderEnum["M"] = "m";
    GenderEnum["Na"] = "na";
    return GenderEnum;
}({});
var MagazineSubscriptionStatus = /*#__PURE__*/ function(MagazineSubscriptionStatus) {
    MagazineSubscriptionStatus["Active"] = "active";
    MagazineSubscriptionStatus["Canceled"] = "canceled";
    MagazineSubscriptionStatus["Incomplete"] = "incomplete";
    MagazineSubscriptionStatus["IncompleteExpired"] = "incomplete_expired";
    MagazineSubscriptionStatus["PastDue"] = "past_due";
    MagazineSubscriptionStatus["Paused"] = "paused";
    MagazineSubscriptionStatus["Trialing"] = "trialing";
    MagazineSubscriptionStatus["Unpaid"] = "unpaid";
    return MagazineSubscriptionStatus;
}({});
var MagazineSubscriptionType = /*#__PURE__*/ function(MagazineSubscriptionType) {
    MagazineSubscriptionType["BenefactorSubscription"] = "BENEFACTOR_SUBSCRIPTION";
    MagazineSubscriptionType["MonthlySubscription"] = "MONTHLY_SUBSCRIPTION";
    MagazineSubscriptionType["YearlySubscription"] = "YEARLY_SUBSCRIPTION";
    return MagazineSubscriptionType;
}({});
var MembershipPeriodKind = /*#__PURE__*/ function(MembershipPeriodKind) {
    MembershipPeriodKind["Admin"] = "ADMIN";
    MembershipPeriodKind["Bonus"] = "BONUS";
    MembershipPeriodKind["Changeover"] = "CHANGEOVER";
    MembershipPeriodKind["Regular"] = "REGULAR";
    return MembershipPeriodKind;
}({});
var MembershipTypeInterval = /*#__PURE__*/ function(MembershipTypeInterval) {
    MembershipTypeInterval["Day"] = "day";
    MembershipTypeInterval["Month"] = "month";
    MembershipTypeInterval["Week"] = "week";
    MembershipTypeInterval["Year"] = "year";
    return MembershipTypeInterval;
}({});
var MutationType = /*#__PURE__*/ function(MutationType) {
    MutationType["Created"] = "CREATED";
    MutationType["Deleted"] = "DELETED";
    MutationType["Updated"] = "UPDATED";
    return MutationType;
}({});
var NewsletterName = /*#__PURE__*/ function(NewsletterName) {
    NewsletterName["Accomplice"] = "ACCOMPLICE";
    NewsletterName["Bab"] = "BAB";
    NewsletterName["Climate"] = "CLIMATE";
    NewsletterName["Daily"] = "DAILY";
    NewsletterName["Projectr"] = "PROJECTR";
    NewsletterName["Sunday"] = "SUNDAY";
    NewsletterName["Wdwww"] = "WDWWW";
    NewsletterName["Weekly"] = "WEEKLY";
    return NewsletterName;
}({});
var NotificationChannel = /*#__PURE__*/ function(NotificationChannel) {
    NotificationChannel["App"] = "APP";
    NotificationChannel["Email"] = "EMAIL";
    NotificationChannel["Web"] = "WEB";
    return NotificationChannel;
}({});
var OsType = /*#__PURE__*/ function(OsType) {
    OsType["Android"] = "android";
    OsType["Ios"] = "ios";
    return OsType;
}({});
var OfferAvailability = /*#__PURE__*/ function(OfferAvailability) {
    OfferAvailability["Purchasable"] = "PURCHASABLE";
    OfferAvailability["Unavailable"] = "UNAVAILABLE";
    OfferAvailability["UnavailableCurrent"] = "UNAVAILABLE_CURRENT";
    OfferAvailability["UnavailableUpgradePending"] = "UNAVAILABLE_UPGRADE_PENDING";
    OfferAvailability["Upgradeable"] = "UPGRADEABLE";
    return OfferAvailability;
}({});
var OrderDirection = /*#__PURE__*/ function(OrderDirection) {
    OrderDirection["Asc"] = "ASC";
    OrderDirection["Desc"] = "DESC";
    return OrderDirection;
}({});
var PackageGroup = /*#__PURE__*/ function(PackageGroup) {
    PackageGroup["Give"] = "GIVE";
    PackageGroup["Hidden"] = "HIDDEN";
    PackageGroup["Me"] = "ME";
    return PackageGroup;
}({});
var PaymentMethod = /*#__PURE__*/ function(PaymentMethod) {
    PaymentMethod["Paymentslip"] = "PAYMENTSLIP";
    PaymentMethod["Paypal"] = "PAYPAL";
    PaymentMethod["Postfinancecard"] = "POSTFINANCECARD";
    PaymentMethod["Stripe"] = "STRIPE";
    return PaymentMethod;
}({});
var PaymentSourceStatus = /*#__PURE__*/ function(PaymentSourceStatus) {
    PaymentSourceStatus["Canceled"] = "CANCELED";
    PaymentSourceStatus["Chargeable"] = "CHARGEABLE";
    PaymentSourceStatus["Consumed"] = "CONSUMED";
    PaymentSourceStatus["Failed"] = "FAILED";
    PaymentSourceStatus["Pending"] = "PENDING";
    return PaymentSourceStatus;
}({});
var PaymentSourceWallet = /*#__PURE__*/ function(PaymentSourceWallet) {
    PaymentSourceWallet["AmexExpressCheckout"] = "amex_express_checkout";
    PaymentSourceWallet["ApplePay"] = "apple_pay";
    PaymentSourceWallet["GooglePay"] = "google_pay";
    PaymentSourceWallet["Masterpass"] = "masterpass";
    PaymentSourceWallet["SamsungPay"] = "samsung_pay";
    PaymentSourceWallet["VisaCheckout"] = "visa_checkout";
    return PaymentSourceWallet;
}({});
var PaymentStatus = /*#__PURE__*/ function(PaymentStatus) {
    PaymentStatus["Cancelled"] = "CANCELLED";
    PaymentStatus["Paid"] = "PAID";
    PaymentStatus["Refunded"] = "REFUNDED";
    PaymentStatus["Waiting"] = "WAITING";
    PaymentStatus["WaitingForRefund"] = "WAITING_FOR_REFUND";
    return PaymentStatus;
}({});
var PaynoteMode = /*#__PURE__*/ function(PaynoteMode) {
    PaynoteMode["Button"] = "button";
    PaynoteMode["NoPaynote"] = "noPaynote";
    PaynoteMode["TrialForm"] = "trialForm";
    return PaynoteMode;
}({});
var Permission = /*#__PURE__*/ function(Permission) {
    Permission["Allowed"] = "ALLOWED";
    Permission["Enforced"] = "ENFORCED";
    Permission["Forbidden"] = "FORBIDDEN";
    return Permission;
}({});
var PledgeStatus = /*#__PURE__*/ function(PledgeStatus) {
    PledgeStatus["Cancelled"] = "CANCELLED";
    PledgeStatus["Draft"] = "DRAFT";
    PledgeStatus["PaidInvestigate"] = "PAID_INVESTIGATE";
    PledgeStatus["Successful"] = "SUCCESSFUL";
    PledgeStatus["WaitingForPayment"] = "WAITING_FOR_PAYMENT";
    return PledgeStatus;
}({});
var PortraitSize = /*#__PURE__*/ function(PortraitSize) {
    /** @deprecated use `ImageProperties` instead */ PortraitSize["Share"] = "SHARE";
    /** @deprecated use `ImageProperties` instead */ PortraitSize["Small"] = "SMALL";
    return PortraitSize;
}({});
var ProgressState = /*#__PURE__*/ function(ProgressState) {
    ProgressState["Finished"] = "FINISHED";
    ProgressState["Unfinished"] = "UNFINISHED";
    return ProgressState;
}({});
var QrCodeErrorCorrectionLevel = /*#__PURE__*/ function(QrCodeErrorCorrectionLevel) {
    QrCodeErrorCorrectionLevel["H"] = "H";
    QrCodeErrorCorrectionLevel["L"] = "L";
    QrCodeErrorCorrectionLevel["M"] = "M";
    QrCodeErrorCorrectionLevel["Q"] = "Q";
    return QrCodeErrorCorrectionLevel;
}({});
var QuestionTypeRangeKind = /*#__PURE__*/ function(QuestionTypeRangeKind) {
    QuestionTypeRangeKind["Continous"] = "continous";
    QuestionTypeRangeKind["Discrete"] = "discrete";
    return QuestionTypeRangeKind;
}({});
var ReferralCodeValidationResult = /*#__PURE__*/ function(ReferralCodeValidationResult) {
    ReferralCodeValidationResult["IsOwn"] = "IS_OWN";
    ReferralCodeValidationResult["NotFound"] = "NOT_FOUND";
    ReferralCodeValidationResult["Ok"] = "OK";
    return ReferralCodeValidationResult;
}({});
var RepoChangeMutationType = /*#__PURE__*/ function(RepoChangeMutationType) {
    RepoChangeMutationType["Created"] = "CREATED";
    RepoChangeMutationType["Deleted"] = "DELETED";
    RepoChangeMutationType["Updated"] = "UPDATED";
    return RepoChangeMutationType;
}({});
var RepoFileStatus = /*#__PURE__*/ function(RepoFileStatus) {
    RepoFileStatus["Destroyed"] = "Destroyed";
    RepoFileStatus["Failure"] = "Failure";
    RepoFileStatus["Pending"] = "Pending";
    RepoFileStatus["Private"] = "Private";
    RepoFileStatus["Public"] = "Public";
    return RepoFileStatus;
}({});
var RepoOrderField = /*#__PURE__*/ function(RepoOrderField) {
    RepoOrderField["CreatedAt"] = "CREATED_AT";
    RepoOrderField["Name"] = "NAME";
    RepoOrderField["PushedAt"] = "PUSHED_AT";
    RepoOrderField["Stargazers"] = "STARGAZERS";
    RepoOrderField["UpdatedAt"] = "UPDATED_AT";
    return RepoOrderField;
}({});
var RepoPhaseKey = /*#__PURE__*/ function(RepoPhaseKey) {
    RepoPhaseKey["Cr"] = "cr";
    RepoPhaseKey["Creation"] = "creation";
    RepoPhaseKey["Draft"] = "draft";
    RepoPhaseKey["FinalControl"] = "finalControl";
    RepoPhaseKey["FinalEditing"] = "finalEditing";
    RepoPhaseKey["Production"] = "production";
    RepoPhaseKey["ProofReading"] = "proofReading";
    RepoPhaseKey["Published"] = "published";
    RepoPhaseKey["Ready"] = "ready";
    RepoPhaseKey["Scheduled"] = "scheduled";
    RepoPhaseKey["Tc"] = "tc";
    return RepoPhaseKey;
}({});
var SearchProcessor = /*#__PURE__*/ function(SearchProcessor) {
    SearchProcessor["FormatFeedSamples"] = "formatFeedSamples";
    return SearchProcessor;
}({});
var SearchSortKey = /*#__PURE__*/ function(SearchSortKey) {
    SearchSortKey["MostDebated"] = "mostDebated";
    SearchSortKey["MostRead"] = "mostRead";
    SearchSortKey["PublishedAt"] = "publishedAt";
    SearchSortKey["Relevance"] = "relevance";
    return SearchSortKey;
}({});
var SearchTypes = /*#__PURE__*/ function(SearchTypes) {
    SearchTypes["Comment"] = "Comment";
    SearchTypes["Document"] = "Document";
    SearchTypes["DocumentZone"] = "DocumentZone";
    SearchTypes["User"] = "User";
    return SearchTypes;
}({});
var Sex = /*#__PURE__*/ function(Sex) {
    Sex["Both"] = "BOTH";
    Sex["Female"] = "FEMALE";
    Sex["Male"] = "MALE";
    return Sex;
}({});
var SignInTokenType = /*#__PURE__*/ function(SignInTokenType) {
    SignInTokenType["AccessToken"] = "ACCESS_TOKEN";
    SignInTokenType["App"] = "APP";
    SignInTokenType["EmailCode"] = "EMAIL_CODE";
    SignInTokenType["EmailToken"] = "EMAIL_TOKEN";
    return SignInTokenType;
}({});
var SubmissionsSortBy = /*#__PURE__*/ function(SubmissionsSortBy) {
    SubmissionsSortBy["CreatedAt"] = "createdAt";
    SubmissionsSortBy["Random"] = "random";
    return SubmissionsSortBy;
}({});
var SubscriptionObjectType = /*#__PURE__*/ function(SubscriptionObjectType) {
    SubscriptionObjectType["Document"] = "Document";
    SubscriptionObjectType["User"] = "User";
    return SubscriptionObjectType;
}({});
const AudioQueueItemFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "AudioQueueItem"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "AudioQueueItem"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "sequence"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "document"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "meta"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "path"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "publishDate"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "image"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioCoverCrop"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "x"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "y"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "width"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "height"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "alias": {
                                                    "kind": "Name",
                                                    "value": "coverForNativeApp"
                                                },
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioCover"
                                                },
                                                "arguments": [
                                                    {
                                                        "kind": "Argument",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "properties"
                                                        },
                                                        "value": {
                                                            "kind": "ObjectValue",
                                                            "fields": [
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "width"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "1024"
                                                                    }
                                                                },
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "height"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "1024"
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "kind": "Field",
                                                "alias": {
                                                    "kind": "Name",
                                                    "value": "coverMd"
                                                },
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioCover"
                                                },
                                                "arguments": [
                                                    {
                                                        "kind": "Argument",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "properties"
                                                        },
                                                        "value": {
                                                            "kind": "ObjectValue",
                                                            "fields": [
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "width"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "256"
                                                                    }
                                                                },
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "height"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "256"
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "kind": "Field",
                                                "alias": {
                                                    "kind": "Name",
                                                    "value": "coverSm"
                                                },
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioCover"
                                                },
                                                "arguments": [
                                                    {
                                                        "kind": "Argument",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "properties"
                                                        },
                                                        "value": {
                                                            "kind": "ObjectValue",
                                                            "fields": [
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "width"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "128"
                                                                    }
                                                                },
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "height"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "128"
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioSource"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "mediaId"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "kind"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "mp3"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "aac"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "ogg"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "durationMs"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "userProgress"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "secs"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "format"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "meta"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "title"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "color"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "shareLogo"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "shareBackgroundImage"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "shareBackgroundImageInverted"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const NextReadDocumentFieldsFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "NextReadDocumentFields"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Document"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "meta"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "audioCover"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "properties"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "width"
                                                        },
                                                        "value": {
                                                            "kind": "IntValue",
                                                            "value": "624"
                                                        }
                                                    },
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "height"
                                                        },
                                                        "value": {
                                                            "kind": "IntValue",
                                                            "value": "624"
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "audioCoverCrop"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "x"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "y"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "width"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "height"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "image"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "estimatedReadingMinutes"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "estimatedConsumptionMinutes"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "contributors"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "name"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "kind"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "title"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "description"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "publishDate"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "path"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "kind"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "color"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "format"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "meta"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "title"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "color"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "section"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "meta"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "color"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "series"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const SubscriptionFieldsFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "SubscriptionFields"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Subscription"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "active"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "isEligibleForNotifications"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "filters"
                        }
                    }
                ]
            }
        }
    ]
};
const AudioQueueQueryDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "AudioQueueQuery"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "me"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "audioQueue"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "FragmentSpread",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "AudioQueueItem"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "AudioQueueItem"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "AudioQueueItem"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "sequence"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "document"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "meta"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "path"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "publishDate"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "image"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioCoverCrop"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "x"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "y"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "width"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "height"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "alias": {
                                                    "kind": "Name",
                                                    "value": "coverForNativeApp"
                                                },
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioCover"
                                                },
                                                "arguments": [
                                                    {
                                                        "kind": "Argument",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "properties"
                                                        },
                                                        "value": {
                                                            "kind": "ObjectValue",
                                                            "fields": [
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "width"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "1024"
                                                                    }
                                                                },
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "height"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "1024"
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "kind": "Field",
                                                "alias": {
                                                    "kind": "Name",
                                                    "value": "coverMd"
                                                },
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioCover"
                                                },
                                                "arguments": [
                                                    {
                                                        "kind": "Argument",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "properties"
                                                        },
                                                        "value": {
                                                            "kind": "ObjectValue",
                                                            "fields": [
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "width"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "256"
                                                                    }
                                                                },
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "height"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "256"
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "kind": "Field",
                                                "alias": {
                                                    "kind": "Name",
                                                    "value": "coverSm"
                                                },
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioCover"
                                                },
                                                "arguments": [
                                                    {
                                                        "kind": "Argument",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "properties"
                                                        },
                                                        "value": {
                                                            "kind": "ObjectValue",
                                                            "fields": [
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "width"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "128"
                                                                    }
                                                                },
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "height"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "128"
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioSource"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "mediaId"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "kind"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "mp3"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "aac"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "ogg"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "durationMs"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "userProgress"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "secs"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "format"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "meta"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "title"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "color"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "shareLogo"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "shareBackgroundImage"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "shareBackgroundImageInverted"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const AddAudioQueueItemsDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "AddAudioQueueItems"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "entity"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "AudioQueueEntityInput"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "sequence"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "Int"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "audioQueueItems"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "addAudioQueueItem"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "entity"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "entity"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "sequence"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "sequence"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "FragmentSpread",
                                    "name": {
                                        "kind": "Name",
                                        "value": "AudioQueueItem"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "AudioQueueItem"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "AudioQueueItem"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "sequence"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "document"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "meta"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "path"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "publishDate"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "image"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioCoverCrop"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "x"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "y"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "width"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "height"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "alias": {
                                                    "kind": "Name",
                                                    "value": "coverForNativeApp"
                                                },
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioCover"
                                                },
                                                "arguments": [
                                                    {
                                                        "kind": "Argument",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "properties"
                                                        },
                                                        "value": {
                                                            "kind": "ObjectValue",
                                                            "fields": [
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "width"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "1024"
                                                                    }
                                                                },
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "height"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "1024"
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "kind": "Field",
                                                "alias": {
                                                    "kind": "Name",
                                                    "value": "coverMd"
                                                },
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioCover"
                                                },
                                                "arguments": [
                                                    {
                                                        "kind": "Argument",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "properties"
                                                        },
                                                        "value": {
                                                            "kind": "ObjectValue",
                                                            "fields": [
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "width"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "256"
                                                                    }
                                                                },
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "height"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "256"
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "kind": "Field",
                                                "alias": {
                                                    "kind": "Name",
                                                    "value": "coverSm"
                                                },
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioCover"
                                                },
                                                "arguments": [
                                                    {
                                                        "kind": "Argument",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "properties"
                                                        },
                                                        "value": {
                                                            "kind": "ObjectValue",
                                                            "fields": [
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "width"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "128"
                                                                    }
                                                                },
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "height"
                                                                    },
                                                                    "value": {
                                                                        "kind": "IntValue",
                                                                        "value": "128"
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "audioSource"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "mediaId"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "kind"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "mp3"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "aac"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "ogg"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "durationMs"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "userProgress"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "secs"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "format"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "meta"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "title"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "color"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "shareLogo"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "shareBackgroundImage"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "shareBackgroundImageInverted"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const MoveAudioQueueItemDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "MoveAudioQueueItem"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "sequence"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "Int"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "audioQueueItems"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "moveAudioQueueItem"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "id"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "sequence"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "sequence"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "sequence"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const RemoveAudioQueueItemDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "RemoveAudioQueueItem"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "audioQueueItems"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "removeAudioQueueItem"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "id"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const ClearAudioQueueDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "ClearAudioQueue"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "audioQueueItems"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "clearAudioQueue"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const ReorderAudioQueueDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "ReorderAudioQueue"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "ids"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "ListType",
                            "type": {
                                "kind": "NonNullType",
                                "type": {
                                    "kind": "NamedType",
                                    "name": {
                                        "kind": "Name",
                                        "value": "ID"
                                    }
                                }
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "audioQueueItems"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "reorderAudioQueue"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "ids"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "ids"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "sequence"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const LatestArticlesDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "LatestArticles"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "count"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "Int"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "after"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "String"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "latestArticles"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "documents"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "first"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "count"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "after"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "after"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "pageInfo"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "hasNextPage"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "endCursor"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "nodes"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "meta"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "title"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "path"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "publishDate"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "image"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "audioCoverCrop"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "x"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "y"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "width"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "height"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "alias": {
                                                                "kind": "Name",
                                                                "value": "coverSm"
                                                            },
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "audioCover"
                                                            },
                                                            "arguments": [
                                                                {
                                                                    "kind": "Argument",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "properties"
                                                                    },
                                                                    "value": {
                                                                        "kind": "ObjectValue",
                                                                        "fields": [
                                                                            {
                                                                                "kind": "ObjectField",
                                                                                "name": {
                                                                                    "kind": "Name",
                                                                                    "value": "width"
                                                                                },
                                                                                "value": {
                                                                                    "kind": "IntValue",
                                                                                    "value": "128"
                                                                                }
                                                                            },
                                                                            {
                                                                                "kind": "ObjectField",
                                                                                "name": {
                                                                                    "kind": "Name",
                                                                                    "value": "height"
                                                                                },
                                                                                "value": {
                                                                                    "kind": "IntValue",
                                                                                    "value": "128"
                                                                                }
                                                                            }
                                                                        ]
                                                                    }
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "audioSource"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "mediaId"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "kind"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "mp3"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "aac"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "ogg"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "durationMs"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "userProgress"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "id"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "secs"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "format"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "meta"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "title"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "color"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "shareLogo"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "shareBackgroundImage"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "shareBackgroundImageInverted"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const AcknowledgeCtaDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "AcknowledgeCTA"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "response"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "JSON"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "acknowledgeCallToAction"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "id"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "response"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "response"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "acknowledgedAt"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const AuthorizeSessionDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "authorizeSession"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "email"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "tokens"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "ListType",
                            "type": {
                                "kind": "NonNullType",
                                "type": {
                                    "kind": "NamedType",
                                    "name": {
                                        "kind": "Name",
                                        "value": "SignInToken"
                                    }
                                }
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "consents"
                        }
                    },
                    "type": {
                        "kind": "ListType",
                        "type": {
                            "kind": "NonNullType",
                            "type": {
                                "kind": "NamedType",
                                "name": {
                                    "kind": "Name",
                                    "value": "String"
                                }
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "requiredFields"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "RequiredUserFields"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "authorizeSession"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "email"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "email"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "tokens"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "tokens"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "consents"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "consents"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "requiredFields"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "requiredFields"
                                    }
                                }
                            }
                        ]
                    }
                ]
            }
        }
    ]
};
const SetDiscussionPreferencesDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "SetDiscussionPreferences"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "discussionId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "discussionPreferences"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "DiscussionPreferencesInput"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "setDiscussionPreferences"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "id"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "discussionId"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "discussionPreferences"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "discussionPreferences"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "userPreference"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "notifications"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const CancelMagazineSubscriptionDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "CancelMagazineSubscription"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "subscriptionId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "details"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "CancellationInput"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "cancelImmediately"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "Boolean"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "cancelMagazineSubscription"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "subscriptionId"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "subscriptionId"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "details"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "details"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "cancelImmediately"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "cancelImmediately"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const ReactivateMagazineSubscriptionDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "ReactivateMagazineSubscription"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "subscriptionId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "reactivateMagazineSubscription"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "subscriptionId"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "subscriptionId"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const CancelUpgradeMagazineSubscriptionDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "CancelUpgradeMagazineSubscription"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "subscriptionId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "cancelUpgradeMagazineSubscription"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "subscriptionId"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "subscriptionId"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const UpdateMagazineSubscriptionDonationDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "UpdateMagazineSubscriptionDonation"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "subscriptionId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "donationAmount"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "Int"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "updateMagazineSubscriptionDonation"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "subscriptionId"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "subscriptionId"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "donationAmount"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "donationAmount"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const CreateStripeCustomerPortalSessionDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "createStripeCustomerPortalSession"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "companyName"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "CompanyName"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "createStripeCustomerPortalSession"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "companyName"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "companyName"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "sessionUrl"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const NewslettersResubscribeDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "NewslettersResubscribe"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "userId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "resubscribeEmail"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "userId"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "userId"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "status"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const UpsertDocumentProgressDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "upsertDocumentProgress"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "documentId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "percentage"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "Float"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "nodeId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "upsertDocumentProgress"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "documentId"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "documentId"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "percentage"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "percentage"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "nodeId"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "nodeId"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "document"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "userProgress"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "percentage"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "nodeId"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "updatedAt"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "max"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "percentage"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "updatedAt"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const RemoveDocumentProgressDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "removeDocumentProgress"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "documentId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "removeDocumentProgress"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "documentId"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "documentId"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "document"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "userProgress"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "percentage"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "nodeId"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "updatedAt"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "max"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "percentage"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "updatedAt"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const SubmitConsentDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "submitConsent"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "submitConsent"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "name"
                                },
                                "value": {
                                    "kind": "StringValue",
                                    "value": "PROGRESS_OPT_OUT",
                                    "block": false
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "alias": {
                                        "kind": "Name",
                                        "value": "progressOptOut"
                                    },
                                    "name": {
                                        "kind": "Name",
                                        "value": "hasConsentedTo"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "name"
                                            },
                                            "value": {
                                                "kind": "StringValue",
                                                "value": "PROGRESS_OPT_OUT",
                                                "block": false
                                            }
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const RevokeConsentDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "revokeConsent"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "revokeConsent"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "name"
                                },
                                "value": {
                                    "kind": "StringValue",
                                    "value": "PROGRESS_OPT_OUT",
                                    "block": false
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "alias": {
                                        "kind": "Name",
                                        "value": "progressOptOut"
                                    },
                                    "name": {
                                        "kind": "Name",
                                        "value": "hasConsentedTo"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "name"
                                            },
                                            "value": {
                                                "kind": "StringValue",
                                                "value": "PROGRESS_OPT_OUT",
                                                "block": false
                                            }
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const ClearProgressDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "clearProgress"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "clearProgress"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const RequestAccessDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "requestAccess"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "campaignId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "payload"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "JSON"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "requestAccess"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "campaignId"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "campaignId"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "payload"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "payload"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "endAt"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const SetOnboardedDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "setOnboarded"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "setOnboarded"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "onboarded"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const SignInDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "signIn"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "email"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "context"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "String"
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "consents"
                        }
                    },
                    "type": {
                        "kind": "ListType",
                        "type": {
                            "kind": "NonNullType",
                            "type": {
                                "kind": "NamedType",
                                "name": {
                                    "kind": "Name",
                                    "value": "String"
                                }
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "tokenType"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "SignInTokenType"
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "accessToken"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "ID"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "signIn"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "email"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "email"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "context"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "context"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "consents"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "consents"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "tokenType"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "tokenType"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "accessToken"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "accessToken"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "phrase"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "tokenType"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "alternativeFirstFactors"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const SignUpForNewsletterDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "SignUpForNewsletter"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "email"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "name"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "context"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "meta"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "JSON"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "requestNewsletterSubscription"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "email"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "email"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "name"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "name"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "context"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "context"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "meta"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "meta"
                                    }
                                }
                            }
                        ]
                    }
                ]
            }
        }
    ]
};
const SubmitQuestionnaireAnswerDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "SubmitQuestionnaireAnswer"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "answerId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "questionId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "payload"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "JSON"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "submitAnswer"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "answer"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "id"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "answerId"
                                                }
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "questionId"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "questionId"
                                                }
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "payload"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "payload"
                                                }
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "InlineFragment",
                                    "typeCondition": {
                                        "kind": "NamedType",
                                        "name": {
                                            "kind": "Name",
                                            "value": "QuestionInterface"
                                        }
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "userAnswer"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "payload"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const SubscribeDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "Subscribe"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "objectId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "type"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "SubscriptionObjectType"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "filters"
                        }
                    },
                    "type": {
                        "kind": "ListType",
                        "type": {
                            "kind": "NonNullType",
                            "type": {
                                "kind": "NamedType",
                                "name": {
                                    "kind": "Name",
                                    "value": "EventObjectType"
                                }
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "subscribe"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "objectId"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "objectId"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "type"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "type"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "filters"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "filters"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "FragmentSpread",
                                    "name": {
                                        "kind": "Name",
                                        "value": "SubscriptionFields"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "SubscriptionFields"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Subscription"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "active"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "isEligibleForNotifications"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "filters"
                        }
                    }
                ]
            }
        }
    ]
};
const UnsubscribeDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "Unsubscribe"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "subscriptionId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "unsubscribe"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "subscriptionId"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "subscriptionId"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "FragmentSpread",
                                    "name": {
                                        "kind": "Name",
                                        "value": "SubscriptionFields"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "SubscriptionFields"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Subscription"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "active"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "isEligibleForNotifications"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "filters"
                        }
                    }
                ]
            }
        }
    ]
};
const UpdateNewsletterSubscriptionDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "UpdateNewsletterSubscription"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "name"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "subscribed"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "Boolean"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "updateNewsletterSubscription"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "name"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "name"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "subscribed"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "subscribed"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "name"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "subscribed"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const UpdateNewsletterSubscriptionWithMacDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "UpdateNewsletterSubscriptionWithMac"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "name"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "subscribed"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "Boolean"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "signup"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "NewsletterSignupInput"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "updateNewsletterSubscription"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "name"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "name"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "subscribed"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "subscribed"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "signup"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "signup"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "name"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "subscribed"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "isEligible"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const ActiveMagazineSubscriptionDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "ActiveMagazineSubscription"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "me"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "activeMagazineSubscription"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "type"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "company"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "currentPeriodEnd"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "cancelAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "canceledAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "endedAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "status"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "paymentMethod"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "renewsAtPrice"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "donation"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "amount"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "upgrade"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "scheduledStart"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "subscriptionType"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "billingDetails"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "total"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "donation"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "amount"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const ArticleTeaserDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "ArticleTeaser"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "path"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "article"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "document"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "path"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "path"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "meta"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "description"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "image"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "credits"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const CaNewsletterDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "CANewsletter"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "name"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "me"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "newsletterSettings"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "status"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "subscriptions"
                                                },
                                                "arguments": [
                                                    {
                                                        "kind": "Argument",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "name"
                                                        },
                                                        "value": {
                                                            "kind": "Variable",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "name"
                                                            }
                                                        }
                                                    }
                                                ],
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "name"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "subscribed"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const CampaignReferralsDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "CampaignReferrals"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "campaignSlug"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "campaign"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "slug"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "campaignSlug"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "isActive"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "newMembers"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "count"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const CancellationCategoriesDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "CancellationCategories"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "cancellationCategories"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "type"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "label"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const GetDocumentProgressDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "getDocumentProgress"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "path"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "document"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "path"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "path"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "userProgress"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "percentage"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "nodeId"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "updatedAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "max"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "percentage"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "updatedAt"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const DocumentRecommendationsDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "DocumentRecommendations"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "path"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "document"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "path"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "path"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "meta"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "recommendations"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "nodes"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "FragmentSpread",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "NextReadDocumentFields"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "NextReadDocumentFields"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Document"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "meta"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "audioCover"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "properties"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "width"
                                                        },
                                                        "value": {
                                                            "kind": "IntValue",
                                                            "value": "624"
                                                        }
                                                    },
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "height"
                                                        },
                                                        "value": {
                                                            "kind": "IntValue",
                                                            "value": "624"
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "audioCoverCrop"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "x"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "y"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "width"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "height"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "image"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "estimatedReadingMinutes"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "estimatedConsumptionMinutes"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "contributors"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "name"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "kind"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "title"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "description"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "publishDate"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "path"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "kind"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "color"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "format"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "meta"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "title"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "color"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "section"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "meta"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "color"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "series"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const FollowableAuthorDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "FollowableAuthor"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "user"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "id"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "slug"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "name"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "portrait"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "credentials"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "isListed"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "description"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "verified"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "subscribedBy"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "onlyMe"
                                            },
                                            "value": {
                                                "kind": "BooleanValue",
                                                "value": true
                                            }
                                        }
                                    ],
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "nodes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "active"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "isEligibleForNotifications"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const FollowableDocumentDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "FollowableDocument"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "path"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "document"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "path"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "path"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "content"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "meta"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "description"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "path"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "image"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "newsletter"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "name"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "subscribedBy"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "onlyMe"
                                            },
                                            "value": {
                                                "kind": "BooleanValue",
                                                "value": true
                                            }
                                        }
                                    ],
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "nodes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "active"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "isEligibleForNotifications"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const MeDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "Me"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "me"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "username"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "slug"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "portrait"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "name"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "firstName"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "lastName"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "email"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "initials"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "roles"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "isListed"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "hasPublicProfile"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "notificationChannels"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "regwallTrialStatus"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "onboarded"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "accessCampaigns"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "accessGrants"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "status"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "endAt"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "hasDormantMembership"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "prolongBeforeDate"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "activeMembership"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "type"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "name"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "renew"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "endDate"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "graceEndDate"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "canProlong"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "activeMagazineSubscription"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "alias": {
                                        "kind": "Name",
                                        "value": "prolitterisOptOut"
                                    },
                                    "name": {
                                        "kind": "Name",
                                        "value": "hasConsentedTo"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "name"
                                            },
                                            "value": {
                                                "kind": "StringValue",
                                                "value": "PROLITTERIS_OPT_OUT",
                                                "block": false
                                            }
                                        }
                                    ]
                                },
                                {
                                    "kind": "Field",
                                    "alias": {
                                        "kind": "Name",
                                        "value": "progressOptOut"
                                    },
                                    "name": {
                                        "kind": "Name",
                                        "value": "hasConsentedTo"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "name"
                                            },
                                            "value": {
                                                "kind": "StringValue",
                                                "value": "PROGRESS_OPT_OUT",
                                                "block": false
                                            }
                                        }
                                    ]
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "ipAllowlistAccess"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "name"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const MyBelongingsDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "MyBelongings"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "me"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "hasDormantMembership"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "memberships"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "accessGranted"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "claimerName"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "voucherCode"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "createdAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "sequenceNumber"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "renew"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "active"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "overdue"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "autoPay"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "autoPayIsMutable"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "canProlong"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "user"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "pledge"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "package"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "name"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "group"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "company"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "id"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "name"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "options"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "price"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "reward"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "InlineFragment",
                                                                                    "typeCondition": {
                                                                                        "kind": "NamedType",
                                                                                        "name": {
                                                                                            "kind": "Name",
                                                                                            "value": "MembershipType"
                                                                                        }
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "name"
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "periods"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "beginDate"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "endDate"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "type"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "name"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "magazineSubscriptions"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "type"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "company"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "status"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "activeMagazineSubscription"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "type"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "company"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "currentPeriodEnd"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "cancelAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "canceledAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "endedAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "status"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "paymentMethod"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "renewsAtPrice"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "accessGrants"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "endAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "campaign"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "title"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "description"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "pledges"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "package"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "name"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "group"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "company"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "name"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "options"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "templateId"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "reward"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "InlineFragment",
                                                                        "typeCondition": {
                                                                            "kind": "NamedType",
                                                                            "name": {
                                                                                "kind": "Name",
                                                                                "value": "MembershipType"
                                                                            }
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "name"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "interval"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "InlineFragment",
                                                                        "typeCondition": {
                                                                            "kind": "NamedType",
                                                                            "name": {
                                                                                "kind": "Name",
                                                                                "value": "Goodie"
                                                                            }
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "name"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "minAmount"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "maxAmount"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "amount"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "periods"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "price"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "accessGranted"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "membership"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "user"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "id"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "name"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "sequenceNumber"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "additionalPeriods"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "endDate"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "status"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "total"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "donation"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "payments"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "method"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "total"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "status"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "paymentslipUrl"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "createdAt"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "memberships"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "claimerName"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "voucherCode"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "createdAt"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "sequenceNumber"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "type"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "name"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "createdAt"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const MyCallToActionsDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "MyCallToActions"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "me"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "callToActions"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "beginAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "endAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "acknowledgedAt"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "payload"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "InlineFragment",
                                                            "typeCondition": {
                                                                "kind": "NamedType",
                                                                "name": {
                                                                    "kind": "Name",
                                                                    "value": "CallToActionBasicPayload"
                                                                }
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "text"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "linkHref"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "linkLabel"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "InlineFragment",
                                                            "typeCondition": {
                                                                "kind": "NamedType",
                                                                "name": {
                                                                    "kind": "Name",
                                                                    "value": "CallToActionComponentPayload"
                                                                }
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "customComponent"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "key"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "args"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const NewsletterSettingsDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "NewsletterSettings"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "me"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "newsletterSettings"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "status"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "subscriptions"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "name"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "subscribed"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const NextReadsBookmarksDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "NextReadsBookmarks"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "repoId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "me"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "collectionItems"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "names"
                                            },
                                            "value": {
                                                "kind": "ListValue",
                                                "values": [
                                                    {
                                                        "kind": "StringValue",
                                                        "value": "bookmarks",
                                                        "block": false
                                                    }
                                                ]
                                            }
                                        },
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "first"
                                            },
                                            "value": {
                                                "kind": "IntValue",
                                                "value": "5"
                                            }
                                        },
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "progress"
                                            },
                                            "value": {
                                                "kind": "EnumValue",
                                                "value": "UNFINISHED"
                                            }
                                        },
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "uniqueDocuments"
                                            },
                                            "value": {
                                                "kind": "BooleanValue",
                                                "value": true
                                            }
                                        },
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "lastDays"
                                            },
                                            "value": {
                                                "kind": "IntValue",
                                                "value": "300"
                                            }
                                        },
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "excludeRepoId"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "repoId"
                                                }
                                            }
                                        }
                                    ],
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "nodes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "document"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "FragmentSpread",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "NextReadDocumentFields"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "NextReadDocumentFields"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Document"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "meta"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "audioCover"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "properties"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "width"
                                                        },
                                                        "value": {
                                                            "kind": "IntValue",
                                                            "value": "624"
                                                        }
                                                    },
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "height"
                                                        },
                                                        "value": {
                                                            "kind": "IntValue",
                                                            "value": "624"
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "audioCoverCrop"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "x"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "y"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "width"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "height"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "image"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "estimatedReadingMinutes"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "estimatedConsumptionMinutes"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "contributors"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "name"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "kind"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "title"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "description"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "publishDate"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "path"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "kind"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "color"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "format"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "meta"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "title"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "color"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "section"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "meta"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "color"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "series"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const NextReadsDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "NextReads"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "repoId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "nextReads"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "repoId"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "repoId"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "documents"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "FragmentSpread",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "NextReadDocumentFields"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "NextReadDocumentFields"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Document"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "meta"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "audioCover"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "properties"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "width"
                                                        },
                                                        "value": {
                                                            "kind": "IntValue",
                                                            "value": "624"
                                                        }
                                                    },
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "height"
                                                        },
                                                        "value": {
                                                            "kind": "IntValue",
                                                            "value": "624"
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "audioCoverCrop"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "x"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "y"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "width"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "height"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "image"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "estimatedReadingMinutes"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "estimatedConsumptionMinutes"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "contributors"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "name"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "kind"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "title"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "description"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "publishDate"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "path"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "kind"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "color"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "format"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "meta"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "title"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "color"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "section"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "meta"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "color"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "series"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "title"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const OnboardingDocumentsDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "OnboardingDocuments"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "repoIds"
                        }
                    },
                    "type": {
                        "kind": "ListType",
                        "type": {
                            "kind": "NonNullType",
                            "type": {
                                "kind": "NamedType",
                                "name": {
                                    "kind": "Name",
                                    "value": "ID"
                                }
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "documents"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "repoIds"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "repoIds"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "nodes"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "repoId"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "meta"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "title"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "description"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "path"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "audioCover"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "subscribedBy"
                                                },
                                                "arguments": [
                                                    {
                                                        "kind": "Argument",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "onlyMe"
                                                        },
                                                        "value": {
                                                            "kind": "BooleanValue",
                                                            "value": true
                                                        }
                                                    }
                                                ],
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "nodes"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "FragmentSpread",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "SubscriptionFields"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "SubscriptionFields"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Subscription"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "id"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "active"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "isEligibleForNotifications"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "filters"
                        }
                    }
                ]
            }
        }
    ]
};
const GetCompleteFrontOverviewDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "getCompleteFrontOverview"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "path"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "front"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "document"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "path"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "path"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "content"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const GetFrontOverviewYearDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "getFrontOverviewYear"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "after"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "ID"
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "before"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "ID"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "front"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "document"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "path"
                                },
                                "value": {
                                    "kind": "StringValue",
                                    "value": "/",
                                    "block": false
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "children"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "after"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "after"
                                                }
                                            }
                                        },
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "before"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "before"
                                                }
                                            }
                                        }
                                    ],
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "nodes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "body"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const PastAccessGrantsDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "PastAccessGrants"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "me"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "accessGrants"
                                    },
                                    "arguments": [
                                        {
                                            "kind": "Argument",
                                            "name": {
                                                "kind": "Name",
                                                "value": "withPast"
                                            },
                                            "value": {
                                                "kind": "BooleanValue",
                                                "value": true
                                            }
                                        }
                                    ],
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "campaign"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "status"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "endAt"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const PendingAppSignInDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "PendingAppSignIn"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "pendingAppSignIn"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "title"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "body"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "verificationUrl"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "expiresAt"
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const QuestionnaireDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "Questionnaire"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "slug"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "questionnaire"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "slug"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "slug"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "beginDate"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "endDate"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "userHasSubmitted"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "userSubmitDate"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "resubmitAnswers"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "revokeSubmissions"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "userIsEligible"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "questions"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "InlineFragment",
                                                "typeCondition": {
                                                    "kind": "NamedType",
                                                    "name": {
                                                        "kind": "Name",
                                                        "value": "QuestionInterface"
                                                    }
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "order"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "text"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "explanation"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "private"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "metadata"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "userAnswer"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "payload"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "InlineFragment",
                                                "typeCondition": {
                                                    "kind": "NamedType",
                                                    "name": {
                                                        "kind": "Name",
                                                        "value": "QuestionTypeText"
                                                    }
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "maxLength"
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "InlineFragment",
                                                "typeCondition": {
                                                    "kind": "NamedType",
                                                    "name": {
                                                        "kind": "Name",
                                                        "value": "QuestionTypeChoice"
                                                    }
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "cardinality"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "options"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "label"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "value"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "category"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "requireAddress"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "InlineFragment",
                                                "typeCondition": {
                                                    "kind": "NamedType",
                                                    "name": {
                                                        "kind": "Name",
                                                        "value": "QuestionTypeImageChoice"
                                                    }
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "options"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "label"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "value"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "category"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "requireAddress"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "imageUrl"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "InlineFragment",
                                                "typeCondition": {
                                                    "kind": "NamedType",
                                                    "name": {
                                                        "kind": "Name",
                                                        "value": "QuestionTypeRange"
                                                    }
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "kind"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "ticks"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "label"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "value"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                "kind": "InlineFragment",
                                                "typeCondition": {
                                                    "kind": "NamedType",
                                                    "name": {
                                                        "kind": "Name",
                                                        "value": "QuestionTypeDocument"
                                                    }
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "template"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const RssFeedDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "RSSFeed"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "feed"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "search"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "first"
                                },
                                "value": {
                                    "kind": "IntValue",
                                    "value": "100"
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "filter"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "feed"
                                            },
                                            "value": {
                                                "kind": "BooleanValue",
                                                "value": true
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "template"
                                            },
                                            "value": {
                                                "kind": "StringValue",
                                                "value": "article",
                                                "block": false
                                            }
                                        }
                                    ]
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "sort"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "key"
                                            },
                                            "value": {
                                                "kind": "EnumValue",
                                                "value": "publishedAt"
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "direction"
                                            },
                                            "value": {
                                                "kind": "EnumValue",
                                                "value": "DESC"
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "nodes"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "entity"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "InlineFragment",
                                                            "typeCondition": {
                                                                "kind": "NamedType",
                                                                "name": {
                                                                    "kind": "Name",
                                                                    "value": "Document"
                                                                }
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "repoId"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "meta"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "title"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "description"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "publishDate"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "path"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const SitemapByYearDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "sitemapByYear"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "from"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "DateTime"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "to"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "DateTime"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "first"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "Int"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "after"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "String"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "search"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "filter"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "type"
                                            },
                                            "value": {
                                                "kind": "EnumValue",
                                                "value": "Document"
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "template"
                                            },
                                            "value": {
                                                "kind": "StringValue",
                                                "value": "article",
                                                "block": false
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "publishedAt"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "from"
                                                        },
                                                        "value": {
                                                            "kind": "Variable",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "from"
                                                            }
                                                        }
                                                    },
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "to"
                                                        },
                                                        "value": {
                                                            "kind": "Variable",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "to"
                                                            }
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "first"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "first"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "after"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "after"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "sort"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "key"
                                            },
                                            "value": {
                                                "kind": "EnumValue",
                                                "value": "publishedAt"
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "direction"
                                            },
                                            "value": {
                                                "kind": "EnumValue",
                                                "value": "DESC"
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "totalCount"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "pageInfo"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "hasNextPage"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "endCursor"
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "nodes"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "entity"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "InlineFragment",
                                                            "typeCondition": {
                                                                "kind": "NamedType",
                                                                "name": {
                                                                    "kind": "Name",
                                                                    "value": "Document"
                                                                }
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "meta"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "title"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "path"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "publishDate"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "lastPublishedAt"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const TransactionsDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "Transactions"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "me"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "transactions"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "amount"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "company"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "status"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "createdAt"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const UnauthorizedSessionDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "UnauthorizedSession"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "email"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "token"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "SignInToken"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "echo"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "ipAddress"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "userAgent"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "country"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "city"
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "unauthorizedSession"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "email"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "email"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "token"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "token"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "newUser"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "enabledSecondFactors"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "requiredConsents"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "requiredFields"
                                    }
                                },
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "session"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "ipAddress"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "userAgent"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "country"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "city"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "phrase"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "isCurrent"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/parse-useragent.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getNativeAppBuildId",
    ()=>getNativeAppBuildId,
    "getNativeAppVersion",
    ()=>getNativeAppVersion,
    "matchAndroidUserAgent",
    ()=>matchAndroidUserAgent,
    "matchFirefoxUserAgent",
    ()=>matchFirefoxUserAgent,
    "matchIOSUserAgent",
    ()=>matchIOSUserAgent,
    "matchSearchBotUserAgent",
    ()=>matchSearchBotUserAgent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$isbot$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/isbot/index.mjs [app-client] (ecmascript)");
;
function getNativeAppVersion(value) {
    const matches = value?.match(/RepublikApp\/([.0-9]+)/);
    return matches ? matches[1] : undefined;
}
const getNativeAppBuildId = (value)=>{
    const matches = value?.match(/RepublikApp\/([.0-9]+)\/([0-9]+)/);
    return matches ? matches[2] : undefined;
};
const matchIOSUserAgent = (value)=>!!value && (!!value.match(/iPad|iPhone|iPod/) || // iPad Pro in App
    // for web see https://stackoverflow.com/questions/56578799/tell-ipados-from-macos-on-the-web but that only works client side
    !!value.match(/Mac.+RepublikApp/));
const matchAndroidUserAgent = (value)=>!!value && !!value.match(/Android/);
const matchFirefoxUserAgent = (value)=>!!value && !!value.match(/Firefox/);
const matchSearchBotUserAgent = (value)=>!!value && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$isbot$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isbot"])(value);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/lib/util/useragent/shared.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parsePlatformInformation",
    ()=>parsePlatformInformation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/parse-useragent.ts [app-client] (ecmascript)");
;
function parsePlatformInformation(userAgent) {
    // parse useragent header
    const isIOS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchIOSUserAgent"])(userAgent);
    const isAndroid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchAndroidUserAgent"])(userAgent);
    const isFirefox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchFirefoxUserAgent"])(userAgent);
    const nativeAppVersion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNativeAppVersion"])(userAgent);
    const nativeAppBuildId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$parse$2d$useragent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNativeAppBuildId"])(userAgent);
    return {
        userAgent,
        isIOS,
        isAndroid,
        isFirefox,
        nativeAppBuildId,
        nativeAppVersion,
        isNativeApp: !!nativeAppVersion,
        isIOSApp: isIOS && !!nativeAppVersion,
        isAndroidApp: isAndroid && !!nativeAppVersion,
        // version lower than v2
        isLegacyNativeApp: !!nativeAppVersion && Number(nativeAppVersion) < 2
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/lib/hooks/usePlatformInformation.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "usePlatformInformation",
    ()=>usePlatformInformation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$util$2f$useragent$2f$shared$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/lib/util/useragent/shared.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function usePlatformInformation(initialUserAgent) {
    _s();
    const [platformData, setPlatformData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialUserAgent // to be used for initial render on server
     ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$util$2f$useragent$2f$shared$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parsePlatformInformation"])(initialUserAgent) : {
        userAgent: '',
        isIOS: false,
        isAndroid: false,
        isFirefox: false,
        nativeAppBuildId: undefined,
        nativeAppVersion: undefined,
        isNativeApp: false,
        isIOSApp: false,
        isAndroidApp: false,
        isLegacyNativeApp: false
    });
    // on client, get useragent from navigator
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePlatformInformation.useEffect": ()=>{
            const userAgent = navigator.userAgent;
            const data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$util$2f$useragent$2f$shared$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parsePlatformInformation"])(userAgent);
            setPlatformData(data);
        }
    }["usePlatformInformation.useEffect"], []);
    return platformData;
}
_s(usePlatformInformation, "8V3mx83+wTXF+OyJ1IdeATNvRM4=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/lib/hooks/usePostMessage.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "usePostMessage",
    ()=>usePostMessage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$usePlatformInformation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/lib/hooks/usePlatformInformation.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function usePostMessage() {
    _s();
    const { isNativeApp, isLegacyNativeApp } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$usePlatformInformation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePlatformInformation"])();
    const postMessage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "usePostMessage.useMemo[postMessage]": ()=>{
            return !isNativeApp ? ({
                "usePostMessage.useMemo[postMessage]": ()=>{} // does nothing outside of app, e.g. gallery full screen message
            })["usePostMessage.useMemo[postMessage]"] : isLegacyNativeApp ? ({
                "usePostMessage.useMemo[postMessage]": (msg)=>window.postMessage(typeof msg === 'string' ? msg : JSON.stringify(msg), '*')
            })["usePostMessage.useMemo[postMessage]"] : window?.ReactNativeWebView?.postMessage ? ({
                "usePostMessage.useMemo[postMessage]": (msg)=>window.ReactNativeWebView.postMessage(typeof msg === 'string' ? msg : JSON.stringify(msg))
            })["usePostMessage.useMemo[postMessage]"] : ({
                "usePostMessage.useMemo[postMessage]": (msg)=>console.warn('postMessage unavailable', msg)
            })["usePostMessage.useMemo[postMessage]"];
        }
    }["usePostMessage.useMemo[postMessage]"], [
        isNativeApp,
        isLegacyNativeApp
    ]);
    return postMessage;
}
_s(usePostMessage, "1VMqoRt+uimcJd3nYg6oSwrtQSQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$usePlatformInformation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePlatformInformation"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/lib/hooks/useNativeAppEvent.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$usePostMessage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/lib/hooks/usePostMessage.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
/**
 * useNativeAppEvent is a hook that allows you to subscribe to events emitted by the native app.
 * via the window.postMessage API.
 * @param eventName The name of the event to subscribe to.
 * @param callback The callback to call when the event is emitted.
 */ function useNativeAppEvent(eventName, callback, callbackDependencies = []) {
    _s();
    const savedCallback = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(callback);
    const postMessage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$usePostMessage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePostMessage"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useNativeAppEvent.useEffect": ()=>{
            savedCallback.current = callback;
        }
    }["useNativeAppEvent.useEffect"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useNativeAppEvent.useEffect": ()=>{
            const handler = {
                "useNativeAppEvent.useEffect.handler": (event)=>{
                    if (event?.data?.content?.type === eventName) {
                        savedCallback?.current(event.data.content);
                        // Acknowledge to app that message has been handled. Otherwise the app will continue to send it ...
                        postMessage({
                            type: 'ackMessage',
                            id: event?.data?.id
                        });
                    }
                }
            }["useNativeAppEvent.useEffect.handler"];
            document.addEventListener('message', handler);
            return ({
                "useNativeAppEvent.useEffect": ()=>document.removeEventListener('message', handler)
            })["useNativeAppEvent.useEffect"];
        }
    }["useNativeAppEvent.useEffect"], [
        eventName,
        postMessage,
        ...callbackDependencies
    ]);
}
_s(useNativeAppEvent, "j9e7IQHXTUKdmISgPPvsRRrECqA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$usePostMessage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePostMessage"]
    ];
});
const __TURBOPACK__default__export__ = useNativeAppEvent;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/native-app/handlers/app-sign-in-handler.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NAAppSignInHandler",
    ()=>NAAppSignInHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hooks/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/graphql/republik-api/__generated__/gql/graphql.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/lib/hooks/useNativeAppEvent.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/node_modules/zod/lib/index.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const AppStateMessageDataSchema = __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].object({
    current: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string(),
    type: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string()
});
function NAAppSignInHandler() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const lastHandledVerificationUrlRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { data, loading, refetch } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PendingAppSignInDocument"], {
        fetchPolicy: 'network-only'
    });
    function redirect(verificationUrl) {
        const url = new URL(verificationUrl);
        url.searchParams.set('redirect', encodeURIComponent(window.location.href));
        router.replace(url.toString().replace(url.origin, ''));
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('authorization', {
        "NAAppSignInHandler.useNativeAppEvent": async ()=>{
            refetch();
        }
    }["NAAppSignInHandler.useNativeAppEvent"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('appState', {
        "NAAppSignInHandler.useNativeAppEvent": async (content)=>{
            if (AppStateMessageDataSchema.safeParse(content).success && content?.current === 'active') {
                refetch();
            }
        }
    }["NAAppSignInHandler.useNativeAppEvent"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NAAppSignInHandler.useEffect": ()=>{
            if (!loading && data?.pendingAppSignIn && data.pendingAppSignIn.verificationUrl != lastHandledVerificationUrlRef.current) {
                lastHandledVerificationUrlRef.current = data.pendingAppSignIn.verificationUrl;
                redirect(data.pendingAppSignIn.verificationUrl);
            }
        }
    }["NAAppSignInHandler.useEffect"], [
        data
    ]);
    return null;
}
_s(NAAppSignInHandler, "Yh7OBqYXRHRcNNQvibA1GfUSOo4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = NAAppSignInHandler;
var _c;
__turbopack_context__.k.register(_c, "NAAppSignInHandler");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/constants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ADMIN_BASE_URL",
    ()=>ADMIN_BASE_URL,
    "API_AUTHORIZATION_HEADER",
    ()=>API_AUTHORIZATION_HEADER,
    "API_URL",
    ()=>API_URL,
    "API_WS_URL",
    ()=>API_WS_URL,
    "APP_OPTIONS",
    ()=>APP_OPTIONS,
    "CDN_FRONTEND_BASE_URL",
    ()=>CDN_FRONTEND_BASE_URL,
    "DISCUSSION_POLL_INTERVAL_MS",
    ()=>DISCUSSION_POLL_INTERVAL_MS,
    "EMAIL_CONTACT",
    ()=>EMAIL_CONTACT,
    "EMAIL_IR",
    ()=>EMAIL_IR,
    "EMAIL_PAYMENT",
    ()=>EMAIL_PAYMENT,
    "GENERAL_FEEDBACK_DISCUSSION_ID",
    ()=>GENERAL_FEEDBACK_DISCUSSION_ID,
    "ONBOARDING_PACKAGES",
    ()=>ONBOARDING_PACKAGES,
    "OPEN_ACCESS",
    ()=>OPEN_ACCESS,
    "PAYPAL_BUSINESS",
    ()=>PAYPAL_BUSINESS,
    "PAYPAL_DONATE_LINK",
    ()=>PAYPAL_DONATE_LINK,
    "PAYPAL_FORM_ACTION",
    ()=>PAYPAL_FORM_ACTION,
    "PF_FORM_ACTION",
    ()=>PF_FORM_ACTION,
    "PF_PSPID",
    ()=>PF_PSPID,
    "PROLITTERIS_OPT_OUT_CONSENT",
    ()=>PROLITTERIS_OPT_OUT_CONSENT,
    "PUBLIC_BASE_URL",
    ()=>PUBLIC_BASE_URL,
    "PUBLIKATOR_BASE_URL",
    ()=>PUBLIKATOR_BASE_URL,
    "REGWALL_CAMPAIGN",
    ()=>REGWALL_CAMPAIGN,
    "RENDER_FRONTEND_BASE_URL",
    ()=>RENDER_FRONTEND_BASE_URL,
    "SCHEMA_PUBLISHER",
    ()=>SCHEMA_PUBLISHER,
    "SCREENSHOT_SERVER_BASE_URL",
    ()=>SCREENSHOT_SERVER_BASE_URL,
    "STATS_POLL_INTERVAL_MS",
    ()=>STATS_POLL_INTERVAL_MS,
    "STATUS_POLL_INTERVAL_MS",
    ()=>STATUS_POLL_INTERVAL_MS,
    "STRIPE_PUBLISHABLE_KEY",
    ()=>STRIPE_PUBLISHABLE_KEY,
    "TRIAL_CAMPAIGN",
    ()=>TRIAL_CAMPAIGN,
    "TRIAL_CAMPAIGNS",
    ()=>TRIAL_CAMPAIGNS,
    "isClient",
    ()=>isClient,
    "isDev",
    ()=>isDev
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const API_URL = ("TURBOPACK compile-time value", "http://localhost:5010/graphql");
const API_WS_URL = ("TURBOPACK compile-time value", "ws://localhost:5011/graphql");
const SCREENSHOT_SERVER_BASE_URL = ("TURBOPACK compile-time value", "http://localhost:3000");
const API_AUTHORIZATION_HEADER = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_AUTHORIZATION_HEADER;
const APP_OPTIONS = !!("TURBOPACK compile-time value", "true") && ("TURBOPACK compile-time value", "true") !== 'false' && ("TURBOPACK compile-time value", "true") !== '0';
const PUBLIC_BASE_URL = ("TURBOPACK compile-time value", "http://localhost:3010");
const CDN_FRONTEND_BASE_URL = ("TURBOPACK compile-time value", "");
const RENDER_FRONTEND_BASE_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_RENDER_FRONTEND_BASE_URL || PUBLIC_BASE_URL;
const PUBLIKATOR_BASE_URL = ("TURBOPACK compile-time value", "http://localhost:3005");
const ADMIN_BASE_URL = ("TURBOPACK compile-time value", "http://localhost:3006");
const STRIPE_PUBLISHABLE_KEY = ("TURBOPACK compile-time value", "pk_test_sgFutulewhWC8v8csVIXTMea");
const PF_PSPID = ("TURBOPACK compile-time value", "projectrTEST");
const PF_FORM_ACTION = ("TURBOPACK compile-time value", "https://e-payment.postfinance.ch/ncol/test/orderstandard.asp");
const PAYPAL_FORM_ACTION = ("TURBOPACK compile-time value", "https://www.sandbox.paypal.com/cgi-bin/webscr");
const PAYPAL_BUSINESS = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_PAYPAL_BUSINESS;
const PAYPAL_DONATE_LINK = ("TURBOPACK compile-time value", "https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=");
const EMAIL_CONTACT = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_EMAIL_CONTACT;
const EMAIL_IR = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_EMAIL_IR;
const EMAIL_PAYMENT = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_EMAIL_PAYMENT || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_EMAIL_CONTACT;
const OPEN_ACCESS = ("TURBOPACK compile-time value", "true") === 'true';
const DISCUSSION_POLL_INTERVAL_MS = +__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_DISCUSSION_POLL_INTERVAL_MS || 0;
const STATS_POLL_INTERVAL_MS = +__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_STATS_POLL_INTERVAL_MS || 0;
const STATUS_POLL_INTERVAL_MS = +__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_STATUS_POLL_INTERVAL_MS || 0;
const GENERAL_FEEDBACK_DISCUSSION_ID = ("TURBOPACK compile-time value", "ec6ba678-8eb2-45e0-97fa-20d3a4d58b64");
const ONBOARDING_PACKAGES = [
    'ABO',
    'BENEFACTOR',
    'MONTHLY_ABO',
    'YEARLY_ABO'
];
const TRIAL_CAMPAIGN = ("TURBOPACK compile-time value", "e33e858b-a2dc-4bbd-88c5-55663e0c8bf2");
const TRIAL_CAMPAIGNS = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_TRIAL_CAMPAIGNS;
const REGWALL_CAMPAIGN = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_REGWALL_TRIAL_CAMPAIGN_ID;
const SCHEMA_PUBLISHER = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_SCHEMA_PUBLISHER;
const isDev = ("TURBOPACK compile-time value", "development") !== 'production';
const isClient = ("TURBOPACK compile-time value", "object") !== 'undefined';
const PROLITTERIS_OPT_OUT_CONSENT = 'PROLITTERIS_OPT_OUT';
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/native-app/handlers/routing-handler.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NARoutingHandler",
    ()=>NARoutingHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/lib/hooks/useNativeAppEvent.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$usePostMessage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/lib/hooks/usePostMessage.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function useOnRouteChange(callBack) {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const callbackRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(callBack);
    const lastUrlRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useOnRouteChange.useEffect": ()=>{
            try {
                const url = new URL(pathname, window.location.origin);
                url.search = searchParams.toString();
                const urlStr = url.toString();
                if (lastUrlRef.current === urlStr) {
                    return;
                }
                lastUrlRef.current = urlStr;
                callbackRef.current(urlStr);
            } catch (e) {
                console.error(e);
            }
        }
    }["useOnRouteChange.useEffect"], [
        pathname,
        searchParams
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useOnRouteChange.useEffect": ()=>{
            callbackRef.current = callBack;
        }
    }["useOnRouteChange.useEffect"], [
        callBack
    ]);
}
_s(useOnRouteChange, "eiFcu42FRjILBC4kjzHcEFILZCE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
function NARoutingHandler() {
    _s1();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const postMessage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$usePostMessage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePostMessage"])();
    const previousPushUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(undefined);
    useOnRouteChange({
        "NARoutingHandler.useOnRouteChange": (url)=>{
            postMessage({
                type: 'routeChange',
                payload: {
                    url
                }
            });
        }
    }["NARoutingHandler.useOnRouteChange"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('push-route', {
        "NARoutingHandler.useNativeAppEvent": async (content)=>{
            if (!content.url || typeof content.url !== 'string') {
                console.error('push-route: invalid url', content);
                return;
            }
            const targetUrl = content.url.replace(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PUBLIC_BASE_URL"], '');
            // Check for and ignore recurring attempts to navigate to the same URL
            if (previousPushUrl.current !== targetUrl) {
                previousPushUrl.current = targetUrl;
                router.push(targetUrl);
            }
        }
    }["NARoutingHandler.useNativeAppEvent"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('back', {
        "NARoutingHandler.useNativeAppEvent": ()=>{
            router.back();
        }
    }["NARoutingHandler.useNativeAppEvent"]);
    return null;
}
_s1(NARoutingHandler, "4RvgqcW6H9q0YuJ0wj1xjouM9hY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$usePostMessage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePostMessage"],
        useOnRouteChange,
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = NARoutingHandler;
var _c;
__turbopack_context__.k.register(_c, "NARoutingHandler");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/native-app/handlers/register-device-push-notification-handler.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NARegisterDevicePushNotificationHandler",
    ()=>NARegisterDevicePushNotificationHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/lib/hooks/useNativeAppEvent.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
function NARegisterDevicePushNotificationHandler() {
    _s();
    // const [upsertDevice] = useMutation()
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('onPushRegistered', {
        "NARegisterDevicePushNotificationHandler.useNativeAppEvent": (content)=>{
            //  const { token, os, osVersion, model, appVersion, userAgent } = content.data
            //  upsertDevice({
            //    variables: {
            //      token,
            //      information: {
            //        os,
            //        osVersion,
            //        model,
            //        appVersion,
            //        userAgent,
            //      },
            //    },
            //  })
            console.log('onPushRegistered', content);
        }
    }["NARegisterDevicePushNotificationHandler.useNativeAppEvent"]);
    return null;
}
_s(NARegisterDevicePushNotificationHandler, "08/Wx1BXyJGlQ2YjZvYEravz+PA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = NARegisterDevicePushNotificationHandler;
var _c;
__turbopack_context__.k.register(_c, "NARegisterDevicePushNotificationHandler");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/native-app/handlers/color-scheme-handler.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NAColorSchemeSyncHandler",
    ()=>NAColorSchemeSyncHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/lib/hooks/useNativeAppEvent.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
function NAColorSchemeSyncHandler() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('osColorScheme', {
        "NAColorSchemeSyncHandler.useNativeAppEvent": (content)=>{
        // if (content.type === 'osColorScheme') {
        //     if (content.value) {
        //       setOSColorScheme(content.value)
        //     }
        }
    }["NAColorSchemeSyncHandler.useNativeAppEvent"]);
    return null;
}
_s(NAColorSchemeSyncHandler, "08/Wx1BXyJGlQ2YjZvYEravz+PA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$lib$2f$hooks$2f$useNativeAppEvent$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = NAColorSchemeSyncHandler;
var _c;
__turbopack_context__.k.register(_c, "NAColorSchemeSyncHandler");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/theme-provider.tsx [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeProvider",
    ()=>ThemeProvider,
    "useForceTheme",
    ()=>useForceTheme
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-themes/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
const ForceThemeCtx = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(_c = ()=>{});
_c1 = ForceThemeCtx;
function useForceTheme(theme) {
    _s();
    const setForced = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ForceThemeCtx);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useForceTheme.useEffect": ()=>{
            setForced(theme);
            return ({
                "useForceTheme.useEffect": ()=>setForced(undefined)
            })["useForceTheme.useEffect"];
        }
    }["useForceTheme.useEffect"], [
        theme,
        setForced
    ]);
}
_s(useForceTheme, "M/hBRkYtX2cozDhYQRjYxzQ+lkk=");
const ThemeProvider = ({ children })=>{
    _s1();
    const [forced, setForced] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ForceThemeCtx.Provider, {
        value: setForced,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeProvider"], {
            attribute: "data-theme",
            disableTransitionOnChange: true,
            forcedTheme: forced,
            children: children
        }, void 0, false, {
            fileName: "[project]/apps/www/src/app/components/theme-provider.tsx",
            lineNumber: 30,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/components/theme-provider.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s1(ThemeProvider, "sJAiYgtvqGpMkUmmUtZoVTm79Sg=");
_c2 = ThemeProvider;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ForceThemeCtx$createContext");
__turbopack_context__.k.register(_c1, "ForceThemeCtx");
__turbopack_context__.k.register(_c2, "ThemeProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/theme-provider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeProvider",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$theme$2d$provider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ThemeProvider"],
    "useForceTheme",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$theme$2d$provider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useForceTheme"],
    "useTheme",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTheme"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$theme$2d$provider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/theme-provider.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-themes/dist/index.mjs [app-client] (ecmascript)");
}),
"[project]/apps/www/src/lib/apollo/withMe.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "checkRoles",
    ()=>checkRoles,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hoc$2f$graphql$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hoc/graphql.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/graphql/republik-api/__generated__/gql/graphql.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/constants.js [app-client] (ecmascript)");
;
;
;
const checkRoles = (me, roles)=>{
    return !!(me && (!roles || me.roles && me.roles.some((role)=>roles.indexOf(role) !== -1)));
};
const __TURBOPACK__default__export__ = _c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hoc$2f$graphql$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["graphql"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MeDocument"], {
    props: ({ data: { me, refetch } })=>({
            me,
            meRefetch: refetch,
            hasActiveMembership: !!me?.activeMembership || !!me?.activeMagazineSubscription,
            hasAccess: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OPEN_ACCESS"] ? true : checkRoles(me, [
                'member'
            ])
        })
});
var _c;
__turbopack_context__.k.register(_c, "%default%");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/context/getInitials.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getInitials",
    ()=>getInitials
]);
const getInitials = (me)=>(me.name && me.name.trim() ? me.name.split(' ').filter((n, i, all)=>i === 0 || all.length - 1 === i) : me.email.split('@')[0].split(/\.|-|_/).slice(0, 2)).slice(0, 2).filter(Boolean).map((s)=>s[0]).join('');
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/context/MeContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ME_PORTRAIT_STORAGE_KEY",
    ()=>ME_PORTRAIT_STORAGE_KEY,
    "default",
    ()=>__TURBOPACK__default__export__,
    "useMe",
    ()=>useMe
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/noop-head.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hooks/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$apollo$2f$withMe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/apollo/withMe.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/glamor/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/graphql/republik-api/__generated__/gql/graphql.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$getInitials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/context/getInitials.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
const HAS_ACTIVE_MEMBERSHIP_ATTRIBUTE = 'data-has-active-membership';
const HAS_ACTIVE_MEMBERSHIP_STORAGE_KEY = 'me.hasActiveMembership';
const ME_PORTRAIT_ATTRIBUTE = 'data-me-portrait';
const ME_PORTRAIT_STORAGE_KEY = 'me.portraitOrInitials';
const IS_CLIMATELAB_MEMBER_ATTRIBUTE = 'data-is-climatelab-member';
const IS_CLIMATELAB_MEMBER_STORAGE_KEY = 'me.isClimatelabMember';
const CLIMATELAB_ONLY_ITEM_ATTRIBUTE = 'data-climatelab-only';
// Rule to hide elements while a statically generated page is fetching the active-user
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"].global(`:root[${ME_PORTRAIT_ATTRIBUTE}="true"] [data-hide-if-me="true"]`, {
    display: 'none !important'
});
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"].global(':root [data-show-if-me="true"]', {
    display: 'none !important'
});
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"].global(`:root[${ME_PORTRAIT_ATTRIBUTE}="true"] [data-show-if-me="true"]`, {
    display: 'block !important'
});
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"].global(`:root[${HAS_ACTIVE_MEMBERSHIP_ATTRIBUTE}="true"] [data-hide-if-active-membership="true"]`, {
    display: 'none !important'
});
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"].global(':root [data-show-if-active-membership="true"]', {
    display: 'none !important'
});
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"].global(`:root[${HAS_ACTIVE_MEMBERSHIP_ATTRIBUTE}="true"] [data-show-if-active-membership="true"]`, {
    display: 'block !important'
});
// Climate-lab global styles
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"].global(`:root[${IS_CLIMATELAB_MEMBER_ATTRIBUTE}="true"] [${CLIMATELAB_ONLY_ITEM_ATTRIBUTE}="true"]`, {
    display: 'block !important'
});
// Hide climate-lab only items for non-climate-lab members
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"].global(`:root [${CLIMATELAB_ONLY_ITEM_ATTRIBUTE}="true"]`, {
    display: 'none !important'
});
const getTrialStatus = (me)=>{
    // anonymous user: de facto eligible for trial
    if (!me) return 'TRIAL_ELIGIBLE';
    // has membership or active Abo teilen etc: not relevant for trial
    // important: trial users have the member role, too, but they don't have a subscription
    if (me.activeMembership || me.activeMagazineSubscription) return 'MEMBER';
    // In trial user:
    // We use the first character of the user id to assign a trial group.
    // The character is either a number [0-9] or a letter [a-f].
    // [0-7] -> group A, [8-f] -> group B
    if (me.regwallTrialStatus === 'Active') {
        const firstChar = me.id[0];
        return [
            '0',
            '1',
            '2',
            '3',
            '4',
            '5',
            '6',
            '7'
        ].includes(firstChar) ? 'TRIAL_GROUP_A' // in trial user, AB-test group A
         : 'TRIAL_GROUP_B' // in trial user, AB-test group B
        ;
    }
    // abo teilen user: have the member role and should see the magazine
    if (me.roles?.includes('member')) return 'TRIAL_GROUP_TEILEN';
    // logged-in user, has done a "regwall" trial: not eligible for trial
    if (me.regwallTrialStatus === 'Past') return 'NOT_TRIAL_ELIGIBLE';
    // logged-in user, hasn't done a "regwall" trial yet: eligible for trial
    if (!me.regwallTrialStatus) return 'TRIAL_ELIGIBLE';
};
const MeContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({});
const useMe = ()=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(MeContext);
};
_s(useMe, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
const MeContextProvider = ({ children, assumeAccess = false })=>{
    _s1();
    const { data, loading, error, refetch } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$graphql$2f$republik$2d$api$2f$_$5f$generated_$5f2f$gql$2f$graphql$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MeDocument"], {});
    const me = data?.me;
    const isMember = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$apollo$2f$withMe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["checkRoles"])(me, [
        'member'
    ]);
    const isClimateLabMember = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$apollo$2f$withMe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["checkRoles"])(me, [
        'climate'
    ]);
    const hasActiveMembership = !!me?.activeMembership || !!me?.activeMagazineSubscription;
    const portraitOrInitials = me ? me.portrait ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$getInitials$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(me) : false;
    const trialStatus = getTrialStatus(me);
    const allowlistName = data?.ipAllowlistAccess?.name ?? null;
    const hasAllowlistAccess = !!allowlistName;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MeContextProvider.useEffect": ()=>{
            if (loading) return;
            if (portraitOrInitials) {
                document.documentElement.setAttribute(ME_PORTRAIT_ATTRIBUTE, 'true');
            } else {
                document.documentElement.removeAttribute(ME_PORTRAIT_ATTRIBUTE);
            }
            if (hasActiveMembership) {
                document.documentElement.setAttribute(HAS_ACTIVE_MEMBERSHIP_ATTRIBUTE, 'true');
            } else {
                document.documentElement.removeAttribute(HAS_ACTIVE_MEMBERSHIP_ATTRIBUTE);
            }
            try {
                if (portraitOrInitials) {
                    localStorage.setItem(ME_PORTRAIT_STORAGE_KEY, portraitOrInitials);
                } else {
                    localStorage.removeItem(ME_PORTRAIT_STORAGE_KEY);
                }
                if (hasActiveMembership) {
                    localStorage.setItem(HAS_ACTIVE_MEMBERSHIP_STORAGE_KEY, String(hasActiveMembership));
                } else {
                    localStorage.removeItem(HAS_ACTIVE_MEMBERSHIP_STORAGE_KEY);
                }
            // eslint-disable-next-line no-empty
            } catch (e) {}
        }
    }["MeContextProvider.useEffect"], [
        loading,
        portraitOrInitials,
        hasActiveMembership
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MeContextProvider.useEffect": ()=>{
            try {
                if (loading) return;
                if (isClimateLabMember) {
                    localStorage.setItem(IS_CLIMATELAB_MEMBER_STORAGE_KEY, 'true');
                    document.documentElement.setAttribute(IS_CLIMATELAB_MEMBER_ATTRIBUTE, 'true');
                } else {
                    localStorage.setItem(IS_CLIMATELAB_MEMBER_STORAGE_KEY, 'false');
                    document.documentElement.removeAttribute(IS_CLIMATELAB_MEMBER_ATTRIBUTE);
                }
            } catch (e) {}
        }
    }["MeContextProvider.useEffect"], [
        isClimateLabMember,
        loading
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MeContext.Provider, {
        value: {
            me: me,
            meLoading: loading,
            meError: error,
            meRefetch: refetch,
            hasActiveMembership,
            hasAccess: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OPEN_ACCESS"] ? true : !data && assumeAccess ? assumeAccess : isMember,
            isMember: isMember,
            isEditor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$apollo$2f$withMe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["checkRoles"])(me, [
                'editor'
            ]),
            isClimateLabMember,
            trialStatus,
            // Progress consent requires a logged in user AND them not having opted out
            progressConsent: me && me.progressOptOut !== true,
            allowlistName,
            hasAllowlistAccess
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
                    dangerouslySetInnerHTML: {
                        __html: [
                            'try{',
                            `var isMember = localStorage.getItem("${HAS_ACTIVE_MEMBERSHIP_STORAGE_KEY}");`,
                            `if (isMember === "true")`,
                            `document.documentElement.setAttribute("${HAS_ACTIVE_MEMBERSHIP_ATTRIBUTE}", isMember);`,
                            `if (localStorage.getItem("${ME_PORTRAIT_STORAGE_KEY}"))`,
                            `document.documentElement.setAttribute("${ME_PORTRAIT_ATTRIBUTE}", "true");`,
                            `var isClimateLabMember = localStorage.getItem("${IS_CLIMATELAB_MEMBER_STORAGE_KEY}");`,
                            `if (isClimateLabMember === "true")`,
                            `document.documentElement.setAttribute("${IS_CLIMATELAB_MEMBER_ATTRIBUTE}", isClimateLabMember); `,
                            '} catch(e) {console.error(e)}'
                        ].join('')
                    }
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/lib/context/MeContext.tsx",
                    lineNumber: 231,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/apps/www/src/lib/context/MeContext.tsx",
                lineNumber: 230,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/lib/context/MeContext.tsx",
        lineNumber: 208,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s1(MeContextProvider, "3rbdl1gJs76kcuakYPDUsdB/jJ4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
_c = MeContextProvider;
const __TURBOPACK__default__export__ = MeContextProvider;
var _c;
__turbopack_context__.k.register(_c, "MeContextProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/lib/analytics/provider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnalyticsProvider",
    ()=>AnalyticsProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/context/MeContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$plausible$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-plausible/dist/index.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const AnalyticsProvider = (props)=>{
    _s();
    const { me, hasActiveMembership, trialStatus, meLoading, allowlistName } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMe"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$plausible$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        domain: ("TURBOPACK compile-time value", "republik.love"),
        revenue: true,
        trackLocalhost: true,
        pageviewProps: {
            user_type: hasActiveMembership ? 'member' : me ? 'logged in' : 'anonymous',
            trial_status: trialStatus,
            ...allowlistName && {
                ip_allowlist: allowlistName
            }
        },
        // Defer enabling analytics until me query has been loaded. This should still reliably track the 1st page view, just a bit later.
        enabled: !meLoading,
        ...props
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/lib/analytics/provider.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(AnalyticsProvider, "yIV2iwaKdnW8cfVSlLRC6Tolt+o=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$context$2f$MeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMe"]
    ];
});
_c = AnalyticsProvider;
var _c;
__turbopack_context__.k.register(_c, "AnalyticsProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/lib/errors/reportError.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "reportError",
    ()=>reportError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$core$2f$build$2f$esm$2f$exports$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sentry/core/build/esm/exports.js [app-client] (ecmascript)");
;
async function reportError(context, error) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$core$2f$build$2f$esm$2f$exports$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureException"](error, {
        tags: {
            origin: 'reportError-func',
            reportErrorContext: context
        }
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/lib/analytics/utm-session-storage.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SyncUTMToSessionStorage",
    ()=>SyncUTMToSessionStorage,
    "getUTMSessionStorage",
    ()=>getUTMSessionStorage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$errors$2f$reportError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/errors/reportError.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const STORAGE_KEY = 'republik-utm';
function setUTMSessionStorage() {
    try {
        const params = getUTMSessionStorage();
        for (const [k, v] of new URLSearchParams(window.location.search)){
            if (k.startsWith('utm_')) {
                params[k] = v;
            }
        }
        window.sessionStorage.setItem(STORAGE_KEY, JSON.stringify(params));
    } catch (error) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$errors$2f$reportError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reportError"])('setUTMSessionStorage', error instanceof Error ? error : String(error));
    }
}
function getUTMSessionStorage() {
    try {
        return JSON.parse(window.sessionStorage.getItem(STORAGE_KEY) ?? '{}');
    } catch (error) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$errors$2f$reportError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reportError"])('getUTMSessionStorage', error instanceof Error ? error : String(error));
    }
    return {};
}
function SyncUTMToSessionStorage() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SyncUTMToSessionStorage.useEffect": ()=>{
            setUTMSessionStorage();
        }
    }["SyncUTMToSessionStorage.useEffect"], []);
    return null;
}
_s(SyncUTMToSessionStorage, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = SyncUTMToSessionStorage;
var _c;
__turbopack_context__.k.register(_c, "SyncUTMToSessionStorage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/lib/apollo/provider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ApolloWrapper",
    ()=>ApolloWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$http$2f$HttpLink$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/link/http/HttpLink.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$integration$2d$nextjs$2f$dist$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client-integration-nextjs/dist/index.browser.js [app-client] (ecmascript) <locals>");
'use client';
;
;
;
function makeClient() {
    const httpLink = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$http$2f$HttpLink$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HttpLink"]({
        uri: ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : '/graphql',
        credentials: 'include'
    });
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$integration$2d$nextjs$2f$dist$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ApolloClient"]({
        cache: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$integration$2d$nextjs$2f$dist$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["InMemoryCache"](),
        link: ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : httpLink
    });
}
function ApolloWrapper({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$integration$2d$nextjs$2f$dist$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ApolloNextAppProvider"], {
        makeClient: makeClient,
        children: children
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/lib/apollo/provider.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
_c = ApolloWrapper;
var _c;
__turbopack_context__.k.register(_c, "ApolloWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# debugId=17b6eba5-3d25-da89-f058-61ebbbb8110c
//# sourceMappingURL=apps_www_0_8fz~p._.js.map