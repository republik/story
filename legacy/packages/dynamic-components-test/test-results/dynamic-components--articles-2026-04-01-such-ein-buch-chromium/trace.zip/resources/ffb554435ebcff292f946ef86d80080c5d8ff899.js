;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="05521c61-bb64-7f38-147b-6c21fdbdd1e7")}catch(e){}}();
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/packages/theme/logo.json.[json].cjs [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = {
    "BRAND_MARK_PATH": "M115.667 115.595L95.393 72.228c-15.316.61-28.904-2.242-28.904-2.242V67.81c24.692-4.344 47.487-12.462 47.487-34.28C113.977 5.92 88.8.136 59.822.007L59.816 0H0v4.7l11.6 6.24 2.26 4.6v95.456l-2.26 4.6L0 121.832v4.702h62.816v-4.702l-11.598-6.238-2.44-4.6V80.77l10.07-8.575 22.035 54.34h46.38v-4.702l-11.596-6.238zM62.3 7.325c8.183 1.527 14.355 8.964 14.355 27.578 0 21.176-8.317 27.912-21.95 27.912h-5.928V17.07L62.3 7.325z",
    "BRAND_MARK_VIEWBOX": "0 0 127.264 127.264",
    "LOGO_PATH": "M721.463 133.73v-4.7l11.6-6.24 2.26-4.6V22.735l-2.26-4.6-11.6-6.238v-4.7h62.818v4.7l-11.6 6.238-2.438 4.6v95.457l2.44 4.6 11.6 6.24v4.7h-62.82zM424.22 136.78c34.81 0 46.53-20.452 46.53-46.696V26.59l2.438-4.6 17.783-10.094v-4.7h-51.005v4.7l17.963 10.095 2.26 4.6v63.132c0 23.71-10.033 34.027-25.08 34.027-15.55 0-24.078-11.403-24.078-34.753l.002-66.262 2.44-4.6 11.6-6.24v-4.7h-62.82v4.7l11.6 6.24 2.26 4.6V89.54c0 33.305 18.02 47.24 48.107 47.24zM715.02 87.195l-28.378 36.894h-23.156V22.733l2.442-4.6 11.597-6.24v-4.7H614.71v4.7l11.6 6.24 2.258 4.6v95.457l-2.26 4.6-11.6 6.24v4.7h98.6l6.415-46.535M309.033 7.208l-.012-.013h-59.817v4.7l11.6 6.238 2.26 4.6v95.458l-2.26 4.6-11.6 6.24v4.7h62.817v-4.7l-11.6-6.24-2.44-4.6V86.456l5.496-4.836 19.513 7.26c21.39-2.392 40.19-19.536 40.19-39.93 0-28.612-22.613-41.47-54.147-41.742zm-3.012 68.08h-8.04V24.324l13.608-9.857c8.34 2.882 14.27 11.627 14.27 29.56 0 22.694-11.044 31.263-19.837 31.263zM233.688 87.193l-28.71 36.896h-26.224V73.983h11.035l4.4 3.65 10.2 16.22h5v-49.2h-5l-10.2 16.22-4.4 3.65h-11.036V25.97l12.73-9.136h12.03l28.024 34.896h4.983L229.19 0h-5.213l-5.788 7.195h-88.214v4.7l11.6 6.24 2.26 4.6v95.456l-2.26 4.6-10.184 6.24v4.7h100.163l7.117-46.537M913.52 122.79L875.7 50.81l34.8-34.314 9.282-4.6v-4.7H874.5v30.59l-24.884 24.382h-6.826V22.732l2.44-4.6 11.6-6.24v-4.7H794.01v4.7l11.6 6.24 2.26 4.6v95.46l-2.26 4.6-11.6 6.237v4.7h62.817v-4.7l-11.6-6.24-2.44-4.6V83.26l5.61-5.534 30.407 56.004h46.31v-4.7M115.67 122.79L95.395 79.423c-15.315.61-28.903-2.24-28.903-2.24V75c24.693-4.342 47.487-12.46 47.487-34.276 0-27.613-25.178-33.396-54.154-33.525l-.006-.005H.003v4.7l11.6 6.24 2.26 4.6v95.456l-2.26 4.6-11.6 6.24v4.7H62.82v-4.7l-11.6-6.24-2.44-4.6V87.965l10.07-8.575 22.035 54.34h46.382v-4.7l-11.598-6.24zM62.302 14.52c8.184 1.527 14.354 8.963 14.354 27.578 0 21.176-8.315 27.912-21.948 27.912h-5.93V24.266l13.523-9.747zM568.615 69.232v-2.136c22.137-4.47 36.877-13.75 36.877-30.26 0-18.82-16.657-29.642-45.396-29.642h-66.903v4.7l11.6 6.24 2.26 4.6v95.456l-2.26 4.6-11.6 6.24v4.7h68.4c26.272-.708 47.42-10.087 47.42-33.62 0-21.525-17.542-28.874-40.398-30.878zM555.74 14.34c7.565 2.452 13.404 9.734 13.404 25.316 0 19.984-8.392 26.342-21.886 26.342h-5.288V24.266l13.77-9.927zm-7.75 109.75h-6.02V83.983l14.292-10.232c10.236 2.52 16.403 9.83 16.403 25.322 0 20.04-9.634 25.015-24.676 25.015z",
    "LOGO_VIEWBOX": "0 0 925.115 136.781",
    "LOGO_GRADIENT": ""
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__objRest",
    ()=>__objRest,
    "__spreadValues",
    ()=>__spreadValues,
    "compact",
    ()=>compact,
    "createCss",
    ()=>createCss,
    "createMergeCss",
    ()=>createMergeCss,
    "filterBaseConditions",
    ()=>filterBaseConditions,
    "getPatternStyles",
    ()=>getPatternStyles,
    "getSlotCompoundVariant",
    ()=>getSlotCompoundVariant,
    "getSlotRecipes",
    ()=>getSlotRecipes,
    "hypenateProperty",
    ()=>hypenateProperty,
    "isBaseCondition",
    ()=>isBaseCondition,
    "isObject",
    ()=>isObject,
    "mapObject",
    ()=>mapObject,
    "memo",
    ()=>memo,
    "mergeProps",
    ()=>mergeProps,
    "patternFns",
    ()=>patternFns,
    "splitProps",
    ()=>splitProps,
    "toHash",
    ()=>toHash,
    "uniq",
    ()=>uniq,
    "walkObject",
    ()=>walkObject,
    "withoutSpace",
    ()=>withoutSpace
]);
// src/assert.ts
function isObject(value) {
    return typeof value === "object" && value != null && !Array.isArray(value);
}
var isObjectOrArray = (obj)=>typeof obj === "object" && obj !== null;
// src/compact.ts
function compact(value) {
    return Object.fromEntries(Object.entries(value ?? {}).filter(([_, value2])=>value2 !== void 0));
}
// src/condition.ts
var isBaseCondition = (v)=>v === "base";
function filterBaseConditions(c) {
    return c.slice().filter((v)=>!isBaseCondition(v));
}
// src/hash.ts
function toChar(code) {
    return String.fromCharCode(code + (code > 25 ? 39 : 97));
}
function toName(code) {
    let name = "";
    let x;
    for(x = Math.abs(code); x > 52; x = x / 52 | 0)name = toChar(x % 52) + name;
    return toChar(x % 52) + name;
}
function toPhash(h, x) {
    let i = x.length;
    while(i)h = h * 33 ^ x.charCodeAt(--i);
    return h;
}
function toHash(value) {
    return toName(toPhash(5381, value) >>> 0);
}
// src/important.ts
var importantRegex = /\s*!(important)?/i;
function isImportant(value) {
    return typeof value === "string" ? importantRegex.test(value) : false;
}
function withoutImportant(value) {
    return typeof value === "string" ? value.replace(importantRegex, "").trim() : value;
}
function withoutSpace(str) {
    return typeof str === "string" ? str.replaceAll(" ", "_") : str;
}
// src/memo.ts
var memo = (fn)=>{
    const cache = /* @__PURE__ */ new Map();
    const get = (...args)=>{
        const key = JSON.stringify(args);
        if (cache.has(key)) {
            return cache.get(key);
        }
        const result = fn(...args);
        cache.set(key, result);
        return result;
    };
    return get;
};
// src/merge-props.ts
var MERGE_OMIT = /* @__PURE__ */ new Set([
    "__proto__",
    "constructor",
    "prototype"
]);
function mergeProps(...sources) {
    return sources.reduce((prev, obj)=>{
        if (!obj) return prev;
        Object.keys(obj).forEach((key)=>{
            if (MERGE_OMIT.has(key)) return;
            const prevValue = prev[key];
            const value = obj[key];
            if (isObject(prevValue) && isObject(value)) {
                prev[key] = mergeProps(prevValue, value);
            } else {
                prev[key] = value;
            }
        });
        return prev;
    }, {});
}
// src/walk-object.ts
var isNotNullish = (element)=>element != null;
function walkObject(target, predicate, options = {}) {
    const { stop, getKey } = options;
    function inner(value, path = []) {
        if (isObjectOrArray(value)) {
            const result = {};
            for (const [prop, child] of Object.entries(value)){
                const key = getKey?.(prop, child) ?? prop;
                const childPath = [
                    ...path,
                    key
                ];
                if (stop?.(value, childPath)) {
                    return predicate(value, path);
                }
                const next = inner(child, childPath);
                if (isNotNullish(next)) {
                    result[key] = next;
                }
            }
            return result;
        }
        return predicate(value, path);
    }
    return inner(target);
}
function mapObject(obj, fn) {
    if (Array.isArray(obj)) return obj.map((value)=>fn(value));
    if (!isObject(obj)) return fn(obj);
    return walkObject(obj, (value)=>fn(value));
}
// src/normalize-style-object.ts
function toResponsiveObject(values, breakpoints) {
    return values.reduce((acc, current, index)=>{
        const key = breakpoints[index];
        if (current != null) {
            acc[key] = current;
        }
        return acc;
    }, {});
}
function normalizeStyleObject(styles, context, shorthand = true) {
    const { utility, conditions } = context;
    const { hasShorthand, resolveShorthand } = utility;
    return walkObject(styles, (value)=>{
        return Array.isArray(value) ? toResponsiveObject(value, conditions.breakpoints.keys) : value;
    }, {
        stop: (value)=>Array.isArray(value),
        getKey: shorthand ? (prop)=>hasShorthand ? resolveShorthand(prop) : prop : void 0
    });
}
// src/classname.ts
var fallbackCondition = {
    shift: (v)=>v,
    finalize: (v)=>v,
    breakpoints: {
        keys: []
    }
};
var sanitize = (value)=>typeof value === "string" ? value.replaceAll(/[\n\s]+/g, " ") : value;
function createCss(context) {
    const { utility, hash, conditions: conds = fallbackCondition } = context;
    const formatClassName = (str)=>[
            utility.prefix,
            str
        ].filter(Boolean).join("-");
    const hashFn = (conditions, className)=>{
        let result;
        if (hash) {
            const baseArray = [
                ...conds.finalize(conditions),
                className
            ];
            result = formatClassName(utility.toHash(baseArray, toHash));
        } else {
            const baseArray = [
                ...conds.finalize(conditions),
                formatClassName(className)
            ];
            result = baseArray.join(":");
        }
        return result;
    };
    return memo(({ base, ...styles } = {})=>{
        const styleObject = Object.assign(styles, base);
        const normalizedObject = normalizeStyleObject(styleObject, context);
        const classNames = /* @__PURE__ */ new Set();
        walkObject(normalizedObject, (value, paths)=>{
            if (value == null) return;
            const important = isImportant(value);
            const [prop, ...allConditions] = conds.shift(paths);
            const conditions = filterBaseConditions(allConditions);
            const transformed = utility.transform(prop, withoutImportant(sanitize(value)));
            let className = hashFn(conditions, transformed.className);
            if (important) className = `${className}!`;
            classNames.add(className);
        });
        return Array.from(classNames).join(" ");
    });
}
function compactStyles(...styles) {
    return styles.flat().filter((style)=>isObject(style) && Object.keys(compact(style)).length > 0);
}
function createMergeCss(context) {
    function resolve(styles) {
        const allStyles = compactStyles(...styles);
        if (allStyles.length === 1) return allStyles;
        return allStyles.map((style)=>normalizeStyleObject(style, context));
    }
    function mergeCss(...styles) {
        return mergeProps(...resolve(styles));
    }
    function assignCss(...styles) {
        return Object.assign({}, ...resolve(styles));
    }
    return {
        mergeCss: memo(mergeCss),
        assignCss
    };
}
// src/hypenate-property.ts
var wordRegex = /([A-Z])/g;
var msRegex = /^ms-/;
var hypenateProperty = memo((property)=>{
    if (property.startsWith("--")) return property;
    return property.replace(wordRegex, "-$1").replace(msRegex, "-ms-").toLowerCase();
});
// src/is-css-function.ts
var fns = [
    "min",
    "max",
    "clamp",
    "calc"
];
var fnRegExp = new RegExp(`^(${fns.join("|")})\\(.*\\)`);
var isCssFunction = (v)=>typeof v === "string" && fnRegExp.test(v);
// src/is-css-unit.ts
var lengthUnits = "cm,mm,Q,in,pc,pt,px,em,ex,ch,rem,lh,rlh,vw,vh,vmin,vmax,vb,vi,svw,svh,lvw,lvh,dvw,dvh,cqw,cqh,cqi,cqb,cqmin,cqmax,%";
var lengthUnitsPattern = `(?:${lengthUnits.split(",").join("|")})`;
var lengthRegExp = new RegExp(`^[+-]?[0-9]*.?[0-9]+(?:[eE][+-]?[0-9]+)?${lengthUnitsPattern}$`);
var isCssUnit = (v)=>typeof v === "string" && lengthRegExp.test(v);
// src/is-css-var.ts
var isCssVar = (v)=>typeof v === "string" && /^var\(--.+\)$/.test(v);
// src/pattern-fns.ts
var patternFns = {
    map: mapObject,
    isCssFunction,
    isCssVar,
    isCssUnit
};
var getPatternStyles = (pattern, styles)=>{
    if (!pattern?.defaultValues) return styles;
    const defaults = typeof pattern.defaultValues === "function" ? pattern.defaultValues(styles) : pattern.defaultValues;
    return Object.assign({}, defaults, compact(styles));
};
// src/slot.ts
var getSlotRecipes = (recipe = {})=>{
    const init = (slot)=>({
            className: [
                recipe.className,
                slot
            ].filter(Boolean).join("__"),
            base: recipe.base?.[slot] ?? {},
            variants: {},
            defaultVariants: recipe.defaultVariants ?? {},
            compoundVariants: recipe.compoundVariants ? getSlotCompoundVariant(recipe.compoundVariants, slot) : []
        });
    const slots = recipe.slots ?? [];
    const recipeParts = slots.map((slot)=>[
            slot,
            init(slot)
        ]);
    for (const [variantsKey, variantsSpec] of Object.entries(recipe.variants ?? {})){
        for (const [variantKey, variantSpec] of Object.entries(variantsSpec)){
            recipeParts.forEach(([slot, slotRecipe])=>{
                slotRecipe.variants[variantsKey] ??= {};
                slotRecipe.variants[variantsKey][variantKey] = variantSpec[slot] ?? {};
            });
        }
    }
    return Object.fromEntries(recipeParts);
};
var getSlotCompoundVariant = (compoundVariants, slotName)=>compoundVariants.filter((compoundVariant)=>compoundVariant.css[slotName]).map((compoundVariant)=>({
            ...compoundVariant,
            css: compoundVariant.css[slotName]
        }));
// src/split-props.ts
function splitProps(props, ...keys) {
    const descriptors = Object.getOwnPropertyDescriptors(props);
    const dKeys = Object.keys(descriptors);
    const split = (k)=>{
        const clone = {};
        for(let i = 0; i < k.length; i++){
            const key = k[i];
            if (descriptors[key]) {
                Object.defineProperty(clone, key, descriptors[key]);
                delete descriptors[key];
            }
        }
        return clone;
    };
    const fn = (key)=>split(Array.isArray(key) ? key : dKeys.filter(key));
    return keys.map(fn).concat(split(dKeys));
}
// src/uniq.ts
var uniq = (...items)=>{
    const set = items.reduce((acc, currItems)=>{
        if (currItems) {
            currItems.forEach((item)=>acc.add(item));
        }
        return acc;
    }, /* @__PURE__ */ new Set([]));
    return Array.from(set);
};
;
function __spreadValues(a, b) {
    return {
        ...a,
        ...b
    };
}
function __objRest(source, exclude) {
    return Object.fromEntries(Object.entries(source).filter(([key])=>!exclude.includes(key)));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/css/conditions.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "finalizeConditions",
    ()=>finalizeConditions,
    "isCondition",
    ()=>isCondition,
    "sortConditions",
    ()=>sortConditions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
;
const conditionsStr = "_hover,_focus,_focusWithin,_focusVisible,_disabled,_active,_visited,_target,_readOnly,_readWrite,_empty,_checked,_enabled,_expanded,_highlighted,_complete,_incomplete,_dragging,_before,_after,_firstLetter,_firstLine,_marker,_selection,_file,_backdrop,_first,_last,_only,_even,_odd,_firstOfType,_lastOfType,_onlyOfType,_peerFocus,_peerHover,_peerActive,_peerFocusWithin,_peerFocusVisible,_peerDisabled,_peerChecked,_peerInvalid,_peerExpanded,_peerPlaceholderShown,_groupFocus,_groupHover,_groupActive,_groupFocusWithin,_groupFocusVisible,_groupDisabled,_groupChecked,_groupExpanded,_groupInvalid,_indeterminate,_required,_valid,_invalid,_autofill,_inRange,_outOfRange,_placeholder,_placeholderShown,_pressed,_selected,_grabbed,_underValue,_overValue,_atValue,_default,_optional,_open,_closed,_fullscreen,_loading,_hidden,_current,_currentPage,_currentStep,_today,_unavailable,_rangeStart,_rangeEnd,_now,_topmost,_motionReduce,_motionSafe,_print,_landscape,_portrait,_dark,_light,_osDark,_osLight,_highContrast,_lessContrast,_moreContrast,_ltr,_rtl,_scrollbar,_scrollbarThumb,_scrollbarTrack,_horizontal,_vertical,_icon,_starting,_noscript,_invertedColors,_campaign26,_campaign26Bright,_campaign26Light,_campaign26Dark,_challengeAccepted,_challengeAcceptedDark,_stateOpen,_stateClosed,sm,smOnly,smDown,md,mdOnly,mdDown,lg,lgOnly,lgDown,smToMd,smToLg,mdToLg,@/sm,@/md,@/lg,base";
const conditions = new Set(conditionsStr.split(','));
const conditionRegex = /^@|&|&$/;
function isCondition(value) {
    return conditions.has(value) || conditionRegex.test(value);
}
const underscoreRegex = /^_/;
const conditionsSelectorRegex = /&|@/;
function finalizeConditions(paths) {
    return paths.map((path)=>{
        if (conditions.has(path)) {
            return path.replace(underscoreRegex, '');
        }
        if (conditionsSelectorRegex.test(path)) {
            return `[${(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["withoutSpace"])(path.trim())}]`;
        }
        return path;
    });
}
function sortConditions(paths) {
    return paths.sort((a, b)=>{
        const aa = isCondition(a);
        const bb = isCondition(b);
        if (aa && !bb) return 1;
        if (!aa && bb) return -1;
        return 0;
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "assignCss",
    ()=>assignCss,
    "css",
    ()=>css,
    "mergeCss",
    ()=>mergeCss
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$conditions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/conditions.mjs [app-client] (ecmascript)");
;
;
const utilities = "aspectRatio:asp,boxDecorationBreak:bx-db,zIndex:z,boxSizing:bx-s,objectPosition:obj-p,objectFit:obj-f,overscrollBehavior:ovs-b,overscrollBehaviorX:ovs-bx,overscrollBehaviorY:ovs-by,position:pos/1,top:top,left:left,inset:inset,insetInline:inset-x/insetX,insetBlock:inset-y/insetY,insetBlockEnd:inset-be,insetBlockStart:inset-bs,insetInlineEnd:inset-e/insetEnd/end,insetInlineStart:inset-s/insetStart/start,right:right,bottom:bottom,float:float,visibility:vis,display:d,hideFrom:hide,hideBelow:show,flexBasis:flex-b,flex:flex,flexDirection:flex-d/flexDir,flexGrow:flex-g,flexShrink:flex-sh,gridTemplateColumns:grid-tc,gridTemplateRows:grid-tr,gridColumn:grid-c,gridRow:grid-r,gridColumnStart:grid-cs,gridColumnEnd:grid-ce,gridAutoFlow:grid-af,gridAutoColumns:grid-ac,gridAutoRows:grid-ar,gap:gap,gridGap:grid-g,gridRowGap:grid-rg,gridColumnGap:grid-cg,rowGap:rg,columnGap:cg,justifyContent:jc,alignContent:ac,alignItems:ai,alignSelf:as,padding:p/1,paddingLeft:pl/1,paddingRight:pr/1,paddingTop:pt/1,paddingBottom:pb/1,paddingBlock:py/1/paddingY,paddingBlockEnd:pbe,paddingBlockStart:pbs,paddingInline:px/paddingX/1,paddingInlineEnd:pe/1/paddingEnd,paddingInlineStart:ps/1/paddingStart,marginLeft:ml/1,marginRight:mr/1,marginTop:mt/1,marginBottom:mb/1,margin:m/1,marginBlock:my/1/marginY,marginBlockEnd:mbe,marginBlockStart:mbs,marginInline:mx/1/marginX,marginInlineEnd:me/1/marginEnd,marginInlineStart:ms/1/marginStart,spaceX:sx,spaceY:sy,outlineWidth:ring-w/ringWidth,outlineColor:ring-c/ringColor,outline:ring/1,outlineOffset:ring-o/ringOffset,focusRing:focus-ring,focusVisibleRing:focus-v-ring,focusRingColor:focus-ring-c,focusRingOffset:focus-ring-o,focusRingWidth:focus-ring-w,focusRingStyle:focus-ring-s,divideX:dvd-x,divideY:dvd-y,divideColor:dvd-c,divideStyle:dvd-s,width:w/1,inlineSize:w-is,minWidth:min-w/minW,minInlineSize:min-w-is,maxWidth:max-w/maxW,maxInlineSize:max-w-is,height:h/1,blockSize:h-bs,minHeight:min-h/minH,minBlockSize:min-h-bs,maxHeight:max-h/maxH,maxBlockSize:max-b,boxSize:size,color:c,fontFamily:ff,fontSize:fs,fontSizeAdjust:fs-a,fontPalette:fp,fontKerning:fk,fontFeatureSettings:ff-s,fontWeight:fw,fontSmoothing:fsmt,fontVariant:fv,fontVariantAlternates:fv-alt,fontVariantCaps:fv-caps,fontVariationSettings:fv-s,fontVariantNumeric:fv-num,letterSpacing:ls,lineHeight:lh,textAlign:ta,textDecoration:td,textDecorationColor:td-c,textEmphasisColor:te-c,textDecorationStyle:td-s,textDecorationThickness:td-t,textUnderlineOffset:tu-o,textTransform:tt,textIndent:ti,textShadow:tsh,textShadowColor:tsh-c/textShadowColor,WebkitTextFillColor:wktf-c,textOverflow:tov,verticalAlign:va,wordBreak:wb,textWrap:tw,truncate:trunc,lineClamp:lc,listStyleType:li-t,listStylePosition:li-pos,listStyleImage:li-img,listStyle:li-s,backgroundPosition:bg-p/bgPosition,backgroundPositionX:bg-p-x/bgPositionX,backgroundPositionY:bg-p-y/bgPositionY,backgroundAttachment:bg-a/bgAttachment,backgroundClip:bg-cp/bgClip,background:bg/1,backgroundColor:bg-c/bgColor,backgroundOrigin:bg-o/bgOrigin,backgroundImage:bg-i/bgImage,backgroundRepeat:bg-r/bgRepeat,backgroundBlendMode:bg-bm/bgBlendMode,backgroundSize:bg-s/bgSize,backgroundGradient:bg-grad/bgGradient,backgroundLinear:bg-linear/bgLinear,backgroundRadial:bg-radial/bgRadial,backgroundConic:bg-conic/bgConic,textGradient:txt-grad,gradientFromPosition:grad-from-pos,gradientToPosition:grad-to-pos,gradientFrom:grad-from,gradientTo:grad-to,gradientVia:grad-via,gradientViaPosition:grad-via-pos,borderRadius:bdr/rounded,borderTopLeftRadius:bdr-tl/roundedTopLeft,borderTopRightRadius:bdr-tr/roundedTopRight,borderBottomRightRadius:bdr-br/roundedBottomRight,borderBottomLeftRadius:bdr-bl/roundedBottomLeft,borderTopRadius:bdr-t/roundedTop,borderRightRadius:bdr-r/roundedRight,borderBottomRadius:bdr-b/roundedBottom,borderLeftRadius:bdr-l/roundedLeft,borderStartStartRadius:bdr-ss/roundedStartStart,borderStartEndRadius:bdr-se/roundedStartEnd,borderStartRadius:bdr-s/roundedStart,borderEndStartRadius:bdr-es/roundedEndStart,borderEndEndRadius:bdr-ee/roundedEndEnd,borderEndRadius:bdr-e/roundedEnd,border:bd,borderWidth:bd-w,borderTopWidth:bd-t-w,borderLeftWidth:bd-l-w,borderRightWidth:bd-r-w,borderBottomWidth:bd-b-w,borderBlockStartWidth:bd-bs-w,borderBlockEndWidth:bd-be-w,borderColor:bd-c,borderInline:bd-x/borderX,borderInlineWidth:bd-x-w/borderXWidth,borderInlineColor:bd-x-c/borderXColor,borderBlock:bd-y/borderY,borderBlockWidth:bd-y-w/borderYWidth,borderBlockColor:bd-y-c/borderYColor,borderLeft:bd-l,borderLeftColor:bd-l-c,borderInlineStart:bd-s/borderStart,borderInlineStartWidth:bd-s-w/borderStartWidth,borderInlineStartColor:bd-s-c/borderStartColor,borderRight:bd-r,borderRightColor:bd-r-c,borderInlineEnd:bd-e/borderEnd,borderInlineEndWidth:bd-e-w/borderEndWidth,borderInlineEndColor:bd-e-c/borderEndColor,borderTop:bd-t,borderTopColor:bd-t-c,borderBottom:bd-b,borderBottomColor:bd-b-c,borderBlockEnd:bd-be,borderBlockEndColor:bd-be-c,borderBlockStart:bd-bs,borderBlockStartColor:bd-bs-c,opacity:op,boxShadow:bx-sh/shadow,boxShadowColor:bx-sh-c/shadowColor,mixBlendMode:mix-bm,filter:filter,brightness:brightness,contrast:contrast,grayscale:grayscale,hueRotate:hue-rotate,invert:invert,saturate:saturate,sepia:sepia,dropShadow:drop-shadow,blur:blur,backdropFilter:bkdp,backdropBlur:bkdp-blur,backdropBrightness:bkdp-brightness,backdropContrast:bkdp-contrast,backdropGrayscale:bkdp-grayscale,backdropHueRotate:bkdp-hue-rotate,backdropInvert:bkdp-invert,backdropOpacity:bkdp-opacity,backdropSaturate:bkdp-saturate,backdropSepia:bkdp-sepia,borderCollapse:bd-cl,borderSpacing:bd-sp,borderSpacingX:bd-sx,borderSpacingY:bd-sy,tableLayout:tbl,transitionTimingFunction:trs-tmf,transitionDelay:trs-dly,transitionDuration:trs-dur,transitionProperty:trs-prop,transition:trs,animation:anim,animationName:anim-n,animationTimingFunction:anim-tmf,animationDuration:anim-dur,animationDelay:anim-dly,animationPlayState:anim-ps,animationComposition:anim-comp,animationFillMode:anim-fm,animationDirection:anim-dir,animationIterationCount:anim-ic,animationRange:anim-r,animationState:anim-s,animationRangeStart:anim-rs,animationRangeEnd:anim-re,animationTimeline:anim-tl,transformOrigin:trf-o,transformBox:trf-b,transformStyle:trf-s,transform:trf,rotate:rotate,rotateX:rotate-x,rotateY:rotate-y,rotateZ:rotate-z,scale:scale,scaleX:scale-x,scaleY:scale-y,translate:translate,translateX:translate-x/x,translateY:translate-y/y,translateZ:translate-z/z,accentColor:ac-c,caretColor:ca-c,scrollBehavior:scr-bhv,scrollbar:scr-bar,scrollbarColor:scr-bar-c,scrollbarGutter:scr-bar-g,scrollbarWidth:scr-bar-w,scrollMargin:scr-m,scrollMarginLeft:scr-ml,scrollMarginRight:scr-mr,scrollMarginTop:scr-mt,scrollMarginBottom:scr-mb,scrollMarginBlock:scr-my/scrollMarginY,scrollMarginBlockEnd:scr-mbe,scrollMarginBlockStart:scr-mbt,scrollMarginInline:scr-mx/scrollMarginX,scrollMarginInlineEnd:scr-me,scrollMarginInlineStart:scr-ms,scrollPadding:scr-p,scrollPaddingBlock:scr-py/scrollPaddingY,scrollPaddingBlockStart:scr-pbs,scrollPaddingBlockEnd:scr-pbe,scrollPaddingInline:scr-px/scrollPaddingX,scrollPaddingInlineEnd:scr-pe,scrollPaddingInlineStart:scr-ps,scrollPaddingLeft:scr-pl,scrollPaddingRight:scr-pr,scrollPaddingTop:scr-pt,scrollPaddingBottom:scr-pb,scrollSnapAlign:scr-sa,scrollSnapStop:scrs-s,scrollSnapType:scrs-t,scrollSnapStrictness:scrs-strt,scrollSnapMargin:scrs-m,scrollSnapMarginTop:scrs-mt,scrollSnapMarginBottom:scrs-mb,scrollSnapMarginLeft:scrs-ml,scrollSnapMarginRight:scrs-mr,scrollSnapCoordinate:scrs-c,scrollSnapDestination:scrs-d,scrollSnapPointsX:scrs-px,scrollSnapPointsY:scrs-py,scrollSnapTypeX:scrs-tx,scrollSnapTypeY:scrs-ty,scrollTimeline:scrtl,scrollTimelineAxis:scrtl-a,scrollTimelineName:scrtl-n,touchAction:tch-a,userSelect:us,overflow:ov,overflowWrap:ov-wrap,overflowX:ov-x,overflowY:ov-y,overflowAnchor:ov-a,overflowBlock:ov-b,overflowInline:ov-i,overflowClipBox:ovcp-bx,overflowClipMargin:ovcp-m,overscrollBehaviorBlock:ovs-bb,overscrollBehaviorInline:ovs-bi,fill:fill,stroke:stk,strokeWidth:stk-w,strokeDasharray:stk-dsh,strokeDashoffset:stk-do,strokeLinecap:stk-lc,strokeLinejoin:stk-lj,strokeMiterlimit:stk-ml,strokeOpacity:stk-op,srOnly:sr,debug:debug,appearance:ap,backfaceVisibility:bfv,clipPath:cp-path,hyphens:hy,mask:msk,maskImage:msk-i,maskSize:msk-s,textSizeAdjust:txt-adj,container:cq,containerName:cq-n,containerType:cq-t,cursor:cursor,textStyle:textStyle";
const classNameByProp = new Map();
const shorthands = new Map();
utilities.split(',').forEach((utility)=>{
    const [prop, meta] = utility.split(':');
    const [className, ...shorthandList] = meta.split('/');
    classNameByProp.set(prop, className);
    if (shorthandList.length) {
        shorthandList.forEach((shorthand)=>{
            shorthands.set(shorthand === '1' ? className : shorthand, prop);
        });
    }
});
const resolveShorthand = (prop)=>shorthands.get(prop) || prop;
const context = {
    conditions: {
        shift: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$conditions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortConditions"],
        finalize: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$conditions$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeConditions"],
        breakpoints: {
            keys: [
                "base",
                "sm",
                "md",
                "lg"
            ]
        }
    },
    utility: {
        prefix: "r",
        transform: (prop, value)=>{
            const key = resolveShorthand(prop);
            const propKey = classNameByProp.get(key) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hypenateProperty"])(key);
            return {
                className: `${propKey}_${(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["withoutSpace"])(value)}`
            };
        },
        hasShorthand: true,
        toHash: (path, hashFn)=>hashFn(path.join(":")),
        resolveShorthand: resolveShorthand
    }
};
const cssFn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createCss"])(context);
const css = (...styles)=>cssFn(mergeCss(...styles));
css.raw = (...styles)=>mergeCss(...styles);
const { mergeCss, assignCss } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMergeCss"])(context);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/css/cx.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cx",
    ()=>cx
]);
function cx() {
    let str = '', i = 0, arg;
    for(; i < arguments.length;){
        if ((arg = arguments[i++]) && typeof arg === 'string') {
            str && (str += ' ');
            str += arg;
        }
    }
    return str;
}
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/css/cva.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "assertCompoundVariant",
    ()=>assertCompoundVariant,
    "cva",
    ()=>cva,
    "getCompoundVariantCss",
    ()=>getCompoundVariantCss
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const defaults = (conf)=>({
        base: {},
        variants: {},
        defaultVariants: {},
        compoundVariants: [],
        ...conf
    });
function cva(config) {
    const { base, variants, defaultVariants, compoundVariants } = defaults(config);
    const getVariantProps = (variants)=>({
            ...defaultVariants,
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(variants)
        });
    function resolve(props = {}) {
        const computedVariants = getVariantProps(props);
        let variantCss = {
            ...base
        };
        for (const [key, value] of Object.entries(computedVariants)){
            if (variants[key]?.[value]) {
                variantCss = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeCss"])(variantCss, variants[key][value]);
            }
        }
        const compoundVariantCss = getCompoundVariantCss(compoundVariants, computedVariants);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeCss"])(variantCss, compoundVariantCss);
    }
    function merge(__cva) {
        const override = defaults(__cva.config);
        const variantKeys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uniq"])(__cva.variantKeys, Object.keys(variants));
        return cva({
            base: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeCss"])(base, override.base),
            variants: Object.fromEntries(variantKeys.map((key)=>[
                    key,
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeCss"])(variants[key], override.variants[key])
                ])),
            defaultVariants: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])(defaultVariants, override.defaultVariants),
            compoundVariants: [
                ...compoundVariants,
                ...override.compoundVariants
            ]
        });
    }
    function cvaFn(props) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(resolve(props));
    }
    const variantKeys = Object.keys(variants);
    function splitVariantProps(props) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["splitProps"])(props, variantKeys);
    }
    const variantMap = Object.fromEntries(Object.entries(variants).map(([key, value])=>[
            key,
            Object.keys(value)
        ]));
    return Object.assign((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(cvaFn), {
        __cva__: true,
        variantMap,
        variantKeys,
        raw: resolve,
        config,
        merge,
        splitVariantProps,
        getVariantProps
    });
}
function getCompoundVariantCss(compoundVariants, variantMap) {
    let result = {};
    compoundVariants.forEach((compoundVariant)=>{
        const isMatching = Object.entries(compoundVariant).every(([key, value])=>{
            if (key === 'css') return true;
            const values = Array.isArray(value) ? value : [
                value
            ];
            return values.some((value)=>variantMap[key] === value);
        });
        if (isMatching) {
            result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeCss"])(result, compoundVariant.css);
        }
    });
    return result;
}
function assertCompoundVariant(name, compoundVariants, variants, prop) {
    if (compoundVariants.length > 0 && typeof variants?.[prop] === 'object') {
        throw new Error(`[recipe:${name}:${prop}] Conditions are not supported when using compound variants.`);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/css/sva.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sva",
    ()=>sva
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cva$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/cva.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/cx.mjs [app-client] (ecmascript)");
;
;
;
function sva(config) {
    const slots = Object.entries((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSlotRecipes"])(config)).map(([slot, slotCva])=>[
            slot,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cva$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])(slotCva)
        ]);
    const defaultVariants = config.defaultVariants ?? {};
    const classNameMap = slots.reduce((acc, [slot, cvaFn])=>{
        if (config.className) acc[slot] = cvaFn.config.className;
        return acc;
    }, {});
    function svaFn(props) {
        const result = slots.map(([slot, cvaFn])=>[
                slot,
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cx"])(cvaFn(props), classNameMap[slot])
            ]);
        return Object.fromEntries(result);
    }
    function raw(props) {
        const result = slots.map(([slot, cvaFn])=>[
                slot,
                cvaFn.raw(props)
            ]);
        return Object.fromEntries(result);
    }
    const variants = config.variants ?? {};
    const variantKeys = Object.keys(variants);
    function splitVariantProps(props) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["splitProps"])(props, variantKeys);
    }
    const getVariantProps = (variants)=>({
            ...defaultVariants,
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compact"])(variants)
        });
    const variantMap = Object.fromEntries(Object.entries(variants).map(([key, value])=>[
            key,
            Object.keys(value)
        ]));
    return Object.assign((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(svaFn), {
        __cva__: false,
        raw,
        config,
        variantMap,
        variantKeys,
        classNameMap,
        splitVariantProps,
        getVariantProps
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/cx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cva$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/cva.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$sva$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/sva.mjs [app-client] (ecmascript)");
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/container.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ContainerNarrow",
    ()=>ContainerNarrow,
    "default",
    ()=>Container
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/cx.mjs [app-client] (ecmascript)");
;
;
function Container({ children, className }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$cx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cx"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            mx: 'auto',
            px: '4',
            maxWidth: 'maxContentWidth',
            width: 'full'
        }), className),
        children: children
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/components/container.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
_c = Container;
function ContainerNarrow({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            mx: 'auto',
            px: '4',
            maxWidth: 'narrow',
            width: 'full'
        }),
        children: children
    }, void 0, false, {
        fileName: "[project]/apps/www/src/app/components/container.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
_c1 = ContainerNarrow;
var _c, _c1;
__turbopack_context__.k.register(_c, "Container");
__turbopack_context__.k.register(_c1, "ContainerNarrow");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/box.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "box",
    ()=>box,
    "getBoxStyle",
    ()=>getBoxStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const boxConfig = {
    transform (props) {
        return props;
    }
};
const getBoxStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(boxConfig, styles);
    return boxConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const box = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getBoxStyle(styles));
box.raw = getBoxStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/flex.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "flex",
    ()=>flex,
    "getFlexStyle",
    ()=>getFlexStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const flexConfig = {
    transform (props) {
        const { direction, align, justify, wrap: wrap2, basis, grow, shrink, ...rest } = props;
        return {
            display: "flex",
            flexDirection: direction,
            alignItems: align,
            justifyContent: justify,
            flexWrap: wrap2,
            flexBasis: basis,
            flexGrow: grow,
            flexShrink: shrink,
            ...rest
        };
    }
};
const getFlexStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(flexConfig, styles);
    return flexConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const flex = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getFlexStyle(styles));
flex.raw = getFlexStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/stack.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getStackStyle",
    ()=>getStackStyle,
    "stack",
    ()=>stack
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const stackConfig = {
    transform (props) {
        const { align, justify, direction, gap, ...rest } = props;
        return {
            display: "flex",
            flexDirection: direction,
            alignItems: align,
            justifyContent: justify,
            gap,
            ...rest
        };
    },
    defaultValues: {
        direction: 'column',
        gap: '8px'
    }
};
const getStackStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(stackConfig, styles);
    return stackConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const stack = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getStackStyle(styles));
stack.raw = getStackStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/vstack.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getVstackStyle",
    ()=>getVstackStyle,
    "vstack",
    ()=>vstack
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const vstackConfig = {
    transform (props) {
        const { justify, gap, ...rest } = props;
        return {
            display: "flex",
            alignItems: "center",
            justifyContent: justify,
            gap,
            flexDirection: "column",
            ...rest
        };
    },
    defaultValues: {
        gap: '8px'
    }
};
const getVstackStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(vstackConfig, styles);
    return vstackConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const vstack = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getVstackStyle(styles));
vstack.raw = getVstackStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/hstack.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getHstackStyle",
    ()=>getHstackStyle,
    "hstack",
    ()=>hstack
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const hstackConfig = {
    transform (props) {
        const { justify, gap, ...rest } = props;
        return {
            display: "flex",
            alignItems: "center",
            justifyContent: justify,
            gap,
            flexDirection: "row",
            ...rest
        };
    },
    defaultValues: {
        gap: '8px'
    }
};
const getHstackStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(hstackConfig, styles);
    return hstackConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const hstack = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getHstackStyle(styles));
hstack.raw = getHstackStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/spacer.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSpacerStyle",
    ()=>getSpacerStyle,
    "spacer",
    ()=>spacer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const spacerConfig = {
    transform (props, { map, isCssUnit, isCssVar }) {
        const { size, ...rest } = props;
        return {
            alignSelf: "stretch",
            justifySelf: "stretch",
            flex: map(size, (v)=>{
                if (v == null) return "1";
                const val = isCssUnit(v) || isCssVar(v) ? v : `token(spacing.${v}, ${v})`;
                return `0 0 ${val}`;
            }),
            ...rest
        };
    }
};
const getSpacerStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(spacerConfig, styles);
    return spacerConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const spacer = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getSpacerStyle(styles));
spacer.raw = getSpacerStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/square.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSquareStyle",
    ()=>getSquareStyle,
    "square",
    ()=>square
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const squareConfig = {
    transform (props) {
        const { size, ...rest } = props;
        return {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flex: "0 0 auto",
            width: size,
            height: size,
            ...rest
        };
    }
};
const getSquareStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(squareConfig, styles);
    return squareConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const square = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getSquareStyle(styles));
square.raw = getSquareStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/circle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "circle",
    ()=>circle,
    "getCircleStyle",
    ()=>getCircleStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const circleConfig = {
    transform (props) {
        const { size, ...rest } = props;
        return {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flex: "0 0 auto",
            width: size,
            height: size,
            borderRadius: "9999px",
            ...rest
        };
    }
};
const getCircleStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(circleConfig, styles);
    return circleConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const circle = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getCircleStyle(styles));
circle.raw = getCircleStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/center.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "center",
    ()=>center,
    "getCenterStyle",
    ()=>getCenterStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const centerConfig = {
    transform (props) {
        const { inline, ...rest } = props;
        return {
            display: inline ? "inline-flex" : "flex",
            alignItems: "center",
            justifyContent: "center",
            ...rest
        };
    }
};
const getCenterStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(centerConfig, styles);
    return centerConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const center = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getCenterStyle(styles));
center.raw = getCenterStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/link-overlay.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getLinkOverlayStyle",
    ()=>getLinkOverlayStyle,
    "linkOverlay",
    ()=>linkOverlay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const linkOverlayConfig = {
    transform (props) {
        return {
            _before: {
                content: '""',
                position: "absolute",
                inset: "0",
                zIndex: "0",
                ...props["_before"]
            },
            ...props
        };
    }
};
const getLinkOverlayStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(linkOverlayConfig, styles);
    return linkOverlayConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const linkOverlay = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getLinkOverlayStyle(styles));
linkOverlay.raw = getLinkOverlayStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/aspect-ratio.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "aspectRatio",
    ()=>aspectRatio,
    "getAspectRatioStyle",
    ()=>getAspectRatioStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const aspectRatioConfig = {
    transform (props, { map }) {
        const { ratio = 4 / 3, ...rest } = props;
        return {
            position: "relative",
            _before: {
                content: `""`,
                display: "block",
                height: "0",
                paddingBottom: map(ratio, (r)=>`${1 / r * 100}%`)
            },
            "&>*": {
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                overflow: "hidden",
                position: "absolute",
                inset: "0",
                width: "100%",
                height: "100%"
            },
            "&>img, &>video": {
                objectFit: "cover"
            },
            ...rest
        };
    }
};
const getAspectRatioStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(aspectRatioConfig, styles);
    return aspectRatioConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const aspectRatio = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getAspectRatioStyle(styles));
aspectRatio.raw = getAspectRatioStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/grid.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getGridStyle",
    ()=>getGridStyle,
    "grid",
    ()=>grid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const gridConfig = {
    transform (props, { map, isCssUnit }) {
        const { columnGap, rowGap, gap, columns, minChildWidth, ...rest } = props;
        const getValue = (v)=>isCssUnit(v) ? v : `token(sizes.${v}, ${v})`;
        return {
            display: "grid",
            gridTemplateColumns: columns != null ? map(columns, (v)=>`repeat(${v}, minmax(0, 1fr))`) : minChildWidth != null ? map(minChildWidth, (v)=>`repeat(auto-fit, minmax(${getValue(v)}, 1fr))`) : void 0,
            gap,
            columnGap,
            rowGap,
            ...rest
        };
    },
    defaultValues (props) {
        return {
            gap: props.columnGap || props.rowGap ? void 0 : "8px"
        };
    }
};
const getGridStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(gridConfig, styles);
    return gridConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const grid = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getGridStyle(styles));
grid.raw = getGridStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/grid-item.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getGridItemStyle",
    ()=>getGridItemStyle,
    "gridItem",
    ()=>gridItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const gridItemConfig = {
    transform (props, { map }) {
        const { colSpan, rowSpan, colStart, rowStart, colEnd, rowEnd, ...rest } = props;
        const spanFn = (v)=>v === "auto" ? v : `span ${v}`;
        return {
            gridColumn: colSpan != null ? map(colSpan, spanFn) : void 0,
            gridRow: rowSpan != null ? map(rowSpan, spanFn) : void 0,
            gridColumnStart: colStart,
            gridColumnEnd: colEnd,
            gridRowStart: rowStart,
            gridRowEnd: rowEnd,
            ...rest
        };
    }
};
const getGridItemStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(gridItemConfig, styles);
    return gridItemConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const gridItem = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getGridItemStyle(styles));
gridItem.raw = getGridItemStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/wrap.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getWrapStyle",
    ()=>getWrapStyle,
    "wrap",
    ()=>wrap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const wrapConfig = {
    transform (props) {
        const { columnGap, rowGap, gap = columnGap || rowGap ? void 0 : "8px", align, justify, ...rest } = props;
        return {
            display: "flex",
            flexWrap: "wrap",
            alignItems: align,
            justifyContent: justify,
            gap,
            columnGap,
            rowGap,
            ...rest
        };
    }
};
const getWrapStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(wrapConfig, styles);
    return wrapConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const wrap = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getWrapStyle(styles));
wrap.raw = getWrapStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/container.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "container",
    ()=>container,
    "getContainerStyle",
    ()=>getContainerStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const containerConfig = {
    transform (props) {
        return {
            position: "relative",
            maxWidth: "8xl",
            mx: "auto",
            px: {
                base: "4",
                md: "6",
                lg: "8"
            },
            ...props
        };
    }
};
const getContainerStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(containerConfig, styles);
    return containerConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const container = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getContainerStyle(styles));
container.raw = getContainerStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/divider.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "divider",
    ()=>divider,
    "getDividerStyle",
    ()=>getDividerStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const dividerConfig = {
    transform (props, { map }) {
        const { orientation, thickness, color, ...rest } = props;
        return {
            "--thickness": thickness,
            width: map(orientation, (v)=>v === "vertical" ? void 0 : "100%"),
            height: map(orientation, (v)=>v === "horizontal" ? void 0 : "100%"),
            borderBlockEndWidth: map(orientation, (v)=>v === "horizontal" ? "var(--thickness)" : void 0),
            borderInlineEndWidth: map(orientation, (v)=>v === "vertical" ? "var(--thickness)" : void 0),
            borderColor: color,
            ...rest
        };
    },
    defaultValues: {
        orientation: 'horizontal',
        thickness: '1px'
    }
};
const getDividerStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(dividerConfig, styles);
    return dividerConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const divider = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getDividerStyle(styles));
divider.raw = getDividerStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/float.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "float",
    ()=>float,
    "getFloatStyle",
    ()=>getFloatStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const floatConfig = {
    transform (props, { map }) {
        const { offset, offsetX, offsetY, placement, ...rest } = props;
        return {
            display: "inline-flex",
            justifyContent: "center",
            alignItems: "center",
            position: "absolute",
            insetBlockStart: map(placement, (v)=>{
                const [side] = v.split("-");
                const map2 = {
                    top: offsetY,
                    middle: "50%",
                    bottom: "auto"
                };
                return map2[side];
            }),
            insetBlockEnd: map(placement, (v)=>{
                const [side] = v.split("-");
                const map2 = {
                    top: "auto",
                    middle: "50%",
                    bottom: offsetY
                };
                return map2[side];
            }),
            insetInlineStart: map(placement, (v)=>{
                const [, align] = v.split("-");
                const map2 = {
                    start: offsetX,
                    center: "50%",
                    end: "auto"
                };
                return map2[align];
            }),
            insetInlineEnd: map(placement, (v)=>{
                const [, align] = v.split("-");
                const map2 = {
                    start: "auto",
                    center: "50%",
                    end: offsetX
                };
                return map2[align];
            }),
            translate: map(placement, (v)=>{
                const [side, align] = v.split("-");
                const mapX = {
                    start: "-50%",
                    center: "-50%",
                    end: "50%"
                };
                const mapY = {
                    top: "-50%",
                    middle: "-50%",
                    bottom: "50%"
                };
                return `${mapX[align]} ${mapY[side]}`;
            }),
            ...rest
        };
    },
    defaultValues (props) {
        const offset = props.offset || "0";
        return {
            offset,
            offsetX: offset,
            offsetY: offset,
            placement: "top-end"
        };
    }
};
const getFloatStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(floatConfig, styles);
    return floatConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const float = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getFloatStyle(styles));
float.raw = getFloatStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/bleed.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bleed",
    ()=>bleed,
    "getBleedStyle",
    ()=>getBleedStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const bleedConfig = {
    transform (props, { map, isCssUnit, isCssVar }) {
        const { inline, block, ...rest } = props;
        const valueFn = (v)=>isCssUnit(v) || isCssVar(v) ? v : `token(spacing.${v}, ${v})`;
        return {
            "--bleed-x": map(inline, valueFn),
            "--bleed-y": map(block, valueFn),
            marginInline: "calc(var(--bleed-x, 0) * -1)",
            marginBlock: "calc(var(--bleed-y, 0) * -1)",
            ...rest
        };
    },
    defaultValues: {
        inline: '0',
        block: '0'
    }
};
const getBleedStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(bleedConfig, styles);
    return bleedConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const bleed = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getBleedStyle(styles));
bleed.raw = getBleedStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/visually-hidden.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getVisuallyHiddenStyle",
    ()=>getVisuallyHiddenStyle,
    "visuallyHidden",
    ()=>visuallyHidden
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const visuallyHiddenConfig = {
    transform (props) {
        return {
            srOnly: true,
            ...props
        };
    }
};
const getVisuallyHiddenStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(visuallyHiddenConfig, styles);
    return visuallyHiddenConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const visuallyHidden = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getVisuallyHiddenStyle(styles));
visuallyHidden.raw = getVisuallyHiddenStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/cq.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cq",
    ()=>cq,
    "getCqStyle",
    ()=>getCqStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/helpers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
;
;
const cqConfig = {
    transform (props) {
        const { name, type, ...rest } = props;
        return {
            containerType: type,
            containerName: name,
            ...rest
        };
    },
    defaultValues: {
        type: 'inline-size'
    }
};
const getCqStyle = (styles = {})=>{
    const _styles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPatternStyles"])(cqConfig, styles);
    return cqConfig.transform(_styles, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$helpers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["patternFns"]);
};
const cq = (styles)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(getCqStyle(styles));
cq.raw = getCqStyle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/theme/__generated__/patterns/index.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$box$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/box.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$flex$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/flex.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$stack$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/stack.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$vstack$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/vstack.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$hstack$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/hstack.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$spacer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/spacer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$square$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/square.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$circle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/circle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$center$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/center.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$link$2d$overlay$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/link-overlay.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$aspect$2d$ratio$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/aspect-ratio.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$grid$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/grid.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$grid$2d$item$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/grid-item.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$wrap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/wrap.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$container$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/container.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$divider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/divider.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$float$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/float.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$bleed$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/bleed.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$visually$2d$hidden$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/visually-hidden.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$cq$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/cq.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/components/layout/error-page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ErrorPage",
    ()=>ErrorPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$logo$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/logo.json.[json].cjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$stack$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/patterns/stack.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
;
;
;
;
;
function ErrorPage({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            minHeight: '100dvh',
            display: 'flex',
            flexDirection: 'column'
        }),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                    p: '4'
                }),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: "/",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                        viewBox: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$logo$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].LOGO_VIEWBOX,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                            fill: 'text',
                            height: 'header.logoHeight'
                        }),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                            d: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$logo$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].LOGO_PATH
                        }, void 0, false, {
                            fileName: "[project]/apps/www/src/app/components/layout/error-page.tsx",
                            lineNumber: 35,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/components/layout/error-page.tsx",
                        lineNumber: 28,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/components/layout/error-page.tsx",
                    lineNumber: 27,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/layout/error-page.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    flexGrow: 1,
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    p: '4',
                    fontSize: 'l'
                }),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$patterns$2f$stack$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stack"])({
                            gap: '4',
                            textAlign: 'center'
                        }),
                        children: children
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/components/layout/error-page.tsx",
                        lineNumber: 51,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/apps/www/src/app/components/layout/error-page.tsx",
                    lineNumber: 50,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/components/layout/error-page.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/components/layout/error-page.tsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}
_c = ErrorPage;
var _c;
__turbopack_context__.k.register(_c, "ErrorPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/www/src/app/error.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Error
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$layout$2f$error$2d$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/app/components/layout/error-page.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/theme/__generated__/css/css.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$core$2f$build$2f$esm$2f$exports$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sentry/core/build/esm/exports.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/www/src/lib/constants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client'; // Error components must be Client Components
;
;
;
;
;
;
const linkClass = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
    color: 'primary',
    textDecoration: 'none',
    _hover: {
        textDecoration: 'underline'
    }
});
function Error({ error, reset }) {
    _s();
    const [errorId, setErrorId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Error.useEffect": ()=>{
            // Log the error to an error reporting service
            const eventId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$core$2f$build$2f$esm$2f$exports$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureException"](error, {
                tags: {
                    origin: 'ErrorBoundary',
                    routing: 'app-dir'
                }
            });
            setErrorId(eventId);
        }
    }["Error.useEffect"], [
        error,
        setErrorId
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$app$2f$components$2f$layout$2f$error$2d$page$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorPage"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    textStyle: 'h1Sans'
                }),
                children: "Es ist ein Fehler aufgetreten"
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/error.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: [
                    "Sollte dieser Fehler zum wiederholten Male aufgetreten sein, wenden Sie sich bitte an",
                    ' ',
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        className: linkClass,
                        href: [
                            'mailto:kontakt@republik.ch',
                            '?subject=Fehlermeldung%20auf%20' + __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PUBLIC_BASE_URL"] + window.location.pathname,
                            '&body=' + encodeURIComponent([
                                'Hallo Republik-Team, ich bin auf folgenden Fehler in der Webseite gestossen:',
                                errorId ? `Fehler ID: ${errorId}` : null,
                                `URL: ${__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$www$2f$src$2f$lib$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PUBLIC_BASE_URL"]}${window.location.pathname}`,
                                error.stack
                            ].filter(Boolean).join('\n\n'))
                        ].join(''),
                        children: "kontakt@republik.ch"
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/error.tsx",
                        lineNumber: 51,
                        columnNumber: 9
                    }, this),
                    "."
                ]
            }, void 0, true, {
                fileName: "[project]/apps/www/src/app/error.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    gap: '2',
                    md: {
                        flexDirection: 'row'
                    }
                }),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                            px: '5',
                            py: '3',
                            backgroundColor: 'primary',
                            color: 'white',
                            _hover: {
                                backgroundColor: 'primaryHover'
                            }
                        }),
                        onClick: ()=>reset(),
                        children: "Seite neu laden"
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/error.tsx",
                        lineNumber: 88,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "oder"
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/error.tsx",
                        lineNumber: 102,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        className: linkClass,
                        children: "zum Magazin"
                    }, void 0, false, {
                        fileName: "[project]/apps/www/src/app/error.tsx",
                        lineNumber: 103,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/www/src/app/error.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: errorId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$theme$2f$_$5f$generated_$5f2f$css$2f$css$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                        color: 'textSoft',
                        fontSize: 's',
                        textAlign: 'center',
                        pb: '4'
                    }),
                    children: [
                        "Fehler: ",
                        errorId
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/www/src/app/error.tsx",
                    lineNumber: 109,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/www/src/app/error.tsx",
                lineNumber: 107,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/www/src/app/error.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
_s(Error, "i+Nxsr8foc4NQprAgrhatVJydoQ=");
_c = Error;
var _c;
__turbopack_context__.k.register(_c, "Error");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/next/dist/client/use-merged-ref.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "useMergedRef", {
    enumerable: true,
    get: function() {
        return useMergedRef;
    }
});
const _react = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
function useMergedRef(refA, refB) {
    const cleanupA = (0, _react.useRef)(null);
    const cleanupB = (0, _react.useRef)(null);
    // NOTE: In theory, we could skip the wrapping if only one of the refs is non-null.
    // (this happens often if the user doesn't pass a ref to Link/Form/Image)
    // But this can cause us to leak a cleanup-ref into user code (previously via `<Link legacyBehavior>`),
    // and the user might pass that ref into ref-merging library that doesn't support cleanup refs
    // (because it hasn't been updated for React 19)
    // which can then cause things to blow up, because a cleanup-returning ref gets called with `null`.
    // So in practice, it's safer to be defensive and always wrap the ref, even on React 19.
    return (0, _react.useCallback)((current)=>{
        if (current === null) {
            const cleanupFnA = cleanupA.current;
            if (cleanupFnA) {
                cleanupA.current = null;
                cleanupFnA();
            }
            const cleanupFnB = cleanupB.current;
            if (cleanupFnB) {
                cleanupB.current = null;
                cleanupFnB();
            }
        } else {
            if (refA) {
                cleanupA.current = applyRef(refA, current);
            }
            if (refB) {
                cleanupB.current = applyRef(refB, current);
            }
        }
    }, [
        refA,
        refB
    ]);
}
function applyRef(refA, current) {
    if (typeof refA === 'function') {
        const cleanup = refA(current);
        if (typeof cleanup === 'function') {
            return cleanup;
        } else {
            return ()=>refA(null);
        }
    } else {
        refA.current = current;
        return ()=>{
            refA.current = null;
        };
    }
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
"[project]/node_modules/next/dist/shared/lib/utils/error-once.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "errorOnce", {
    enumerable: true,
    get: function() {
        return errorOnce;
    }
});
let errorOnce = (_)=>{};
if ("TURBOPACK compile-time truthy", 1) {
    const errors = new Set();
    errorOnce = (msg)=>{
        if (!errors.has(msg)) {
            console.error(msg);
        }
        errors.add(msg);
    };
}
}),
"[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use client';
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    default: null,
    useLinkStatus: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    /**
 * A React component that extends the HTML `<a>` element to provide
 * [prefetching](https://nextjs.org/docs/app/building-your-application/routing/linking-and-navigating#2-prefetching)
 * and client-side navigation. This is the primary way to navigate between routes in Next.js.
 *
 * @remarks
 * - Prefetching is only enabled in production.
 *
 * @see https://nextjs.org/docs/app/api-reference/components/link
 */ default: function() {
        return LinkComponent;
    },
    useLinkStatus: function() {
        return useLinkStatus;
    }
});
const _interop_require_wildcard = __turbopack_context__.r("[project]/node_modules/next/node_modules/@swc/helpers/cjs/_interop_require_wildcard.cjs [app-client] (ecmascript)");
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_wildcard._(__turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _formaturl = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/router/utils/format-url.js [app-client] (ecmascript)");
const _approutercontextsharedruntime = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/app-router-context.shared-runtime.js [app-client] (ecmascript)");
const _usemergedref = __turbopack_context__.r("[project]/node_modules/next/dist/client/use-merged-ref.js [app-client] (ecmascript)");
const _utils = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/utils.js [app-client] (ecmascript)");
const _addbasepath = __turbopack_context__.r("[project]/node_modules/next/dist/client/add-base-path.js [app-client] (ecmascript)");
const _warnonce = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/utils/warn-once.js [app-client] (ecmascript)");
const _routerreducertypes = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/router-reducer/router-reducer-types.js [app-client] (ecmascript)");
const _links = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/links.js [app-client] (ecmascript)");
const _islocalurl = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/router/utils/is-local-url.js [app-client] (ecmascript)");
const _types = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/segment-cache/types.js [app-client] (ecmascript)");
const _erroronce = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/utils/error-once.js [app-client] (ecmascript)");
function isModifiedEvent(event) {
    const eventTarget = event.currentTarget;
    const target = eventTarget.getAttribute('target');
    return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || // triggers resource download
    event.nativeEvent && event.nativeEvent.which === 2;
}
function linkClicked(e, href, linkInstanceRef, replace, scroll, onNavigate, transitionTypes) {
    if (typeof window !== 'undefined') {
        const { nodeName } = e.currentTarget;
        // anchors inside an svg have a lowercase nodeName
        const isAnchorNodeName = nodeName.toUpperCase() === 'A';
        if (isAnchorNodeName && isModifiedEvent(e) || e.currentTarget.hasAttribute('download')) {
            // ignore click for browser’s default behavior
            return;
        }
        if (!(0, _islocalurl.isLocalURL)(href)) {
            if (replace) {
                // browser default behavior does not replace the history state
                // so we need to do it manually
                e.preventDefault();
                location.replace(href);
            }
            // ignore click for browser’s default behavior
            return;
        }
        e.preventDefault();
        if (onNavigate) {
            let isDefaultPrevented = false;
            onNavigate({
                preventDefault: ()=>{
                    isDefaultPrevented = true;
                }
            });
            if (isDefaultPrevented) {
                return;
            }
        }
        const { dispatchNavigateAction } = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/app-router-instance.js [app-client] (ecmascript)");
        _react.default.startTransition(()=>{
            dispatchNavigateAction(href, replace ? 'replace' : 'push', scroll === false ? _routerreducertypes.ScrollBehavior.NoScroll : _routerreducertypes.ScrollBehavior.Default, linkInstanceRef.current, transitionTypes);
        });
    }
}
function formatStringOrUrl(urlObjOrString) {
    if (typeof urlObjOrString === 'string') {
        return urlObjOrString;
    }
    return (0, _formaturl.formatUrl)(urlObjOrString);
}
function LinkComponent(props) {
    const [linkStatus, setOptimisticLinkStatus] = (0, _react.useOptimistic)(_links.IDLE_LINK_STATUS);
    let children;
    const linkInstanceRef = (0, _react.useRef)(null);
    const { href: hrefProp, as: asProp, children: childrenProp, prefetch: prefetchProp = null, passHref, replace, shallow, scroll, onClick, onMouseEnter: onMouseEnterProp, onTouchStart: onTouchStartProp, legacyBehavior = false, onNavigate, transitionTypes, ref: forwardedRef, unstable_dynamicOnHover, ...restProps } = props;
    children = childrenProp;
    if (legacyBehavior && (typeof children === 'string' || typeof children === 'number')) {
        children = /*#__PURE__*/ (0, _jsxruntime.jsx)("a", {
            children: children
        });
    }
    const router = _react.default.useContext(_approutercontextsharedruntime.AppRouterContext);
    const prefetchEnabled = prefetchProp !== false;
    const fetchStrategy = prefetchProp !== false ? getFetchStrategyFromPrefetchProp(prefetchProp) : _types.FetchStrategy.PPR;
    if ("TURBOPACK compile-time truthy", 1) {
        function createPropError(args) {
            return Object.defineProperty(new Error(`Failed prop type: The prop \`${args.key}\` expects a ${args.expected} in \`<Link>\`, but got \`${args.actual}\` instead.` + (typeof window !== 'undefined' ? "\nOpen your browser's console to view the Component stack trace." : '')), "__NEXT_ERROR_CODE", {
                value: "E319",
                enumerable: false,
                configurable: true
            });
        }
        // TypeScript trick for type-guarding:
        const requiredPropsGuard = {
            href: true
        };
        const requiredProps = Object.keys(requiredPropsGuard);
        requiredProps.forEach((key)=>{
            if (key === 'href') {
                if (props[key] == null || typeof props[key] !== 'string' && typeof props[key] !== 'object') {
                    throw createPropError({
                        key,
                        expected: '`string` or `object`',
                        actual: props[key] === null ? 'null' : typeof props[key]
                    });
                }
            } else {
                // TypeScript trick for type-guarding:
                const _ = key;
            }
        });
        // TypeScript trick for type-guarding:
        const optionalPropsGuard = {
            as: true,
            replace: true,
            scroll: true,
            shallow: true,
            passHref: true,
            prefetch: true,
            unstable_dynamicOnHover: true,
            onClick: true,
            onMouseEnter: true,
            onTouchStart: true,
            legacyBehavior: true,
            onNavigate: true,
            transitionTypes: true
        };
        const optionalProps = Object.keys(optionalPropsGuard);
        optionalProps.forEach((key)=>{
            const valType = typeof props[key];
            if (key === 'as') {
                if (props[key] && valType !== 'string' && valType !== 'object') {
                    throw createPropError({
                        key,
                        expected: '`string` or `object`',
                        actual: valType
                    });
                }
            } else if (key === 'onClick' || key === 'onMouseEnter' || key === 'onTouchStart' || key === 'onNavigate') {
                if (props[key] && valType !== 'function') {
                    throw createPropError({
                        key,
                        expected: '`function`',
                        actual: valType
                    });
                }
            } else if (key === 'replace' || key === 'scroll' || key === 'shallow' || key === 'passHref' || key === 'legacyBehavior' || key === 'unstable_dynamicOnHover') {
                if (props[key] != null && valType !== 'boolean') {
                    throw createPropError({
                        key,
                        expected: '`boolean`',
                        actual: valType
                    });
                }
            } else if (key === 'prefetch') {
                if (props[key] != null && valType !== 'boolean' && props[key] !== 'auto') {
                    throw createPropError({
                        key,
                        expected: '`boolean | "auto"`',
                        actual: valType
                    });
                }
            } else if (key === 'transitionTypes') {
                if (props[key] != null && !Array.isArray(props[key])) {
                    throw createPropError({
                        key,
                        expected: '`string[]`',
                        actual: valType
                    });
                }
            } else {
                // TypeScript trick for type-guarding:
                const _ = key;
            }
        });
    }
    const resolvedHref = asProp || hrefProp;
    const formattedHref = formatStringOrUrl(resolvedHref);
    if ("TURBOPACK compile-time truthy", 1) {
        if (props.locale) {
            (0, _warnonce.warnOnce)('The `locale` prop is not supported in `next/link` while using the `app` router. Read more about app router internalization: https://nextjs.org/docs/app/building-your-application/routing/internationalization');
        }
        if (!asProp) {
            let href;
            if (typeof resolvedHref === 'string') {
                href = resolvedHref;
            } else if (typeof resolvedHref === 'object' && typeof resolvedHref.pathname === 'string') {
                href = resolvedHref.pathname;
            }
            if (href) {
                const hasDynamicSegment = href.split('/').some((segment)=>segment.startsWith('[') && segment.endsWith(']'));
                if (hasDynamicSegment) {
                    throw Object.defineProperty(new Error(`Dynamic href \`${href}\` found in <Link> while using the \`/app\` router, this is not supported. Read more: https://nextjs.org/docs/messages/app-dir-dynamic-href`), "__NEXT_ERROR_CODE", {
                        value: "E267",
                        enumerable: false,
                        configurable: true
                    });
                }
            }
        }
    }
    // This will return the first child, if multiple are provided it will throw an error
    let child;
    if (legacyBehavior) {
        if (children?.$$typeof === Symbol.for('react.lazy')) {
            throw Object.defineProperty(new Error(`\`<Link legacyBehavior>\` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's \`<a>\` tag.`), "__NEXT_ERROR_CODE", {
                value: "E863",
                enumerable: false,
                configurable: true
            });
        }
        if ("TURBOPACK compile-time truthy", 1) {
            if (onClick) {
                console.warn(`"onClick" was passed to <Link> with \`href\` of \`${formattedHref}\` but "legacyBehavior" was set. The legacy behavior requires onClick be set on the child of next/link`);
            }
            if (onMouseEnterProp) {
                console.warn(`"onMouseEnter" was passed to <Link> with \`href\` of \`${formattedHref}\` but "legacyBehavior" was set. The legacy behavior requires onMouseEnter be set on the child of next/link`);
            }
            try {
                child = _react.default.Children.only(children);
            } catch (err) {
                if (!children) {
                    throw Object.defineProperty(new Error(`No children were passed to <Link> with \`href\` of \`${formattedHref}\` but one child is required https://nextjs.org/docs/messages/link-no-children`), "__NEXT_ERROR_CODE", {
                        value: "E320",
                        enumerable: false,
                        configurable: true
                    });
                }
                throw Object.defineProperty(new Error(`Multiple children were passed to <Link> with \`href\` of \`${formattedHref}\` but only one child is supported https://nextjs.org/docs/messages/link-multiple-children` + (typeof window !== 'undefined' ? " \nOpen your browser's console to view the Component stack trace." : '')), "__NEXT_ERROR_CODE", {
                    value: "E266",
                    enumerable: false,
                    configurable: true
                });
            }
        } else //TURBOPACK unreachable
        ;
    } else {
        if ("TURBOPACK compile-time truthy", 1) {
            if (children?.type === 'a') {
                throw Object.defineProperty(new Error('Invalid <Link> with <a> child. Please remove <a> or use <Link legacyBehavior>.\nLearn more: https://nextjs.org/docs/messages/invalid-new-link-with-extra-anchor'), "__NEXT_ERROR_CODE", {
                    value: "E209",
                    enumerable: false,
                    configurable: true
                });
            }
        }
    }
    const childRef = legacyBehavior ? child && typeof child === 'object' && child.ref : forwardedRef;
    // Use a callback ref to attach an IntersectionObserver to the anchor tag on
    // mount. In the future we will also use this to keep track of all the
    // currently mounted <Link> instances, e.g. so we can re-prefetch them after
    // a revalidation or refresh.
    const observeLinkVisibilityOnMount = _react.default.useCallback({
        "LinkComponent.useCallback[observeLinkVisibilityOnMount]": (element)=>{
            if (router !== null) {
                linkInstanceRef.current = (0, _links.mountLinkInstance)(element, formattedHref, router, fetchStrategy, prefetchEnabled, setOptimisticLinkStatus);
            }
            return ({
                "LinkComponent.useCallback[observeLinkVisibilityOnMount]": ()=>{
                    if (linkInstanceRef.current) {
                        (0, _links.unmountLinkForCurrentNavigation)(linkInstanceRef.current);
                        linkInstanceRef.current = null;
                    }
                    (0, _links.unmountPrefetchableInstance)(element);
                }
            })["LinkComponent.useCallback[observeLinkVisibilityOnMount]"];
        }
    }["LinkComponent.useCallback[observeLinkVisibilityOnMount]"], [
        prefetchEnabled,
        formattedHref,
        router,
        fetchStrategy,
        setOptimisticLinkStatus
    ]);
    const mergedRef = (0, _usemergedref.useMergedRef)(observeLinkVisibilityOnMount, childRef);
    const childProps = {
        ref: mergedRef,
        onClick (e) {
            if ("TURBOPACK compile-time truthy", 1) {
                if (!e) {
                    throw Object.defineProperty(new Error(`Component rendered inside next/link has to pass click event to "onClick" prop.`), "__NEXT_ERROR_CODE", {
                        value: "E312",
                        enumerable: false,
                        configurable: true
                    });
                }
            }
            if (!legacyBehavior && typeof onClick === 'function') {
                onClick(e);
            }
            if (legacyBehavior && child.props && typeof child.props.onClick === 'function') {
                child.props.onClick(e);
            }
            if (!router) {
                return;
            }
            if (e.defaultPrevented) {
                return;
            }
            linkClicked(e, formattedHref, linkInstanceRef, replace, scroll, onNavigate, transitionTypes);
        },
        onMouseEnter (e) {
            if (!legacyBehavior && typeof onMouseEnterProp === 'function') {
                onMouseEnterProp(e);
            }
            if (legacyBehavior && child.props && typeof child.props.onMouseEnter === 'function') {
                child.props.onMouseEnter(e);
            }
            if (!router) {
                return;
            }
            if ("TURBOPACK compile-time truthy", 1) {
                return;
            }
            //TURBOPACK unreachable
            ;
            const upgradeToDynamicPrefetch = undefined;
        },
        onTouchStart: ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : function onTouchStart(e) {
            if (!legacyBehavior && typeof onTouchStartProp === 'function') {
                onTouchStartProp(e);
            }
            if (legacyBehavior && child.props && typeof child.props.onTouchStart === 'function') {
                child.props.onTouchStart(e);
            }
            if (!router) {
                return;
            }
            if (!prefetchEnabled) {
                return;
            }
            const upgradeToDynamicPrefetch = unstable_dynamicOnHover === true;
            (0, _links.onNavigationIntent)(e.currentTarget, upgradeToDynamicPrefetch);
        }
    };
    // If the url is absolute, we can bypass the logic to prepend the basePath.
    if ((0, _utils.isAbsoluteUrl)(formattedHref)) {
        childProps.href = formattedHref;
    } else if (!legacyBehavior || passHref || child.type === 'a' && !('href' in child.props)) {
        childProps.href = (0, _addbasepath.addBasePath)(formattedHref);
    }
    let link;
    if (legacyBehavior) {
        if ("TURBOPACK compile-time truthy", 1) {
            (0, _erroronce.errorOnce)('`legacyBehavior` is deprecated and will be removed in a future ' + 'release. A codemod is available to upgrade your components:\n\n' + 'npx @next/codemod@latest new-link .\n\n' + 'Learn more: https://nextjs.org/docs/app/building-your-application/upgrading/codemods#remove-a-tags-from-link-components');
        }
        link = /*#__PURE__*/ _react.default.cloneElement(child, childProps);
    } else {
        link = /*#__PURE__*/ (0, _jsxruntime.jsx)("a", {
            ...restProps,
            ...childProps,
            children: children
        });
    }
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(LinkStatusContext.Provider, {
        value: linkStatus,
        children: link
    });
}
const LinkStatusContext = /*#__PURE__*/ (0, _react.createContext)(_links.IDLE_LINK_STATUS);
const useLinkStatus = ()=>{
    return (0, _react.useContext)(LinkStatusContext);
};
function getFetchStrategyFromPrefetchProp(prefetchProp) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    else {
        return prefetchProp === null || prefetchProp === 'auto' ? _types.FetchStrategy.PPR : // (although invalid values should've been filtered out by prop validation in dev)
        _types.FetchStrategy.Full;
    }
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
}
}),
]);

//# debugId=05521c61-bb64-7f38-147b-6c21fdbdd1e7
//# sourceMappingURL=_0ri~zbg._.js.map