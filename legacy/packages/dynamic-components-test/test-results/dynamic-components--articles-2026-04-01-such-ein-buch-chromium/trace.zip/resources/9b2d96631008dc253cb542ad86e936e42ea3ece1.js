;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="511c54c0-fbc9-d108-be92-5de13ee21fc3")}catch(e){}}();
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__addDisposableResource",
    ()=>__addDisposableResource,
    "__assign",
    ()=>__assign,
    "__asyncDelegator",
    ()=>__asyncDelegator,
    "__asyncGenerator",
    ()=>__asyncGenerator,
    "__asyncValues",
    ()=>__asyncValues,
    "__await",
    ()=>__await,
    "__awaiter",
    ()=>__awaiter,
    "__classPrivateFieldGet",
    ()=>__classPrivateFieldGet,
    "__classPrivateFieldIn",
    ()=>__classPrivateFieldIn,
    "__classPrivateFieldSet",
    ()=>__classPrivateFieldSet,
    "__createBinding",
    ()=>__createBinding,
    "__decorate",
    ()=>__decorate,
    "__disposeResources",
    ()=>__disposeResources,
    "__esDecorate",
    ()=>__esDecorate,
    "__exportStar",
    ()=>__exportStar,
    "__extends",
    ()=>__extends,
    "__generator",
    ()=>__generator,
    "__importDefault",
    ()=>__importDefault,
    "__importStar",
    ()=>__importStar,
    "__makeTemplateObject",
    ()=>__makeTemplateObject,
    "__metadata",
    ()=>__metadata,
    "__param",
    ()=>__param,
    "__propKey",
    ()=>__propKey,
    "__read",
    ()=>__read,
    "__rest",
    ()=>__rest,
    "__rewriteRelativeImportExtension",
    ()=>__rewriteRelativeImportExtension,
    "__runInitializers",
    ()=>__runInitializers,
    "__setFunctionName",
    ()=>__setFunctionName,
    "__spread",
    ()=>__spread,
    "__spreadArray",
    ()=>__spreadArray,
    "__spreadArrays",
    ()=>__spreadArrays,
    "__values",
    ()=>__values,
    "default",
    ()=>__TURBOPACK__default__export__
]);
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */ /* global Reflect, Promise, SuppressedError, Symbol, Iterator */ var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || ({
        __proto__: []
    }) instanceof Array && function(d, b) {
        d.__proto__ = b;
    } || function(d, b) {
        for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return extendStatics(d, b);
};
function __extends(d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
        this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
function __rest(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
}
function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function __param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
function __esDecorate(ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) {
        if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected");
        return f;
    }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for(var i = decorators.length - 1; i >= 0; i--){
        var context = {};
        for(var p in contextIn)context[p] = p === "access" ? {} : contextIn[p];
        for(var p in contextIn.access)context.access[p] = contextIn.access[p];
        context.addInitializer = function(f) {
            if (done) throw new TypeError("Cannot add initializers after decoration has completed");
            extraInitializers.push(accept(f || null));
        };
        var result = (0, decorators[i])(kind === "accessor" ? {
            get: descriptor.get,
            set: descriptor.set
        } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        } else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
}
;
function __runInitializers(thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for(var i = 0; i < initializers.length; i++){
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
}
;
function __propKey(x) {
    return typeof x === "symbol" ? x : "".concat(x);
}
;
function __setFunctionName(f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", {
        configurable: true,
        value: prefix ? "".concat(prefix, " ", name) : name
    });
}
;
function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}
function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}
function __generator(thisArg, body) {
    var _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    //TURBOPACK unreachable
    ;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
var __createBinding = Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
};
function __exportStar(m, o) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
}
function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function() {
            if (o && i >= o.length) o = void 0;
            return {
                value: o && o[i++],
                done: !o
            };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while((n === void 0 || n-- > 0) && !(r = i.next()).done)ar.push(r.value);
    } catch (error) {
        e = {
            error: error
        };
    } finally{
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        } finally{
            if (e) throw e.error;
        }
    }
    return ar;
}
function __spread() {
    for(var ar = [], i = 0; i < arguments.length; i++)ar = ar.concat(__read(arguments[i]));
    return ar;
}
function __spreadArrays() {
    for(var s = 0, i = 0, il = arguments.length; i < il; i++)s += arguments[i].length;
    for(var r = Array(s), k = 0, i = 0; i < il; i++)for(var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)r[k] = a[j];
    return r;
}
function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for(var i = 0, l = from.length, ar; i < l; i++){
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
}
function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}
function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function() {
        return this;
    }, i;
    //TURBOPACK unreachable
    ;
    function awaitReturn(f) {
        return function(v) {
            return Promise.resolve(v).then(f, reject);
        };
    }
    function verb(n, f) {
        if (g[n]) {
            i[n] = function(v) {
                return new Promise(function(a, b) {
                    q.push([
                        n,
                        v,
                        a,
                        b
                    ]) > 1 || resume(n, v);
                });
            };
            if (f) i[n] = f(i[n]);
        }
    }
    function resume(n, v) {
        try {
            step(g[n](v));
        } catch (e) {
            settle(q[0][3], e);
        }
    }
    function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }
    function fulfill(value) {
        resume("next", value);
    }
    function reject(value) {
        resume("throw", value);
    }
    function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
    }
}
function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function(e) {
        throw e;
    }), verb("return"), i[Symbol.iterator] = function() {
        return this;
    }, i;
    //TURBOPACK unreachable
    ;
    function verb(n, f) {
        i[n] = o[n] ? function(v) {
            return (p = !p) ? {
                value: __await(o[n](v)),
                done: false
            } : f ? f(v) : v;
        } : f;
    }
}
function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i);
    //TURBOPACK unreachable
    ;
    function verb(n) {
        i[n] = o[n] && function(v) {
            return new Promise(function(resolve, reject) {
                v = o[n](v), settle(resolve, reject, v.done, v.value);
            });
        };
    }
    function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function(v) {
            resolve({
                value: v,
                done: d
            });
        }, reject);
    }
}
function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) {
        Object.defineProperty(cooked, "raw", {
            value: raw
        });
    } else {
        cooked.raw = raw;
    }
    return cooked;
}
;
var __setModuleDefault = Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
};
var ownKeys = function(o) {
    ownKeys = Object.getOwnPropertyNames || function(o) {
        var ar = [];
        for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
        return ar;
    };
    return ownKeys(o);
};
function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
    }
    __setModuleDefault(result, mod);
    return result;
}
function __importDefault(mod) {
    return mod && mod.__esModule ? mod : {
        default: mod
    };
}
function __classPrivateFieldGet(receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}
function __classPrivateFieldSet(receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
}
function __classPrivateFieldIn(state, receiver) {
    if (receiver === null || typeof receiver !== "object" && typeof receiver !== "function") throw new TypeError("Cannot use 'in' operator on non-object");
    return typeof state === "function" ? receiver === state : state.has(receiver);
}
function __addDisposableResource(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose, inner;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
            if (async) inner = dispose;
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        if (inner) dispose = function() {
            try {
                inner.call(this);
            } catch (e) {
                return Promise.reject(e);
            }
        };
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
}
var _SuppressedError = typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};
function __disposeResources(env) {
    function fail(e) {
        env.error = env.hasError ? new _SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
        env.hasError = true;
    }
    var r, s = 0;
    function next() {
        while(r = env.stack.pop()){
            try {
                if (!r.async && s === 1) return s = 0, env.stack.push(r), Promise.resolve().then(next);
                if (r.dispose) {
                    var result = r.dispose.call(r.value);
                    if (r.async) return s |= 2, Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } else s |= 1;
            } catch (e) {
                fail(e);
            }
        }
        if (s === 1) return env.hasError ? Promise.reject(env.error) : Promise.resolve();
        if (env.hasError) throw env.error;
    }
    return next();
}
function __rewriteRelativeImportExtension(path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
        return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function(m, tsx, d, ext, cm) {
            return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : d + ext + "." + cm.toLowerCase() + "js";
        });
    }
    return path;
}
const __TURBOPACK__default__export__ = {
    __extends,
    __assign,
    __rest,
    __decorate,
    __param,
    __esDecorate,
    __runInitializers,
    __propKey,
    __setFunctionName,
    __metadata,
    __awaiter,
    __generator,
    __createBinding,
    __exportStar,
    __values,
    __read,
    __spread,
    __spreadArrays,
    __spreadArray,
    __await,
    __asyncGenerator,
    __asyncDelegator,
    __asyncValues,
    __makeTemplateObject,
    __importStar,
    __importDefault,
    __classPrivateFieldGet,
    __classPrivateFieldSet,
    __classPrivateFieldIn,
    __addDisposableResource,
    __disposeResources,
    __rewriteRelativeImportExtension
};
}),
"[project]/node_modules/ts-invariant/lib/invariant.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InvariantError",
    ()=>InvariantError,
    "default",
    ()=>__TURBOPACK__default__export__,
    "invariant",
    ()=>invariant,
    "setVerbosity",
    ()=>setVerbosity
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
;
var genericMessage = "Invariant Violation";
var _a = Object.setPrototypeOf, setPrototypeOf = _a === void 0 ? function(obj, proto) {
    obj.__proto__ = proto;
    return obj;
} : _a;
var InvariantError = function(_super) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__extends"])(InvariantError, _super);
    function InvariantError(message) {
        if (message === void 0) {
            message = genericMessage;
        }
        var _this = _super.call(this, typeof message === "number" ? genericMessage + ": " + message + " (see https://github.com/apollographql/invariant-packages)" : message) || this;
        _this.framesToPop = 1;
        _this.name = genericMessage;
        setPrototypeOf(_this, InvariantError.prototype);
        return _this;
    }
    return InvariantError;
}(Error);
;
function invariant(condition, message) {
    if (!condition) {
        throw new InvariantError(message);
    }
}
var verbosityLevels = [
    "debug",
    "log",
    "warn",
    "error",
    "silent"
];
var verbosityLevel = verbosityLevels.indexOf("log");
function wrapConsoleMethod(name) {
    return function() {
        if (verbosityLevels.indexOf(name) >= verbosityLevel) {
            // Default to console.log if this host environment happens not to provide
            // all the console.* methods we need.
            var method = console[name] || console.log;
            return method.apply(console, arguments);
        }
    };
}
(function(invariant) {
    invariant.debug = wrapConsoleMethod("debug");
    invariant.log = wrapConsoleMethod("log");
    invariant.warn = wrapConsoleMethod("warn");
    invariant.error = wrapConsoleMethod("error");
})(invariant || (invariant = {}));
function setVerbosity(level) {
    var old = verbosityLevels[verbosityLevel];
    verbosityLevel = Math.max(0, verbosityLevels.indexOf(level));
    return old;
}
const __TURBOPACK__default__export__ = invariant;
}),
"[project]/node_modules/rehackt/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
// We don't want bundlers to error when they encounter usage of any of these exports.
// It's up to the package author to ensure that if they access React internals,
// they do so in a safe way that won't break if React changes how they use these internals.
// (e.g. only access them in development, and only in an optional way that won't
// break if internals are not there or do not have the expected structure)
// @ts-ignore
module.exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = undefined;
// @ts-ignore
module.exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = undefined;
// @ts-ignore
module.exports.__SERVER_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = undefined;
// Here we actually pull in the React library and add everything
// it exports to our own `module.exports`.
// If React suddenly were to add one of the above "polyfilled" exports,
// the React version would overwrite our version, so this should be
// future-proof.
Object.assign(module.exports, __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
}),
"[project]/node_modules/@wry/equality/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "equal",
    ()=>equal
]);
const { toString, hasOwnProperty } = Object.prototype;
const fnToStr = Function.prototype.toString;
const previousComparisons = new Map();
function equal(a, b) {
    try {
        return check(a, b);
    } finally{
        previousComparisons.clear();
    }
}
const __TURBOPACK__default__export__ = equal;
function check(a, b) {
    // If the two values are strictly equal, our job is easy.
    if (a === b) {
        return true;
    }
    // Object.prototype.toString returns a representation of the runtime type of
    // the given value that is considerably more precise than typeof.
    const aTag = toString.call(a);
    const bTag = toString.call(b);
    // If the runtime types of a and b are different, they could maybe be equal
    // under some interpretation of equality, but for simplicity and performance
    // we just return false instead.
    if (aTag !== bTag) {
        return false;
    }
    switch(aTag){
        case '[object Array]':
            // Arrays are a lot like other objects, but we can cheaply compare their
            // lengths as a short-cut before comparing their elements.
            if (a.length !== b.length) return false;
        // Fall through to object case...
        case '[object Object]':
            {
                if (previouslyCompared(a, b)) return true;
                const aKeys = definedKeys(a);
                const bKeys = definedKeys(b);
                // If `a` and `b` have a different number of enumerable keys, they
                // must be different.
                const keyCount = aKeys.length;
                if (keyCount !== bKeys.length) return false;
                // Now make sure they have the same keys.
                for(let k = 0; k < keyCount; ++k){
                    if (!hasOwnProperty.call(b, aKeys[k])) {
                        return false;
                    }
                }
                // Finally, check deep equality of all child properties.
                for(let k = 0; k < keyCount; ++k){
                    const key = aKeys[k];
                    if (!check(a[key], b[key])) {
                        return false;
                    }
                }
                return true;
            }
        case '[object Error]':
            return a.name === b.name && a.message === b.message;
        case '[object Number]':
            // Handle NaN, which is !== itself.
            if (a !== a) return b !== b;
        // Fall through to shared +a === +b case...
        case '[object Boolean]':
        case '[object Date]':
            return +a === +b;
        case '[object RegExp]':
        case '[object String]':
            return a == `${b}`;
        case '[object Map]':
        case '[object Set]':
            {
                if (a.size !== b.size) return false;
                if (previouslyCompared(a, b)) return true;
                const aIterator = a.entries();
                const isMap = aTag === '[object Map]';
                while(true){
                    const info = aIterator.next();
                    if (info.done) break;
                    // If a instanceof Set, aValue === aKey.
                    const [aKey, aValue] = info.value;
                    // So this works the same way for both Set and Map.
                    if (!b.has(aKey)) {
                        return false;
                    }
                    // However, we care about deep equality of values only when dealing
                    // with Map structures.
                    if (isMap && !check(aValue, b.get(aKey))) {
                        return false;
                    }
                }
                return true;
            }
        case '[object Uint16Array]':
        case '[object Uint8Array]':
        case '[object Uint32Array]':
        case '[object Int32Array]':
        case '[object Int8Array]':
        case '[object Int16Array]':
        case '[object ArrayBuffer]':
            // DataView doesn't need these conversions, but the equality check is
            // otherwise the same.
            a = new Uint8Array(a);
            b = new Uint8Array(b);
        // Fall through...
        case '[object DataView]':
            {
                let len = a.byteLength;
                if (len === b.byteLength) {
                    while(len-- && a[len] === b[len]){
                    // Keep looping as long as the bytes are equal.
                    }
                }
                return len === -1;
            }
        case '[object AsyncFunction]':
        case '[object GeneratorFunction]':
        case '[object AsyncGeneratorFunction]':
        case '[object Function]':
            {
                const aCode = fnToStr.call(a);
                if (aCode !== fnToStr.call(b)) {
                    return false;
                }
                // We consider non-native functions equal if they have the same code
                // (native functions require === because their code is censored).
                // Note that this behavior is not entirely sound, since !== function
                // objects with the same code can behave differently depending on
                // their closure scope. However, any function can behave differently
                // depending on the values of its input arguments (including this)
                // and its calling context (including its closure scope), even
                // though the function object is === to itself; and it is entirely
                // possible for functions that are not === to behave exactly the
                // same under all conceivable circumstances. Because none of these
                // factors are statically decidable in JavaScript, JS function
                // equality is not well-defined. This ambiguity allows us to
                // consider the best possible heuristic among various imperfect
                // options, and equating non-native functions that have the same
                // code has enormous practical benefits, such as when comparing
                // functions that are repeatedly passed as fresh function
                // expressions within objects that are otherwise deeply equal. Since
                // any function created from the same syntactic expression (in the
                // same code location) will always stringify to the same code
                // according to fnToStr.call, we can reasonably expect these
                // repeatedly passed function expressions to have the same code, and
                // thus behave "the same" (with all the caveats mentioned above),
                // even though the runtime function objects are !== to one another.
                return !endsWith(aCode, nativeCodeSuffix);
            }
    }
    // Otherwise the values are not equal.
    return false;
}
function definedKeys(obj) {
    // Remember that the second argument to Array.prototype.filter will be
    // used as `this` within the callback function.
    return Object.keys(obj).filter(isDefinedKey, obj);
}
function isDefinedKey(key) {
    return this[key] !== void 0;
}
const nativeCodeSuffix = "{ [native code] }";
function endsWith(full, suffix) {
    const fromIndex = full.length - suffix.length;
    return fromIndex >= 0 && full.indexOf(suffix, fromIndex) === fromIndex;
}
function previouslyCompared(a, b) {
    // Though cyclic references can make an object graph appear infinite from the
    // perspective of a depth-first traversal, the graph still contains a finite
    // number of distinct object references. We use the previousComparisons cache
    // to avoid comparing the same pair of object references more than once, which
    // guarantees termination (even if we end up comparing every object in one
    // graph to every object in the other graph, which is extremely unlikely),
    // while still allowing weird isomorphic structures (like rings with different
    // lengths) a chance to pass the equality test.
    let bSet = previousComparisons.get(a);
    if (bSet) {
        // Return true here because we can be sure false will be returned somewhere
        // else if the objects are not equivalent.
        if (bSet.has(b)) return true;
    } else {
        previousComparisons.set(a, bSet = new Set);
    }
    bSet.add(b);
    return false;
}
}),
"[project]/node_modules/@wry/caches/lib/weak.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WeakCache",
    ()=>WeakCache
]);
function noop() {}
const defaultDispose = noop;
const _WeakRef = typeof WeakRef !== "undefined" ? WeakRef : function(value) {
    return {
        deref: ()=>value
    };
};
const _WeakMap = typeof WeakMap !== "undefined" ? WeakMap : Map;
const _FinalizationRegistry = typeof FinalizationRegistry !== "undefined" ? FinalizationRegistry : function() {
    return {
        register: noop,
        unregister: noop
    };
};
const finalizationBatchSize = 10024;
class WeakCache {
    constructor(max = Infinity, dispose = defaultDispose){
        this.max = max;
        this.dispose = dispose;
        this.map = new _WeakMap();
        this.newest = null;
        this.oldest = null;
        this.unfinalizedNodes = new Set();
        this.finalizationScheduled = false;
        this.size = 0;
        this.finalize = ()=>{
            const iterator = this.unfinalizedNodes.values();
            for(let i = 0; i < finalizationBatchSize; i++){
                const node = iterator.next().value;
                if (!node) break;
                this.unfinalizedNodes.delete(node);
                const key = node.key;
                delete node.key;
                node.keyRef = new _WeakRef(key);
                this.registry.register(key, node, node);
            }
            if (this.unfinalizedNodes.size > 0) {
                queueMicrotask(this.finalize);
            } else {
                this.finalizationScheduled = false;
            }
        };
        this.registry = new _FinalizationRegistry(this.deleteNode.bind(this));
    }
    has(key) {
        return this.map.has(key);
    }
    get(key) {
        const node = this.getNode(key);
        return node && node.value;
    }
    getNode(key) {
        const node = this.map.get(key);
        if (node && node !== this.newest) {
            const { older, newer } = node;
            if (newer) {
                newer.older = older;
            }
            if (older) {
                older.newer = newer;
            }
            node.older = this.newest;
            node.older.newer = node;
            node.newer = null;
            this.newest = node;
            if (node === this.oldest) {
                this.oldest = newer;
            }
        }
        return node;
    }
    set(key, value) {
        let node = this.getNode(key);
        if (node) {
            return node.value = value;
        }
        node = {
            key,
            value,
            newer: null,
            older: this.newest
        };
        if (this.newest) {
            this.newest.newer = node;
        }
        this.newest = node;
        this.oldest = this.oldest || node;
        this.scheduleFinalization(node);
        this.map.set(key, node);
        this.size++;
        return node.value;
    }
    clean() {
        while(this.oldest && this.size > this.max){
            this.deleteNode(this.oldest);
        }
    }
    deleteNode(node) {
        if (node === this.newest) {
            this.newest = node.older;
        }
        if (node === this.oldest) {
            this.oldest = node.newer;
        }
        if (node.newer) {
            node.newer.older = node.older;
        }
        if (node.older) {
            node.older.newer = node.newer;
        }
        this.size--;
        const key = node.key || node.keyRef && node.keyRef.deref();
        this.dispose(node.value, key);
        if (!node.keyRef) {
            this.unfinalizedNodes.delete(node);
        } else {
            this.registry.unregister(node);
        }
        if (key) this.map.delete(key);
    }
    delete(key) {
        const node = this.map.get(key);
        if (node) {
            this.deleteNode(node);
            return true;
        }
        return false;
    }
    scheduleFinalization(node) {
        this.unfinalizedNodes.add(node);
        if (!this.finalizationScheduled) {
            this.finalizationScheduled = true;
            queueMicrotask(this.finalize);
        }
    }
}
}),
"[project]/node_modules/@wry/caches/lib/strong.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StrongCache",
    ()=>StrongCache
]);
function defaultDispose() {}
class StrongCache {
    constructor(max = Infinity, dispose = defaultDispose){
        this.max = max;
        this.dispose = dispose;
        this.map = new Map();
        this.newest = null;
        this.oldest = null;
    }
    has(key) {
        return this.map.has(key);
    }
    get(key) {
        const node = this.getNode(key);
        return node && node.value;
    }
    get size() {
        return this.map.size;
    }
    getNode(key) {
        const node = this.map.get(key);
        if (node && node !== this.newest) {
            const { older, newer } = node;
            if (newer) {
                newer.older = older;
            }
            if (older) {
                older.newer = newer;
            }
            node.older = this.newest;
            node.older.newer = node;
            node.newer = null;
            this.newest = node;
            if (node === this.oldest) {
                this.oldest = newer;
            }
        }
        return node;
    }
    set(key, value) {
        let node = this.getNode(key);
        if (node) {
            return node.value = value;
        }
        node = {
            key,
            value,
            newer: null,
            older: this.newest
        };
        if (this.newest) {
            this.newest.newer = node;
        }
        this.newest = node;
        this.oldest = this.oldest || node;
        this.map.set(key, node);
        return node.value;
    }
    clean() {
        while(this.oldest && this.map.size > this.max){
            this.delete(this.oldest.key);
        }
    }
    delete(key) {
        const node = this.map.get(key);
        if (node) {
            if (node === this.newest) {
                this.newest = node.older;
            }
            if (node === this.oldest) {
                this.oldest = node.newer;
            }
            if (node.newer) {
                node.newer.older = node.older;
            }
            if (node.older) {
                node.older.newer = node.newer;
            }
            this.map.delete(key);
            this.dispose(node.value, key);
            return true;
        }
        return false;
    }
}
}),
"[project]/node_modules/zen-observable-ts/module.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Observable",
    ()=>Observable
]);
function _createForOfIteratorHelperLoose(o, allowArrayLike) {
    var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];
    if (it) return (it = it.call(o)).next.bind(it);
    if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
        if (it) o = it;
        var i = 0;
        return function() {
            if (i >= o.length) return {
                done: true
            };
            return {
                done: false,
                value: o[i++]
            };
        };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++){
        arr2[i] = arr[i];
    }
    return arr2;
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    Object.defineProperty(Constructor, "prototype", {
        writable: false
    });
    return Constructor;
}
// === Symbol Support ===
var hasSymbols = function() {
    return typeof Symbol === 'function';
};
var hasSymbol = function(name) {
    return hasSymbols() && Boolean(Symbol[name]);
};
var getSymbol = function(name) {
    return hasSymbol(name) ? Symbol[name] : '@@' + name;
};
if (hasSymbols() && !hasSymbol('observable')) {
    Symbol.observable = Symbol('observable');
}
var SymbolIterator = getSymbol('iterator');
var SymbolObservable = getSymbol('observable');
var SymbolSpecies = getSymbol('species'); // === Abstract Operations ===
function getMethod(obj, key) {
    var value = obj[key];
    if (value == null) return undefined;
    if (typeof value !== 'function') throw new TypeError(value + ' is not a function');
    return value;
}
function getSpecies(obj) {
    var ctor = obj.constructor;
    if (ctor !== undefined) {
        ctor = ctor[SymbolSpecies];
        if (ctor === null) {
            ctor = undefined;
        }
    }
    return ctor !== undefined ? ctor : Observable;
}
function isObservable(x) {
    return x instanceof Observable; // SPEC: Brand check
}
function hostReportError(e) {
    if (hostReportError.log) {
        hostReportError.log(e);
    } else {
        setTimeout(function() {
            throw e;
        });
    }
}
function enqueue(fn) {
    Promise.resolve().then(function() {
        try {
            fn();
        } catch (e) {
            hostReportError(e);
        }
    });
}
function cleanupSubscription(subscription) {
    var cleanup = subscription._cleanup;
    if (cleanup === undefined) return;
    subscription._cleanup = undefined;
    if (!cleanup) {
        return;
    }
    try {
        if (typeof cleanup === 'function') {
            cleanup();
        } else {
            var unsubscribe = getMethod(cleanup, 'unsubscribe');
            if (unsubscribe) {
                unsubscribe.call(cleanup);
            }
        }
    } catch (e) {
        hostReportError(e);
    }
}
function closeSubscription(subscription) {
    subscription._observer = undefined;
    subscription._queue = undefined;
    subscription._state = 'closed';
}
function flushSubscription(subscription) {
    var queue = subscription._queue;
    if (!queue) {
        return;
    }
    subscription._queue = undefined;
    subscription._state = 'ready';
    for(var i = 0; i < queue.length; ++i){
        notifySubscription(subscription, queue[i].type, queue[i].value);
        if (subscription._state === 'closed') break;
    }
}
function notifySubscription(subscription, type, value) {
    subscription._state = 'running';
    var observer = subscription._observer;
    try {
        var m = getMethod(observer, type);
        switch(type){
            case 'next':
                if (m) m.call(observer, value);
                break;
            case 'error':
                closeSubscription(subscription);
                if (m) m.call(observer, value);
                else throw value;
                break;
            case 'complete':
                closeSubscription(subscription);
                if (m) m.call(observer);
                break;
        }
    } catch (e) {
        hostReportError(e);
    }
    if (subscription._state === 'closed') cleanupSubscription(subscription);
    else if (subscription._state === 'running') subscription._state = 'ready';
}
function onNotify(subscription, type, value) {
    if (subscription._state === 'closed') return;
    if (subscription._state === 'buffering') {
        subscription._queue.push({
            type: type,
            value: value
        });
        return;
    }
    if (subscription._state !== 'ready') {
        subscription._state = 'buffering';
        subscription._queue = [
            {
                type: type,
                value: value
            }
        ];
        enqueue(function() {
            return flushSubscription(subscription);
        });
        return;
    }
    notifySubscription(subscription, type, value);
}
var Subscription = /*#__PURE__*/ function() {
    function Subscription(observer, subscriber) {
        // ASSERT: observer is an object
        // ASSERT: subscriber is callable
        this._cleanup = undefined;
        this._observer = observer;
        this._queue = undefined;
        this._state = 'initializing';
        var subscriptionObserver = new SubscriptionObserver(this);
        try {
            this._cleanup = subscriber.call(undefined, subscriptionObserver);
        } catch (e) {
            subscriptionObserver.error(e);
        }
        if (this._state === 'initializing') this._state = 'ready';
    }
    var _proto = Subscription.prototype;
    _proto.unsubscribe = function unsubscribe() {
        if (this._state !== 'closed') {
            closeSubscription(this);
            cleanupSubscription(this);
        }
    };
    _createClass(Subscription, [
        {
            key: "closed",
            get: function() {
                return this._state === 'closed';
            }
        }
    ]);
    return Subscription;
}();
var SubscriptionObserver = /*#__PURE__*/ function() {
    function SubscriptionObserver(subscription) {
        this._subscription = subscription;
    }
    var _proto2 = SubscriptionObserver.prototype;
    _proto2.next = function next(value) {
        onNotify(this._subscription, 'next', value);
    };
    _proto2.error = function error(value) {
        onNotify(this._subscription, 'error', value);
    };
    _proto2.complete = function complete() {
        onNotify(this._subscription, 'complete');
    };
    _createClass(SubscriptionObserver, [
        {
            key: "closed",
            get: function() {
                return this._subscription._state === 'closed';
            }
        }
    ]);
    return SubscriptionObserver;
}();
var Observable = /*#__PURE__*/ function() {
    function Observable(subscriber) {
        if (!(this instanceof Observable)) throw new TypeError('Observable cannot be called as a function');
        if (typeof subscriber !== 'function') throw new TypeError('Observable initializer must be a function');
        this._subscriber = subscriber;
    }
    var _proto3 = Observable.prototype;
    _proto3.subscribe = function subscribe(observer) {
        if (typeof observer !== 'object' || observer === null) {
            observer = {
                next: observer,
                error: arguments[1],
                complete: arguments[2]
            };
        }
        return new Subscription(observer, this._subscriber);
    };
    _proto3.forEach = function forEach(fn) {
        var _this = this;
        return new Promise(function(resolve, reject) {
            if (typeof fn !== 'function') {
                reject(new TypeError(fn + ' is not a function'));
                return;
            }
            function done() {
                subscription.unsubscribe();
                resolve();
            }
            var subscription = _this.subscribe({
                next: function(value) {
                    try {
                        fn(value, done);
                    } catch (e) {
                        reject(e);
                        subscription.unsubscribe();
                    }
                },
                error: reject,
                complete: resolve
            });
        });
    };
    _proto3.map = function map(fn) {
        var _this2 = this;
        if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
        var C = getSpecies(this);
        return new C(function(observer) {
            return _this2.subscribe({
                next: function(value) {
                    try {
                        value = fn(value);
                    } catch (e) {
                        return observer.error(e);
                    }
                    observer.next(value);
                },
                error: function(e) {
                    observer.error(e);
                },
                complete: function() {
                    observer.complete();
                }
            });
        });
    };
    _proto3.filter = function filter(fn) {
        var _this3 = this;
        if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
        var C = getSpecies(this);
        return new C(function(observer) {
            return _this3.subscribe({
                next: function(value) {
                    try {
                        if (!fn(value)) return;
                    } catch (e) {
                        return observer.error(e);
                    }
                    observer.next(value);
                },
                error: function(e) {
                    observer.error(e);
                },
                complete: function() {
                    observer.complete();
                }
            });
        });
    };
    _proto3.reduce = function reduce(fn) {
        var _this4 = this;
        if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
        var C = getSpecies(this);
        var hasSeed = arguments.length > 1;
        var hasValue = false;
        var seed = arguments[1];
        var acc = seed;
        return new C(function(observer) {
            return _this4.subscribe({
                next: function(value) {
                    var first = !hasValue;
                    hasValue = true;
                    if (!first || hasSeed) {
                        try {
                            acc = fn(acc, value);
                        } catch (e) {
                            return observer.error(e);
                        }
                    } else {
                        acc = value;
                    }
                },
                error: function(e) {
                    observer.error(e);
                },
                complete: function() {
                    if (!hasValue && !hasSeed) return observer.error(new TypeError('Cannot reduce an empty sequence'));
                    observer.next(acc);
                    observer.complete();
                }
            });
        });
    };
    _proto3.concat = function concat() {
        var _this5 = this;
        for(var _len = arguments.length, sources = new Array(_len), _key = 0; _key < _len; _key++){
            sources[_key] = arguments[_key];
        }
        var C = getSpecies(this);
        return new C(function(observer) {
            var subscription;
            var index = 0;
            function startNext(next) {
                subscription = next.subscribe({
                    next: function(v) {
                        observer.next(v);
                    },
                    error: function(e) {
                        observer.error(e);
                    },
                    complete: function() {
                        if (index === sources.length) {
                            subscription = undefined;
                            observer.complete();
                        } else {
                            startNext(C.from(sources[index++]));
                        }
                    }
                });
            }
            startNext(_this5);
            return function() {
                if (subscription) {
                    subscription.unsubscribe();
                    subscription = undefined;
                }
            };
        });
    };
    _proto3.flatMap = function flatMap(fn) {
        var _this6 = this;
        if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
        var C = getSpecies(this);
        return new C(function(observer) {
            var subscriptions = [];
            var outer = _this6.subscribe({
                next: function(value) {
                    if (fn) {
                        try {
                            value = fn(value);
                        } catch (e) {
                            return observer.error(e);
                        }
                    }
                    var inner = C.from(value).subscribe({
                        next: function(value) {
                            observer.next(value);
                        },
                        error: function(e) {
                            observer.error(e);
                        },
                        complete: function() {
                            var i = subscriptions.indexOf(inner);
                            if (i >= 0) subscriptions.splice(i, 1);
                            completeIfDone();
                        }
                    });
                    subscriptions.push(inner);
                },
                error: function(e) {
                    observer.error(e);
                },
                complete: function() {
                    completeIfDone();
                }
            });
            function completeIfDone() {
                if (outer.closed && subscriptions.length === 0) observer.complete();
            }
            return function() {
                subscriptions.forEach(function(s) {
                    return s.unsubscribe();
                });
                outer.unsubscribe();
            };
        });
    };
    _proto3[SymbolObservable] = function() {
        return this;
    };
    Observable.from = function from(x) {
        var C = typeof this === 'function' ? this : Observable;
        if (x == null) throw new TypeError(x + ' is not an object');
        var method = getMethod(x, SymbolObservable);
        if (method) {
            var observable = method.call(x);
            if (Object(observable) !== observable) throw new TypeError(observable + ' is not an object');
            if (isObservable(observable) && observable.constructor === C) return observable;
            return new C(function(observer) {
                return observable.subscribe(observer);
            });
        }
        if (hasSymbol('iterator')) {
            method = getMethod(x, SymbolIterator);
            if (method) {
                return new C(function(observer) {
                    enqueue(function() {
                        if (observer.closed) return;
                        for(var _iterator = _createForOfIteratorHelperLoose(method.call(x)), _step; !(_step = _iterator()).done;){
                            var item = _step.value;
                            observer.next(item);
                            if (observer.closed) return;
                        }
                        observer.complete();
                    });
                });
            }
        }
        if (Array.isArray(x)) {
            return new C(function(observer) {
                enqueue(function() {
                    if (observer.closed) return;
                    for(var i = 0; i < x.length; ++i){
                        observer.next(x[i]);
                        if (observer.closed) return;
                    }
                    observer.complete();
                });
            });
        }
        throw new TypeError(x + ' is not observable');
    };
    Observable.of = function of() {
        for(var _len2 = arguments.length, items = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++){
            items[_key2] = arguments[_key2];
        }
        var C = typeof this === 'function' ? this : Observable;
        return new C(function(observer) {
            enqueue(function() {
                if (observer.closed) return;
                for(var i = 0; i < items.length; ++i){
                    observer.next(items[i]);
                    if (observer.closed) return;
                }
                observer.complete();
            });
        });
    };
    _createClass(Observable, null, [
        {
            key: SymbolSpecies,
            get: function() {
                return this;
            }
        }
    ]);
    return Observable;
}();
if (hasSymbols()) {
    Object.defineProperty(Observable, Symbol('extensions'), {
        value: {
            symbol: SymbolObservable,
            hostReportError: hostReportError
        },
        configurable: true
    });
}
;
}),
"[project]/node_modules/@apollo/client/node_modules/optimism/node_modules/@wry/trie/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Trie",
    ()=>Trie
]);
// A [trie](https://en.wikipedia.org/wiki/Trie) data structure that holds
// object keys weakly, yet can also hold non-object keys, unlike the
// native `WeakMap`.
// If no makeData function is supplied, the looked-up data will be an empty,
// null-prototype Object.
const defaultMakeData = ()=>Object.create(null);
// Useful for processing arguments objects as well as arrays.
const { forEach, slice } = Array.prototype;
const { hasOwnProperty } = Object.prototype;
class Trie {
    constructor(weakness = true, makeData = defaultMakeData){
        this.weakness = weakness;
        this.makeData = makeData;
    }
    lookup(...array) {
        return this.lookupArray(array);
    }
    lookupArray(array) {
        let node = this;
        forEach.call(array, (key)=>node = node.getChildTrie(key));
        return hasOwnProperty.call(node, "data") ? node.data : node.data = this.makeData(slice.call(array));
    }
    peek(...array) {
        return this.peekArray(array);
    }
    peekArray(array) {
        let node = this;
        for(let i = 0, len = array.length; node && i < len; ++i){
            const map = this.weakness && isObjRef(array[i]) ? node.weak : node.strong;
            node = map && map.get(array[i]);
        }
        return node && node.data;
    }
    getChildTrie(key) {
        const map = this.weakness && isObjRef(key) ? this.weak || (this.weak = new WeakMap()) : this.strong || (this.strong = new Map());
        let child = map.get(key);
        if (!child) map.set(key, child = new Trie(this.weakness, this.makeData));
        return child;
    }
}
function isObjRef(value) {
    switch(typeof value){
        case "object":
            if (value === null) break;
        // Fall through to return true...
        case "function":
            return true;
    }
    return false;
}
}),
"[project]/node_modules/@wry/trie/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Trie",
    ()=>Trie
]);
// A [trie](https://en.wikipedia.org/wiki/Trie) data structure that holds
// object keys weakly, yet can also hold non-object keys, unlike the
// native `WeakMap`.
// If no makeData function is supplied, the looked-up data will be an empty,
// null-prototype Object.
const defaultMakeData = ()=>Object.create(null);
// Useful for processing arguments objects as well as arrays.
const { forEach, slice } = Array.prototype;
const { hasOwnProperty } = Object.prototype;
class Trie {
    constructor(weakness = true, makeData = defaultMakeData){
        this.weakness = weakness;
        this.makeData = makeData;
    }
    lookup() {
        return this.lookupArray(arguments);
    }
    lookupArray(array) {
        let node = this;
        forEach.call(array, (key)=>node = node.getChildTrie(key));
        return hasOwnProperty.call(node, "data") ? node.data : node.data = this.makeData(slice.call(array));
    }
    peek() {
        return this.peekArray(arguments);
    }
    peekArray(array) {
        let node = this;
        for(let i = 0, len = array.length; node && i < len; ++i){
            const map = node.mapFor(array[i], false);
            node = map && map.get(array[i]);
        }
        return node && node.data;
    }
    remove() {
        return this.removeArray(arguments);
    }
    removeArray(array) {
        let data;
        if (array.length) {
            const head = array[0];
            const map = this.mapFor(head, false);
            const child = map && map.get(head);
            if (child) {
                data = child.removeArray(slice.call(array, 1));
                if (!child.data && !child.weak && !(child.strong && child.strong.size)) {
                    map.delete(head);
                }
            }
        } else {
            data = this.data;
            delete this.data;
        }
        return data;
    }
    getChildTrie(key) {
        const map = this.mapFor(key, true);
        let child = map.get(key);
        if (!child) map.set(key, child = new Trie(this.weakness, this.makeData));
        return child;
    }
    mapFor(key, create) {
        return this.weakness && isObjRef(key) ? this.weak || (create ? this.weak = new WeakMap : void 0) : this.strong || (create ? this.strong = new Map : void 0);
    }
}
function isObjRef(value) {
    switch(typeof value){
        case "object":
            if (value === null) break;
        // Fall through to return true...
        case "function":
            return true;
    }
    return false;
}
}),
"[project]/node_modules/@apollo/client/node_modules/@wry/context/lib/slot.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Slot",
    ()=>Slot
]);
// This currentContext variable will only be used if the makeSlotClass
// function is called, which happens only if this is the first copy of the
// @wry/context package to be imported.
let currentContext = null;
// This unique internal object is used to denote the absence of a value
// for a given Slot, and is never exposed to outside code.
const MISSING_VALUE = {};
let idCounter = 1;
// Although we can't do anything about the cost of duplicated code from
// accidentally bundling multiple copies of the @wry/context package, we can
// avoid creating the Slot class more than once using makeSlotClass.
const makeSlotClass = ()=>class Slot {
        constructor(){
            // If you have a Slot object, you can find out its slot.id, but you cannot
            // guess the slot.id of a Slot you don't have access to, thanks to the
            // randomized suffix.
            this.id = [
                "slot",
                idCounter++,
                Date.now(),
                Math.random().toString(36).slice(2)
            ].join(":");
        }
        hasValue() {
            for(let context = currentContext; context; context = context.parent){
                // We use the Slot object iself as a key to its value, which means the
                // value cannot be obtained without a reference to the Slot object.
                if (this.id in context.slots) {
                    const value = context.slots[this.id];
                    if (value === MISSING_VALUE) break;
                    if (context !== currentContext) {
                        // Cache the value in currentContext.slots so the next lookup will
                        // be faster. This caching is safe because the tree of contexts and
                        // the values of the slots are logically immutable.
                        currentContext.slots[this.id] = value;
                    }
                    return true;
                }
            }
            if (currentContext) {
                // If a value was not found for this Slot, it's never going to be found
                // no matter how many times we look it up, so we might as well cache
                // the absence of the value, too.
                currentContext.slots[this.id] = MISSING_VALUE;
            }
            return false;
        }
        getValue() {
            if (this.hasValue()) {
                return currentContext.slots[this.id];
            }
        }
        withValue(value, callback, // Given the prevalence of arrow functions, specifying arguments is likely
        // to be much more common than specifying `this`, hence this ordering:
        args, thisArg) {
            const slots = {
                __proto__: null,
                [this.id]: value
            };
            const parent = currentContext;
            currentContext = {
                parent,
                slots
            };
            try {
                // Function.prototype.apply allows the arguments array argument to be
                // omitted or undefined, so args! is fine here.
                return callback.apply(thisArg, args);
            } finally{
                currentContext = parent;
            }
        }
        // Capture the current context and wrap a callback function so that it
        // reestablishes the captured context when called.
        static bind(callback) {
            const context = currentContext;
            return function() {
                const saved = currentContext;
                try {
                    currentContext = context;
                    return callback.apply(this, arguments);
                } finally{
                    currentContext = saved;
                }
            };
        }
        // Immediately run a callback function without any captured context.
        static noContext(callback, // Given the prevalence of arrow functions, specifying arguments is likely
        // to be much more common than specifying `this`, hence this ordering:
        args, thisArg) {
            if (currentContext) {
                const saved = currentContext;
                try {
                    currentContext = null;
                    // Function.prototype.apply allows the arguments array argument to be
                    // omitted or undefined, so args! is fine here.
                    return callback.apply(thisArg, args);
                } finally{
                    currentContext = saved;
                }
            } else {
                return callback.apply(thisArg, args);
            }
        }
    };
function maybe(fn) {
    try {
        return fn();
    } catch (ignored) {}
}
// We store a single global implementation of the Slot class as a permanent
// non-enumerable property of the globalThis object. This obfuscation does
// nothing to prevent access to the Slot class, but at least it ensures the
// implementation (i.e. currentContext) cannot be tampered with, and all copies
// of the @wry/context package (hopefully just one) will share the same Slot
// implementation. Since the first copy of the @wry/context package to be
// imported wins, this technique imposes a steep cost for any future breaking
// changes to the Slot class.
const globalKey = "@wry/context:Slot";
const host = // Prefer globalThis when available.
// https://github.com/benjamn/wryware/issues/347
maybe(()=>globalThis) || // Fall back to global, which works in Node.js and may be converted by some
// bundlers to the appropriate identifier (window, self, ...) depending on the
// bundling target. https://github.com/endojs/endo/issues/576#issuecomment-1178515224
maybe(()=>/*TURBOPACK member replacement*/ __turbopack_context__.g) || // Otherwise, use a dummy host that's local to this module. We used to fall
// back to using the Array constructor as a namespace, but that was flagged in
// https://github.com/benjamn/wryware/issues/347, and can be avoided.
Object.create(null);
// Whichever globalHost we're using, make TypeScript happy about the additional
// globalKey property.
const globalHost = host;
const Slot = globalHost[globalKey] || // Earlier versions of this package stored the globalKey property on the Array
// constructor, so we check there as well, to prevent Slot class duplication.
Array[globalKey] || function(Slot) {
    try {
        Object.defineProperty(globalHost, globalKey, {
            value: Slot,
            enumerable: false,
            writable: false,
            // When it was possible for globalHost to be the Array constructor (a
            // legacy Slot dedup strategy), it was important for the property to be
            // configurable:true so it could be deleted. That does not seem to be as
            // important when globalHost is the global object, but I don't want to
            // cause similar problems again, and configurable:true seems safest.
            // https://github.com/endojs/endo/issues/576#issuecomment-1178274008
            configurable: true
        });
    } finally{
        return Slot;
    }
}(makeSlotClass());
}),
"[project]/node_modules/@apollo/client/node_modules/@wry/context/lib/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "asyncFromGen",
    ()=>asyncFromGen,
    "bind",
    ()=>bind,
    "noContext",
    ()=>noContext,
    "setTimeout",
    ()=>setTimeoutWithContext,
    "wrapYieldingFiberMethods",
    ()=>wrapYieldingFiberMethods
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f40$wry$2f$context$2f$lib$2f$slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/node_modules/@wry/context/lib/slot.js [app-client] (ecmascript)");
;
;
const { bind, noContext } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f40$wry$2f$context$2f$lib$2f$slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"];
;
function setTimeoutWithContext(callback, delay) {
    return setTimeout(bind(callback), delay);
}
function asyncFromGen(genFn) {
    return function() {
        const gen = genFn.apply(this, arguments);
        const boundNext = bind(gen.next);
        const boundThrow = bind(gen.throw);
        return new Promise((resolve, reject)=>{
            function invoke(method, argument) {
                try {
                    var result = method.call(gen, argument);
                } catch (error) {
                    return reject(error);
                }
                const next = result.done ? resolve : invokeNext;
                if (isPromiseLike(result.value)) {
                    result.value.then(next, result.done ? reject : invokeThrow);
                } else {
                    next(result.value);
                }
            }
            const invokeNext = (value)=>invoke(boundNext, value);
            const invokeThrow = (error)=>invoke(boundThrow, error);
            invokeNext();
        });
    };
}
function isPromiseLike(value) {
    return value && typeof value.then === "function";
}
// If you use the fibers npm package to implement coroutines in Node.js,
// you should call this function at least once to ensure context management
// remains coherent across any yields.
const wrappedFibers = [];
function wrapYieldingFiberMethods(Fiber) {
    // There can be only one implementation of Fiber per process, so this array
    // should never grow longer than one element.
    if (wrappedFibers.indexOf(Fiber) < 0) {
        const wrap = (obj, method)=>{
            const fn = obj[method];
            obj[method] = function() {
                return noContext(fn, arguments, this);
            };
        };
        // These methods can yield, according to
        // https://github.com/laverdet/node-fibers/blob/ddebed9b8ae3883e57f822e2108e6943e5c8d2a8/fibers.js#L97-L100
        wrap(Fiber, "yield");
        wrap(Fiber.prototype, "run");
        wrap(Fiber.prototype, "throwInto");
        wrappedFibers.push(Fiber);
    }
    return Fiber;
}
}),
"[project]/node_modules/@apollo/client/node_modules/optimism/lib/context.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "nonReactive",
    ()=>nonReactive,
    "parentEntrySlot",
    ()=>parentEntrySlot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f40$wry$2f$context$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/node_modules/@wry/context/lib/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f40$wry$2f$context$2f$lib$2f$slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/node_modules/@wry/context/lib/slot.js [app-client] (ecmascript)");
;
const parentEntrySlot = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f40$wry$2f$context$2f$lib$2f$slot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"]();
function nonReactive(fn) {
    return parentEntrySlot.withValue(void 0, fn);
}
;
;
}),
"[project]/node_modules/@apollo/client/node_modules/optimism/lib/helpers.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "arrayFromSet",
    ()=>arrayFromSet,
    "hasOwnProperty",
    ()=>hasOwnProperty,
    "maybeUnsubscribe",
    ()=>maybeUnsubscribe
]);
const { hasOwnProperty } = Object.prototype;
const arrayFromSet = Array.from || function(set) {
    const array = [];
    set.forEach((item)=>array.push(item));
    return array;
};
function maybeUnsubscribe(entryOrDep) {
    const { unsubscribe } = entryOrDep;
    if (typeof unsubscribe === "function") {
        entryOrDep.unsubscribe = void 0;
        unsubscribe();
    }
}
}),
"[project]/node_modules/@apollo/client/node_modules/optimism/lib/entry.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Entry",
    ()=>Entry
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/node_modules/optimism/lib/context.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/node_modules/optimism/lib/helpers.js [app-client] (ecmascript)");
;
;
const emptySetPool = [];
const POOL_TARGET_SIZE = 100;
// Since this package might be used browsers, we should avoid using the
// Node built-in assert module.
function assert(condition, optionalMessage) {
    if (!condition) {
        throw new Error(optionalMessage || "assertion failure");
    }
}
function valueIs(a, b) {
    const len = a.length;
    return(// Unknown values are not equal to each other.
    len > 0 && // Both values must be ordinary (or both exceptional) to be equal.
    len === b.length && // The underlying value or exception must be the same.
    a[len - 1] === b[len - 1]);
}
function valueGet(value) {
    switch(value.length){
        case 0:
            throw new Error("unknown value");
        case 1:
            return value[0];
        case 2:
            throw value[1];
    }
}
function valueCopy(value) {
    return value.slice(0);
}
class Entry {
    constructor(fn){
        this.fn = fn;
        this.parents = new Set();
        this.childValues = new Map();
        // When this Entry has children that are dirty, this property becomes
        // a Set containing other Entry objects, borrowed from emptySetPool.
        // When the set becomes empty, it gets recycled back to emptySetPool.
        this.dirtyChildren = null;
        this.dirty = true;
        this.recomputing = false;
        this.value = [];
        this.deps = null;
        ++Entry.count;
    }
    peek() {
        if (this.value.length === 1 && !mightBeDirty(this)) {
            rememberParent(this);
            return this.value[0];
        }
    }
    // This is the most important method of the Entry API, because it
    // determines whether the cached this.value can be returned immediately,
    // or must be recomputed. The overall performance of the caching system
    // depends on the truth of the following observations: (1) this.dirty is
    // usually false, (2) this.dirtyChildren is usually null/empty, and thus
    // (3) valueGet(this.value) is usually returned without recomputation.
    recompute(args) {
        assert(!this.recomputing, "already recomputing");
        rememberParent(this);
        return mightBeDirty(this) ? reallyRecompute(this, args) : valueGet(this.value);
    }
    setDirty() {
        if (this.dirty) return;
        this.dirty = true;
        reportDirty(this);
        // We can go ahead and unsubscribe here, since any further dirty
        // notifications we receive will be redundant, and unsubscribing may
        // free up some resources, e.g. file watchers.
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["maybeUnsubscribe"])(this);
    }
    dispose() {
        this.setDirty();
        // Sever any dependency relationships with our own children, so those
        // children don't retain this parent Entry in their child.parents sets,
        // thereby preventing it from being fully garbage collected.
        forgetChildren(this);
        // Because this entry has been kicked out of the cache (in index.js),
        // we've lost the ability to find out if/when this entry becomes dirty,
        // whether that happens through a subscription, because of a direct call
        // to entry.setDirty(), or because one of its children becomes dirty.
        // Because of this loss of future information, we have to assume the
        // worst (that this entry might have become dirty very soon), so we must
        // immediately mark this entry's parents as dirty. Normally we could
        // just call entry.setDirty() rather than calling parent.setDirty() for
        // each parent, but that would leave this entry in parent.childValues
        // and parent.dirtyChildren, which would prevent the child from being
        // truly forgotten.
        eachParent(this, (parent, child)=>{
            parent.setDirty();
            forgetChild(parent, this);
        });
    }
    forget() {
        // The code that creates Entry objects in index.ts will replace this method
        // with one that actually removes the Entry from the cache, which will also
        // trigger the entry.dispose method.
        this.dispose();
    }
    dependOn(dep) {
        dep.add(this);
        if (!this.deps) {
            this.deps = emptySetPool.pop() || new Set();
        }
        this.deps.add(dep);
    }
    forgetDeps() {
        if (this.deps) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrayFromSet"])(this.deps).forEach((dep)=>dep.delete(this));
            this.deps.clear();
            emptySetPool.push(this.deps);
            this.deps = null;
        }
    }
}
Entry.count = 0;
function rememberParent(child) {
    const parent = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parentEntrySlot"].getValue();
    if (parent) {
        child.parents.add(parent);
        if (!parent.childValues.has(child)) {
            parent.childValues.set(child, []);
        }
        if (mightBeDirty(child)) {
            reportDirtyChild(parent, child);
        } else {
            reportCleanChild(parent, child);
        }
        return parent;
    }
}
function reallyRecompute(entry, args) {
    forgetChildren(entry);
    // Set entry as the parent entry while calling recomputeNewValue(entry).
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parentEntrySlot"].withValue(entry, recomputeNewValue, [
        entry,
        args
    ]);
    if (maybeSubscribe(entry, args)) {
        // If we successfully recomputed entry.value and did not fail to
        // (re)subscribe, then this Entry is no longer explicitly dirty.
        setClean(entry);
    }
    return valueGet(entry.value);
}
function recomputeNewValue(entry, args) {
    entry.recomputing = true;
    const { normalizeResult } = entry;
    let oldValueCopy;
    if (normalizeResult && entry.value.length === 1) {
        oldValueCopy = valueCopy(entry.value);
    }
    // Make entry.value an empty array, representing an unknown value.
    entry.value.length = 0;
    try {
        // If entry.fn succeeds, entry.value will become a normal Value.
        entry.value[0] = entry.fn.apply(null, args);
        // If we have a viable oldValueCopy to compare with the (successfully
        // recomputed) new entry.value, and they are not already === identical, give
        // normalizeResult a chance to pick/choose/reuse parts of oldValueCopy[0]
        // and/or entry.value[0] to determine the final cached entry.value.
        if (normalizeResult && oldValueCopy && !valueIs(oldValueCopy, entry.value)) {
            try {
                entry.value[0] = normalizeResult(entry.value[0], oldValueCopy[0]);
            } catch (_a) {
            // If normalizeResult throws, just use the newer value, rather than
            // saving the exception as entry.value[1].
            }
        }
    } catch (e) {
        // If entry.fn throws, entry.value will hold that exception.
        entry.value[1] = e;
    }
    // Either way, this line is always reached.
    entry.recomputing = false;
}
function mightBeDirty(entry) {
    return entry.dirty || !!(entry.dirtyChildren && entry.dirtyChildren.size);
}
function setClean(entry) {
    entry.dirty = false;
    if (mightBeDirty(entry)) {
        // This Entry may still have dirty children, in which case we can't
        // let our parents know we're clean just yet.
        return;
    }
    reportClean(entry);
}
function reportDirty(child) {
    eachParent(child, reportDirtyChild);
}
function reportClean(child) {
    eachParent(child, reportCleanChild);
}
function eachParent(child, callback) {
    const parentCount = child.parents.size;
    if (parentCount) {
        const parents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrayFromSet"])(child.parents);
        for(let i = 0; i < parentCount; ++i){
            callback(parents[i], child);
        }
    }
}
// Let a parent Entry know that one of its children may be dirty.
function reportDirtyChild(parent, child) {
    // Must have called rememberParent(child) before calling
    // reportDirtyChild(parent, child).
    assert(parent.childValues.has(child));
    assert(mightBeDirty(child));
    const parentWasClean = !mightBeDirty(parent);
    if (!parent.dirtyChildren) {
        parent.dirtyChildren = emptySetPool.pop() || new Set;
    } else if (parent.dirtyChildren.has(child)) {
        // If we already know this child is dirty, then we must have already
        // informed our own parents that we are dirty, so we can terminate
        // the recursion early.
        return;
    }
    parent.dirtyChildren.add(child);
    // If parent was clean before, it just became (possibly) dirty (according to
    // mightBeDirty), since we just added child to parent.dirtyChildren.
    if (parentWasClean) {
        reportDirty(parent);
    }
}
// Let a parent Entry know that one of its children is no longer dirty.
function reportCleanChild(parent, child) {
    // Must have called rememberChild(child) before calling
    // reportCleanChild(parent, child).
    assert(parent.childValues.has(child));
    assert(!mightBeDirty(child));
    const childValue = parent.childValues.get(child);
    if (childValue.length === 0) {
        parent.childValues.set(child, valueCopy(child.value));
    } else if (!valueIs(childValue, child.value)) {
        parent.setDirty();
    }
    removeDirtyChild(parent, child);
    if (mightBeDirty(parent)) {
        return;
    }
    reportClean(parent);
}
function removeDirtyChild(parent, child) {
    const dc = parent.dirtyChildren;
    if (dc) {
        dc.delete(child);
        if (dc.size === 0) {
            if (emptySetPool.length < POOL_TARGET_SIZE) {
                emptySetPool.push(dc);
            }
            parent.dirtyChildren = null;
        }
    }
}
// Removes all children from this entry and returns an array of the
// removed children.
function forgetChildren(parent) {
    if (parent.childValues.size > 0) {
        parent.childValues.forEach((_value, child)=>{
            forgetChild(parent, child);
        });
    }
    // Remove this parent Entry from any sets to which it was added by the
    // addToSet method.
    parent.forgetDeps();
    // After we forget all our children, this.dirtyChildren must be empty
    // and therefore must have been reset to null.
    assert(parent.dirtyChildren === null);
}
function forgetChild(parent, child) {
    child.parents.delete(parent);
    parent.childValues.delete(child);
    removeDirtyChild(parent, child);
}
function maybeSubscribe(entry, args) {
    if (typeof entry.subscribe === "function") {
        try {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["maybeUnsubscribe"])(entry); // Prevent double subscriptions.
            entry.unsubscribe = entry.subscribe.apply(null, args);
        } catch (e) {
            // If this Entry has a subscribe function and it threw an exception
            // (or an unsubscribe function it previously returned now throws),
            // return false to indicate that we were not able to subscribe (or
            // unsubscribe), and this Entry should remain dirty.
            entry.setDirty();
            return false;
        }
    }
    // Returning true indicates either that there was no entry.subscribe
    // function or that it succeeded.
    return true;
}
}),
"[project]/node_modules/@apollo/client/node_modules/optimism/lib/dep.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "dep",
    ()=>dep
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/node_modules/optimism/lib/context.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/node_modules/optimism/lib/helpers.js [app-client] (ecmascript)");
;
;
const EntryMethods = {
    setDirty: true,
    dispose: true,
    forget: true
};
function dep(options) {
    const depsByKey = new Map();
    const subscribe = options && options.subscribe;
    function depend(key) {
        const parent = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parentEntrySlot"].getValue();
        if (parent) {
            let dep = depsByKey.get(key);
            if (!dep) {
                depsByKey.set(key, dep = new Set);
            }
            parent.dependOn(dep);
            if (typeof subscribe === "function") {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["maybeUnsubscribe"])(dep);
                dep.unsubscribe = subscribe(key);
            }
        }
    }
    depend.dirty = function dirty(key, entryMethodName) {
        const dep = depsByKey.get(key);
        if (dep) {
            const m = entryMethodName && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasOwnProperty"].call(EntryMethods, entryMethodName) ? entryMethodName : "setDirty";
            // We have to use arrayFromSet(dep).forEach instead of dep.forEach,
            // because modifying a Set while iterating over it can cause elements in
            // the Set to be removed from the Set before they've been iterated over.
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrayFromSet"])(dep).forEach((entry)=>entry[m]());
            depsByKey.delete(key);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["maybeUnsubscribe"])(dep);
        }
    };
    return depend;
}
}),
"[project]/node_modules/@apollo/client/node_modules/optimism/lib/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "defaultMakeCacheKey",
    ()=>defaultMakeCacheKey,
    "wrap",
    ()=>wrap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$node_modules$2f40$wry$2f$trie$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/node_modules/optimism/node_modules/@wry/trie/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$wry$2f$caches$2f$lib$2f$strong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@wry/caches/lib/strong.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$entry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/node_modules/optimism/lib/entry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/node_modules/optimism/lib/context.js [app-client] (ecmascript) <locals>");
// A lighter-weight dependency, similar to OptimisticWrapperFunction, except
// with only one argument, no makeCacheKey, no wrapped function to recompute,
// and no result value. Useful for representing dependency leaves in the graph
// of computation. Subscriptions are supported.
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$dep$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/node_modules/optimism/lib/dep.js [app-client] (ecmascript)");
;
;
;
;
;
;
// The defaultMakeCacheKey function is remarkably powerful, because it gives
// a unique object for any shallow-identical list of arguments. If you need
// to implement a custom makeCacheKey function, you may find it helpful to
// delegate the final work to defaultMakeCacheKey, which is why we export it
// here. However, you may want to avoid defaultMakeCacheKey if your runtime
// does not support WeakMap, or you have the ability to return a string key.
// In those cases, just write your own custom makeCacheKey functions.
let defaultKeyTrie;
function defaultMakeCacheKey(...args) {
    const trie = defaultKeyTrie || (defaultKeyTrie = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$node_modules$2f40$wry$2f$trie$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trie"](typeof WeakMap === "function"));
    return trie.lookupArray(args);
}
;
;
const caches = new Set();
function wrap(originalFunction, { max = Math.pow(2, 16), keyArgs, makeCacheKey = defaultMakeCacheKey, normalizeResult, subscribe, cache: cacheOption = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$wry$2f$caches$2f$lib$2f$strong$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StrongCache"] } = Object.create(null)) {
    const cache = typeof cacheOption === "function" ? new cacheOption(max, (entry)=>entry.dispose()) : cacheOption;
    const optimistic = function() {
        const key = makeCacheKey.apply(null, keyArgs ? keyArgs.apply(null, arguments) : arguments);
        if (key === void 0) {
            return originalFunction.apply(null, arguments);
        }
        let entry = cache.get(key);
        if (!entry) {
            cache.set(key, entry = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$entry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Entry"](originalFunction));
            entry.normalizeResult = normalizeResult;
            entry.subscribe = subscribe;
            // Give the Entry the ability to trigger cache.delete(key), even though
            // the Entry itself does not know about key or cache.
            entry.forget = ()=>cache.delete(key);
        }
        const value = entry.recompute(Array.prototype.slice.call(arguments));
        // Move this entry to the front of the least-recently used queue,
        // since we just finished computing its value.
        cache.set(key, entry);
        caches.add(cache);
        // Clean up any excess entries in the cache, but only if there is no
        // active parent entry, meaning we're not in the middle of a larger
        // computation that might be flummoxed by the cleaning.
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$node_modules$2f$optimism$2f$lib$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parentEntrySlot"].hasValue()) {
            caches.forEach((cache)=>cache.clean());
            caches.clear();
        }
        return value;
    };
    Object.defineProperty(optimistic, "size", {
        get: ()=>cache.size,
        configurable: false,
        enumerable: false
    });
    Object.freeze(optimistic.options = {
        max,
        keyArgs,
        makeCacheKey,
        normalizeResult,
        subscribe,
        cache
    });
    function dirtyKey(key) {
        const entry = key && cache.get(key);
        if (entry) {
            entry.setDirty();
        }
    }
    optimistic.dirtyKey = dirtyKey;
    optimistic.dirty = function dirty() {
        dirtyKey(makeCacheKey.apply(null, arguments));
    };
    function peekKey(key) {
        const entry = key && cache.get(key);
        if (entry) {
            return entry.peek();
        }
    }
    optimistic.peekKey = peekKey;
    optimistic.peek = function peek() {
        return peekKey(makeCacheKey.apply(null, arguments));
    };
    function forgetKey(key) {
        return key ? cache.delete(key) : false;
    }
    optimistic.forgetKey = forgetKey;
    optimistic.forget = function forget() {
        return forgetKey(makeCacheKey.apply(null, arguments));
    };
    optimistic.makeCacheKey = makeCacheKey;
    optimistic.getKey = keyArgs ? function getKey() {
        return makeCacheKey.apply(null, keyArgs.apply(null, arguments));
    } : makeCacheKey;
    return Object.freeze(optimistic);
}
}),
"[project]/node_modules/isbot/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createIsbot",
    ()=>createIsbot,
    "createIsbotFromList",
    ()=>createIsbotFromList,
    "getPattern",
    ()=>getPattern,
    "isbot",
    ()=>isbot,
    "isbotMatch",
    ()=>isbotMatch,
    "isbotMatches",
    ()=>isbotMatches,
    "isbotNaive",
    ()=>isbotNaive,
    "isbotPattern",
    ()=>isbotPattern,
    "isbotPatterns",
    ()=>isbotPatterns,
    "list",
    ()=>list
]);
// src/patterns.json
var patterns_default = [
    " daum[ /]",
    " deusu/",
    " yadirectfetcher",
    "(?:^|[^g])news(?!sapphire)",
    "(?<! (?:channel/|google/))google(?!(app|/google| pixel))",
    "(?<! cu)bots?(?:\\b|_)",
    "(?<!(?:lib))http",
    "(?<![hg]m)score",
    "@[a-z][\\w-]+\\.",
    "\\(\\)",
    "\\.com\\b",
    "\\btime/",
    "\\|",
    "^<",
    "^[\\w \\.\\-\\(?:\\):%]+(?:/v?\\d+(?:\\.\\d+)?(?:\\.\\d{1,10})*?)?(?:,|$)",
    "^[^ ]{50,}$",
    "^\\d+\\b",
    "^\\w*search\\b",
    "^\\w+/[\\w\\(\\)]*$",
    "^active",
    "^ad muncher",
    "^amaya",
    "^avsdevicesdk/",
    "^biglotron",
    "^bot",
    "^bw/",
    "^clamav[ /]",
    "^client/",
    "^cobweb/",
    "^custom",
    "^ddg[_-]android",
    "^discourse",
    "^dispatch/\\d",
    "^downcast/",
    "^duckduckgo",
    "^email",
    "^facebook",
    "^getright/",
    "^gozilla/",
    "^hobbit",
    "^hotzonu",
    "^hwcdn/",
    "^igetter/",
    "^jeode/",
    "^jetty/",
    "^jigsaw",
    "^microsoft bits",
    "^movabletype",
    "^mozilla/\\d\\.\\d\\s[\\w\\.-]+$",
    "^mozilla/\\d\\.\\d\\s\\(compatible;?(?:\\s\\w+\\/\\d+\\.\\d+)?\\)$",
    "^navermailapp",
    "^netsurf",
    "^offline",
    "^openai/",
    "^owler",
    "^php",
    "^postman",
    "^python",
    "^rank",
    "^read",
    "^reed",
    "^rest",
    "^rss",
    "^snapchat",
    "^space bison",
    "^svn",
    "^swcd ",
    "^taringa",
    "^thumbor/",
    "^track",
    "^w3c",
    "^webbandit/",
    "^webcopier",
    "^wget",
    "^whatsapp",
    "^wordpress",
    "^xenu link sleuth",
    "^yahoo",
    "^yandex",
    "^zdm/\\d",
    "^zoom marketplace/",
    "^{{.*}}$",
    "adscanner/",
    "analyzer",
    "archive",
    "ask jeeves/teoma",
    "audit",
    "bit\\.ly/",
    "bluecoat drtr",
    "browsex",
    "burpcollaborator",
    "capture",
    "catch",
    "check\\b",
    "checker",
    "chrome-lighthouse",
    "chromeframe",
    "classifier",
    "cloudflare",
    "convertify",
    "cookiehubscan",
    "crawl",
    "cypress/",
    "dareboost",
    "datanyze",
    "dejaclick",
    "detect",
    "dmbrowser",
    "download",
    "evc-batch/",
    "exaleadcloudview",
    "feed",
    "firephp",
    "functionize",
    "gomezagent",
    "headless",
    "httrack",
    "hubspot marketing grader",
    "hydra",
    "ibisbrowser",
    "infrawatch",
    "insight",
    "inspect",
    "iplabel",
    "ips-agent",
    "java(?!;)",
    "jsjcw_scanner",
    "library",
    "linkcheck",
    "mail\\.ru/",
    "manager",
    "measure",
    "neustar wpm",
    "node",
    "nutch",
    "offbyone",
    "optimize",
    "pageburst",
    "pagespeed",
    "parser",
    "perl",
    "phantomjs",
    "pingdom",
    "powermarks",
    "preview",
    "proxy",
    "ptst[ /]\\d",
    "retriever",
    "rexx;",
    "rigor",
    "rss\\b",
    "scanner\\.",
    "scrape",
    "server",
    "sogou",
    "sparkler/",
    "speedcurve",
    "spider",
    "splash",
    "statuscake",
    "supercleaner",
    "synapse",
    "synthetic",
    "tools",
    "torrent",
    "transcoder",
    "url",
    "validator",
    "virtuoso",
    "wappalyzer",
    "webglance",
    "webkit2png",
    "whatcms/",
    "zgrab"
];
// src/pattern.ts
var fullPattern = " daum[ /]| deusu/| yadirectfetcher|(?:^|[^g])news(?!sapphire)|(?<! (?:channel/|google/))google(?!(app|/google| pixel))|(?<! cu)bots?(?:\\b|_)|(?<!(?:lib))http|(?<![hg]m)score|@[a-z][\\w-]+\\.|\\(\\)|\\.com\\b|\\btime/|\\||^<|^[\\w \\.\\-\\(?:\\):%]+(?:/v?\\d+(?:\\.\\d+)?(?:\\.\\d{1,10})*?)?(?:,|$)|^[^ ]{50,}$|^\\d+\\b|^\\w*search\\b|^\\w+/[\\w\\(\\)]*$|^active|^ad muncher|^amaya|^avsdevicesdk/|^biglotron|^bot|^bw/|^clamav[ /]|^client/|^cobweb/|^custom|^ddg[_-]android|^discourse|^dispatch/\\d|^downcast/|^duckduckgo|^email|^facebook|^getright/|^gozilla/|^hobbit|^hotzonu|^hwcdn/|^igetter/|^jeode/|^jetty/|^jigsaw|^microsoft bits|^movabletype|^mozilla/\\d\\.\\d\\s[\\w\\.-]+$|^mozilla/\\d\\.\\d\\s\\(compatible;?(?:\\s\\w+\\/\\d+\\.\\d+)?\\)$|^navermailapp|^netsurf|^offline|^openai/|^owler|^php|^postman|^python|^rank|^read|^reed|^rest|^rss|^snapchat|^space bison|^svn|^swcd |^taringa|^thumbor/|^track|^w3c|^webbandit/|^webcopier|^wget|^whatsapp|^wordpress|^xenu link sleuth|^yahoo|^yandex|^zdm/\\d|^zoom marketplace/|^{{.*}}$|adscanner/|analyzer|archive|ask jeeves/teoma|audit|bit\\.ly/|bluecoat drtr|browsex|burpcollaborator|capture|catch|check\\b|checker|chrome-lighthouse|chromeframe|classifier|cloudflare|convertify|cookiehubscan|crawl|cypress/|dareboost|datanyze|dejaclick|detect|dmbrowser|download|evc-batch/|exaleadcloudview|feed|firephp|functionize|gomezagent|headless|httrack|hubspot marketing grader|hydra|ibisbrowser|infrawatch|insight|inspect|iplabel|ips-agent|java(?!;)|jsjcw_scanner|library|linkcheck|mail\\.ru/|manager|measure|neustar wpm|node|nutch|offbyone|optimize|pageburst|pagespeed|parser|perl|phantomjs|pingdom|powermarks|preview|proxy|ptst[ /]\\d|retriever|rexx;|rigor|rss\\b|scanner\\.|scrape|server|sogou|sparkler/|speedcurve|spider|splash|statuscake|supercleaner|synapse|synthetic|tools|torrent|transcoder|url|validator|virtuoso|wappalyzer|webglance|webkit2png|whatcms/|zgrab";
// src/index.ts
var naivePattern = /bot|crawl|http|lighthouse|scan|search|spider/i;
var pattern;
function getPattern() {
    if (pattern instanceof RegExp) {
        return pattern;
    }
    try {
        pattern = new RegExp(fullPattern, "i");
    } catch (error) {
        pattern = naivePattern;
    }
    return pattern;
}
var list = patterns_default;
var isbotNaive = (userAgent)=>Boolean(userAgent) && naivePattern.test(userAgent);
function isbot(userAgent) {
    return Boolean(userAgent) && getPattern().test(userAgent);
}
var createIsbot = (customPattern)=>(userAgent)=>Boolean(userAgent) && customPattern.test(userAgent);
var createIsbotFromList = (list2)=>{
    const pattern2 = new RegExp(list2.join("|"), "i");
    return (userAgent)=>Boolean(userAgent) && pattern2.test(userAgent);
};
var isbotMatch = (userAgent)=>{
    var _a, _b;
    return (_b = (_a = userAgent == null ? void 0 : userAgent.match(getPattern())) == null ? void 0 : _a[0]) != null ? _b : null;
};
var isbotMatches = (userAgent)=>list.map((part)=>{
        var _a;
        return (_a = userAgent == null ? void 0 : userAgent.match(new RegExp(part, "i"))) == null ? void 0 : _a[0];
    }).filter(Boolean);
var isbotPattern = (userAgent)=>{
    var _a;
    return userAgent ? (_a = list.find((pattern2)=>new RegExp(pattern2, "i").test(userAgent))) != null ? _a : null : null;
};
var isbotPatterns = (userAgent)=>userAgent ? list.filter((pattern2)=>new RegExp(pattern2, "i").test(userAgent)) : [];
;
}),
"[project]/node_modules/@apollo/client-react-streaming/dist/index.cc.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SimulatePreloadedQuery",
    ()=>SimulatePreloadedQuery,
    "built_for_browser",
    ()=>built_for_browser
]);
// src/index.cc.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
var RealSimulatePreloadedQuery;
var SimulatePreloadedQuery = (props)=>{
    if (!RealSimulatePreloadedQuery) {
        RealSimulatePreloadedQuery = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lazy"](()=>__turbopack_context__.A("[project]/node_modules/@apollo/client-react-streaming/dist/SimulatePreloadedQuery.cc.js [app-client] (ecmascript, async loader)"));
    }
    return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](RealSimulatePreloadedQuery, {
        ...props
    });
};
;
const built_for_browser = true;
}),
"[project]/node_modules/@apollo/client-react-streaming/dist/stream-utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "JSONDecodeStream",
    ()=>JSONDecodeStream,
    "JSONEncodeStream",
    ()=>JSONEncodeStream,
    "built_for_browser",
    ()=>built_for_browser
]);
// src/stream-utils/JSONTransformStreams.tsx
var JSONEncodeStream = class extends TransformStream {
    constructor(){
        super({
            transform (chunk, controller) {
                controller.enqueue(JSON.stringify(chunk));
            }
        });
    }
};
var JSONDecodeStream = class extends TransformStream {
    constructor(){
        super({
            transform (chunk, controller) {
                if (typeof chunk !== "string") {
                    chunk = new TextDecoder().decode(chunk);
                }
                controller.enqueue(JSON.parse(chunk));
            }
        });
    }
};
const built_for_browser = true;
;
}),
"[project]/node_modules/@apollo/client-react-streaming/dist/index.browser.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ApolloClient",
    ()=>ApolloClient,
    "DataTransportContext",
    ()=>DataTransportContext,
    "DebounceMultipartResponsesLink",
    ()=>AccumulateMultipartResponsesLink,
    "InMemoryCache",
    ()=>InMemoryCache,
    "ReadFromReadableStreamLink",
    ()=>ReadFromReadableStreamLink,
    "RemoveMultipartDirectivesLink",
    ()=>RemoveMultipartDirectivesLink,
    "SSRMultipartLink",
    ()=>SSRMultipartLink,
    "TeeToReadableStreamLink",
    ()=>TeeToReadableStreamLink,
    "WrapApolloProvider",
    ()=>WrapApolloProvider,
    "built_for_browser",
    ()=>built_for_browser,
    "createTransportedQueryPreloader",
    ()=>createTransportedQueryPreloader,
    "isTransportedQueryRef",
    ()=>isTransportedQueryRef,
    "readFromReadableStream",
    ()=>readFromReadableStream,
    "resetApolloSingletons",
    ()=>resetApolloSingletons,
    "reviveTransportedQueryRef",
    ()=>reviveTransportedQueryRef,
    "skipDataTransport",
    ()=>skipDataTransport,
    "teeToReadableStream",
    ()=>teeToReadableStream,
    "useWrapTransportedQueryRef",
    ()=>useWrapTransportedQueryRef
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$core$2f$ApolloLink$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/link/core/ApolloLink.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$cache$2f$inmemory$2f$inMemoryCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/cache/inmemory/inMemoryCache.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zen$2d$observable$2d$ts$2f$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zen-observable-ts/module.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$graphql$2d$tag$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/graphql-tag/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$core$2f$ApolloClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/core/ApolloClient.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$utilities$2f$graphql$2f$directives$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/utilities/graphql/directives.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$utilities$2f$graphql$2f$transform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/utilities/graphql/transform.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$utilities$2f$common$2f$incrementalResult$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/utilities/common/incrementalResult.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$utilities$2f$graphql$2f$print$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/utilities/graphql/print.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ts$2d$invariant$2f$lib$2f$invariant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/ts-invariant/lib/invariant.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$wry$2f$equality$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@wry/equality/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$internal$2f$cache$2f$getSuspenseCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/internal/cache/getSuspenseCache.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$internal$2f$cache$2f$QueryReference$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/internal/cache/QueryReference.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useApolloClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/hooks/useApolloClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$context$2f$ApolloProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/react/context/ApolloProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$graphql$2f$utilities$2f$stripIgnoredCharacters$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/graphql/utilities/stripIgnoredCharacters.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$utilities$2f$common$2f$canonicalStringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client/utilities/common/canonicalStringify.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$react$2d$streaming$2f$dist$2f$stream$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client-react-streaming/dist/stream-utils.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
// src/AccumulateMultipartResponsesLink.ts
var AccumulateMultipartResponsesLink = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$core$2f$ApolloLink$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApolloLink"] {
    maxDelay;
    constructor(config){
        super();
        this.maxDelay = config.cutoffDelay;
    }
    request(operation, forward) {
        if (!forward) {
            throw new Error("This is not a terminal link!");
        }
        const operationContainsMultipartDirectives = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$utilities$2f$graphql$2f$directives$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasDirectives"])([
            "defer"
        ], operation.query);
        const upstream = forward(operation);
        if (!operationContainsMultipartDirectives) return upstream;
        const maxDelay = this.maxDelay;
        let accumulatedData, maxDelayTimeout;
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zen$2d$observable$2d$ts$2f$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Observable"]((subscriber)=>{
            const upstreamSubscription = upstream.subscribe({
                next: (result)=>{
                    if (accumulatedData) {
                        if (accumulatedData.data && "incremental" in result) {
                            accumulatedData.data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$utilities$2f$common$2f$incrementalResult$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeIncrementalData"])(accumulatedData.data, result);
                        } else if (result.data) {
                            accumulatedData.data = result.data;
                        }
                        if (result.errors) {
                            accumulatedData.errors = [
                                ...accumulatedData.errors || [],
                                ...result.errors || []
                            ];
                        }
                        if (result.extensions) accumulatedData.extensions = {
                            ...accumulatedData.extensions,
                            ...result.extensions
                        };
                    } else {
                        accumulatedData = result;
                    }
                    if (!maxDelay) {
                        flushAccumulatedData();
                    } else if (!maxDelayTimeout) {
                        maxDelayTimeout = setTimeout(flushAccumulatedData, maxDelay);
                    }
                },
                error: (error)=>{
                    if (maxDelayTimeout) clearTimeout(maxDelayTimeout);
                    subscriber.error(error);
                },
                complete: ()=>{
                    if (maxDelayTimeout) {
                        clearTimeout(maxDelayTimeout);
                        flushAccumulatedData();
                    }
                    subscriber.complete();
                }
            });
            function flushAccumulatedData() {
                subscriber.next(accumulatedData);
                subscriber.complete();
                upstreamSubscription.unsubscribe();
            }
            return function cleanUp() {
                clearTimeout(maxDelayTimeout);
                upstreamSubscription.unsubscribe();
            };
        });
    }
};
function getDirectiveArgumentValue(directive, argument) {
    return directive.arguments?.find((arg)=>arg.name.value === argument)?.value;
}
var RemoveMultipartDirectivesLink = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$core$2f$ApolloLink$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApolloLink"] {
    stripDirectives = [];
    constructor(config){
        super();
        if (config.stripDefer !== false) this.stripDirectives.push("defer");
    }
    request(operation, forward) {
        if (!forward) {
            throw new Error("This is not a terminal link!");
        }
        const { query } = operation;
        let modifiedQuery = query;
        modifiedQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$utilities$2f$graphql$2f$transform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeDirectivesFromDocument"])(this.stripDirectives.map((directive)=>({
                test (node) {
                    let shouldStrip = node.kind === "Directive" && node.name.value === directive;
                    const label = getDirectiveArgumentValue(node, "label");
                    if (label?.kind === "StringValue" && label.value.startsWith("SsrDontStrip")) {
                        shouldStrip = false;
                    }
                    return shouldStrip;
                },
                remove: true
            })).concat({
            test (node) {
                if (node.kind !== "Directive") return false;
                const label = getDirectiveArgumentValue(node, "label");
                return label?.kind === "StringValue" && label.value.startsWith("SsrStrip");
            },
            remove: true
        }), modifiedQuery);
        if (modifiedQuery === null) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zen$2d$observable$2d$ts$2f$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Observable"].of({});
        }
        operation.query = modifiedQuery;
        return forward(operation);
    }
};
var SSRMultipartLink = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$core$2f$ApolloLink$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApolloLink"] {
    constructor(config = {}){
        const combined = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$core$2f$ApolloLink$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApolloLink"].from([
            new RemoveMultipartDirectivesLink({
                stripDefer: config.stripDefer
            }),
            new AccumulateMultipartResponsesLink({
                cutoffDelay: config.cutoffDelay || 0
            })
        ]);
        super(combined.request);
    }
};
// src/bundleInfo.ts
var bundle = {
    pkg: "@apollo/client-react-streaming"
};
var sourceSymbol = Symbol.for("apollo.source_package");
// src/DataTransportAbstraction/WrappedInMemoryCache.tsx
var InMemoryCache = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$cache$2f$inmemory$2f$inMemoryCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InMemoryCache"] {
    /**
   * Information about the current package and it's export names, for use in error messages.
   *
   * @internal
   */ static info = bundle;
    [sourceSymbol];
    constructor(config){
        super(config);
        const info = this.constructor.info;
        this[sourceSymbol] = `${info.pkg}:InMemoryCache`;
    }
};
var DataTransportContext = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
var CLEAN = {};
function useTransportValue(value) {
    const dataTransport = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(DataTransportContext);
    if (!dataTransport) throw new Error("useTransportValue must be used within a streaming-specific ApolloProvider");
    const valueRef = dataTransport.useStaticValueRef(value);
    const whichResult = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])({
        "useTransportValue.useSyncExternalStore[whichResult]": ()=>({
                "useTransportValue.useSyncExternalStore[whichResult]": ()=>{}
            })["useTransportValue.useSyncExternalStore[whichResult]"]
    }["useTransportValue.useSyncExternalStore[whichResult]"], {
        "useTransportValue.useSyncExternalStore[whichResult]": ()=>0 /* client */ 
    }["useTransportValue.useSyncExternalStore[whichResult]"], {
        "useTransportValue.useSyncExternalStore[whichResult]": ()=>valueRef.current === CLEAN ? 0 /* client */  : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$wry$2f$equality$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["equal"])(value, valueRef.current) ? 0 /* client */  : 1 /* server */ 
    }["useTransportValue.useSyncExternalStore[whichResult]"]);
    if (whichResult === 0 /* client */ ) {
        valueRef.current = CLEAN;
    }
    return whichResult === 1 /* server */  ? valueRef.current : value;
}
var teeToReadableStreamKey = Symbol.for("apollo.tee.readableStreamController");
var readFromReadableStreamKey = Symbol.for("apollo.read.readableStream");
function teeToReadableStream(onLinkHit, context) {
    return Object.assign(context, {
        [teeToReadableStreamKey]: onLinkHit
    });
}
function readFromReadableStream(readableStream, context) {
    return Object.assign(context, {
        [readFromReadableStreamKey]: readableStream
    });
}
var TeeToReadableStreamLink = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$core$2f$ApolloLink$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApolloLink"] {
    constructor(){
        super((operation, forward)=>{
            const context = operation.getContext();
            const onLinkHit = context[teeToReadableStreamKey];
            if (onLinkHit) {
                const controller = onLinkHit();
                const tryClose = ()=>{
                    try {
                        controller.close();
                    } catch  {}
                };
                return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zen$2d$observable$2d$ts$2f$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Observable"]((observer)=>{
                    const subscription = forward(operation).subscribe({
                        next (result) {
                            controller.enqueue({
                                type: "next",
                                value: result
                            });
                            observer.next(result);
                        },
                        error (error) {
                            controller.enqueue({
                                type: "error"
                            });
                            tryClose();
                            observer.error(error);
                        },
                        complete () {
                            controller.enqueue({
                                type: "completed"
                            });
                            tryClose();
                            observer.complete();
                        }
                    });
                    return ()=>{
                        tryClose();
                        subscription.unsubscribe();
                    };
                });
            }
            return forward(operation);
        });
    }
};
var ReadFromReadableStreamLink = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$core$2f$ApolloLink$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApolloLink"] {
    constructor(){
        super((operation, forward)=>{
            const context = operation.getContext();
            const eventSteam = context[readFromReadableStreamKey];
            if (eventSteam) {
                return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zen$2d$observable$2d$ts$2f$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Observable"]((observer)=>{
                    let aborted = false;
                    const reader = (()=>{
                        try {
                            return eventSteam.getReader();
                        } catch  {}
                    })();
                    if (!reader) {
                        const subscription = forward(operation).subscribe(observer);
                        return ()=>subscription.unsubscribe();
                    }
                    consume(reader);
                    let onAbort = ()=>{
                        aborted = true;
                        reader.cancel();
                    };
                    return ()=>onAbort();
                    //TURBOPACK unreachable
                    ;
                    async function consume(reader2) {
                        let event = undefined;
                        while(!aborted && !event?.done){
                            event = await reader2.read();
                            if (aborted) break;
                            if (event.value) {
                                switch(event.value.type){
                                    case "next":
                                        observer.next(event.value.value);
                                        break;
                                    case "completed":
                                        observer.complete();
                                        break;
                                    case "error":
                                        {
                                            onAbort();
                                            const subscription = forward(operation).subscribe(observer);
                                            onAbort = ()=>subscription.unsubscribe();
                                        }
                                        break;
                                }
                            }
                        }
                    }
                });
            }
            return forward(operation);
        });
    }
};
function serializeOptions(options) {
    return {
        ...options,
        query: printMinified(options.query)
    };
}
function deserializeOptions(options) {
    return {
        ...options,
        // `gql` memoizes results, but based on the input string.
        // We parse-stringify-parse here to ensure that our minified query
        // has the best chance of being the referential same query as the one used in
        // client-side code.
        query: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$graphql$2d$tag$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gql"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$utilities$2f$graphql$2f$print$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["print"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$graphql$2d$tag$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gql"])(options.query)))
    };
}
function printMinified(query) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$graphql$2f$utilities$2f$stripIgnoredCharacters$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stripIgnoredCharacters"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$utilities$2f$graphql$2f$print$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["print"])(query));
}
function getInjectableEventStream() {
    let controller;
    const stream = new ReadableStream({
        start (c) {
            controller = c;
        }
    });
    return [
        controller,
        stream
    ];
}
function createTransportedQueryPreloader(client) {
    return (...[query, options])=>{
        options = {
            ...options
        };
        delete options.returnPartialData;
        delete options.nextFetchPolicy;
        delete options.pollInterval;
        const [controller, stream] = getInjectableEventStream();
        client.query({
            query,
            ...options,
            // ensure that this query makes it to the network
            fetchPolicy: "no-cache",
            context: skipDataTransport(teeToReadableStream(()=>controller, {
                ...options?.context,
                // we want to do this even if the query is already running for another reason
                queryDeduplication: false
            }))
        }).catch(()=>{});
        return createTransportedQueryRef(query, options, crypto.randomUUID(), stream);
    };
}
function createTransportedQueryRef(query, options, queryKey, stream) {
    return {
        $__apollo_queryRef: {
            options: sanitizeForTransport(serializeOptions({
                query,
                ...options
            })),
            queryKey,
            stream: stream.pipeThrough(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$react$2d$streaming$2f$dist$2f$stream$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JSONEncodeStream"]())
        }
    };
}
var hydrationCache = /* @__PURE__ */ new WeakMap();
function reviveTransportedQueryRef(queryRef, client) {
    const { $__apollo_queryRef: { options, stream, queryKey } } = queryRef;
    if (!hydrationCache.has(queryRef)) {
        const hydratedOptions = deserializeOptions(options);
        const cacheKey = [
            hydratedOptions.query,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$utilities$2f$common$2f$canonicalStringify$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canonicalStringify"])(hydratedOptions.variables),
            queryKey
        ];
        hydrationCache.set(queryRef, {
            cacheKey
        });
        const internalQueryRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$internal$2f$cache$2f$getSuspenseCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSuspenseCache"])(client).getQueryRef(cacheKey, ()=>client.watchQuery({
                ...hydratedOptions,
                fetchPolicy: "network-only",
                context: skipDataTransport(readFromReadableStream(stream.pipeThrough(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$react$2d$streaming$2f$dist$2f$stream$2d$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JSONDecodeStream"]()), {
                    ...hydratedOptions.context,
                    queryDeduplication: true
                }))
            }));
        Object.assign(queryRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$internal$2f$cache$2f$QueryReference$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wrapQueryRef"])(internalQueryRef));
    }
}
function isTransportedQueryRef(queryRef) {
    return !!(queryRef && queryRef.$__apollo_queryRef);
}
function useWrapTransportedQueryRef(queryRef) {
    const client = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$hooks$2f$useApolloClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApolloClient"])();
    let cacheKey;
    let isTransported;
    if (isTransported = isTransportedQueryRef(queryRef)) {
        reviveTransportedQueryRef(queryRef, client);
        cacheKey = hydrationCache.get(queryRef)?.cacheKey;
    }
    const unwrapped = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$internal$2f$cache$2f$QueryReference$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unwrapQueryRef"])(queryRef);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useWrapTransportedQueryRef.useEffect": ()=>{
            if (!isTransported) return;
            if (cacheKey) {
                if (unwrapped.disposed) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$internal$2f$cache$2f$getSuspenseCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSuspenseCache"])(client).add(cacheKey, unwrapped);
                }
            }
        }
    }["useWrapTransportedQueryRef.useEffect"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useWrapTransportedQueryRef.useEffect": ()=>{
            if (isTransported) {
                return unwrapped.softRetain();
            }
        }
    }["useWrapTransportedQueryRef.useEffect"], [
        isTransported,
        unwrapped
    ]);
    return queryRef;
}
function sanitizeForTransport(value) {
    return JSON.parse(JSON.stringify(value));
}
var hookWrappers = {
    useFragment (orig_useFragment) {
        return wrap(orig_useFragment, [
            "data",
            "complete",
            "missing"
        ]);
    },
    useQuery (orig_useQuery) {
        return wrap(orig_useQuery, [
            "data",
            "loading",
            "networkStatus",
            "called"
        ]);
    },
    useSuspenseQuery (orig_useSuspenseQuery) {
        return wrap(orig_useSuspenseQuery, [
            "data",
            "networkStatus"
        ]);
    },
    useReadQuery (orig_useReadQuery) {
        return wrap((queryRef)=>{
            return orig_useReadQuery(useWrapTransportedQueryRef(queryRef));
        }, [
            "data",
            "networkStatus"
        ]);
    },
    useQueryRefHandlers (orig_useQueryRefHandlers) {
        return wrap((queryRef)=>{
            return orig_useQueryRefHandlers(useWrapTransportedQueryRef(queryRef));
        }, []);
    },
    useSuspenseFragment (orig_useSuspenseFragment) {
        return wrap(orig_useSuspenseFragment, [
            "data"
        ]);
    }
};
function wrap(useFn, transportKeys) {
    return (...args)=>{
        const result = useFn(...args);
        if (transportKeys.length == 0) {
            return result;
        }
        const forTransport = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
            "wrap.useMemo[forTransport]": ()=>{
                const transport = {};
                for (const key of transportKeys){
                    transport[key] = result[key];
                }
                return transport;
            }
        }["wrap.useMemo[forTransport]"], [
            result
        ]);
        const transported = useTransportValue(forTransport);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
            "wrap.useMemo": ()=>({
                    ...result,
                    ...transported
                })
        }["wrap.useMemo"], [
            result,
            transported
        ]);
    };
}
// src/assertInstance.ts
function assertInstance(value, info, name) {
    if (value[sourceSymbol] !== `${info.pkg}:${name}`) {
        throw new Error(`When using \`${name}\` in streaming SSR, you must use the \`${name}\` export provided by \`"${info.pkg}"\`.`);
    }
}
// src/DataTransportAbstraction/WrappedApolloClient.tsx
function getQueryManager(client) {
    return client["queryManager"];
}
var wrappers = Symbol.for("apollo.hook.wrappers");
var ApolloClientBase = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$core$2f$ApolloClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ApolloClient"] {
    /**
   * Information about the current package and it's export names, for use in error messages.
   *
   * @internal
   */ static info = bundle;
    [sourceSymbol];
    constructor(options){
        const warnings = [];
        if ("ssrMode" in options) {
            delete options.ssrMode;
            warnings.push("The `ssrMode` option is not supported in %s. Please remove it from your %s constructor options.");
        }
        if ("ssrForceFetchDelay" in options) {
            delete options.ssrForceFetchDelay;
            warnings.push("The `ssrForceFetchDelay` option is not supported in %s. Please remove it from your %s constructor options.");
        }
        super(options);
        const info = this.constructor.info;
        this[sourceSymbol] = `${info.pkg}:ApolloClient`;
        for (const warning of warnings){
            console.warn(warning, info.pkg, "ApolloClient");
        }
        assertInstance(this.cache, info, "InMemoryCache");
        this.setLink(this.link);
    }
    setLink(newLink) {
        super.setLink.call(this, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$link$2f$core$2f$ApolloLink$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApolloLink"].from([
            new ReadFromReadableStreamLink(),
            new TeeToReadableStreamLink(),
            newLink
        ]));
    }
};
var ApolloClientClientBaseImpl = class extends ApolloClientBase {
    constructor(options){
        super(options);
        this.onQueryStarted = this.onQueryStarted.bind(this);
        getQueryManager(this)[wrappers] = hookWrappers;
    }
    simulatedStreamingQueries = /* @__PURE__ */ new Map();
    onQueryStarted({ options, id }) {
        const hydratedOptions = deserializeOptions(options);
        const [controller, stream] = getInjectableEventStream();
        const queryManager = getQueryManager(this);
        const queryId = queryManager.generateQueryId();
        queryManager.fetchQuery(queryId, {
            ...hydratedOptions,
            query: queryManager.transform(hydratedOptions.query),
            fetchPolicy: "network-only",
            context: skipDataTransport(readFromReadableStream(stream, {
                ...hydratedOptions.context,
                queryDeduplication: true
            }))
        }).finally(()=>queryManager.removeQuery(queryId));
        this.simulatedStreamingQueries.set(id, {
            controller,
            options: hydratedOptions
        });
    }
    onQueryProgress = (event)=>{
        const queryInfo = this.simulatedStreamingQueries.get(event.id);
        if (!queryInfo) return;
        if (event.type === "error" || event.type === "next" && event.value.errors) {
            this.simulatedStreamingQueries.delete(event.id);
            {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ts$2d$invariant$2f$lib$2f$invariant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"].debug("Query failed on server, rerunning in browser:", queryInfo.options);
                this.rerunSimulatedQuery(queryInfo);
            }
        } else if (event.type === "completed") {
            this.simulatedStreamingQueries.delete(event.id);
            queryInfo.controller.enqueue(event);
        } else if (event.type === "next") {
            queryInfo.controller.enqueue(event);
        }
    };
    /**
   * Can be called when the stream closed unexpectedly while there might still be unresolved
   * simulated server-side queries going on.
   * Those queries will be cancelled and then re-run in the browser.
   */ rerunSimulatedQueries = ()=>{
        for (const [id, queryInfo] of this.simulatedStreamingQueries){
            this.simulatedStreamingQueries.delete(id);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ts$2d$invariant$2f$lib$2f$invariant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"].debug("streaming connection closed before server query could be fully transported, rerunning:", queryInfo.options);
            this.rerunSimulatedQuery(queryInfo);
        }
    };
    rerunSimulatedQuery = (queryInfo)=>{
        const queryManager = getQueryManager(this);
        const queryId = queryManager.generateQueryId();
        queryManager.fetchQuery(queryId, {
            ...queryInfo.options,
            fetchPolicy: "no-cache",
            query: queryManager.transform(queryInfo.options.query),
            context: skipDataTransport(teeToReadableStream(()=>queryInfo.controller, {
                ...queryInfo.options.context,
                queryDeduplication: false
            }))
        }).finally(()=>queryManager.removeQuery(queryId));
    };
};
var skipDataTransportKey = Symbol.for("apollo.dataTransport.skip");
function skipDataTransport(context) {
    return Object.assign(context, {
        [skipDataTransportKey]: true
    });
}
var ApolloClientBrowserImpl = class extends ApolloClientClientBaseImpl {
};
var ApolloClientImplementation = ApolloClientBrowserImpl;
var ApolloClient = class extends ApolloClientImplementation {
};
// src/DataTransportAbstraction/symbols.ts
var ApolloClientSingleton = /* @__PURE__ */ Symbol.for("ApolloClientSingleton");
// src/DataTransportAbstraction/testHelpers.ts
function resetApolloSingletons() {
    delete window[ApolloClientSingleton];
}
function WrapApolloProvider(TransportProvider) {
    const WrappedApolloProvider3 = ({ makeClient, children, ...extraProps })=>{
        const clientRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(undefined);
        if (!clientRef.current) {
            {
                clientRef.current = window[ApolloClientSingleton] ??= makeClient();
            }
            assertInstance(clientRef.current, WrappedApolloProvider3.info, "ApolloClient");
        }
        return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2f$react$2f$context$2f$ApolloProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApolloProvider"], {
            client: clientRef.current
        }, /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(TransportProvider, {
            onQueryEvent: (event)=>event.type === "started" ? clientRef.current.onQueryStarted(event) : clientRef.current.onQueryProgress(event),
            rerunSimulatedQueries: clientRef.current.rerunSimulatedQueries,
            registerDispatchRequestStarted: clientRef.current.watchQueryQueue?.register,
            ...extraProps
        }, children));
    };
    WrappedApolloProvider3.info = bundle;
    return WrappedApolloProvider3;
}
const built_for_browser = true;
;
}),
"[project]/node_modules/@apollo/client-react-streaming/dist/manual-transport.browser.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildManualDataTransport",
    ()=>buildManualDataTransport,
    "built_for_browser",
    ()=>built_for_browser,
    "registerLateInitializingQueue",
    ()=>registerLateInitializingQueue,
    "resetManualSSRApolloSingletons",
    ()=>resetManualSSRApolloSingletons
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$react$2d$streaming$2f$dist$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client-react-streaming/dist/index.browser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ts$2d$invariant$2f$lib$2f$invariant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/ts-invariant/lib/invariant.js [app-client] (ecmascript)");
;
;
;
// src/ManualDataTransport/ManualDataTransport.tsx
// src/ManualDataTransport/ApolloRehydrateSymbols.tsx
var ApolloSSRDataTransport = /* @__PURE__ */ Symbol.for("ApolloSSRDataTransport");
var ApolloHookRehydrationCache = /* @__PURE__ */ Symbol.for("apollo.hookRehydrationCache");
// src/ManualDataTransport/lateInitializingQueue.ts
function registerLateInitializingQueue(key, callback) {
    const previousData = window[key] || [];
    if (Array.isArray(previousData)) {
        window[key] = {
            push: (...data)=>{
                for (const value of data){
                    callback(value);
                }
            }
        };
        window[key].push(...previousData);
    }
}
function registerDataTransport({ onQueryEvent, onRehydrate, revive: revive2 }) {
    registerLateInitializingQueue(ApolloSSRDataTransport, (data)=>{
        const parsed = revive2(data);
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ts$2d$invariant$2f$lib$2f$invariant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["invariant"].debug(`received data from the server:`, parsed);
        onRehydrate(parsed.rehydrate);
        for (const result of parsed.events){
            onQueryEvent(result);
        }
    });
}
// src/ManualDataTransport/serialization.ts
function revive(value) {
    return value;
}
// src/ManualDataTransport/ManualDataTransport.tsx
var buildManualDataTransportBrowserImpl = ({ reviveFromStream = revive })=>function ManualDataTransportBrowserImpl({ children, onQueryEvent, rerunSimulatedQueries }) {
        const hookRehydrationCache = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(window[ApolloHookRehydrationCache] ??= {});
        registerDataTransport({
            onQueryEvent,
            onRehydrate (rehydrate) {
                Object.assign(hookRehydrationCache.current, rehydrate);
            },
            revive: reviveFromStream
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
            "buildManualDataTransportBrowserImpl.ManualDataTransportBrowserImpl.useEffect": ()=>{
                if (document.readyState !== "complete") {
                    window.addEventListener("load", rerunSimulatedQueries, {
                        once: true
                    });
                    return ({
                        "buildManualDataTransportBrowserImpl.ManualDataTransportBrowserImpl.useEffect": ()=>window.removeEventListener("load", rerunSimulatedQueries)
                    })["buildManualDataTransportBrowserImpl.ManualDataTransportBrowserImpl.useEffect"];
                } else {
                    rerunSimulatedQueries();
                }
            }
        }["buildManualDataTransportBrowserImpl.ManualDataTransportBrowserImpl.useEffect"], [
            rerunSimulatedQueries
        ]);
        const useStaticValueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(function useStaticValueRef2(v) {
            const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
            const store = hookRehydrationCache.current;
            const dataRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(UNINITIALIZED);
            if (dataRef.current === UNINITIALIZED) {
                if (store && id in store) {
                    dataRef.current = store[id];
                    delete store[id];
                } else {
                    dataRef.current = v;
                }
            }
            return dataRef;
        }, []);
        return /* @__PURE__ */ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$react$2d$streaming$2f$dist$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DataTransportContext"].Provider, {
            value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
                "buildManualDataTransportBrowserImpl.ManualDataTransportBrowserImpl.useMemo": ()=>({
                        useStaticValueRef
                    })
            }["buildManualDataTransportBrowserImpl.ManualDataTransportBrowserImpl.useMemo"], [
                useStaticValueRef
            ])
        }, children);
    };
var UNINITIALIZED = {};
var buildManualDataTransport = buildManualDataTransportBrowserImpl;
function resetManualSSRApolloSingletons() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$react$2d$streaming$2f$dist$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resetApolloSingletons"])();
    delete window[ApolloHookRehydrationCache];
    delete window[ApolloSSRDataTransport];
}
const built_for_browser = true;
;
}),
"[project]/node_modules/next-themes/dist/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeProvider",
    ()=>J,
    "useTheme",
    ()=>z
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
var M = (e, i, s, u, m, a, l, h)=>{
    let d = document.documentElement, w = [
        "light",
        "dark"
    ];
    function p(n) {
        (Array.isArray(e) ? e : [
            e
        ]).forEach((y)=>{
            let k = y === "class", S = k && a ? m.map((f)=>a[f] || f) : m;
            k ? (d.classList.remove(...S), d.classList.add(a && a[n] ? a[n] : n)) : d.setAttribute(y, n);
        }), R(n);
    }
    function R(n) {
        h && w.includes(n) && (d.style.colorScheme = n);
    }
    function c() {
        return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    }
    if (u) p(u);
    else try {
        let n = localStorage.getItem(i) || s, y = l && n === "system" ? c() : n;
        p(y);
    } catch (n) {}
};
var b = [
    "light",
    "dark"
], I = "(prefers-color-scheme: dark)", O = typeof window == "undefined", x = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](void 0), U = {
    setTheme: (e)=>{},
    themes: []
}, z = ()=>{
    var e;
    return (e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](x)) != null ? e : U;
}, J = (e)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](x) ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, e.children) : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](V, {
        ...e
    }), N = [
    "light",
    "dark"
], V = ({ forcedTheme: e, disableTransitionOnChange: i = !1, enableSystem: s = !0, enableColorScheme: u = !0, storageKey: m = "theme", themes: a = N, defaultTheme: l = s ? "system" : "light", attribute: h = "data-theme", value: d, children: w, nonce: p, scriptProps: R })=>{
    let [c, n] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        "V.useState": ()=>H(m, l)
    }["V.useState"]), [T, y] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]({
        "V.useState": ()=>c === "system" ? E() : c
    }["V.useState"]), k = d ? Object.values(d) : a, S = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "V.useCallback[S]": (o)=>{
            let r = o;
            if (!r) return;
            o === "system" && s && (r = E());
            let v = d ? d[r] : r, C = i ? W(p) : null, P = document.documentElement, L = {
                "V.useCallback[S].L": (g)=>{
                    g === "class" ? (P.classList.remove(...k), v && P.classList.add(v)) : g.startsWith("data-") && (v ? P.setAttribute(g, v) : P.removeAttribute(g));
                }
            }["V.useCallback[S].L"];
            if (Array.isArray(h) ? h.forEach(L) : L(h), u) {
                let g = b.includes(l) ? l : null, D = b.includes(r) ? r : g;
                P.style.colorScheme = D;
            }
            C == null || C();
        }
    }["V.useCallback[S]"], [
        p
    ]), f = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "V.useCallback[f]": (o)=>{
            let r = typeof o == "function" ? o(c) : o;
            n(r);
            try {
                localStorage.setItem(m, r);
            } catch (v) {}
        }
    }["V.useCallback[f]"], [
        c
    ]), A = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "V.useCallback[A]": (o)=>{
            let r = E(o);
            y(r), c === "system" && s && !e && S("system");
        }
    }["V.useCallback[A]"], [
        c,
        e
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "V.useEffect": ()=>{
            let o = window.matchMedia(I);
            return o.addListener(A), A(o), ({
                "V.useEffect": ()=>o.removeListener(A)
            })["V.useEffect"];
        }
    }["V.useEffect"], [
        A
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "V.useEffect": ()=>{
            let o = {
                "V.useEffect.o": (r)=>{
                    r.key === m && (r.newValue ? n(r.newValue) : f(l));
                }
            }["V.useEffect.o"];
            return window.addEventListener("storage", o), ({
                "V.useEffect": ()=>window.removeEventListener("storage", o)
            })["V.useEffect"];
        }
    }["V.useEffect"], [
        f
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "V.useEffect": ()=>{
            S(e != null ? e : c);
        }
    }["V.useEffect"], [
        e,
        c
    ]);
    let Q = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "V.useMemo[Q]": ()=>({
                theme: c,
                setTheme: f,
                forcedTheme: e,
                resolvedTheme: c === "system" ? T : c,
                themes: s ? [
                    ...a,
                    "system"
                ] : a,
                systemTheme: s ? T : void 0
            })
    }["V.useMemo[Q]"], [
        c,
        f,
        e,
        T,
        s,
        a
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](x.Provider, {
        value: Q
    }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](_, {
        forcedTheme: e,
        storageKey: m,
        attribute: h,
        enableSystem: s,
        enableColorScheme: u,
        defaultTheme: l,
        value: d,
        themes: a,
        nonce: p,
        scriptProps: R
    }), w);
}, _ = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"](({ forcedTheme: e, storageKey: i, attribute: s, enableSystem: u, enableColorScheme: m, defaultTheme: a, value: l, themes: h, nonce: d, scriptProps: w })=>{
    let p = JSON.stringify([
        s,
        i,
        a,
        e,
        h,
        l,
        u,
        m
    ]).slice(1, -1);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("script", {
        ...w,
        suppressHydrationWarning: !0,
        nonce: typeof window == "undefined" ? d : "",
        dangerouslySetInnerHTML: {
            __html: `(${M.toString()})(${p})`
        }
    });
}), H = (e, i)=>{
    if (O) return;
    let s;
    try {
        s = localStorage.getItem(e) || void 0;
    } catch (u) {}
    return s || i;
}, W = (e)=>{
    let i = document.createElement("style");
    return e && i.setAttribute("nonce", e), i.appendChild(document.createTextNode("*,*::before,*::after{-webkit-transition:none!important;-moz-transition:none!important;-o-transition:none!important;-ms-transition:none!important;transition:none!important}")), document.head.appendChild(i), ()=>{
        window.getComputedStyle(document.body), setTimeout(()=>{
            document.head.removeChild(i);
        }, 1);
    };
}, E = (e)=>(e || (e = window.matchMedia(I)), e.matches ? "dark" : "light");
;
}),
"[project]/node_modules/hoist-non-react-statics/node_modules/react-is/cjs/react-is.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/** @license React v16.13.1
 * react-is.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ 'use strict';
if ("TURBOPACK compile-time truthy", 1) {
    (function() {
        'use strict';
        // The Symbol used to tag the ReactElement-like types. If there is no native Symbol
        // nor polyfill, then a plain number is used for performance.
        var hasSymbol = typeof Symbol === 'function' && Symbol.for;
        var REACT_ELEMENT_TYPE = hasSymbol ? Symbol.for('react.element') : 0xeac7;
        var REACT_PORTAL_TYPE = hasSymbol ? Symbol.for('react.portal') : 0xeaca;
        var REACT_FRAGMENT_TYPE = hasSymbol ? Symbol.for('react.fragment') : 0xeacb;
        var REACT_STRICT_MODE_TYPE = hasSymbol ? Symbol.for('react.strict_mode') : 0xeacc;
        var REACT_PROFILER_TYPE = hasSymbol ? Symbol.for('react.profiler') : 0xead2;
        var REACT_PROVIDER_TYPE = hasSymbol ? Symbol.for('react.provider') : 0xeacd;
        var REACT_CONTEXT_TYPE = hasSymbol ? Symbol.for('react.context') : 0xeace; // TODO: We don't use AsyncMode or ConcurrentMode anymore. They were temporary
        // (unstable) APIs that have been removed. Can we remove the symbols?
        var REACT_ASYNC_MODE_TYPE = hasSymbol ? Symbol.for('react.async_mode') : 0xeacf;
        var REACT_CONCURRENT_MODE_TYPE = hasSymbol ? Symbol.for('react.concurrent_mode') : 0xeacf;
        var REACT_FORWARD_REF_TYPE = hasSymbol ? Symbol.for('react.forward_ref') : 0xead0;
        var REACT_SUSPENSE_TYPE = hasSymbol ? Symbol.for('react.suspense') : 0xead1;
        var REACT_SUSPENSE_LIST_TYPE = hasSymbol ? Symbol.for('react.suspense_list') : 0xead8;
        var REACT_MEMO_TYPE = hasSymbol ? Symbol.for('react.memo') : 0xead3;
        var REACT_LAZY_TYPE = hasSymbol ? Symbol.for('react.lazy') : 0xead4;
        var REACT_BLOCK_TYPE = hasSymbol ? Symbol.for('react.block') : 0xead9;
        var REACT_FUNDAMENTAL_TYPE = hasSymbol ? Symbol.for('react.fundamental') : 0xead5;
        var REACT_RESPONDER_TYPE = hasSymbol ? Symbol.for('react.responder') : 0xead6;
        var REACT_SCOPE_TYPE = hasSymbol ? Symbol.for('react.scope') : 0xead7;
        function isValidElementType(type) {
            return typeof type === 'string' || typeof type === 'function' || // Note: its typeof might be other than 'symbol' or 'number' if it's a polyfill.
            type === REACT_FRAGMENT_TYPE || type === REACT_CONCURRENT_MODE_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || typeof type === 'object' && type !== null && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_FUNDAMENTAL_TYPE || type.$$typeof === REACT_RESPONDER_TYPE || type.$$typeof === REACT_SCOPE_TYPE || type.$$typeof === REACT_BLOCK_TYPE);
        }
        function typeOf(object) {
            if (typeof object === 'object' && object !== null) {
                var $$typeof = object.$$typeof;
                switch($$typeof){
                    case REACT_ELEMENT_TYPE:
                        var type = object.type;
                        switch(type){
                            case REACT_ASYNC_MODE_TYPE:
                            case REACT_CONCURRENT_MODE_TYPE:
                            case REACT_FRAGMENT_TYPE:
                            case REACT_PROFILER_TYPE:
                            case REACT_STRICT_MODE_TYPE:
                            case REACT_SUSPENSE_TYPE:
                                return type;
                            default:
                                var $$typeofType = type && type.$$typeof;
                                switch($$typeofType){
                                    case REACT_CONTEXT_TYPE:
                                    case REACT_FORWARD_REF_TYPE:
                                    case REACT_LAZY_TYPE:
                                    case REACT_MEMO_TYPE:
                                    case REACT_PROVIDER_TYPE:
                                        return $$typeofType;
                                    default:
                                        return $$typeof;
                                }
                        }
                    case REACT_PORTAL_TYPE:
                        return $$typeof;
                }
            }
            return undefined;
        } // AsyncMode is deprecated along with isAsyncMode
        var AsyncMode = REACT_ASYNC_MODE_TYPE;
        var ConcurrentMode = REACT_CONCURRENT_MODE_TYPE;
        var ContextConsumer = REACT_CONTEXT_TYPE;
        var ContextProvider = REACT_PROVIDER_TYPE;
        var Element = REACT_ELEMENT_TYPE;
        var ForwardRef = REACT_FORWARD_REF_TYPE;
        var Fragment = REACT_FRAGMENT_TYPE;
        var Lazy = REACT_LAZY_TYPE;
        var Memo = REACT_MEMO_TYPE;
        var Portal = REACT_PORTAL_TYPE;
        var Profiler = REACT_PROFILER_TYPE;
        var StrictMode = REACT_STRICT_MODE_TYPE;
        var Suspense = REACT_SUSPENSE_TYPE;
        var hasWarnedAboutDeprecatedIsAsyncMode = false; // AsyncMode should be deprecated
        function isAsyncMode(object) {
            {
                if (!hasWarnedAboutDeprecatedIsAsyncMode) {
                    hasWarnedAboutDeprecatedIsAsyncMode = true; // Using console['warn'] to evade Babel and ESLint
                    console['warn']('The ReactIs.isAsyncMode() alias has been deprecated, ' + 'and will be removed in React 17+. Update your code to use ' + 'ReactIs.isConcurrentMode() instead. It has the exact same API.');
                }
            }
            return isConcurrentMode(object) || typeOf(object) === REACT_ASYNC_MODE_TYPE;
        }
        function isConcurrentMode(object) {
            return typeOf(object) === REACT_CONCURRENT_MODE_TYPE;
        }
        function isContextConsumer(object) {
            return typeOf(object) === REACT_CONTEXT_TYPE;
        }
        function isContextProvider(object) {
            return typeOf(object) === REACT_PROVIDER_TYPE;
        }
        function isElement(object) {
            return typeof object === 'object' && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
        }
        function isForwardRef(object) {
            return typeOf(object) === REACT_FORWARD_REF_TYPE;
        }
        function isFragment(object) {
            return typeOf(object) === REACT_FRAGMENT_TYPE;
        }
        function isLazy(object) {
            return typeOf(object) === REACT_LAZY_TYPE;
        }
        function isMemo(object) {
            return typeOf(object) === REACT_MEMO_TYPE;
        }
        function isPortal(object) {
            return typeOf(object) === REACT_PORTAL_TYPE;
        }
        function isProfiler(object) {
            return typeOf(object) === REACT_PROFILER_TYPE;
        }
        function isStrictMode(object) {
            return typeOf(object) === REACT_STRICT_MODE_TYPE;
        }
        function isSuspense(object) {
            return typeOf(object) === REACT_SUSPENSE_TYPE;
        }
        exports.AsyncMode = AsyncMode;
        exports.ConcurrentMode = ConcurrentMode;
        exports.ContextConsumer = ContextConsumer;
        exports.ContextProvider = ContextProvider;
        exports.Element = Element;
        exports.ForwardRef = ForwardRef;
        exports.Fragment = Fragment;
        exports.Lazy = Lazy;
        exports.Memo = Memo;
        exports.Portal = Portal;
        exports.Profiler = Profiler;
        exports.StrictMode = StrictMode;
        exports.Suspense = Suspense;
        exports.isAsyncMode = isAsyncMode;
        exports.isConcurrentMode = isConcurrentMode;
        exports.isContextConsumer = isContextConsumer;
        exports.isContextProvider = isContextProvider;
        exports.isElement = isElement;
        exports.isForwardRef = isForwardRef;
        exports.isFragment = isFragment;
        exports.isLazy = isLazy;
        exports.isMemo = isMemo;
        exports.isPortal = isPortal;
        exports.isProfiler = isProfiler;
        exports.isStrictMode = isStrictMode;
        exports.isSuspense = isSuspense;
        exports.isValidElementType = isValidElementType;
        exports.typeOf = typeOf;
    })();
}
}),
"[project]/node_modules/hoist-non-react-statics/node_modules/react-is/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/hoist-non-react-statics/node_modules/react-is/cjs/react-is.development.js [app-client] (ecmascript)");
}
}),
"[project]/node_modules/prop-types/node_modules/react-is/cjs/react-is.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/** @license React v16.13.1
 * react-is.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ 'use strict';
if ("TURBOPACK compile-time truthy", 1) {
    (function() {
        'use strict';
        // The Symbol used to tag the ReactElement-like types. If there is no native Symbol
        // nor polyfill, then a plain number is used for performance.
        var hasSymbol = typeof Symbol === 'function' && Symbol.for;
        var REACT_ELEMENT_TYPE = hasSymbol ? Symbol.for('react.element') : 0xeac7;
        var REACT_PORTAL_TYPE = hasSymbol ? Symbol.for('react.portal') : 0xeaca;
        var REACT_FRAGMENT_TYPE = hasSymbol ? Symbol.for('react.fragment') : 0xeacb;
        var REACT_STRICT_MODE_TYPE = hasSymbol ? Symbol.for('react.strict_mode') : 0xeacc;
        var REACT_PROFILER_TYPE = hasSymbol ? Symbol.for('react.profiler') : 0xead2;
        var REACT_PROVIDER_TYPE = hasSymbol ? Symbol.for('react.provider') : 0xeacd;
        var REACT_CONTEXT_TYPE = hasSymbol ? Symbol.for('react.context') : 0xeace; // TODO: We don't use AsyncMode or ConcurrentMode anymore. They were temporary
        // (unstable) APIs that have been removed. Can we remove the symbols?
        var REACT_ASYNC_MODE_TYPE = hasSymbol ? Symbol.for('react.async_mode') : 0xeacf;
        var REACT_CONCURRENT_MODE_TYPE = hasSymbol ? Symbol.for('react.concurrent_mode') : 0xeacf;
        var REACT_FORWARD_REF_TYPE = hasSymbol ? Symbol.for('react.forward_ref') : 0xead0;
        var REACT_SUSPENSE_TYPE = hasSymbol ? Symbol.for('react.suspense') : 0xead1;
        var REACT_SUSPENSE_LIST_TYPE = hasSymbol ? Symbol.for('react.suspense_list') : 0xead8;
        var REACT_MEMO_TYPE = hasSymbol ? Symbol.for('react.memo') : 0xead3;
        var REACT_LAZY_TYPE = hasSymbol ? Symbol.for('react.lazy') : 0xead4;
        var REACT_BLOCK_TYPE = hasSymbol ? Symbol.for('react.block') : 0xead9;
        var REACT_FUNDAMENTAL_TYPE = hasSymbol ? Symbol.for('react.fundamental') : 0xead5;
        var REACT_RESPONDER_TYPE = hasSymbol ? Symbol.for('react.responder') : 0xead6;
        var REACT_SCOPE_TYPE = hasSymbol ? Symbol.for('react.scope') : 0xead7;
        function isValidElementType(type) {
            return typeof type === 'string' || typeof type === 'function' || // Note: its typeof might be other than 'symbol' or 'number' if it's a polyfill.
            type === REACT_FRAGMENT_TYPE || type === REACT_CONCURRENT_MODE_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || typeof type === 'object' && type !== null && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_FUNDAMENTAL_TYPE || type.$$typeof === REACT_RESPONDER_TYPE || type.$$typeof === REACT_SCOPE_TYPE || type.$$typeof === REACT_BLOCK_TYPE);
        }
        function typeOf(object) {
            if (typeof object === 'object' && object !== null) {
                var $$typeof = object.$$typeof;
                switch($$typeof){
                    case REACT_ELEMENT_TYPE:
                        var type = object.type;
                        switch(type){
                            case REACT_ASYNC_MODE_TYPE:
                            case REACT_CONCURRENT_MODE_TYPE:
                            case REACT_FRAGMENT_TYPE:
                            case REACT_PROFILER_TYPE:
                            case REACT_STRICT_MODE_TYPE:
                            case REACT_SUSPENSE_TYPE:
                                return type;
                            default:
                                var $$typeofType = type && type.$$typeof;
                                switch($$typeofType){
                                    case REACT_CONTEXT_TYPE:
                                    case REACT_FORWARD_REF_TYPE:
                                    case REACT_LAZY_TYPE:
                                    case REACT_MEMO_TYPE:
                                    case REACT_PROVIDER_TYPE:
                                        return $$typeofType;
                                    default:
                                        return $$typeof;
                                }
                        }
                    case REACT_PORTAL_TYPE:
                        return $$typeof;
                }
            }
            return undefined;
        } // AsyncMode is deprecated along with isAsyncMode
        var AsyncMode = REACT_ASYNC_MODE_TYPE;
        var ConcurrentMode = REACT_CONCURRENT_MODE_TYPE;
        var ContextConsumer = REACT_CONTEXT_TYPE;
        var ContextProvider = REACT_PROVIDER_TYPE;
        var Element = REACT_ELEMENT_TYPE;
        var ForwardRef = REACT_FORWARD_REF_TYPE;
        var Fragment = REACT_FRAGMENT_TYPE;
        var Lazy = REACT_LAZY_TYPE;
        var Memo = REACT_MEMO_TYPE;
        var Portal = REACT_PORTAL_TYPE;
        var Profiler = REACT_PROFILER_TYPE;
        var StrictMode = REACT_STRICT_MODE_TYPE;
        var Suspense = REACT_SUSPENSE_TYPE;
        var hasWarnedAboutDeprecatedIsAsyncMode = false; // AsyncMode should be deprecated
        function isAsyncMode(object) {
            {
                if (!hasWarnedAboutDeprecatedIsAsyncMode) {
                    hasWarnedAboutDeprecatedIsAsyncMode = true; // Using console['warn'] to evade Babel and ESLint
                    console['warn']('The ReactIs.isAsyncMode() alias has been deprecated, ' + 'and will be removed in React 17+. Update your code to use ' + 'ReactIs.isConcurrentMode() instead. It has the exact same API.');
                }
            }
            return isConcurrentMode(object) || typeOf(object) === REACT_ASYNC_MODE_TYPE;
        }
        function isConcurrentMode(object) {
            return typeOf(object) === REACT_CONCURRENT_MODE_TYPE;
        }
        function isContextConsumer(object) {
            return typeOf(object) === REACT_CONTEXT_TYPE;
        }
        function isContextProvider(object) {
            return typeOf(object) === REACT_PROVIDER_TYPE;
        }
        function isElement(object) {
            return typeof object === 'object' && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
        }
        function isForwardRef(object) {
            return typeOf(object) === REACT_FORWARD_REF_TYPE;
        }
        function isFragment(object) {
            return typeOf(object) === REACT_FRAGMENT_TYPE;
        }
        function isLazy(object) {
            return typeOf(object) === REACT_LAZY_TYPE;
        }
        function isMemo(object) {
            return typeOf(object) === REACT_MEMO_TYPE;
        }
        function isPortal(object) {
            return typeOf(object) === REACT_PORTAL_TYPE;
        }
        function isProfiler(object) {
            return typeOf(object) === REACT_PROFILER_TYPE;
        }
        function isStrictMode(object) {
            return typeOf(object) === REACT_STRICT_MODE_TYPE;
        }
        function isSuspense(object) {
            return typeOf(object) === REACT_SUSPENSE_TYPE;
        }
        exports.AsyncMode = AsyncMode;
        exports.ConcurrentMode = ConcurrentMode;
        exports.ContextConsumer = ContextConsumer;
        exports.ContextProvider = ContextProvider;
        exports.Element = Element;
        exports.ForwardRef = ForwardRef;
        exports.Fragment = Fragment;
        exports.Lazy = Lazy;
        exports.Memo = Memo;
        exports.Portal = Portal;
        exports.Profiler = Profiler;
        exports.StrictMode = StrictMode;
        exports.Suspense = Suspense;
        exports.isAsyncMode = isAsyncMode;
        exports.isConcurrentMode = isConcurrentMode;
        exports.isContextConsumer = isContextConsumer;
        exports.isContextProvider = isContextProvider;
        exports.isElement = isElement;
        exports.isForwardRef = isForwardRef;
        exports.isFragment = isFragment;
        exports.isLazy = isLazy;
        exports.isMemo = isMemo;
        exports.isPortal = isPortal;
        exports.isProfiler = isProfiler;
        exports.isStrictMode = isStrictMode;
        exports.isSuspense = isSuspense;
        exports.isValidElementType = isValidElementType;
        exports.typeOf = typeOf;
    })();
}
}),
"[project]/node_modules/prop-types/node_modules/react-is/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/prop-types/node_modules/react-is/cjs/react-is.development.js [app-client] (ecmascript)");
}
}),
"[project]/node_modules/hoist-non-react-statics/dist/hoist-non-react-statics.cjs.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var reactIs = __turbopack_context__.r("[project]/node_modules/hoist-non-react-statics/node_modules/react-is/index.js [app-client] (ecmascript)");
/**
 * Copyright 2015, Yahoo! Inc.
 * Copyrights licensed under the New BSD License. See the accompanying LICENSE file for terms.
 */ var REACT_STATICS = {
    childContextTypes: true,
    contextType: true,
    contextTypes: true,
    defaultProps: true,
    displayName: true,
    getDefaultProps: true,
    getDerivedStateFromError: true,
    getDerivedStateFromProps: true,
    mixins: true,
    propTypes: true,
    type: true
};
var KNOWN_STATICS = {
    name: true,
    length: true,
    prototype: true,
    caller: true,
    callee: true,
    arguments: true,
    arity: true
};
var FORWARD_REF_STATICS = {
    '$$typeof': true,
    render: true,
    defaultProps: true,
    displayName: true,
    propTypes: true
};
var MEMO_STATICS = {
    '$$typeof': true,
    compare: true,
    defaultProps: true,
    displayName: true,
    propTypes: true,
    type: true
};
var TYPE_STATICS = {};
TYPE_STATICS[reactIs.ForwardRef] = FORWARD_REF_STATICS;
TYPE_STATICS[reactIs.Memo] = MEMO_STATICS;
function getStatics(component) {
    // React v16.11 and below
    if (reactIs.isMemo(component)) {
        return MEMO_STATICS;
    } // React v16.12 and above
    return TYPE_STATICS[component['$$typeof']] || REACT_STATICS;
}
var defineProperty = Object.defineProperty;
var getOwnPropertyNames = Object.getOwnPropertyNames;
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var getPrototypeOf = Object.getPrototypeOf;
var objectPrototype = Object.prototype;
function hoistNonReactStatics(targetComponent, sourceComponent, blacklist) {
    if (typeof sourceComponent !== 'string') {
        // don't hoist over string (html) components
        if (objectPrototype) {
            var inheritedComponent = getPrototypeOf(sourceComponent);
            if (inheritedComponent && inheritedComponent !== objectPrototype) {
                hoistNonReactStatics(targetComponent, inheritedComponent, blacklist);
            }
        }
        var keys = getOwnPropertyNames(sourceComponent);
        if (getOwnPropertySymbols) {
            keys = keys.concat(getOwnPropertySymbols(sourceComponent));
        }
        var targetStatics = getStatics(targetComponent);
        var sourceStatics = getStatics(sourceComponent);
        for(var i = 0; i < keys.length; ++i){
            var key = keys[i];
            if (!KNOWN_STATICS[key] && !(blacklist && blacklist[key]) && !(sourceStatics && sourceStatics[key]) && !(targetStatics && targetStatics[key])) {
                var descriptor = getOwnPropertyDescriptor(sourceComponent, key);
                try {
                    // Avoid failures from read-only properties
                    defineProperty(targetComponent, key, descriptor);
                } catch (e) {}
            }
        }
    }
    return targetComponent;
}
module.exports = hoistNonReactStatics;
}),
"[project]/node_modules/prop-types/lib/ReactPropTypesSecret.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';
module.exports = ReactPropTypesSecret;
}),
"[project]/node_modules/prop-types/lib/has.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = Function.call.bind(Object.prototype.hasOwnProperty);
}),
"[project]/node_modules/prop-types/checkPropTypes.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ 'use strict';
var printWarning = function() {};
if ("TURBOPACK compile-time truthy", 1) {
    var ReactPropTypesSecret = __turbopack_context__.r("[project]/node_modules/prop-types/lib/ReactPropTypesSecret.js [app-client] (ecmascript)");
    var loggedTypeFailures = {};
    var has = __turbopack_context__.r("[project]/node_modules/prop-types/lib/has.js [app-client] (ecmascript)");
    printWarning = function(text) {
        var message = 'Warning: ' + text;
        if (typeof console !== 'undefined') {
            console.error(message);
        }
        try {
            // --- Welcome to debugging React ---
            // This error was thrown as a convenience so that you can use this stack
            // to find the callsite that caused this warning to fire.
            throw new Error(message);
        } catch (x) {}
    };
}
/**
 * Assert that the values match with the type specs.
 * Error messages are memorized and will only be shown once.
 *
 * @param {object} typeSpecs Map of name to a ReactPropType
 * @param {object} values Runtime values that need to be type-checked
 * @param {string} location e.g. "prop", "context", "child context"
 * @param {string} componentName Name of the component for error messages.
 * @param {?Function} getStack Returns the component stack.
 * @private
 */ function checkPropTypes(typeSpecs, values, location, componentName, getStack) {
    if ("TURBOPACK compile-time truthy", 1) {
        for(var typeSpecName in typeSpecs){
            if (has(typeSpecs, typeSpecName)) {
                var error;
                // Prop type validation may throw. In case they do, we don't want to
                // fail the render phase where it didn't fail before. So we log it.
                // After these have been cleaned up, we'll let them throw.
                try {
                    // This is intentionally an invariant that gets caught. It's the same
                    // behavior as without this statement except with a better message.
                    if (typeof typeSpecs[typeSpecName] !== 'function') {
                        var err = Error((componentName || 'React class') + ': ' + location + ' type `' + typeSpecName + '` is invalid; ' + 'it must be a function, usually from the `prop-types` package, but received `' + typeof typeSpecs[typeSpecName] + '`.' + 'This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.');
                        err.name = 'Invariant Violation';
                        throw err;
                    }
                    error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret);
                } catch (ex) {
                    error = ex;
                }
                if (error && !(error instanceof Error)) {
                    printWarning((componentName || 'React class') + ': type specification of ' + location + ' `' + typeSpecName + '` is invalid; the type checker ' + 'function must return `null` or an `Error` but returned a ' + typeof error + '. ' + 'You may have forgotten to pass an argument to the type checker ' + 'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and ' + 'shape all require an argument).');
                }
                if (error instanceof Error && !(error.message in loggedTypeFailures)) {
                    // Only monitor this failure once because there tends to be a lot of the
                    // same error.
                    loggedTypeFailures[error.message] = true;
                    var stack = getStack ? getStack() : '';
                    printWarning('Failed ' + location + ' type: ' + error.message + (stack != null ? stack : ''));
                }
            }
        }
    }
}
/**
 * Resets warning cache when testing.
 *
 * @private
 */ checkPropTypes.resetWarningCache = function() {
    if (("TURBOPACK compile-time value", "development") !== 'production') {
        loggedTypeFailures = {};
    }
};
module.exports = checkPropTypes;
}),
"[project]/node_modules/prop-types/factoryWithTypeCheckers.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ 'use strict';
var ReactIs = __turbopack_context__.r("[project]/node_modules/prop-types/node_modules/react-is/index.js [app-client] (ecmascript)");
var assign = __turbopack_context__.r("[project]/node_modules/next/dist/build/polyfills/object-assign.js [app-client] (ecmascript)");
var ReactPropTypesSecret = __turbopack_context__.r("[project]/node_modules/prop-types/lib/ReactPropTypesSecret.js [app-client] (ecmascript)");
var has = __turbopack_context__.r("[project]/node_modules/prop-types/lib/has.js [app-client] (ecmascript)");
var checkPropTypes = __turbopack_context__.r("[project]/node_modules/prop-types/checkPropTypes.js [app-client] (ecmascript)");
var printWarning = function() {};
if ("TURBOPACK compile-time truthy", 1) {
    printWarning = function(text) {
        var message = 'Warning: ' + text;
        if (typeof console !== 'undefined') {
            console.error(message);
        }
        try {
            // --- Welcome to debugging React ---
            // This error was thrown as a convenience so that you can use this stack
            // to find the callsite that caused this warning to fire.
            throw new Error(message);
        } catch (x) {}
    };
}
function emptyFunctionThatReturnsNull() {
    return null;
}
module.exports = function(isValidElement, throwOnDirectAccess) {
    /* global Symbol */ var ITERATOR_SYMBOL = typeof Symbol === 'function' && Symbol.iterator;
    var FAUX_ITERATOR_SYMBOL = '@@iterator'; // Before Symbol spec.
    /**
   * Returns the iterator method function contained on the iterable object.
   *
   * Be sure to invoke the function with the iterable as context:
   *
   *     var iteratorFn = getIteratorFn(myIterable);
   *     if (iteratorFn) {
   *       var iterator = iteratorFn.call(myIterable);
   *       ...
   *     }
   *
   * @param {?object} maybeIterable
   * @return {?function}
   */ function getIteratorFn(maybeIterable) {
        var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
        if (typeof iteratorFn === 'function') {
            return iteratorFn;
        }
    }
    /**
   * Collection of methods that allow declaration and validation of props that are
   * supplied to React components. Example usage:
   *
   *   var Props = require('ReactPropTypes');
   *   var MyArticle = React.createClass({
   *     propTypes: {
   *       // An optional string prop named "description".
   *       description: Props.string,
   *
   *       // A required enum prop named "category".
   *       category: Props.oneOf(['News','Photos']).isRequired,
   *
   *       // A prop named "dialog" that requires an instance of Dialog.
   *       dialog: Props.instanceOf(Dialog).isRequired
   *     },
   *     render: function() { ... }
   *   });
   *
   * A more formal specification of how these methods are used:
   *
   *   type := array|bool|func|object|number|string|oneOf([...])|instanceOf(...)
   *   decl := ReactPropTypes.{type}(.isRequired)?
   *
   * Each and every declaration produces a function with the same signature. This
   * allows the creation of custom validation functions. For example:
   *
   *  var MyLink = React.createClass({
   *    propTypes: {
   *      // An optional string or URI prop named "href".
   *      href: function(props, propName, componentName) {
   *        var propValue = props[propName];
   *        if (propValue != null && typeof propValue !== 'string' &&
   *            !(propValue instanceof URI)) {
   *          return new Error(
   *            'Expected a string or an URI for ' + propName + ' in ' +
   *            componentName
   *          );
   *        }
   *      }
   *    },
   *    render: function() {...}
   *  });
   *
   * @internal
   */ var ANONYMOUS = '<<anonymous>>';
    // Important!
    // Keep this list in sync with production version in `./factoryWithThrowingShims.js`.
    var ReactPropTypes = {
        array: createPrimitiveTypeChecker('array'),
        bigint: createPrimitiveTypeChecker('bigint'),
        bool: createPrimitiveTypeChecker('boolean'),
        func: createPrimitiveTypeChecker('function'),
        number: createPrimitiveTypeChecker('number'),
        object: createPrimitiveTypeChecker('object'),
        string: createPrimitiveTypeChecker('string'),
        symbol: createPrimitiveTypeChecker('symbol'),
        any: createAnyTypeChecker(),
        arrayOf: createArrayOfTypeChecker,
        element: createElementTypeChecker(),
        elementType: createElementTypeTypeChecker(),
        instanceOf: createInstanceTypeChecker,
        node: createNodeChecker(),
        objectOf: createObjectOfTypeChecker,
        oneOf: createEnumTypeChecker,
        oneOfType: createUnionTypeChecker,
        shape: createShapeTypeChecker,
        exact: createStrictShapeTypeChecker
    };
    /**
   * inlined Object.is polyfill to avoid requiring consumers ship their own
   * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
   */ /*eslint-disable no-self-compare*/ function is(x, y) {
        // SameValue algorithm
        if (x === y) {
            // Steps 1-5, 7-10
            // Steps 6.b-6.e: +0 != -0
            return x !== 0 || 1 / x === 1 / y;
        } else {
            // Step 6.a: NaN == NaN
            return x !== x && y !== y;
        }
    }
    /*eslint-enable no-self-compare*/ /**
   * We use an Error-like object for backward compatibility as people may call
   * PropTypes directly and inspect their output. However, we don't use real
   * Errors anymore. We don't inspect their stack anyway, and creating them
   * is prohibitively expensive if they are created too often, such as what
   * happens in oneOfType() for any type before the one that matched.
   */ function PropTypeError(message, data) {
        this.message = message;
        this.data = data && typeof data === 'object' ? data : {};
        this.stack = '';
    }
    // Make `instanceof Error` still work for returned errors.
    PropTypeError.prototype = Error.prototype;
    function createChainableTypeChecker(validate) {
        if (("TURBOPACK compile-time value", "development") !== 'production') {
            var manualPropTypeCallCache = {};
            var manualPropTypeWarningCount = 0;
        }
        function checkType(isRequired, props, propName, componentName, location, propFullName, secret) {
            componentName = componentName || ANONYMOUS;
            propFullName = propFullName || propName;
            if (secret !== ReactPropTypesSecret) {
                if (throwOnDirectAccess) {
                    // New behavior only for users of `prop-types` package
                    var err = new Error('Calling PropTypes validators directly is not supported by the `prop-types` package. ' + 'Use `PropTypes.checkPropTypes()` to call them. ' + 'Read more at http://fb.me/use-check-prop-types');
                    err.name = 'Invariant Violation';
                    throw err;
                } else if (("TURBOPACK compile-time value", "development") !== 'production' && typeof console !== 'undefined') {
                    // Old behavior for people using React.PropTypes
                    var cacheKey = componentName + ':' + propName;
                    if (!manualPropTypeCallCache[cacheKey] && // Avoid spamming the console because they are often not actionable except for lib authors
                    manualPropTypeWarningCount < 3) {
                        printWarning('You are manually calling a React.PropTypes validation ' + 'function for the `' + propFullName + '` prop on `' + componentName + '`. This is deprecated ' + 'and will throw in the standalone `prop-types` package. ' + 'You may be seeing this warning due to a third-party PropTypes ' + 'library. See https://fb.me/react-warning-dont-call-proptypes ' + 'for details.');
                        manualPropTypeCallCache[cacheKey] = true;
                        manualPropTypeWarningCount++;
                    }
                }
            }
            if (props[propName] == null) {
                if (isRequired) {
                    if (props[propName] === null) {
                        return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required ' + ('in `' + componentName + '`, but its value is `null`.'));
                    }
                    return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required in ' + ('`' + componentName + '`, but its value is `undefined`.'));
                }
                return null;
            } else {
                return validate(props, propName, componentName, location, propFullName);
            }
        }
        var chainedCheckType = checkType.bind(null, false);
        chainedCheckType.isRequired = checkType.bind(null, true);
        return chainedCheckType;
    }
    function createPrimitiveTypeChecker(expectedType) {
        function validate(props, propName, componentName, location, propFullName, secret) {
            var propValue = props[propName];
            var propType = getPropType(propValue);
            if (propType !== expectedType) {
                // `propValue` being instance of, say, date/regexp, pass the 'object'
                // check, but we can offer a more precise error message here rather than
                // 'of type `object`'.
                var preciseType = getPreciseType(propValue);
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + preciseType + '` supplied to `' + componentName + '`, expected ') + ('`' + expectedType + '`.'), {
                    expectedType: expectedType
                });
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function createAnyTypeChecker() {
        return createChainableTypeChecker(emptyFunctionThatReturnsNull);
    }
    function createArrayOfTypeChecker(typeChecker) {
        function validate(props, propName, componentName, location, propFullName) {
            if (typeof typeChecker !== 'function') {
                return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside arrayOf.');
            }
            var propValue = props[propName];
            if (!Array.isArray(propValue)) {
                var propType = getPropType(propValue);
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an array.'));
            }
            for(var i = 0; i < propValue.length; i++){
                var error = typeChecker(propValue, i, componentName, location, propFullName + '[' + i + ']', ReactPropTypesSecret);
                if (error instanceof Error) {
                    return error;
                }
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function createElementTypeChecker() {
        function validate(props, propName, componentName, location, propFullName) {
            var propValue = props[propName];
            if (!isValidElement(propValue)) {
                var propType = getPropType(propValue);
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement.'));
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function createElementTypeTypeChecker() {
        function validate(props, propName, componentName, location, propFullName) {
            var propValue = props[propName];
            if (!ReactIs.isValidElementType(propValue)) {
                var propType = getPropType(propValue);
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement type.'));
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function createInstanceTypeChecker(expectedClass) {
        function validate(props, propName, componentName, location, propFullName) {
            if (!(props[propName] instanceof expectedClass)) {
                var expectedClassName = expectedClass.name || ANONYMOUS;
                var actualClassName = getClassName(props[propName]);
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + actualClassName + '` supplied to `' + componentName + '`, expected ') + ('instance of `' + expectedClassName + '`.'));
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function createEnumTypeChecker(expectedValues) {
        if (!Array.isArray(expectedValues)) {
            if ("TURBOPACK compile-time truthy", 1) {
                if (arguments.length > 1) {
                    printWarning('Invalid arguments supplied to oneOf, expected an array, got ' + arguments.length + ' arguments. ' + 'A common mistake is to write oneOf(x, y, z) instead of oneOf([x, y, z]).');
                } else {
                    printWarning('Invalid argument supplied to oneOf, expected an array.');
                }
            }
            return emptyFunctionThatReturnsNull;
        }
        function validate(props, propName, componentName, location, propFullName) {
            var propValue = props[propName];
            for(var i = 0; i < expectedValues.length; i++){
                if (is(propValue, expectedValues[i])) {
                    return null;
                }
            }
            var valuesString = JSON.stringify(expectedValues, function replacer(key, value) {
                var type = getPreciseType(value);
                if (type === 'symbol') {
                    return String(value);
                }
                return value;
            });
            return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of value `' + String(propValue) + '` ' + ('supplied to `' + componentName + '`, expected one of ' + valuesString + '.'));
        }
        return createChainableTypeChecker(validate);
    }
    function createObjectOfTypeChecker(typeChecker) {
        function validate(props, propName, componentName, location, propFullName) {
            if (typeof typeChecker !== 'function') {
                return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside objectOf.');
            }
            var propValue = props[propName];
            var propType = getPropType(propValue);
            if (propType !== 'object') {
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an object.'));
            }
            for(var key in propValue){
                if (has(propValue, key)) {
                    var error = typeChecker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
                    if (error instanceof Error) {
                        return error;
                    }
                }
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function createUnionTypeChecker(arrayOfTypeCheckers) {
        if (!Array.isArray(arrayOfTypeCheckers)) {
            ("TURBOPACK compile-time truthy", 1) ? printWarning('Invalid argument supplied to oneOfType, expected an instance of array.') : "TURBOPACK unreachable";
            return emptyFunctionThatReturnsNull;
        }
        for(var i = 0; i < arrayOfTypeCheckers.length; i++){
            var checker = arrayOfTypeCheckers[i];
            if (typeof checker !== 'function') {
                printWarning('Invalid argument supplied to oneOfType. Expected an array of check functions, but ' + 'received ' + getPostfixForTypeWarning(checker) + ' at index ' + i + '.');
                return emptyFunctionThatReturnsNull;
            }
        }
        function validate(props, propName, componentName, location, propFullName) {
            var expectedTypes = [];
            for(var i = 0; i < arrayOfTypeCheckers.length; i++){
                var checker = arrayOfTypeCheckers[i];
                var checkerResult = checker(props, propName, componentName, location, propFullName, ReactPropTypesSecret);
                if (checkerResult == null) {
                    return null;
                }
                if (checkerResult.data && has(checkerResult.data, 'expectedType')) {
                    expectedTypes.push(checkerResult.data.expectedType);
                }
            }
            var expectedTypesMessage = expectedTypes.length > 0 ? ', expected one of type [' + expectedTypes.join(', ') + ']' : '';
            return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`' + expectedTypesMessage + '.'));
        }
        return createChainableTypeChecker(validate);
    }
    function createNodeChecker() {
        function validate(props, propName, componentName, location, propFullName) {
            if (!isNode(props[propName])) {
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`, expected a ReactNode.'));
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function invalidValidatorError(componentName, location, propFullName, key, type) {
        return new PropTypeError((componentName || 'React class') + ': ' + location + ' type `' + propFullName + '.' + key + '` is invalid; ' + 'it must be a function, usually from the `prop-types` package, but received `' + type + '`.');
    }
    function createShapeTypeChecker(shapeTypes) {
        function validate(props, propName, componentName, location, propFullName) {
            var propValue = props[propName];
            var propType = getPropType(propValue);
            if (propType !== 'object') {
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
            }
            for(var key in shapeTypes){
                var checker = shapeTypes[key];
                if (typeof checker !== 'function') {
                    return invalidValidatorError(componentName, location, propFullName, key, getPreciseType(checker));
                }
                var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
                if (error) {
                    return error;
                }
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function createStrictShapeTypeChecker(shapeTypes) {
        function validate(props, propName, componentName, location, propFullName) {
            var propValue = props[propName];
            var propType = getPropType(propValue);
            if (propType !== 'object') {
                return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
            }
            // We need to check all keys in case some are required but missing from props.
            var allKeys = assign({}, props[propName], shapeTypes);
            for(var key in allKeys){
                var checker = shapeTypes[key];
                if (has(shapeTypes, key) && typeof checker !== 'function') {
                    return invalidValidatorError(componentName, location, propFullName, key, getPreciseType(checker));
                }
                if (!checker) {
                    return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` key `' + key + '` supplied to `' + componentName + '`.' + '\nBad object: ' + JSON.stringify(props[propName], null, '  ') + '\nValid keys: ' + JSON.stringify(Object.keys(shapeTypes), null, '  '));
                }
                var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
                if (error) {
                    return error;
                }
            }
            return null;
        }
        return createChainableTypeChecker(validate);
    }
    function isNode(propValue) {
        switch(typeof propValue){
            case 'number':
            case 'string':
            case 'undefined':
                return true;
            case 'boolean':
                return !propValue;
            case 'object':
                if (Array.isArray(propValue)) {
                    return propValue.every(isNode);
                }
                if (propValue === null || isValidElement(propValue)) {
                    return true;
                }
                var iteratorFn = getIteratorFn(propValue);
                if (iteratorFn) {
                    var iterator = iteratorFn.call(propValue);
                    var step;
                    if (iteratorFn !== propValue.entries) {
                        while(!(step = iterator.next()).done){
                            if (!isNode(step.value)) {
                                return false;
                            }
                        }
                    } else {
                        // Iterator will provide entry [k,v] tuples rather than values.
                        while(!(step = iterator.next()).done){
                            var entry = step.value;
                            if (entry) {
                                if (!isNode(entry[1])) {
                                    return false;
                                }
                            }
                        }
                    }
                } else {
                    return false;
                }
                return true;
            default:
                return false;
        }
    }
    function isSymbol(propType, propValue) {
        // Native Symbol.
        if (propType === 'symbol') {
            return true;
        }
        // falsy value can't be a Symbol
        if (!propValue) {
            return false;
        }
        // 19.4.3.5 Symbol.prototype[@@toStringTag] === 'Symbol'
        if (propValue['@@toStringTag'] === 'Symbol') {
            return true;
        }
        // Fallback for non-spec compliant Symbols which are polyfilled.
        if (typeof Symbol === 'function' && propValue instanceof Symbol) {
            return true;
        }
        return false;
    }
    // Equivalent of `typeof` but with special handling for array and regexp.
    function getPropType(propValue) {
        var propType = typeof propValue;
        if (Array.isArray(propValue)) {
            return 'array';
        }
        if (propValue instanceof RegExp) {
            // Old webkits (at least until Android 4.0) return 'function' rather than
            // 'object' for typeof a RegExp. We'll normalize this here so that /bla/
            // passes PropTypes.object.
            return 'object';
        }
        if (isSymbol(propType, propValue)) {
            return 'symbol';
        }
        return propType;
    }
    // This handles more types than `getPropType`. Only used for error messages.
    // See `createPrimitiveTypeChecker`.
    function getPreciseType(propValue) {
        if (typeof propValue === 'undefined' || propValue === null) {
            return '' + propValue;
        }
        var propType = getPropType(propValue);
        if (propType === 'object') {
            if (propValue instanceof Date) {
                return 'date';
            } else if (propValue instanceof RegExp) {
                return 'regexp';
            }
        }
        return propType;
    }
    // Returns a string that is postfixed to a warning about an invalid type.
    // For example, "undefined" or "of type array"
    function getPostfixForTypeWarning(value) {
        var type = getPreciseType(value);
        switch(type){
            case 'array':
            case 'object':
                return 'an ' + type;
            case 'boolean':
            case 'date':
            case 'regexp':
                return 'a ' + type;
            default:
                return type;
        }
    }
    // Returns class name of the object, if any.
    function getClassName(propValue) {
        if (!propValue.constructor || !propValue.constructor.name) {
            return ANONYMOUS;
        }
        return propValue.constructor.name;
    }
    ReactPropTypes.checkPropTypes = checkPropTypes;
    ReactPropTypes.resetWarningCache = checkPropTypes.resetWarningCache;
    ReactPropTypes.PropTypes = ReactPropTypes;
    return ReactPropTypes;
};
}),
"[project]/node_modules/prop-types/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ if ("TURBOPACK compile-time truthy", 1) {
    var ReactIs = __turbopack_context__.r("[project]/node_modules/prop-types/node_modules/react-is/index.js [app-client] (ecmascript)");
    // By explicitly using `prop-types` you are opting into new development behavior.
    // http://fb.me/prop-types-in-prod
    var throwOnDirectAccess = true;
    module.exports = __turbopack_context__.r("[project]/node_modules/prop-types/factoryWithTypeCheckers.js [app-client] (ecmascript)")(ReactIs.isElement, throwOnDirectAccess);
} else //TURBOPACK unreachable
;
}),
"[project]/node_modules/glamor/lib/sheet.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.StyleSheet = StyleSheet;
var _objectAssign = __turbopack_context__.r("[project]/node_modules/next/dist/build/polyfills/object-assign.js [app-client] (ecmascript)");
var _objectAssign2 = _interopRequireDefault(_objectAssign);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function _toConsumableArray(arr) {
    if (Array.isArray(arr)) {
        for(var i = 0, arr2 = Array(arr.length); i < arr.length; i++){
            arr2[i] = arr[i];
        }
        return arr2;
    } else {
        return Array.from(arr);
    }
}
/* 

high performance StyleSheet for css-in-js systems 

- uses multiple style tags behind the scenes for millions of rules 
- uses `insertRule` for appending in production for *much* faster performance
- 'polyfills' on server side 


// usage

import StyleSheet from 'glamor/lib/sheet'
let styleSheet = new StyleSheet()

styleSheet.inject() 
- 'injects' the stylesheet into the page (or into memory if on server)

styleSheet.insert('#box { border: 1px solid red; }') 
- appends a css rule into the stylesheet 

styleSheet.flush() 
- empties the stylesheet of all its contents


*/ function last(arr) {
    return arr[arr.length - 1];
}
function sheetForTag(tag) {
    if (tag.sheet) {
        return tag.sheet;
    }
    // this weirdness brought to you by firefox 
    for(var i = 0; i < document.styleSheets.length; i++){
        if (document.styleSheets[i].ownerNode === tag) {
            return document.styleSheets[i];
        }
    }
}
var isBrowser = typeof window !== 'undefined';
var isDev = ("TURBOPACK compile-time value", "development") === 'development' || !("TURBOPACK compile-time value", "development"); //(x => (x === 'development') || !x)(process.env.NODE_ENV)
var isTest = ("TURBOPACK compile-time value", "development") === 'test';
var oldIE = function() {
    if (isBrowser) {
        var div = document.createElement('div');
        div.innerHTML = '<!--[if lt IE 10]><i></i><![endif]-->';
        return div.getElementsByTagName('i').length === 1;
    }
}();
function makeStyleTag() {
    var tag = document.createElement('style');
    tag.type = 'text/css';
    tag.setAttribute('data-glamor', '');
    tag.appendChild(document.createTextNode(''));
    (document.head || document.getElementsByTagName('head')[0]).appendChild(tag);
    return tag;
}
function StyleSheet() {
    var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {}, _ref$speedy = _ref.speedy, speedy = _ref$speedy === undefined ? !isDev && !isTest : _ref$speedy, _ref$maxLength = _ref.maxLength, maxLength = _ref$maxLength === undefined ? isBrowser && oldIE ? 4000 : 65000 : _ref$maxLength;
    this.isSpeedy = speedy; // the big drawback here is that the css won't be editable in devtools
    this.sheet = undefined;
    this.tags = [];
    this.maxLength = maxLength;
    this.ctr = 0;
}
(0, _objectAssign2.default)(StyleSheet.prototype, {
    getSheet: function getSheet() {
        return sheetForTag(last(this.tags));
    },
    inject: function inject() {
        var _this = this;
        if (this.injected) {
            throw new Error('already injected stylesheet!');
        }
        if (isBrowser) {
            this.tags[0] = makeStyleTag();
        } else {
            // server side 'polyfill'. just enough behavior to be useful.
            this.sheet = {
                cssRules: [],
                insertRule: function insertRule(rule) {
                    // enough 'spec compliance' to be able to extract the rules later  
                    // in other words, just the cssText field 
                    _this.sheet.cssRules.push({
                        cssText: rule
                    });
                }
            };
        }
        this.injected = true;
    },
    speedy: function speedy(bool) {
        if (this.ctr !== 0) {
            throw new Error('cannot change speedy mode after inserting any rule to sheet. Either call speedy(' + bool + ') earlier in your app, or call flush() before speedy(' + bool + ')');
        }
        this.isSpeedy = !!bool;
    },
    _insert: function _insert(rule) {
        // this weirdness for perf, and chrome's weird bug 
        // https://stackoverflow.com/questions/20007992/chrome-suddenly-stopped-accepting-insertrule
        try {
            var sheet = this.getSheet();
            sheet.insertRule(rule, rule.indexOf('@import') !== -1 ? 0 : sheet.cssRules.length);
        } catch (e) {
            if ("TURBOPACK compile-time truthy", 1) {
                // might need beter dx for this 
                console.warn('whoops, illegal rule inserted', rule); //eslint-disable-line no-console
            }
        }
    },
    insert: function insert(rule) {
        if (isBrowser) {
            // this is the ultrafast version, works across browsers 
            if (this.isSpeedy && this.getSheet().insertRule) {
                this._insert(rule);
            } else {
                if (rule.indexOf('@import') !== -1) {
                    var tag = last(this.tags);
                    tag.insertBefore(document.createTextNode(rule), tag.firstChild);
                } else {
                    last(this.tags).appendChild(document.createTextNode(rule));
                }
            }
        } else {
            // server side is pretty simple         
            this.sheet.insertRule(rule, rule.indexOf('@import') !== -1 ? 0 : this.sheet.cssRules.length);
        }
        this.ctr++;
        if (isBrowser && this.ctr % this.maxLength === 0) {
            this.tags.push(makeStyleTag());
        }
        return this.ctr - 1;
    },
    // commenting this out till we decide on v3's decision 
    // _replace(index, rule) {
    //   // this weirdness for perf, and chrome's weird bug 
    //   // https://stackoverflow.com/questions/20007992/chrome-suddenly-stopped-accepting-insertrule
    //   try {  
    //     let sheet = this.getSheet()        
    //     sheet.deleteRule(index) // todo - correct index here     
    //     sheet.insertRule(rule, index)
    //   }
    //   catch(e) {
    //     if(isDev) {
    //       // might need beter dx for this 
    //       console.warn('whoops, problem replacing rule', rule) //eslint-disable-line no-console
    //     }          
    //   }          
    // }
    // replace(index, rule) {
    //   if(isBrowser) {
    //     if(this.isSpeedy && this.getSheet().insertRule) {
    //       this._replace(index, rule)
    //     }
    //     else {
    //       let _slot = Math.floor((index  + this.maxLength) / this.maxLength) - 1        
    //       let _index = (index % this.maxLength) + 1
    //       let tag = this.tags[_slot]
    //       tag.replaceChild(document.createTextNode(rule), tag.childNodes[_index])
    //     }
    //   }
    //   else {
    //     let rules = this.sheet.cssRules
    //     this.sheet.cssRules = [ ...rules.slice(0, index), { cssText: rule }, ...rules.slice(index + 1) ]
    //   }
    // }
    delete: function _delete(index) {
        // we insert a blank rule when 'deleting' so previously returned indexes remain stable
        return this.replace(index, '');
    },
    flush: function flush() {
        if (isBrowser) {
            this.tags.forEach(function(tag) {
                return tag.parentNode.removeChild(tag);
            });
            this.tags = [];
            this.sheet = null;
            this.ctr = 0;
        // todo - look for remnants in document.styleSheets
        } else {
            // simpler on server 
            this.sheet.cssRules = [];
        }
        this.injected = false;
    },
    rules: function rules() {
        if (!isBrowser) {
            return this.sheet.cssRules;
        }
        var arr = [];
        this.tags.forEach(function(tag) {
            return arr.splice.apply(arr, [
                arr.length,
                0
            ].concat(_toConsumableArray(Array.from(sheetForTag(tag).cssRules))));
        });
        return arr;
    }
});
}),
"[project]/node_modules/glamor/lib/CSSPropertyOperations/CSSProperty.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
/**
 * Copyright 2013-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 *
 * @providesModule CSSProperty
 */ /**
 * CSS properties which accept numbers but are not in units of "px".
 */ var isUnitlessNumber = {
    animationIterationCount: true,
    borderImageOutset: true,
    borderImageSlice: true,
    borderImageWidth: true,
    boxFlex: true,
    boxFlexGroup: true,
    boxOrdinalGroup: true,
    columnCount: true,
    flex: true,
    flexGrow: true,
    flexPositive: true,
    flexShrink: true,
    flexNegative: true,
    flexOrder: true,
    gridRow: true,
    gridRowStart: true,
    gridRowEnd: true,
    gridColumn: true,
    gridColumnStart: true,
    gridColumnEnd: true,
    fontWeight: true,
    lineClamp: true,
    lineHeight: true,
    opacity: true,
    order: true,
    orphans: true,
    tabSize: true,
    widows: true,
    zIndex: true,
    zoom: true,
    // SVG-related properties
    fillOpacity: true,
    floodOpacity: true,
    stopOpacity: true,
    strokeDasharray: true,
    strokeDashoffset: true,
    strokeMiterlimit: true,
    strokeOpacity: true,
    strokeWidth: true
};
function prefixKey(prefix, key) {
    return prefix + key.charAt(0).toUpperCase() + key.substring(1);
}
/**
 * Support style names that may come passed in prefixed by adding permutations
 * of vendor prefixes.
 */ var prefixes = [
    'Webkit',
    'ms',
    'Moz',
    'O'
];
// Using Object.keys here, or else the vanilla for-in loop makes IE8 go into an
// infinite loop, because it iterates over the newly added props too.
Object.keys(isUnitlessNumber).forEach(function(prop) {
    prefixes.forEach(function(prefix) {
        isUnitlessNumber[prefixKey(prefix, prop)] = isUnitlessNumber[prop];
    });
});
/**
 * Most style properties can be unset by doing .style[prop] = '' but IE8
 * doesn't like doing that with shorthand properties so for the properties that
 * IE8 breaks on, which are listed here, we instead unset each of the
 * individual properties. See http://bugs.jquery.com/ticket/12385.
 * The 4-value 'clock' properties like margin, padding, border-width seem to
 * behave without any problems. Curiously, list-style works too without any
 * special prodding.
 */ var shorthandPropertyExpansions = {
    background: {
        backgroundAttachment: true,
        backgroundColor: true,
        backgroundImage: true,
        backgroundPositionX: true,
        backgroundPositionY: true,
        backgroundRepeat: true
    },
    backgroundPosition: {
        backgroundPositionX: true,
        backgroundPositionY: true
    },
    border: {
        borderWidth: true,
        borderStyle: true,
        borderColor: true
    },
    borderBottom: {
        borderBottomWidth: true,
        borderBottomStyle: true,
        borderBottomColor: true
    },
    borderLeft: {
        borderLeftWidth: true,
        borderLeftStyle: true,
        borderLeftColor: true
    },
    borderRight: {
        borderRightWidth: true,
        borderRightStyle: true,
        borderRightColor: true
    },
    borderTop: {
        borderTopWidth: true,
        borderTopStyle: true,
        borderTopColor: true
    },
    font: {
        fontStyle: true,
        fontVariant: true,
        fontWeight: true,
        fontSize: true,
        lineHeight: true,
        fontFamily: true
    },
    outline: {
        outlineWidth: true,
        outlineStyle: true,
        outlineColor: true
    }
};
var CSSProperty = {
    isUnitlessNumber: isUnitlessNumber,
    shorthandPropertyExpansions: shorthandPropertyExpansions
};
exports.default = CSSProperty;
}),
"[project]/node_modules/glamor/lib/CSSPropertyOperations/dangerousStyleValue.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
Object.defineProperty(exports, "__esModule", {
    value: true
});
var _CSSProperty = __turbopack_context__.r("[project]/node_modules/glamor/lib/CSSPropertyOperations/CSSProperty.js [app-client] (ecmascript)");
var _CSSProperty2 = _interopRequireDefault(_CSSProperty);
var _warning = __turbopack_context__.r("[project]/node_modules/glamor/node_modules/fbjs/lib/warning.js [app-client] (ecmascript)");
var _warning2 = _interopRequireDefault(_warning);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
/**
 * Copyright 2013-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 *
 * @providesModule dangerousStyleValue
 */ var isUnitlessNumber = _CSSProperty2.default.isUnitlessNumber;
var styleWarnings = {};
/**
 * Convert a value into the proper css writable value. The style name `name`
 * should be logical (no hyphens), as specified
 * in `CSSProperty.isUnitlessNumber`.
 *
 * @param {string} name CSS property name such as `topMargin`.
 * @param {*} value CSS property value such as `10px`.
 * @param {ReactDOMComponent} component
 * @return {string} Normalized style value with dimensions applied.
 */ function dangerousStyleValue(name, value, component) {
    // Note that we've removed escapeTextForBrowser() calls here since the
    // whole string will be escaped when the attribute is injected into
    // the markup. If you provide unsafe user data here they can inject
    // arbitrary CSS which may be problematic (I couldn't repro this):
    // https://www.owasp.org/index.php/XSS_Filter_Evasion_Cheat_Sheet
    // http://www.thespanner.co.uk/2007/11/26/ultimate-xss-css-injection/
    // This is not an XSS hole but instead a potential CSS injection issue
    // which has lead to a greater discussion about how we're going to
    // trust URLs moving forward. See #2115901
    var isEmpty = value == null || typeof value === 'boolean' || value === '';
    if (isEmpty) {
        return '';
    }
    var isNonNumeric = isNaN(value);
    if (isNonNumeric || value === 0 || isUnitlessNumber.hasOwnProperty(name) && isUnitlessNumber[name]) {
        return '' + value; // cast to string
    }
    if (typeof value === 'string') {
        if ("TURBOPACK compile-time truthy", 1) {
            // Allow '0' to pass through without warning. 0 is already special and
            // doesn't require units, so we don't need to warn about it.
            if (component && value !== '0') {
                var owner = component._currentElement._owner;
                var ownerName = owner ? owner.getName() : null;
                if (ownerName && !styleWarnings[ownerName]) {
                    styleWarnings[ownerName] = {};
                }
                var warned = false;
                if (ownerName) {
                    var warnings = styleWarnings[ownerName];
                    warned = warnings[name];
                    if (!warned) {
                        warnings[name] = true;
                    }
                }
                if (!warned) {
                    ("TURBOPACK compile-time truthy", 1) ? (0, _warning2.default)(false, 'a `%s` tag (owner: `%s`) was passed a numeric string value ' + 'for CSS property `%s` (value: `%s`) which will be treated ' + 'as a unitless number in a future version of React.', component._currentElement.type, ownerName || 'unknown', name, value) : "TURBOPACK unreachable";
                }
            }
        }
        value = value.trim();
    }
    return value + 'px';
}
exports.default = dangerousStyleValue;
}),
"[project]/node_modules/glamor/lib/CSSPropertyOperations/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.processStyleName = undefined;
exports.createMarkupForStyles = createMarkupForStyles;
var _camelizeStyleName = __turbopack_context__.r("[project]/node_modules/glamor/node_modules/fbjs/lib/camelizeStyleName.js [app-client] (ecmascript)");
var _camelizeStyleName2 = _interopRequireDefault(_camelizeStyleName);
var _dangerousStyleValue = __turbopack_context__.r("[project]/node_modules/glamor/lib/CSSPropertyOperations/dangerousStyleValue.js [app-client] (ecmascript)");
var _dangerousStyleValue2 = _interopRequireDefault(_dangerousStyleValue);
var _hyphenateStyleName = __turbopack_context__.r("[project]/node_modules/glamor/node_modules/fbjs/lib/hyphenateStyleName.js [app-client] (ecmascript)");
var _hyphenateStyleName2 = _interopRequireDefault(_hyphenateStyleName);
var _memoizeStringOnly = __turbopack_context__.r("[project]/node_modules/glamor/node_modules/fbjs/lib/memoizeStringOnly.js [app-client] (ecmascript)");
var _memoizeStringOnly2 = _interopRequireDefault(_memoizeStringOnly);
var _warning = __turbopack_context__.r("[project]/node_modules/glamor/node_modules/fbjs/lib/warning.js [app-client] (ecmascript)");
var _warning2 = _interopRequireDefault(_warning);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var processStyleName = exports.processStyleName = (0, _memoizeStringOnly2.default)(_hyphenateStyleName2.default); /**
                                                                                                                   * Copyright 2013-present, Facebook, Inc.
                                                                                                                   * All rights reserved.
                                                                                                                   *
                                                                                                                   * This source code is licensed under the BSD-style license found in the
                                                                                                                   * LICENSE file in the root directory of this source tree. An additional grant
                                                                                                                   * of patent rights can be found in the PATENTS file in the same directory.
                                                                                                                   *
                                                                                                                   * @providesModule CSSPropertyOperations
                                                                                                                   */ 
if ("TURBOPACK compile-time truthy", 1) {
    // 'msTransform' is correct, but the other prefixes should be capitalized
    var badVendoredStyleNamePattern = /^(?:webkit|moz|o)[A-Z]/;
    // style values shouldn't contain a semicolon
    var badStyleValueWithSemicolonPattern = /;\s*$/;
    var warnedStyleNames = {};
    var warnedStyleValues = {};
    var warnedForNaNValue = false;
    var warnHyphenatedStyleName = function warnHyphenatedStyleName(name, owner) {
        if (warnedStyleNames.hasOwnProperty(name) && warnedStyleNames[name]) {
            return;
        }
        warnedStyleNames[name] = true;
        ("TURBOPACK compile-time truthy", 1) ? (0, _warning2.default)(false, 'Unsupported style property %s. Did you mean %s?%s', name, (0, _camelizeStyleName2.default)(name), checkRenderMessage(owner)) : "TURBOPACK unreachable";
    };
    var warnBadVendoredStyleName = function warnBadVendoredStyleName(name, owner) {
        if (warnedStyleNames.hasOwnProperty(name) && warnedStyleNames[name]) {
            return;
        }
        warnedStyleNames[name] = true;
        ("TURBOPACK compile-time truthy", 1) ? (0, _warning2.default)(false, 'Unsupported vendor-prefixed style property %s. Did you mean %s?%s', name, name.charAt(0).toUpperCase() + name.slice(1), checkRenderMessage(owner)) : "TURBOPACK unreachable";
    };
    var warnStyleValueWithSemicolon = function warnStyleValueWithSemicolon(name, value, owner) {
        if (warnedStyleValues.hasOwnProperty(value) && warnedStyleValues[value]) {
            return;
        }
        warnedStyleValues[value] = true;
        ("TURBOPACK compile-time truthy", 1) ? (0, _warning2.default)(false, 'Style property values shouldn\'t contain a semicolon.%s ' + 'Try "%s: %s" instead.', checkRenderMessage(owner), name, value.replace(badStyleValueWithSemicolonPattern, '')) : "TURBOPACK unreachable";
    };
    var warnStyleValueIsNaN = function warnStyleValueIsNaN(name, value, owner) {
        if (warnedForNaNValue) {
            return;
        }
        warnedForNaNValue = true;
        ("TURBOPACK compile-time truthy", 1) ? (0, _warning2.default)(false, '`NaN` is an invalid value for the `%s` css style property.%s', name, checkRenderMessage(owner)) : "TURBOPACK unreachable";
    };
    var checkRenderMessage = function checkRenderMessage(owner) {
        if (owner) {
            var name = owner.getName();
            if (name) {
                return ' Check the render method of `' + name + '`.';
            }
        }
        return '';
    };
    /**
   * @param {string} name
   * @param {*} value
   * @param {ReactDOMComponent} component
   */ var warnValidStyle = function warnValidStyle(name, value, component) {
        //eslint-disable-line no-var
        var owner = void 0;
        if (component) {
            owner = component._currentElement._owner;
        }
        if (name.indexOf('-') > -1) {
            warnHyphenatedStyleName(name, owner);
        } else if (badVendoredStyleNamePattern.test(name)) {
            warnBadVendoredStyleName(name, owner);
        } else if (badStyleValueWithSemicolonPattern.test(value)) {
            warnStyleValueWithSemicolon(name, value, owner);
        }
        if (typeof value === 'number' && isNaN(value)) {
            warnStyleValueIsNaN(name, value, owner);
        }
    };
}
/**
   * Serializes a mapping of style properties for use as inline styles:
   *
   *   > createMarkupForStyles({width: '200px', height: 0})
   *   "width:200px;height:0;"
   *
   * Undefined values are ignored so that declarative programming is easier.
   * The result should be HTML-escaped before insertion into the DOM.
   *
   * @param {object} styles
   * @param {ReactDOMComponent} component
   * @return {?string}
   */ function createMarkupForStyles(styles, component) {
    var serialized = '';
    for(var styleName in styles){
        var isCustomProp = styleName.indexOf('--') === 0;
        if (!styles.hasOwnProperty(styleName)) {
            continue;
        }
        if (styleName === 'label') {
            continue;
        }
        var styleValue = styles[styleName];
        if (("TURBOPACK compile-time value", "development") !== 'production' && !isCustomProp) {
            warnValidStyle(styleName, styleValue, component);
        }
        if (styleValue != null) {
            if (isCustomProp) {
                serialized += styleName + ':' + styleValue + ';';
            } else {
                serialized += processStyleName(styleName) + ':';
                serialized += (0, _dangerousStyleValue2.default)(styleName, styleValue, component) + ';';
            }
        }
    }
    return serialized || null;
}
}),
"[project]/node_modules/glamor/lib/clean.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function(obj) {
    return typeof obj;
} : function(obj) {
    return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};
exports.default = clean;
// Returns true for null, false, undefined and {}
function isFalsy(value) {
    return value === null || value === undefined || value === false || (typeof value === 'undefined' ? 'undefined' : _typeof(value)) === 'object' && Object.keys(value).length === 0;
}
function cleanObject(object) {
    if (isFalsy(object)) return null;
    if ((typeof object === 'undefined' ? 'undefined' : _typeof(object)) !== 'object') return object;
    var acc = {}, keys = Object.keys(object), hasFalsy = false;
    for(var i = 0; i < keys.length; i++){
        var value = object[keys[i]];
        var filteredValue = clean(value);
        if (filteredValue === null || filteredValue !== value) {
            hasFalsy = true;
        }
        if (filteredValue !== null) {
            acc[keys[i]] = filteredValue;
        }
    }
    return Object.keys(acc).length === 0 ? null : hasFalsy ? acc : object;
}
function cleanArray(rules) {
    var hasFalsy = false;
    var filtered = [];
    rules.forEach(function(rule) {
        var filteredRule = clean(rule);
        if (filteredRule === null || filteredRule !== rule) {
            hasFalsy = true;
        }
        if (filteredRule !== null) {
            filtered.push(filteredRule);
        }
    });
    return filtered.length == 0 ? null : hasFalsy ? filtered : rules;
}
// Takes style array or object provided by user and clears all the falsy data 
// If there is no styles left after filtration returns null
function clean(input) {
    return Array.isArray(input) ? cleanArray(input) : cleanObject(input);
}
}),
"[project]/node_modules/glamor/lib/prefixer.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = prefixer;
var _staticData = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/static/staticData.js [app-client] (ecmascript)");
var _staticData2 = _interopRequireDefault(_staticData);
var _prefixProperty = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/utils/prefixProperty.js [app-client] (ecmascript)");
var _prefixProperty2 = _interopRequireDefault(_prefixProperty);
var _prefixValue = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/utils/prefixValue.js [app-client] (ecmascript)");
var _prefixValue2 = _interopRequireDefault(_prefixValue);
var _cursor = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/static/plugins/cursor.js [app-client] (ecmascript)");
var _cursor2 = _interopRequireDefault(_cursor);
var _crossFade = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/static/plugins/crossFade.js [app-client] (ecmascript)");
var _crossFade2 = _interopRequireDefault(_crossFade);
var _filter = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/static/plugins/filter.js [app-client] (ecmascript)");
var _filter2 = _interopRequireDefault(_filter);
var _flex = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/static/plugins/flex.js [app-client] (ecmascript)");
var _flex2 = _interopRequireDefault(_flex);
var _flexboxOld = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/static/plugins/flexboxOld.js [app-client] (ecmascript)");
var _flexboxOld2 = _interopRequireDefault(_flexboxOld);
var _gradient = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/static/plugins/gradient.js [app-client] (ecmascript)");
var _gradient2 = _interopRequireDefault(_gradient);
var _imageSet = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/static/plugins/imageSet.js [app-client] (ecmascript)");
var _imageSet2 = _interopRequireDefault(_imageSet);
var _position = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/static/plugins/position.js [app-client] (ecmascript)");
var _position2 = _interopRequireDefault(_position);
var _sizing = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/static/plugins/sizing.js [app-client] (ecmascript)");
var _sizing2 = _interopRequireDefault(_sizing);
var _transition = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/static/plugins/transition.js [app-client] (ecmascript)");
var _transition2 = _interopRequireDefault(_transition);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var plugins = [
    _crossFade2.default,
    _cursor2.default,
    _filter2.default,
    _flexboxOld2.default,
    _gradient2.default,
    _imageSet2.default,
    _position2.default,
    _sizing2.default,
    _transition2.default,
    _flex2.default
]; // custom facade for inline-style-prefixer
var prefixMap = _staticData2.default.prefixMap;
function prefixer(style) {
    for(var property in style){
        var value = style[property];
        var processedValue = (0, _prefixValue2.default)(plugins, property, value, style, prefixMap);
        // only modify the value if it was touched
        // by any plugin to prevent unnecessary mutations
        if (processedValue) {
            style[property] = processedValue;
        }
        (0, _prefixProperty2.default)(prefixMap, property, style);
    }
    return style;
}
}),
"[project]/node_modules/glamor/lib/plugins.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
Object.defineProperty(exports, "__esModule", {
    value: true
});
var _extends = Object.assign || function(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i];
        for(var key in source){
            if (Object.prototype.hasOwnProperty.call(source, key)) {
                target[key] = source[key];
            }
        }
    }
    return target;
};
exports.PluginSet = PluginSet;
exports.fallbacks = fallbacks;
exports.contentWrap = contentWrap;
exports.prefixes = prefixes;
var _objectAssign = __turbopack_context__.r("[project]/node_modules/next/dist/build/polyfills/object-assign.js [app-client] (ecmascript)");
var _objectAssign2 = _interopRequireDefault(_objectAssign);
var _CSSPropertyOperations = __turbopack_context__.r("[project]/node_modules/glamor/lib/CSSPropertyOperations/index.js [app-client] (ecmascript)");
var _prefixer = __turbopack_context__.r("[project]/node_modules/glamor/lib/prefixer.js [app-client] (ecmascript)");
var _prefixer2 = _interopRequireDefault(_prefixer);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var isDev = function(x) {
    return x === 'development' || !x;
}(("TURBOPACK compile-time value", "development"));
function PluginSet(initial) {
    this.fns = initial || [];
}
(0, _objectAssign2.default)(PluginSet.prototype, {
    add: function add() {
        var _this = this;
        for(var _len = arguments.length, fns = Array(_len), _key = 0; _key < _len; _key++){
            fns[_key] = arguments[_key];
        }
        fns.forEach(function(fn) {
            if (_this.fns.indexOf(fn) >= 0) {
                if (isDev) {
                    console.warn('adding the same plugin again, ignoring'); //eslint-disable-line no-console
                }
            } else {
                _this.fns = [
                    fn
                ].concat(_this.fns);
            }
        });
    },
    remove: function remove(fn) {
        this.fns = this.fns.filter(function(x) {
            return x !== fn;
        });
    },
    clear: function clear() {
        this.fns = [];
    },
    transform: function transform(o) {
        return this.fns.reduce(function(o, fn) {
            return fn(o);
        }, o);
    }
});
function fallbacks(node) {
    var hasArray = Object.keys(node.style).map(function(x) {
        return Array.isArray(node.style[x]);
    }).indexOf(true) >= 0;
    if (hasArray) {
        var style = node.style;
        var flattened = Object.keys(style).reduce(function(o, key) {
            o[key] = Array.isArray(style[key]) ? style[key].join('; ' + (0, _CSSPropertyOperations.processStyleName)(key) + ': ') : style[key];
            return o;
        }, {});
        // todo - 
        // flatten arrays which haven't been flattened yet 
        return (0, _objectAssign2.default)({}, node, {
            style: flattened
        });
    }
    return node;
}
var contentValues = [
    'normal',
    'none',
    'counter',
    'open-quote',
    'close-quote',
    'no-open-quote',
    'no-close-quote',
    'initial',
    'inherit'
];
function contentWrap(node) {
    if (node.style.content) {
        var cont = node.style.content;
        if (contentValues.indexOf(cont) >= 0) {
            return node;
        }
        if (/^(attr|calc|counters?|url)\(/.test(cont)) {
            return node;
        }
        if (cont.charAt(0) === cont.charAt(cont.length - 1) && (cont.charAt(0) === '"' || cont.charAt(0) === "'")) {
            return node;
        }
        return _extends({}, node, {
            style: _extends({}, node.style, {
                content: '"' + cont + '"'
            })
        });
    }
    return node;
}
function prefixes(node) {
    return (0, _objectAssign2.default)({}, node, {
        style: (0, _prefixer2.default)(_extends({}, node.style))
    });
}
}),
"[project]/node_modules/glamor/lib/hash.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = doHash;
// murmurhash2 via https://gist.github.com/raycmorgan/588423
function doHash(str, seed) {
    var m = 0x5bd1e995;
    var r = 24;
    var h = seed ^ str.length;
    var length = str.length;
    var currentIndex = 0;
    while(length >= 4){
        var k = UInt32(str, currentIndex);
        k = Umul32(k, m);
        k ^= k >>> r;
        k = Umul32(k, m);
        h = Umul32(h, m);
        h ^= k;
        currentIndex += 4;
        length -= 4;
    }
    switch(length){
        case 3:
            h ^= UInt16(str, currentIndex);
            h ^= str.charCodeAt(currentIndex + 2) << 16;
            h = Umul32(h, m);
            break;
        case 2:
            h ^= UInt16(str, currentIndex);
            h = Umul32(h, m);
            break;
        case 1:
            h ^= str.charCodeAt(currentIndex);
            h = Umul32(h, m);
            break;
    }
    h ^= h >>> 13;
    h = Umul32(h, m);
    h ^= h >>> 15;
    return h >>> 0;
}
function UInt32(str, pos) {
    return str.charCodeAt(pos++) + (str.charCodeAt(pos++) << 8) + (str.charCodeAt(pos++) << 16) + (str.charCodeAt(pos) << 24);
}
function UInt16(str, pos) {
    return str.charCodeAt(pos++) + (str.charCodeAt(pos++) << 8);
}
function Umul32(n, m) {
    n = n | 0;
    m = m | 0;
    var nlo = n & 0xffff;
    var nhi = n >>> 16;
    var res = nlo * m + ((nhi * m & 0xffff) << 16) | 0;
    return res;
}
}),
"[project]/node_modules/glamor/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.compose = exports.merge = exports.$ = exports.style = exports.presets = exports.keyframes = exports.fontFace = exports.insertGlobal = exports.insertRule = exports.plugins = exports.styleSheet = undefined;
exports.speedy = speedy;
exports.simulations = simulations;
exports.simulate = simulate;
exports.cssLabels = cssLabels;
exports.isLikeRule = isLikeRule;
exports.idFor = idFor;
exports.css = css;
exports.rehydrate = rehydrate;
exports.flush = flush;
exports.select = select;
exports.parent = parent;
exports.media = media;
exports.pseudo = pseudo;
exports.active = active;
exports.any = any;
exports.checked = checked;
exports.disabled = disabled;
exports.empty = empty;
exports.enabled = enabled;
exports._default = _default;
exports.first = first;
exports.firstChild = firstChild;
exports.firstOfType = firstOfType;
exports.fullscreen = fullscreen;
exports.focus = focus;
exports.hover = hover;
exports.indeterminate = indeterminate;
exports.inRange = inRange;
exports.invalid = invalid;
exports.lastChild = lastChild;
exports.lastOfType = lastOfType;
exports.left = left;
exports.link = link;
exports.onlyChild = onlyChild;
exports.onlyOfType = onlyOfType;
exports.optional = optional;
exports.outOfRange = outOfRange;
exports.readOnly = readOnly;
exports.readWrite = readWrite;
exports.required = required;
exports.right = right;
exports.root = root;
exports.scope = scope;
exports.target = target;
exports.valid = valid;
exports.visited = visited;
exports.dir = dir;
exports.lang = lang;
exports.not = not;
exports.nthChild = nthChild;
exports.nthLastChild = nthLastChild;
exports.nthLastOfType = nthLastOfType;
exports.nthOfType = nthOfType;
exports.after = after;
exports.before = before;
exports.firstLetter = firstLetter;
exports.firstLine = firstLine;
exports.selection = selection;
exports.backdrop = backdrop;
exports.placeholder = placeholder;
exports.cssFor = cssFor;
exports.attribsFor = attribsFor;
var _objectAssign = __turbopack_context__.r("[project]/node_modules/next/dist/build/polyfills/object-assign.js [app-client] (ecmascript)");
var _objectAssign2 = _interopRequireDefault(_objectAssign);
var _sheet = __turbopack_context__.r("[project]/node_modules/glamor/lib/sheet.js [app-client] (ecmascript)");
var _CSSPropertyOperations = __turbopack_context__.r("[project]/node_modules/glamor/lib/CSSPropertyOperations/index.js [app-client] (ecmascript)");
var _clean = __turbopack_context__.r("[project]/node_modules/glamor/lib/clean.js [app-client] (ecmascript)");
var _clean2 = _interopRequireDefault(_clean);
var _plugins = __turbopack_context__.r("[project]/node_modules/glamor/lib/plugins.js [app-client] (ecmascript)");
var _hash = __turbopack_context__.r("[project]/node_modules/glamor/lib/hash.js [app-client] (ecmascript)");
var _hash2 = _interopRequireDefault(_hash);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function _toConsumableArray(arr) {
    if (Array.isArray(arr)) {
        for(var i = 0, arr2 = Array(arr.length); i < arr.length; i++){
            arr2[i] = arr[i];
        }
        return arr2;
    } else {
        return Array.from(arr);
    }
}
function _defineProperty(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/* stylesheet */ var styleSheet = exports.styleSheet = new _sheet.StyleSheet();
// an isomorphic StyleSheet shim. hides all the nitty gritty.
// /**************** LIFTOFF IN 3... 2... 1... ****************/
styleSheet.inject(); //eslint-disable-line indent
// /****************      TO THE MOOOOOOON     ****************/
// convenience function to toggle speedy
function speedy(bool) {
    return styleSheet.speedy(bool);
}
// plugins
// we include these by default
var plugins = exports.plugins = styleSheet.plugins = new _plugins.PluginSet([
    _plugins.prefixes,
    _plugins.contentWrap,
    _plugins.fallbacks
]);
plugins.media = new _plugins.PluginSet(); // neat! media, font-face, keyframes
plugins.fontFace = new _plugins.PluginSet();
plugins.keyframes = new _plugins.PluginSet([
    _plugins.prefixes,
    _plugins.fallbacks
]);
// define some constants
var isDev = ("TURBOPACK compile-time value", "development") === 'development' || !("TURBOPACK compile-time value", "development");
var isTest = ("TURBOPACK compile-time value", "development") === 'test';
var isBrowser = typeof window !== 'undefined';
/**** simulations  ****/ // a flag to enable simulation meta tags on dom nodes
// defaults to true in dev mode. recommend *not* to
// toggle often.
var canSimulate = isDev;
// we use these flags for issuing warnings when simulate is called
// in prod / in incorrect order
var warned1 = false, warned2 = false;
// toggles simulation activity. shouldn't be needed in most cases
function simulations() {
    var bool = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
    canSimulate = !!bool;
}
// use this on dom nodes to 'simulate' pseudoclasses
// <div {...hover({ color: 'red' })} {...simulate('hover', 'visited')}>...</div>
// you can even send in some weird ones, as long as it's in simple format
// and matches an existing rule on the element
// eg simulate('nthChild2', ':hover:active') etc
function simulate() {
    for(var _len = arguments.length, pseudos = Array(_len), _key = 0; _key < _len; _key++){
        pseudos[_key] = arguments[_key];
    }
    pseudos = (0, _clean2.default)(pseudos);
    if (!pseudos) return {};
    if (!canSimulate) {
        if (!warned1) {
            console.warn('can\'t simulate without once calling simulations(true)'); //eslint-disable-line no-console
            warned1 = true;
        }
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        return {};
    }
    return pseudos.reduce(function(o, p) {
        return o['data-simulate-' + simple(p)] = '', o;
    }, {});
}
/**** labels ****/ // toggle for debug labels.
// *shouldn't* have to mess with this manually
var hasLabels = isDev;
function cssLabels(bool) {
    hasLabels = !!bool;
}
// takes a string, converts to lowercase, strips out nonalphanumeric.
function simple(str) {
    var char = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
    return str.toLowerCase().replace(/[^a-z0-9]/g, char);
}
// hashes a string to something 'unique'
// we use this to generate ids for styles
function hashify(obj) {
    var str = JSON.stringify(obj);
    var toRet = (0, _hash2.default)(str).toString(36);
    if (obj.label && obj.label.length > 0 && isDev) {
        return simple(obj.label.join('.'), '-') + '-' + toRet;
    }
    return toRet;
}
// of shape { 'data-css-<id>': '' }
function isLikeRule(rule) {
    var keys = Object.keys(rule).filter(function(x) {
        return x !== 'toString';
    });
    if (keys.length !== 1) {
        return false;
    }
    return !!/data\-css\-([a-zA-Z0-9\-_]+)/.exec(keys[0]);
}
// extracts id from a { 'data-css-<id>': ''} like object
function idFor(rule) {
    var keys = Object.keys(rule).filter(function(x) {
        return x !== 'toString';
    });
    if (keys.length !== 1) throw new Error('not a rule');
    var regex = /data\-css\-([a-zA-Z0-9\-_]+)/;
    var match = regex.exec(keys[0]);
    if (!match) throw new Error('not a rule');
    return match[1];
}
// from https://github.com/j2css/j2c/blob/5d381c2d721d04b54fabe6a165d587247c3087cb/src/helpers.js#L28-L61
// "Tokenizes" the selectors into parts relevant for the next function.
// Strings and comments are matched, but ignored afterwards.
// This is not a full tokenizers. It only recognizes comas, parentheses,
// strings and comments.
// regexp generated by scripts/regexps.js then trimmed by hand
var selectorTokenizer = /[(),]|"(?:\\.|[^"\n])*"|'(?:\\.|[^'\n])*'|\/\*[\s\S]*?\*\//g;
/**
 * This will split a coma-separated selector list into individual selectors,
 * ignoring comas in strings, comments and in :pseudo-selectors(parameter, lists).
 *
 * @param {string} selector
 * @return {string[]}
 */ function splitSelector(selector) {
    if (selector.indexOf(',') === -1) {
        return [
            selector
        ];
    }
    var indices = [], res = [], inParen = 0, o;
    /*eslint-disable no-cond-assign*/ while(o = selectorTokenizer.exec(selector)){
        /*eslint-enable no-cond-assign*/ switch(o[0]){
            case '(':
                inParen++;
                break;
            case ')':
                inParen--;
                break;
            case ',':
                if (inParen) break;
                indices.push(o.index);
        }
    }
    for(o = indices.length; o--;){
        res.unshift(selector.slice(indices[o] + 1));
        selector = selector.slice(0, indices[o]);
    }
    res.unshift(selector);
    return res;
}
function selector(id, path) {
    if (!id) {
        return path.replace(/\&/g, '');
    }
    if (!path) return '.css-' + id + ',[data-css-' + id + ']';
    var x = splitSelector(path).map(function(x) {
        return x.indexOf('&') >= 0 ? [
            x.replace(/\&/mg, '.css-' + id),
            x.replace(/\&/mg, '[data-css-' + id + ']')
        ].join(',') // todo - make sure each sub selector has an &
         : '.css-' + id + x + ',[data-css-' + id + ']' + x;
    }).join(',');
    if (canSimulate && /^\&\:/.exec(path) && !/\s/.exec(path)) {
        x += ',.css-' + id + '[data-simulate-' + simple(path) + '],[data-css-' + id + '][data-simulate-' + simple(path) + ']';
    }
    return x;
}
// end https://github.com/j2css/j2c/blob/5d381c2d721d04b54fabe6a165d587247c3087cb/src/helpers.js#L28-L61
function toCSS(_ref) {
    var selector = _ref.selector, style = _ref.style;
    var result = plugins.transform({
        selector: selector,
        style: style
    });
    return result.selector + '{' + (0, _CSSPropertyOperations.createMarkupForStyles)(result.style) + '}';
}
function deconstruct(style) {
    // we can be sure it's not infinitely nested here
    var plain = void 0, selects = void 0, medias = void 0, supports = void 0;
    Object.keys(style).forEach(function(key) {
        if (key.indexOf('&') >= 0) {
            selects = selects || {};
            selects[key] = style[key];
        } else if (key.indexOf('@media') === 0) {
            medias = medias || {};
            medias[key] = deconstruct(style[key]);
        } else if (key.indexOf('@supports') === 0) {
            supports = supports || {};
            supports[key] = deconstruct(style[key]);
        } else if (key === 'label') {
            if (style.label.length > 0) {
                plain = plain || {};
                plain.label = hasLabels ? style.label.join('.') : '';
            }
        } else {
            plain = plain || {};
            plain[key] = style[key];
        }
    });
    return {
        plain: plain,
        selects: selects,
        medias: medias,
        supports: supports
    };
}
function deconstructedStyleToCSS(id, style) {
    var css = [];
    // plugins here
    var plain = style.plain, selects = style.selects, medias = style.medias, supports = style.supports;
    if (plain) {
        css.push(toCSS({
            style: plain,
            selector: selector(id)
        }));
    }
    if (selects) {
        Object.keys(selects).forEach(function(key) {
            return css.push(toCSS({
                style: selects[key],
                selector: selector(id, key)
            }));
        });
    }
    if (medias) {
        Object.keys(medias).forEach(function(key) {
            return css.push(key + '{' + deconstructedStyleToCSS(id, medias[key]).join('') + '}');
        });
    }
    if (supports) {
        Object.keys(supports).forEach(function(key) {
            return css.push(key + '{' + deconstructedStyleToCSS(id, supports[key]).join('') + '}');
        });
    }
    return css;
}
// this cache to track which rules have
// been inserted into the stylesheet
var inserted = styleSheet.inserted = {};
// and helpers to insert rules into said styleSheet
function insert(spec) {
    if (!inserted[spec.id]) {
        inserted[spec.id] = true;
        var deconstructed = deconstruct(spec.style);
        var rules = deconstructedStyleToCSS(spec.id, deconstructed);
        inserted[spec.id] = isBrowser ? true : rules;
        rules.forEach(function(cssRule) {
            return styleSheet.insert(cssRule);
        });
    }
}
// a simple cache to store generated rules
var registered = styleSheet.registered = {};
function register(spec) {
    if (!registered[spec.id]) {
        registered[spec.id] = spec;
    }
}
function _getRegistered(rule) {
    if (isLikeRule(rule)) {
        var ret = registered[idFor(rule)];
        if (ret == null) {
            throw new Error('[glamor] an unexpected rule cache miss occurred. This is probably a sign of multiple glamor instances in your app. See https://github.com/threepointone/glamor/issues/79');
        }
        return ret;
    }
    return rule;
}
// todo - perf
var ruleCache = {};
function toRule(spec) {
    register(spec);
    insert(spec);
    if (ruleCache[spec.id]) {
        return ruleCache[spec.id];
    }
    var ret = _defineProperty({}, 'data-css-' + spec.id, hasLabels ? spec.label || '' : '');
    Object.defineProperty(ret, 'toString', {
        enumerable: false,
        value: function value() {
            return 'css-' + spec.id;
        }
    });
    ruleCache[spec.id] = ret;
    return ret;
}
function log() {
    //eslint-disable-line no-unused-vars
    console.log(this); //eslint-disable-line no-console
    return this;
}
function isSelector(key) {
    var possibles = [
        ':',
        '.',
        '[',
        '>',
        ' '
    ], found = false, ch = key.charAt(0);
    for(var i = 0; i < possibles.length; i++){
        if (ch === possibles[i]) {
            found = true;
            break;
        }
    }
    return found || key.indexOf('&') >= 0;
}
function joinSelectors(a, b) {
    var as = splitSelector(a).map(function(a) {
        return !(a.indexOf('&') >= 0) ? '&' + a : a;
    });
    var bs = splitSelector(b).map(function(b) {
        return !(b.indexOf('&') >= 0) ? '&' + b : b;
    });
    return bs.reduce(function(arr, b) {
        return arr.concat(as.map(function(a) {
            return b.replace(/\&/g, a);
        }));
    }, []).join(',');
}
function joinMediaQueries(a, b) {
    return a ? '@media ' + a.substring(6) + ' and ' + b.substring(6) : b;
}
function isMediaQuery(key) {
    return key.indexOf('@media') === 0;
}
function isSupports(key) {
    return key.indexOf('@supports') === 0;
}
function joinSupports(a, b) {
    return a ? '@supports ' + a.substring(9) + ' and ' + b.substring(9) : b;
}
// flatten a nested array
function flatten(inArr) {
    var arr = [];
    for(var i = 0; i < inArr.length; i++){
        if (Array.isArray(inArr[i])) arr = arr.concat(flatten(inArr[i]));
        else arr = arr.concat(inArr[i]);
    }
    return arr;
}
var prefixedPseudoSelectors = {
    '::placeholder': [
        '::-webkit-input-placeholder',
        '::-moz-placeholder',
        '::-ms-input-placeholder'
    ],
    ':fullscreen': [
        ':-webkit-full-screen',
        ':-moz-full-screen',
        ':-ms-fullscreen'
    ]
};
function build(dest, _ref2) {
    var _ref2$selector = _ref2.selector, selector = _ref2$selector === undefined ? '' : _ref2$selector, _ref2$mq = _ref2.mq, mq = _ref2$mq === undefined ? '' : _ref2$mq, _ref2$supp = _ref2.supp, supp = _ref2$supp === undefined ? '' : _ref2$supp, _ref2$src = _ref2.src, src = _ref2$src === undefined ? {} : _ref2$src;
    if (!Array.isArray(src)) {
        src = [
            src
        ];
    }
    src = flatten(src);
    src.forEach(function(_src) {
        if (isLikeRule(_src)) {
            var reg = _getRegistered(_src);
            if (reg.type !== 'css') {
                throw new Error('cannot merge this rule');
            }
            _src = reg.style;
        }
        _src = (0, _clean2.default)(_src);
        if (_src && _src.composes) {
            build(dest, {
                selector: selector,
                mq: mq,
                supp: supp,
                src: _src.composes
            });
        }
        Object.keys(_src || {}).forEach(function(key) {
            if (isSelector(key)) {
                if (prefixedPseudoSelectors[key]) {
                    prefixedPseudoSelectors[key].forEach(function(p) {
                        return build(dest, {
                            selector: joinSelectors(selector, p),
                            mq: mq,
                            supp: supp,
                            src: _src[key]
                        });
                    });
                }
                build(dest, {
                    selector: joinSelectors(selector, key),
                    mq: mq,
                    supp: supp,
                    src: _src[key]
                });
            } else if (isMediaQuery(key)) {
                build(dest, {
                    selector: selector,
                    mq: joinMediaQueries(mq, key),
                    supp: supp,
                    src: _src[key]
                });
            } else if (isSupports(key)) {
                build(dest, {
                    selector: selector,
                    mq: mq,
                    supp: joinSupports(supp, key),
                    src: _src[key]
                });
            } else if (key === 'composes') {
            // ignore, we already dealth with it
            } else {
                var _dest = dest;
                if (supp) {
                    _dest[supp] = _dest[supp] || {};
                    _dest = _dest[supp];
                }
                if (mq) {
                    _dest[mq] = _dest[mq] || {};
                    _dest = _dest[mq];
                }
                if (selector) {
                    _dest[selector] = _dest[selector] || {};
                    _dest = _dest[selector];
                }
                if (key === 'label') {
                    if (hasLabels) {
                        dest.label = dest.label.concat(_src.label);
                    }
                } else {
                    _dest[key] = _src[key];
                }
            }
        });
    });
}
function _css(rules) {
    var style = {
        label: []
    };
    build(style, {
        src: rules
    }); // mutative! but worth it.
    var spec = {
        id: hashify(style),
        style: style,
        label: hasLabels ? style.label.join('.') : '',
        type: 'css'
    };
    return toRule(spec);
}
var nullrule = {
};
Object.defineProperty(nullrule, 'toString', {
    enumerable: false,
    value: function value() {
        return 'css-nil';
    }
});
var inputCaches = typeof WeakMap !== 'undefined' ? [
    nullrule,
    new WeakMap(),
    new WeakMap(),
    new WeakMap()
] : [
    nullrule
];
var warnedWeakMapError = false;
function multiIndexCache(fn) {
    return function(args) {
        if (inputCaches[args.length]) {
            var coi = inputCaches[args.length];
            var ctr = 0;
            while(ctr < args.length - 1){
                if (!coi.has(args[ctr])) {
                    coi.set(args[ctr], new WeakMap());
                }
                coi = coi.get(args[ctr]);
                ctr++;
            }
            if (coi.has(args[args.length - 1])) {
                var ret = coi.get(args[ctr]);
                if (registered[ret.toString().substring(4)]) {
                    // make sure it hasn't been flushed
                    return ret;
                }
            }
        }
        var value = fn(args);
        if (inputCaches[args.length]) {
            var _ctr = 0, _coi = inputCaches[args.length];
            while(_ctr < args.length - 1){
                _coi = _coi.get(args[_ctr]);
                _ctr++;
            }
            try {
                _coi.set(args[_ctr], value);
            } catch (err) {
                if (isDev && !warnedWeakMapError) {
                    var _console;
                    warnedWeakMapError = true;
                    (_console = console).warn.apply(_console, [
                        'failed setting the WeakMap cache for args:'
                    ].concat(_toConsumableArray(args))); // eslint-disable-line no-console
                    console.warn('this should NOT happen, please file a bug on the github repo.'); // eslint-disable-line no-console
                }
            }
        }
        return value;
    };
}
var cachedCss = typeof WeakMap !== 'undefined' ? multiIndexCache(_css) : _css;
function css() {
    for(var _len2 = arguments.length, rules = Array(_len2), _key2 = 0; _key2 < _len2; _key2++){
        rules[_key2] = arguments[_key2];
    }
    if (rules[0] && rules[0].length && rules[0].raw) {
        throw new Error('you forgot to include glamor/babel in your babel plugins.');
    }
    rules = (0, _clean2.default)(rules);
    if (!rules) {
        return nullrule;
    }
    return cachedCss(rules);
}
css.insert = function(css) {
    var spec = {
        id: hashify(css),
        css: css,
        type: 'raw'
    };
    register(spec);
    if (!inserted[spec.id]) {
        styleSheet.insert(spec.css);
        inserted[spec.id] = isBrowser ? true : [
            spec.css
        ];
    }
};
var insertRule = exports.insertRule = css.insert;
css.global = function(selector, style) {
    style = (0, _clean2.default)(style);
    if (style) {
        return css.insert(toCSS({
            selector: selector,
            style: style
        }));
    }
};
var insertGlobal = exports.insertGlobal = css.global;
function insertKeyframe(spec) {
    if (!inserted[spec.id]) {
        var inner = Object.keys(spec.keyframes).map(function(kf) {
            var result = plugins.keyframes.transform({
                id: spec.id,
                name: kf,
                style: spec.keyframes[kf]
            });
            return result.name + '{' + (0, _CSSPropertyOperations.createMarkupForStyles)(result.style) + '}';
        }).join('');
        var rules = [
            '-webkit-',
            '-moz-',
            '-o-',
            ''
        ].map(function(prefix) {
            return '@' + prefix + 'keyframes ' + (spec.name + '_' + spec.id) + '{' + inner + '}';
        });
        rules.forEach(function(rule) {
            return styleSheet.insert(rule);
        });
        inserted[spec.id] = isBrowser ? true : rules;
    }
}
css.keyframes = function(name, kfs) {
    if (!kfs) {
        kfs = name, name = 'animation';
    }
    // do not ignore empty keyframe definitions for now.
    kfs = (0, _clean2.default)(kfs) || {};
    var spec = {
        id: hashify({
            name: name,
            kfs: kfs
        }),
        type: 'keyframes',
        name: name,
        keyframes: kfs
    };
    register(spec);
    insertKeyframe(spec);
    return name + '_' + spec.id;
};
// we don't go all out for fonts as much, giving a simple font loading strategy
// use a fancier lib if you need moar power
css.fontFace = function(font) {
    font = (0, _clean2.default)(font);
    var spec = {
        id: hashify(font),
        type: 'font-face',
        font: font
    };
    register(spec);
    insertFontFace(spec);
    return font.fontFamily;
};
var fontFace = exports.fontFace = css.fontFace;
var keyframes = exports.keyframes = css.keyframes;
function insertFontFace(spec) {
    if (!inserted[spec.id]) {
        var rule = '@font-face{' + (0, _CSSPropertyOperations.createMarkupForStyles)(spec.font) + '}';
        styleSheet.insert(rule);
        inserted[spec.id] = isBrowser ? true : [
            rule
        ];
    }
}
// rehydrate the insertion cache with ids sent from
// renderStatic / renderStaticOptimized
function rehydrate(ids) {
    // load up ids
    (0, _objectAssign2.default)(inserted, ids.reduce(function(o, i) {
        return o[i] = true, o;
    }, {}));
// assume css loaded separately
}
// clears out the cache and empties the stylesheet
// best for tests, though there might be some value for SSR.
function flush() {
    inserted = styleSheet.inserted = {};
    registered = styleSheet.registered = {};
    ruleCache = {};
    styleSheet.flush();
    styleSheet.inject();
}
var presets = exports.presets = {
    mobile: '(min-width: 400px)',
    Mobile: '@media (min-width: 400px)',
    phablet: '(min-width: 550px)',
    Phablet: '@media (min-width: 550px)',
    tablet: '(min-width: 750px)',
    Tablet: '@media (min-width: 750px)',
    desktop: '(min-width: 1000px)',
    Desktop: '@media (min-width: 1000px)',
    hd: '(min-width: 1200px)',
    Hd: '@media (min-width: 1200px)'
};
var style = exports.style = css;
function select(selector) {
    for(var _len3 = arguments.length, styles = Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++){
        styles[_key3 - 1] = arguments[_key3];
    }
    if (!selector) {
        return style(styles);
    }
    return css(_defineProperty({}, selector, styles));
}
var $ = exports.$ = select;
function parent(selector) {
    for(var _len4 = arguments.length, styles = Array(_len4 > 1 ? _len4 - 1 : 0), _key4 = 1; _key4 < _len4; _key4++){
        styles[_key4 - 1] = arguments[_key4];
    }
    return css(_defineProperty({}, selector + ' &', styles));
}
var merge = exports.merge = css;
var compose = exports.compose = css;
function media(query) {
    for(var _len5 = arguments.length, rules = Array(_len5 > 1 ? _len5 - 1 : 0), _key5 = 1; _key5 < _len5; _key5++){
        rules[_key5 - 1] = arguments[_key5];
    }
    return css(_defineProperty({}, '@media ' + query, rules));
}
function pseudo(selector) {
    for(var _len6 = arguments.length, styles = Array(_len6 > 1 ? _len6 - 1 : 0), _key6 = 1; _key6 < _len6; _key6++){
        styles[_key6 - 1] = arguments[_key6];
    }
    return css(_defineProperty({}, selector, styles));
}
// allllll the pseudoclasses
function active(x) {
    return pseudo(':active', x);
}
function any(x) {
    return pseudo(':any', x);
}
function checked(x) {
    return pseudo(':checked', x);
}
function disabled(x) {
    return pseudo(':disabled', x);
}
function empty(x) {
    return pseudo(':empty', x);
}
function enabled(x) {
    return pseudo(':enabled', x);
}
function _default(x) {
    return pseudo(':default', x); // note '_default' name
}
function first(x) {
    return pseudo(':first', x);
}
function firstChild(x) {
    return pseudo(':first-child', x);
}
function firstOfType(x) {
    return pseudo(':first-of-type', x);
}
function fullscreen(x) {
    return pseudo(':fullscreen', x);
}
function focus(x) {
    return pseudo(':focus', x);
}
function hover(x) {
    return pseudo(':hover', x);
}
function indeterminate(x) {
    return pseudo(':indeterminate', x);
}
function inRange(x) {
    return pseudo(':in-range', x);
}
function invalid(x) {
    return pseudo(':invalid', x);
}
function lastChild(x) {
    return pseudo(':last-child', x);
}
function lastOfType(x) {
    return pseudo(':last-of-type', x);
}
function left(x) {
    return pseudo(':left', x);
}
function link(x) {
    return pseudo(':link', x);
}
function onlyChild(x) {
    return pseudo(':only-child', x);
}
function onlyOfType(x) {
    return pseudo(':only-of-type', x);
}
function optional(x) {
    return pseudo(':optional', x);
}
function outOfRange(x) {
    return pseudo(':out-of-range', x);
}
function readOnly(x) {
    return pseudo(':read-only', x);
}
function readWrite(x) {
    return pseudo(':read-write', x);
}
function required(x) {
    return pseudo(':required', x);
}
function right(x) {
    return pseudo(':right', x);
}
function root(x) {
    return pseudo(':root', x);
}
function scope(x) {
    return pseudo(':scope', x);
}
function target(x) {
    return pseudo(':target', x);
}
function valid(x) {
    return pseudo(':valid', x);
}
function visited(x) {
    return pseudo(':visited', x);
}
// parameterized pseudoclasses
function dir(p, x) {
    return pseudo(':dir(' + p + ')', x);
}
function lang(p, x) {
    return pseudo(':lang(' + p + ')', x);
}
function not(p, x) {
    // should this be a plugin?
    var selector = p.split(',').map(function(x) {
        return x.trim();
    }).map(function(x) {
        return ':not(' + x + ')';
    });
    if (selector.length === 1) {
        return pseudo(':not(' + p + ')', x);
    }
    return select(selector.join(''), x);
}
function nthChild(p, x) {
    return pseudo(':nth-child(' + p + ')', x);
}
function nthLastChild(p, x) {
    return pseudo(':nth-last-child(' + p + ')', x);
}
function nthLastOfType(p, x) {
    return pseudo(':nth-last-of-type(' + p + ')', x);
}
function nthOfType(p, x) {
    return pseudo(':nth-of-type(' + p + ')', x);
}
// pseudoelements
function after(x) {
    return pseudo('::after', x);
}
function before(x) {
    return pseudo('::before', x);
}
function firstLetter(x) {
    return pseudo('::first-letter', x);
}
function firstLine(x) {
    return pseudo('::first-line', x);
}
function selection(x) {
    return pseudo('::selection', x);
}
function backdrop(x) {
    return pseudo('::backdrop', x);
}
function placeholder(x) {
    // https://github.com/threepointone/glamor/issues/14
    return css({
        '::placeholder': x
    });
}
/*** helpers for web components ***/ // https://github.com/threepointone/glamor/issues/16
function cssFor() {
    for(var _len7 = arguments.length, rules = Array(_len7), _key7 = 0; _key7 < _len7; _key7++){
        rules[_key7] = arguments[_key7];
    }
    rules = (0, _clean2.default)(rules);
    return rules ? rules.map(function(r) {
        var style = {
            label: []
        };
        build(style, {
            src: r
        }); // mutative! but worth it.
        return deconstructedStyleToCSS(hashify(style), deconstruct(style)).join('');
    }).join('') : '';
}
function attribsFor() {
    for(var _len8 = arguments.length, rules = Array(_len8), _key8 = 0; _key8 < _len8; _key8++){
        rules[_key8] = arguments[_key8];
    }
    rules = (0, _clean2.default)(rules);
    var htmlAttributes = rules ? rules.map(function(rule) {
        idFor(rule); // throwaway check for rule
        var key = Object.keys(rule)[0], value = rule[key];
        return key + '="' + (value || '') + '"';
    }).join(' ') : '';
    return htmlAttributes;
}
}),
"[project]/node_modules/glamor/node_modules/fbjs/lib/camelize.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @typechecks
 */ var _hyphenPattern = /-(.)/g;
/**
 * Camelcases a hyphenated string, for example:
 *
 *   > camelize('background-color')
 *   < "backgroundColor"
 *
 * @param {string} string
 * @return {string}
 */ function camelize(string) {
    return string.replace(_hyphenPattern, function(_, character) {
        return character.toUpperCase();
    });
}
module.exports = camelize;
}),
"[project]/node_modules/glamor/node_modules/fbjs/lib/camelizeStyleName.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @typechecks
 */ var camelize = __turbopack_context__.r("[project]/node_modules/glamor/node_modules/fbjs/lib/camelize.js [app-client] (ecmascript)");
var msPattern = /^-ms-/;
/**
 * Camelcases a hyphenated CSS property name, for example:
 *
 *   > camelizeStyleName('background-color')
 *   < "backgroundColor"
 *   > camelizeStyleName('-moz-transition')
 *   < "MozTransition"
 *   > camelizeStyleName('-ms-transition')
 *   < "msTransition"
 *
 * As Andi Smith suggests
 * (http://www.andismith.com/blog/2012/02/modernizr-prefixed/), an `-ms` prefix
 * is converted to lowercase `ms`.
 *
 * @param {string} string
 * @return {string}
 */ function camelizeStyleName(string) {
    return camelize(string.replace(msPattern, 'ms-'));
}
module.exports = camelizeStyleName;
}),
"[project]/node_modules/glamor/node_modules/fbjs/lib/emptyFunction.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * 
 */ function makeEmptyFunction(arg) {
    return function() {
        return arg;
    };
}
/**
 * This function accepts and discards inputs; it has no side effects. This is
 * primarily useful idiomatically for overridable function endpoints which
 * always need to be callable, since JS lacks a null-call idiom ala Cocoa.
 */ var emptyFunction = function emptyFunction() {};
emptyFunction.thatReturns = makeEmptyFunction;
emptyFunction.thatReturnsFalse = makeEmptyFunction(false);
emptyFunction.thatReturnsTrue = makeEmptyFunction(true);
emptyFunction.thatReturnsNull = makeEmptyFunction(null);
emptyFunction.thatReturnsThis = function() {
    return this;
};
emptyFunction.thatReturnsArgument = function(arg) {
    return arg;
};
module.exports = emptyFunction;
}),
"[project]/node_modules/glamor/node_modules/fbjs/lib/warning.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */ 'use strict';
var emptyFunction = __turbopack_context__.r("[project]/node_modules/glamor/node_modules/fbjs/lib/emptyFunction.js [app-client] (ecmascript)");
/**
 * Similar to invariant but only logs a warning if the condition is not met.
 * This can be used to log issues in development environments in critical
 * paths. Removing the logging code for production environments will keep the
 * same logic and follow the same code paths.
 */ var warning = emptyFunction;
if ("TURBOPACK compile-time truthy", 1) {
    var printWarning = function printWarning(format) {
        for(var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
            args[_key - 1] = arguments[_key];
        }
        var argIndex = 0;
        var message = 'Warning: ' + format.replace(/%s/g, function() {
            return args[argIndex++];
        });
        if (typeof console !== 'undefined') {
            console.error(message);
        }
        try {
            // --- Welcome to debugging React ---
            // This error was thrown as a convenience so that you can use this stack
            // to find the callsite that caused this warning to fire.
            throw new Error(message);
        } catch (x) {}
    };
    warning = function warning(condition, format) {
        if (format === undefined) {
            throw new Error('`warning(condition, format, ...args)` requires a warning ' + 'message argument');
        }
        if (format.indexOf('Failed Composite propType: ') === 0) {
            return; // Ignore CompositeComponent proptype check.
        }
        if (!condition) {
            for(var _len2 = arguments.length, args = Array(_len2 > 2 ? _len2 - 2 : 0), _key2 = 2; _key2 < _len2; _key2++){
                args[_key2 - 2] = arguments[_key2];
            }
            printWarning.apply(undefined, [
                format
            ].concat(args));
        }
    };
}
module.exports = warning;
}),
"[project]/node_modules/glamor/node_modules/fbjs/lib/hyphenate.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @typechecks
 */ var _uppercasePattern = /([A-Z])/g;
/**
 * Hyphenates a camelcased string, for example:
 *
 *   > hyphenate('backgroundColor')
 *   < "background-color"
 *
 * For CSS style names, use `hyphenateStyleName` instead which works properly
 * with all vendor prefixes, including `ms`.
 *
 * @param {string} string
 * @return {string}
 */ function hyphenate(string) {
    return string.replace(_uppercasePattern, '-$1').toLowerCase();
}
module.exports = hyphenate;
}),
"[project]/node_modules/glamor/node_modules/fbjs/lib/hyphenateStyleName.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @typechecks
 */ var hyphenate = __turbopack_context__.r("[project]/node_modules/glamor/node_modules/fbjs/lib/hyphenate.js [app-client] (ecmascript)");
var msPattern = /^ms-/;
/**
 * Hyphenates a camelcased CSS property name, for example:
 *
 *   > hyphenateStyleName('backgroundColor')
 *   < "background-color"
 *   > hyphenateStyleName('MozTransition')
 *   < "-moz-transition"
 *   > hyphenateStyleName('msTransition')
 *   < "-ms-transition"
 *
 * As Modernizr suggests (http://modernizr.com/docs/#prefixed), an `ms` prefix
 * is converted to `-ms-`.
 *
 * @param {string} string
 * @return {string}
 */ function hyphenateStyleName(string) {
    return hyphenate(string).replace(msPattern, '-ms-');
}
module.exports = hyphenateStyleName;
}),
"[project]/node_modules/glamor/node_modules/fbjs/lib/memoizeStringOnly.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * 
 * @typechecks static-only
 */ /**
 * Memoizes the return value of a function that accepts one string argument.
 */ function memoizeStringOnly(callback) {
    var cache = {};
    return function(string) {
        if (!cache.hasOwnProperty(string)) {
            cache[string] = callback.call(this, string);
        }
        return cache[string];
    };
}
module.exports = memoizeStringOnly;
}),
"[project]/node_modules/inline-style-prefixer/static/staticData.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
var w = [
    "Webkit"
];
var m = [
    "Moz"
];
var ms = [
    "ms"
];
var wm = [
    "Webkit",
    "Moz"
];
var wms = [
    "Webkit",
    "ms"
];
var wmms = [
    "Webkit",
    "Moz",
    "ms"
];
exports.default = {
    plugins: [],
    prefixMap: {
        "appearance": wm,
        "userSelect": wmms,
        "textEmphasisPosition": w,
        "textEmphasis": w,
        "textEmphasisStyle": w,
        "textEmphasisColor": w,
        "boxDecorationBreak": w,
        "clipPath": w,
        "maskImage": w,
        "maskMode": w,
        "maskRepeat": w,
        "maskPosition": w,
        "maskClip": w,
        "maskOrigin": w,
        "maskSize": w,
        "maskComposite": w,
        "mask": w,
        "maskBorderSource": w,
        "maskBorderMode": w,
        "maskBorderSlice": w,
        "maskBorderWidth": w,
        "maskBorderOutset": w,
        "maskBorderRepeat": w,
        "maskBorder": w,
        "maskType": w,
        "textDecorationStyle": w,
        "textDecorationSkip": w,
        "textDecorationLine": w,
        "textDecorationColor": w,
        "filter": w,
        "fontFeatureSettings": w,
        "breakAfter": wmms,
        "breakBefore": wmms,
        "breakInside": wmms,
        "columnCount": wm,
        "columnFill": wm,
        "columnGap": wm,
        "columnRule": wm,
        "columnRuleColor": wm,
        "columnRuleStyle": wm,
        "columnRuleWidth": wm,
        "columns": wm,
        "columnSpan": wm,
        "columnWidth": wm,
        "writingMode": wms,
        "flex": w,
        "flexBasis": w,
        "flexDirection": w,
        "flexGrow": w,
        "flexFlow": w,
        "flexShrink": w,
        "flexWrap": w,
        "alignContent": w,
        "alignItems": w,
        "alignSelf": w,
        "justifyContent": w,
        "order": w,
        "transform": w,
        "transformOrigin": w,
        "transformOriginX": w,
        "transformOriginY": w,
        "backfaceVisibility": w,
        "perspective": w,
        "perspectiveOrigin": w,
        "transformStyle": w,
        "transformOriginZ": w,
        "animation": w,
        "animationDelay": w,
        "animationDirection": w,
        "animationFillMode": w,
        "animationDuration": w,
        "animationIterationCount": w,
        "animationName": w,
        "animationPlayState": w,
        "animationTimingFunction": w,
        "backdropFilter": w,
        "fontKerning": w,
        "scrollSnapType": wms,
        "scrollSnapPointsX": wms,
        "scrollSnapPointsY": wms,
        "scrollSnapDestination": wms,
        "scrollSnapCoordinate": wms,
        "shapeImageThreshold": w,
        "shapeImageMargin": w,
        "shapeImageOutside": w,
        "hyphens": wmms,
        "flowInto": wms,
        "flowFrom": wms,
        "regionFragment": wms,
        "textAlignLast": m,
        "tabSize": m,
        "wrapFlow": ms,
        "wrapThrough": ms,
        "wrapMargin": ms,
        "gridTemplateColumns": ms,
        "gridTemplateRows": ms,
        "gridTemplateAreas": ms,
        "gridTemplate": ms,
        "gridAutoColumns": ms,
        "gridAutoRows": ms,
        "gridAutoFlow": ms,
        "grid": ms,
        "gridRowStart": ms,
        "gridColumnStart": ms,
        "gridRowEnd": ms,
        "gridRow": ms,
        "gridColumn": ms,
        "gridColumnEnd": ms,
        "gridColumnGap": ms,
        "gridRowGap": ms,
        "gridArea": ms,
        "gridGap": ms,
        "textSizeAdjust": wms,
        "borderImage": w,
        "borderImageOutset": w,
        "borderImageRepeat": w,
        "borderImageSlice": w,
        "borderImageSource": w,
        "borderImageWidth": w,
        "transitionDelay": w,
        "transitionDuration": w,
        "transitionProperty": w,
        "transitionTimingFunction": w
    }
};
module.exports = exports["default"];
}),
"[project]/node_modules/inline-style-prefixer/utils/capitalizeString.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = capitalizeString;
function capitalizeString(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}
module.exports = exports["default"];
}),
"[project]/node_modules/inline-style-prefixer/utils/prefixProperty.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = prefixProperty;
var _capitalizeString = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/utils/capitalizeString.js [app-client] (ecmascript)");
var _capitalizeString2 = _interopRequireDefault(_capitalizeString);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function prefixProperty(prefixProperties, property, style) {
    if (prefixProperties.hasOwnProperty(property)) {
        var requiredPrefixes = prefixProperties[property];
        for(var i = 0, len = requiredPrefixes.length; i < len; ++i){
            style[requiredPrefixes[i] + (0, _capitalizeString2.default)(property)] = style[property];
        }
    }
}
module.exports = exports['default'];
}),
"[project]/node_modules/inline-style-prefixer/utils/prefixValue.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = prefixValue;
function prefixValue(plugins, property, value, style, metaData) {
    for(var i = 0, len = plugins.length; i < len; ++i){
        var processedValue = plugins[i](property, value, style, metaData);
        // we can stop processing if a value is returned
        // as all plugin criteria are unique
        if (processedValue) {
            return processedValue;
        }
    }
}
module.exports = exports["default"];
}),
"[project]/node_modules/inline-style-prefixer/static/plugins/cursor.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = cursor;
var prefixes = [
    '-webkit-',
    '-moz-',
    ''
];
var values = {
    'zoom-in': true,
    'zoom-out': true,
    grab: true,
    grabbing: true
};
function cursor(property, value) {
    if (property === 'cursor' && values.hasOwnProperty(value)) {
        return prefixes.map(function(prefix) {
            return prefix + value;
        });
    }
}
module.exports = exports['default'];
}),
"[project]/node_modules/inline-style-prefixer/static/plugins/crossFade.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = crossFade;
var _isPrefixedValue = __turbopack_context__.r("[project]/node_modules/css-in-js-utils/lib/isPrefixedValue.js [app-client] (ecmascript)");
var _isPrefixedValue2 = _interopRequireDefault(_isPrefixedValue);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
// http://caniuse.com/#search=cross-fade
var prefixes = [
    '-webkit-',
    ''
];
function crossFade(property, value) {
    if (typeof value === 'string' && !(0, _isPrefixedValue2.default)(value) && value.indexOf('cross-fade(') > -1) {
        return prefixes.map(function(prefix) {
            return value.replace(/cross-fade\(/g, prefix + 'cross-fade(');
        });
    }
}
module.exports = exports['default'];
}),
"[project]/node_modules/inline-style-prefixer/static/plugins/filter.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = filter;
var _isPrefixedValue = __turbopack_context__.r("[project]/node_modules/css-in-js-utils/lib/isPrefixedValue.js [app-client] (ecmascript)");
var _isPrefixedValue2 = _interopRequireDefault(_isPrefixedValue);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
// http://caniuse.com/#feat=css-filter-function
var prefixes = [
    '-webkit-',
    ''
];
function filter(property, value) {
    if (typeof value === 'string' && !(0, _isPrefixedValue2.default)(value) && value.indexOf('filter(') > -1) {
        return prefixes.map(function(prefix) {
            return value.replace(/filter\(/g, prefix + 'filter(');
        });
    }
}
module.exports = exports['default'];
}),
"[project]/node_modules/inline-style-prefixer/static/plugins/flex.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = flex;
var values = {
    flex: [
        '-webkit-box',
        '-moz-box',
        '-ms-flexbox',
        '-webkit-flex',
        'flex'
    ],
    'inline-flex': [
        '-webkit-inline-box',
        '-moz-inline-box',
        '-ms-inline-flexbox',
        '-webkit-inline-flex',
        'inline-flex'
    ]
};
function flex(property, value) {
    if (property === 'display' && values.hasOwnProperty(value)) {
        return values[value];
    }
}
module.exports = exports['default'];
}),
"[project]/node_modules/inline-style-prefixer/static/plugins/flexboxOld.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = flexboxOld;
var alternativeValues = {
    'space-around': 'justify',
    'space-between': 'justify',
    'flex-start': 'start',
    'flex-end': 'end',
    'wrap-reverse': 'multiple',
    wrap: 'multiple'
};
var alternativeProps = {
    alignItems: 'WebkitBoxAlign',
    justifyContent: 'WebkitBoxPack',
    flexWrap: 'WebkitBoxLines'
};
function flexboxOld(property, value, style) {
    if (property === 'flexDirection' && typeof value === 'string') {
        if (value.indexOf('column') > -1) {
            style.WebkitBoxOrient = 'vertical';
        } else {
            style.WebkitBoxOrient = 'horizontal';
        }
        if (value.indexOf('reverse') > -1) {
            style.WebkitBoxDirection = 'reverse';
        } else {
            style.WebkitBoxDirection = 'normal';
        }
    }
    if (alternativeProps.hasOwnProperty(property)) {
        style[alternativeProps[property]] = alternativeValues[value] || value;
    }
}
module.exports = exports['default'];
}),
"[project]/node_modules/inline-style-prefixer/static/plugins/gradient.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = gradient;
var _isPrefixedValue = __turbopack_context__.r("[project]/node_modules/css-in-js-utils/lib/isPrefixedValue.js [app-client] (ecmascript)");
var _isPrefixedValue2 = _interopRequireDefault(_isPrefixedValue);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var prefixes = [
    '-webkit-',
    '-moz-',
    ''
];
var values = /linear-gradient|radial-gradient|repeating-linear-gradient|repeating-radial-gradient/;
function gradient(property, value) {
    if (typeof value === 'string' && !(0, _isPrefixedValue2.default)(value) && values.test(value)) {
        return prefixes.map(function(prefix) {
            return prefix + value;
        });
    }
}
module.exports = exports['default'];
}),
"[project]/node_modules/inline-style-prefixer/static/plugins/imageSet.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = imageSet;
var _isPrefixedValue = __turbopack_context__.r("[project]/node_modules/css-in-js-utils/lib/isPrefixedValue.js [app-client] (ecmascript)");
var _isPrefixedValue2 = _interopRequireDefault(_isPrefixedValue);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
// http://caniuse.com/#feat=css-image-set
var prefixes = [
    '-webkit-',
    ''
];
function imageSet(property, value) {
    if (typeof value === 'string' && !(0, _isPrefixedValue2.default)(value) && value.indexOf('image-set(') > -1) {
        return prefixes.map(function(prefix) {
            return value.replace(/image-set\(/g, prefix + 'image-set(');
        });
    }
}
module.exports = exports['default'];
}),
"[project]/node_modules/inline-style-prefixer/static/plugins/position.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = position;
function position(property, value) {
    if (property === 'position' && value === 'sticky') {
        return [
            '-webkit-sticky',
            'sticky'
        ];
    }
}
module.exports = exports['default'];
}),
"[project]/node_modules/inline-style-prefixer/static/plugins/sizing.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = sizing;
var prefixes = [
    '-webkit-',
    '-moz-',
    ''
];
var properties = {
    maxHeight: true,
    maxWidth: true,
    width: true,
    height: true,
    columnWidth: true,
    minWidth: true,
    minHeight: true
};
var values = {
    'min-content': true,
    'max-content': true,
    'fill-available': true,
    'fit-content': true,
    'contain-floats': true
};
function sizing(property, value) {
    if (properties.hasOwnProperty(property) && values.hasOwnProperty(value)) {
        return prefixes.map(function(prefix) {
            return prefix + value;
        });
    }
}
module.exports = exports['default'];
}),
"[project]/node_modules/inline-style-prefixer/static/plugins/transition.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = transition;
var _hyphenateProperty = __turbopack_context__.r("[project]/node_modules/css-in-js-utils/lib/hyphenateProperty.js [app-client] (ecmascript)");
var _hyphenateProperty2 = _interopRequireDefault(_hyphenateProperty);
var _isPrefixedValue = __turbopack_context__.r("[project]/node_modules/css-in-js-utils/lib/isPrefixedValue.js [app-client] (ecmascript)");
var _isPrefixedValue2 = _interopRequireDefault(_isPrefixedValue);
var _capitalizeString = __turbopack_context__.r("[project]/node_modules/inline-style-prefixer/utils/capitalizeString.js [app-client] (ecmascript)");
var _capitalizeString2 = _interopRequireDefault(_capitalizeString);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var properties = {
    transition: true,
    transitionProperty: true,
    WebkitTransition: true,
    WebkitTransitionProperty: true,
    MozTransition: true,
    MozTransitionProperty: true
};
var prefixMapping = {
    Webkit: '-webkit-',
    Moz: '-moz-',
    ms: '-ms-'
};
function prefixValue(value, propertyPrefixMap) {
    if ((0, _isPrefixedValue2.default)(value)) {
        return value;
    }
    // only split multi values, not cubic beziers
    var multipleValues = value.split(/,(?![^()]*(?:\([^()]*\))?\))/g);
    for(var i = 0, len = multipleValues.length; i < len; ++i){
        var singleValue = multipleValues[i];
        var values = [
            singleValue
        ];
        for(var property in propertyPrefixMap){
            var dashCaseProperty = (0, _hyphenateProperty2.default)(property);
            if (singleValue.indexOf(dashCaseProperty) > -1 && dashCaseProperty !== 'order') {
                var prefixes = propertyPrefixMap[property];
                for(var j = 0, pLen = prefixes.length; j < pLen; ++j){
                    // join all prefixes and create a new value
                    values.unshift(singleValue.replace(dashCaseProperty, prefixMapping[prefixes[j]] + dashCaseProperty));
                }
            }
        }
        multipleValues[i] = values.join(',');
    }
    return multipleValues.join(',');
}
function transition(property, value, style, propertyPrefixMap) {
    // also check for already prefixed transitions
    if (typeof value === 'string' && properties.hasOwnProperty(property)) {
        var outputValue = prefixValue(value, propertyPrefixMap);
        // if the property is already prefixed
        var webkitOutput = outputValue.split(/,(?![^()]*(?:\([^()]*\))?\))/g).filter(function(val) {
            return !/-moz-|-ms-/.test(val);
        }).join(',');
        if (property.indexOf('Webkit') > -1) {
            return webkitOutput;
        }
        var mozOutput = outputValue.split(/,(?![^()]*(?:\([^()]*\))?\))/g).filter(function(val) {
            return !/-webkit-|-ms-/.test(val);
        }).join(',');
        if (property.indexOf('Moz') > -1) {
            return mozOutput;
        }
        style['Webkit' + (0, _capitalizeString2.default)(property)] = webkitOutput;
        style['Moz' + (0, _capitalizeString2.default)(property)] = mozOutput;
        return outputValue;
    }
}
module.exports = exports['default'];
}),
"[project]/node_modules/css-in-js-utils/lib/isPrefixedValue.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = isPrefixedValue;
var regex = /-webkit-|-moz-|-ms-/;
function isPrefixedValue(value) {
    return typeof value === 'string' && regex.test(value);
}
module.exports = exports['default'];
}),
"[project]/node_modules/css-in-js-utils/lib/hyphenateProperty.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = hyphenateProperty;
var _hyphenateStyleName = __turbopack_context__.r("[project]/node_modules/hyphenate-style-name/index.js [app-client] (ecmascript)");
var _hyphenateStyleName2 = _interopRequireDefault(_hyphenateStyleName);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function hyphenateProperty(property) {
    return (0, _hyphenateStyleName2.default)(property);
}
module.exports = exports['default'];
}),
"[project]/node_modules/hyphenate-style-name/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
/* eslint-disable no-var, prefer-template */ var uppercasePattern = /[A-Z]/g;
var msPattern = /^ms-/;
var cache = {};
function toHyphenLower(match) {
    return '-' + match.toLowerCase();
}
function hyphenateStyleName(name) {
    if (cache.hasOwnProperty(name)) {
        return cache[name];
    }
    var hName = name.replace(uppercasePattern, toHyphenLower);
    return cache[name] = msPattern.test(hName) ? '-' + hName : hName;
}
const __TURBOPACK__default__export__ = hyphenateStyleName;
}),
"[project]/node_modules/next-plausible/dist/index.esm.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PlausibleProvider,
    "usePlausible",
    ()=>usePlausible,
    "withPlausibleProxy",
    ()=>withPlausibleProxy
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/script.js [app-client] (ecmascript)");
;
;
function usePlausible() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePlausible.useCallback": function(eventName, ...rest) {
            var _a, _b;
            return (_b = (_a = window).plausible) === null || _b === void 0 ? void 0 : _b.call(_a, eventName, rest[0]);
        }
    }["usePlausible.useCallback"], []);
}
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */ function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}
function getCombinations(elements) {
    const combinations = [];
    for(let i = 0; i < elements.length; i++){
        combinations.push([
            elements[i]
        ]);
        if (i < elements.length - 1) {
            getCombinations(elements.slice(i + 1)).forEach((combination)=>{
                combinations.push([
                    elements[i],
                    ...combination
                ]);
            });
        }
    }
    return combinations;
}
const allModifiers = [
    'exclusions',
    'local',
    'manual',
    'outbound-links',
    'file-downloads',
    'tagged-events',
    'pageview-props',
    'revenue',
    'hash'
];
const getScriptPath = (options, ...modifiers)=>{
    var _a, _b;
    let basePath = (_a = options.basePath) !== null && _a !== void 0 ? _a : '';
    if (options.subdirectory) {
        basePath += `/${options.subdirectory}`;
    }
    return `${basePath}/js/${[
        (_b = options.scriptName) !== null && _b !== void 0 ? _b : 'script',
        ...modifiers.sort().filter((modifier)=>modifier !== null)
    ].join('.')}.js`;
};
const plausibleDomain = 'https://plausible.io';
const getRemoteScriptName = (selfHosted)=>selfHosted ? 'plausible' : 'script';
const getDomain = (options)=>{
    var _a;
    return (_a = options.customDomain) !== null && _a !== void 0 ? _a : plausibleDomain;
};
const getApiEndpoint = (options)=>{
    var _a, _b;
    return `${(_a = options.basePath) !== null && _a !== void 0 ? _a : ''}/${(_b = options.subdirectory) !== null && _b !== void 0 ? _b : 'proxy'}/api/event${options.trailingSlash ? '/' : ''}`;
};
function withPlausibleProxy(options = {}) {
    return (nextConfig)=>{
        const nextPlausiblePublicProxyOptions = Object.assign(Object.assign({}, options), {
            trailingSlash: !!nextConfig.trailingSlash,
            basePath: nextConfig.basePath
        });
        const nextPlausibleEnv = {
            next_plausible_proxy: 'true',
            next_plausible_trailingSlash: nextPlausiblePublicProxyOptions.trailingSlash ? 'true' : undefined,
            next_plausible_basePath: nextPlausiblePublicProxyOptions.basePath,
            next_plausible_customDomain: nextPlausiblePublicProxyOptions.customDomain,
            next_plausible_scriptName: nextPlausiblePublicProxyOptions.scriptName,
            next_plausible_subdirectory: nextPlausiblePublicProxyOptions.subdirectory
        };
        return Object.assign(Object.assign({}, nextConfig), {
            env: Object.assign(Object.assign({}, nextConfig.env), Object.fromEntries(Object.entries(nextPlausibleEnv).filter(([_, value])=>value !== undefined))),
            rewrites: ()=>__awaiter(this, void 0, void 0, function*() {
                    var _a;
                    const domain = getDomain(options);
                    const getRemoteScript = (...modifiers)=>{
                        var _a;
                        return ((_a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PLAUSIBLE_TEST_DOMAIN) !== null && _a !== void 0 ? _a : domain) + getScriptPath({
                            scriptName: getRemoteScriptName(domain !== plausibleDomain)
                        }, ...modifiers);
                    };
                    const plausibleRewrites = [
                        {
                            source: getScriptPath(options),
                            destination: getRemoteScript()
                        },
                        ...getCombinations(allModifiers).map((modifiers)=>({
                                source: getScriptPath(options, ...modifiers),
                                destination: getRemoteScript(...modifiers)
                            })),
                        {
                            source: getApiEndpoint(Object.assign(Object.assign({}, nextPlausiblePublicProxyOptions), {
                                basePath: ''
                            })),
                            destination: `${domain}/api/event`
                        }
                    ];
                    if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PLAUSIBLE_DEBUG) {
                        console.log('plausibleRewrites = ', plausibleRewrites);
                    }
                    const rewrites = yield (_a = nextConfig.rewrites) === null || _a === void 0 ? void 0 : _a.call(nextConfig);
                    if (!rewrites) {
                        return plausibleRewrites;
                    } else if (Array.isArray(rewrites)) {
                        return rewrites.concat(plausibleRewrites);
                    } else if (rewrites.afterFiles) {
                        rewrites.afterFiles = rewrites.afterFiles.concat(plausibleRewrites);
                        return rewrites;
                    } else {
                        rewrites.afterFiles = plausibleRewrites;
                        return rewrites;
                    }
                })
        });
    };
}
function PlausibleProvider(props) {
    var _a;
    const { enabled = ("TURBOPACK compile-time value", "development") === 'production' && (!__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_VERCEL_ENV || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_VERCEL_ENV === 'production') } = props;
    const proxyOptions = ("TURBOPACK compile-time truthy", 1) ? {
        trailingSlash: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.next_plausible_trailingSlash === 'true',
        basePath: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.next_plausible_basePath,
        customDomain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.next_plausible_customDomain,
        scriptName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.next_plausible_scriptName,
        subdirectory: ("TURBOPACK compile-time value", "__plsb")
    } : "TURBOPACK unreachable";
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, null, enabled && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], Object.assign({
        async: true,
        defer: true,
        "data-api": ("TURBOPACK compile-time truthy", 1) ? getApiEndpoint(proxyOptions) : "TURBOPACK unreachable",
        "data-domain": props.domain,
        "data-exclude": props.exclude,
        src: (("TURBOPACK compile-time truthy", 1) ? '' : "TURBOPACK unreachable") + getScriptPath(Object.assign(Object.assign({}, proxyOptions), {
            scriptName: ("TURBOPACK compile-time truthy", 1) ? proxyOptions.scriptName : "TURBOPACK unreachable"
        }), props.trackLocalhost ? 'local' : null, props.manualPageviews ? 'manual' : null, props.pageviewProps ? 'pageview-props' : null, props.trackOutboundLinks ? 'outbound-links' : null, props.exclude ? 'exclusions' : null, props.revenue ? 'revenue' : null, props.trackFileDownloads ? 'file-downloads' : null, props.taggedEvents ? 'tagged-events' : null, props.hash ? 'hash' : null),
        integrity: props.integrity,
        crossOrigin: props.integrity ? 'anonymous' : undefined
    }, typeof props.pageviewProps === 'object' ? Object.fromEntries(Object.entries(props.pageviewProps).map(([k, v])=>[
            `event-${k}`,
            v
        ])) : undefined, props.scriptProps)), enabled && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        id: "next-plausible-init",
        dangerouslySetInnerHTML: {
            __html: `window.plausible = window.plausible || function() { (window.plausible.q = window.plausible.q || []).push(arguments) }`
        },
        nonce: (_a = props.scriptProps) === null || _a === void 0 ? void 0 : _a.nonce
    }), props.children);
}
;
}),
"[project]/node_modules/graphql-tag/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "disableExperimentalFragmentVariables",
    ()=>disableExperimentalFragmentVariables,
    "disableFragmentWarnings",
    ()=>disableFragmentWarnings,
    "enableExperimentalFragmentVariables",
    ()=>enableExperimentalFragmentVariables,
    "gql",
    ()=>gql,
    "resetCaches",
    ()=>resetCaches
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$graphql$2f$language$2f$parser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/graphql/language/parser.mjs [app-client] (ecmascript)");
;
;
var docCache = new Map();
var fragmentSourceMap = new Map();
var printFragmentWarnings = true;
var experimentalFragmentVariables = false;
function normalize(string) {
    return string.replace(/[\s,]+/g, ' ').trim();
}
function cacheKeyFromLoc(loc) {
    return normalize(loc.source.body.substring(loc.start, loc.end));
}
function processFragments(ast) {
    var seenKeys = new Set();
    var definitions = [];
    ast.definitions.forEach(function(fragmentDefinition) {
        if (fragmentDefinition.kind === 'FragmentDefinition') {
            var fragmentName = fragmentDefinition.name.value;
            var sourceKey = cacheKeyFromLoc(fragmentDefinition.loc);
            var sourceKeySet = fragmentSourceMap.get(fragmentName);
            if (sourceKeySet && !sourceKeySet.has(sourceKey)) {
                if (printFragmentWarnings) {
                    console.warn("Warning: fragment with name " + fragmentName + " already exists.\n" + "graphql-tag enforces all fragment names across your application to be unique; read more about\n" + "this in the docs: http://dev.apollodata.com/core/fragments.html#unique-names");
                }
            } else if (!sourceKeySet) {
                fragmentSourceMap.set(fragmentName, sourceKeySet = new Set);
            }
            sourceKeySet.add(sourceKey);
            if (!seenKeys.has(sourceKey)) {
                seenKeys.add(sourceKey);
                definitions.push(fragmentDefinition);
            }
        } else {
            definitions.push(fragmentDefinition);
        }
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__assign"])({}, ast), {
        definitions: definitions
    });
}
function stripLoc(doc) {
    var workSet = new Set(doc.definitions);
    workSet.forEach(function(node) {
        if (node.loc) delete node.loc;
        Object.keys(node).forEach(function(key) {
            var value = node[key];
            if (value && typeof value === 'object') {
                workSet.add(value);
            }
        });
    });
    var loc = doc.loc;
    if (loc) {
        delete loc.startToken;
        delete loc.endToken;
    }
    return doc;
}
function parseDocument(source) {
    var cacheKey = normalize(source);
    if (!docCache.has(cacheKey)) {
        var parsed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$graphql$2f$language$2f$parser$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parse"])(source, {
            experimentalFragmentVariables: experimentalFragmentVariables,
            allowLegacyFragmentVariables: experimentalFragmentVariables
        });
        if (!parsed || parsed.kind !== 'Document') {
            throw new Error('Not a valid GraphQL document.');
        }
        docCache.set(cacheKey, stripLoc(processFragments(parsed)));
    }
    return docCache.get(cacheKey);
}
function gql(literals) {
    var args = [];
    for(var _i = 1; _i < arguments.length; _i++){
        args[_i - 1] = arguments[_i];
    }
    if (typeof literals === 'string') {
        literals = [
            literals
        ];
    }
    var result = literals[0];
    args.forEach(function(arg, i) {
        if (arg && arg.kind === 'Document') {
            result += arg.loc.source.body;
        } else {
            result += arg;
        }
        result += literals[i + 1];
    });
    return parseDocument(result);
}
function resetCaches() {
    docCache.clear();
    fragmentSourceMap.clear();
}
function disableFragmentWarnings() {
    printFragmentWarnings = false;
}
function enableExperimentalFragmentVariables() {
    experimentalFragmentVariables = true;
}
function disableExperimentalFragmentVariables() {
    experimentalFragmentVariables = false;
}
var extras = {
    gql: gql,
    resetCaches: resetCaches,
    disableFragmentWarnings: disableFragmentWarnings,
    enableExperimentalFragmentVariables: enableExperimentalFragmentVariables,
    disableExperimentalFragmentVariables: disableExperimentalFragmentVariables
};
(function(gql_1) {
    gql_1.gql = extras.gql, gql_1.resetCaches = extras.resetCaches, gql_1.disableFragmentWarnings = extras.disableFragmentWarnings, gql_1.enableExperimentalFragmentVariables = extras.enableExperimentalFragmentVariables, gql_1.disableExperimentalFragmentVariables = extras.disableExperimentalFragmentVariables;
})(gql || (gql = {}));
gql["default"] = gql;
const __TURBOPACK__default__export__ = gql;
}),
"[project]/node_modules/@apollo/client-integration-nextjs/dist/index.browser.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ApolloClient",
    ()=>ApolloClient,
    "ApolloNextAppProvider",
    ()=>ApolloNextAppProvider,
    "InMemoryCache",
    ()=>InMemoryCache,
    "built_for_browser",
    ()=>built_for_browser,
    "resetApolloClientSingletons",
    ()=>resetApolloClientSingletons
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$react$2d$streaming$2f$dist$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client-react-streaming/dist/index.browser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$react$2d$streaming$2f$dist$2f$manual$2d$transport$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@apollo/client-react-streaming/dist/manual-transport.browser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
;
;
;
;
// src/index.shared.ts
// src/bundleInfo.ts
var bundle = {
    pkg: "@apollo/client-integration-nextjs",
    client: "ApolloClient",
    cache: "InMemoryCache"
};
var ApolloClient = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$react$2d$streaming$2f$dist$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApolloClient"] {
    /**
   * Information about the current package and it's export names, for use in error messages.
   *
   * @internal
   */ static info = bundle;
};
var InMemoryCache = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$react$2d$streaming$2f$dist$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InMemoryCache"] {
    /**
   * Information about the current package and it's export names, for use in error messages.
   *
   * @internal
   */ static info = bundle;
};
var ApolloNextAppProvider = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$react$2d$streaming$2f$dist$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WrapApolloProvider"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$react$2d$streaming$2f$dist$2f$manual$2d$transport$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildManualDataTransport"])({
    useInsertHtml () {
        const insertHtml = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ServerInsertedHTMLContext"]);
        if (!insertHtml) {
            {
                return ()=>{};
            }
        }
        return insertHtml;
    }
}));
ApolloNextAppProvider.info = bundle;
var resetApolloClientSingletons = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$apollo$2f$client$2d$react$2d$streaming$2f$dist$2f$manual$2d$transport$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resetManualSSRApolloSingletons"];
const built_for_browser = true;
;
}),
]);

//# debugId=511c54c0-fbc9-d108-be92-5de13ee21fc3
//# sourceMappingURL=node_modules_0wo7dcw._.js.map