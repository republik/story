;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="2bb265b8-6ca3-8408-3782-04dcb2ab8e20")}catch(e){}}();
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "abs",
    ()=>abs,
    "acos",
    ()=>acos,
    "asin",
    ()=>asin,
    "atan",
    ()=>atan,
    "atan2",
    ()=>atan2,
    "ceil",
    ()=>ceil,
    "cos",
    ()=>cos,
    "degrees",
    ()=>degrees,
    "epsilon",
    ()=>epsilon,
    "epsilon2",
    ()=>epsilon2,
    "exp",
    ()=>exp,
    "floor",
    ()=>floor,
    "halfPi",
    ()=>halfPi,
    "haversin",
    ()=>haversin,
    "log",
    ()=>log,
    "pi",
    ()=>pi,
    "pow",
    ()=>pow,
    "quarterPi",
    ()=>quarterPi,
    "radians",
    ()=>radians,
    "sign",
    ()=>sign,
    "sin",
    ()=>sin,
    "sqrt",
    ()=>sqrt,
    "tan",
    ()=>tan,
    "tau",
    ()=>tau
]);
var epsilon = 1e-6;
var epsilon2 = 1e-12;
var pi = Math.PI;
var halfPi = pi / 2;
var quarterPi = pi / 4;
var tau = pi * 2;
var degrees = 180 / pi;
var radians = pi / 180;
var abs = Math.abs;
var atan = Math.atan;
var atan2 = Math.atan2;
var cos = Math.cos;
var ceil = Math.ceil;
var exp = Math.exp;
var floor = Math.floor;
var log = Math.log;
var pow = Math.pow;
var sin = Math.sin;
var sign = Math.sign || function(x) {
    return x > 0 ? 1 : x < 0 ? -1 : 0;
};
var sqrt = Math.sqrt;
var tan = Math.tan;
function acos(x) {
    return x > 1 ? 0 : x < -1 ? pi : Math.acos(x);
}
function asin(x) {
    return x > 1 ? halfPi : x < -1 ? -halfPi : Math.asin(x);
}
function haversin(x) {
    return (x = sin(x / 2)) * x;
}
}),
"[project]/node_modules/d3-geo/src/noop.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>noop
]);
function noop() {}
}),
"[project]/node_modules/d3-geo/src/clip/buffer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/noop.js [app-client] (ecmascript)");
;
function __TURBOPACK__default__export__() {
    var lines = [], line;
    return {
        point: function(x, y, m) {
            line.push([
                x,
                y,
                m
            ]);
        },
        lineStart: function() {
            lines.push(line = []);
        },
        lineEnd: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        rejoin: function() {
            if (lines.length > 1) lines.push(lines.pop().concat(lines.shift()));
        },
        result: function() {
            var result = lines;
            lines = [];
            line = null;
            return result;
        }
    };
}
}),
"[project]/node_modules/d3-geo/src/clip/line.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
function __TURBOPACK__default__export__(a, b, x0, y0, x1, y1) {
    var ax = a[0], ay = a[1], bx = b[0], by = b[1], t0 = 0, t1 = 1, dx = bx - ax, dy = by - ay, r;
    r = x0 - ax;
    if (!dx && r > 0) return;
    r /= dx;
    if (dx < 0) {
        if (r < t0) return;
        if (r < t1) t1 = r;
    } else if (dx > 0) {
        if (r > t1) return;
        if (r > t0) t0 = r;
    }
    r = x1 - ax;
    if (!dx && r < 0) return;
    r /= dx;
    if (dx < 0) {
        if (r > t1) return;
        if (r > t0) t0 = r;
    } else if (dx > 0) {
        if (r < t0) return;
        if (r < t1) t1 = r;
    }
    r = y0 - ay;
    if (!dy && r > 0) return;
    r /= dy;
    if (dy < 0) {
        if (r < t0) return;
        if (r < t1) t1 = r;
    } else if (dy > 0) {
        if (r > t1) return;
        if (r > t0) t0 = r;
    }
    r = y1 - ay;
    if (!dy && r < 0) return;
    r /= dy;
    if (dy < 0) {
        if (r > t1) return;
        if (r > t0) t0 = r;
    } else if (dy > 0) {
        if (r < t0) return;
        if (r < t1) t1 = r;
    }
    if (t0 > 0) a[0] = ax + t0 * dx, a[1] = ay + t0 * dy;
    if (t1 < 1) b[0] = ax + t1 * dx, b[1] = ay + t1 * dy;
    return true;
}
}),
"[project]/node_modules/d3-geo/src/pointEqual.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
;
function __TURBOPACK__default__export__(a, b) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(a[0] - b[0]) < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"] && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(a[1] - b[1]) < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"];
}
}),
"[project]/node_modules/d3-geo/src/clip/rejoin.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$pointEqual$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/pointEqual.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
;
;
function Intersection(point, points, other, entry) {
    this.x = point;
    this.z = points;
    this.o = other; // another intersection
    this.e = entry; // is an entry?
    this.v = false; // visited
    this.n = this.p = null; // next & previous
}
function __TURBOPACK__default__export__(segments, compareIntersection, startInside, interpolate, stream) {
    var subject = [], clip = [], i, n;
    segments.forEach(function(segment) {
        if ((n = segment.length - 1) <= 0) return;
        var n, p0 = segment[0], p1 = segment[n], x;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$pointEqual$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(p0, p1)) {
            if (!p0[2] && !p1[2]) {
                stream.lineStart();
                for(i = 0; i < n; ++i)stream.point((p0 = segment[i])[0], p0[1]);
                stream.lineEnd();
                return;
            }
            // handle degenerate cases by moving the point
            p1[0] += 2 * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"];
        }
        subject.push(x = new Intersection(p0, segment, null, true));
        clip.push(x.o = new Intersection(p0, null, x, false));
        subject.push(x = new Intersection(p1, segment, null, false));
        clip.push(x.o = new Intersection(p1, null, x, true));
    });
    if (!subject.length) return;
    clip.sort(compareIntersection);
    link(subject);
    link(clip);
    for(i = 0, n = clip.length; i < n; ++i){
        clip[i].e = startInside = !startInside;
    }
    var start = subject[0], points, point;
    while(1){
        // Find first unvisited intersection.
        var current = start, isSubject = true;
        while(current.v)if ((current = current.n) === start) return;
        points = current.z;
        stream.lineStart();
        do {
            current.v = current.o.v = true;
            if (current.e) {
                if (isSubject) {
                    for(i = 0, n = points.length; i < n; ++i)stream.point((point = points[i])[0], point[1]);
                } else {
                    interpolate(current.x, current.n.x, 1, stream);
                }
                current = current.n;
            } else {
                if (isSubject) {
                    points = current.p.z;
                    for(i = points.length - 1; i >= 0; --i)stream.point((point = points[i])[0], point[1]);
                } else {
                    interpolate(current.x, current.p.x, -1, stream);
                }
                current = current.p;
            }
            current = current.o;
            points = current.z;
            isSubject = !isSubject;
        }while (!current.v)
        stream.lineEnd();
    }
}
function link(array) {
    if (!(n = array.length)) return;
    var n, i = 0, a = array[0], b;
    while(++i < n){
        a.n = b = array[i];
        b.p = a;
        a = b;
    }
    a.n = b = array[0];
    b.p = a;
}
}),
"[project]/node_modules/d3-geo/src/clip/rectangle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>clipRectangle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/clip/buffer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/clip/line.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$rejoin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/clip/rejoin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$node_modules$2f$d3$2d$array$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/node_modules/d3-array/src/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$node_modules$2f$d3$2d$array$2f$src$2f$merge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__merge$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/node_modules/d3-array/src/merge.js [app-client] (ecmascript) <export default as merge>");
;
;
;
;
;
var clipMax = 1e9, clipMin = -clipMax;
function clipRectangle(x0, y0, x1, y1) {
    function visible(x, y) {
        return x0 <= x && x <= x1 && y0 <= y && y <= y1;
    }
    function interpolate(from, to, direction, stream) {
        var a = 0, a1 = 0;
        if (from == null || (a = corner(from, direction)) !== (a1 = corner(to, direction)) || comparePoint(from, to) < 0 ^ direction > 0) {
            do stream.point(a === 0 || a === 3 ? x0 : x1, a > 1 ? y1 : y0);
            while ((a = (a + direction + 4) % 4) !== a1)
        } else {
            stream.point(to[0], to[1]);
        }
    }
    function corner(p, direction) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(p[0] - x0) < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"] ? direction > 0 ? 0 : 3 : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(p[0] - x1) < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"] ? direction > 0 ? 2 : 1 : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(p[1] - y0) < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"] ? direction > 0 ? 1 : 0 : direction > 0 ? 3 : 2; // abs(p[1] - y1) < epsilon
    }
    function compareIntersection(a, b) {
        return comparePoint(a.x, b.x);
    }
    function comparePoint(a, b) {
        var ca = corner(a, 1), cb = corner(b, 1);
        return ca !== cb ? ca - cb : ca === 0 ? b[1] - a[1] : ca === 1 ? a[0] - b[0] : ca === 2 ? a[1] - b[1] : b[0] - a[0];
    }
    return function(stream) {
        var activeStream = stream, bufferStream = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(), segments, polygon, ring, x__, y__, v__, x_, y_, v_, first, clean;
        var clipStream = {
            point: point,
            lineStart: lineStart,
            lineEnd: lineEnd,
            polygonStart: polygonStart,
            polygonEnd: polygonEnd
        };
        function point(x, y) {
            if (visible(x, y)) activeStream.point(x, y);
        }
        function polygonInside() {
            var winding = 0;
            for(var i = 0, n = polygon.length; i < n; ++i){
                for(var ring = polygon[i], j = 1, m = ring.length, point = ring[0], a0, a1, b0 = point[0], b1 = point[1]; j < m; ++j){
                    a0 = b0, a1 = b1, point = ring[j], b0 = point[0], b1 = point[1];
                    if (a1 <= y1) {
                        if (b1 > y1 && (b0 - a0) * (y1 - a1) > (b1 - a1) * (x0 - a0)) ++winding;
                    } else {
                        if (b1 <= y1 && (b0 - a0) * (y1 - a1) < (b1 - a1) * (x0 - a0)) --winding;
                    }
                }
            }
            return winding;
        }
        // Buffer geometry within a polygon and then clip it en masse.
        function polygonStart() {
            activeStream = bufferStream, segments = [], polygon = [], clean = true;
        }
        function polygonEnd() {
            var startInside = polygonInside(), cleanInside = clean && startInside, visible = (segments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$node_modules$2f$d3$2d$array$2f$src$2f$merge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__merge$3e$__["merge"])(segments)).length;
            if (cleanInside || visible) {
                stream.polygonStart();
                if (cleanInside) {
                    stream.lineStart();
                    interpolate(null, null, 1, stream);
                    stream.lineEnd();
                }
                if (visible) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$rejoin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(segments, compareIntersection, startInside, interpolate, stream);
                }
                stream.polygonEnd();
            }
            activeStream = stream, segments = polygon = ring = null;
        }
        function lineStart() {
            clipStream.point = linePoint;
            if (polygon) polygon.push(ring = []);
            first = true;
            v_ = false;
            x_ = y_ = NaN;
        }
        // TODO rather than special-case polygons, simply handle them separately.
        // Ideally, coincident intersection points should be jittered to avoid
        // clipping issues.
        function lineEnd() {
            if (segments) {
                linePoint(x__, y__);
                if (v__ && v_) bufferStream.rejoin();
                segments.push(bufferStream.result());
            }
            clipStream.point = point;
            if (v_) activeStream.lineEnd();
        }
        function linePoint(x, y) {
            var v = visible(x, y);
            if (polygon) ring.push([
                x,
                y
            ]);
            if (first) {
                x__ = x, y__ = y, v__ = v;
                first = false;
                if (v) {
                    activeStream.lineStart();
                    activeStream.point(x, y);
                }
            } else {
                if (v && v_) activeStream.point(x, y);
                else {
                    var a = [
                        x_ = Math.max(clipMin, Math.min(clipMax, x_)),
                        y_ = Math.max(clipMin, Math.min(clipMax, y_))
                    ], b = [
                        x = Math.max(clipMin, Math.min(clipMax, x)),
                        y = Math.max(clipMin, Math.min(clipMax, y))
                    ];
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(a, b, x0, y0, x1, y1)) {
                        if (!v_) {
                            activeStream.lineStart();
                            activeStream.point(a[0], a[1]);
                        }
                        activeStream.point(b[0], b[1]);
                        if (!v) activeStream.lineEnd();
                        clean = false;
                    } else if (v) {
                        activeStream.lineStart();
                        activeStream.point(x, y);
                        clean = false;
                    }
                }
            }
            x_ = x, y_ = y, v_ = v;
        }
        return clipStream;
    };
}
}),
"[project]/node_modules/d3-geo/src/identity.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
function __TURBOPACK__default__export__(x) {
    return x;
}
}),
"[project]/node_modules/d3-geo/src/transform.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "transformer",
    ()=>transformer
]);
function __TURBOPACK__default__export__(methods) {
    return {
        stream: transformer(methods)
    };
}
function transformer(methods) {
    return function(stream) {
        var s = new TransformStream;
        for(var key in methods)s[key] = methods[key];
        s.stream = stream;
        return s;
    };
}
function TransformStream() {}
TransformStream.prototype = {
    constructor: TransformStream,
    point: function(x, y) {
        this.stream.point(x, y);
    },
    sphere: function() {
        this.stream.sphere();
    },
    lineStart: function() {
        this.stream.lineStart();
    },
    lineEnd: function() {
        this.stream.lineEnd();
    },
    polygonStart: function() {
        this.stream.polygonStart();
    },
    polygonEnd: function() {
        this.stream.polygonEnd();
    }
};
}),
"[project]/node_modules/d3-geo/src/stream.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
function streamGeometry(geometry, stream) {
    if (geometry && streamGeometryType.hasOwnProperty(geometry.type)) {
        streamGeometryType[geometry.type](geometry, stream);
    }
}
var streamObjectType = {
    Feature: function(object, stream) {
        streamGeometry(object.geometry, stream);
    },
    FeatureCollection: function(object, stream) {
        var features = object.features, i = -1, n = features.length;
        while(++i < n)streamGeometry(features[i].geometry, stream);
    }
};
var streamGeometryType = {
    Sphere: function(object, stream) {
        stream.sphere();
    },
    Point: function(object, stream) {
        object = object.coordinates;
        stream.point(object[0], object[1], object[2]);
    },
    MultiPoint: function(object, stream) {
        var coordinates = object.coordinates, i = -1, n = coordinates.length;
        while(++i < n)object = coordinates[i], stream.point(object[0], object[1], object[2]);
    },
    LineString: function(object, stream) {
        streamLine(object.coordinates, stream, 0);
    },
    MultiLineString: function(object, stream) {
        var coordinates = object.coordinates, i = -1, n = coordinates.length;
        while(++i < n)streamLine(coordinates[i], stream, 0);
    },
    Polygon: function(object, stream) {
        streamPolygon(object.coordinates, stream);
    },
    MultiPolygon: function(object, stream) {
        var coordinates = object.coordinates, i = -1, n = coordinates.length;
        while(++i < n)streamPolygon(coordinates[i], stream);
    },
    GeometryCollection: function(object, stream) {
        var geometries = object.geometries, i = -1, n = geometries.length;
        while(++i < n)streamGeometry(geometries[i], stream);
    }
};
function streamLine(coordinates, stream, closed) {
    var i = -1, n = coordinates.length - closed, coordinate;
    stream.lineStart();
    while(++i < n)coordinate = coordinates[i], stream.point(coordinate[0], coordinate[1], coordinate[2]);
    stream.lineEnd();
}
function streamPolygon(coordinates, stream) {
    var i = -1, n = coordinates.length;
    stream.polygonStart();
    while(++i < n)streamLine(coordinates[i], stream, 1);
    stream.polygonEnd();
}
function __TURBOPACK__default__export__(object, stream) {
    if (object && streamObjectType.hasOwnProperty(object.type)) {
        streamObjectType[object.type](object, stream);
    } else {
        streamGeometry(object, stream);
    }
}
}),
"[project]/node_modules/d3-geo/src/path/bounds.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/noop.js [app-client] (ecmascript)");
;
var x0 = Infinity, y0 = x0, x1 = -x0, y1 = x1;
var boundsStream = {
    point: boundsPoint,
    lineStart: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    lineEnd: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    polygonStart: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    polygonEnd: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    result: function() {
        var bounds = [
            [
                x0,
                y0
            ],
            [
                x1,
                y1
            ]
        ];
        x1 = y1 = -(y0 = x0 = Infinity);
        return bounds;
    }
};
function boundsPoint(x, y) {
    if (x < x0) x0 = x;
    if (x > x1) x1 = x;
    if (y < y0) y0 = y;
    if (y > y1) y1 = y;
}
const __TURBOPACK__default__export__ = boundsStream;
}),
"[project]/node_modules/d3-geo/src/projection/fit.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fitExtent",
    ()=>fitExtent,
    "fitHeight",
    ()=>fitHeight,
    "fitSize",
    ()=>fitSize,
    "fitWidth",
    ()=>fitWidth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$stream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/stream.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$bounds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/path/bounds.js [app-client] (ecmascript)");
;
;
function fit(projection, fitBounds, object) {
    var clip = projection.clipExtent && projection.clipExtent();
    projection.scale(150).translate([
        0,
        0
    ]);
    if (clip != null) projection.clipExtent(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$stream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(object, projection.stream(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$bounds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]));
    fitBounds(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$bounds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].result());
    if (clip != null) projection.clipExtent(clip);
    return projection;
}
function fitExtent(projection, extent, object) {
    return fit(projection, function(b) {
        var w = extent[1][0] - extent[0][0], h = extent[1][1] - extent[0][1], k = Math.min(w / (b[1][0] - b[0][0]), h / (b[1][1] - b[0][1])), x = +extent[0][0] + (w - k * (b[1][0] + b[0][0])) / 2, y = +extent[0][1] + (h - k * (b[1][1] + b[0][1])) / 2;
        projection.scale(150 * k).translate([
            x,
            y
        ]);
    }, object);
}
function fitSize(projection, size, object) {
    return fitExtent(projection, [
        [
            0,
            0
        ],
        size
    ], object);
}
function fitWidth(projection, width, object) {
    return fit(projection, function(b) {
        var w = +width, k = w / (b[1][0] - b[0][0]), x = (w - k * (b[1][0] + b[0][0])) / 2, y = -k * b[0][1];
        projection.scale(150 * k).translate([
            x,
            y
        ]);
    }, object);
}
function fitHeight(projection, height, object) {
    return fit(projection, function(b) {
        var h = +height, k = h / (b[1][1] - b[0][1]), x = -k * b[0][0], y = (h - k * (b[1][1] + b[0][1])) / 2;
        projection.scale(150 * k).translate([
            x,
            y
        ]);
    }, object);
}
}),
"[project]/node_modules/d3-geo/src/projection/identity.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$rectangle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/clip/rectangle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$identity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/identity.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$transform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/transform.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$fit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/projection/fit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
;
;
;
;
;
function __TURBOPACK__default__export__() {
    var k = 1, tx = 0, ty = 0, sx = 1, sy = 1, alpha = 0, ca, sa, x0 = null, y0, x1, y1, kx = 1, ky = 1, transform = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$transform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transformer"])({
        point: function(x, y) {
            var p = projection([
                x,
                y
            ]);
            this.stream.point(p[0], p[1]);
        }
    }), postclip = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$identity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], cache, cacheStream;
    function reset() {
        kx = k * sx;
        ky = k * sy;
        cache = cacheStream = null;
        return projection;
    }
    function projection(p) {
        var x = p[0] * kx, y = p[1] * ky;
        if (alpha) {
            var t = y * ca - x * sa;
            x = x * ca + y * sa;
            y = t;
        }
        return [
            x + tx,
            y + ty
        ];
    }
    projection.invert = function(p) {
        var x = p[0] - tx, y = p[1] - ty;
        if (alpha) {
            var t = y * ca + x * sa;
            x = x * ca - y * sa;
            y = t;
        }
        return [
            x / kx,
            y / ky
        ];
    };
    projection.stream = function(stream) {
        return cache && cacheStream === stream ? cache : cache = transform(postclip(cacheStream = stream));
    };
    projection.postclip = function(_) {
        return arguments.length ? (postclip = _, x0 = y0 = x1 = y1 = null, reset()) : postclip;
    };
    projection.clipExtent = function(_) {
        return arguments.length ? (postclip = _ == null ? (x0 = y0 = x1 = y1 = null, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$identity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$rectangle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(x0 = +_[0][0], y0 = +_[0][1], x1 = +_[1][0], y1 = +_[1][1]), reset()) : x0 == null ? null : [
            [
                x0,
                y0
            ],
            [
                x1,
                y1
            ]
        ];
    };
    projection.scale = function(_) {
        return arguments.length ? (k = +_, reset()) : k;
    };
    projection.translate = function(_) {
        return arguments.length ? (tx = +_[0], ty = +_[1], reset()) : [
            tx,
            ty
        ];
    };
    projection.angle = function(_) {
        return arguments.length ? (alpha = _ % 360 * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], sa = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(alpha), ca = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(alpha), reset()) : alpha * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"];
    };
    projection.reflectX = function(_) {
        return arguments.length ? (sx = _ ? -1 : 1, reset()) : sx < 0;
    };
    projection.reflectY = function(_) {
        return arguments.length ? (sy = _ ? -1 : 1, reset()) : sy < 0;
    };
    projection.fitExtent = function(extent, object) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$fit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fitExtent"])(projection, extent, object);
    };
    projection.fitSize = function(size, object) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$fit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fitSize"])(projection, size, object);
    };
    projection.fitWidth = function(width, object) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$fit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fitWidth"])(projection, width, object);
    };
    projection.fitHeight = function(height, object) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$fit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fitHeight"])(projection, height, object);
    };
    return projection;
}
}),
"[project]/node_modules/d3-geo/src/projection/identity.js [app-client] (ecmascript) <export default as geoIdentity>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "geoIdentity",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$identity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$identity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/projection/identity.js [app-client] (ecmascript)");
}),
"[project]/node_modules/d3-geo/src/compose.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
function __TURBOPACK__default__export__(a, b) {
    function compose(x, y) {
        return x = a(x, y), b(x[0], x[1]);
    }
    if (a.invert && b.invert) compose.invert = function(x, y) {
        return x = b.invert(x, y), x && a.invert(x[0], x[1]);
    };
    return compose;
}
}),
"[project]/node_modules/d3-geo/src/rotation.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "rotateRadians",
    ()=>rotateRadians
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$compose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/compose.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
;
;
function rotationIdentity(lambda, phi) {
    return [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(lambda) > __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"] ? lambda + Math.round(-lambda / __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tau"]) * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tau"] : lambda,
        phi
    ];
}
rotationIdentity.invert = rotationIdentity;
function rotateRadians(deltaLambda, deltaPhi, deltaGamma) {
    return (deltaLambda %= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tau"]) ? deltaPhi || deltaGamma ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$compose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(rotationLambda(deltaLambda), rotationPhiGamma(deltaPhi, deltaGamma)) : rotationLambda(deltaLambda) : deltaPhi || deltaGamma ? rotationPhiGamma(deltaPhi, deltaGamma) : rotationIdentity;
}
function forwardRotationLambda(deltaLambda) {
    return function(lambda, phi) {
        return lambda += deltaLambda, [
            lambda > __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"] ? lambda - __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tau"] : lambda < -__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"] ? lambda + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tau"] : lambda,
            phi
        ];
    };
}
function rotationLambda(deltaLambda) {
    var rotation = forwardRotationLambda(deltaLambda);
    rotation.invert = forwardRotationLambda(-deltaLambda);
    return rotation;
}
function rotationPhiGamma(deltaPhi, deltaGamma) {
    var cosDeltaPhi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(deltaPhi), sinDeltaPhi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(deltaPhi), cosDeltaGamma = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(deltaGamma), sinDeltaGamma = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(deltaGamma);
    function rotation(lambda, phi) {
        var cosPhi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(phi), x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(lambda) * cosPhi, y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(lambda) * cosPhi, z = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(phi), k = z * cosDeltaPhi + x * sinDeltaPhi;
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atan2"])(y * cosDeltaGamma - k * sinDeltaGamma, x * cosDeltaPhi - z * sinDeltaPhi),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asin"])(k * cosDeltaGamma + y * sinDeltaGamma)
        ];
    }
    rotation.invert = function(lambda, phi) {
        var cosPhi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(phi), x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(lambda) * cosPhi, y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(lambda) * cosPhi, z = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(phi), k = z * cosDeltaGamma - y * sinDeltaGamma;
        return [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atan2"])(y * cosDeltaGamma + z * sinDeltaGamma, x * cosDeltaPhi + k * sinDeltaPhi),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asin"])(k * cosDeltaPhi - x * sinDeltaPhi)
        ];
    };
    return rotation;
}
function __TURBOPACK__default__export__(rotate) {
    rotate = rotateRadians(rotate[0] * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], rotate[1] * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], rotate.length > 2 ? rotate[2] * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"] : 0);
    function forward(coordinates) {
        coordinates = rotate(coordinates[0] * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], coordinates[1] * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"]);
        return coordinates[0] *= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"], coordinates[1] *= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"], coordinates;
    }
    forward.invert = function(coordinates) {
        coordinates = rotate.invert(coordinates[0] * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], coordinates[1] * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"]);
        return coordinates[0] *= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"], coordinates[1] *= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"], coordinates;
    };
    return forward;
}
}),
"[project]/node_modules/d3-geo/src/adder.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Adds floating point numbers with twice the normal precision.
// Reference: J. R. Shewchuk, Adaptive Precision Floating-Point Arithmetic and
// Fast Robust Geometric Predicates, Discrete & Computational Geometry 18(3)
// 305–363 (1997).
// Code adapted from GeographicLib by Charles F. F. Karney,
// http://geographiclib.sourceforge.net/
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
function __TURBOPACK__default__export__() {
    return new Adder;
}
function Adder() {
    this.reset();
}
Adder.prototype = {
    constructor: Adder,
    reset: function() {
        this.s = this.t = 0; // exact error
    },
    add: function(y) {
        add(temp, y, this.t);
        add(this, temp.s, this.s);
        if (this.s) this.t += temp.t;
        else this.s = temp.t;
    },
    valueOf: function() {
        return this.s;
    }
};
var temp = new Adder;
function add(adder, a, b) {
    var x = adder.s = a + b, bv = x - a, av = x - bv;
    adder.t = a - av + (b - bv);
}
}),
"[project]/node_modules/d3-geo/src/cartesian.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cartesian",
    ()=>cartesian,
    "cartesianAddInPlace",
    ()=>cartesianAddInPlace,
    "cartesianCross",
    ()=>cartesianCross,
    "cartesianDot",
    ()=>cartesianDot,
    "cartesianNormalizeInPlace",
    ()=>cartesianNormalizeInPlace,
    "cartesianScale",
    ()=>cartesianScale,
    "spherical",
    ()=>spherical
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
;
function spherical(cartesian) {
    return [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atan2"])(cartesian[1], cartesian[0]),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asin"])(cartesian[2])
    ];
}
function cartesian(spherical) {
    var lambda = spherical[0], phi = spherical[1], cosPhi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(phi);
    return [
        cosPhi * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(lambda),
        cosPhi * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(lambda),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(phi)
    ];
}
function cartesianDot(a, b) {
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}
function cartesianCross(a, b) {
    return [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0]
    ];
}
function cartesianAddInPlace(a, b) {
    a[0] += b[0], a[1] += b[1], a[2] += b[2];
}
function cartesianScale(vector, k) {
    return [
        vector[0] * k,
        vector[1] * k,
        vector[2] * k
    ];
}
function cartesianNormalizeInPlace(d) {
    var l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sqrt"])(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
    d[0] /= l, d[1] /= l, d[2] /= l;
}
}),
"[project]/node_modules/d3-geo/src/polygonContains.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$adder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/adder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/cartesian.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
;
;
;
var sum = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$adder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
function longitude(point) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(point[0]) <= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"]) return point[0];
    else return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sign"])(point[0]) * (((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(point[0]) + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"]) % __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tau"] - __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"]);
}
function __TURBOPACK__default__export__(polygon, point) {
    var lambda = longitude(point), phi = point[1], sinPhi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(phi), normal = [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(lambda),
        -(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(lambda),
        0
    ], angle = 0, winding = 0;
    sum.reset();
    if (sinPhi === 1) phi = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["halfPi"] + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"];
    else if (sinPhi === -1) phi = -__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["halfPi"] - __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"];
    for(var i = 0, n = polygon.length; i < n; ++i){
        if (!(m = (ring = polygon[i]).length)) continue;
        var ring, m, point0 = ring[m - 1], lambda0 = longitude(point0), phi0 = point0[1] / 2 + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["quarterPi"], sinPhi0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(phi0), cosPhi0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(phi0);
        for(var j = 0; j < m; ++j, lambda0 = lambda1, sinPhi0 = sinPhi1, cosPhi0 = cosPhi1, point0 = point1){
            var point1 = ring[j], lambda1 = longitude(point1), phi1 = point1[1] / 2 + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["quarterPi"], sinPhi1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(phi1), cosPhi1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(phi1), delta = lambda1 - lambda0, sign = delta >= 0 ? 1 : -1, absDelta = sign * delta, antimeridian = absDelta > __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"], k = sinPhi0 * sinPhi1;
            sum.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atan2"])(k * sign * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(absDelta), cosPhi0 * cosPhi1 + k * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(absDelta)));
            angle += antimeridian ? delta + sign * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tau"] : delta;
            // Are the longitudes either side of the point’s meridian (lambda),
            // and are the latitudes smaller than the parallel (phi)?
            if (antimeridian ^ lambda0 >= lambda ^ lambda1 >= lambda) {
                var arc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianCross"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesian"])(point0), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesian"])(point1));
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianNormalizeInPlace"])(arc);
                var intersection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianCross"])(normal, arc);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianNormalizeInPlace"])(intersection);
                var phiArc = (antimeridian ^ delta >= 0 ? -1 : 1) * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asin"])(intersection[2]);
                if (phi > phiArc || phi === phiArc && (arc[0] || arc[1])) {
                    winding += antimeridian ^ delta >= 0 ? 1 : -1;
                }
            }
        }
    }
    // First, determine whether the South pole is inside or outside:
    //
    // It is inside if:
    // * the polygon winds around it in a clockwise direction.
    // * the polygon does not (cumulatively) wind around it, but has a negative
    //   (counter-clockwise) area.
    //
    // Second, count the (signed) number of times a segment crosses a lambda
    // from the point to the South pole.  If it is zero, then the point is the
    // same side as the South pole.
    return (angle < -__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"] || angle < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"] && sum < -__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"]) ^ winding & 1;
}
}),
"[project]/node_modules/d3-geo/src/clip/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/clip/buffer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$rejoin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/clip/rejoin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$polygonContains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/polygonContains.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$node_modules$2f$d3$2d$array$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/node_modules/d3-array/src/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$node_modules$2f$d3$2d$array$2f$src$2f$merge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__merge$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/node_modules/d3-array/src/merge.js [app-client] (ecmascript) <export default as merge>");
;
;
;
;
;
function __TURBOPACK__default__export__(pointVisible, clipLine, interpolate, start) {
    return function(sink) {
        var line = clipLine(sink), ringBuffer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(), ringSink = clipLine(ringBuffer), polygonStarted = false, polygon, segments, ring;
        var clip = {
            point: point,
            lineStart: lineStart,
            lineEnd: lineEnd,
            polygonStart: function() {
                clip.point = pointRing;
                clip.lineStart = ringStart;
                clip.lineEnd = ringEnd;
                segments = [];
                polygon = [];
            },
            polygonEnd: function() {
                clip.point = point;
                clip.lineStart = lineStart;
                clip.lineEnd = lineEnd;
                segments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$node_modules$2f$d3$2d$array$2f$src$2f$merge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__merge$3e$__["merge"])(segments);
                var startInside = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$polygonContains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(polygon, start);
                if (segments.length) {
                    if (!polygonStarted) sink.polygonStart(), polygonStarted = true;
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$rejoin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(segments, compareIntersection, startInside, interpolate, sink);
                } else if (startInside) {
                    if (!polygonStarted) sink.polygonStart(), polygonStarted = true;
                    sink.lineStart();
                    interpolate(null, null, 1, sink);
                    sink.lineEnd();
                }
                if (polygonStarted) sink.polygonEnd(), polygonStarted = false;
                segments = polygon = null;
            },
            sphere: function() {
                sink.polygonStart();
                sink.lineStart();
                interpolate(null, null, 1, sink);
                sink.lineEnd();
                sink.polygonEnd();
            }
        };
        function point(lambda, phi) {
            if (pointVisible(lambda, phi)) sink.point(lambda, phi);
        }
        function pointLine(lambda, phi) {
            line.point(lambda, phi);
        }
        function lineStart() {
            clip.point = pointLine;
            line.lineStart();
        }
        function lineEnd() {
            clip.point = point;
            line.lineEnd();
        }
        function pointRing(lambda, phi) {
            ring.push([
                lambda,
                phi
            ]);
            ringSink.point(lambda, phi);
        }
        function ringStart() {
            ringSink.lineStart();
            ring = [];
        }
        function ringEnd() {
            pointRing(ring[0][0], ring[0][1]);
            ringSink.lineEnd();
            var clean = ringSink.clean(), ringSegments = ringBuffer.result(), i, n = ringSegments.length, m, segment, point;
            ring.pop();
            polygon.push(ring);
            ring = null;
            if (!n) return;
            // No intersections.
            if (clean & 1) {
                segment = ringSegments[0];
                if ((m = segment.length - 1) > 0) {
                    if (!polygonStarted) sink.polygonStart(), polygonStarted = true;
                    sink.lineStart();
                    for(i = 0; i < m; ++i)sink.point((point = segment[i])[0], point[1]);
                    sink.lineEnd();
                }
                return;
            }
            // Rejoin connected segments.
            // TODO reuse ringBuffer.rejoin()?
            if (n > 1 && clean & 2) ringSegments.push(ringSegments.pop().concat(ringSegments.shift()));
            segments.push(ringSegments.filter(validSegment));
        }
        return clip;
    };
}
function validSegment(segment) {
    return segment.length > 1;
}
// Intersections are sorted along the clip edge. For both antimeridian cutting
// and circle clipping, the same comparison is used.
function compareIntersection(a, b) {
    return ((a = a.x)[0] < 0 ? a[1] - __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["halfPi"] - __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["halfPi"] - a[1]) - ((b = b.x)[0] < 0 ? b[1] - __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["halfPi"] - __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["halfPi"] - b[1]);
}
}),
"[project]/node_modules/d3-geo/src/clip/antimeridian.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/clip/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(function() {
    return true;
}, clipAntimeridianLine, clipAntimeridianInterpolate, [
    -__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"],
    -__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["halfPi"]
]);
// Takes a line and cuts into visible segments. Return values: 0 - there were
// intersections or the line was empty; 1 - no intersections; 2 - there were
// intersections, and the first and last segments should be rejoined.
function clipAntimeridianLine(stream) {
    var lambda0 = NaN, phi0 = NaN, sign0 = NaN, clean; // no intersections
    return {
        lineStart: function() {
            stream.lineStart();
            clean = 1;
        },
        point: function(lambda1, phi1) {
            var sign1 = lambda1 > 0 ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"] : -__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"], delta = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(lambda1 - lambda0);
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(delta - __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"]) < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"]) {
                stream.point(lambda0, phi0 = (phi0 + phi1) / 2 > 0 ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["halfPi"] : -__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["halfPi"]);
                stream.point(sign0, phi0);
                stream.lineEnd();
                stream.lineStart();
                stream.point(sign1, phi0);
                stream.point(lambda1, phi0);
                clean = 0;
            } else if (sign0 !== sign1 && delta >= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"]) {
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(lambda0 - sign0) < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"]) lambda0 -= sign0 * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"]; // handle degeneracies
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(lambda1 - sign1) < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"]) lambda1 -= sign1 * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"];
                phi0 = clipAntimeridianIntersect(lambda0, phi0, lambda1, phi1);
                stream.point(sign0, phi0);
                stream.lineEnd();
                stream.lineStart();
                stream.point(sign1, phi0);
                clean = 0;
            }
            stream.point(lambda0 = lambda1, phi0 = phi1);
            sign0 = sign1;
        },
        lineEnd: function() {
            stream.lineEnd();
            lambda0 = phi0 = NaN;
        },
        clean: function() {
            return 2 - clean; // if intersections, rejoin first and last segments
        }
    };
}
function clipAntimeridianIntersect(lambda0, phi0, lambda1, phi1) {
    var cosPhi0, cosPhi1, sinLambda0Lambda1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(lambda0 - lambda1);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(sinLambda0Lambda1) > __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"] ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atan"])(((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(phi0) * (cosPhi1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(phi1)) * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(lambda1) - (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(phi1) * (cosPhi0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(phi0)) * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(lambda0)) / (cosPhi0 * cosPhi1 * sinLambda0Lambda1)) : (phi0 + phi1) / 2;
}
function clipAntimeridianInterpolate(from, to, direction, stream) {
    var phi;
    if (from == null) {
        phi = direction * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["halfPi"];
        stream.point(-__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"], phi);
        stream.point(0, phi);
        stream.point(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"], phi);
        stream.point(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"], 0);
        stream.point(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"], -phi);
        stream.point(0, -phi);
        stream.point(-__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"], -phi);
        stream.point(-__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"], 0);
        stream.point(-__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"], phi);
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(from[0] - to[0]) > __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"]) {
        var lambda = from[0] < to[0] ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"] : -__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"];
        phi = direction * lambda / 2;
        stream.point(-lambda, phi);
        stream.point(0, phi);
        stream.point(lambda, phi);
    } else {
        stream.point(to[0], to[1]);
    }
}
}),
"[project]/node_modules/d3-geo/src/constant.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
function __TURBOPACK__default__export__(x) {
    return function() {
        return x;
    };
}
}),
"[project]/node_modules/d3-geo/src/circle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "circleStream",
    ()=>circleStream,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/cartesian.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$constant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/constant.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$rotation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/rotation.js [app-client] (ecmascript)");
;
;
;
;
function circleStream(stream, radius, delta, direction, t0, t1) {
    if (!delta) return;
    var cosRadius = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(radius), sinRadius = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(radius), step = direction * delta;
    if (t0 == null) {
        t0 = radius + direction * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tau"];
        t1 = radius - step / 2;
    } else {
        t0 = circleRadius(cosRadius, t0);
        t1 = circleRadius(cosRadius, t1);
        if (direction > 0 ? t0 < t1 : t0 > t1) t0 += direction * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tau"];
    }
    for(var point, t = t0; direction > 0 ? t > t1 : t < t1; t -= step){
        point = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["spherical"])([
            cosRadius,
            -sinRadius * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(t),
            -sinRadius * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(t)
        ]);
        stream.point(point[0], point[1]);
    }
}
// Returns the signed angle of a cartesian point relative to [cosRadius, 0, 0].
function circleRadius(cosRadius, point) {
    point = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesian"])(point), point[0] -= cosRadius;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianNormalizeInPlace"])(point);
    var radius = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["acos"])(-point[1]);
    return ((-point[2] < 0 ? -radius : radius) + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tau"] - __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"]) % __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tau"];
}
function __TURBOPACK__default__export__() {
    var center = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$constant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])([
        0,
        0
    ]), radius = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$constant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(90), precision = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$constant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(6), ring, rotate, stream = {
        point: point
    };
    function point(x, y) {
        ring.push(x = rotate(x, y));
        x[0] *= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"], x[1] *= __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"];
    }
    function circle() {
        var c = center.apply(this, arguments), r = radius.apply(this, arguments) * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], p = precision.apply(this, arguments) * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"];
        ring = [];
        rotate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$rotation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotateRadians"])(-c[0] * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], -c[1] * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], 0).invert;
        circleStream(stream, r, p, 1);
        c = {
            type: "Polygon",
            coordinates: [
                ring
            ]
        };
        ring = rotate = null;
        return c;
    }
    circle.center = function(_) {
        return arguments.length ? (center = typeof _ === "function" ? _ : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$constant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])([
            +_[0],
            +_[1]
        ]), circle) : center;
    };
    circle.radius = function(_) {
        return arguments.length ? (radius = typeof _ === "function" ? _ : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$constant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(+_), circle) : radius;
    };
    circle.precision = function(_) {
        return arguments.length ? (precision = typeof _ === "function" ? _ : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$constant$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(+_), circle) : precision;
    };
    return circle;
}
}),
"[project]/node_modules/d3-geo/src/clip/circle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/cartesian.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/circle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$pointEqual$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/pointEqual.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/clip/index.js [app-client] (ecmascript)");
;
;
;
;
;
function __TURBOPACK__default__export__(radius) {
    var cr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(radius), delta = 6 * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], smallRadius = cr > 0, notHemisphere = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(cr) > __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"]; // TODO optimise for this common case
    function interpolate(from, to, direction, stream) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["circleStream"])(stream, radius, delta, direction, from, to);
    }
    function visible(lambda, phi) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(lambda) * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(phi) > cr;
    }
    // Takes a line and cuts into visible segments. Return values used for polygon
    // clipping: 0 - there were intersections or the line was empty; 1 - no
    // intersections 2 - there were intersections, and the first and last segments
    // should be rejoined.
    function clipLine(stream) {
        var point0, c0, v0, v00, clean; // no intersections
        return {
            lineStart: function() {
                v00 = v0 = false;
                clean = 1;
            },
            point: function(lambda, phi) {
                var point1 = [
                    lambda,
                    phi
                ], point2, v = visible(lambda, phi), c = smallRadius ? v ? 0 : code(lambda, phi) : v ? code(lambda + (lambda < 0 ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"] : -__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"]), phi) : 0;
                if (!point0 && (v00 = v0 = v)) stream.lineStart();
                if (v !== v0) {
                    point2 = intersect(point0, point1);
                    if (!point2 || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$pointEqual$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(point0, point2) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$pointEqual$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(point1, point2)) point1[2] = 1;
                }
                if (v !== v0) {
                    clean = 0;
                    if (v) {
                        // outside going in
                        stream.lineStart();
                        point2 = intersect(point1, point0);
                        stream.point(point2[0], point2[1]);
                    } else {
                        // inside going out
                        point2 = intersect(point0, point1);
                        stream.point(point2[0], point2[1], 2);
                        stream.lineEnd();
                    }
                    point0 = point2;
                } else if (notHemisphere && point0 && smallRadius ^ v) {
                    var t;
                    // If the codes for two points are different, or are both zero,
                    // and there this segment intersects with the small circle.
                    if (!(c & c0) && (t = intersect(point1, point0, true))) {
                        clean = 0;
                        if (smallRadius) {
                            stream.lineStart();
                            stream.point(t[0][0], t[0][1]);
                            stream.point(t[1][0], t[1][1]);
                            stream.lineEnd();
                        } else {
                            stream.point(t[1][0], t[1][1]);
                            stream.lineEnd();
                            stream.lineStart();
                            stream.point(t[0][0], t[0][1], 3);
                        }
                    }
                }
                if (v && (!point0 || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$pointEqual$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(point0, point1))) {
                    stream.point(point1[0], point1[1]);
                }
                point0 = point1, v0 = v, c0 = c;
            },
            lineEnd: function() {
                if (v0) stream.lineEnd();
                point0 = null;
            },
            // Rejoin first and last segments if there were intersections and the first
            // and last points were visible.
            clean: function() {
                return clean | (v00 && v0) << 1;
            }
        };
    }
    // Intersects the great circle between a and b with the clip circle.
    function intersect(a, b, two) {
        var pa = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesian"])(a), pb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesian"])(b);
        // We have two planes, n1.p = d1 and n2.p = d2.
        // Find intersection line p(t) = c1 n1 + c2 n2 + t (n1 ⨯ n2).
        var n1 = [
            1,
            0,
            0
        ], n2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianCross"])(pa, pb), n2n2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianDot"])(n2, n2), n1n2 = n2[0], determinant = n2n2 - n1n2 * n1n2;
        // Two polar points.
        if (!determinant) return !two && a;
        var c1 = cr * n2n2 / determinant, c2 = -cr * n1n2 / determinant, n1xn2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianCross"])(n1, n2), A = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianScale"])(n1, c1), B = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianScale"])(n2, c2);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianAddInPlace"])(A, B);
        // Solve |p(t)|^2 = 1.
        var u = n1xn2, w = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianDot"])(A, u), uu = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianDot"])(u, u), t2 = w * w - uu * ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianDot"])(A, A) - 1);
        if (t2 < 0) return;
        var t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sqrt"])(t2), q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianScale"])(u, (-w - t) / uu);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianAddInPlace"])(q, A);
        q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["spherical"])(q);
        if (!two) return q;
        // Two intersection points.
        var lambda0 = a[0], lambda1 = b[0], phi0 = a[1], phi1 = b[1], z;
        if (lambda1 < lambda0) z = lambda0, lambda0 = lambda1, lambda1 = z;
        var delta = lambda1 - lambda0, polar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(delta - __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"]) < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"], meridian = polar || delta < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"];
        if (!polar && phi1 < phi0) z = phi0, phi0 = phi1, phi1 = z;
        // Check that the first point is between a and b.
        if (meridian ? polar ? phi0 + phi1 > 0 ^ q[1] < ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(q[0] - lambda0) < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"] ? phi0 : phi1) : phi0 <= q[1] && q[1] <= phi1 : delta > __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"] ^ (lambda0 <= q[0] && q[0] <= lambda1)) {
            var q1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianScale"])(u, (-w + t) / uu);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesianAddInPlace"])(q1, A);
            return [
                q,
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["spherical"])(q1)
            ];
        }
    }
    // Generates a 4-bit vector representing the location of a point relative to
    // the small circle's bounding box.
    function code(lambda, phi) {
        var r = smallRadius ? radius : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"] - radius, code = 0;
        if (lambda < -r) code |= 1; // left
        else if (lambda > r) code |= 2; // right
        if (phi < -r) code |= 4; // below
        else if (phi > r) code |= 8; // above
        return code;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(visible, clipLine, interpolate, smallRadius ? [
        0,
        -radius
    ] : [
        -__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"],
        radius - __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"]
    ]);
}
}),
"[project]/node_modules/d3-geo/src/projection/resample.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/cartesian.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$transform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/transform.js [app-client] (ecmascript)");
;
;
;
var maxDepth = 16, cosMinDistance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(30 * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"]); // cos(minimum angular distance)
function __TURBOPACK__default__export__(project, delta2) {
    return +delta2 ? resample(project, delta2) : resampleNone(project);
}
function resampleNone(project) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$transform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transformer"])({
        point: function(x, y) {
            x = project(x, y);
            this.stream.point(x[0], x[1]);
        }
    });
}
function resample(project, delta2) {
    function resampleLineTo(x0, y0, lambda0, a0, b0, c0, x1, y1, lambda1, a1, b1, c1, depth, stream) {
        var dx = x1 - x0, dy = y1 - y0, d2 = dx * dx + dy * dy;
        if (d2 > 4 * delta2 && depth--) {
            var a = a0 + a1, b = b0 + b1, c = c0 + c1, m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sqrt"])(a * a + b * b + c * c), phi2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asin"])(c /= m), lambda2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(c) - 1) < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"] || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(lambda0 - lambda1) < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon"] ? (lambda0 + lambda1) / 2 : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atan2"])(b, a), p = project(lambda2, phi2), x2 = p[0], y2 = p[1], dx2 = x2 - x0, dy2 = y2 - y0, dz = dy * dx2 - dx * dy2;
            if (dz * dz / d2 > delta2 // perpendicular projected distance
             || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])((dx * dx2 + dy * dy2) / d2 - 0.5) > 0.3 // midpoint close to an end
             || a0 * a1 + b0 * b1 + c0 * c1 < cosMinDistance) {
                resampleLineTo(x0, y0, lambda0, a0, b0, c0, x2, y2, lambda2, a /= m, b /= m, c, depth, stream);
                stream.point(x2, y2);
                resampleLineTo(x2, y2, lambda2, a, b, c, x1, y1, lambda1, a1, b1, c1, depth, stream);
            }
        }
    }
    return function(stream) {
        var lambda00, x00, y00, a00, b00, c00, lambda0, x0, y0, a0, b0, c0; // previous point
        var resampleStream = {
            point: point,
            lineStart: lineStart,
            lineEnd: lineEnd,
            polygonStart: function() {
                stream.polygonStart();
                resampleStream.lineStart = ringStart;
            },
            polygonEnd: function() {
                stream.polygonEnd();
                resampleStream.lineStart = lineStart;
            }
        };
        function point(x, y) {
            x = project(x, y);
            stream.point(x[0], x[1]);
        }
        function lineStart() {
            x0 = NaN;
            resampleStream.point = linePoint;
            stream.lineStart();
        }
        function linePoint(lambda, phi) {
            var c = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$cartesian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cartesian"])([
                lambda,
                phi
            ]), p = project(lambda, phi);
            resampleLineTo(x0, y0, lambda0, a0, b0, c0, x0 = p[0], y0 = p[1], lambda0 = lambda, a0 = c[0], b0 = c[1], c0 = c[2], maxDepth, stream);
            stream.point(x0, y0);
        }
        function lineEnd() {
            resampleStream.point = point;
            stream.lineEnd();
        }
        function ringStart() {
            lineStart();
            resampleStream.point = ringPoint;
            resampleStream.lineEnd = ringEnd;
        }
        function ringPoint(lambda, phi) {
            linePoint(lambda00 = lambda, phi), x00 = x0, y00 = y0, a00 = a0, b00 = b0, c00 = c0;
            resampleStream.point = linePoint;
        }
        function ringEnd() {
            resampleLineTo(x0, y0, lambda0, a0, b0, c0, x00, y00, lambda00, a00, b00, c00, maxDepth, stream);
            resampleStream.lineEnd = lineEnd;
            lineEnd();
        }
        return resampleStream;
    };
}
}),
"[project]/node_modules/d3-geo/src/projection/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>projection,
    "projectionMutator",
    ()=>projectionMutator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$antimeridian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/clip/antimeridian.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/clip/circle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$rectangle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/clip/rectangle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$compose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/compose.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$identity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/identity.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$rotation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/rotation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$transform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/transform.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$fit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/projection/fit.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$resample$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/projection/resample.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
var transformRadians = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$transform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transformer"])({
    point: function(x, y) {
        this.stream.point(x * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], y * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"]);
    }
});
function transformRotate(rotate) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$transform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transformer"])({
        point: function(x, y) {
            var r = rotate(x, y);
            return this.stream.point(r[0], r[1]);
        }
    });
}
function scaleTranslate(k, dx, dy, sx, sy) {
    function transform(x, y) {
        x *= sx;
        y *= sy;
        return [
            dx + k * x,
            dy - k * y
        ];
    }
    transform.invert = function(x, y) {
        return [
            (x - dx) / k * sx,
            (dy - y) / k * sy
        ];
    };
    return transform;
}
function scaleTranslateRotate(k, dx, dy, sx, sy, alpha) {
    var cosAlpha = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(alpha), sinAlpha = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(alpha), a = cosAlpha * k, b = sinAlpha * k, ai = cosAlpha / k, bi = sinAlpha / k, ci = (sinAlpha * dy - cosAlpha * dx) / k, fi = (sinAlpha * dx + cosAlpha * dy) / k;
    function transform(x, y) {
        x *= sx;
        y *= sy;
        return [
            a * x - b * y + dx,
            dy - b * x - a * y
        ];
    }
    transform.invert = function(x, y) {
        return [
            sx * (ai * x - bi * y + ci),
            sy * (fi - bi * x - ai * y)
        ];
    };
    return transform;
}
function projection(project) {
    return projectionMutator(function() {
        return project;
    })();
}
function projectionMutator(projectAt) {
    var project, k = 150, x = 480, y = 250, lambda = 0, phi = 0, deltaLambda = 0, deltaPhi = 0, deltaGamma = 0, rotate, alpha = 0, sx = 1, sy = 1, theta = null, preclip = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$antimeridian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], x0 = null, y0, x1, y1, postclip = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$identity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], delta2 = 0.5, projectResample, projectTransform, projectRotateTransform, cache, cacheStream;
    function projection(point) {
        return projectRotateTransform(point[0] * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], point[1] * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"]);
    }
    function invert(point) {
        point = projectRotateTransform.invert(point[0], point[1]);
        return point && [
            point[0] * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"],
            point[1] * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"]
        ];
    }
    projection.stream = function(stream) {
        return cache && cacheStream === stream ? cache : cache = transformRadians(transformRotate(rotate)(preclip(projectResample(postclip(cacheStream = stream)))));
    };
    projection.preclip = function(_) {
        return arguments.length ? (preclip = _, theta = undefined, reset()) : preclip;
    };
    projection.postclip = function(_) {
        return arguments.length ? (postclip = _, x0 = y0 = x1 = y1 = null, reset()) : postclip;
    };
    projection.clipAngle = function(_) {
        return arguments.length ? (preclip = +_ ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(theta = _ * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"]) : (theta = null, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$antimeridian$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]), reset()) : theta * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"];
    };
    projection.clipExtent = function(_) {
        return arguments.length ? (postclip = _ == null ? (x0 = y0 = x1 = y1 = null, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$identity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$clip$2f$rectangle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(x0 = +_[0][0], y0 = +_[0][1], x1 = +_[1][0], y1 = +_[1][1]), reset()) : x0 == null ? null : [
            [
                x0,
                y0
            ],
            [
                x1,
                y1
            ]
        ];
    };
    projection.scale = function(_) {
        return arguments.length ? (k = +_, recenter()) : k;
    };
    projection.translate = function(_) {
        return arguments.length ? (x = +_[0], y = +_[1], recenter()) : [
            x,
            y
        ];
    };
    projection.center = function(_) {
        return arguments.length ? (lambda = _[0] % 360 * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], phi = _[1] % 360 * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], recenter()) : [
            lambda * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"],
            phi * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"]
        ];
    };
    projection.rotate = function(_) {
        return arguments.length ? (deltaLambda = _[0] % 360 * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], deltaPhi = _[1] % 360 * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], deltaGamma = _.length > 2 ? _[2] % 360 * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"] : 0, recenter()) : [
            deltaLambda * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"],
            deltaPhi * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"],
            deltaGamma * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"]
        ];
    };
    projection.angle = function(_) {
        return arguments.length ? (alpha = _ % 360 * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radians"], recenter()) : alpha * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["degrees"];
    };
    projection.reflectX = function(_) {
        return arguments.length ? (sx = _ ? -1 : 1, recenter()) : sx < 0;
    };
    projection.reflectY = function(_) {
        return arguments.length ? (sy = _ ? -1 : 1, recenter()) : sy < 0;
    };
    projection.precision = function(_) {
        return arguments.length ? (projectResample = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$resample$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(projectTransform, delta2 = _ * _), reset()) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sqrt"])(delta2);
    };
    projection.fitExtent = function(extent, object) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$fit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fitExtent"])(projection, extent, object);
    };
    projection.fitSize = function(size, object) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$fit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fitSize"])(projection, size, object);
    };
    projection.fitWidth = function(width, object) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$fit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fitWidth"])(projection, width, object);
    };
    projection.fitHeight = function(height, object) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$fit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fitHeight"])(projection, height, object);
    };
    function recenter() {
        var center = scaleTranslateRotate(k, 0, 0, sx, sy, alpha).apply(null, project(lambda, phi)), transform = (alpha ? scaleTranslateRotate : scaleTranslate)(k, x - center[0], y - center[1], sx, sy, alpha);
        rotate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$rotation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rotateRadians"])(deltaLambda, deltaPhi, deltaGamma);
        projectTransform = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$compose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(project, transform);
        projectRotateTransform = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$compose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(rotate, projectTransform);
        projectResample = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$resample$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(projectTransform, delta2);
        return reset();
    }
    function reset() {
        cache = cacheStream = null;
        return projection;
    }
    return function() {
        project = projectAt.apply(this, arguments);
        projection.invert = project.invert && invert;
        return recenter();
    };
}
}),
"[project]/node_modules/d3-geo/src/projection/mercator.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "mercatorProjection",
    ()=>mercatorProjection,
    "mercatorRaw",
    ()=>mercatorRaw
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$rotation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/rotation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/projection/index.js [app-client] (ecmascript)");
;
;
;
function mercatorRaw(lambda, phi) {
    return [
        lambda,
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["log"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tan"])((__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["halfPi"] + phi) / 2))
    ];
}
mercatorRaw.invert = function(x, y) {
    return [
        x,
        2 * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atan"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["exp"])(y)) - __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["halfPi"]
    ];
};
function __TURBOPACK__default__export__() {
    return mercatorProjection(mercatorRaw).scale(961 / __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tau"]);
}
function mercatorProjection(project) {
    var m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(project), center = m.center, scale = m.scale, translate = m.translate, clipExtent = m.clipExtent, x0 = null, y0, x1, y1; // clip extent
    m.scale = function(_) {
        return arguments.length ? (scale(_), reclip()) : scale();
    };
    m.translate = function(_) {
        return arguments.length ? (translate(_), reclip()) : translate();
    };
    m.center = function(_) {
        return arguments.length ? (center(_), reclip()) : center();
    };
    m.clipExtent = function(_) {
        return arguments.length ? (_ == null ? x0 = y0 = x1 = y1 = null : (x0 = +_[0][0], y0 = +_[0][1], x1 = +_[1][0], y1 = +_[1][1]), reclip()) : x0 == null ? null : [
            [
                x0,
                y0
            ],
            [
                x1,
                y1
            ]
        ];
    };
    function reclip() {
        var k = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pi"] * scale(), t = m((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$rotation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(m.rotate()).invert([
            0,
            0
        ]));
        return clipExtent(x0 == null ? [
            [
                t[0] - k,
                t[1] - k
            ],
            [
                t[0] + k,
                t[1] + k
            ]
        ] : project === mercatorRaw ? [
            [
                Math.max(t[0] - k, x0),
                y0
            ],
            [
                Math.min(t[0] + k, x1),
                y1
            ]
        ] : [
            [
                x0,
                Math.max(t[1] - k, y0)
            ],
            [
                x1,
                Math.min(t[1] + k, y1)
            ]
        ]);
    }
    return reclip();
}
}),
"[project]/node_modules/d3-geo/src/projection/mercator.js [app-client] (ecmascript) <export default as geoMercator>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "geoMercator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$mercator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$mercator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/projection/mercator.js [app-client] (ecmascript)");
}),
"[project]/node_modules/d3-geo/src/projection/equalEarth.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "equalEarthRaw",
    ()=>equalEarthRaw
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/projection/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
;
;
var A1 = 1.340264, A2 = -0.081106, A3 = 0.000893, A4 = 0.003796, M = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sqrt"])(3) / 2, iterations = 12;
function equalEarthRaw(lambda, phi) {
    var l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asin"])(M * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(phi)), l2 = l * l, l6 = l2 * l2 * l2;
    return [
        lambda * (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(l) / (M * (A1 + 3 * A2 * l2 + l6 * (7 * A3 + 9 * A4 * l2))),
        l * (A1 + A2 * l2 + l6 * (A3 + A4 * l2))
    ];
}
equalEarthRaw.invert = function(x, y) {
    var l = y, l2 = l * l, l6 = l2 * l2 * l2;
    for(var i = 0, delta, fy, fpy; i < iterations; ++i){
        fy = l * (A1 + A2 * l2 + l6 * (A3 + A4 * l2)) - y;
        fpy = A1 + 3 * A2 * l2 + l6 * (7 * A3 + 9 * A4 * l2);
        l -= delta = fy / fpy, l2 = l * l, l6 = l2 * l2 * l2;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(delta) < __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["epsilon2"]) break;
    }
    return [
        M * x * (A1 + 3 * A2 * l2 + l6 * (7 * A3 + 9 * A4 * l2)) / (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cos"])(l),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["asin"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sin"])(l) / M)
    ];
};
function __TURBOPACK__default__export__() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(equalEarthRaw).scale(177.158);
}
}),
"[project]/node_modules/d3-geo/src/projection/equalEarth.js [app-client] (ecmascript) <export default as geoEqualEarth>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "geoEqualEarth",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$equalEarth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$equalEarth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/projection/equalEarth.js [app-client] (ecmascript)");
}),
"[project]/node_modules/d3-geo/src/path/area.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$adder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/adder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/noop.js [app-client] (ecmascript)");
;
;
;
var areaSum = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$adder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(), areaRingSum = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$adder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(), x00, y00, x0, y0;
var areaStream = {
    point: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    lineStart: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    lineEnd: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    polygonStart: function() {
        areaStream.lineStart = areaRingStart;
        areaStream.lineEnd = areaRingEnd;
    },
    polygonEnd: function() {
        areaStream.lineStart = areaStream.lineEnd = areaStream.point = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
        areaSum.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["abs"])(areaRingSum));
        areaRingSum.reset();
    },
    result: function() {
        var area = areaSum / 2;
        areaSum.reset();
        return area;
    }
};
function areaRingStart() {
    areaStream.point = areaPointFirst;
}
function areaPointFirst(x, y) {
    areaStream.point = areaPoint;
    x00 = x0 = x, y00 = y0 = y;
}
function areaPoint(x, y) {
    areaRingSum.add(y0 * x - x0 * y);
    x0 = x, y0 = y;
}
function areaRingEnd() {
    areaPoint(x00, y00);
}
const __TURBOPACK__default__export__ = areaStream;
}),
"[project]/node_modules/d3-geo/src/path/centroid.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
;
// TODO Enforce positive area for exterior, negative area for interior?
var X0 = 0, Y0 = 0, Z0 = 0, X1 = 0, Y1 = 0, Z1 = 0, X2 = 0, Y2 = 0, Z2 = 0, x00, y00, x0, y0;
var centroidStream = {
    point: centroidPoint,
    lineStart: centroidLineStart,
    lineEnd: centroidLineEnd,
    polygonStart: function() {
        centroidStream.lineStart = centroidRingStart;
        centroidStream.lineEnd = centroidRingEnd;
    },
    polygonEnd: function() {
        centroidStream.point = centroidPoint;
        centroidStream.lineStart = centroidLineStart;
        centroidStream.lineEnd = centroidLineEnd;
    },
    result: function() {
        var centroid = Z2 ? [
            X2 / Z2,
            Y2 / Z2
        ] : Z1 ? [
            X1 / Z1,
            Y1 / Z1
        ] : Z0 ? [
            X0 / Z0,
            Y0 / Z0
        ] : [
            NaN,
            NaN
        ];
        X0 = Y0 = Z0 = X1 = Y1 = Z1 = X2 = Y2 = Z2 = 0;
        return centroid;
    }
};
function centroidPoint(x, y) {
    X0 += x;
    Y0 += y;
    ++Z0;
}
function centroidLineStart() {
    centroidStream.point = centroidPointFirstLine;
}
function centroidPointFirstLine(x, y) {
    centroidStream.point = centroidPointLine;
    centroidPoint(x0 = x, y0 = y);
}
function centroidPointLine(x, y) {
    var dx = x - x0, dy = y - y0, z = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sqrt"])(dx * dx + dy * dy);
    X1 += z * (x0 + x) / 2;
    Y1 += z * (y0 + y) / 2;
    Z1 += z;
    centroidPoint(x0 = x, y0 = y);
}
function centroidLineEnd() {
    centroidStream.point = centroidPoint;
}
function centroidRingStart() {
    centroidStream.point = centroidPointFirstRing;
}
function centroidRingEnd() {
    centroidPointRing(x00, y00);
}
function centroidPointFirstRing(x, y) {
    centroidStream.point = centroidPointRing;
    centroidPoint(x00 = x0 = x, y00 = y0 = y);
}
function centroidPointRing(x, y) {
    var dx = x - x0, dy = y - y0, z = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sqrt"])(dx * dx + dy * dy);
    X1 += z * (x0 + x) / 2;
    Y1 += z * (y0 + y) / 2;
    Z1 += z;
    z = y0 * x - x0 * y;
    X2 += z * (x0 + x);
    Y2 += z * (y0 + y);
    Z2 += z * 3;
    centroidPoint(x0 = x, y0 = y);
}
const __TURBOPACK__default__export__ = centroidStream;
}),
"[project]/node_modules/d3-geo/src/path/context.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PathContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/noop.js [app-client] (ecmascript)");
;
;
function PathContext(context) {
    this._context = context;
}
PathContext.prototype = {
    _radius: 4.5,
    pointRadius: function(_) {
        return this._radius = _, this;
    },
    polygonStart: function() {
        this._line = 0;
    },
    polygonEnd: function() {
        this._line = NaN;
    },
    lineStart: function() {
        this._point = 0;
    },
    lineEnd: function() {
        if (this._line === 0) this._context.closePath();
        this._point = NaN;
    },
    point: function(x, y) {
        switch(this._point){
            case 0:
                {
                    this._context.moveTo(x, y);
                    this._point = 1;
                    break;
                }
            case 1:
                {
                    this._context.lineTo(x, y);
                    break;
                }
            default:
                {
                    this._context.moveTo(x + this._radius, y);
                    this._context.arc(x, y, this._radius, 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tau"]);
                    break;
                }
        }
    },
    result: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
};
}),
"[project]/node_modules/d3-geo/src/path/measure.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$adder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/adder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/math.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/noop.js [app-client] (ecmascript)");
;
;
;
var lengthSum = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$adder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(), lengthRing, x00, y00, x0, y0;
var lengthStream = {
    point: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    lineStart: function() {
        lengthStream.point = lengthPointFirst;
    },
    lineEnd: function() {
        if (lengthRing) lengthPoint(x00, y00);
        lengthStream.point = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$noop$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
    },
    polygonStart: function() {
        lengthRing = true;
    },
    polygonEnd: function() {
        lengthRing = null;
    },
    result: function() {
        var length = +lengthSum;
        lengthSum.reset();
        return length;
    }
};
function lengthPointFirst(x, y) {
    lengthStream.point = lengthPoint;
    x00 = x0 = x, y00 = y0 = y;
}
function lengthPoint(x, y) {
    x0 -= x, y0 -= y;
    lengthSum.add((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$math$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sqrt"])(x0 * x0 + y0 * y0));
    x0 = x, y0 = y;
}
const __TURBOPACK__default__export__ = lengthStream;
}),
"[project]/node_modules/d3-geo/src/path/string.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PathString
]);
function PathString() {
    this._string = [];
}
PathString.prototype = {
    _radius: 4.5,
    _circle: circle(4.5),
    pointRadius: function(_) {
        if ((_ = +_) !== this._radius) this._radius = _, this._circle = null;
        return this;
    },
    polygonStart: function() {
        this._line = 0;
    },
    polygonEnd: function() {
        this._line = NaN;
    },
    lineStart: function() {
        this._point = 0;
    },
    lineEnd: function() {
        if (this._line === 0) this._string.push("Z");
        this._point = NaN;
    },
    point: function(x, y) {
        switch(this._point){
            case 0:
                {
                    this._string.push("M", x, ",", y);
                    this._point = 1;
                    break;
                }
            case 1:
                {
                    this._string.push("L", x, ",", y);
                    break;
                }
            default:
                {
                    if (this._circle == null) this._circle = circle(this._radius);
                    this._string.push("M", x, ",", y, this._circle);
                    break;
                }
        }
    },
    result: function() {
        if (this._string.length) {
            var result = this._string.join("");
            this._string = [];
            return result;
        } else {
            return null;
        }
    }
};
function circle(radius) {
    return "m0," + radius + "a" + radius + "," + radius + " 0 1,1 0," + -2 * radius + "a" + radius + "," + radius + " 0 1,1 0," + 2 * radius + "z";
}
}),
"[project]/node_modules/d3-geo/src/path/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$identity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/identity.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$stream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/stream.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$area$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/path/area.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$bounds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/path/bounds.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$centroid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/path/centroid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/path/context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$measure$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/path/measure.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/path/string.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
function __TURBOPACK__default__export__(projection, context) {
    var pointRadius = 4.5, projectionStream, contextStream;
    function path(object) {
        if (object) {
            if (typeof pointRadius === "function") contextStream.pointRadius(+pointRadius.apply(this, arguments));
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$stream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(object, projectionStream(contextStream));
        }
        return contextStream.result();
    }
    path.area = function(object) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$stream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(object, projectionStream(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$area$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]));
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$area$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].result();
    };
    path.measure = function(object) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$stream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(object, projectionStream(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$measure$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]));
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$measure$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].result();
    };
    path.bounds = function(object) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$stream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(object, projectionStream(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$bounds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]));
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$bounds$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].result();
    };
    path.centroid = function(object) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$stream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(object, projectionStream(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$centroid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]));
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$centroid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].result();
    };
    path.projection = function(_) {
        return arguments.length ? (projectionStream = _ == null ? (projection = null, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$identity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) : (projection = _).stream, path) : projection;
    };
    path.context = function(_) {
        if (!arguments.length) return context;
        contextStream = _ == null ? (context = null, new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]) : new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](context = _);
        if (typeof pointRadius !== "function") contextStream.pointRadius(pointRadius);
        return path;
    };
    path.pointRadius = function(_) {
        if (!arguments.length) return pointRadius;
        pointRadius = typeof _ === "function" ? _ : (contextStream.pointRadius(+_), +_);
        return path;
    };
    return path.projection(projection).context(context);
}
}),
"[project]/node_modules/d3-geo/src/path/index.js [app-client] (ecmascript) <export default as geoPath>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "geoPath",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/path/index.js [app-client] (ecmascript)");
}),
]);

//# debugId=2bb265b8-6ca3-8408-3782-04dcb2ab8e20
//# sourceMappingURL=node_modules_d3-geo_src_12gpvo6._.js.map