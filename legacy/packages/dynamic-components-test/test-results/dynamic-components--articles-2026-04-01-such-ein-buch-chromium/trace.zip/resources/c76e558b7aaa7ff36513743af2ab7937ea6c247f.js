;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="d067472c-5a86-1a66-2995-0d6fb5c364e4")}catch(e){}}();
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@apollo/client-react-streaming/dist/SimulatePreloadedQuery.cc.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_@apollo_0pn98c8._.js",
  "static/chunks/0_lp_modules_@apollo_client-react-streaming_dist_SimulatePreloadedQuery_cc_05h6f.1.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@apollo/client-react-streaming/dist/SimulatePreloadedQuery.cc.js [app-client] (ecmascript)");
    });
});
}),
]);

//# debugId=d067472c-5a86-1a66-2995-0d6fb5c364e4