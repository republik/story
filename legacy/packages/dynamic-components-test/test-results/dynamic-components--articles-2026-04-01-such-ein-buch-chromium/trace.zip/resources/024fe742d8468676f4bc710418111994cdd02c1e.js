;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="3cc8590c-89fe-cd86-15d5-cca63a632df8")}catch(e){}}();
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/packages/styleguide/dist/chunk-QCYBJGVP.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "A",
    ()=>A,
    "A2",
    ()=>A2,
    "BREAKOUT",
    ()=>BREAKOUT,
    "BREAKOUT_SIZES",
    ()=>BREAKOUT_SIZES,
    "Breakout",
    ()=>Breakout,
    "CHART_DEFAULT_FILL",
    ()=>CHART_DEFAULT_FILL,
    "Center_default",
    ()=>Center_default,
    "Chart",
    ()=>Chart,
    "ChartLead",
    ()=>ChartLead,
    "ChartLegend",
    ()=>ChartLegend,
    "ChartTitle",
    ()=>ChartTitle,
    "Collapsable_default",
    ()=>Collapsable_default,
    "ColorContextLocalExtension",
    ()=>ColorContextLocalExtension,
    "ColorContextProvider",
    ()=>ColorContextProvider,
    "ColorContext_default",
    ()=>ColorContext_default,
    "Credit",
    ()=>Credit,
    "DEFAULT_FONT_SIZE",
    ()=>DEFAULT_FONT_SIZE,
    "Editorial",
    ()=>Editorial,
    "Editorial_exports",
    ()=>Editorial_exports,
    "Format",
    ()=>Format,
    "H1",
    ()=>H12,
    "H2",
    ()=>H22,
    "HR",
    ()=>HR,
    "Headline",
    ()=>Headline,
    "Headline2",
    ()=>Headline2,
    "Headline3",
    ()=>Headline3,
    "Headline4",
    ()=>Headline4,
    "InlineSpinner",
    ()=>InlineSpinner,
    "Interaction",
    ()=>Interaction,
    "InvertedColorScheme",
    ()=>InvertedColorScheme,
    "Label",
    ()=>Label,
    "LazyLoad_default",
    ()=>LazyLoad_default,
    "Lead",
    ()=>Lead,
    "Lead2",
    ()=>Lead2,
    "Lead3",
    ()=>Lead3,
    "List",
    ()=>List,
    "ListItem",
    ()=>ListItem,
    "Loader_default",
    ()=>Loader_default,
    "MAX_WIDTH",
    ()=>MAX_WIDTH,
    "MAX_WIDTH_MOBILE",
    ()=>MAX_WIDTH_MOBILE,
    "Meta",
    ()=>Meta,
    "Meta_exports",
    ()=>Meta_exports,
    "Note",
    ()=>Note,
    "P",
    ()=>P,
    "P2",
    ()=>P2,
    "P3",
    ()=>P4,
    "PADDED_MAX_WIDTH",
    ()=>PADDED_MAX_WIDTH,
    "PADDED_MAX_WIDTH_BREAKOUT",
    ()=>PADDED_MAX_WIDTH_BREAKOUT,
    "PADDING",
    ()=>PADDING,
    "RootColorVariables",
    ()=>RootColorVariables,
    "Spinner",
    ()=>Spinner,
    "Spinner_default",
    ()=>Spinner_default,
    "Sub",
    ()=>Sub,
    "Subhead",
    ()=>Subhead,
    "Subhead2",
    ()=>Subhead2,
    "Subject",
    ()=>Subject,
    "Sup",
    ()=>Sup,
    "__async",
    ()=>__async,
    "__export",
    ()=>__export,
    "__objRest",
    ()=>__objRest,
    "__spreadProps",
    ()=>__spreadProps,
    "__spreadValues",
    ()=>__spreadValues,
    "breakoutStyles",
    ()=>breakoutStyles,
    "breakoutUp",
    ()=>breakoutUp,
    "colorMaps",
    ()=>colorMaps,
    "colors_default",
    ()=>colors_default,
    "convertStyleToRem",
    ()=>convertStyleToRem,
    "createFormatter",
    ()=>createFormatter,
    "createPlaceholderFormatter",
    ()=>createPlaceholderFormatter,
    "createRanges",
    ()=>createRanges,
    "cursiveTitle20",
    ()=>cursiveTitle20,
    "cursiveTitle22",
    ()=>cursiveTitle22,
    "cursiveTitle26",
    ()=>cursiveTitle26,
    "cursiveTitle32",
    ()=>cursiveTitle32,
    "deduplicate",
    ()=>deduplicate,
    "defaultProps",
    ()=>defaultProps,
    "ellipsize",
    ()=>ellipsize,
    "fontFamilies",
    ()=>fontFamilies,
    "fontStyles",
    ()=>fontStyles,
    "fontStyles2",
    ()=>fontStyles2,
    "interactionFontRule",
    ()=>interactionFontRule,
    "linkRule",
    ()=>linkRule,
    "linkStyle",
    ()=>linkStyle,
    "mBreakPoint",
    ()=>mBreakPoint,
    "mUp",
    ()=>mUp,
    "mUpAndPrint",
    ()=>mUpAndPrint,
    "mediaQueries_exports",
    ()=>mediaQueries_exports,
    "onlyS",
    ()=>onlyS,
    "plainLinkRule",
    ()=>plainLinkRule,
    "pxToRem",
    ()=>pxToRem,
    "runSort",
    ()=>runSort,
    "sansSerifMedium12",
    ()=>sansSerifMedium12,
    "sansSerifMedium14",
    ()=>sansSerifMedium14,
    "sansSerifMedium15",
    ()=>sansSerifMedium15,
    "sansSerifMedium16",
    ()=>sansSerifMedium16,
    "sansSerifMedium18",
    ()=>sansSerifMedium18,
    "sansSerifMedium19",
    ()=>sansSerifMedium19,
    "sansSerifMedium20",
    ()=>sansSerifMedium20,
    "sansSerifMedium22",
    ()=>sansSerifMedium22,
    "sansSerifMedium26",
    ()=>sansSerifMedium26,
    "sansSerifMedium32",
    ()=>sansSerifMedium32,
    "sansSerifMedium58",
    ()=>sansSerifMedium58,
    "sansSerifRegular10",
    ()=>sansSerifRegular10,
    "sansSerifRegular12",
    ()=>sansSerifRegular12,
    "sansSerifRegular13",
    ()=>sansSerifRegular13,
    "sansSerifRegular14",
    ()=>sansSerifRegular14,
    "sansSerifRegular15",
    ()=>sansSerifRegular15,
    "sansSerifRegular16",
    ()=>sansSerifRegular16,
    "sansSerifRegular17",
    ()=>sansSerifRegular17,
    "sansSerifRegular18",
    ()=>sansSerifRegular18,
    "sansSerifRegular19",
    ()=>sansSerifRegular19,
    "sansSerifRegular21",
    ()=>sansSerifRegular21,
    "sansSerifRegular22",
    ()=>sansSerifRegular22,
    "sansSerifRegular23",
    ()=>sansSerifRegular23,
    "sansSerifRegular30",
    ()=>sansSerifRegular30,
    "serifBold24",
    ()=>serifBold24,
    "serifBold28",
    ()=>serifBold28,
    "serifBold32",
    ()=>serifBold32,
    "serifBold42",
    ()=>serifBold42,
    "serifRegular14",
    ()=>serifRegular14,
    "serifRegular15",
    ()=>serifRegular15,
    "serifRegular16",
    ()=>serifRegular16,
    "serifRegular17",
    ()=>serifRegular17,
    "serifRegular18",
    ()=>serifRegular18,
    "serifRegular19",
    ()=>serifRegular19,
    "serifRegular23",
    ()=>serifRegular23,
    "serifTitle16",
    ()=>serifTitle16,
    "serifTitle20",
    ()=>serifTitle20,
    "serifTitle22",
    ()=>serifTitle22,
    "serifTitle26",
    ()=>serifTitle26,
    "serifTitle32",
    ()=>serifTitle32,
    "serifTitle38",
    ()=>serifTitle38,
    "serifTitle58",
    ()=>serifTitle58,
    "shouldIgnoreClick",
    ()=>shouldIgnoreClick,
    "timeFormat",
    ()=>timeFormat,
    "timeParse",
    ()=>timeParse,
    "underline",
    ()=>underline,
    "useBoundingClientRect",
    ()=>useBoundingClientRect,
    "useColorContext",
    ()=>useColorContext,
    "useMediaQuery",
    ()=>useMediaQuery
]);
// src/components/Chart/index.js
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/glamor/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/linear.js [app-client] (ecmascript) <export default as scaleLinear>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/styleguide/node_modules/d3-array/src/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__ = __turbopack_context__.i("[project]/packages/styleguide/node_modules/d3-array/src/max.js [app-client] (ecmascript) <export default as max>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__ = __turbopack_context__.i("[project]/packages/styleguide/node_modules/d3-array/src/min.js [app-client] (ecmascript) <export default as min>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$memoize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lodash/memoize.js [app-client] (ecmascript)");
// src/components/Colors/ColorContext.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
// src/lib/timeFormat.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$time$2d$format$2f$src$2f$locale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__timeFormatLocale$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-time-format/src/locale.js [app-client] (ecmascript) <export default as timeFormatLocale>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$time$2d$format$2f$locale$2f$de$2d$CH$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-time-format/locale/de-CH.json.[json].cjs [app-client] (ecmascript)");
// src/components/Chart/colorMaps.js
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$ordinal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleOrdinal$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/ordinal.js [app-client] (ecmascript) <export default as scaleOrdinal>");
// src/components/Chart/ChartContext.js
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$identity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__geoIdentity$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/projection/identity.js [app-client] (ecmascript) <export default as geoIdentity>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$mercator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__geoMercator$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/projection/mercator.js [app-client] (ecmascript) <export default as geoMercator>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$equalEarth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__geoEqualEarth$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/projection/equalEarth.js [app-client] (ecmascript) <export default as geoEqualEarth>");
// src/components/Chart/utils.js
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$format$2f$src$2f$locale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__formatLocale$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-format/src/locale.js [app-client] (ecmascript) <export default as formatLocale>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$format$2f$src$2f$formatSpecifier$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__formatSpecifier$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-format/src/formatSpecifier.js [app-client] (ecmascript) <export default as formatSpecifier>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$format$2f$src$2f$precisionFixed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__precisionFixed$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-format/src/precisionFixed.js [app-client] (ecmascript) <export default as precisionFixed>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$ascending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ascending$3e$__ = __turbopack_context__.i("[project]/packages/styleguide/node_modules/d3-array/src/ascending.js [app-client] (ecmascript) <export default as ascending>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$descending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__descending$3e$__ = __turbopack_context__.i("[project]/packages/styleguide/node_modules/d3-array/src/descending.js [app-client] (ecmascript) <export default as descending>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$range$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__range$3e$__ = __turbopack_context__.i("[project]/packages/styleguide/node_modules/d3-array/src/range.js [app-client] (ecmascript) <export default as range>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$color$2f$src$2f$color$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-color/src/color.js [app-client] (ecmascript)");
// src/components/Chart/TimeBars.context.js
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-client] (ecmascript) <export default as scaleBand>");
// src/components/Chart/TimeBars.utils.js
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$time$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/d3-time/src/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleTime$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/time.js [app-client] (ecmascript) <export default as scaleTime>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__point__as__scalePoint$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/band.js [app-client] (ecmascript) <export point as scalePoint>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$time$2f$src$2f$year$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__timeYear$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-time/src/year.js [app-client] (ecmascript) <export default as timeYear>");
// src/components/Chart/Lines.utils.js
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$log$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLog$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/log.js [app-client] (ecmascript) <export default as scaleLog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/line.js [app-client] (ecmascript) <export default as line>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$area$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__area$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/area.js [app-client] (ecmascript) <export default as area>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$pow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__sqrt__as__scaleSqrt$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/pow.js [app-client] (ecmascript) <export sqrt as scaleSqrt>");
// src/components/Chart/ScatterPlots.utils.js
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$extent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__extent$3e$__ = __turbopack_context__.i("[project]/packages/styleguide/node_modules/d3-array/src/extent.js [app-client] (ecmascript) <export default as extent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$symbol$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__symbol$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/symbol.js [app-client] (ecmascript) <export default as symbol>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$symbol$2f$square$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__symbolSquare$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/symbol/square.js [app-client] (ecmascript) <export default as symbolSquare>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$symbol$2f$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__symbolCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/symbol/circle.js [app-client] (ecmascript) <export default as symbolCircle>");
// src/components/Chart/Maps.layout.js
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$threshold$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleThreshold$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/threshold.js [app-client] (ecmascript) <export default as scaleThreshold>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$quantize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleQuantize$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-scale/src/quantize.js [app-client] (ecmascript) <export default as scaleQuantize>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__geoPath$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-geo/src/path/index.js [app-client] (ecmascript) <export default as geoPath>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$topojson$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/topojson/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$topojson$2d$client$2f$src$2f$feature$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__feature$3e$__ = __turbopack_context__.i("[project]/node_modules/topojson-client/src/feature.js [app-client] (ecmascript) <export default as feature>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$topojson$2d$client$2f$src$2f$mesh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__mesh$3e$__ = __turbopack_context__.i("[project]/node_modules/topojson-client/src/mesh.js [app-client] (ecmascript) <export default as mesh>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$partition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lodash/partition.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$sum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__sum$3e$__ = __turbopack_context__.i("[project]/packages/styleguide/node_modules/d3-array/src/sum.js [app-client] (ecmascript) <export default as sum>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$arc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__arc$3e$__ = __turbopack_context__.i("[project]/node_modules/d3-shape/src/arc.js [app-client] (ecmascript) <export default as arc>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$scroll$2d$into$2d$view$2f$scrollIntoView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/scroll-into-view/scrollIntoView.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$debounce$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lodash/debounce.js [app-client] (ecmascript)");
// src/components/Chart/Table.js
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/icons/dist/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature(), _s9 = __turbopack_context__.k.signature(), _s10 = __turbopack_context__.k.signature(), _s11 = __turbopack_context__.k.signature(), _s12 = __turbopack_context__.k.signature(), _s13 = __turbopack_context__.k.signature(), _s14 = __turbopack_context__.k.signature(), _s15 = __turbopack_context__.k.signature(), _s16 = __turbopack_context__.k.signature(), _s17 = __turbopack_context__.k.signature(), _s18 = __turbopack_context__.k.signature(), _s19 = __turbopack_context__.k.signature(), _s20 = __turbopack_context__.k.signature(), _s21 = __turbopack_context__.k.signature(), _s22 = __turbopack_context__.k.signature(), _s23 = __turbopack_context__.k.signature(), _s24 = __turbopack_context__.k.signature(), _s25 = __turbopack_context__.k.signature(), _s26 = __turbopack_context__.k.signature(), _s27 = __turbopack_context__.k.signature(), _s28 = __turbopack_context__.k.signature(), _s29 = __turbopack_context__.k.signature(), _s30 = __turbopack_context__.k.signature(), _s31 = __turbopack_context__.k.signature(), _s32 = __turbopack_context__.k.signature(), _s33 = __turbopack_context__.k.signature(), _s34 = __turbopack_context__.k.signature(), _s35 = __turbopack_context__.k.signature(), _s36 = __turbopack_context__.k.signature(), _s37 = __turbopack_context__.k.signature(), _s38 = __turbopack_context__.k.signature(), _s39 = __turbopack_context__.k.signature(), _s40 = __turbopack_context__.k.signature(), _s41 = __turbopack_context__.k.signature(), _s42 = __turbopack_context__.k.signature(), _s43 = __turbopack_context__.k.signature(), _s44 = __turbopack_context__.k.signature(), _s45 = __turbopack_context__.k.signature(), _s46 = __turbopack_context__.k.signature(), _s47 = __turbopack_context__.k.signature(), _s48 = __turbopack_context__.k.signature(), _s49 = __turbopack_context__.k.signature(), _s50 = __turbopack_context__.k.signature(), _s51 = __turbopack_context__.k.signature(), _s52 = __turbopack_context__.k.signature(), _s53 = __turbopack_context__.k.signature();
var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value)=>key in obj ? __defProp(obj, key, {
        enumerable: true,
        configurable: true,
        writable: true,
        value
    }) : obj[key] = value;
var __spreadValues = (a, b)=>{
    for(var prop in b || (b = {}))if (__hasOwnProp.call(b, prop)) __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols) for (var prop of __getOwnPropSymbols(b)){
        if (__propIsEnum.call(b, prop)) __defNormalProp(a, prop, b[prop]);
    }
    return a;
};
var __spreadProps = (a, b)=>__defProps(a, __getOwnPropDescs(b));
var __objRest = (source, exclude)=>{
    var target = {};
    for(var prop in source)if (__hasOwnProp.call(source, prop) && exclude.indexOf(prop) < 0) target[prop] = source[prop];
    if (source != null && __getOwnPropSymbols) for (var prop of __getOwnPropSymbols(source)){
        if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop)) target[prop] = source[prop];
    }
    return target;
};
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __publicField = (obj, key, value)=>__defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __async = (__this, __arguments, generator)=>{
    return new Promise((resolve, reject)=>{
        var fulfilled = (value)=>{
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        };
        var rejected = (value)=>{
            try {
                step(generator.throw(value));
            } catch (e) {
                reject(e);
            }
        };
        var step = (x)=>x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
        step((generator = generator.apply(__this, __arguments)).next());
    });
};
;
;
;
;
;
;
;
;
// src/components/Typography/styles.ts
var styles_exports = {};
__export(styles_exports, {
    cursiveTitle20: ()=>cursiveTitle20,
    cursiveTitle22: ()=>cursiveTitle22,
    cursiveTitle26: ()=>cursiveTitle26,
    cursiveTitle30: ()=>cursiveTitle30,
    cursiveTitle32: ()=>cursiveTitle32,
    cursiveTitle58: ()=>cursiveTitle58,
    sansSerifMedium12: ()=>sansSerifMedium12,
    sansSerifMedium14: ()=>sansSerifMedium14,
    sansSerifMedium15: ()=>sansSerifMedium15,
    sansSerifMedium16: ()=>sansSerifMedium16,
    sansSerifMedium18: ()=>sansSerifMedium18,
    sansSerifMedium19: ()=>sansSerifMedium19,
    sansSerifMedium20: ()=>sansSerifMedium20,
    sansSerifMedium22: ()=>sansSerifMedium22,
    sansSerifMedium24: ()=>sansSerifMedium24,
    sansSerifMedium26: ()=>sansSerifMedium26,
    sansSerifMedium30: ()=>sansSerifMedium30,
    sansSerifMedium32: ()=>sansSerifMedium32,
    sansSerifMedium40: ()=>sansSerifMedium40,
    sansSerifMedium58: ()=>sansSerifMedium58,
    sansSerifRegular10: ()=>sansSerifRegular10,
    sansSerifRegular11: ()=>sansSerifRegular11,
    sansSerifRegular12: ()=>sansSerifRegular12,
    sansSerifRegular13: ()=>sansSerifRegular13,
    sansSerifRegular14: ()=>sansSerifRegular14,
    sansSerifRegular15: ()=>sansSerifRegular15,
    sansSerifRegular16: ()=>sansSerifRegular16,
    sansSerifRegular17: ()=>sansSerifRegular17,
    sansSerifRegular18: ()=>sansSerifRegular18,
    sansSerifRegular19: ()=>sansSerifRegular19,
    sansSerifRegular21: ()=>sansSerifRegular21,
    sansSerifRegular22: ()=>sansSerifRegular22,
    sansSerifRegular23: ()=>sansSerifRegular23,
    sansSerifRegular30: ()=>sansSerifRegular30,
    serifBold16: ()=>serifBold16,
    serifBold17: ()=>serifBold17,
    serifBold19: ()=>serifBold19,
    serifBold24: ()=>serifBold24,
    serifBold28: ()=>serifBold28,
    serifBold32: ()=>serifBold32,
    serifBold36: ()=>serifBold36,
    serifBold42: ()=>serifBold42,
    serifBold52: ()=>serifBold52,
    serifRegular14: ()=>serifRegular14,
    serifRegular15: ()=>serifRegular15,
    serifRegular16: ()=>serifRegular16,
    serifRegular17: ()=>serifRegular17,
    serifRegular18: ()=>serifRegular18,
    serifRegular19: ()=>serifRegular19,
    serifRegular21: ()=>serifRegular21,
    serifRegular23: ()=>serifRegular23,
    serifRegular25: ()=>serifRegular25,
    serifTitle16: ()=>serifTitle16,
    serifTitle20: ()=>serifTitle20,
    serifTitle22: ()=>serifTitle22,
    serifTitle26: ()=>serifTitle26,
    serifTitle28: ()=>serifTitle28,
    serifTitle30: ()=>serifTitle30,
    serifTitle32: ()=>serifTitle32,
    serifTitle38: ()=>serifTitle38,
    serifTitle58: ()=>serifTitle58
});
// src/theme/fonts.js
var fontStyles = {
    serifTitle: {
        fontFamily: "RepublikSerif, Rubis, Georgia, serif",
        fontWeight: 900,
        fontStyle: "normal"
    },
    serifRegular: {
        fontFamily: "Rubis, Georgia, serif",
        fontWeight: 400,
        fontStyle: "normal"
    },
    serifItalic: {
        fontFamily: "Rubis, Georgia, serif",
        fontWeight: 400,
        fontStyle: "italic"
    },
    serifBold: {
        fontFamily: "Rubis, Georgia, serif",
        fontWeight: 700,
        fontStyle: "normal"
    },
    serifBoldItalic: {
        fontFamily: "Rubis, Georgia, serif",
        fontWeight: 700,
        fontStyle: "italic"
    },
    serifMedium: {
        fontFamily: "Rubis, Georgia, serif",
        fontWeight: 500,
        fontStyle: "normal"
    },
    serifMediumItalic: {
        fontFamily: "Rubis, Georgia, serif",
        fontWeight: 500,
        fontStyle: "italic"
    },
    sansSerifRegular: {
        fontFamily: "GT-America-Standard, Helvetica Neue, Helvetica, sans-serif",
        fontWeight: 400,
        fontStyle: "normal"
    },
    sansSerifItalic: {
        fontFamily: "GT-America-Standard, Helvetica Neue, Helvetica, sans-serif",
        fontWeight: 400,
        fontStyle: "italic"
    },
    sansSerifMedium: {
        fontFamily: "GT-America-Standard, Helvetica Neue, Helvetica, sans-serif",
        fontWeight: 500,
        fontStyle: "normal"
    },
    sansSerifBold: {
        fontFamily: "GT-America-Standard, Helvetica Neue, Helvetica, sans-serif",
        fontWeight: 700,
        fontStyle: "normal"
    },
    monospaceRegular: {
        fontFamily: "Menlo, Courier, monospace",
        fontWeight: 400,
        fontStyle: "normal"
    },
    cursiveTitle: {
        fontFamily: "Inicia, Roboto, sans-serif",
        fontWeight: 500,
        fontStyle: "italic"
    }
};
var fontFamilies = {
    serifTitle: fontStyles.serifTitle.fontFamily,
    serifRegular: fontStyles.serifRegular.fontFamily,
    serifItalic: fontStyles.serifItalic.fontFamily,
    serifBold: fontStyles.serifBold.fontFamily,
    serifBoldItalic: fontStyles.serifBoldItalic.fontFamily,
    serifMedium: fontStyles.serifMedium.fontFamily,
    serifMediumItalic: fontStyles.serifMediumItalic.fontFamily,
    sansSerifRegular: fontStyles.sansSerifRegular.fontFamily,
    sansSerifItalic: fontStyles.sansSerifItalic.fontFamily,
    sansSerifMedium: fontStyles.sansSerifMedium.fontFamily,
    sansSerifBold: fontStyles.sansSerifBold.fontFamily,
    monospaceRegular: fontStyles.monospaceRegular.fontFamily,
    cursiveTitle: fontStyles.cursiveTitle.fontFamily
};
// src/components/Typography/styles.ts
var serifTitle58 = __spreadProps(__spreadValues({}, fontStyles.serifTitle), {
    fontSize: 58,
    lineHeight: "60px"
});
var serifTitle38 = __spreadProps(__spreadValues({}, fontStyles.serifTitle), {
    fontSize: 38,
    lineHeight: "43px"
});
var serifTitle32 = __spreadProps(__spreadValues({}, fontStyles.serifTitle), {
    fontSize: 32,
    lineHeight: "34px"
});
var serifTitle30 = __spreadProps(__spreadValues({}, fontStyles.serifTitle), {
    fontSize: 30,
    lineHeight: "34px"
});
var serifTitle28 = __spreadProps(__spreadValues({}, fontStyles.serifTitle), {
    fontSize: 28,
    lineHeight: "30px"
});
var serifTitle26 = __spreadProps(__spreadValues({}, fontStyles.serifTitle), {
    fontSize: 26,
    lineHeight: "28px"
});
var serifTitle22 = __spreadProps(__spreadValues({}, fontStyles.serifTitle), {
    fontSize: 22,
    lineHeight: "24px"
});
var serifTitle20 = __spreadProps(__spreadValues({}, fontStyles.serifTitle), {
    fontSize: 20,
    lineHeight: "22px"
});
var serifTitle16 = __spreadProps(__spreadValues({}, fontStyles.serifTitle), {
    fontSize: 16,
    lineHeight: "18px"
});
var serifRegular25 = __spreadProps(__spreadValues({}, fontStyles.serifRegular), {
    fontSize: 25,
    lineHeight: "33px"
});
var serifRegular23 = __spreadProps(__spreadValues({}, fontStyles.serifRegular), {
    fontSize: 23,
    lineHeight: "30px"
});
var serifRegular21 = __spreadProps(__spreadValues({}, fontStyles.serifRegular), {
    fontSize: 21,
    lineHeight: "32px"
});
var serifRegular19 = __spreadProps(__spreadValues({}, fontStyles.serifRegular), {
    fontSize: 19,
    lineHeight: "30px"
});
var serifRegular18 = __spreadProps(__spreadValues({}, fontStyles.serifRegular), {
    fontSize: 18,
    lineHeight: "24px"
});
var serifRegular17 = __spreadProps(__spreadValues({}, fontStyles.serifRegular), {
    fontSize: 17,
    lineHeight: "26px"
});
var serifRegular16 = __spreadProps(__spreadValues({}, fontStyles.serifRegular), {
    fontSize: 16,
    lineHeight: "24px"
});
var serifRegular15 = __spreadProps(__spreadValues({}, fontStyles.serifRegular), {
    fontSize: 15,
    lineHeight: "24px"
});
var serifRegular14 = __spreadProps(__spreadValues({}, fontStyles.serifRegular), {
    fontSize: 14,
    lineHeight: "19px"
});
var serifBold52 = __spreadProps(__spreadValues({}, fontStyles.serifBold), {
    fontSize: 52,
    lineHeight: "56px",
    letterSpacing: -0.45
});
var serifBold42 = __spreadProps(__spreadValues({}, fontStyles.serifBold), {
    fontSize: 42,
    lineHeight: "48px",
    letterSpacing: -0.3
});
var serifBold32 = __spreadProps(__spreadValues({}, fontStyles.serifBold), {
    fontSize: 32,
    lineHeight: 1.2
});
var serifBold36 = __spreadProps(__spreadValues({}, fontStyles.serifBold), {
    fontSize: 36,
    lineHeight: "38px",
    letterSpacing: -0.3
});
var serifBold28 = __spreadProps(__spreadValues({}, fontStyles.serifBold), {
    fontSize: 28,
    lineHeight: "33px"
});
var serifBold24 = __spreadProps(__spreadValues({}, fontStyles.serifBold), {
    fontSize: 24,
    lineHeight: "30px",
    letterSpacing: -0.21
});
var serifBold19 = __spreadProps(__spreadValues({}, fontStyles.serifBold), {
    fontSize: 19,
    lineHeight: "24px"
});
var serifBold17 = __spreadProps(__spreadValues({}, fontStyles.serifBold), {
    fontSize: 17,
    lineHeight: "26px"
});
var serifBold16 = __spreadProps(__spreadValues({}, fontStyles.serifBold), {
    fontSize: 16,
    lineHeight: "24px"
});
var sansSerifRegular30 = __spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    fontSize: 30,
    lineHeight: "35px"
});
var sansSerifRegular23 = __spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    fontSize: 23,
    lineHeight: "30px"
});
var sansSerifRegular22 = __spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    fontSize: 22,
    lineHeight: "26px"
});
var sansSerifRegular21 = __spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    fontSize: 21,
    lineHeight: "32px"
});
var sansSerifRegular19 = __spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    fontSize: 19,
    lineHeight: "30px"
});
var sansSerifRegular18 = __spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    fontSize: 18,
    lineHeight: "30px"
});
var sansSerifRegular17 = __spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    fontSize: 17,
    lineHeight: "26px"
});
var sansSerifRegular16 = __spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    fontSize: 16,
    lineHeight: "25px"
});
var sansSerifRegular15 = __spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    fontSize: 15,
    lineHeight: "21px"
});
var sansSerifRegular14 = __spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    fontSize: 14,
    lineHeight: "17px"
});
var sansSerifRegular13 = __spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    fontSize: 13,
    lineHeight: "16px"
});
var sansSerifRegular12 = __spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    fontSize: 12,
    lineHeight: "15px"
});
var sansSerifRegular11 = __spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    fontSize: 11,
    lineHeight: "12px"
});
var sansSerifRegular10 = __spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    fontSize: 10,
    lineHeight: "12px"
});
var sansSerifMedium58 = __spreadProps(__spreadValues({}, fontStyles.sansSerifMedium), {
    fontSize: 58,
    lineHeight: "60px"
});
var sansSerifMedium40 = __spreadProps(__spreadValues({}, fontStyles.sansSerifMedium), {
    fontSize: 40,
    lineHeight: "46px",
    letterSpacing: -0.35
});
var sansSerifMedium32 = __spreadProps(__spreadValues({}, fontStyles.sansSerifMedium), {
    fontSize: 32,
    lineHeight: "34px"
});
var sansSerifMedium30 = __spreadProps(__spreadValues({}, fontStyles.sansSerifMedium), {
    fontSize: 30,
    lineHeight: "34px"
});
var sansSerifMedium26 = __spreadProps(__spreadValues({}, fontStyles.sansSerifMedium), {
    fontSize: 26,
    lineHeight: "28px"
});
var sansSerifMedium24 = __spreadProps(__spreadValues({}, fontStyles.sansSerifMedium), {
    fontSize: 24,
    lineHeight: "30px"
});
var sansSerifMedium22 = __spreadProps(__spreadValues({}, fontStyles.sansSerifMedium), {
    fontSize: 22,
    lineHeight: "28px",
    letterSpacing: "normal"
});
var sansSerifMedium20 = __spreadProps(__spreadValues({}, fontStyles.sansSerifMedium), {
    fontSize: 20,
    lineHeight: "24px",
    letterSpacing: "normal"
});
var sansSerifMedium19 = __spreadProps(__spreadValues({}, fontStyles.sansSerifMedium), {
    fontSize: 19,
    lineHeight: "30px"
});
var sansSerifMedium18 = __spreadProps(__spreadValues({}, fontStyles.sansSerifMedium), {
    fontSize: 18,
    lineHeight: "24px"
});
var sansSerifMedium16 = __spreadProps(__spreadValues({}, fontStyles.sansSerifMedium), {
    fontSize: 16,
    lineHeight: "25px"
});
var sansSerifMedium15 = __spreadProps(__spreadValues({}, fontStyles.sansSerifMedium), {
    fontSize: 15,
    lineHeight: "24px"
});
var sansSerifMedium14 = __spreadProps(__spreadValues({}, fontStyles.sansSerifMedium), {
    fontSize: 14,
    lineHeight: "17px"
});
var sansSerifMedium12 = __spreadProps(__spreadValues({}, fontStyles.sansSerifMedium), {
    fontSize: 12,
    lineHeight: "15px"
});
var cursiveTitle58 = __spreadProps(__spreadValues({}, fontStyles.cursiveTitle), {
    fontSize: 58,
    lineHeight: "60px"
});
var cursiveTitle32 = __spreadProps(__spreadValues({}, fontStyles.cursiveTitle), {
    fontSize: 32,
    lineHeight: "34px"
});
var cursiveTitle30 = __spreadProps(__spreadValues({}, fontStyles.cursiveTitle), {
    fontSize: 30,
    lineHeight: "34px"
});
var cursiveTitle26 = __spreadProps(__spreadValues({}, fontStyles.cursiveTitle), {
    fontSize: 26,
    lineHeight: "28px"
});
var cursiveTitle22 = __spreadProps(__spreadValues({}, fontStyles.cursiveTitle), {
    fontSize: 22,
    lineHeight: "24px"
});
var cursiveTitle20 = __spreadProps(__spreadValues({}, fontStyles.cursiveTitle), {
    fontSize: 20,
    lineHeight: "22px"
});
// src/lib/styleMixins.ts
var ellipsize = {
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
};
var underline = {
    textDecoration: "underline"
};
;
;
;
// src/theme/colors.js
var colorsDeprecated = {
    primary: "#3CAD00",
    primaryBg: "#EBF6E5",
    secondary: "#4B6359",
    secondaryBg: "#F6F8F7",
    disabled: "#B7C1BD",
    text: "#282828",
    error: "#9F2500",
    divider: "#DADDDC",
    editorial: "#08809A",
    feuilleton: "#7C7C7C",
    scribble: "#D44338",
    meta: "#000000",
    containerBg: "#FFF",
    lightText: "#979797",
    fill: "#000",
    lightFill: "#E9E9E9",
    online: "#00DC00",
    social: "#E9A733",
    neutral: "#bbb",
    highlight: "#FFFFCC",
    sequential: [
        "rgb(8, 48, 107)",
        "rgb(8, 61, 126)",
        "rgb(10, 74, 144)",
        "rgb(15, 87, 159)",
        "rgb(24, 100, 170)",
        "rgb(34, 113, 180)",
        "rgb(47, 126, 188)",
        "rgb(60, 139, 195)",
        "rgb(75, 151, 201)",
        "rgb(91, 163, 207)",
        "rgb(109, 174, 213)"
    ],
    sequential3: [
        "rgb(8,48,107)",
        "rgb(24,100,170)",
        "rgb(75,151,201)"
    ],
    opposite3: [
        "rgb(103,0,13)",
        "rgb(187,21,26)",
        "rgb(239,69,51)"
    ],
    discrete: [
        "#1f77b4",
        "#ff7f0e",
        "#2ca02c",
        "#d62728",
        "#9467bd",
        "#8c564b",
        "#e377c2",
        "#7f7f7f",
        "#bcbd22",
        "#17becf"
    ],
    negative: {
        containerBg: "#111",
        primaryBg: "#191919",
        text: "#f0f0f0",
        lightText: "#828282",
        divider: "#5b5b5b",
        fill: "#FFF",
        lightFill: "#555",
        error: "rgb(239,69,51)",
        disabled: "#242424"
    }
};
var colors = __spreadProps(__spreadValues({}, colorsDeprecated), {
    light: {
        logo: "#000000",
        default: "#FFFFFF",
        overlay: "#FFFFFF",
        hover: "#F6F8F7",
        alert: "#E4F5E1",
        error: "#9F2500",
        defaultInverted: "#191919",
        overlayInverted: "#1F1F1F",
        divider: "#DADDDC",
        dividerInverted: "#4C4D4C",
        primary: "#00AA00",
        primaryHover: "#008800",
        primaryText: "#FFFFFF",
        text: "#282828",
        textInverted: "#F0F0F0",
        textSoft: "#757575",
        textSoftInverted: "#A9A9A9",
        disabled: "#949494",
        accentColorBriefing: "#0A99B8",
        accentColorInteraction: "#00AA00",
        accentColorOppinion: "#D0913C",
        accentColorFormats: "#d44438",
        accentColorMeta: "#000000",
        accentColorAudio: "#000000",
        overlayShadow: "0 0 15px rgba(0,0,0,0.1)",
        fadeOutGradientDefault: "linear-gradient(0deg, rgba(255,255,255,1) 0%, rgba(255,255,255,0) 100%)",
        fadeOutGradientDefault90: "linear-gradient(90deg, rgba(255,255,255,1) 0%, rgba(255,255,255,0) 100%)",
        fadeOutGradientOverlay: "linear-gradient(0deg, rgba(255,255,255,1) 0%, rgba(255,255,255,0) 100%)",
        displayLight: "block",
        displayDark: "none",
        sequential100: "rgb(8, 48, 107)",
        sequential95: "rgb(8, 61, 126)",
        sequential90: "rgb(10, 74, 144)",
        sequential85: "rgb(15, 87, 159)",
        sequential80: "rgb(24, 100, 170)",
        sequential75: "rgb(34, 113, 180)",
        sequential70: "rgb(47, 126, 188)",
        sequential65: "rgb(60, 139, 195)",
        sequential60: "rgb(75, 151, 201)",
        sequential55: "rgb(91, 163, 207)",
        sequential50: "rgb(109, 174, 213)",
        opposite100: "rgb(103,0,13)",
        opposite80: "rgb(187,21,26)",
        opposite60: "rgb(239,69,51)",
        neutral: "#bbb",
        discrete1: "#1f77b4",
        discrete2: "#ff7f0e",
        discrete3: "#2ca02c",
        discrete4: "#d62728",
        discrete5: "#9467bd",
        discrete6: "#8c564b",
        discrete7: "#e377c2",
        discrete8: "#7f7f7f",
        discrete9: "#bcbd22",
        discrete10: "#17becf",
        chartsInverted: "#000000",
        imageChoiceShadow: "0 1px 2px 0 rgba(0, 0, 0, 0.24), 0 0 2px 0 rgba(0, 0, 0, 0.12)",
        imageChoiceShadowHover: "0 4px 8px 0 rgba(0, 0, 0, 0.24), 0 0 8px 0 rgba(0, 0, 0, 0.12)",
        boxShadowBottomNavBar: "0 -5px 10px -3px rgba(0, 0, 0, 0.1)"
    },
    dark: {
        logo: "#FFFFFF",
        default: "#191919",
        overlay: "#1F1F1F",
        hover: "#292929",
        alert: "#144313",
        error: "#F0400A",
        defaultInverted: "#FFFFFF",
        overlayInverted: "#FFFFFF",
        divider: "#4C4D4C",
        dividerInverted: "#DADDDC",
        primary: "#00AA00",
        primaryHover: "#008800",
        primaryText: "#FFFFFF",
        text: "#F0F0F0",
        textInverted: "#282828",
        textSoft: "#A9A9A9",
        textSoftInverted: "#757575",
        disabled: "#6E6E6E",
        accentColorBriefing: "#0A99B8",
        accentColorInteraction: "#00AA00",
        accentColorOppinion: "#D0913C",
        accentColorFormats: "#d44438",
        accentColorMeta: "#FFFFFF",
        accentColorAudio: "#FFFFFF",
        overlayShadow: "0 0 15px rgba(0,0,0,0.3)",
        fadeOutGradientDefault: "linear-gradient(0deg, rgba(25,25,25,1) 0%, rgba(25,25,25,0) 100%)",
        fadeOutGradientDefault90: "linear-gradient(90deg, rgba(25,25,25,1) 0%, rgba(25,25,25,0) 100%)",
        fadeOutGradientOverlay: "linear-gradient(0deg, rgba(31,31,31,1) 0%, rgba(31,31,31,0) 100%)",
        displayLight: "none",
        displayDark: "block",
        sequential100: "rgb(24, 100, 170)",
        sequential95: "rgb(34, 113, 180)",
        sequential90: "rgb(47, 126, 188)",
        sequential85: "rgb(60, 139, 195)",
        sequential80: "rgb(75, 151, 201)",
        sequential75: "rgb(91, 163, 207)",
        sequential70: "rgb(109, 174, 213)",
        sequential65: "rgb(128, 185, 218)",
        sequential60: "rgb(147, 195, 223)",
        sequential55: "rgb(165, 204, 228)",
        sequential50: "rgb(181, 212, 233)",
        opposite100: "rgb(187,21,26)",
        opposite80: "rgb(239,69,51)",
        opposite60: "rgb(252, 138, 107)",
        neutral: "#bbb",
        discrete1: "#1f77b4",
        discrete2: "#ff7f0e",
        discrete3: "#2ca02c",
        discrete4: "#d62728",
        discrete5: "#9467bd",
        discrete6: "#8c564b",
        discrete7: "#e377c2",
        discrete8: "#7f7f7f",
        discrete9: "#bcbd22",
        discrete10: "#17becf",
        chartsInverted: "#FFFFFF",
        imageChoiceShadow: "0 1px 2px 0 rgba(255, 255, 255, 0.24), 0 0 2px 0 rgba(255, 255, 255, 0.12)",
        imageChoiceShadowHover: "0 4px 8px 0 rgba(255, 255, 255, 0.24), 0 0 8px 0 rgba(255, 255, 255, 0.12)",
        boxShadowBottomNavBar: "0 -5px 10px -3px rgba(0, 0, 0, 0.1)"
    },
    mappings: {
        format: {
            "#000": "accentColorMeta",
            "#000000": "accentColorMeta",
            "#282828": "accentColorMeta",
            "#07809A": "accentColorBriefing",
            "#07809a": "accentColorBriefing"
        },
        charts: {
            "#000": "chartsInverted",
            "#000000": "chartsInverted"
        }
    }
});
var colors_default = colors;
;
var getVariableColorKeys = (colors2)=>{
    return Array.from(/* @__PURE__ */ new Set([
        ...Object.keys(colors2.light),
        ...Object.keys(colors2.dark)
    ]));
};
var variableColorKeys = getVariableColorKeys(colors_default);
var createScheme = (specificColors)=>{
    const colorDefinitions = __spreadValues(__spreadValues({}, colors_default), specificColors);
    const { mappings = {} } = colorDefinitions;
    const getCSSColor = (color, mappingName = void 0)=>{
        const mapping = mappings[mappingName] || {};
        return color in mapping ? `var(--color-${mapping[color]})` : color in colorDefinitions ? `var(--color-${color})` : color;
    };
    const createColorRule = (attr, color, mappingName = void 0)=>{
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            [attr]: getCSSColor(color, mappingName)
        });
    };
    return {
        schemeKey: colorDefinitions.schemeKey,
        colorDefinitions,
        ranges: {
            neutral: [
                colorDefinitions.neutral
            ],
            sequential: [
                "sequential100",
                "sequential95",
                "sequential90",
                "sequential85",
                "sequential80",
                "sequential75",
                "sequential70",
                "sequential65",
                "sequential60",
                "sequential55",
                "sequential50"
            ].map((key)=>colorDefinitions[key]),
            sequential3: [
                "sequential100",
                "sequential80",
                "sequential60"
            ].map((key)=>colorDefinitions[key]),
            opposite3: [
                "opposite100",
                "opposite80",
                "opposite60"
            ].map((key)=>colorDefinitions[key]),
            discrete: [
                "discrete1",
                "discrete2",
                "discrete3",
                "discrete4",
                "discrete5",
                "discrete6",
                "discrete7",
                "discrete8",
                "discrete9",
                "discrete10"
            ].map((key)=>colorDefinitions[key])
        },
        set: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$memoize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(createColorRule, (...args)=>args.join(".")),
        getCSSColor
    };
};
var generateCSSColorDefinitions = (colors2)=>{
    return variableColorKeys.map((key)=>`--color-${key}: ${colors2[key]};`).join(" ");
};
var getObjectForKeys = (colorKeys, mapper = (key)=>key)=>colorKeys.reduce((c, key)=>{
        c[key] = mapper(key);
        return c;
    }, {});
var defaultColorContextValue = createScheme(__spreadValues({
    schemeKey: "auto"
}, getObjectForKeys(variableColorKeys, (key)=>`var(--color-${key})`)));
var ColorContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext(defaultColorContextValue);
var useColorContext = ()=>{
    _s();
    const colorContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ColorContext);
    return [
        colorContext
    ];
};
_s(useColorContext, "T+exPwMnRI4twGLliQUnoPh70sg=");
var ColorContextLocalExtension = ({ children, localColors = colors_default, localMappings = {} })=>{
    _s1();
    const [{ schemeKey, colorDefinitions }] = useColorContext();
    const [colorValue, cssVarRule] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ColorContextLocalExtension.useMemo": ()=>{
            const { mappings = {} } = colorDefinitions;
            const variableLocalColorKeys = getVariableColorKeys(localColors);
            const extendedColorDefinitions = __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, colorDefinitions), localColors[schemeKey === "auto" ? "light" : schemeKey]), getObjectForKeys(variableLocalColorKeys, {
                "ColorContextLocalExtension.useMemo.extendedColorDefinitions": (key)=>`var(--color-${key})`
            }["ColorContextLocalExtension.useMemo.extendedColorDefinitions"])), {
                mappings: __spreadValues(__spreadValues({}, mappings), getObjectForKeys(Object.keys(localMappings), {
                    "ColorContextLocalExtension.useMemo.extendedColorDefinitions": (key)=>{
                        return __spreadValues(__spreadValues({}, mappings[key]), localMappings[key]);
                    }
                }["ColorContextLocalExtension.useMemo.extendedColorDefinitions"]))
            });
            const lightColorCSSDefs = variableLocalColorKeys.reduce({
                "ColorContextLocalExtension.useMemo.lightColorCSSDefs": (defs, key)=>{
                    defs[`--color-${key}`] = localColors.light[key];
                    return defs;
                }
            }["ColorContextLocalExtension.useMemo.lightColorCSSDefs"], {});
            const darkColorCSSDefs = variableLocalColorKeys.reduce({
                "ColorContextLocalExtension.useMemo.darkColorCSSDefs": (defs, key)=>{
                    defs[`--color-${key}`] = localColors.dark[key];
                    return defs;
                }
            }["ColorContextLocalExtension.useMemo.darkColorCSSDefs"], {});
            return [
                createScheme(extendedColorDefinitions),
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                    ':root &, [data-theme="light"] &': __spreadValues({}, lightColorCSSDefs),
                    ':root[data-theme="dark"] &, [data-theme="dark"] &': __spreadValues({}, darkColorCSSDefs)
                })
            ];
        }
    }["ColorContextLocalExtension.useMemo"], [
        colorDefinitions,
        localColors,
        localMappings,
        schemeKey
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ColorContext.Provider, {
        value: colorValue,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", __spreadProps(__spreadValues({}, cssVarRule), {
            children
        }))
    });
};
_s1(ColorContextLocalExtension, "uZ/gaOXSS/8pJQUE/TPvZs5aMgg=", false, function() {
    return [
        useColorContext
    ];
});
_c = ColorContextLocalExtension;
var RootColorVariables = ()=>{
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("style", {
        "data-testid": "theme-variables",
        dangerouslySetInnerHTML: {
            __html: [
                // default light
                `:root, [data-theme="light"], [data-theme="dark"] [data-theme-inverted] { ${generateCSSColorDefinitions(colors_default.light)} }`,
                // dark class applied to html element via next-themes OR manually applied on an element
                `[data-theme="dark"], [data-theme="light"] [data-theme-inverted] { ${generateCSSColorDefinitions(colors_default.dark)} }`,
                `@media print {
            [data-theme="dark"], [data-theme="light"] [data-theme-inverted] { ${generateCSSColorDefinitions(colors_default.light)} }
          }`
            ].join("\n")
        }
    });
};
_c1 = RootColorVariables;
var colorSchemeKeyToDataTheme = (colorSchemeKey)=>{
    return colorSchemeKey === "light" || colorSchemeKey === "dark" ? colorSchemeKey : void 0;
};
var ColorContextProvider = ({ colorSchemeKey = "auto", root = false, children })=>{
    if (root) {
        throw Error(`root prop not supported anymore on ColorContextProvider`);
    }
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ColorContext.Provider, {
        value: defaultColorContextValue,
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
            "data-theme": colorSchemeKeyToDataTheme(colorSchemeKey),
            children
        })
    });
};
_c2 = ColorContextProvider;
var InvertedColorScheme = ({ children })=>{
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        "data-theme-inverted": true,
        children
    });
};
_c3 = InvertedColorScheme;
var ColorContext_default = ColorContext;
;
;
;
;
var locale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$time$2d$format$2f$src$2f$locale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__timeFormatLocale$3e$__["timeFormatLocale"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$time$2d$format$2f$locale$2f$de$2d$CH$2e$json$2e5b$json$5d2e$cjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
var timeFormat = locale.format;
var timeParse = locale.parse;
;
var swissPartyColors = {
    EAG: "#AD4F89",
    PDA: "#BF3939",
    AL: "#A83232",
    SOL: "#A83232",
    DA: "#A83232",
    SE: "#A83232",
    KP: "#8C2736",
    JA: "#8C2736",
    JSVR: "#F0554D",
    SP: "#F0554D",
    JUSO: "#F0554D",
    GPS: "#84B547",
    GRÜNE: "#84B547",
    JG: "#84B547",
    GLP: "#C4C43D",
    JGLP: "#C4C43D",
    BDP: "#E6C820",
    JBDP: "#E6C820",
    EVP: "#DEAA28",
    JEVP: "#DEAA28",
    MITTE: "#D6862B",
    CVP: "#D6862B",
    JCVP: "#D6862B",
    CSPO: "#E3BA24",
    JCSPO: "#E3BA24",
    PPS: "#E7B661",
    LDU: "#1BAA6E",
    CSP: "#35AEB2",
    JCSP: "#35AEB2",
    PCSI: "#35AEB2",
    LPS: "#618DEA",
    LDP: "#618DEA",
    JLDP: "#618DEA",
    FDP: "#3872B5",
    JFS: "#3872B5",
    UP: "#3872B5",
    SVP: "#4B8A3E",
    JSVP: "#4B8A3E",
    MCR: "#49A5E7",
    MCRJ: "#49A5E7",
    LEGA: "#9070D4",
    PNOS: "#B07F3E",
    EDU: "#A65E42",
    JEDU: "#A65E42",
    SD: "#9D9D9D",
    AUTO: "#9D9D9D",
    FPS: "#9D9D9D",
    NONE: "#B8B8B8",
    OTHER: "#B8B8B8"
};
var colorMaps = {
    swissPartyColors
};
var CHART_DEFAULT_FILL = "#E0E0E0";
var getColorMapper = (props, colorValues = [])=>{
    const colorMapProp = props.colorMap;
    if (colorMapProp) {
        const colorMap = colorMaps[colorMapProp] || Object.keys(colorMapProp).reduce((map, key)=>{
            map[key.toUpperCase()] = colorMapProp[key];
            return map;
        }, {});
        return (value = "")=>colorMap[value.toUpperCase()] || CHART_DEFAULT_FILL;
    }
    let colorRange = props.colorRanges[props.colorRange] || props.colorRange;
    if (!colorRange) {
        colorRange = colorValues.length > 3 ? props.colorRanges.discrete : props.colorRanges.sequential3;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$ordinal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleOrdinal$3e$__["scaleOrdinal"])(colorRange).domain(colorValues);
};
;
;
;
;
;
;
;
;
var groupBy = (array, key)=>{
    const keys = [];
    const object = array.reduce((o, item, index)=>{
        const k = key(item, index) || "";
        if (!o[k]) {
            o[k] = [];
            keys.push(k);
        }
        o[k].push(item);
        return o;
    }, {});
    return keys.map((k)=>({
            key: k,
            values: object[k]
        }));
};
var sortPropType = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
    "none",
    "ascending",
    "descending"
]);
var runSort = (cmd, array, accessor = (d)=>d)=>{
    if (cmd !== "none") {
        const compare = cmd === "descending" ? __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$descending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__descending$3e$__["descending"] : __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$ascending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ascending$3e$__["ascending"];
        const original = [].concat(array);
        array.sort((a, b)=>compare(accessor(a), accessor(b)) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$ascending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ascending$3e$__["ascending"])(original.indexOf(a), original.indexOf(b)));
    }
};
var sortBy = (array, accessor)=>[].concat(array).sort((a, b)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$ascending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ascending$3e$__["ascending"])(accessor(a), accessor(b)) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$ascending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ascending$3e$__["ascending"])(array.indexOf(a), array.indexOf(b)));
var thousandSeparator = "\u2019";
var swissNumbers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$format$2f$src$2f$locale$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__formatLocale$3e$__["formatLocale"])({
    decimal: ",",
    thousands: thousandSeparator,
    grouping: [
        3
    ],
    currency: [
        "CHF\xA0",
        ""
    ],
    minus: "\u2212",
    percent: "\u2009%"
});
var formatPow = (tLabel, baseValue)=>{
    const decimalFormat = swissNumbers.format(".0f");
    let [n] = decimalFormat(baseValue).split(".");
    let scale = (value)=>value;
    let suffix = "";
    if (n.length > 9) {
        scale = (value)=>value / Math.pow(10, 9);
        suffix = tLabel(" Mrd.");
    } else if (n.length > 6) {
        scale = (value)=>value / Math.pow(10, 6);
        suffix = tLabel(" Mio.");
    }
    return {
        scale,
        suffix
    };
};
var sFormat = (tLabel, precision = 4, pow, type = "r")=>{
    const numberFormat4 = swissNumbers.format("d");
    const numberFormat5 = swissNumbers.format(",d");
    const numberFormat = (value)=>{
        if (String(Math.abs(Math.round(value))).length > 4) {
            return numberFormat5(value);
        }
        return numberFormat4(value);
    };
    const numberFormatWithSuffix4 = swissNumbers.format(`.${precision}${type}`);
    const numberFormatWithSuffix5 = swissNumbers.format(`,.${precision}${type}`);
    const numberFormatWithSuffix = (value)=>{
        if (String(Math.abs(Math.round(value))).length > 4) {
            return numberFormatWithSuffix5(value);
        }
        return numberFormatWithSuffix4(value);
    };
    return (value)=>{
        let fPow = pow || formatPow(tLabel, value);
        if (fPow.suffix) {
            return numberFormatWithSuffix(fPow.scale(value)) + fPow.suffix;
        }
        return numberFormat(fPow.scale(value));
    };
};
var getFormat = (numberFormat, tLabel)=>{
    const specifier = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$format$2f$src$2f$formatSpecifier$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__formatSpecifier$3e$__["formatSpecifier"])(numberFormat);
    if (specifier.type === "s") {
        return sFormat(tLabel, specifier.precision);
    }
    if (specifier.comma) {
        const numberFormat5 = swissNumbers.format(specifier.toString());
        specifier.comma = false;
        const numberFormat4 = swissNumbers.format(specifier);
        return (value)=>{
            if (String(Math.abs(Math.round(value))).length > 4) {
                return numberFormat5(value);
            }
            return numberFormat4(value);
        };
    }
    return swissNumbers.format(specifier);
};
var last = (array, index)=>array.length - 1 === index;
var calculateAxis = (numberFormat, tLabel, domain, unit = "", { ticks: predefinedTicks } = {})=>{
    const [min5, max6] = domain;
    const step = (max6 - min5) / 2;
    const ticks = predefinedTicks || [
        min5,
        min5 < 0 && max6 > 0 ? 0 : min5 + step,
        max6
    ];
    const format2 = swissNumbers.format;
    const specifier = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$format$2f$src$2f$formatSpecifier$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__formatSpecifier$3e$__["formatSpecifier"])(numberFormat);
    let formatter = getFormat(numberFormat, tLabel);
    let regularFormat;
    let lastFormat;
    if (specifier.type === "%") {
        let fullStep = +(ticks[1] * 100).toFixed(specifier.precision);
        let fullMax = +(max6 * 100).toFixed(specifier.precision);
        specifier.precision = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$format$2f$src$2f$precisionFixed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__precisionFixed$3e$__["precisionFixed"])(fullStep - Math.floor(fullStep) || fullMax - Math.floor(fullMax));
        lastFormat = format2(specifier.toString());
        specifier.type = "f";
        const regularFormatInner = format2(specifier.toString());
        regularFormat = (value)=>regularFormatInner(value * 100);
    } else if (specifier.type === "s") {
        const magnitude = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])([
            max6 - (min5 > 0 ? min5 : 0),
            min5
        ].map(Math.abs));
        let pow = formatPow(tLabel, Math.max(0, min5) + magnitude / 2);
        specifier.precision = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$format$2f$src$2f$precisionFixed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__precisionFixed$3e$__["precisionFixed"])(ticks.reduce((precision, value)=>precision || pow.scale(value) - Math.floor(pow.scale(value)), 0));
        lastFormat = sFormat(tLabel, specifier.precision, pow, "f");
        regularFormat = sFormat(tLabel, specifier.precision, {
            scale: pow.scale,
            suffix: ""
        }, "f");
    } else {
        specifier.precision = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(ticks.map((tick, i)=>Math.max(i && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$format$2f$src$2f$precisionFixed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__precisionFixed$3e$__["precisionFixed"])(tick - ticks[i - 1]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$format$2f$src$2f$precisionFixed$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__precisionFixed$3e$__["precisionFixed"])(tick - Math.floor(tick)))));
        lastFormat = regularFormat = getFormat(specifier.toString());
    }
    const axisFormat = (value, isLast)=>isLast ? `${lastFormat(value)} ${unit}` : regularFormat(value);
    return {
        ticks,
        format: formatter,
        axisFormat,
        domain
    };
};
var get3EqualDistTicks = (scale)=>{
    const range3 = scale.range();
    return [
        scale.invert(range3[0]),
        scale.invert(range3[0] + (range3[1] - range3[0]) / 2),
        scale.invert(range3[1])
    ];
};
var subSupSplitter = (createTag)=>{
    return (input)=>{
        if (!input) {
            return input;
        }
        return String(input).split(/(<sub>|<sup>)([^<]+)<\/su[bp]>/g).reduce((elements, text, i)=>{
            if (text === "<sub>" || text === "<sup>") {
                elements.nextElement = text.replace("<", "").replace(">", "");
            } else {
                if (elements.nextElement) {
                    elements.push(createTag(elements.nextElement, elements.nextElement + i, text));
                    elements.nextElement = null;
                } else {
                    elements.push(text);
                }
            }
            return elements;
        }, []);
    };
};
var subsup = subSupSplitter((tag, key, text)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(tag, {
        key
    }, text));
subsup.svg = subSupSplitter((tag, key, text)=>{
    const dy = tag === "sub" ? "0.25em" : "-0.5em";
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("tspan", {
                dy,
                fontSize: "75%",
                children: text
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("tspan", {
                dy: tag === "sub" ? `-${dy}` : dy.slice(1),
                fontSize: "75%",
                children: "\u200B"
            })
        ]
    }, key);
});
var deduplicate = (d, i, all)=>all.indexOf(d) === i;
var unsafeDatumFn = (code)=>new Function("datum", `return ${code}`);
var getTextColor = (bgColor)=>{
    const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$color$2f$src$2f$color$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgb"])(bgColor);
    const yiq = (color.r * 299 + color.g * 587 + color.b * 114) / 1e3;
    return yiq >= 128 ? "black" : "white";
};
var xAccessor = (d)=>d.x;
var yAccessor = (d)=>d.y;
var isValuePresent = (value)=>{
    var _a;
    return ((_a = value == null ? void 0 : value.toString()) == null ? void 0 : _a.length) > 0;
};
var identityFn = (x)=>x;
var getDataFilter = (userFilter)=>userFilter ? unsafeDatumFn(userFilter) : identityFn;
var groupInColumns = (data, column, columnFilter)=>columnFilter ? columnFilter.map(({ test, title })=>{
        const filter = unsafeDatumFn(test);
        return {
            key: title,
            values: data.filter((d)=>filter(d.datum))
        };
    }).reduce((all, group)=>all.concat(group.values), []) : groupBy(data, (d)=>d.datum[column]);
var getColumnCount = (itemCount, userColumns, width, minWidth, paddingLeft, paddingRight, skipRowPadding)=>{
    const possibleColumns = Math.floor((width + (skipRowPadding ? paddingLeft + paddingRight : 0)) / (minWidth + paddingLeft + paddingRight));
    let columns = userColumns;
    if (possibleColumns < userColumns) {
        columns = Math.max(possibleColumns, 1);
        if (Math.ceil(itemCount / columns) === Math.ceil(itemCount / (columns - 1))) {
            columns -= 1;
        }
    }
    return columns;
};
var xTranslateFn = (groups, columns, innerWidth, paddingLeft, paddingRight)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$ordinal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleOrdinal$3e$__["scaleOrdinal"])().domain(groups).range((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$range$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__range$3e$__["range"])(columns).map((d)=>{
        return d * (innerWidth + paddingRight + paddingLeft);
    }));
var yTranslateFn = (groups, columns, columnHeight, columnMargin)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$ordinal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleOrdinal$3e$__["scaleOrdinal"])().domain(groups).range((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$range$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__range$3e$__["range"])(groups.length).map((d)=>{
        const row = Math.floor(d / columns);
        return row * columnHeight + row * columnMargin;
    }));
var getColumnLayout = (userColumns, groupedData, width, minWidth, getHeight, columnSort, paddingTop, paddingRight, paddingBottom, paddingLeft, columnMargin, skipRowPadding)=>{
    const itemCount = groupedData.length;
    const columns = getColumnCount(itemCount, userColumns, width, minWidth, paddingLeft, paddingRight, skipRowPadding);
    const rows = Math.ceil(itemCount / columns);
    const innerWidth = Math.floor((width - (paddingLeft + paddingRight) * (skipRowPadding ? columns - 1 : columns)) / columns) - 1;
    const innerHeight = getHeight(innerWidth);
    const columnHeight = innerHeight + paddingBottom + paddingTop;
    const height = rows * columnHeight + (rows - 1) * columnMargin;
    let groups = groupedData.map((g)=>g.key);
    runSort(columnSort, groups);
    const gx = xTranslateFn(groups, columns, innerWidth, paddingLeft, paddingRight);
    const gy = yTranslateFn(groups, columns, columnHeight, columnMargin);
    return {
        height,
        innerWidth,
        innerHeight,
        gx,
        gy
    };
};
var isLastItem = (array, index)=>array.length - 1 === index;
var textAlignmentDict = {
    left: "start",
    center: "middle",
    right: "end"
};
;
;
;
var intervals = Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$time$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__).filter((key)=>key.match(/^time/) && key !== "timeInterval").reduce((all, key)=>{
    all[key.replace(/^time/, "").toLowerCase()] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$time$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__[key];
    return all;
}, {});
var getXTicks = (userTicks, xValues, xNormalizer, x)=>{
    if (userTicks) {
        return userTicks.map(xNormalizer);
    }
    return x.step() >= xValues[0].length * 12 ? xValues : [
        xValues[0],
        xValues[xValues.length - 1]
    ].filter(deduplicate);
};
var getBaselines = (xDomain, x, width)=>{
    const xDomainLast = xDomain[xDomain.length - 1];
    const barWidth = x.bandwidth();
    const barStep = x.step();
    const barPadding = barStep - barWidth;
    return xDomain.reduce((lines, xValue)=>{
        let previousLine = lines[lines.length - 1];
        let x1 = previousLine ? previousLine.x2 : 0;
        let x2 = xValue === xDomainLast ? width : x(xValue) + barStep;
        const gap = xValue.split("|")[0] === "GAP";
        if (gap) {
            x2 -= barPadding;
        }
        if (previousLine && previousLine.gap === gap) {
            previousLine.x2 = x2;
        } else {
            lines.push({
                x1,
                x2,
                gap
            });
        }
        return lines;
    }, []);
};
var getIntervals = (xInterval, xProp, timeParse2)=>intervals[xInterval] || xProp === "year" && timeParse2 === "%Y" && intervals.year;
var insertXGaps = (xValues, intervals2, xIntervalStep, xParser, xParserFormat, x)=>{
    const gapsNeeded = Math.max(Math.ceil(// at least 26 px
    26 / Math.max(x.bandwidth(), 1)), 2);
    return xValues.reduce((values, value, index, all)=>{
        values.push(value);
        const next = intervals2.offset(xParser(value), xIntervalStep);
        if (all.indexOf(xParserFormat(next)) === -1 && index !== all.length - 1) {
            for(let i = 0; i < gapsNeeded; i++){
                values.push(`GAP|${value}|${i}`);
            }
        }
        return values;
    }, []);
};
var insertXDomainGaps = (xValues, xInterval, xProp, timeParse2, xIntervalStep, xParser, xParserFormat, x)=>{
    const intervals2 = getIntervals(xInterval, xProp, timeParse2);
    return intervals2 ? insertXGaps(xValues, intervals2, xIntervalStep, xParser, xParserFormat, x) : xValues;
};
var sumSegments = (sum2, segment)=>sum2 + segment.value;
var mergeSegments = ({ values: segments, key: x })=>({
        segments,
        up: segments.filter((segment)=>segment.value > 0).reduce(sumSegments, 0),
        down: segments.filter((segment)=>segment.value < 0).reduce(sumSegments, 0),
        x
    });
var processSegments = (data)=>({
        bars: groupBy(data.values, xAccessor).map(mergeSegments),
        key: data.key
    });
var getGroupMin = (group)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__["min"])(group.bars, (d)=>d.down);
var getGroupMax = (group)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(group.bars, (d)=>d.up);
var getMin = (groupedData)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__["min"])([
        0
    ].concat(groupedData.map(getGroupMin)));
};
var getMax = (groupedData)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(groupedData.map(getGroupMax));
// src/components/Chart/Layout.constants.js
var COLUMN_TITLE_HEIGHT = 24;
var COLUMN_PADDING = 20;
var AXIS_TOP_HEIGHT = 24;
var AXIS_BOTTOM_HEIGHT = 24;
var X_UNIT_PADDING = 30;
var AXIS_BOTTOM_CUTOFF_HEIGHT = 40;
var AXIS_BOTTOM_XUNIT_HEIGHT = 12;
var PADDING_TOP = 24;
var PADDING_SIDES = 20;
var Y_CONNECTOR = 7;
var Y_CONNECTOR_PADDING = 4;
var Y_LABEL_HEIGHT = 14;
var Y_END_LABEL_SPACE = 3;
var X_TICK_HEIGHT = 4;
var Y_GROUP_MARGIN = 20;
// src/components/Chart/TimeBars.context.js
var timeBarsProcesser = ({ props, data, colorValues, xValuesUnformatted, xFormat, xParser, xParserFormat, xNormalizer })=>{
    const groupedData = groupInColumns(data, props.column, props.columnFilter).map(processSegments);
    const paddingTop = props.yScaleInvert || props.xUnit ? PADDING_TOP + PADDING_TOP / 2 : PADDING_TOP;
    const columnTitleHeight = props.column ? COLUMN_TITLE_HEIGHT : 0;
    const columnHeight = props.height + columnTitleHeight + (props.mini ? 0 : paddingTop + AXIS_BOTTOM_HEIGHT);
    const barRange = props.yScaleInvert ? [
        paddingTop + columnTitleHeight,
        columnHeight - AXIS_BOTTOM_HEIGHT
    ] : [
        columnHeight - paddingTop,
        AXIS_BOTTOM_HEIGHT + columnTitleHeight
    ];
    const { height, innerWidth, gx, gy } = getColumnLayout(props.columns, groupedData, props.width, props.minInnerWidth, ()=>columnHeight, props.columnSort, 0, PADDING_SIDES, 0, PADDING_SIDES, COLUMN_PADDING, true);
    let y = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain(props.domain ? props.domain : [
        getMin(groupedData),
        getMax(groupedData)
    ]).range(barRange);
    if (!props.domain) {
        y.nice(3);
    }
    const x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleBand$3e$__["scaleBand"])().domain(xValuesUnformatted).range([
        props.padding,
        innerWidth - props.padding
    ]).padding(props.xBandPadding).round(true);
    const xDomain = insertXDomainGaps(xValuesUnformatted, props.xInterval, props.x, props.timeParse, props.xIntervalStep, xParser, xParserFormat, x);
    x.domain(xDomain).round(true);
    const xTicks = getXTicks(props.xTicks, xValuesUnformatted, xNormalizer, x);
    const yAxis = calculateAxis(props.numberFormat, props.tLabel, y.domain(), props.unit, {
        ticks: props.yTicks
    });
    return {
        groupedData,
        height,
        innerWidth,
        paddingRight: 0,
        paddingLeft: 0,
        groupPosition: {
            y: gy,
            x: gx,
            titleHeight: columnTitleHeight
        },
        xAxis: {
            scale: x,
            domain: xDomain,
            ticks: xTicks,
            format: xFormat,
            axisFormat: (x2)=>xFormat(xParser(x2))
        },
        yAxis: __spreadProps(__spreadValues({}, yAxis), {
            scale: y
        }),
        colorValuesForLegend: colorValues
    };
};
;
;
;
;
;
var measurementDiv = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$memoize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>{
    const div = document.createElement("div");
    div.className = "DOMMEASUREMENTOUTLET";
    div.style.position = "fixed";
    div.style.top = "-100%";
    div.style.visibility = "hidden";
    div.style.pointerEvents = "none";
    document.body.appendChild(div);
    return div;
}, ()=>"");
var createTextGauger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$memoize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(({ fontFamily, fontSize, lineHeight }, { dimension, html })=>{
    if (typeof document === "undefined") {
        return (text)=>{
            return fontSize * 0.6 * String(text).length;
        };
    }
    const element = document.createElement("span");
    element.style.fontFamily = fontFamily;
    element.style.fontSize = `${fontSize}px`;
    element.style.lineHeight = lineHeight;
    measurementDiv().appendChild(element);
    if (html) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$memoize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((text)=>{
            element.innerHTML = text;
            return element.getBoundingClientRect()[dimension];
        });
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$memoize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((text)=>{
        element.textContent = text;
        return element.getBoundingClientRect()[dimension];
    });
}, ({ fontFamily, fontSize, lineHeight }, { dimension, html })=>[
        fontFamily,
        fontSize,
        lineHeight,
        dimension,
        html
    ].join());
// src/components/Chart/Lines.utils.js
var yScales = {
    linear: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"],
    log: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$log$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLog$3e$__["scaleLog"]
};
var Y_LABEL_HEIGHT2 = 14;
var groupBy2 = (array, key)=>{
    const keys = [];
    const object = array.reduce((o, item, index)=>{
        const k = key(item, index) || "";
        if (!o[k]) {
            o[k] = [];
            keys.push(k);
        }
        o[k].push(item);
        return o;
    }, {});
    return keys.map((k)=>({
            key: k,
            values: object[k]
        }));
};
var groupLines = (color, category)=>category ? (d)=>d.category : (d)=>d.datum[color];
var groupByLines = (color, category)=>({ values, key })=>({
            key,
            values: groupBy2(values, groupLines(color, category))
        });
var getMiddleOfRange = (field, d)=>{
    const lower = +d.datum[`${field}_lower`];
    const upper = +d.datum[`${field}_upper`];
    return lower + (upper - lower) / 2;
};
var addLabels = (color, colorAccessor, labelFilter, yFormat, y, props)=>({ values: line })=>{
        const start = line[0];
        const end = line[line.length - 1];
        const label = labelFilter(start.datum);
        const isHighlight = props.highlight ? unsafeDatumFn(props.highlight) : ()=>false;
        const hasStroke = props.stroke ? unsafeDatumFn(props.stroke) : ()=>false;
        const hasStartValue = isValuePresent(start.value);
        const hasEndValue = isValuePresent(end.value);
        const endLabel = label && props.endLabel && colorAccessor(end);
        return {
            line,
            start,
            end,
            highlighted: isHighlight(start.datum),
            stroked: hasStroke(start.datum),
            lineColor: color(colorAccessor(start)),
            startValue: label && props.startValue && hasStartValue && yFormat(start.value),
            endValue: label && props.endValue && hasEndValue && yFormat(end.value),
            endLabel,
            startY: hasStartValue ? y(start.value) : void 0,
            endY: hasEndValue ? y(end.value) : props.area && end.datum[`${props.area}_lower`] ? y(getMiddleOfRange(props.area, end)) : void 0
        };
    };
var calculateAndMoveLabelY = (linesWithLayout, property)=>{
    let labelsMoved = 0;
    let lastY = -Infinity;
    sortBy(linesWithLayout.filter((line)=>line[`${property}Value`] || line[`${property}Label`]), (line)=>line[`${property}Y`]).forEach((line)=>{
        let labelY = line[`${property}Y`];
        let nextY = lastY + Y_LABEL_HEIGHT2;
        if (nextY > labelY) {
            labelY = nextY;
            labelsMoved += 1;
        }
        line[`${property}LabelY`] = lastY = labelY;
    });
    return labelsMoved;
};
var valueAccessor = (d)=>d.value;
var appendAnnotations = (values, annotations)=>annotations ? values.concat(annotations.map(valueAccessor)) : values;
var valueGauger = createTextGauger(sansSerifMedium12, {
    dimension: "width",
    html: true
});
var labelGauger = createTextGauger(sansSerifRegular12, {
    dimension: "width",
    html: true
});
// src/components/Chart/Lines.context.js
var linesProcesser = ({ props, data, colorAccessor, color, colorValues, xValuesUnformatted, xFormat, xParser })=>{
    let groupedData = groupInColumns(data, props.column, props.columnFilter);
    const logScale = props.yScale === "log";
    const forceZero = !logScale && props.zero;
    let yCut;
    if (!forceZero) {
        yCut = "Achse gek\xFCrzt";
    }
    if (logScale) {
        yCut = "Logarithmische Skala";
    }
    const yCutHeight = props.mini ? 25 : AXIS_BOTTOM_CUTOFF_HEIGHT;
    const paddingTop = AXIS_TOP_HEIGHT + (props.column ? COLUMN_TITLE_HEIGHT : 0) + (props.paddingTop || 0);
    const paddingBottom = AXIS_BOTTOM_HEIGHT + (yCut ? yCutHeight : 0) + (props.xUnit ? AXIS_BOTTOM_XUNIT_HEIGHT : 0);
    const innerHeight = props.mini ? props.height - paddingTop - paddingBottom : props.height;
    const columnHeight = innerHeight + paddingTop + paddingBottom;
    let yValues = data.map(valueAccessor);
    yValues = appendAnnotations(yValues, props.yAnnotations);
    yValues = appendAnnotations(yValues, props.xAnnotations);
    if (props.band) {
        const dataWithBand = data.filter((d)=>d.datum[`${props.band}_lower`]);
        yValues = yValues.concat(dataWithBand.map((d)=>+d.datum[`${props.band}_lower`])).concat(dataWithBand.map((d)=>+d.datum[`${props.band}_upper`]));
    }
    if (props.area) {
        const dataWithArea = data.filter((d)=>d.datum[`${props.area}_lower`]);
        yValues = yValues.concat(dataWithArea.map((d)=>+d.datum[`${props.area}_lower`])).concat(dataWithArea.map((d)=>+d.datum[`${props.area}_upper`]));
    }
    const yTicks = props.yLines ? props.yLines.map((d)=>d.tick) : props.yTicks;
    if (yTicks) {
        yValues = yValues.concat(yTicks);
    }
    const minValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__["min"])(yValues);
    const y = yScales[props.yScale]().domain([
        forceZero ? Math.min(0, minValue) : minValue,
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(yValues)
    ]).range([
        innerHeight + paddingTop,
        paddingTop
    ]);
    if (props.yNice) {
        y.nice(props.yNice);
    }
    runSort(props.colorSort, colorValues);
    const yAxis = calculateAxis(props.numberFormat, props.tLabel, y.domain(), props.unit, {
        ticks: yTicks
    });
    const { format: yFormat } = yAxis;
    const startValue = !props.mini && props.startValue;
    const endLabel = !props.mini && props.endLabel && colorValues.length > 0;
    let startValueSizes = [];
    let endValueSizes = [];
    let endLabelSizes = [];
    let yNeedsConnectors = false;
    const labelFilter = props.labelFilter ? unsafeDatumFn(props.labelFilter) : ()=>true;
    groupedData = groupedData.map(groupByLines(props.color, props.category)).map(({ values: lines, key })=>{
        const linesWithLabels = lines.map(addLabels(color, colorAccessor, labelFilter, yFormat, y, props));
        let labelsMoved = 0;
        labelsMoved += calculateAndMoveLabelY(linesWithLabels, "start");
        labelsMoved += calculateAndMoveLabelY(linesWithLabels, "end");
        yNeedsConnectors = yNeedsConnectors || labelsMoved >= 1 && linesWithLabels.length > 2;
        if (startValue) {
            startValueSizes = startValueSizes.concat(linesWithLabels.map((line)=>line.startValue ? valueGauger(line.startValue) : 0));
        }
        if (!props.mini) {
            endValueSizes = endValueSizes.concat(linesWithLabels.map((line)=>line.endValue ? valueGauger(line.endValue) : 0));
            if (endLabel) {
                endLabelSizes = endLabelSizes.concat(linesWithLabels.map((line)=>line.endLabel ? labelGauger(line.endLabel) + Y_END_LABEL_SPACE : 0));
            }
        }
        return {
            key,
            values: linesWithLabels
        };
    });
    let colorLegend = !endLabel || props.colorLegend === true;
    const yConnectorSize = yNeedsConnectors ? Y_CONNECTOR + Y_CONNECTOR_PADDING * 2 : Y_CONNECTOR_PADDING * 2;
    const whiteSpacePadding = groupedData.length > 1 && props.columns > 1 ? 15 : 0;
    let paddingLeft = 0;
    let paddingRight = 0;
    if (!props.mini) {
        const startValueSize = startValue ? Math.ceil((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(startValueSizes) + yConnectorSize) : 0;
        const endValueSize = Math.ceil((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(endValueSizes) + yConnectorSize);
        if (startValue) {
            paddingLeft = paddingRight = Math.max(startValueSize, endValueSize) + whiteSpacePadding;
        } else {
            paddingRight = endValueSize + whiteSpacePadding;
        }
        if (endLabel) {
            const endLabelWidth = props.endLabelWidth !== void 0 ? props.endLabelWidth : endValueSize + Math.ceil((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(endLabelSizes));
            if (startValueSize + endLabelWidth > props.width - props.minInnerWidth) {
                colorLegend = true;
                groupedData.forEach(({ values: lines })=>{
                    lines.forEach((line)=>{
                        line.endLabel = false;
                    });
                });
            } else {
                if (startValue) {
                    paddingLeft = startValueSize + whiteSpacePadding;
                }
                paddingRight = endLabelWidth + whiteSpacePadding;
            }
        }
        if (props.paddingRight !== void 0) {
            paddingRight = props.paddingRight + whiteSpacePadding;
        }
        if (props.paddingLeft !== void 0) {
            paddingLeft = props.paddingLeft + whiteSpacePadding;
        }
    }
    const colorValuesForLegend = colorLegend ? data.filter((d)=>labelFilter(d.datum)).map(colorAccessor).filter(deduplicate).filter(Boolean) : [];
    runSort(props.colorSort, colorValuesForLegend);
    const { height, innerWidth, gx, gy } = getColumnLayout(props.columns, groupedData, props.width, props.minInnerWidth, ()=>columnHeight, props.columnSort, 0, paddingRight, 0, paddingLeft, Y_GROUP_MARGIN);
    let x;
    let xTicks = props.xTicks && props.xTicks.map(xParser);
    let xDomain;
    if (props.xScale === "time") {
        const xTimes = xValuesUnformatted.map((d)=>d.getTime());
        const domainTime = [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__["min"])(xTimes),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(xTimes)
        ];
        const domain = domainTime.map((d)=>new Date(d));
        x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$time$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleTime$3e$__["scaleTime"])().domain(domain);
        xDomain = domain;
        if (!props.xTicks) {
            let yearInteval = Math.round(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$time$2f$src$2f$year$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__timeYear$3e$__["timeYear"].count(domain[0], domain[1]) / 3);
            let time1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$time$2f$src$2f$year$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__timeYear$3e$__["timeYear"].offset(domain[0], yearInteval).getTime();
            let time2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$time$2f$src$2f$year$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__timeYear$3e$__["timeYear"].offset(domain[1], -yearInteval).getTime();
            xTicks = [
                domainTime[0],
                sortBy(xTimes, (d)=>Math.abs(d - time1))[0],
                sortBy(xTimes, (d)=>Math.abs(d - time2))[0],
                domainTime[1]
            ].filter(deduplicate).map((d)=>new Date(d));
        }
    } else if (props.xScale === "linear") {
        const domain = [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__["min"])(xValuesUnformatted),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(xValuesUnformatted)
        ];
        x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain(domain);
        xTicks = xTicks || domain;
        xDomain = domain;
    } else {
        const domain = xValuesUnformatted.filter(deduplicate);
        xDomain = domain;
        x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$band$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__point__as__scalePoint$3e$__["scalePoint"])().domain(domain);
        if (!xTicks && domain.length > 5) {
            let maxIndex = domain.length - 1;
            xTicks = [
                domain[0],
                domain[Math.round(maxIndex * 0.33)],
                domain[Math.round(maxIndex * 0.66)],
                domain[maxIndex]
            ].filter(deduplicate);
        } else if (!xTicks) {
            xTicks = domain;
        }
    }
    if (props.mini) {
        xTicks = [
            xTicks[0],
            xTicks[xTicks.length - 1]
        ];
    }
    x.range([
        0,
        innerWidth
    ]);
    const translatedYAnnotations = (props.yAnnotations || []).map((d)=>__spreadProps(__spreadValues({
            formattedValue: yFormat(d.value)
        }, d), {
            x: d.x ? xParser(d.x) : void 0
        }));
    const translatedXAnnotations = (props.xAnnotations || []).map((d)=>{
        const longestLabel = d.label && d.label.split("\n").reduce((a, b)=>a.length > b.length ? a : b);
        return __spreadProps(__spreadValues({
            formattedValue: yFormat(d.value)
        }, d), {
            x: d.x ? xParser(d.x) : void 0,
            x1: d.x1 ? xParser(d.x1) : void 0,
            x2: d.x2 ? xParser(d.x2) : void 0,
            labelSize: d.label ? labelGauger(longestLabel) : 0
        });
    });
    return {
        groupedData,
        height,
        innerWidth,
        groupPosition: {
            y: gy,
            x: gx
        },
        yAxis: __spreadProps(__spreadValues({}, yAxis), {
            scale: y
        }),
        xAxis: {
            scale: x,
            domain: xDomain,
            ticks: xTicks,
            format: xFormat,
            axisFormat: xFormat
        },
        yLayout: {
            yCut,
            yCutHeight,
            yNeedsConnectors,
            yConnectorSize
        },
        paddingLeft,
        paddingRight,
        columnHeight,
        yAnnotations: translatedYAnnotations,
        xAnnotations: translatedXAnnotations,
        colorValuesForLegend
    };
};
// src/components/Chart/ChartContext.utils.js
var normalizeData = (x, xNormalizer)=>(d)=>({
            datum: d,
            x: xNormalizer(d[x]),
            value: isValuePresent(d.value) ? +d.value : void 0
        });
var getAnnotationsXValues = (annotations, xNormalizer)=>annotations ? annotations.reduce((years, annotation)=>years.concat(annotation.x, annotation.x1, annotation.x2), []).filter(Boolean).map(xNormalizer) : [];
var categorizeData = (category)=>(d)=>{
        if (category) {
            const categorize = unsafeDatumFn(category);
            return __spreadProps(__spreadValues({}, d), {
                category: categorize(d.datum)
            });
        }
        return d;
    };
;
var dataProcesser = {
    TimeBar: timeBarsProcesser,
    Line: linesProcesser,
    Slope: linesProcesser
};
var chartsToUseContext = [
    "TimeBar",
    "Line",
    "Slope"
];
var ChartContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])();
var ChartContextProvider = (plainProps)=>{
    var _a;
    if (chartsToUseContext.indexOf(plainProps.type) === -1) {
        return plainProps.children;
    }
    const props = __spreadValues(__spreadValues({}, defaultProps[plainProps.type]), plainProps);
    const { type, values, xAnnotations, xScale } = props;
    let xParser = identityFn;
    let xParserFormat = identityFn;
    let xFormat = identityFn;
    if (xScale === "time") {
        xParser = timeParse(props.timeParse);
        xParserFormat = timeFormat(props.timeParse);
        xFormat = timeFormat(props.timeFormat || props.timeParse);
    } else if (xScale === "linear") {
        xParser = (x)=>+x;
        xFormat = (x)=>`${x}`;
        xParserFormat = (x)=>x.toString();
        if (type === "Line") {
            xFormat = getFormat(props.xNumberFormat || props.numberFormat, props.tLabel);
        }
    }
    let xNormalizer = xParser;
    let xCompareAccessor = identityFn;
    if (type === "TimeBar") {
        xNormalizer = (d)=>xParserFormat(xParser(d)).toString();
        xCompareAccessor = xParser;
    }
    const data = values.filter(getDataFilter(props.filter)).filter(props.area ? (d)=>isValuePresent(d.value) || isValuePresent(d[`${props.area}_lower`]) : (d)=>isValuePresent(d.value)).map(normalizeData(props.x, xNormalizer, props.area)).map(categorizeData(props.category));
    const shouldXSort = props.xSort || xScale === "time" || xScale === "linear";
    if (shouldXSort) {
        runSort(props.xSort, data, (d)=>xCompareAccessor(xAccessor(d)));
    }
    const colorAccessor = props.color ? (d)=>d.datum[props.color] : (d)=>d.category;
    const colorValues = [].concat(data.map(colorAccessor)).concat(props.colorLegendValues).filter(Boolean).filter(deduplicate);
    const color = getColorMapper(props, colorValues);
    const xValuesUnformatted = data.map(xAccessor).concat(props.xLines || props.xTicks ? (((_a = props.xLines) == null ? void 0 : _a.map((d)=>d.tick)) || props.xTicks).map(xNormalizer) : []).concat(getAnnotationsXValues(xAnnotations, xNormalizer)).filter(deduplicate);
    if (shouldXSort) {
        runSort(props.xSort, xValuesUnformatted, xCompareAccessor);
    }
    const processedData = dataProcesser[type]({
        props,
        data,
        colorAccessor,
        color,
        colorValues,
        xValuesUnformatted,
        xFormat,
        xParser,
        xParserFormat,
        xNormalizer
    });
    const colorLegendValues = props.colorLegend !== false ? (props.colorLegendValues || processedData.colorValuesForLegend).map((colorValue)=>({
            color: color(colorValue),
            label: subsup(colorValue)
        })) : [];
    const chartContextObject = __spreadProps(__spreadValues({}, processedData), {
        colorAccessor,
        color,
        colorLegendValues,
        xNormalizer
    });
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ChartContext.Provider, {
        value: chartContextObject,
        children: props.children
    });
};
_c4 = ChartContextProvider;
var defaultPropsBar = {
    columns: 1,
    minInnerWidth: 140,
    barStyle: "small",
    numberFormat: "s",
    sort: "ascending"
};
var defaultPropsMap = {
    numberFormat: "s",
    columns: 1,
    unit: "",
    heightRatio: 1,
    colorLegend: true,
    colorLegendSize: 0.16,
    colorLegendMinWidth: 80,
    colorLegendPosition: "right",
    points: false,
    pointAttributes: [],
    choropleth: false,
    missingDataColor: "divider",
    ignoreMissingFeature: false,
    feature: "feature",
    shape: "circle",
    sizeRangeMax: 10,
    getProjection: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$equalEarth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__geoEqualEarth$3e$__["geoEqualEarth"])().rotate([
            -10,
            0
        ]),
    opacity: 0.6,
    highlightedColor: "#c40046"
};
var defaultProps = {
    TimeBar: {
        x: "year",
        xScale: "time",
        xBandPadding: 0.25,
        timeParse: "%Y",
        timeFormat: "%Y",
        numberFormat: "s",
        height: 240,
        padding: 50,
        unit: "",
        xUnit: "",
        colorLegend: true,
        xIntervalStep: 1,
        yAnnotations: [],
        xAnnotations: [],
        columns: 1,
        minInnerWidth: 240
    },
    Line: {
        x: "year",
        xScale: "time",
        yScale: "linear",
        timeParse: "%Y",
        timeFormat: "%Y",
        numberFormat: ".0%",
        zero: true,
        unit: "",
        startValue: false,
        endValue: true,
        endLabel: true,
        endDy: "0.3em",
        minInnerWidth: 110,
        columns: 1,
        height: 240,
        yNice: 3,
        strokeWidth: 3,
        strokeWidthHighlighted: 6
    },
    Slope: {
        x: "year",
        xScale: "ordinal",
        yScale: "linear",
        timeParse: "%Y",
        timeFormat: "%Y",
        numberFormat: ".0%",
        zero: true,
        unit: "",
        startValue: true,
        endValue: true,
        endLabel: false,
        endDy: "0.3em",
        minInnerWidth: 90,
        columns: 2,
        height: 240,
        yNice: 3
    },
    Bar: defaultPropsBar,
    Lollipop: __spreadProps(__spreadValues({}, defaultPropsBar), {
        barStyle: "lollipop"
    }),
    ScatterPlot: {
        x: "value",
        y: "value",
        xScale: "linear",
        xShowValue: true,
        yScale: "linear",
        yShowValue: true,
        opacity: 1,
        numberFormat: "s",
        colorLegend: true,
        paddingTop: 15,
        paddingRight: 1,
        paddingBottom: 50,
        paddingLeft: 30,
        sizeRangeMax: 4,
        label: "label",
        heightRatio: 1,
        sizeShowValue: false,
        columns: 1,
        minInnerWidth: 240,
        annotations: []
    },
    GenericMap: defaultPropsMap,
    ProjectedMap: __spreadProps(__spreadValues({}, defaultPropsMap), {
        getProjection: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$identity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__geoIdentity$3e$__["geoIdentity"])()
    }),
    SwissMap: __spreadProps(__spreadValues({}, defaultPropsMap), {
        getProjection: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$projection$2f$mercator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__geoMercator$3e$__["geoMercator"])().rotate([
                -7.439583333333333,
                -46.95240555555556
            ]),
        heightRatio: 0.63
    }),
    Hemicycle: {
        color: "label",
        group: "year",
        inlineLabelThreshold: 10,
        padding: 0,
        colorMap: "swissPartyColors"
    },
    Table: {
        numberFormat: "s",
        sortable: true,
        tableColumns: []
    }
};
var axisPropType = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
    scale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    domain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
    ticks: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
    format: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    axisFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired
});
var propTypes = {
    groupedData: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
    groupPosition: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        y: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
        x: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
        titleHeight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
    }).isRequired,
    height: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    innerWidth: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    paddingLeft: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    paddingRight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    xAxis: axisPropType.isRequired,
    yAxis: axisPropType.isRequired,
    color: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    colorAccessor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    // only used by timebar
    colorLegendValues: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        color: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node.isRequired
    })).isRequired,
    xNormalizer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    // only used by timebar
    // line only
    columnHeight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    strokeWidth: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    strokeWidthHighlighted: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    yLayout: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        yCut: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        yCutHeight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        yNeedsConnectors: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
        yConnectorSize: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
    }),
    yAnnotations: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array,
    xAnnotations: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array
};
ChartContext.Provider.propTypes = {
    value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape(propTypes).isRequired
};
;
;
;
;
var styles = {
    container: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        marginBottom: 10
    }),
    inlineContainer: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        lineHeight: "12px"
    }),
    title: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifMedium12)),
    label: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, sansSerifRegular12), {
        fontFeatureSettings: '"tnum" 1, "kern" 1'
    })),
    labelWithColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        paddingLeft: 12,
        position: "relative"
    }),
    inlineLabel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        display: "inline-block",
        marginRight: 12
    }),
    color: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        position: "absolute",
        left: 0,
        top: 5,
        width: 8,
        height: 8
    }),
    circle: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        borderRadius: "50%"
    })
};
var ColorLegend = ({ title, shape, values, maxWidth, inline })=>{
    _s2();
    const [colorScheme] = useColorContext();
    if (!(values == null ? void 0 : values.length) && !title) {
        return null;
    }
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", __spreadProps(__spreadValues({}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["merge"])(styles.container, inline && styles.inlineContainer)), {
        style: {
            maxWidth
        },
        children: [
            !!title && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", __spreadProps(__spreadValues(__spreadValues({}, styles.title), colorScheme.set("color", "text")), {
                children: title
            })),
            values.map((value, i)=>{
                let text = value.label;
                return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", __spreadProps(__spreadValues(__spreadValues({}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["merge"])(styles.label, inline && styles.inlineLabel, !!value.color && styles.labelWithColor)), colorScheme.set("color", "text")), {
                    children: [
                        !!value.color && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", __spreadValues(__spreadValues({}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["merge"])(styles.color, styles[shape === "square" ? "square" : "circle"])), colorScheme.set("backgroundColor", value.color, "charts"))),
                        text,
                        " "
                    ]
                }), i);
            })
        ]
    }));
};
_s2(ColorLegend, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c5 = ColorLegend;
ColorLegend.propTypes = {
    title: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node
    ]),
    shape: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        "square",
        "circle",
        "marker"
    ]),
    values: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        color: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node
        ]).isRequired
    })),
    maxWidth: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    inline: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
};
var ColorLegend_default = ColorLegend;
;
var COLUMN_PADDING2 = 20;
var COLUMN_TITLE_HEIGHT2 = 30;
var BAR_LABEL_HEIGHT = 15;
var AXIS_HEIGHT = 20;
var LOLLIPOP_PADDING = 7;
var BAR_STYLES = {
    lollipop: {
        highlighted: {
            marginTop: 4,
            height: 6,
            stroke: 4,
            popHeight: 14,
            marginBottom: 16
        },
        normal: {
            marginTop: 4,
            height: 3,
            stroke: 3,
            popHeight: 13,
            marginBottom: 9
        }
    },
    small: {
        highlighted: {
            marginTop: 0,
            height: 24,
            marginBottom: 16
        },
        normal: {
            marginTop: 0,
            height: 16,
            marginBottom: 9
        }
    },
    large: {
        highlighted: {
            marginTop: 0,
            height: 40,
            marginBottom: 40
        },
        normal: {
            marginTop: 0,
            height: 24,
            marginBottom: 16
        }
    },
    inline: {
        withSecondary: {
            marginTop: 0,
            height: 50,
            marginBottom: 9,
            fontSize: 16,
            secondaryFontSize: 12,
            inlineTop: 6
        },
        normal: {
            marginTop: 0,
            height: 20,
            marginBottom: 9,
            fontSize: 12,
            inlineTop: 2
        }
    }
};
var styles2 = {
    groupTitle: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifMedium14)),
    barLabel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifRegular12)),
    barLabelLink: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, underline)),
    inlineLabel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        fontFamily: fontFamilies.sansSerifRegular,
        fontWeight: "normal"
    }),
    axisLabel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifRegular12)),
    axisXLine: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        strokeWidth: "1px",
        shapeRendering: "crispEdges"
    }),
    bandLegend: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        whiteSpace: "nowrap"
    }),
    bandBar: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        display: "inline-block",
        width: 24,
        height: 8,
        borderRadius: "4px"
    })
};
var labelGauger2 = createTextGauger(sansSerifRegular12, {
    dimension: "width",
    html: true
});
var BarChart = (_props)=>{
    _s3();
    const props = __spreadValues(__spreadValues({}, defaultProps.Bar), _props);
    const { values, width, mini, tLabel, description, band, bandLegend, showBarValues, inlineValue, inlineValueUnit, inlineLabel, inlineSecondaryLabel, inlineLabelPosition, link: link2, unit } = props;
    const [colorScheme] = useColorContext();
    const possibleColumns = Math.floor(width / (props.minInnerWidth + COLUMN_PADDING2));
    const columns = possibleColumns >= props.columns ? props.columns : Math.max(possibleColumns, 1);
    const columnWidth = Math.floor((width - COLUMN_PADDING2 * (columns - 1)) / columns) - 1;
    let data = values;
    if (props.filter) {
        const filter = unsafeDatumFn(props.filter);
        data = data.filter(filter);
    }
    data = data.filter((d)=>d.value && d.value.length > 0).map((d)=>({
            datum: d,
            label: d[props.y],
            value: +d.value
        }));
    if (props.category) {
        const categorize = unsafeDatumFn(props.category);
        data.forEach((d)=>{
            d.category = categorize(d.datum);
        });
    }
    runSort(props.sort, data, (d)=>d.value);
    let groupedData;
    if (props.columnFilter) {
        groupedData = props.columnFilter.map(({ test, title })=>{
            const filter = unsafeDatumFn(test);
            return {
                key: title,
                values: data.filter((d)=>filter(d.datum))
            };
        });
        data = groupedData.reduce((all, group)=>all.concat(group.values), []);
    } else {
        groupedData = groupBy(data, (d)=>d.datum[props.column]);
    }
    runSort(props.columnSort, groupedData, (d)=>d.key);
    const skipYLabels = props.y === props.color && groupedData.length > 1;
    const colorAccessor = props.color ? (d)=>d.datum[props.color] : (d)=>d.category;
    let colorValues = [].concat(data.map(colorAccessor)).concat(props.colorLegendValues).filter(Boolean).filter(deduplicate);
    runSort(props.colorSort, colorValues);
    const color = getColorMapper(props, colorValues);
    const highlight = props.highlight ? unsafeDatumFn(props.highlight) : ()=>false;
    const inlineBarStyle = !!inlineValue || !!inlineLabel;
    const barStyle2 = inlineBarStyle ? BAR_STYLES.inline : BAR_STYLES[props.barStyle];
    groupedData = groupedData.map(({ values: groupData, key: title })=>{
        let gY = 0;
        if (title) {
            gY += COLUMN_TITLE_HEIGHT2;
        }
        let firstBarY;
        let stackedBars = groupBy(groupData, (d)=>d.label);
        let marginBottom = 0;
        const bars = stackedBars.map(({ values: segments })=>{
            const first = segments[0];
            const style = inlineBarStyle ? barStyle2[first.datum[inlineSecondaryLabel] ? "withSecondary" : "normal"] : barStyle2[highlight(first.datum) ? "highlighted" : "normal"];
            gY += marginBottom;
            let labelY = gY;
            if (!skipYLabels && first.label) {
                gY += BAR_LABEL_HEIGHT;
            }
            gY += style.marginTop;
            let y = gY;
            if (firstBarY === void 0) {
                firstBarY = gY;
            }
            gY += style.height;
            marginBottom = style.marginBottom;
            let barSegments = segments;
            runSort(props.colorSort, barSegments, colorAccessor);
            return {
                labelY,
                y,
                style,
                height: style.height,
                segments: barSegments,
                first,
                sumPositiv: barSegments.reduce((sum2, segment)=>sum2 + Math.max(0, segment.value), 0),
                sumNegative: barSegments.reduce((sum2, segment)=>sum2 + Math.min(0, segment.value), 0)
            };
        });
        return {
            title,
            bars,
            maxPositiv: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(bars, (bar)=>bar.sumPositiv),
            minNegative: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__["min"])(bars, (bar)=>bar.sumNegative),
            height: gY,
            firstBarY
        };
    });
    const xDomain = props.domain || [
        Math.min(0, (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__["min"])(groupedData.map((d)=>d.minNegative).concat(props.xTicks || []))),
        Math.max(0, (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(groupedData.map((d)=>d.maxPositiv).concat(props.xTicks || [])))
    ];
    const x = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain(xDomain).range([
        0,
        columnWidth
    ]);
    if (!props.domain) {
        x.nice(3);
    }
    const xAxis = calculateAxis(props.numberFormat, tLabel, x.domain(), void 0, {
        ticks: props.xTicks
    });
    const xTicks = props.xTicks || (showBarValues ? [] : xAxis.ticks);
    const hasXTicks = !inlineValue && !!xTicks.length;
    const xZero = x(0);
    const xLastTick = hasXTicks && x(xTicks[xTicks.length - 1]);
    groupedData.forEach((group)=>{
        group.bars.forEach((bar)=>{
            let xPosPositive = xZero;
            let xPosNegative = xZero;
            bar.segments.forEach((d, i)=>{
                d.color = color(colorAccessor(d));
                const size = x(d.value) - xZero;
                d.x = size > 0 ? Math.floor(xPosPositive) : Math.floor(xPosNegative + size);
                d.width = Math.ceil(Math.abs(size));
                if (xLastTick && isLastItem(bar.segments, i) && Math.abs(xLastTick - d.x - d.width) === 1) {
                    d.width += xLastTick - d.x - d.width;
                }
                if (size > 0) {
                    xPosPositive += size;
                } else {
                    xPosNegative += size;
                }
                const isLast = isLastItem(bar.segments, i);
                d.valueTextStartAnchor = d.value >= 0 && isLast || d.value < 0 && i !== 0;
                const isLastSegment = isLast && i !== 0;
                d.inlineLabel = [
                    inlineValue && xAxis.format(d.value),
                    inlineValueUnit && inlineValueUnit,
                    inlineLabel && d.datum[inlineLabel]
                ].join(" ");
                d.inlineLabelTextWidth = d.inlineLabel ? labelGauger2(d.inlineLabel) : 0;
                const needsInlineTextShift = d.width <= d.inlineLabelTextWidth;
                d.inlinePos = d.datum[inlineLabelPosition] || (d.value >= 0 ? isLastSegment && !needsInlineTextShift ? "right" : "left" : isLastSegment && !needsInlineTextShift ? "left" : "right");
                d.shiftInlineText = isLast && needsInlineTextShift;
                if (d.inlinePos === "right") {
                    d.iTextAnchor = "end";
                    d.iXOffset = d.width - 5;
                    if (d.shiftInlineText) {
                        d.iXOffset = -5;
                    }
                } else if (d.inlinePos === "left") {
                    d.iTextAnchor = "start";
                    d.iXOffset = 5;
                    if (d.shiftInlineText) {
                        d.iXOffset = d.width + 5;
                    }
                } else {
                    d.iTextAnchor = "middle";
                    d.iXOffset = d.width / 2;
                }
            });
            bar.xPosPositive = xPosPositive;
            bar.xPosNegative = xPosNegative;
        });
    });
    const isLollipop = props.barStyle === "lollipop";
    let yPos = 0;
    groupBy(groupedData, (d, i)=>Math.floor(i / columns)).forEach(({ values: groups })=>{
        const height = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(groups.map((d)=>d.height));
        groups.forEach((group, column)=>{
            group.groupHeight = height;
            group.y = yPos;
            group.x = column * (columnWidth + COLUMN_PADDING2);
        });
        yPos += height + (hasXTicks ? AXIS_HEIGHT : 0) + (isLollipop ? LOLLIPOP_PADDING : 0);
    });
    const highlightZero = xTicks.indexOf(0) !== -1 && xTicks[0] !== 0;
    const colorLegendValues = [].concat((props.colorLegend || skipYLabels) && (props.colorLegendValues || colorValues).map((colorValue)=>({
            color: color(colorValue),
            label: colorValue
        }))).concat(!mini && band && bandLegend && {
        label: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("span", __spreadProps(__spreadValues({}, styles2.bandLegend), {
            children: [
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", __spreadValues(__spreadValues({}, styles2.bandBar), colorScheme.set("backgroundColor", "divider"))),
                ` ${bandLegend}`
            ]
        }))
    }).filter(Boolean);
    const barLabelLinkHoverRule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BarChart.useMemo2[barLabelLinkHoverRule]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                "@media (hover)": {
                    ":hover": {
                        fill: colorScheme.getCSSColor("textSoft")
                    }
                }
            })
    }["BarChart.useMemo2[barLabelLinkHoverRule]"], [
        colorScheme
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ColorLegend_default, {
                inline: true,
                values: colorLegendValues
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
                width,
                height: yPos,
                children: [
                    /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("desc", {
                        children: description
                    }),
                    groupedData.map((group)=>{
                        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                            transform: `translate(${group.x},${group.y + (hasXTicks ? AXIS_HEIGHT : 0)})`,
                            children: [
                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({
                                    dy: "1.5em",
                                    y: hasXTicks ? -AXIS_HEIGHT : 0
                                }, styles2.groupTitle), colorScheme.set("fill", "text")), {
                                    children: group.title
                                })),
                                group.bars.map((bar)=>{
                                    const href = bar.first.datum[link2];
                                    const hasNegativeValues = bar.xPosNegative !== xZero;
                                    const hasPositiveValues = bar.xPosPositive !== xZero;
                                    let barLabel = skipYLabels ? null : /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, styles2.barLabel), colorScheme.set("fill", "text")), href && barLabelLinkHoverRule), {
                                        y: bar.labelY,
                                        dy: "0.9em",
                                        x: x(0) + (highlightZero ? hasPositiveValues && hasNegativeValues ? 0 : hasPositiveValues ? 2 : -2 : 0),
                                        textAnchor: hasPositiveValues && hasNegativeValues ? "middle" : hasPositiveValues ? "start" : "end",
                                        children: subsup.svg(bar.first.label)
                                    }));
                                    if (href) {
                                        barLabel = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("a", {
                                            xlinkHref: href,
                                            children: barLabel
                                        });
                                    }
                                    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                                        children: [
                                            barLabel,
                                            bar.segments.sort((a, b)=>{
                                                if (!inlineLabel || a.datum[inlineLabel] && b.datum[inlineLabel] || !a.datum[inlineLabel] && !b.datum[inlineLabel]) {
                                                    return 0;
                                                }
                                                return a.datum[inlineLabel] ? 1 : -1;
                                            }).map((segment, i)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                                                    transform: `translate(0,${bar.y})`,
                                                    children: [
                                                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", __spreadProps(__spreadValues({
                                                            x: segment.x
                                                        }, colorScheme.set("fill", segment.color, "charts")), {
                                                            width: segment.width,
                                                            height: bar.height
                                                        })),
                                                        (inlineValue || inlineLabel) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                            children: [
                                                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadProps(__spreadValues({}, styles2.inlineLabel), {
                                                                    x: segment.x + segment.iXOffset,
                                                                    y: bar.style.inlineTop,
                                                                    dy: "1em",
                                                                    fontSize: bar.style.fontSize
                                                                }), colorScheme.set("fill", segment.shiftInlineText ? "text" : getTextColor(segment.color))), {
                                                                    textAnchor: segment.iTextAnchor,
                                                                    children: subsup.svg(segment.inlineLabel)
                                                                })),
                                                                inlineSecondaryLabel && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadProps(__spreadValues({}, styles2.inlineLabel), {
                                                                    x: segment.x + segment.iXOffset,
                                                                    y: bar.style.inlineTop + bar.style.fontSize + 5,
                                                                    dy: "1em",
                                                                    fontSize: bar.style.secondaryFontSize
                                                                }), colorScheme.set("fill", segment.shiftInlineText ? "text" : getTextColor(segment.color))), {
                                                                    textAnchor: segment.iTextAnchor,
                                                                    children: subsup.svg(segment.datum[inlineSecondaryLabel])
                                                                }))
                                                            ]
                                                        }),
                                                        isLollipop && band && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", __spreadProps(__spreadValues({
                                                            rx: bar.style.popHeight / 2,
                                                            ry: bar.style.popHeight / 2,
                                                            x: x(+segment.datum[`${band}_lower`]),
                                                            y: bar.height / 2 - bar.style.popHeight / 2,
                                                            width: x(+segment.datum[`${band}_upper`]) - x(+segment.datum[`${band}_lower`])
                                                        }, colorScheme.set("fill", segment.color, "charts")), {
                                                            height: bar.style.popHeight,
                                                            fillOpacity: "0.3"
                                                        })),
                                                        isLollipop && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", __spreadProps(__spreadValues(__spreadValues({
                                                            cx: segment.x + (segment.value >= 0 ? segment.width - 1 : 0),
                                                            cy: bar.height / 2,
                                                            r: Math.floor(bar.style.popHeight - bar.style.stroke / 2) / 2
                                                        }, colorScheme.set("fill", "textInverted")), colorScheme.set("stroke", segment.color, "charts")), {
                                                            strokeWidth: bar.style.stroke
                                                        }))
                                                    ]
                                                }, `seg${i}`)),
                                            showBarValues && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                children: [
                                                    bar.sumNegative && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles2.barLabel), colorScheme.set("fill", "text")), {
                                                        x: bar.xPosNegative - 6 - (isLollipop ? 8 : 0),
                                                        textAnchor: "end",
                                                        y: bar.y + bar.height / 2,
                                                        dy: ".35em",
                                                        children: [
                                                            xAxis.format(bar.sumNegative),
                                                            " ",
                                                            unit
                                                        ]
                                                    })),
                                                    bar.sumPositiv && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles2.barLabel), colorScheme.set("fill", "text")), {
                                                        x: bar.xPosPositive + 6 + (isLollipop ? 8 : 0),
                                                        textAnchor: "start",
                                                        y: bar.y + bar.height / 2,
                                                        dy: ".35em",
                                                        children: [
                                                            xAxis.format(bar.sumPositiv),
                                                            " ",
                                                            unit
                                                        ]
                                                    }))
                                                ]
                                            })
                                        ]
                                    }, `bar${bar.y}`);
                                }),
                                hasXTicks && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("g", {
                                    transform: `translate(0,${group.title ? COLUMN_TITLE_HEIGHT2 : 0})`,
                                    children: xTicks.map((tick, i)=>{
                                        let textAnchor = "middle";
                                        const isLast = isLastItem(xTicks, i);
                                        if (isLast) {
                                            textAnchor = "end";
                                        }
                                        if (i === 0) {
                                            textAnchor = "start";
                                        }
                                        const highlightTick = tick === 0 && highlightZero;
                                        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                                            "data-axis": true,
                                            transform: `translate(${x(tick)},0)`,
                                            children: [
                                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", __spreadProps(__spreadValues(__spreadValues({}, styles2.axisXLine), colorScheme.set("stroke", "text")), {
                                                    style: {
                                                        opacity: highlightTick ? 1 : 0.17
                                                    },
                                                    y1: 0,
                                                    y2: group.groupHeight
                                                })),
                                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles2.axisLabel), highlightTick ? colorScheme.set("fill", "text") : colorScheme.set("fill", "textSoft")), {
                                                    y: 0,
                                                    dy: "-0.5em",
                                                    textAnchor,
                                                    children: [
                                                        xAxis.axisFormat(tick, isLast),
                                                        " ",
                                                        isLast && unit
                                                    ]
                                                }))
                                            ]
                                        }, `tick${tick}`);
                                    })
                                })
                            ]
                        }, `group${group.title || 1}`);
                    })
                ]
            })
        ]
    });
};
_s3(BarChart, "pRWnYWSU44qR8LJYWYGoYmtbVvM=", false, function() {
    return [
        useColorContext,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]
    ];
});
_c6 = BarChart;
var propTypes2 = {
    values: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
    width: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    mini: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    domain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array,
    y: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    xTicks: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
    ])),
    barStyle: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf(Object.keys(BAR_STYLES)),
    band: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    bandLegend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    sort: sortPropType,
    column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    columnSort: sortPropType,
    columnFilter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        title: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        test: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired
    })),
    highlight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    stroke: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    color: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    colorRange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array
    ]),
    colorMap: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    colorSort: sortPropType,
    colorLegend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    colorLegendValues: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string),
    colorRanges: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        diverging2: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
        sequential3: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
        discrete: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired
    }).isRequired,
    category: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    numberFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    filter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    minInnerWidth: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    columns: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    inlineValue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    inlineValueUnit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    inlineLabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    inlineSecondaryLabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    inlineLabelPosition: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    tLabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    description: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    showBarValues: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    unit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
};
BarChart.propTypes = propTypes2;
var Lollipop = (props)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(BarChart, __spreadValues(__spreadValues({}, defaultProps.Lollipop), props));
_c7 = Lollipop;
Lollipop.wrap = "Bar";
var Bars_default = BarChart;
;
;
;
;
;
;
;
;
var valueGauger2 = createTextGauger(sansSerifMedium12, {
    dimension: "width",
    html: true
});
var labelGauger3 = createTextGauger(sansSerifRegular12, {
    dimension: "width",
    html: true
});
var styles3 = {
    annotationLine: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        strokeWidth: "1px",
        fillRule: "evenodd",
        strokeLinecap: "round",
        strokeDasharray: "1,3",
        strokeLinejoin: "round"
    }),
    annotationLineValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        strokeWidth: "1px",
        shapeRendering: "crispEdges"
    }),
    annotationValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifMedium12)),
    annotationText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifRegular12))
};
var showAnnotationValue = (annotation)=>annotation.showValue !== false;
var YAnnotation = ({ annotation, width, tLabel, yFormat, xCalc })=>{
    _s4();
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", __spreadValues(__spreadValues({
                x1: 0,
                x2: width
            }, styles3.annotationLine), colorScheme.set("stroke", "text"))),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", __spreadValues(__spreadValues({
                r: "3.5",
                cx: annotation.x ? xCalc(annotation.x) : 4
            }, colorScheme.set("stroke", "text")), colorScheme.set("fill", "textInverted"))),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("text", __spreadProps(__spreadValues(__spreadValues({
                x: width,
                textAnchor: "end",
                dy: annotation.dy || "-0.4em"
            }, styles3.annotationText), colorScheme.set("fill", "text")), {
                children: [
                    tLabel(annotation.label),
                    showAnnotationValue(annotation) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            " ",
                            yFormat(annotation.value),
                            " ",
                            tLabel(annotation.unit)
                        ]
                    })
                ]
            }))
        ]
    });
};
_s4(YAnnotation, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c8 = YAnnotation;
var XAnnotation = ({ annotation, tLabel, yFormat, barWidth, xCalc, width })=>{
    _s5();
    const [colorScheme] = useColorContext();
    if (annotation.ghost && !annotation.valuePrefix && !annotation.label && !annotation.position) {
        return null;
    }
    const isRange = annotation.x1 !== void 0 && annotation.x2 !== void 0;
    const labelText = tLabel(annotation.label);
    const valueText = showAnnotationValue(annotation) && [
        tLabel(annotation.valuePrefix),
        yFormat(annotation.value),
        annotation.unit ? " " : "",
        tLabel(annotation.unit)
    ].filter(Boolean).join("");
    const textSize = Math.max(labelText ? labelGauger3(labelText) : 0, valueText ? valueGauger2(valueText) : 0);
    const x1 = annotation.leftLabel ? 0 : isRange ? xCalc(annotation.x1) : xCalc(annotation.x);
    const x2 = isRange ? xCalc(annotation.x2) + barWidth : x1 + Math.max(barWidth, 8);
    let textAnchor = "middle";
    let tx = annotation.leftLabel ? 0 : x1 + (x2 - x1) / 2;
    if (annotation.leftLabel) {
        textAnchor = "start";
    } else if (annotation.textAlignment === void 0) {
        if (x1 + (x2 - x1) / 2 + textSize / 2 > width) {
            textAnchor = "end";
            tx = x2;
            if ((isRange ? x2 : x1) - textSize < 0) {
                textAnchor = "start";
                tx = x1;
            }
        } else {
            textAnchor = "middle";
        }
    } else {
        textAnchor = textAlignmentDict[annotation.textAlignment];
    }
    const isBottom = annotation.position === "bottom";
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", __spreadValues(__spreadValues({
                x1,
                x2
            }, isRange ? styles3.annotationLine : styles3.annotationLineValue), colorScheme.set("stroke", "text"))),
            annotation.leftLabel === void 0 && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", __spreadValues(__spreadValues({
                r: "3.5",
                cx: x1
            }, colorScheme.set("stroke", "text")), colorScheme.set("fill", "textInverted"))),
            isRange && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", __spreadValues(__spreadValues({
                r: "3.5",
                cx: x2
            }, colorScheme.set("stroke", "text")), colorScheme.set("fill", "textInverted"))),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({
                x: tx,
                textAnchor,
                dy: valueText ? isBottom ? "2.7em" : "-1.8em" : isBottom ? "1.4em" : "-0.5em"
            }, styles3.annotationText), colorScheme.set("fill", "text")), {
                children: labelText
            })),
            valueText && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({
                x: tx,
                textAnchor,
                dy: isBottom ? "1.4em" : "-0.5em"
            }, styles3.annotationValue), colorScheme.set("fill", "text")), {
                children: valueText
            }))
        ]
    });
};
_s5(XAnnotation, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c9 = XAnnotation;
;
var styles4 = {
    columnTitle: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifMedium14)),
    axisLabel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifRegular12)),
    axisYLine: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        strokeWidth: "1px",
        shapeRendering: "crispEdges"
    }),
    axisXLine: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        strokeWidth: "1px",
        shapeRendering: "crispEdges"
    })
};
var TimeBarGroup = ({ bars, title, xAnnotations, yAnnotations, yTicks, x, y, xNormalizer, yAxis, tLabel, color, width, xAxisPos, xAxisElement, yScaleInvert })=>{
    _s6();
    const [colorScheme] = useColorContext();
    const barWidth = x.bandwidth();
    const baseTick = y.domain()[0];
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            title && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({
                dy: "1.5em"
            }, styles4.columnTitle), colorScheme.set("fill", "text")), {
                children: title
            })),
            xAnnotations.filter((annotation)=>annotation.ghost).map((annotation, i)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", __spreadValues({
                    x: x(xNormalizer(annotation.x)),
                    y: y(annotation.value),
                    width: barWidth,
                    height: y(0) - y(annotation.value),
                    shapeRendering: "crispEdges"
                }, colorScheme.set("fill", "divider")), `ghost-${i}`)),
            bars.map((bar)=>{
                return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("g", {
                    transform: `translate(${x(bar.x)},0)`,
                    children: bar.segments.map((segment, i)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", __spreadValues({
                            y: segment.y,
                            width: barWidth,
                            height: segment.height,
                            shapeRendering: "crispEdges"
                        }, colorScheme.set("fill", color(segment), "charts")), i))
                }, bar.x);
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("g", {
                transform: `translate(0,${xAxisPos})`,
                children: xAxisElement
            }),
            yTicks.map((tick, i)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                    "data-axis": true,
                    transform: `translate(0,${y(tick)})`,
                    children: [
                        tick !== baseTick && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", __spreadProps(__spreadValues(__spreadValues({}, styles4.axisYLine), colorScheme.set("stroke", "text")), {
                            style: {
                                opacity: tick === 0 ? 0.8 : 0.17
                            },
                            x2: width
                        })),
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles4.axisLabel), colorScheme.set("fill", "text")), {
                            dy: yScaleInvert ? "13px" : "-3px",
                            children: yAxis.axisFormat(tick, last(yTicks, i))
                        }))
                    ]
                }, tick)),
            yAnnotations.map((annotation, i)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("g", {
                    transform: `translate(0,${y(annotation.value)})`,
                    children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(YAnnotation, {
                        annotation,
                        width,
                        yFormat: yAxis.format,
                        xCalc: (d)=>x(xNormalizer(d)),
                        tLabel
                    })
                }, `y-annotation-${i}`)),
            xAnnotations.map((annotation, i)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("g", {
                    transform: `translate(0,${y(annotation.value)})`,
                    children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(XAnnotation, {
                        annotation,
                        width,
                        barWidth,
                        yFormat: yAxis.format,
                        xCalc: (d)=>x(xNormalizer(d)),
                        tLabel
                    })
                }, `x-annotation-${i}`))
        ]
    });
};
_s6(TimeBarGroup, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c10 = TimeBarGroup;
var TimeBarGroup_default = TimeBarGroup;
;
;
;
var styles5 = {
    axisLabel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(sansSerifRegular12),
    axisXLine: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        strokeWidth: "1px",
        shapeRendering: "crispEdges"
    })
};
var tickGauger = createTextGauger(sansSerifRegular12, {
    dimension: "width",
    html: true
});
var XAxis = ({ xUnit, yScaleInvert, type, lines: customLines })=>{
    _s7();
    const [colorScheme] = useColorContext();
    const chartContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(ChartContext);
    const { xAxis } = chartContext;
    const baseLines = type === "TimeBar" && getBaselines(xAxis.domain, xAxis.scale, chartContext.innerWidth);
    const tickPosition = type === "TimeBar" ? Math.round(xAxis.scale.bandwidth() / 2) : 0;
    const xUnitWidth = xUnit ? tickGauger(xUnit) : 0;
    let currentTextAnchor;
    let currentX;
    const lines = (customLines == null ? void 0 : customLines.map((line)=>__spreadProps(__spreadValues({}, line), {
            tick: chartContext.xNormalizer(line.tick)
        }))) || xAxis.ticks.map((tick)=>({
            tick
        }));
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
        "data-axis": true,
        children: [
            baseLines && baseLines.map((line, i)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", __spreadProps(__spreadValues(__spreadValues({
                    x1: line.x1,
                    x2: line.x2
                }, styles5.axisXLine), colorScheme.set("stroke", "divider")), {
                    strokeDasharray: line.gap ? "2 2" : "none"
                }), i)),
            lines.map(({ tick, label, textAnchor }, i)=>{
                const tickText = label != null ? label : xAxis.axisFormat(tick);
                currentX = xAxis.scale(tick) + tickPosition;
                currentTextAnchor = "middle";
                if (isLastItem(xAxis.ticks, i)) {
                    const tickTextWidth = Math.max(tickGauger(tickText), xUnitWidth);
                    if (currentX + tickTextWidth / 2 > chartContext.innerWidth + chartContext.paddingRight) {
                        currentTextAnchor = "end";
                    }
                }
                if (i === 0) {
                    const tickTextWidth = tickGauger(tickText);
                    if (chartContext.paddingLeft + currentX - tickTextWidth / 2 < 0) {
                        currentTextAnchor = "start";
                    }
                }
                if (textAnchor) {
                    currentTextAnchor = textAnchor;
                }
                const lineAlignmentCorrection = currentX === 0 ? 0.5 : currentX === chartContext.innerWidth ? -0.5 : 0;
                return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                    transform: `translate(${currentX}, 0)`,
                    children: [
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", __spreadProps(__spreadValues(__spreadValues({
                            x1: lineAlignmentCorrection,
                            x2: lineAlignmentCorrection
                        }, styles5.axisXLine), colorScheme.set("stroke", "text")), {
                            y2: yScaleInvert ? X_TICK_HEIGHT - 6 : X_TICK_HEIGHT
                        })),
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles5.axisLabel), colorScheme.set("fill", "text")), {
                            y: X_TICK_HEIGHT + 5,
                            dy: yScaleInvert ? "-1.1em" : "0.6em",
                            textAnchor: currentTextAnchor,
                            children: subsup.svg(tickText)
                        }))
                    ]
                }, tick);
            }),
            !!xAxis.ticks.length && xUnit && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({
                x: currentX,
                y: yScaleInvert ? -20 : X_UNIT_PADDING,
                textAnchor: currentTextAnchor
            }, styles5.axisLabel), colorScheme.set("fill", "text")), {
                children: subsup.svg(xUnit)
            }))
        ]
    });
};
_s7(XAxis, "ri13uSDhhhr9hcdCI1+WyzhaYWk=", false, function() {
    return [
        useColorContext
    ];
});
_c11 = XAxis;
var XAxis_default = XAxis;
;
var TimeBarChart = (_props)=>{
    _s8();
    const props = __spreadValues(__spreadValues({}, defaultProps.TimeBar), _props);
    const { width, tLabel, description, yAnnotations = [], xAnnotations = [], xUnit, yScaleInvert, type, height: innerHeight } = props;
    const chartContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(ChartContext);
    const { groupPosition, yAxis, xAxis } = chartContext;
    chartContext.groupedData.forEach((group)=>{
        group.bars.forEach((bar)=>{
            let upValue = 0;
            let upPos = yAxis.scale(0);
            let downValue = 0;
            let downPos = yAxis.scale(0);
            bar.segments.forEach((segment)=>{
                const isPositive = yScaleInvert ? segment.value < 0 : segment.value > 0;
                const baseValue = isPositive ? upValue : downValue;
                const y0 = yAxis.scale(baseValue);
                const y1 = yAxis.scale(baseValue + segment.value);
                const size = segment.height = Math.abs(y0 - y1);
                if (isPositive) {
                    upPos -= size;
                    segment.y = upPos;
                    upValue += segment.value;
                } else {
                    segment.y = downPos;
                    downPos += size;
                    downValue += segment.value;
                }
            });
        });
    });
    const yTicks = [].concat(yAxis.ticks).sort(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$ascending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ascending$3e$__["ascending"]);
    const xAxisElement = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(XAxis_default, {
        xUnit,
        yScaleInvert,
        type
    });
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ColorLegend_default, {
                inline: true,
                values: chartContext.colorLegendValues
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
                width,
                height: chartContext.height,
                children: [
                    /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("desc", {
                        children: description
                    }),
                    chartContext.groupedData.map(({ bars, key })=>{
                        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("g", {
                            transform: `translate(${groupPosition.x(key)},${groupPosition.y(key)})`,
                            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TimeBarGroup_default, {
                                bars,
                                title: key,
                                xAnnotations: xAnnotations.filter((annotation)=>!annotation.column || annotation.column === key),
                                yAnnotations: yAnnotations.filter((annotation)=>!annotation.column || annotation.column === key),
                                yTicks,
                                x: xAxis.scale,
                                y: yAxis.scale,
                                xNormalizer: chartContext.xNormalizer,
                                yAxis,
                                width: chartContext.innerWidth,
                                xAxisElement,
                                xAxisPos: yScaleInvert ? PADDING_TOP + PADDING_TOP / 2 + groupPosition.titleHeight : innerHeight + PADDING_TOP + groupPosition.titleHeight,
                                tLabel,
                                color: (d)=>chartContext.color(chartContext.colorAccessor(d)),
                                yScaleInvert
                            })
                        }, key || 1);
                    })
                ]
            })
        ]
    });
};
_s8(TimeBarChart, "AtMjs5bGLIHxVsN1V48hqdclPuU=");
_c12 = TimeBarChart;
var propTypes3 = {
    values: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
    padding: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    width: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    mini: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    height: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    color: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    colorRange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array
    ]),
    colorLegend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    colorLegendValues: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string),
    colorRanges: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        sequential3: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
        discrete: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired
    }).isRequired,
    colorMap: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    domain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number),
    yTicks: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
    ])),
    yAnnotations: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
        unit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        x: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]),
        dy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        showValue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
    })).isRequired,
    timeParse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    timeFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    xBandPadding: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    x: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    xInterval: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf(Object.keys(intervals)),
    xTicks: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    ])),
    xScale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        "time",
        "ordinal",
        "linear"
    ]),
    xAnnotations: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        valuePrefix: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]).isRequired,
        unit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        x: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]),
        x1: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]),
        x2: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]),
        ghost: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
        position: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            "top",
            "bottom"
        ]),
        showValue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
    })).isRequired,
    unit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    xUnit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    numberFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    filter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    tLabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    description: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    columnSort: sortPropType,
    columnFilter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        title: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        test: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired
    })),
    columns: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    minInnerWidth: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    yScaleInvert: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
};
TimeBarChart.propTypes = propTypes3;
var TimeBars_default = TimeBarChart;
;
;
;
;
;
;
;
;
var styles6 = {
    columnTitle: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifMedium14)),
    axisLabel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifRegular12)),
    axisYLine: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        strokeWidth: "1px",
        shapeRendering: "crispEdges"
    }),
    axisXLine: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        strokeWidth: "1px",
        shapeRendering: "crispEdges"
    }),
    annotationLine: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        strokeWidth: "1px",
        fillRule: "evenodd",
        strokeLinecap: "round",
        strokeDasharray: "1,3",
        strokeLinejoin: "round"
    }),
    annotationText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifRegular12)),
    annotationValue: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifMedium12)),
    value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifMedium12)),
    valueMini: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifMedium22)),
    label: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifRegular12))
};
var LineGroup = (props)=>{
    _s9();
    const { lines, mini, title, y, yLines, yAxisFormat, x, width, yCut, yCutHeight, yConnectorSize, yNeedsConnectors, yAnnotations, xAnnotations, band, area, areaOpacity = 1, endDy, xAccessor: xAccessor2, xAxisElement, strokeWidth, strokeWidthHighlighted } = props;
    const [colorScheme] = useColorContext();
    const [height] = y.range();
    const pathGenerator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__line$3e$__["line"])().x((d)=>x(xAccessor2(d))).y((d)=>y(d.value));
    const bandArea = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$area$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__area$3e$__["area"])().x((d)=>x(xAccessor2(d))).y0((d)=>y(+d.datum[`${band}_lower`])).y1((d)=>y(+d.datum[`${band}_upper`]));
    const lineArea = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$area$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__area$3e$__["area"])().x((d)=>x(xAccessor2(d))).y0((d)=>y(+d.datum[`${area}_lower`])).y1((d)=>y(+d.datum[`${area}_upper`]));
    const linesWithLayout = lines.map((line)=>{
        return __spreadProps(__spreadValues({}, line), {
            startX: x(xAccessor2(line.start)),
            // we always render at end label outside of the chart area
            // even if the line ends in the middle of the graph
            endX: width,
            strokeWidth,
            strokeWidthHighlighted
        });
    });
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({
                dy: "1.7em"
            }, styles6.columnTitle), colorScheme.set("fill", "text")), {
                children: subsup.svg(title)
            })),
            !!yCut && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({
                y: height + yCutHeight / 2,
                dy: "0.3em"
            }, styles6.axisLabel), colorScheme.set("fill", "text")), {
                children: yCut
            })),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("g", {
                transform: `translate(0,${height + (!!yCut && yCutHeight)})`,
                children: xAxisElement
            }),
            linesWithLayout.map(({ line, startValue, endValue, endLabel, highlighted, stroked, start, startX, startY, startLabelY, end, endX, endY, endLabelY, lineColor, strokeWidth: strokeWidth2, strokeWidthHighlighted: strokeWidthHighlighted2 }, i)=>{
                return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                    children: [
                        startValue && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                            children: [
                                yNeedsConnectors && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", __spreadValues({
                                    cx: startX - Y_CONNECTOR_PADDING - Y_CONNECTOR / 2,
                                    cy: startLabelY + 0.5,
                                    r: Y_CONNECTOR / 2
                                }, colorScheme.set("fill", lineColor, "charts"))),
                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles6.value), colorScheme.set("fill", "text")), {
                                    dy: "0.3em",
                                    x: startX - yConnectorSize,
                                    y: startLabelY,
                                    textAnchor: "end",
                                    children: startValue
                                }))
                            ]
                        }),
                        band && line.find((d)=>d.datum[`${band}_lower`]) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", __spreadProps(__spreadValues({}, colorScheme.set("fill", lineColor, "charts")), {
                            fillOpacity: "0.2",
                            d: bandArea(line)
                        })),
                        area && line.find((d)=>d.datum[`${area}_lower`]) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", __spreadProps(__spreadValues({}, colorScheme.set("fill", lineColor, "charts")), {
                            fillOpacity: areaOpacity,
                            d: lineArea(line)
                        })),
                        line.find((d)=>isValuePresent(d.value)) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", __spreadProps(__spreadValues({
                            fill: "none"
                        }, colorScheme.set("stroke", lineColor, "charts")), {
                            strokeWidth: highlighted ? strokeWidthHighlighted2 : strokeWidth2,
                            strokeDasharray: stroked ? "6 2" : "none",
                            d: pathGenerator(line)
                        })),
                        (endValue || endLabel) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                            children: [
                                !mini && yNeedsConnectors && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", __spreadValues({
                                    cx: endX + Y_CONNECTOR_PADDING + Y_CONNECTOR / 2,
                                    cy: endLabelY + 0.5,
                                    r: Y_CONNECTOR / 2
                                }, colorScheme.set("fill", lineColor, "charts"))),
                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("text", __spreadProps(__spreadValues({
                                    dy: endDy,
                                    x: mini ? endX : endX + yConnectorSize,
                                    y: mini ? endLabelY - Y_LABEL_HEIGHT : endLabelY
                                }, colorScheme.set("fill", "text")), {
                                    textAnchor: mini ? "end" : "start",
                                    children: [
                                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("tspan", __spreadProps(__spreadValues({}, styles6[mini ? "valueMini" : "value"]), {
                                            children: endValue
                                        })),
                                        endLabel && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("tspan", __spreadProps(__spreadValues(__spreadValues({}, styles6.label), colorScheme.set("fill", "text")), {
                                            children: [
                                                " ",
                                                subsup.svg(endLabel)
                                            ]
                                        }))
                                    ]
                                }))
                            ]
                        })
                    ]
                }, `line${endLabel}${i}`);
            }),
            yLines.map(({ tick, label, base, dy = "-3px", opacity }, i)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                    "data-axis": true,
                    transform: `translate(0,${y(tick)})`,
                    children: [
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", __spreadProps(__spreadValues(__spreadValues({}, styles6.axisYLine), colorScheme.set("stroke", "text")), {
                            x2: width,
                            style: {
                                opacity: opacity != null ? opacity : base || base === void 0 && tick === 0 ? 0.8 : 0.17
                            }
                        })),
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles6.axisLabel), colorScheme.set("fill", "text")), {
                            dy,
                            children: subsup.svg(label != null ? label : yAxisFormat(tick, isLastItem(yLines, i)))
                        }))
                    ]
                }, `y${tick}`)),
            yAnnotations.map((annotation, i)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                    transform: `translate(0,${y(annotation.value)})`,
                    children: [
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", __spreadValues(__spreadValues({
                            x1: 0,
                            x2: width
                        }, styles6.annotationLine), colorScheme.set("stroke", "text"))),
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", __spreadValues(__spreadValues({
                            r: "3.5",
                            cx: annotation.x ? x(annotation.x) : 4
                        }, colorScheme.set("stroke", "text")), colorScheme.set("fill", "textInverted"))),
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("text", __spreadProps(__spreadValues(__spreadValues({
                            x: width,
                            textAnchor: "end",
                            dy: annotation.dy || "-0.4em"
                        }, styles6.annotationText), colorScheme.set("fill", "text")), {
                            children: [
                                annotation.label,
                                annotation.showValue !== false && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        " ",
                                        annotation.formattedValue,
                                        " ",
                                        subsup.svg(annotation.unit)
                                    ]
                                })
                            ]
                        }))
                    ]
                }, `annotation-${i}`)),
            xAnnotations.map((annotation, i)=>{
                var _a;
                const range3 = annotation.x1 !== void 0 && annotation.x2 !== void 0;
                const x1 = range3 ? x(annotation.x1) : x(annotation.x);
                const x2 = range3 && x(annotation.x2);
                const fullWidth = width + (props.paddingRight || 0);
                let textAnchor = "middle";
                let tx = x1;
                if (textAlignmentDict[annotation.textAlignment]) {
                    textAnchor = textAlignmentDict[annotation.textAlignment];
                } else {
                    if (x1 + (range3 ? x2 - x1 : 0) / 2 + annotation.labelSize / 2 > fullWidth) {
                        textAnchor = "end";
                        if ((range3 ? x2 : x1) - annotation.labelSize < 0) {
                            textAnchor = "start";
                        }
                    }
                    if (range3) {
                        if (textAnchor === "end") {
                            tx = x2;
                        }
                        if (textAnchor === "middle") {
                            tx = x1 + (x2 - x1) / 2;
                        }
                    }
                }
                const isBottom = annotation.position === "bottom";
                const showValue = annotation.showValue !== false;
                return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                    transform: `translate(0,${y(annotation.value)})`,
                    children: [
                        range3 && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", __spreadValues(__spreadValues({
                            x1,
                            x2
                        }, styles6.annotationLine), colorScheme.set("stroke", "text"))),
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", __spreadValues(__spreadValues({
                            r: "3.5",
                            cx: x1
                        }, colorScheme.set("fill", "textInverted")), colorScheme.set("stroke", "text"))),
                        range3 && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", __spreadValues(__spreadValues({
                            r: "3.5",
                            cx: x2
                        }, colorScheme.set("fill", "textInverted")), colorScheme.set("stroke", "text"))),
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({
                            x: tx,
                            textAnchor,
                            dy: showValue ? isBottom ? "2.5em" : "-1.8em" : isBottom ? "0.1em" : "-0.1em"
                        }, styles6.annotationText), colorScheme.set("fill", "text")), {
                            children: (_a = annotation.label) == null ? void 0 : _a.split("\n").map((line, i2, all)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("tspan", {
                                    x: tx,
                                    dy: showValue ? isBottom ? "1.1em" : "-1.1em" : 0,
                                    y: isBottom ? `${0.1 + 1.1 * (i2 + 1)}em` : `-${0.5 + 1.1 * (all.length - i2 - 1)}em`,
                                    children: line
                                }, i2))
                        })),
                        showValue && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("text", __spreadProps(__spreadValues(__spreadValues({
                            x: tx,
                            textAnchor,
                            dy: isBottom ? "1.4em" : "-0.5em"
                        }, styles6.annotationValue), colorScheme.set("fill", "text")), {
                            children: [
                                annotation.valuePrefix,
                                annotation.formattedValue,
                                " ",
                                subsup.svg(annotation.unit)
                            ]
                        }))
                    ]
                }, `x-annotation-${i}`);
            })
        ]
    });
};
_s9(LineGroup, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c13 = LineGroup;
LineGroup.propTypes = {
    lines: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        line: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
            value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        })),
        start: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
            value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        }),
        end: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
            value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        }),
        highlighted: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
        stroked: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
        lineColor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        startValue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
        ]).isRequired,
        endValue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
        ]).isRequired
    })),
    mini: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    title: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    y: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    yCut: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    yCutHeight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    yLines: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
    yAxisFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    yAnnotations: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        x: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].date,
        dy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    })),
    x: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    xAccessor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    endDy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    width: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    band: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
};
var LineGroup_default = LineGroup;
;
var styles7 = {
    bandLegend: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, sansSerifRegular12), {
        whiteSpace: "nowrap"
    })),
    bandBar: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        display: "inline-block",
        width: 24,
        height: 11,
        marginBottom: -1,
        borderTopWidth: 4,
        borderBottomWidth: 4,
        borderTopStyle: "solid",
        borderBottomStyle: "solid"
    })
};
var LineChart = (props)=>{
    _s10();
    const { width, mini, description, band, bandLegend, area, areaOpacity, endDy, strokeWidth, strokeWidthHighlighted } = props;
    const [colorScheme] = useColorContext();
    const chartContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useContext(ChartContext);
    const { paddingLeft, paddingRight, yLayout, groupPosition, xAxis, yAxis } = chartContext;
    const visibleColorLegendValues = [].concat(chartContext.colorLegendValues).concat(!mini && band && bandLegend && {
        label: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("span", __spreadProps(__spreadValues(__spreadValues({}, styles7.bandLegend), colorScheme.set("color", "text")), {
            children: [
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", __spreadValues(__spreadValues(__spreadValues(__spreadValues({}, styles7.bandBar), colorScheme.set("backgroundColor", "text")), colorScheme.set("borderTopColor", "divider")), colorScheme.set("borderBottomColor", "divider"))),
                ` ${bandLegend}`
            ]
        }))
    }).filter(Boolean);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                style: {
                    paddingLeft,
                    paddingRight
                },
                children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ColorLegend_default, {
                    inline: true,
                    values: visibleColorLegendValues
                })
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
                width,
                height: chartContext.height + (props.xUnit ? X_UNIT_PADDING : 0),
                children: [
                    /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("desc", {
                        children: description
                    }),
                    chartContext.groupedData.map(({ values: lines, key })=>{
                        var _a;
                        const filterByColumn = (d)=>!d.column || d.column === key;
                        const yLines = props.yLines || yAxis.ticks.map((tick)=>({
                                tick
                            }));
                        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("g", {
                            transform: `translate(${groupPosition.x(key) + paddingLeft},${groupPosition.y(key)})`,
                            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LineGroup_default, {
                                mini,
                                title: key,
                                lines,
                                x: xAxis.scale,
                                xAccessor,
                                y: yAxis.scale,
                                yTicks: yAxis.ticks,
                                yLines: yLines.filter(filterByColumn),
                                yAxisFormat: yAxis.axisFormat,
                                band,
                                area,
                                areaOpacity,
                                yCut: yLayout.yCut,
                                yCutHeight: yLayout.yCutHeight,
                                yConnectorSize: yLayout.yConnectorSize,
                                yNeedsConnectors: yLayout.yNeedsConnectors,
                                yAnnotations: chartContext.yAnnotations.filter(filterByColumn),
                                xAnnotations: chartContext.xAnnotations.filter(filterByColumn),
                                endDy,
                                width: chartContext.innerWidth,
                                paddingRight,
                                strokeWidth,
                                strokeWidthHighlighted,
                                xAxisElement: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(XAxis_default, {
                                    xUnit: props.xUnit,
                                    lines: (_a = props.xLines) == null ? void 0 : _a.filter(filterByColumn),
                                    type: props.type
                                })
                            })
                        }, key || 1);
                    })
                ]
            })
        ]
    });
};
_s10(LineChart, "ri13uSDhhhr9hcdCI1+WyzhaYWk=", false, function() {
    return [
        useColorContext
    ];
});
_c14 = LineChart;
var propTypes4 = {
    values: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
    width: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    mini: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    x: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    xUnit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    xScale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        "time",
        "ordinal",
        "linear"
    ]),
    xNumberFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    xSort: sortPropType,
    xTicks: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
    ])),
    xLines: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        tick: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]).isRequired,
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        textAnchor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    }).isRequired),
    yScale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf(Object.keys(yScales)),
    timeParse: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    timeFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    columnSort: sortPropType,
    columnFilter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        title: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        test: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired
    })),
    highlight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    stroke: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    labelFilter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    color: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    colorSort: sortPropType,
    colorRange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array
    ]),
    colorRanges: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        sequential3: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
        discrete: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired
    }).isRequired,
    colorMap: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    colorLegend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    colorLegendValues: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string),
    category: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    areaOpacity: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    area: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    band: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    bandLegend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    numberFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    zero: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool.isRequired,
    filter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    startValue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool.isRequired,
    endLabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool.isRequired,
    endLabelWidth: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    endDy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    minInnerWidth: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    columns: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    height: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    paddingTop: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    paddingRight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    paddingLeft: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    unit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    yNice: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    yTicks: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number),
    yLines: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        tick: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        base: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
    }).isRequired),
    yAnnotations: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
        unit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        x: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]),
        dy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        showValue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
    })),
    xAnnotations: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        valuePrefix: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]).isRequired,
        unit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        x: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]),
        x1: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]),
        x2: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]),
        position: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            "top",
            "bottom"
        ]),
        showValue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
    })),
    tLabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    description: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
};
LineChart.propTypes = propTypes4;
var Line = (props)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LineChart, __spreadValues(__spreadValues({}, defaultProps.Line), props));
_c15 = Line;
var Slope = (props)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(LineChart, __spreadValues(__spreadValues({}, defaultProps.Slope), props));
_c16 = Slope;
Slope.base = "Line";
;
;
;
;
;
;
var scales = {
    linear: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"],
    log: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$log$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLog$3e$__["scaleLog"]
};
var tickAccessor = (d)=>d.tick;
var aggregateValues = (data, accessor, xTicks = [], xLines = [])=>data.map(accessor).concat(xTicks).concat(xLines.map(tickAccessor));
var getNice = (nice, plotDimension)=>nice === void 0 ? Math.min(Math.max(Math.round(plotDimension / 150), 3), 5) : nice;
var getPlot = (scale, values, range3, nice, plotDimension)=>{
    const plotScale = scales[scale]().domain((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$extent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__extent$3e$__["extent"])(values)).range(range3);
    const niceValue = getNice(nice, plotDimension);
    if (niceValue) {
        plotScale.nice(niceValue);
    }
    return plotScale;
};
;
;
;
;
;
;
;
;
;
;
// src/theme/mediaQueries.js
var mediaQueries_exports = {};
__export(mediaQueries_exports, {
    lBreakPoint: ()=>lBreakPoint,
    lUp: ()=>lUp,
    mBreakPoint: ()=>mBreakPoint,
    mDown: ()=>mDown,
    mUp: ()=>mUp,
    mUpAndPrint: ()=>mUpAndPrint,
    onlyS: ()=>onlyS,
    sBreakPoint: ()=>sBreakPoint,
    sDown: ()=>sDown
});
var sBreakPoint = 375;
var mBreakPoint = 768;
var lBreakPoint = 1025;
var onlyS = `@media only screen and (max-width: ${mBreakPoint - 1}px)`;
var mUp = `@media only screen and (min-width: ${mBreakPoint}px)`;
var mUpAndPrint = `@media only screen and (min-width: ${mBreakPoint}px), print`;
var mDown = `@media only screen and (min-width: ${mBreakPoint - 1}px)`;
var lUp = `@media only screen and (min-width: ${lBreakPoint}px)`;
var sDown = `@media only screen and (max-width: ${sBreakPoint - 1}px)`;
// src/components/Typography/Editorial.tsx
var Editorial_exports = {};
__export(Editorial_exports, {
    A: ()=>A,
    Answer: ()=>Answer,
    Credit: ()=>Credit,
    Cursive: ()=>Cursive,
    Emphasis: ()=>Emphasis,
    Format: ()=>Format,
    Headline: ()=>Headline,
    LI: ()=>ListItem,
    Lead: ()=>Lead,
    List: ()=>List,
    Note: ()=>Note,
    OL: ()=>OrderedList,
    P: ()=>P,
    Question: ()=>Question,
    StrikeThrough: ()=>StrikeThrough,
    Subhead: ()=>Subhead,
    Subject: ()=>Subject,
    UL: ()=>UnorderedList,
    fontRule: ()=>editorialFontRule,
    link: ()=>link
});
;
;
;
var editorialFontRule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, fontStyles.serifRegular), {
    "& em, & i": fontStyles.serifItalic,
    "& strong, & b": fontStyles.serifBold,
    "& strong em, & em strong, & b i, & i b": fontStyles.serifBoldItalic
}));
var interactionFontRule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    "& em, & i": fontStyles.sansSerifItalic,
    "& strong, & b": fontStyles.sansSerifMedium,
    "& strong em, & em strong, & b i, & i b": {
        textDecoration: `underline wavy ${colors_default.error}`
    }
}));
// src/components/Typography/utils.ts
var DEFAULT_FONT_SIZE = 16;
function pxToRem(pxSize) {
    if (typeof pxSize === "number") {
        return `${pxSize / DEFAULT_FONT_SIZE}rem`;
    }
    return pxSize && `${parseInt(pxSize, 10) / DEFAULT_FONT_SIZE}rem`;
}
function convertStyleToRem(cssRules) {
    return __spreadProps(__spreadValues({}, cssRules), {
        fontSize: pxToRem(cssRules.fontSize),
        lineHeight: pxToRem(cssRules.lineHeight)
    });
}
;
;
var LIST_PADDING = 22;
var MARGIN = 8;
var styles8 = {
    unorderedList: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        margin: "1em 0",
        paddingLeft: 0,
        listStyle: "none",
        "& > li:before": {
            content: "\u2013",
            position: "absolute",
            left: 0
        }
    }),
    orderedList: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        paddingLeft: "1.7em",
        "& > li": {
            paddingLeft: `${MARGIN}px`
        }
    }),
    li: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({
        paddingLeft: `${LIST_PADDING}px`,
        position: "relative"
    }, convertStyleToRem(serifRegular17)), {
        [mUp]: __spreadValues({}, convertStyleToRem(serifRegular19)),
        "& p": {
            margin: "1em 0 1em 0"
        },
        "& p:last-child": {
            marginBottom: 0
        },
        "li &": __spreadProps(__spreadValues({}, convertStyleToRem(serifRegular14)), {
            lineHeight: pxToRem("22px"),
            margin: "12px 0",
            [mUp]: __spreadProps(__spreadValues({}, convertStyleToRem(serifRegular17)), {
                lineHeight: pxToRem("28px"),
                margin: "14px 0"
            })
        })
    }))
};
var unorderedListCompactStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["merge"])(styles8.unorderedList, {
    "& li, & li p": {
        margin: 0
    }
});
var orderedListCompactStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["merge"])(styles8.orderedList, {
    "& li, & li p": {
        margin: 0
    }
});
var UnorderedList = ({ children, attributes, compact })=>{
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("ul", __spreadProps(__spreadValues(__spreadValues({}, attributes), compact ? unorderedListCompactStyle : styles8.unorderedList), {
        children
    }));
};
_c17 = UnorderedList;
var OrderedList = ({ children, attributes, start = 1, compact })=>{
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("ol", __spreadProps(__spreadValues(__spreadValues({
        start
    }, attributes), compact ? orderedListCompactStyle : styles8.orderedList), {
        style: __spreadValues({
            listStyleType: "decimal",
            marginBlock: "1em 0",
            paddingInlineStart: 40
        }, attributes == null ? void 0 : attributes.style),
        children
    }));
};
_c18 = OrderedList;
var ListItem = ({ children, attributes = {}, style = {} })=>{
    _s11();
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("li", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, styles8.li), editorialFontRule), colorScheme.set("color", "text")), attributes), {
        style,
        children
    }));
};
_s11(ListItem, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c19 = ListItem;
var List = ({ children, data, attributes = {} })=>{
    if (data.ordered) {
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(OrderedList, {
            attributes,
            start: data.start,
            compact: data.compact,
            children
        });
    }
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(UnorderedList, {
        attributes,
        compact: data.compact,
        children
    });
};
_c20 = List;
;
var headline = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(serifTitle30)), {
    margin: "0 0 12px 0",
    [mUp]: __spreadProps(__spreadValues({}, convertStyleToRem(serifTitle58)), {
        margin: "0 0 12px 0"
    }),
    ":first-child": {
        marginTop: 0
    },
    ":last-child": {
        marginBottom: 0
    }
}));
var Headline = (_a)=>{
    _s12();
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h1", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, attributes), props), headline), colorScheme.set("color", "text")), {
        children
    }));
};
_s12(Headline, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c21 = Headline;
var subhead = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(serifBold19)), {
    margin: "36px 0 8px 0",
    [mUp]: __spreadProps(__spreadValues({}, convertStyleToRem(serifBold24)), {
        margin: "46px 0 12px 0"
    }),
    ":first-child": {
        marginTop: 0
    },
    ":last-child": {
        marginBottom: 0
    }
}));
var Subhead = (_a)=>{
    _s13();
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h2", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, attributes), props), subhead), colorScheme.set("color", "text")), {
        children
    }));
};
_s13(Subhead, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c22 = Subhead;
var lead = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(serifRegular19)), {
    display: "inline",
    margin: "0 0 10px 0",
    [mUp]: __spreadProps(__spreadValues({}, convertStyleToRem(serifRegular23)), {
        margin: "0 0 20px 0"
    })
}));
var Lead = (_a)=>{
    _s14();
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, attributes), props), lead), colorScheme.set("color", "text")), editorialFontRule), {
        children
    }));
};
_s14(Lead, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c23 = Lead;
var subjectStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({
    color: "#8c8c8c",
    display: "inline",
    margin: 0,
    "&::after": {
        content: " "
    }
}, convertStyleToRem(sansSerifRegular19)), {
    [mUp]: __spreadProps(__spreadValues({}, convertStyleToRem(sansSerifRegular23)), {
        lineHeight: "27px"
    })
}));
var Subject = (_a)=>{
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h2", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, attributes), props), subjectStyle), {
        children
    }));
};
_c24 = Subject;
var credit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({
    margin: "10px 0 0 0"
}, convertStyleToRem(sansSerifRegular14)), {
    [mUp]: __spreadProps(__spreadValues({}, convertStyleToRem(sansSerifRegular15)), {
        margin: "20px 0 0 0"
    })
}));
var Credit = (_a)=>{
    _s15();
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, attributes), props), credit), colorScheme.set("color", "text")), {
        children
    }));
};
_s15(Credit, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c25 = Credit;
var format = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(sansSerifMedium16)), {
    margin: "0 0 18px 0",
    [mUp]: __spreadProps(__spreadValues({}, convertStyleToRem(sansSerifMedium20)), {
        margin: "0 0 28px 0"
    })
}));
var Format = (_a)=>{
    _s16();
    var _b = _a, { children, color, attributes } = _b, props = __objRest(_b, [
        "children",
        "color",
        "attributes"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, attributes), props), format), colorScheme.set("color", color, "format")), {
        children
    }));
};
_s16(Format, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c26 = Format;
var paragraph = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({
    margin: "22px 0 22px 0"
}, convertStyleToRem(serifRegular17)), {
    [mUp]: __spreadProps(__spreadValues({}, convertStyleToRem(serifRegular19)), {
        margin: `${pxToRem(30)} 0 ${pxToRem(30)} 0`
    }),
    ":first-child": {
        marginTop: 0
    },
    "&.no-margin-top": {
        marginTop: -22,
        [mUp]: {
            marginTop: `-${pxToRem(30)}`
        }
    },
    ":last-child": {
        marginBottom: 0
    },
    "h2 + &": {
        marginTop: 0
    }
}));
var P = (_a)=>{
    _s17();
    var _b = _a, { children, attributes, noMarginTop, isEmpty } = _b, props = __objRest(_b, [
        "children",
        "attributes",
        "noMarginTop",
        "isEmpty"
    ]);
    const [colorScheme] = useColorContext();
    if (isEmpty) return null;
    const className = [
        attributes == null ? void 0 : attributes.className,
        noMarginTop && "no-margin-top"
    ].filter(Boolean).join(" ");
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues(__spreadProps(__spreadValues({}, attributes), {
        className
    }), props), paragraph), colorScheme.set("color", "text")), editorialFontRule), {
        children
    }));
};
_s17(P, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c27 = P;
var question = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(serifBold17)), {
    margin: "36px 0 -14px 0",
    [mUp]: __spreadProps(__spreadValues({}, convertStyleToRem(serifBold19)), {
        lineHeight: "30px",
        margin: "46px 0 -18px 0"
    })
}));
var Question = (_a)=>{
    _s18();
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, attributes), props), question), colorScheme.set("color", "text")), editorialFontRule), {
        children
    }));
};
_s18(Question, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c28 = Question;
var Answer = P;
var emphasis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(fontStyles.serifBold);
var Emphasis = (_a)=>{
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("strong", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, attributes), props), emphasis), {
        children
    }));
};
_c29 = Emphasis;
var cursive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(fontStyles.serifItalic);
var Cursive = (_a)=>{
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("em", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, attributes), props), cursive), {
        children
    }));
};
_c30 = Cursive;
var strikeThrough = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
    textDecoration: "line-through"
});
var StrikeThrough = (_a)=>{
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, attributes), props), strikeThrough), {
        children
    }));
};
_c31 = StrikeThrough;
var link = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, underline), {
    cursor: "pointer"
}));
var A = /*#__PURE__*/ _s19(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c32 = _s19((_a, ref)=>{
    _s19();
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    const [colorScheme] = useColorContext();
    const hoverRule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "A.useMemo3[hoverRule]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                "@media (hover)": {
                    ":hover": {
                        color: colorScheme.getCSSColor("textSoft")
                    }
                }
            })
    }["A.useMemo3[hoverRule]"], [
        colorScheme
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("a", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, colorScheme.set("color", "text")), attributes), props), link), hoverRule), {
        ref,
        children
    }));
}, "JhgkLODa8NoPUKcNAuRp/KCDewk=", false, function() {
    return [
        useColorContext,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]
    ];
})), "JhgkLODa8NoPUKcNAuRp/KCDewk=", false, function() {
    return [
        useColorContext,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]
    ];
});
_c33 = A;
var note = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(sansSerifRegular12)), {
    margin: "22px 0",
    [mUp]: __spreadProps(__spreadValues({}, convertStyleToRem(sansSerifRegular15)), {
        margin: "30px 0"
    })
}));
var Note = (_a)=>{
    _s20();
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, attributes), props), note), colorScheme.set("color", "text")), interactionFontRule), {
        children
    }));
};
_s20(Note, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c34 = Note;
// src/components/Typography/Interaction.tsx
var Interaction_exports = {};
__export(Interaction_exports, {
    Cursive: ()=>Cursive2,
    Emphasis: ()=>Emphasis2,
    H1: ()=>H1,
    H2: ()=>H2,
    H3: ()=>H3,
    Headline: ()=>Headline2,
    P: ()=>P2,
    fontRule: ()=>interactionFontRule
});
;
;
var interactionHeadline = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({
    margin: "0 0 12px 0"
}, convertStyleToRem(sansSerifMedium30)), {
    [mUp]: __spreadValues({}, convertStyleToRem(sansSerifMedium58)),
    ":first-child": {
        marginTop: 0
    },
    ":last-child": {
        marginBottom: 0
    }
}));
var interactionH1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(sansSerifMedium30)), {
    [mUp]: __spreadValues({}, convertStyleToRem(sansSerifMedium40)),
    margin: 0
}));
var interactionH2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(sansSerifMedium22)), {
    [mUp]: __spreadValues({}, convertStyleToRem(sansSerifMedium30)),
    margin: 0
}));
var interactionH3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(sansSerifMedium19)), {
    [mUp]: __spreadValues({}, convertStyleToRem(sansSerifMedium22)),
    margin: 0
}));
var Headline2 = (_a)=>{
    _s21();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h1", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, props), interactionHeadline), colorScheme.set("color", "text")), {
        children
    }));
};
_s21(Headline2, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c35 = Headline2;
var H1 = (_a)=>{
    _s22();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h1", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, props), interactionH1), colorScheme.set("color", "text")), {
        children
    }));
};
_s22(H1, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c36 = H1;
var H2 = (_a)=>{
    _s23();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h2", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, props), interactionH2), colorScheme.set("color", "text")), {
        children
    }));
};
_s23(H2, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c37 = H2;
var H3 = (_a)=>{
    _s24();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h3", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, props), interactionH3), colorScheme.set("color", "text")), {
        children
    }));
};
_s24(H3, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c38 = H3;
var interactionP = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({
    margin: 0
}, convertStyleToRem(sansSerifRegular17)), {
    [mUp]: __spreadValues({}, convertStyleToRem(sansSerifRegular21))
}));
var P2 = (_a)=>{
    _s25();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, props), interactionP), interactionFontRule), colorScheme.set("color", "text")), {
        children
    }));
};
_s25(P2, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c39 = P2;
var emphasis2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(fontStyles.sansSerifMedium);
var Emphasis2 = (_a)=>{
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("strong", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, props), attributes), emphasis2), {
        children
    }));
};
_c40 = Emphasis2;
var cursive2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(fontStyles.sansSerifItalic);
var Cursive2 = (_a)=>{
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("em", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, props), attributes), cursive2), {
        children
    }));
};
_c41 = Cursive2;
// src/components/Typography/Meta.tsx
var Meta_exports = {};
__export(Meta_exports, {
    Headline: ()=>Headline3,
    Lead: ()=>Lead2,
    P: ()=>P3,
    Subhead: ()=>Subhead2,
    fontRule: ()=>fontRule
});
;
;
var fontRule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, fontStyles.sansSerifRegular), {
    "& em, & i": fontStyles.sansSerifItalic,
    "& strong, & b": fontStyles.sansSerifMedium,
    "& strong em, & em strong, & b i, & i b": {
        textDecoration: `underline wavy ${colors_default.error}`
    },
    "& a": {
        textDecoration: "underline",
        color: "inherit"
    }
}));
var metaHeadline = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({
    margin: "0 0 12px 0"
}, convertStyleToRem(sansSerifMedium30)), {
    [mUp]: __spreadValues({}, convertStyleToRem(sansSerifMedium58)),
    ":first-child": {
        marginTop: 0
    },
    ":last-child": {
        marginBottom: 0
    }
}));
var Headline3 = (_a)=>{
    _s26();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h1", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, props), metaHeadline), colorScheme.set("color", "text")), {
        children
    }));
};
_s26(Headline3, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c42 = Headline3;
var subhead2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(sansSerifMedium19)), {
    margin: "36px 0 8px 0",
    [mUp]: __spreadProps(__spreadValues({}, convertStyleToRem(sansSerifMedium24)), {
        margin: "46px 0 12px 0"
    }),
    ":first-child": {
        marginTop: 0
    },
    ":last-child": {
        marginBottom: 0
    }
}));
var Subhead2 = (_a)=>{
    _s27();
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h2", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, attributes), props), subhead2), colorScheme.set("color", "text")), {
        children
    }));
};
_s27(Subhead2, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c43 = Subhead2;
var metaP = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({
    margin: "22px 0 22px 0"
}, convertStyleToRem(sansSerifRegular17)), {
    [mUp]: __spreadProps(__spreadValues({}, convertStyleToRem(sansSerifRegular19)), {
        margin: `${pxToRem(30)} 0 ${pxToRem(30)} 0`
    }),
    ":first-child": {
        marginTop: 0
    },
    ":last-child": {
        marginBottom: 0
    },
    "h2 + &": {
        marginTop: 0
    }
}));
var P3 = (_a)=>{
    _s28();
    var _b = _a, { isEmpty, children } = _b, props = __objRest(_b, [
        "isEmpty",
        "children"
    ]);
    const [colorScheme] = useColorContext();
    if (isEmpty) return null;
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, props), metaP), fontRule), colorScheme.set("color", "text")), {
        children
    }));
};
_s28(P3, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c44 = P3;
var lead2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(sansSerifRegular19)), {
    display: "inline",
    margin: "0 0 10px 0",
    [mUp]: __spreadProps(__spreadValues({}, convertStyleToRem(sansSerifRegular23)), {
        margin: "0 0 20px 0"
    })
}));
var Lead2 = (_a)=>{
    _s29();
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, attributes), props), lead2), colorScheme.set("color", "text")), fontRule), {
        children
    }));
};
_s29(Lead2, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c45 = Lead2;
// src/components/Typography/Scribble.tsx
var Scribble_exports = {};
__export(Scribble_exports, {
    Headline: ()=>Headline4,
    LI: ()=>ListItem,
    List: ()=>List,
    OL: ()=>OrderedList,
    UL: ()=>UnorderedList
});
;
;
var headline2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(cursiveTitle30)), {
    margin: "0 0 12px 0",
    [mUp]: __spreadProps(__spreadValues({}, convertStyleToRem(cursiveTitle58)), {
        margin: "0 0 12px 0"
    }),
    ":first-child": {
        marginTop: 0
    },
    ":last-child": {
        marginBottom: 0
    }
}));
var Headline4 = (_a)=>{
    _s30();
    var _b = _a, { children, attributes } = _b, props = __objRest(_b, [
        "children",
        "attributes"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h1", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, attributes), colorScheme.set("color", "text")), props), headline2), {
        children
    }));
};
_s30(Headline4, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c46 = Headline4;
;
var Editorial = __spreadValues({}, Editorial_exports);
var Interaction = __spreadValues({}, Interaction_exports);
var Meta = __spreadValues({}, Meta_exports);
var Scribble = __spreadValues({}, Scribble_exports);
var fontStyles2 = __spreadValues(__spreadValues({}, fontStyles), styles_exports);
var linkStyle = {
    textDecoration: "none",
    color: colors_default.primary,
    "@media (hover)": {
        ":hover": {
            color: colors_default.secondary
        }
    }
};
var linkRule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(linkStyle);
var plainLinkRule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
    textDecoration: "none",
    color: "inherit"
});
var styles9 = {
    h1: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, fontStyles2.serifBold36), {
        [mUp]: __spreadValues({}, fontStyles2.serifBold52),
        margin: "30px 0 20px 0",
        ":first-child": {
            marginTop: 0
        },
        ":last-child": {
            marginBottom: 0
        }
    })),
    h2: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, fontStyles2.serifBold19), {
        [mUp]: __spreadValues({}, fontStyles2.serifBold24),
        margin: "30px 0 20px 0",
        ":first-child": {
            marginTop: 0
        },
        ":last-child": {
            marginBottom: 0
        }
    })),
    lead: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, fontStyles2.serifRegular25), {
        margin: "20px 0 20px 0"
    })),
    p: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, fontStyles2.serifRegular16), {
        [mUp]: __spreadValues({}, fontStyles2.serifRegular21),
        margin: "20px 0 20px 0",
        ":first-child": {
            marginTop: 0
        },
        ":last-child": {
            marginBottom: 0
        }
    })),
    hr: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        border: 0,
        height: 1,
        marginTop: 30,
        marginBottom: 30
    }),
    label: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, convertStyleToRem(fontStyles2.sansSerifRegular14)))
};
var A2 = /*#__PURE__*/ _s31(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c47 = _s31((_a, ref)=>{
    _s31();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    const linkStyleRule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "A2.useMemo4[linkStyleRule]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                textDecoration: "none",
                color: colorScheme.getCSSColor("primary"),
                "@media (hover)": {
                    ":hover": {
                        color: colorScheme.getCSSColor("primaryHover")
                    }
                }
            })
    }["A2.useMemo4[linkStyleRule]"], [
        colorScheme
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("a", __spreadProps(__spreadValues(__spreadValues({}, props), linkStyleRule), {
        ref,
        children
    }));
}, "4nNJqoMh9NdI6BxSi/EUftXshqg=", false, function() {
    return [
        useColorContext,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]
    ];
})), "4nNJqoMh9NdI6BxSi/EUftXshqg=", false, function() {
    return [
        useColorContext,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]
    ];
});
_c48 = A2;
var H12 = (_a)=>{
    _s32();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h1", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, props), styles9.h1), colorScheme.set("color", "text")), {
        children
    }));
};
_s32(H12, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c49 = H12;
var H22 = (_a)=>{
    _s33();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h2", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, props), styles9.h2), colorScheme.set("color", "text")), {
        children
    }));
};
_s33(H22, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c50 = H22;
var Lead3 = (_a)=>{
    _s34();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, props), styles9.lead), colorScheme.set("color", "text")), {
        children
    }));
};
_s34(Lead3, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c51 = Lead3;
var P4 = (_a)=>{
    _s35();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, props), styles9.p), colorScheme.set("color", "text")), {
        children
    }));
};
_s35(P4, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c52 = P4;
var Label = (_a)=>{
    _s36();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, props), styles9.label), colorScheme.set("color", "text")), {
        children
    }));
};
_s36(Label, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c53 = Label;
var subSupStyles = {
    base: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        display: "inline-block",
        textDecoration: "none",
        fontSize: "75%",
        lineHeight: "1.4em",
        position: "relative",
        verticalAlign: "baseline"
    }),
    sub: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        bottom: "-0.25em"
    }),
    sup: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        top: "-0.5em"
    })
};
var Sub = ({ children, attributes })=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("sub", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, attributes), subSupStyles.base), subSupStyles.sub), {
        children
    }));
_c54 = Sub;
var Sup = ({ children, attributes })=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("sup", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, attributes), subSupStyles.base), subSupStyles.sup), {
        children
    }));
_c55 = Sup;
var HR = ({ attributes })=>{
    _s37();
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("hr", __spreadValues(__spreadValues(__spreadValues(__spreadValues({}, attributes), styles9.hr), colorScheme.set("color", "divider")), colorScheme.set("backgroundColor", "divider")));
};
_s37(HR, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c56 = HR;
// src/lib/helpers.js
var intersperse = (list, separator)=>{
    if (list.length === 0) {
        return [];
    }
    return list.slice(1).reduce((items, item, i)=>{
        return items.concat([
            separator(item, i),
            item
        ]);
    }, [
        list[0]
    ]);
};
var rafDebounce = (fn)=>{
    let next;
    return (...args)=>{
        if (!next) {
            next = window.requestAnimationFrame(()=>{
                next = void 0;
                fn(...args);
            });
        }
        return next;
    };
};
var shouldIgnoreClick = (event, ignoreTarget)=>{
    const anchor = [
        event.target,
        event.currentTarget
    ].find((node)=>node.nodeName === "A");
    return !!anchor && !!(!ignoreTarget && anchor.target && anchor.target !== "_self" || event.metaKey || event.ctrlKey || event.shiftKey || event.nativeEvent && event.nativeEvent.which === 2);
};
;
var boxStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({
    position: "absolute"
}, sansSerifRegular14), {
    lineHeight: "1.1em",
    padding: "12px 16px",
    pointerEvents: "none",
    zIndex: 10,
    minWidth: 200
}));
var boxPosition = {
    top: {
        center: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            transform: "translateX(-50%) translateY(-100%)"
        }),
        left: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            transform: "translateX(-15%) translateY(-100%)"
        }),
        right: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            transform: "translateX(-85%) translateY(-100%)"
        })
    },
    below: {
        center: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            transform: "translateX(-50%) translateY(0)"
        }),
        left: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            transform: "translateX(-15%) translateY(0)"
        }),
        right: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            transform: "translateX(-85%) translateY(0)"
        })
    }
};
var notchStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
    position: "absolute",
    width: 0,
    height: 0,
    borderStyle: "solid",
    borderWidth: "8px 7.5px 0 7.5px",
    borderColor: "transparent"
});
var notchPosition = {
    top: {
        center: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            bottom: -8,
            transform: "translateX(-50%)",
            left: "50%"
        }),
        left: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            bottom: -8,
            transform: "translateX(-50%)",
            left: "15%"
        }),
        right: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            bottom: -8,
            transform: "translateX(50%)",
            right: "15%"
        })
    },
    below: {
        center: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            top: -8,
            transform: "translateX(-50%) rotate(180deg)",
            left: "50%"
        }),
        left: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            top: -8,
            transform: "translateX(-50%) rotate(180deg)",
            left: "15%"
        }),
        right: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
            top: -8,
            transform: "translateX(50%) rotate(180deg)",
            right: "15%"
        })
    }
};
var labeledValueStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
    fontSize: 14,
    lineHeight: "20px",
    borderBottomWidth: 1,
    borderBottomStyle: "solid",
    paddingBottom: 10,
    marginBottom: 5,
    ":last-child": {
        borderBottom: "none",
        paddingBottom: 5,
        marginBottom: 0
    }
});
var formatLines = (text)=>{
    return text.split("\n").map((d, i)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: subsup(d)
        }, `d${i}`));
};
var mergeFragments = (fragments)=>intersperse(fragments, (item, index)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("br", {}, `br${index}`));
var ContextBoxValue = ({ label, children })=>{
    _s38();
    const [colorScheme] = useColorContext();
    if (!children) {
        return null;
    }
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, labeledValueStyle), Interaction.fontRule), colorScheme.set("color", "text")), colorScheme.set("borderColor", "divider")), {
        children: [
            !!label && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("strong", {
                        children: label
                    }),
                    /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("br", {})
                ]
            }),
            children
        ]
    }));
};
_s38(ContextBoxValue, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c57 = ContextBoxValue;
ContextBoxValue.propTypes = {
    label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    children: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node
};
var ContextBox = ({ orientation: yOrientation = "top", x, y, contextWidth, children })=>{
    _s39();
    const maxWidth = Math.min(400, contextWidth);
    let xOrientation = "center";
    if (contextWidth - x < maxWidth / 2) {
        xOrientation = "right";
    } else if (x < maxWidth / 2) {
        xOrientation = "left";
    }
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, boxStyle), colorScheme.set("color", "text")), colorScheme.set("backgroundColor", "overlay")), colorScheme.set("boxShadow", "overlayShadow")), {
        className: boxPosition[yOrientation][xOrientation],
        style: {
            left: x,
            top: y,
            maxWidth
        },
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                children
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", __spreadProps(__spreadValues(__spreadValues({}, notchStyle), colorScheme.set("borderTopColor", "overlay")), {
                className: notchPosition[yOrientation][xOrientation]
            }))
        ]
    }));
};
_s39(ContextBox, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c58 = ContextBox;
ContextBox.propTypes = {
    x: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    y: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    contextWidth: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    orientation: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        "top",
        "below"
    ]),
    children: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node
};
var ContextBox_default = ContextBox;
// src/lib/translate.ts
var replaceKeys = (message, replacements)=>{
    let withReplacements = message;
    Object.keys(replacements).forEach((replacementKey)=>{
        withReplacements = withReplacements.replace(`{${replacementKey}}`, replacements[replacementKey]);
    });
    return withReplacements;
};
var createPlaceholderFormatter = (placeholder = "")=>{
    const formatter = ()=>placeholder;
    formatter.elements = ()=>[
            placeholder
        ];
    formatter.first = formatter;
    formatter.first.elements = formatter.elements;
    formatter.pluralize = formatter;
    formatter.pluralize.elements = formatter.elements;
    return formatter;
};
var createFormatter = (translations)=>{
    const index = translations.reduce((accumulator, translation)=>{
        accumulator[translation.key] = translation.value;
        return accumulator;
    }, {});
    const formatter = function(key, replacements, missingValue) {
        let message = index[key] || (missingValue !== void 0 ? missingValue : `TK(${key})`);
        if (replacements) {
            message = replaceKeys(message, replacements);
        }
        return message;
    };
    const firstKey = (keys)=>keys.find((k)=>index[k] !== void 0) || keys[keys.length - 1];
    const pluralizationKeys = (baseKey, replacements)=>[
            `${baseKey}/${replacements.count}`,
            `${baseKey}/other`
        ];
    formatter.first = (keys, replacements, missingValue)=>{
        return formatter(firstKey(keys), replacements, missingValue);
    };
    formatter.pluralize = (baseKey, replacements, missingValue)=>{
        return formatter.first(pluralizationKeys(baseKey, replacements), replacements, missingValue);
    };
    const createReplacementReducer = (replacements)=>(r, part)=>{
            if (part[0] === "{") {
                r.push(replacements[part.slice(1, -1)] || "");
            } else {
                r.push(part);
            }
            return r;
        };
    formatter.elements = (key, replacements, missingValue)=>{
        return formatter(key, void 0, missingValue).split(/(\{[^{}]+\})/g).filter(Boolean).reduce(createReplacementReducer(replacements), []);
    };
    formatter.first.elements = (keys, replacements, missingValue)=>{
        return formatter.elements(firstKey(keys), replacements, missingValue);
    };
    formatter.pluralize.elements = (baseKey, replacements, missingValue)=>{
        return formatter.first.elements(pluralizationKeys(baseKey, replacements), replacements, missingValue);
    };
    return formatter;
};
;
var Box = ({ width, height, xFormat, yFormat, hover, hoverTouch, tooltipLabel, tooltipBody, label, yShowValue, xShowValue, sizeShowValue, detail, yUnit, xUnit, sizeUnit, sizeFormat })=>{
    if (!hover.length) {
        return null;
    }
    const { cx, cy, r } = hover.sort((a, b)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$ascending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ascending$3e$__["ascending"])(a.cy, b.cy))[0];
    const top = hoverTouch || cy > height / 3;
    const yOffset = r + (hoverTouch ? 40 : 12);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ContextBox_default, {
        orientation: top ? "top" : "below",
        x: cx,
        y: cy + (top ? -yOffset : yOffset),
        contextWidth: width,
        children: hover.map(({ value }, i)=>{
            const replacements = __spreadProps(__spreadValues({}, value.datum), {
                y: value.y,
                x: value.x,
                size: value.size,
                formattedY: yFormat(value.y),
                formattedX: xFormat(value.x),
                formattedSize: sizeFormat(value.size)
            });
            const contextT = (text)=>replaceKeys(text, replacements);
            return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ContextBoxValue, {
                label: tooltipLabel ? contextT(tooltipLabel) : value.datum[label],
                children: mergeFragments(tooltipBody ? formatLines(contextT(tooltipBody)) : [
                    value.datum[detail],
                    yShowValue && `${replacements.formattedY} ${yUnit}`,
                    xShowValue && `${replacements.formattedX} ${xUnit}`,
                    sizeShowValue && `${replacements.formattedSize} ${sizeUnit}`
                ].filter(Boolean).map(formatLines))
            }, `${value.datum[label]}${i}`);
        })
    });
};
_c59 = Box;
var ScatterPlotContextBox_default = Box;
;
;
;
var styles10 = {
    inlineLabel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifMedium12)),
    inlineSecondaryLabel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifRegular12))
};
var InlineLabel = ({ symbol: symbol2, inlineLabel, inlineSecondaryLabel, inlineLabelPosition })=>{
    _s40();
    const [colorScheme] = useColorContext();
    const { datum } = symbol2.value;
    const primary = datum[inlineLabel];
    const secondary = datum[inlineSecondaryLabel];
    const pos = datum[inlineLabelPosition] || "center";
    let textAnchor = "middle";
    let yOffset = 0;
    let xOffset = 0;
    if (pos === "left") {
        textAnchor = "end";
        xOffset = -(symbol2.r + 5);
    }
    if (pos === "right") {
        textAnchor = "start";
        xOffset = symbol2.r + 5;
    }
    if (pos === "top" || pos === "bottom") {
        yOffset = symbol2.r + 5 + (primary && secondary ? 15 : 7);
        if (pos === "top") {
            yOffset = -yOffset;
        }
    }
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
        textAnchor,
        transform: `translate(${symbol2.cx + xOffset},${symbol2.cy + yOffset})`,
        children: [
            primary && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles10.inlineLabel), colorScheme.set("fill", "text")), {
                dy: secondary ? "-0.3em" : "0.4em",
                children: subsup.svg(primary)
            })),
            secondary && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles10.inlineSecondaryLabel), colorScheme.set("fill", "text")), {
                dy: primary ? "0.9em" : "0.4em",
                children: subsup.svg(secondary)
            }))
        ]
    });
};
_s40(InlineLabel, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c60 = InlineLabel;
;
;
var ScatterPlotCanvas = ({ symbols, width, height, getColor, opacity })=>{
    _s41();
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ScatterPlotCanvas.useEffect": ()=>{
            const canvas = canvasRef.current;
            const devicePixelRatio = window.devicePixelRatio || 1;
            canvas.width = width * devicePixelRatio;
            canvas.height = height * devicePixelRatio;
            const ctx = canvas.getContext("2d");
            ctx.save();
            ctx.scale(devicePixelRatio, devicePixelRatio);
            ctx.clearRect(0, 0, width, height);
            ctx.globalAlpha = opacity;
            symbols.forEach({
                "ScatterPlotCanvas.useEffect": ({ cx, cy, r, value })=>{
                    ctx.beginPath();
                    ctx.moveTo(cx + r, cy);
                    ctx.arc(cx, cy, r, 0, 2 * Math.PI);
                    ctx.fillStyle = getColor(value);
                    ctx.fill();
                }
            }["ScatterPlotCanvas.useEffect"]);
            ctx.restore();
        }
    }["ScatterPlotCanvas.useEffect"], [
        symbols,
        width,
        height,
        opacity,
        getColor
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("canvas", {
        ref: canvasRef,
        style: {
            position: "absolute",
            top: 0,
            left: 0,
            width,
            height
        }
    });
};
_s41(ScatterPlotCanvas, "UJgi7ynoup7eqypjnwyX/s32POg=");
_c61 = ScatterPlotCanvas;
var ScatterPlotCanvas_default = ScatterPlotCanvas;
;
var X_TICK_HEIGHT2 = 6;
var styles11 = {
    columnTitle: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifMedium14)),
    axisLabel: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifRegular12)),
    axisLine: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        strokeWidth: "1px",
        shapeRendering: "crispEdges"
    }),
    annotationLine: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        strokeWidth: "1px",
        fillRule: "evenodd",
        strokeLinecap: "round",
        strokeDasharray: "1,3",
        strokeLinejoin: "round"
    }),
    annotationText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifRegular12))
};
var ScatterPlotGroup = ({ values, plotX, plotY, rSize, description, title, inlineLabel, inlineSecondaryLabel, inlineLabelPosition, plotXLines, plotYLines, opacity, width, height, paddingTop, paddingLeft, paddingRight, paddingBottom, yLinesPaddingLeft, xAxis, yAxis, maxYLine, getColor, xUnit, annotations, contextBoxProps, allowCanvasRendering })=>{
    _s42();
    const [hover, setHover] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [hoverTouch, setHoverTouch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    const hoverRectRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    const [colorScheme] = useColorContext();
    const plotHeight = height + paddingBottom + paddingTop;
    const plotWidth = width + paddingLeft + paddingRight;
    const symbols = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ScatterPlotGroup.useMemo5[symbols]": ()=>values.map({
                "ScatterPlotGroup.useMemo5[symbols]": (value, i)=>{
                    return {
                        key: `symbol${i}`,
                        value,
                        cx: plotX(value.x),
                        cy: plotY(value.y),
                        r: rSize(value.size)
                    };
                }
            }["ScatterPlotGroup.useMemo5[symbols]"])
    }["ScatterPlotGroup.useMemo5[symbols]"], [
        values,
        plotX,
        plotY,
        rSize
    ]);
    const focusRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    const focus = focusRef.current = (event)=>{
        if (!symbols) {
            return;
        }
        const { left, top } = containerRef.current.getBoundingClientRect();
        let hoverTouchItem = false;
        let currentEvent = event;
        if (currentEvent.changedTouches) {
            hoverTouchItem = true;
            currentEvent = currentEvent.changedTouches[0];
        }
        const focusX = currentEvent.clientX - left;
        const focusY = currentEvent.clientY - top;
        const withDistance = symbols.map((symbol2)=>{
            return {
                symbol: symbol2,
                distance: Math.sqrt(Math.pow(symbol2.cx - focusX, 2) + Math.pow(symbol2.cy - focusY, 2)) - symbol2.r
            };
        });
        let hoverItems = withDistance.filter(({ distance })=>distance < 1);
        if (hoverItems.length === 0) {
            const minDistance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$min$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__min$3e$__["min"])(withDistance, (d)=>d.distance);
            if (minDistance < 10) {
                hoverItems = withDistance.filter(({ distance })=>distance === minDistance);
            }
        }
        if (hoverItems.length) {
            event.preventDefault();
        }
        hoverItems = hoverItems.map(({ symbol: symbol2 })=>symbol2);
        setHover(hoverItems);
        setHoverTouch(hoverTouchItem);
    };
    const blur = ()=>{
        setHover([]);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ScatterPlotGroup.useEffect2": ()=>{
            const focusCallback = {
                "ScatterPlotGroup.useEffect2.focusCallback": (event)=>focusRef.current(event)
            }["ScatterPlotGroup.useEffect2.focusCallback"];
            const blurCallback = {
                "ScatterPlotGroup.useEffect2.blurCallback": ()=>{
                    setHover([]);
                }
            }["ScatterPlotGroup.useEffect2.blurCallback"];
            const rect = hoverRectRef.current;
            rect.addEventListener("touchstart", focusCallback, {
                passive: false
            });
            rect.addEventListener("touchmove", focusCallback);
            rect.addEventListener("touchend", blurCallback);
            return ({
                "ScatterPlotGroup.useEffect2": ()=>{
                    rect.removeEventListener("touchstart", focusCallback, {
                        passive: false
                    });
                    rect.removeEventListener("touchmove", focusCallback);
                    rect.removeEventListener("touchend", blurCallback);
                }
            })["ScatterPlotGroup.useEffect2"];
        }
    }["ScatterPlotGroup.useEffect2"], []);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        ref: containerRef,
        style: {
            position: "relative"
        },
        children: [
            allowCanvasRendering && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ScatterPlotCanvas_default, {
                opacity,
                symbols,
                getColor,
                width: plotWidth,
                height: plotHeight
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
                width: plotWidth,
                height: plotHeight,
                style: {
                    position: "relative"
                },
                children: [
                    /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("desc", {
                        children: description
                    }),
                    title && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({
                        dy: "1.5em"
                    }, styles11.columnTitle), colorScheme.set("fill", "text")), {
                        children: title
                    })),
                    !allowCanvasRendering && symbols.map((symbol2)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", __spreadProps(__spreadValues({
                            fillOpacity: opacity
                        }, colorScheme.set("fill", getColor(symbol2.value), "charts")), {
                            cx: symbol2.cx,
                            cy: symbol2.cy,
                            r: symbol2.r
                        }), symbol2.key)),
                    (inlineLabel || inlineSecondaryLabel) && symbols.filter(({ value: { datum } })=>datum[inlineLabel] || datum[inlineSecondaryLabel]).map((symbol2)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(InlineLabel, {
                                symbol: symbol2,
                                inlineLabel,
                                inlineSecondaryLabel,
                                inlineLabelPosition
                            })
                        }, `inlineLabel${symbol2.key}`)),
                    hover.map((symbol2)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", __spreadProps(__spreadValues({
                            fill: "none"
                        }, colorScheme.set("stroke", "text")), {
                            cx: symbol2.cx,
                            cy: symbol2.cy,
                            r: symbol2.r
                        }), `hover${symbol2.key}`)),
                    plotYLines.map(({ tick, label, base }, i)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                            "data-axis": true,
                            transform: `translate(${yLinesPaddingLeft},${plotY(tick)})`,
                            children: [
                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", __spreadProps(__spreadValues(__spreadValues({}, styles11.axisLine), colorScheme.set("stroke", "text")), {
                                    x2: width + paddingLeft - yLinesPaddingLeft,
                                    style: {
                                        opacity: base || base === void 0 && tick === 0 ? 0.8 : 0.17
                                    }
                                })),
                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles11.axisLabel), colorScheme.set("fill", "text")), {
                                    dy: "-3px",
                                    children: subsup.svg(label != null ? label : yAxis.axisFormat(tick, last(plotYLines, i)))
                                }))
                            ]
                        }, tick)),
                    plotXLines.map(({ tick, label, textAnchor, base }, i)=>{
                        if (!textAnchor) {
                            textAnchor = "middle";
                            if (last(plotXLines, i)) {
                                textAnchor = "end";
                            }
                            if (i === 0 && paddingLeft < 20) {
                                textAnchor = "start";
                            }
                        }
                        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                            "data-axis": true,
                            transform: `translate(${plotX(tick)},${paddingTop + height + X_TICK_HEIGHT2})`,
                            children: [
                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", __spreadProps(__spreadValues(__spreadValues({}, styles11.axisLine), colorScheme.set("stroke", "text")), {
                                    y2: -((maxYLine ? plotY(plotY.domain()[0]) - plotY(maxYLine.tick) : height) + X_TICK_HEIGHT2),
                                    style: {
                                        opacity: base || base === void 0 && tick === 0 ? 0.8 : 0.17
                                    }
                                })),
                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles11.axisLabel), colorScheme.set("fill", "text")), {
                                    y: 5,
                                    dy: "0.6em",
                                    textAnchor,
                                    children: subsup.svg(label != null ? label : xAxis.axisFormat(tick, last(plotXLines, i)))
                                }))
                            ]
                        }, `x${tick}`);
                    }),
                    /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({
                        x: width + paddingLeft,
                        y: paddingTop + height + 28 + X_TICK_HEIGHT2,
                        textAnchor: "end"
                    }, styles11.axisLabel), colorScheme.set("fill", "text")), {
                        children: xUnit
                    })),
                    annotations.map((annotation, i)=>{
                        const x1 = plotX(annotation.x1);
                        const x2 = plotX(annotation.x2);
                        const y1 = plotY(annotation.y1);
                        const y2 = plotY(annotation.y2);
                        const xSortedPoints = [
                            [
                                x1,
                                y1
                            ],
                            [
                                x2,
                                y2
                            ]
                        ].sort((a, b)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$ascending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ascending$3e$__["ascending"])(a[0], b[0]));
                        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", __spreadValues(__spreadValues({
                                    x1,
                                    x2,
                                    y1,
                                    y2
                                }, styles11.annotationLine), colorScheme.set("stroke", "text"))),
                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", __spreadValues(__spreadValues({
                                    r: "3.5",
                                    cx: x1,
                                    cy: y1
                                }, colorScheme.set("stroke", "text")), colorScheme.set("fill", "textInverted"))),
                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", __spreadValues(__spreadValues({
                                    r: "3.5",
                                    cx: x2,
                                    cy: y2
                                }, colorScheme.set("stroke", "text")), colorScheme.set("fill", "textInverted"))),
                                annotation.label && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({
                                    x: x1 + (x2 - x1) / 2,
                                    y: y1 + (y2 - y1) / 2,
                                    textAnchor: "start",
                                    dy: xSortedPoints[0][1] > xSortedPoints[1][1] ? "1.2em" : "-0.4em"
                                }, styles11.annotationText), colorScheme.set("fill", "text")), {
                                    children: subsup.svg(annotation.label)
                                }))
                            ]
                        }, `a${i}`);
                    }),
                    /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
                        fill: "transparent",
                        width: plotWidth,
                        height: plotHeight,
                        onMouseEnter: (e)=>focus(e),
                        onMouseMove: (e)=>focus(e),
                        onMouseLeave: (e)=>blur(e),
                        ref: /* touch events are added via ref for { passive: false } on touchstart
                 * react does not support setting passive, which defaults to true in newer browsers
                 * https://github.com/facebook/react/issues/6436
                 */ hoverRectRef
                    })
                ]
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ScatterPlotContextBox_default, __spreadValues({
                width: plotWidth,
                height: plotHeight,
                xFormat: xAxis.format,
                yFormat: yAxis.format,
                hover,
                hoverTouch
            }, contextBoxProps))
        ]
    });
};
_s42(ScatterPlotGroup, "0S8/GaPeeNs9NKx4hcbrDeCw3mo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"],
        useColorContext,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]
    ];
});
_c62 = ScatterPlotGroup;
var ScatterPlotGroup_default = ScatterPlotGroup;
;
var COLUMN_PADDING3 = 28;
var COLUMN_TITLE_HEIGHT3 = 24;
var ScatterPlot = (_a)=>{
    var _b = _a, { values, width, height: userHeight, heightRatio, x, xUnit, xNice, xTicks, xLines, xScale, xNumberFormat, xShowValue, y, yUnit, yNice, yTicks, yLines, yScale, yNumberFormat, yShowValue, numberFormat, opacity, color, colorLegend, colorLegendValues, colorRange, colorRanges, colorMap, colorSort, colorDarkMapping, pointSize, sizeRangeMax, sizeUnit, sizeNumberFormat, sizeShowValue, label, inlineLabel, inlineLabelPosition, inlineSecondaryLabel, detail, tLabel, description, paddingTop, paddingRight, paddingBottom, paddingLeft, tooltipLabel, tooltipBody, column, columnSort, columnFilter, columns, minInnerWidth, annotations, allowCanvasRendering } = _b, props = __objRest(_b, [
        "values",
        "width",
        "height",
        "heightRatio",
        "x",
        "xUnit",
        "xNice",
        "xTicks",
        "xLines",
        "xScale",
        "xNumberFormat",
        "xShowValue",
        "y",
        "yUnit",
        "yNice",
        "yTicks",
        "yLines",
        "yScale",
        "yNumberFormat",
        "yShowValue",
        "numberFormat",
        "opacity",
        "color",
        "colorLegend",
        "colorLegendValues",
        "colorRange",
        "colorRanges",
        "colorMap",
        "colorSort",
        "colorDarkMapping",
        "pointSize",
        "sizeRangeMax",
        "sizeUnit",
        "sizeNumberFormat",
        "sizeShowValue",
        "label",
        "inlineLabel",
        "inlineLabelPosition",
        "inlineSecondaryLabel",
        "detail",
        "tLabel",
        "description",
        "paddingTop",
        "paddingRight",
        "paddingBottom",
        "paddingLeft",
        "tooltipLabel",
        "tooltipBody",
        "column",
        "columnSort",
        "columnFilter",
        "columns",
        "minInnerWidth",
        "annotations",
        "allowCanvasRendering"
    ]);
    const data = values.filter((d)=>d[x] && d[x].length > 0 && d[y] && d[y].length > 0).map((d)=>{
        const sizeDataColumn = pointSize || props.size || "size";
        const dSize = d[sizeDataColumn];
        return {
            datum: d,
            x: +d[x],
            y: +d[y],
            size: dSize === void 0 ? 1 : +d[sizeDataColumn] || 0
        };
    });
    const groupedData = groupInColumns(data, column, columnFilter);
    const columnTitleHeight = column ? COLUMN_TITLE_HEIGHT3 : 0;
    const { height, innerWidth, innerHeight, gx, gy } = getColumnLayout(columns, groupedData, width - paddingLeft - paddingRight, minInnerWidth, (innerWidth2)=>(userHeight || innerWidth2 * heightRatio) + columnTitleHeight, columnSort, paddingTop, paddingRight + COLUMN_PADDING3 / 2, paddingBottom, paddingLeft + COLUMN_PADDING3 / 2, COLUMN_PADDING3, true);
    const xValues = aggregateValues(data, xAccessor, xTicks, xLines).concat(annotations.map((annotation)=>annotation.x1)).concat(annotations.map((annotation)=>annotation.x2));
    const plotX = getPlot(xScale, xValues, [
        paddingLeft,
        innerWidth + paddingLeft
    ], xNice, innerWidth);
    const xAxis = calculateAxis(xNumberFormat || numberFormat, tLabel, plotX.domain(), void 0, {
        ticks: xLines ? xLines.map(tickAccessor) : xTicks
    });
    let plotXLines = xLines || (xTicks || (xScale === "log" ? get3EqualDistTicks(plotX) : xAxis.ticks)).map((tick)=>({
            tick
        }));
    plotXLines = plotXLines.slice().sort((a, b)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$ascending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ascending$3e$__["ascending"])(a.tick, b.tick));
    const yValues = aggregateValues(data, yAccessor, yTicks, yLines).concat(annotations.map((annotation)=>annotation.y1)).concat(annotations.map((annotation)=>annotation.y2));
    const plotY = getPlot(yScale, yValues, [
        innerHeight + paddingTop,
        paddingTop + columnTitleHeight
    ], yNice, innerHeight);
    const yAxis = calculateAxis(yNumberFormat || numberFormat, tLabel, plotY.domain(), tLabel(yUnit), {
        ticks: yLines ? yLines.map(tickAccessor) : yTicks
    });
    const plotYLines = yLines || (yTicks || (yScale === "log" ? get3EqualDistTicks(plotY) : yAxis.ticks)).map((tick)=>({
            tick
        })).sort((a, b)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$ascending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ascending$3e$__["ascending"])(a.tick, b.tick));
    const maxYLine = plotYLines[plotYLines.length - 1];
    const colorAccessor = (d)=>d.datum[color];
    const colorValues = [].concat(data.map(colorAccessor)).concat(colorLegendValues).filter(deduplicate).filter(Boolean);
    runSort(colorSort, colorValues);
    const colorMapper = getColorMapper({
        colorMap,
        colorRanges,
        colorRange
    }, colorValues);
    const yLinesPaddingLeft = paddingLeft < 2 ? paddingLeft : 0;
    const showColorLegend = color !== column;
    const displayedColorLegendValues = showColorLegend ? [].concat(colorLegend && (colorLegendValues || colorValues).map((colorValue)=>({
            color: colorMapper(colorValue),
            label: colorValue
        }))).filter(Boolean) : [];
    const rSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$pow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__sqrt__as__scaleSqrt$3e$__["scaleSqrt"])().domain([
        0,
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(data, (d)=>d.size)
    ]).range([
        0,
        props.sizeRange ? props.sizeRange[1] : sizeRangeMax
    ]);
    const contextBoxProps = {
        tooltipLabel,
        tooltipBody,
        label,
        yShowValue,
        xShowValue,
        sizeShowValue,
        detail,
        yUnit,
        xUnit,
        sizeUnit,
        sizeFormat: getFormat(sizeNumberFormat || numberFormat, tLabel)
    };
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ColorLegend_default, {
                inline: true,
                values: displayedColorLegendValues
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                style: {
                    position: "relative",
                    width,
                    height
                },
                children: groupedData.map(({ values: values2, key })=>{
                    const filterByColumn = (d)=>!d.column || d.column === key;
                    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                        style: {
                            position: "absolute",
                            left: gx(key),
                            top: gy(key)
                        },
                        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ScatterPlotGroup_default, {
                            values: values2,
                            plotX,
                            plotY,
                            rSize,
                            description,
                            title: key,
                            inlineLabel,
                            inlineSecondaryLabel,
                            inlineLabelPosition,
                            plotXLines: plotXLines.filter(filterByColumn),
                            plotYLines: plotYLines.filter(filterByColumn),
                            opacity,
                            width: innerWidth,
                            height: innerHeight,
                            paddingTop,
                            paddingLeft,
                            paddingRight,
                            paddingBottom,
                            yLinesPaddingLeft,
                            xAxis,
                            yAxis,
                            maxYLine,
                            getColor: (d)=>colorMapper(colorAccessor(d)),
                            xUnit,
                            annotations: annotations.filter(filterByColumn),
                            contextBoxProps,
                            allowCanvasRendering: allowCanvasRendering && !colorDarkMapping
                        })
                    }, key || 1);
                })
            })
        ]
    });
};
_c63 = ScatterPlot;
var propTypes5 = {
    values: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
    width: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    height: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    heightRatio: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    x: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    xUnit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    xNice: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    xTicks: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number),
    xLines: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        tick: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        base: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
        textAnchor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    }).isRequired),
    xScale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf(Object.keys(scales)),
    xNumberFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    xShowValue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool.isRequired,
    y: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    yUnit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    yNice: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    yTicks: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number),
    yLines: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        tick: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        base: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
    }).isRequired),
    yScale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf(Object.keys(scales)),
    yNumberFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    yShowValue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool.isRequired,
    numberFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    opacity: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    color: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    colorLegend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    colorLegendValues: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string),
    colorRange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array
    ]),
    colorRanges: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        sequential3: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
        discrete: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired
    }).isRequired,
    colorMap: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    colorSort: sortPropType,
    pointSize: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    sizeRangeMax: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    sizeUnit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    sizeNumberFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    sizeShowValue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool.isRequired,
    label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    inlineLabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    inlineLabelPosition: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    inlineSecondaryLabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    detail: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    tLabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    description: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    paddingTop: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    paddingRight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    paddingBottom: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    paddingLeft: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    tooltipLabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    tooltipBody: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    columnSort: sortPropType,
    columnFilter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        title: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        test: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired
    })),
    columns: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    minInnerWidth: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    annotations: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        x1: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        x2: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        y1: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        y2: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    }).isRequired).isRequired
};
ScatterPlot.defaultProps = defaultProps.ScatterPlot;
ScatterPlot.propTypes = propTypes5;
var ScatterPlotWithDefaultProps = (props)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ScatterPlot, __spreadValues(__spreadValues({}, defaultProps.ScatterPlot), props));
_c64 = ScatterPlotWithDefaultProps;
var ScatterPlots_default = ScatterPlotWithDefaultProps;
;
;
;
;
;
;
;
;
;
var MARKER_HEIGHT = 20;
var MARKER_RADIUS = 5.5;
var PADDING_TOP2 = MARKER_HEIGHT + 10;
var PADDING_BOTTOM = 10;
var COLUMN_PADDING4 = 30;
function mapsLayout(props, geoJson) {
    const { values, width, mini, t, tLabel, choropleth, ignoreMissingFeature, missingDataLegend, color } = props;
    let data = values;
    if (props.filter) {
        const filter = unsafeDatumFn(props.filter);
        data = data.filter(filter);
    }
    data = data.map((d)=>{
        const value = +d.value;
        return {
            datum: d,
            value,
            empty: !(value || value === 0) && !d[props.color],
            featureId: String(d[props.feature])
        };
    });
    const marker = props.shape === "marker";
    if (marker) {
        data.sort((a, b)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$descending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__descending$3e$__["descending"])(a.datum.lat, b.datum.lat));
    }
    const numberFormat = getFormat(props.numberFormat, t);
    let domain;
    let colorScale;
    let colorAccessor = choropleth ? (d)=>d.value : (d)=>d[color] || 0;
    let colorValues;
    let colorRange = props.colorRanges[props.colorRange] || props.colorRange;
    if (props.color) {
        colorAccessor = (d)=>d.datum[props.color];
        domain = data.map(colorAccessor).filter(deduplicate);
        colorValues = domain.map((value)=>({
                label: tLabel(value),
                value
            }));
        colorScale = getColorMapper(props, colorRange);
    } else {
        const dataValues = data.map((d)=>d.value);
        const valuesExtent = props.extent || (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$extent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__extent$3e$__["extent"])(dataValues);
        if (props.thresholds || props.thresholdsLegend) {
            colorScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$threshold$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleThreshold$3e$__["scaleThreshold"])();
            domain = props.thresholds || props.thresholdsLegend.map((d)=>d.minValue).filter(Boolean);
            if (!colorRange) {
                colorRange = props.colorRanges.sequential.slice(0, domain.length + 1);
            }
        } else {
            colorScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$quantize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleQuantize$3e$__["scaleQuantize"])();
            domain = valuesExtent;
        }
        colorScale.domain(domain).range(colorRange || props.colorRanges.sequential);
        colorValues = colorScale.range().map((value, i)=>{
            var _a;
            const extent4 = colorScale.invertExtent(value);
            const safeExtent = [
                extent4[0] === void 0 ? valuesExtent[0] : extent4[0],
                extent4[1] === void 0 ? valuesExtent[1] : extent4[1]
            ];
            return {
                value: safeExtent[0],
                label: props.thresholdsLegend && ((_a = props.thresholdsLegend[i]) == null ? void 0 : _a.label) || `${numberFormat(safeExtent[0])} ${tLabel("bis")} ${numberFormat(safeExtent[1])}`
            };
        });
    }
    const projection = props.getProjection();
    const geoPathGenerator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$geo$2f$src$2f$path$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__geoPath$3e$__["geoPath"])().projection(projection);
    const projectPoint = typeof projection === "function" ? projection : (coordinates)=>geoPathGenerator({
            type: "Point",
            coordinates
        }).split("m")[0].slice(1).split(",").map((d)=>+d);
    const paddingTop = mini ? 15 : PADDING_TOP2;
    const paddingBottom = mini ? 0 : PADDING_BOTTOM;
    let mapWidth;
    let innerHeight;
    if (props.height) {
        const height = props.height;
        innerHeight = mini ? height - paddingTop - paddingBottom : height;
        mapWidth = innerHeight * props.widthRatio;
    } else {
        mapWidth = width;
        innerHeight = mapWidth * props.heightRatio;
    }
    if (geoJson) {
        projection.fitSize([
            width,
            innerHeight
        ], geoJson.features);
        const bounds = geoPathGenerator.bounds(geoJson.features);
        mapWidth = bounds[1][0] - bounds[0][0];
        innerHeight = bounds[1][1] - bounds[0][1];
    }
    const columnPadding = mini ? 12 : COLUMN_PADDING4;
    const possibleColumns = Math.floor(width / (mapWidth + columnPadding));
    const columns = possibleColumns >= props.columns ? props.columns : Math.max(possibleColumns, 1);
    const padding = (width - mapWidth) / 2;
    const leftAlign = props.leftAlign || columns > 1 || mini;
    if (leftAlign) {
        const projectionTranslate = projection.translate();
        projection.translate([
            projectionTranslate[0] - padding,
            projectionTranslate[1]
        ]);
    }
    const colorLegendValues = (props.colorLegendValues ? props.colorLegendValues.map((label)=>({
            label,
            color: colorScale(label)
        })) : colorValues.map((color2)=>({
            label: color2.label,
            color: colorScale(color2.value)
        }))).concat(missingDataLegend ? {
        label: missingDataLegend,
        color: props.missingDataColor
    } : []);
    const geotiffs = {};
    const geotiff = props.geotiff;
    const mapGeotiff = (d)=>{
        let tl = projectPoint(d.bbox[0]);
        let br = projectPoint(d.bbox[1]);
        return {
            xlinkHref: d.url,
            x: tl[0],
            y: tl[1],
            width: br[0] - tl[0],
            height: br[1] - tl[1]
        };
    };
    if (geotiff) {
        geotiffs[""] = mapGeotiff(geotiff);
    }
    let groupedData;
    if (props.columnFilter) {
        groupedData = props.columnFilter.map(({ test, title, geotiff: columnGeotiff })=>{
            const filter = unsafeDatumFn(test);
            geotiffs[title] = mapGeotiff(columnGeotiff);
            return {
                key: title,
                values: data.filter((d)=>filter(d.datum))
            };
        });
        data = groupedData.reduce((all, group)=>all.concat(group.values), []);
    } else {
        groupedData = groupBy(data, (d)=>d.datum[props.column]);
    }
    if (groupedData.length === 0) {
        groupedData = [
            {
                key: "",
                values: []
            }
        ];
    }
    let groups = groupedData.map((g)=>g.key);
    runSort(props.columnSort, groups);
    const columnHeight = innerHeight + paddingTop + paddingBottom;
    const gx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$ordinal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleOrdinal$3e$__["scaleOrdinal"])().domain(groups).range((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$range$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__range$3e$__["range"])(columns).map((d)=>d * (mapWidth + columnPadding)));
    const gy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$ordinal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleOrdinal$3e$__["scaleOrdinal"])().domain(groups).range((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$range$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__range$3e$__["range"])(groups.length).map((d)=>Math.floor(d / columns) * columnHeight));
    const rows = Math.ceil(groups.length / columns);
    const paddingLeft = leftAlign ? 0 : padding;
    const mapSpace = (mapWidth + (columns > 1 ? columnPadding : 0)) * columns;
    const paddingRight = width - mapSpace - paddingLeft;
    let featuresWithPaths = [];
    let compositionBorderPath;
    if (geoJson) {
        featuresWithPaths = geoJson.features.features.map((feature)=>{
            return {
                id: String(feature.id),
                path: geoPathGenerator(feature),
                bounds: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$memoize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>geoPathGenerator.bounds(feature)),
                properties: feature.properties
            };
        });
        compositionBorderPath = geoJson.compositionBorders && geoPathGenerator(geoJson.compositionBorders);
        if (choropleth) {
            groupedData = groupedData.map(({ values: values2, key: groupTitle })=>{
                const groupData = [].concat(values2);
                groupData.forEach((d)=>{
                    d.feature = featuresWithPaths.find((f)=>f.id === d.featureId);
                    if (!ignoreMissingFeature && !d.feature) {
                        throw new Error(`No feature for data ${d.featureId} ${groupTitle ? ` (${groupTitle})` : ""} ${d.value}`);
                    }
                });
                featuresWithPaths.forEach((feature)=>{
                    const d = groupData.find((datum)=>datum.featureId === feature.id);
                    if (!d) {
                        if (missingDataLegend === void 0) {
                            throw new Error(`No data for feature ${feature.id} ${groupTitle ? ` (${groupTitle})` : ""}`);
                        }
                        groupData.push({
                            feature,
                            empty: true
                        });
                    }
                });
                return {
                    values: groupData,
                    key: groupTitle
                };
            });
        }
    }
    return {
        paddingTop,
        paddingLeft,
        paddingRight,
        paddingBottom,
        mapSpace,
        mapWidth,
        columnHeight,
        rows,
        gx,
        gy,
        projectPoint,
        colorScale,
        colorAccessor,
        domain,
        data,
        groupedData,
        geotiffs,
        featuresWithPaths,
        compositionBorderPath,
        colorLegendValues,
        numberFormat
    };
}
;
;
;
;
;
;
;
;
var containerStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
    display: "block",
    position: "absolute",
    top: "50%",
    left: "50%"
});
var spin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["keyframes"])({
    "0%": {
        opacity: 1
    },
    "100%": {
        opacity: 0.15
    }
});
var barStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
    display: "block",
    animation: `${spin} 1.2s linear infinite`,
    borderRadius: 5,
    backgroundColor: "#999",
    position: "absolute",
    width: "20%",
    height: "7.8%",
    top: "-3.9%",
    left: "-10%"
});
var Spinner = ({ size = 50 })=>{
    const bars = [];
    for(let i = 0; i < 12; i++){
        const style = {};
        style.WebkitAnimationDelay = style.animationDelay = (i - 12) / 10 + "s";
        style.WebkitTransform = style.transform = "rotate(" + i * 30 + "deg) translate(146%)";
        bars.push(/* @__PURE__ */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("span", __spreadProps(__spreadValues({}, barStyle), {
            style,
            key: i
        })));
    }
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", __spreadProps(__spreadValues({}, containerStyle), {
        style: {
            width: size,
            height: size
        },
        children: bars
    }));
};
_c65 = Spinner;
var inlineBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
    position: "relative",
    display: "inline-block"
});
var InlineSpinner = ({ size = 50 })=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", __spreadProps(__spreadValues({}, inlineBlock), {
        style: {
            width: size,
            height: size
        },
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Spinner, {
            size
        })
    }));
_c66 = InlineSpinner;
var Spinner_default = Spinner;
;
var { P: P5 } = Interaction;
var styles12 = {
    message: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        position: "absolute",
        top: "50%",
        marginTop: 30,
        width: "100%",
        textAlign: "center"
    }),
    spacer: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        position: "relative",
        minHeight: 120,
        height: "100%",
        minWidth: "100%"
    })
};
var Spacer = ({ style, children })=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", __spreadProps(__spreadValues({}, styles12.spacer), {
        style,
        children
    }));
_c67 = Spacer;
var Loader = ({ style, message, loading, error, render = ()=>null, delay = 500, ErrorContainer = ({ children })=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children
    }) })=>{
    _s43();
    const [visible, setVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [colorScheme] = useColorContext();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Loader.useEffect3": ()=>{
            const timer = setTimeout({
                "Loader.useEffect3.timer": ()=>setVisible(true)
            }["Loader.useEffect3.timer"], delay);
            return ({
                "Loader.useEffect3": ()=>clearTimeout(timer)
            })["Loader.useEffect3"];
        }
    }["Loader.useEffect3"], [
        delay
    ]);
    if (loading && !visible) {
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Spacer, {
            style
        });
    } else if (loading) {
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(Spacer, {
            style,
            children: [
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Spinner_default, {}),
                !!message && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(P5, __spreadProps(__spreadValues(__spreadValues({}, styles12.message), colorScheme.set("color", "text")), {
                    children: message
                }))
            ]
        });
    } else if (error) {
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ErrorContainer, {
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(P5, __spreadProps(__spreadValues({}, colorScheme.set("color", "error")), {
                children: error.graphQLErrors && error.graphQLErrors.length ? error.graphQLErrors.map((e)=>e.message).join(", ") : error.toString()
            }))
        });
    }
    return render();
};
_s43(Loader, "a/TyoVOanrIkSKGjjFZ2XxpzzjQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"],
        useColorContext,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]
    ];
});
_c68 = Loader;
var Loader_default = Loader;
;
var FEATURE_BG = "#E0E0E0";
var styles13 = {
    columnTitle: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifMedium14)),
    interactivePath: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        userSelect: "none",
        WebkitTapHighlightColor: "rgba(0, 0, 0, 0)"
    }),
    pointGroup: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        userSelect: "none"
    })
};
var symbolShapes = {
    square: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$symbol$2f$square$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__symbolSquare$3e$__["symbolSquare"],
    circle: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$symbol$2f$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__symbolCircle$3e$__["symbolCircle"]
};
var shapes = Object.keys(symbolShapes).concat("marker");
var Points = ({ data, colorScale, colorAccessor, project, shape, sizeRangeMax, hoverPoint, setHoverPoint, opacity, colorScheme })=>{
    _s44();
    const valueAccessor2 = (d)=>isNaN(d.value) ? 1 : d.value;
    const marker = shape === "marker";
    let symbolPath;
    if (!marker) {
        const size = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain([
            0,
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$max$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__max$3e$__["max"])(data.map((d)=>valueAccessor2(d)))
        ]).range([
            0,
            sizeRangeMax
        ]);
        symbolPath = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$symbol$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__symbol$3e$__["symbol"])().type(symbolShapes[shape]).size((d)=>size(valueAccessor2(d)));
    }
    const displayData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useMemo({
        "Points.useMemo[displayData]": ()=>[
                ...data
            ].sort({
                "Points.useMemo[displayData]": (a, b)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$descending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__descending$3e$__["descending"])(valueAccessor2(a), valueAccessor2(b))
            }["Points.useMemo[displayData]"])
    }["Points.useMemo[displayData]"], [
        data
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("g", {
        children: displayData.map((d, i)=>{
            const color = colorScale(colorAccessor(d));
            let pos = project([
                d.datum.lon || d.datum.x,
                d.datum.lat || d.datum.y
            ]);
            if (marker) {
                pos = pos.map(Math.round);
            }
            return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", __spreadProps(__spreadValues({
                transform: `translate(${pos.join(",")})`,
                onMouseEnter: ()=>setHoverPoint(d),
                onTouchStart: ()=>setHoverPoint(d),
                onMouseLeave: ()=>setHoverPoint(null),
                onTouchEnd: ()=>setHoverPoint(null)
            }, styles13.pointGroup), {
                children: [
                    marker && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("circle", __spreadProps(__spreadValues({
                        cy: -MARKER_HEIGHT,
                        r: MARKER_RADIUS
                    }, colorScheme.set("fill", color, "charts")), {
                        stroke: "white",
                        strokeWidth: "1"
                    })),
                    marker && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", __spreadProps(__spreadValues({
                        y2: -MARKER_HEIGHT
                    }, colorScheme.set("stroke", color, "charts")), {
                        strokeWidth: "2",
                        shapeRendering: "crispEdges"
                    })),
                    !marker && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            (hoverPoint == null ? void 0 : hoverPoint.datum) === d.datum && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                                d: symbolPath(d),
                                fill: "none",
                                stroke: "#000",
                                strokeWidth: "1"
                            }),
                            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", __spreadProps(__spreadValues({
                                d: symbolPath(d)
                            }, colorScheme.set("fill", color, "charts")), {
                                style: {
                                    opacity
                                }
                            }))
                        ]
                    })
                ]
            }), i);
        })
    });
};
_s44(Points, "lXgQMKl/zycmyrxQ3ysW0x4F5WE=");
_c69 = Points;
Points.propTypes = {
    data: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array,
    colorScale: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    colorAccessor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    project: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    shape: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf(shapes).isRequired,
    domain: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array,
    sizeRangeMax: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
};
var fetchJsonCacheData = /* @__PURE__ */ new Map();
var fetchJson = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$memoize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((url)=>fetch(url).then((response)=>response.json()).then((data)=>{
        fetchJsonCacheData.set(url, data);
        return data;
    }));
var getStateFromFeaturesData = (features, data)=>{
    const geoJsonFeatures = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$topojson$2d$client$2f$src$2f$feature$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__feature$3e$__["feature"])(data, data.objects[features.object]);
    return {
        loading: false,
        geoJson: {
            features: geoJsonFeatures,
            compositionBorders: features.compositionBorders && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$topojson$2d$client$2f$src$2f$mesh$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__mesh$3e$__["mesh"])(data, data.objects[features.compositionBorders])
        }
    };
};
var GenericMap = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Component"] {
    constructor(props){
        super(props);
        __publicField(this, "setHoverPoint", (displayPoint)=>{
            if (!displayPoint) {
                this.setState({
                    hoverPoint: null
                });
                return;
            }
            const { datum } = displayPoint;
            const { layout: { projectPoint, numberFormat } } = this.state;
            const { pointLabel, pointAttributes, unit, tooltipLabel, tooltipBody } = this.props;
            const [x, y] = projectPoint([
                datum.lon,
                datum.lat
            ]);
            const value = datum.value !== void 0 && (isNaN(datum.value) ? String(datum.value).trim() : numberFormat(datum.value));
            const replacements = __spreadProps(__spreadValues({}, datum), {
                formattedValue: value
            });
            const contextT = (text)=>replaceKeys(text, replacements);
            const label = tooltipLabel ? contextT(tooltipLabel) : datum[pointLabel];
            const body = mergeFragments(tooltipBody ? formatLines(contextT(tooltipBody)) : [
                value && `${value} ${unit}`
            ].concat(pointAttributes.map((t)=>datum[t])).filter(Boolean).map(formatLines));
            if (label || body.length) {
                this.setState({
                    hoverPoint: {
                        x,
                        y,
                        label,
                        body
                    }
                });
            } else {
                this.setState({
                    hoverPoint: null
                });
            }
        });
        this.state = props.features && fetchJsonCacheData.has(props.features.url) ? getStateFromFeaturesData(props.features, fetchJsonCacheData.get(props.features.url)) : {
            loading: !!props.features
        };
        this.state.layout = mapsLayout(props, this.state.geoJson);
    }
    componentDidMount() {
        const { features } = this.props;
        if (features) {
            fetchJson(features.url).then((data)=>{
                this.setState(getStateFromFeaturesData(features, data));
            }).catch((error)=>{
                this.setState({
                    loading: false,
                    error
                });
            });
        }
    }
    componentDidUpdate(prevProps, prevState) {
        if (prevProps !== this.props || prevState.geoJson !== this.state.geoJson) {
            this.setState({
                layout: mapsLayout(this.props, this.state.geoJson)
            });
        }
    }
    componentWillUnmount() {
        fetchJsonCacheData.clear();
        fetchJson.cache.clear();
    }
    renderTooltips() {
        const props = this.props;
        const { width, tLabel, missingDataLegend, tooltipLabel, tooltipBody } = props;
        const { paddingTop, gx, gy, groupedData, numberFormat } = this.state.layout;
        const { hoverFeature, title } = this.state;
        return !!hoverFeature && groupedData.map(({ values: groupData, key: groupTitle })=>{
            return groupData.filter((datum)=>datum.feature === hoverFeature).map((d)=>{
                const [[x0, y0], [x1]] = d.feature.bounds();
                const replacements = __spreadProps(__spreadValues(__spreadValues({}, hoverFeature.properties), d.datum), {
                    value: d.value || d.value === 0,
                    formattedValue: (d.value || d.value === 0) && numberFormat(d.value)
                });
                const contextT = (text)=>replaceKeys(text, replacements);
                const label = tooltipLabel ? contextT(tooltipLabel) : title === groupTitle ? hoverFeature.properties.name : tLabel(groupTitle);
                const body = mergeFragments(tooltipBody ? formatLines(d.empty ? missingDataLegend : contextT(tooltipBody)) : [
                    groupTitle && title === groupTitle && tLabel(groupTitle),
                    replacements.formattedValue && `${replacements.formattedValue} ${props.unit}`,
                    d.datum && d.datum[props.color],
                    d.empty && missingDataLegend
                ].filter(Boolean).map(formatLines));
                return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ContextBox_default, {
                    orientation: "top",
                    x: gx(groupTitle) + x0 + (x1 - x0) / 2,
                    y: gy(groupTitle) + paddingTop + y0 - 15,
                    contextWidth: width,
                    children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ContextBoxValue, {
                        label,
                        children: body
                    })
                }, d.feature.id);
            });
        });
    }
    renderPointTooltip() {
        const { hoverPoint } = this.state;
        const { width } = this.props;
        if (!hoverPoint) {
            return null;
        }
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ContextBox_default, {
            orientation: "top",
            x: hoverPoint.x,
            y: hoverPoint.y,
            contextWidth: width,
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ContextBoxValue, {
                label: hoverPoint.label,
                children: hoverPoint.body
            })
        });
    }
    render() {
        const { props, state } = this;
        const { width, mini, tLabel, description, choropleth, colorLegendSize, colorLegendPosition, missingDataColor, opacity, colorScheme, highlighted, highlightedColor } = props;
        const { loading, error, geoJson, hoverPoint } = state;
        const { paddingTop, paddingLeft, paddingBottom, paddingRight, mapSpace, mapWidth, columnHeight, rows, gx, gy, data, projectPoint, colorScale, colorAccessor, domain, groupedData, geotiffs, featuresWithPaths, compositionBorderPath, colorLegendValues } = this.state.layout;
        let legendStyle;
        if (mapSpace * colorLegendSize >= props.colorLegendMinWidth || mini) {
            legendStyle = {
                position: "absolute"
            };
            if (colorLegendPosition === "left") {
                legendStyle.bottom = paddingBottom;
                legendStyle.left = paddingLeft;
                legendStyle.right = paddingRight + mapSpace * (1 - colorLegendSize);
            } else {
                legendStyle.top = mini ? 12 : paddingTop;
                legendStyle.left = paddingLeft + mapSpace * (1 - colorLegendSize);
                legendStyle.right = 0;
            }
        } else {
            legendStyle = {
                paddingLeft
            };
        }
        const { hoverFeature } = this.state;
        const hasTooltips = !!hoverFeature && choropleth;
        const hasGeoJson = !!geoJson;
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
            style: {
                position: "relative"
            },
            children: [
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                    style: legendStyle,
                    children: [
                        !!props.geotiffLegendTitle && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ColorLegend_default, {
                            title: tLabel(props.geotiffLegendTitle),
                            values: props.geotiffLegend
                        }),
                        !!props.colorLegend && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ColorLegend_default, {
                            title: tLabel(props.legendTitle),
                            shape: props.shape,
                            values: colorLegendValues
                        })
                    ]
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
                    style: {
                        position: "relative"
                    },
                    children: [
                        /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
                            width,
                            height: columnHeight * rows,
                            children: [
                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("desc", {
                                    children: description
                                }),
                                groupedData.map(({ values: groupData, key: title })=>{
                                    const geotiff = geotiffs[title];
                                    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                                        transform: `translate(${gx(title)},${gy(title)})`,
                                        children: [
                                            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({
                                                dy: "1.5em",
                                                x: paddingLeft + mapWidth / 2,
                                                textAnchor: "middle"
                                            }, styles13.columnTitle), colorScheme.set("fill", "text")), {
                                                children: tLabel(title)
                                            })),
                                            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                                                transform: `translate(0,${paddingTop})`,
                                                children: [
                                                    !choropleth && featuresWithPaths.map((feature)=>{
                                                        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                                                            fill: FEATURE_BG,
                                                            stroke: "white",
                                                            strokeWidth: 1,
                                                            d: feature.path
                                                        }, feature.id);
                                                    }),
                                                    choropleth && hasGeoJson && groupData.map((d)=>{
                                                        const { feature } = d;
                                                        if (!feature) {
                                                            return null;
                                                        }
                                                        let fill;
                                                        if (d.empty) {
                                                            fill = missingDataColor;
                                                        } else {
                                                            fill = colorScale(colorAccessor(d));
                                                        }
                                                        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", __spreadProps(__spreadValues(__spreadProps(__spreadValues({}, colorScheme.set("fill", fill, "charts")), {
                                                            d: feature.path
                                                        }), styles13.interactivePath), {
                                                            onTouchStart: ()=>this.setState({
                                                                    hoverFeature: feature,
                                                                    title
                                                                }),
                                                            onTouchEnd: ()=>this.setState({
                                                                    hoverFeature: void 0,
                                                                    title: void 0
                                                                }),
                                                            onMouseEnter: ()=>this.setState({
                                                                    hoverFeature: feature,
                                                                    title
                                                                }),
                                                            onMouseLeave: ()=>this.setState({
                                                                    hoverFeature: void 0,
                                                                    title: void 0
                                                                })
                                                        }), feature.id);
                                                    }),
                                                    highlighted && choropleth && hasGeoJson && groupData.map(({ datum, feature })=>{
                                                        if (!feature || !(datum == null ? void 0 : datum[highlighted])) {
                                                            return null;
                                                        }
                                                        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                                                            fill: "none",
                                                            pointerEvents: "none",
                                                            stroke: highlightedColor,
                                                            strokeWidth: 1.5,
                                                            d: feature.path
                                                        }, `highlighted-${feature.id}`);
                                                    }),
                                                    hasTooltips && featuresWithPaths.filter((feature)=>feature.id === hoverFeature.id).map((feature)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                                                            fill: "none",
                                                            pointerEvents: "none",
                                                            stroke: "black",
                                                            strokeWidth: 1.5,
                                                            d: feature.path
                                                        }, `stroke-${feature.id}`)),
                                                    geotiff && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("image", __spreadValues({}, geotiff)),
                                                    compositionBorderPath && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                                                        fill: "none",
                                                        stroke: "black",
                                                        strokeWidth: 1,
                                                        d: compositionBorderPath
                                                    }),
                                                    props.points && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Points, {
                                                        data,
                                                        colorScheme,
                                                        colorScale,
                                                        colorAccessor,
                                                        domain,
                                                        project: projectPoint,
                                                        shape: props.shape,
                                                        sizeRangeMax: props.sizeRangeMax,
                                                        hoverPoint,
                                                        setHoverPoint: this.setHoverPoint,
                                                        opacity
                                                    })
                                                ]
                                            })
                                        ]
                                    }, title || 1);
                                })
                            ]
                        }),
                        (!hasGeoJson || !!error) && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                            style: {
                                position: "absolute",
                                left: paddingLeft,
                                top: paddingTop,
                                width: mapSpace
                            },
                            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Loader_default, {
                                loading,
                                error
                            })
                        }),
                        hasTooltips && this.renderTooltips(),
                        this.renderPointTooltip()
                    ]
                })
            ]
        });
    }
};
var geotiffShape = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
    url: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    bbox: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired))
});
var featuresShape = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
    object: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    url: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired
});
var propTypes6 = {
    values: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
    width: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    // full width map, dynamic height
    heightRatio: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    // static height
    height: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    // inner map width ratio to size canvas until geo data is loaded
    widthRatio: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    leftAlign: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    mini: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    columnSort: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        "none",
        "descending"
    ]),
    columnFilter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        title: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        test: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        geotiff: geotiffShape
    })),
    columns: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    thresholds: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number),
    thresholdsLegend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        minValue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
    })),
    extent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number),
    colorLegend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool.isRequired,
    colorLegendLabels: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string),
    colorLegendSize: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    colorLegendMinWidth: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    colorLegendPosition: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    colorRange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array
    ]),
    colorRanges: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        sequential3: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
        discrete: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
        sequential: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired
    }).isRequired,
    colorMap: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    shape: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf(shapes).isRequired,
    sizeRangeMax: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    features: featuresShape,
    highlighted: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    highlightedColor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    geotiff: geotiffShape,
    geotiffLegendTitle: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    geotiffLegend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        color: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired
    })),
    legendTitle: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    unit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    numberFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    filter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    points: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool.isRequired,
    pointLabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    pointAttributes: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string),
    choropleth: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool.isRequired,
    feature: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    missingDataLegend: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    missingDataColor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    ignoreMissingFeature: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool.isRequired,
    tLabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
    description: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    color: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    opacity: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    tooltipLabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    tooltipBody: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
};
GenericMap.propTypes = propTypes6;
GenericMap.defaultProps = defaultProps.GenericMap;
var ProjectedMap = (props)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(GenericMap, __spreadValues(__spreadValues({}, defaultProps.ProjectedMap), props));
_c70 = ProjectedMap;
ProjectedMap.base = "GenericMap";
var SwissMap = (props)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(GenericMap, __spreadValues(__spreadValues({}, defaultProps.SwissMap), props));
_c71 = SwissMap;
SwissMap.base = "GenericMap";
;
;
;
;
;
;
;
var styles14 = {
    axis: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifRegular12)),
    labelStrong: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifMedium14)),
    label: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadValues({}, sansSerifRegular14))
};
var arc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$shape$2f$src$2f$arc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__arc$3e$__["arc"])();
var MAX_ARC = Math.PI;
var calcSectorAngles = (vals = [])=>{
    const total = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$sum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__sum$3e$__["sum"])(vals, (d)=>+d.value);
    return vals.reduce((acc, cur, i)=>{
        const deltaAngle = MAX_ARC / total * cur.value;
        const startAngle = acc[i - 1] ? acc[i - 1][1] : -MAX_ARC / 2;
        const endAngle = startAngle + deltaAngle;
        acc.push([
            startAngle,
            endAngle,
            cur.label
        ]);
        return acc;
    }, []);
};
var Hemicycle = (_props)=>{
    _s45();
    const props = __spreadValues(__spreadValues({}, defaultProps.Hemicycle), _props);
    const { values, width, unit, inlineLabelThreshold, middleAnnotation, padding, group, color: colorProp } = props;
    const margins = {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0
    };
    const color = getColorMapper(props);
    const [colorScheme] = useColorContext();
    const primaryGroupLabel = values.length > 0 && values[0][group];
    const labelheight = 18;
    const sidePadding = width * 0.01 * padding;
    const w = width - margins.left - margins.right - sidePadding;
    const height = (w >> 1) + (primaryGroupLabel ? 3 : 2) * labelheight;
    const h = height - margins.top - margins.bottom;
    const [primaryVals, secondaryVals] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$partition$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(values, (v)=>v[group] === primaryGroupLabel);
    const secondaryGroupLabel = secondaryVals.length > 0 && secondaryVals[0][group];
    const primaryValsTotal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$sum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__sum$3e$__["sum"])(primaryVals, (d)=>+d.value);
    const primaryAngles = calcSectorAngles(primaryVals);
    const secondaryAngles = calcSectorAngles(secondaryVals);
    const hemicycleWidth = w;
    const hemicycleHeight = hemicycleWidth >> 1;
    const outerRadiusPrimary = hemicycleHeight;
    const innerRadiusPrimary = hemicycleHeight >> 1;
    const outerRadiusSecondary = hemicycleHeight * 0.4;
    const innerRadiusSecondary = hemicycleHeight * 0.3;
    const hemicycleOffset = hemicycleHeight + 2 * labelheight;
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", {
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
                height,
                width,
                children: [
                    /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                        transform: `translate(${width >> 1},0)`,
                        children: [
                            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("line", __spreadProps(__spreadValues({
                                x1: 0,
                                x2: 0,
                                y1: 0,
                                y2: h + labelheight - (secondaryAngles.length > 0 ? innerRadiusSecondary : innerRadiusPrimary)
                            }, colorScheme.set("stroke", "text")), {
                                style: {
                                    opacity: 0.17
                                }
                            })),
                            middleAnnotation && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles14.axis), colorScheme.set("fill", "textSoft")), {
                                x: 5,
                                y: 0,
                                alignmentBaseline: "hanging",
                                children: middleAnnotation
                            }))
                        ]
                    }),
                    /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                        transform: `translate(${margins.left + sidePadding >> 1},${margins.top})`,
                        children: [
                            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                                transform: `translate(${w >> 1},${hemicycleOffset})`,
                                children: [
                                    primaryAngles.map((d, i)=>{
                                        const datum = primaryVals.find((g)=>g.label === d[2]);
                                        const fill = color(datum[colorProp]);
                                        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", __spreadProps(__spreadValues({}, colorScheme.set("fill", fill, "charts")), {
                                            d: arc({
                                                outerRadius: outerRadiusPrimary,
                                                innerRadius: innerRadiusPrimary,
                                                startAngle: d[0],
                                                endAngle: d[1] + 1e-3
                                            })
                                        }), `primaryPath${i}`);
                                    }),
                                    primaryAngles.filter((d, i)=>primaryVals[i].value >= inlineLabelThreshold).map((d, i)=>{
                                        const isMajorParty = Math.abs(d[1] - d[0]) > MAX_ARC / 10;
                                        const datum = primaryVals.find((g)=>g.label === d[2]);
                                        const fill = color(datum[colorProp]);
                                        const x = hemicycleHeight * (isMajorParty ? 0.75 : 1.05) * Math.sin((d[0] + d[1]) / 2);
                                        const y = Math.max(-hemicycleOffset, -hemicycleHeight * (isMajorParty ? 0.78 : 1.15) * Math.cos((d[0] + d[1]) / 2));
                                        const textAnchor = isMajorParty || Math.abs(d[0] + d[1] / 2) < 0.5 ? "middle" : d[0] < 0 ? "end" : "start";
                                        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("g", {
                                            transform: `translate(${x},${y})`,
                                            children: [
                                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues({}, styles14.label), {
                                                    x: 0,
                                                    y: 0,
                                                    textAnchor,
                                                    alignmentBaseline: "hanging",
                                                    fill: getTextColor(fill),
                                                    children: d[2]
                                                })),
                                                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues({}, styles14.label), {
                                                    x: 0,
                                                    y: labelheight * 0.9,
                                                    textAnchor,
                                                    alignmentBaseline: "hanging",
                                                    fill: getTextColor(fill),
                                                    children: datum.value
                                                }))
                                            ]
                                        }, `primaryText${i}`);
                                    }),
                                    secondaryAngles.map((d, i)=>{
                                        const datum = secondaryVals.find((g)=>g.label === d[2]);
                                        const fill = color(datum[colorProp]);
                                        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", __spreadProps(__spreadValues({}, colorScheme.set("fill", fill, "charts")), {
                                            d: arc({
                                                outerRadius: outerRadiusSecondary,
                                                innerRadius: innerRadiusSecondary,
                                                startAngle: d[0],
                                                endAngle: d[1] + 1e-3
                                            })
                                        }), `secondaryPath${i}`);
                                    })
                                ]
                            }),
                            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles14.labelStrong), colorScheme.set("fill", "text")), {
                                x: 0,
                                y: h,
                                textAnchor: "start",
                                children: primaryGroupLabel
                            })),
                            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles14.labelStrong), colorScheme.set("fill", "text")), {
                                x: hemicycleWidth * 0.3,
                                y: h,
                                textAnchor: "start",
                                children: secondaryGroupLabel
                            })),
                            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("text", __spreadProps(__spreadValues(__spreadValues({}, styles14.label), colorScheme.set("fill", "text")), {
                                x: hemicycleWidth >> 1,
                                y: h - labelheight,
                                textAnchor: "middle",
                                children: `${primaryValsTotal} ${unit || ""}`
                            }))
                        ]
                    })
                ]
            }),
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
                style: {
                    width,
                    marginTop: 5
                },
                children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ColorLegend_default, {
                    inline: true,
                    values: primaryVals.filter((v)=>v.value < inlineLabelThreshold).map((v)=>({
                            color: color(v[colorProp]),
                            label: `${v.label}: ${v.value}`
                        }))
                })
            })
        ]
    });
};
_s45(Hemicycle, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c72 = Hemicycle;
var propTypes7 = {
    width: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
    unit: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    padding: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    inlineLabelThreshold: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    middleAnnotation: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    group: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    color: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    colorMap: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    values: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
        ]).isRequired
    })).isRequired
};
Hemicycle.propTypes = propTypes7;
var Hemicycle_default = Hemicycle;
;
;
;
;
;
;
;
var PADDING = 15;
var MAX_WIDTH = 665;
var MAX_WIDTH_MOBILE = 414 - PADDING * 2;
var DEFAULT_MARGIN = 15;
var BREAKOUT = 155 + DEFAULT_MARGIN;
var FLOAT_MARGIN = 100;
var NARROW_WIDTH = 495;
var SMALL_WIDTH = 410;
var TINY_WIDTH = 325;
var floatStyle = {
    float: "left",
    minWidth: BREAKOUT,
    maxWidth: NARROW_WIDTH,
    marginTop: FLOAT_MARGIN / 2,
    marginRight: FLOAT_MARGIN,
    marginBottom: FLOAT_MARGIN / 2,
    width: "100%",
    "[data-can-breakout=true] &": {
        marginLeft: -BREAKOUT
    }
};
var breakoutUp = `@media only screen and (min-width: ${MAX_WIDTH + BREAKOUT * 2 + PADDING * 2 + PADDING}px)`;
var BREAKOUT_SIZES = {
    narrow: NARROW_WIDTH,
    tiny: TINY_WIDTH,
    breakout: MAX_WIDTH + BREAKOUT * 2,
    breakoutLeft: MAX_WIDTH + BREAKOUT,
    float: NARROW_WIDTH,
    floatSmall: SMALL_WIDTH,
    floatTiny: TINY_WIDTH
};
var breakoutStyles = {
    narrow: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        margin: "0 auto",
        maxWidth: NARROW_WIDTH
    }),
    tiny: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        margin: "0 auto",
        maxWidth: TINY_WIDTH
    }),
    // explicit no breakout
    normal: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({}),
    breakout: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        [breakoutUp]: {
            "[data-can-breakout=true] &": {
                marginLeft: -BREAKOUT,
                marginRight: -BREAKOUT,
                width: `calc(100% + ${BREAKOUT * 2}px)`
            }
        }
    }),
    breakoutLeft: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        [breakoutUp]: {
            "[data-can-breakout=true] &": {
                marginLeft: -BREAKOUT,
                width: `calc(100% + ${BREAKOUT}px)`
            }
        }
    }),
    float: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        [breakoutUp]: __spreadValues({}, floatStyle)
    }),
    floatSmall: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        [breakoutUp]: __spreadProps(__spreadValues({}, floatStyle), {
            maxWidth: SMALL_WIDTH
        })
    }),
    floatTiny: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        [breakoutUp]: __spreadProps(__spreadValues({}, floatStyle), {
            maxWidth: TINY_WIDTH
        })
    })
};
var PADDED_MAX_WIDTH = MAX_WIDTH + PADDING * 2;
var PADDED_MAX_WIDTH_BREAKOUT = BREAKOUT_SIZES.breakout + PADDING * 2;
var centerStyles = {
    base: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        margin: "0 auto",
        padding: PADDING,
        "&:after": {
            content: '""',
            display: "table",
            clear: "both"
        }
    }),
    regular: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        maxWidth: PADDED_MAX_WIDTH
    }),
    breakout: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        maxWidth: PADDED_MAX_WIDTH_BREAKOUT
    })
};
var Center = (_a)=>{
    var _b = _a, { children, attributes = {}, breakout } = _b, props = __objRest(_b, [
        "children",
        "attributes",
        "breakout"
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, centerStyles.base), centerStyles[breakout ? "breakout" : "regular"]), attributes), props), {
        "data-can-breakout": !breakout,
        className: "center",
        children
    }));
};
_c73 = Center;
var Breakout = (_a)=>{
    var _b = _a, { size, children, attributes = {} } = _b, props = __objRest(_b, [
        "size",
        "children",
        "attributes"
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, attributes), props), breakoutStyles[size]), {
        children
    }));
};
_c74 = Breakout;
var Center_default = Center;
;
;
;
;
function useBoundingClientRect(deps = []) {
    _s46();
    const [rect, setRect] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(null);
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
            "useBoundingClientRect.useCallback": (el)=>{
                if (el) {
                    setRect(el.getBoundingClientRect());
                }
            }
        }["useBoundingClientRect.useCallback"], deps),
        // eslint-disable-line react-hooks/exhaustive-deps
        rect
    ];
}
_s46(useBoundingClientRect, "XOT4zJD5Gmk5z2dQBMvHxkxJDCg=");
;
function useMediaQuery(queryInput) {
    _s47();
    const query = queryInput.replace(/^@media /, "");
    const [matches, setMatches] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "useMediaQuery.useState3": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                return window.matchMedia(query).matches;
            } else //TURBOPACK unreachable
            ;
        }
    }["useMediaQuery.useState3"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useMediaQuery.useEffect4": ()=>{
            const mql = window.matchMedia(query);
            setMatches(mql.matches);
            const onChange = {
                "useMediaQuery.useEffect4.onChange": ({ matches: matches2 })=>{
                    setMatches(matches2);
                }
            }["useMediaQuery.useEffect4.onChange"];
            mql.addListener(onChange);
            return ({
                "useMediaQuery.useEffect4": ()=>{
                    mql.removeListener(onChange);
                }
            })["useMediaQuery.useEffect4"];
        }
    }["useMediaQuery.useEffect4"], [
        query,
        setMatches
    ]);
    return matches;
}
_s47(useMediaQuery, "R83rqMY1yP5M0CV6dFcP47LKRBY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]
    ];
});
;
;
;
;
var checkVisible = ()=>{
    const height = window.innerHeight;
    const scrollY = window.pageYOffset;
    const scrollYEdge = scrollY + height;
    instances.all.forEach((instance)=>{
        if (!instance.state.visible) {
            if (instance.y - instance.props.offset * height < scrollYEdge) {
                instance.setState({
                    visible: true
                });
            }
        }
    });
};
var onScroll = rafDebounce(()=>{
    checkVisible();
    recalculateLazyLoads();
});
var onResize = rafDebounce(()=>{
    const scrollY = window.pageYOffset;
    instances.all.forEach((instance)=>{
        if (instance.ref) {
            const rect = instance.ref.getBoundingClientRect();
            instance.y = rect.top + scrollY;
        } else {
            instance.y = void 0;
        }
    });
    checkVisible();
});
var recalculateLazyLoads = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2f$debounce$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(onResize, 1e3);
var instances = {
    add (instance) {
        if (!instances.all.length) {
            window.addEventListener("scroll", onScroll);
            window.addEventListener("resize", onResize);
        }
        instances.all.push(instance);
        onResize();
    },
    rm (instance) {
        instances.all.splice(instances.all.indexOf(instance), 1);
        if (!instances.all.length) {
            window.removeEventListener("scroll", onScroll);
            window.removeEventListener("resize", onResize);
        }
    },
    all: []
};
var LazyLoad = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Component"] {
    constructor(...args){
        super(...args);
        this.state = {};
        this.setRef = (ref)=>{
            this.ref = ref;
        };
    }
    componentDidMount() {
        instances.add(this);
    }
    componentWillUnmount() {
        instances.rm(this);
    }
    render() {
        const { children, attributes, style, type: Element, consistentPlaceholder } = this.props;
        const visible = this.props.visible || this.state.visible;
        if (visible && !consistentPlaceholder) {
            return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children
            });
        }
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Element, __spreadProps(__spreadValues({
            ref: this.setRef
        }, attributes), {
            style,
            children: visible ? children : consistentPlaceholder ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("noscript", {
                children
            }) : null
        }));
    }
};
LazyLoad.propTypes = {
    children: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].node,
    attributes: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    style: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].elementType,
    visible: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    offset: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    consistentPlaceholder: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
};
LazyLoad.defaultProps = {
    offset: 0.5,
    type: "div",
    consistentPlaceholder: false
};
var LazyLoad_default = LazyLoad;
;
var COLLAPSED_HEIGHT = {
    mobile: 180,
    desktop: 240
};
var collapsedBodyStyle = (mobile, desktop)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        overflow: "hidden",
        maxHeight: mobile,
        [mUp]: {
            maxHeight: desktop
        },
        "@media print": {
            overflow: "visible",
            maxHeight: "none"
        }
    });
var collapsedEditorPreviewStyle = (mobile, desktop)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        position: "relative",
        minHeight: mobile,
        [mUp]: {
            minHeight: desktop
        },
        "&:before": {
            content: " ",
            display: "block",
            position: "absolute",
            left: 0,
            bottom: 0,
            right: 0,
            borderWidth: "1px 0px 1px 0px",
            borderBottomStyle: "solid",
            borderTopStyle: "solid",
            top: mobile,
            [mUp]: {
                top: desktop
            },
            "@media print": {
                display: "none"
            }
        }
    });
var Collapsable = ({ t, children, height = COLLAPSED_HEIGHT, threshold = 50, initialVisibility = "auto", style, alwaysCollapsed = false, editorPreview, isOnOverlay, labelPrefix })=>{
    _s48();
    const [bodyVisibility, setBodyVisibility] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialVisibility);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Collapsable.useEffect5": ()=>{
            recalculateLazyLoads();
        }
    }["Collapsable.useEffect5"], [
        bodyVisibility
    ]);
    const [bodyRef, bodySize] = useBoundingClientRect([
        children
    ]);
    const [colorScheme] = useColorContext();
    const isDesktop = useMediaQuery(mUp);
    const { desktop, mobile } = height;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Collapsable.useEffect5": ()=>{
            if (window.matchMedia("print").matches) {
                setBodyVisibility("full");
            } else if (bodyVisibility === "auto" && (bodySize == null ? void 0 : bodySize.height) !== void 0) {
                const maxBodyHeight = isDesktop ? desktop : mobile;
                if (bodySize.height > maxBodyHeight + threshold) {
                    setBodyVisibility("preview");
                }
            }
        }
    }["Collapsable.useEffect5"], [
        isDesktop,
        bodyVisibility,
        bodySize,
        desktop,
        mobile,
        threshold
    ]);
    const collapsed = bodyVisibility === "auto" ? void 0 : bodyVisibility === "preview";
    const collapseLabel = t && t(`styleguide/Collapsable/${labelPrefix ? `${labelPrefix}/` : ""}${collapsed ? "expand" : "collapse"}`);
    const root = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const onToggleCollapsed = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "Collapsable.useCallback[onToggleCollapsed]": ()=>setBodyVisibility({
                "Collapsable.useCallback[onToggleCollapsed]": (v)=>{
                    var _a;
                    if (v === "full") {
                        if (((_a = root.current) == null ? void 0 : _a.getBoundingClientRect().top) < 0) {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$scroll$2d$into$2d$view$2f$scrollIntoView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(root.current, {
                                time: 0,
                                align: {
                                    top: 0
                                }
                            });
                        }
                        return "preview";
                    }
                    return "full";
                }
            }["Collapsable.useCallback[onToggleCollapsed]"])
    }["Collapsable.useCallback[onToggleCollapsed]"], [
        setBodyVisibility
    ]);
    const buttonContainerBefore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Collapsable.useMemo6[buttonContainerBefore]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                "&::before": {
                    background: colorScheme.getCSSColor(isOnOverlay ? "fadeOutGradientOverlay" : "fadeOutGradientDefault")
                }
            })
    }["Collapsable.useMemo6[buttonContainerBefore]"], [
        colorScheme,
        isOnOverlay
    ]);
    const collapsedEditorPreviewRule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Collapsable.useMemo6[collapsedEditorPreviewRule]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
                "&:before": {
                    backgroundColor: colorScheme.getCSSColor("hover"),
                    borderColor: colorScheme.getCSSColor("primary")
                }
            })
    }["Collapsable.useMemo6[collapsedEditorPreviewRule]"], [
        colorScheme
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("div", __spreadProps(__spreadValues({}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["merge"])(editorPreview && collapsedEditorPreviewStyle(mobile, desktop), editorPreview && collapsedEditorPreviewRule)), {
        ref: root,
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", __spreadProps(__spreadValues(__spreadValues({
                ref: bodyRef
            }, styles15.body), collapsed && !editorPreview && collapsedBodyStyle(mobile, desktop)), {
                style,
                children
            })),
            bodyVisibility !== "auto" && !editorPreview && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", __spreadProps(__spreadValues({}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["merge"])(collapsed ? styles15.buttonContainer : {}, collapsed ? buttonContainerBefore : {}, !alwaysCollapsed && colorScheme.set("borderColor", "divider"))), {
                children: !alwaysCollapsed && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("button", __spreadProps(__spreadValues(__spreadValues({}, styles15.button), colorScheme.set("color", "textSoft")), {
                    onClick: onToggleCollapsed,
                    title: collapseLabel,
                    children: collapseLabel
                }))
            }))
        ]
    }));
};
_s48(Collapsable, "8VXHIlzfnGjFoFtfbvtROIwjJlE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"],
        useBoundingClientRect,
        useColorContext,
        useMediaQuery,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]
    ];
});
_c75 = Collapsable;
var styles15 = {
    body: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        position: "relative"
    }),
    buttonContainer: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        position: "relative",
        "&::before": {
            position: "absolute",
            display: "block",
            content: '""',
            left: 0,
            right: 0,
            top: -80,
            height: 80
        },
        "@media print": {
            display: "none"
        }
    }),
    button: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(sansSerifMedium14)), {
        textDecoration: "underline",
        outline: "none",
        WebkitAppearance: "none",
        background: "transparent",
        border: "none",
        padding: "0",
        display: "block",
        cursor: "pointer",
        height: pxToRem("24px"),
        lineHeight: pxToRem("24px"),
        "@media print": {
            display: "none"
        }
    }))
};
var Collapsable_default = Collapsable;
;
;
;
var labelGauger4 = createTextGauger(sansSerifRegular18, {
    dimension: "width",
    html: true
});
var styles16 = {
    container: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        overflowX: "auto",
        overflowY: "hidden",
        marginLeft: -PADDING,
        marginRight: -PADDING
    }),
    table: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, sansSerifRegular18), {
        lineHeight: "1.2",
        minWidth: "100%",
        borderSpacing: "0 2px",
        borderCollapse: "separate",
        padding: `0 ${PADDING - 10}px`
    })),
    header: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        borderBottomWidth: "1px",
        borderBottomStyle: "solid",
        padding: "8px 10px",
        userSelect: "none"
    }),
    cell: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        padding: "8px 10px"
    }),
    cellNumeric: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])({
        textAlign: "right",
        fontFeatureSettings: '"tnum", "kern"'
    })
};
var Table = (_props)=>{
    _s49();
    const props = __spreadValues(__spreadValues({}, defaultProps.Table), _props);
    const [colorScheme] = useColorContext();
    const { values, numberFormat, colorRanges, colorRange, defaultSortColumn, thresholds, tableColumns, collapsable, sortable, cellVerticalAlign, t } = props;
    const columns = values.columns || Object.keys(values[0] || {});
    const numberFormatter = getFormat(numberFormat, props.tLabel);
    const dateParser = timeParse(props.timeParse);
    const dateFormatter = timeFormat(props.timeFormat);
    const [sortBy2, setSortBy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        key: defaultSortColumn,
        order: "desc"
    });
    const numberColumns = tableColumns.filter((d)=>d.type === "number").map((d)=>d.column);
    const numericColumns = numberColumns.concat(tableColumns.filter((d)=>d.type === "date").map((d)=>d.column));
    const dateColumns = tableColumns.filter((d)=>d.type === "date").map((d)=>d.column);
    const barColumns = tableColumns.filter((d)=>d.type === "bar").map((d)=>d.column);
    const parsedData = numberColumns.length || dateColumns.length ? values.map((row)=>{
        let parsedRow = __spreadValues({}, row);
        numberColumns.forEach((key)=>{
            if (parsedRow[key] !== void 0) {
                parsedRow[key] = +parsedRow[key];
            }
        });
        dateColumns.forEach((key)=>{
            if (parsedRow[key] !== void 0) {
                parsedRow[key] = dateParser(parsedRow[key]);
            }
        });
        return parsedRow;
    }) : [].concat(values);
    const barChartData = [];
    if (barColumns.length) {
        values.map((row)=>{
            barColumns.forEach((key)=>{
                if (row[key] !== void 0) {
                    row[key] = +row[key];
                }
                barChartData.push(row[key]);
            });
        });
    }
    const barChartExtent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$extent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__extent$3e$__["extent"])(barChartData);
    if (sortBy2.key) {
        parsedData.sort((a, b)=>{
            return sortBy2.order === "desc" ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$descending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__descending$3e$__["descending"])(a[sortBy2.key], b[sortBy2.key]) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$styleguide$2f$node_modules$2f$d3$2d$array$2f$src$2f$ascending$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ascending$3e$__["ascending"])(a[sortBy2.key], b[sortBy2.key]);
        });
    }
    const setSort = (key)=>{
        if (sortBy2.key === key) {
            setSortBy(sortBy2.order === "asc" ? {} : {
                key,
                order: sortBy2.order === "desc" ? "asc" : "desc"
            });
        } else {
            setSortBy({
                key,
                order: "desc"
            });
        }
    };
    let colorScale;
    if (thresholds) {
        colorScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$threshold$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleThreshold$3e$__["scaleThreshold"])().domain(thresholds).range(colorRanges[colorRange] || colorRange || colorRanges.sequential.slice(0, thresholds.length + 1));
    } else {
        const colorColumns = tableColumns.filter((c)=>c.color).map((c)=>c.column);
        const colorValues = !colorColumns.length ? [] : parsedData.reduce((values2, row)=>{
            colorColumns.forEach((key)=>{
                values2.push(row[key]);
            });
            return values2;
        }, []).filter(Boolean).filter(deduplicate);
        colorScale = getColorMapper(props, colorValues);
    }
    const content = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", __spreadProps(__spreadValues({}, styles16.container), {
        children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("table", __spreadProps(__spreadValues({}, styles16.table), {
            children: [
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("thead", {
                    children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("tr", {
                        children: columns.map((tableHead, index)=>/* @__PURE__ */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("th", __spreadProps(__spreadValues(__spreadValues({}, styles16.header), colorScheme.set("borderBottomColor", "text")), {
                                style: {
                                    textAlign: numericColumns.includes(tableHead) ? "right" : "left",
                                    cursor: sortable ? "pointer" : void 0,
                                    whiteSpace: sortBy2.key === tableHead ? "nowrap" : void 0,
                                    width: tableColumns.find((d)=>d.column === tableHead) ? tableColumns.find((d)=>d.column === tableHead).width : void 0,
                                    verticalAlign: cellVerticalAlign
                                },
                                key: index,
                                onClick: ()=>{
                                    if (sortable) {
                                        setSort(columns[index]);
                                    }
                                }
                            }), tableHead, sortBy2.key && sortBy2.key === tableHead && (sortBy2.order === "desc" ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconExpandMore"], {
                                style: {
                                    paddingLeft: "2px"
                                }
                            }) : /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$icons$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconExpandLess"], {
                                style: {
                                    paddingLeft: "2px"
                                }
                            }))))
                    })
                }),
                /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("tbody", {
                    style: {
                        marginTop: "5px"
                    },
                    children: parsedData.map((row, rowIndex)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("tr", __spreadProps(__spreadValues({}, rowIndex % 2 !== 0 && colorScheme.set("backgroundColor", "hover")), {
                            children: columns.map((cellKey, cellIndex)=>/* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Cell, __spreadProps(__spreadValues({
                                    barChartExtent
                                }, tableColumns.find((d)=>d.column === cellKey)), {
                                    isNumeric: numericColumns.includes(cellKey),
                                    value: row[cellKey],
                                    colorScale,
                                    columnName: cellKey,
                                    isBarColumn: barColumns.includes(cellKey),
                                    numberFormatter,
                                    verticalAlign: cellVerticalAlign,
                                    children: numberColumns.includes(cellKey) ? numberFormatter(row[cellKey]) : dateColumns.includes(cellKey) ? dateFormatter(row[cellKey]) : row[cellKey]
                                }), cellIndex))
                        }), rowIndex))
                })
            ]
        }))
    }));
    if (collapsable) {
        const height = 40 * 6;
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Collapsable_default, {
            labelPrefix: "table",
            height: {
                mobile: height,
                desktop: height
            },
            t,
            children: content
        });
    }
    return content;
};
_s49(Table, "W+g3KRV4j92G65Fs1+YKKwBX4Sg=", false, function() {
    return [
        useColorContext,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]
    ];
});
_c76 = Table;
var propTypes8 = {
    values: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
    tableColumns: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        column: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        width: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        color: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
    })),
    numberFormat: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
    sortable: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    cellVerticalAlign: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    defaultSortColumn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    colorMap: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    colorRange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array
    ]),
    colorRanges: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        diverging2: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
        sequential3: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
        discrete: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired
    }).isRequired,
    collapsable: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
};
Table.propTypes = propTypes8;
var Table_default = Table;
var Cell = (props)=>{
    const { columnName, width, color, colorScale, value, children, isNumeric, isBarColumn, barChartExtent, numberFormatter, verticalAlign } = props;
    const maxWidth = isBarColumn && (width || 100);
    const barScale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$d3$2d$scale$2f$src$2f$linear$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__scaleLinear$3e$__["scaleLinear"])().domain(barChartExtent).range([
        0,
        maxWidth - PADDING
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("td", __spreadProps(__spreadValues(__spreadValues({}, isNumeric && styles16.cellNumeric), styles16.cell), {
        style: {
            width: width !== void 0 ? +width : void 0,
            backgroundColor: !isBarColumn && color ? colorScale(value) : "transparent",
            color: !isBarColumn && color && getTextColor(colorScale(value)),
            whiteSpace: isBarColumn && "nowrap",
            verticalAlign
        },
        children: isBarColumn ? /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(BarComponent, {
            colorScale,
            barWidth: Math.ceil(barScale(value)),
            label: numberFormatter(value),
            columnName,
            color
        }) : children
    }));
};
_c77 = Cell;
var BarComponent = (props)=>{
    const { barWidth, color, label, columnName, colorScale } = props;
    const labelSize = labelGauger4(label);
    const BAR_LABEL_PADDING = 5;
    const isLabelOutside = labelSize > barWidth;
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                style: {
                    display: "inline-block",
                    position: "relative",
                    verticalAlign: "middle",
                    width: barWidth,
                    backgroundColor: color && colorScale(columnName),
                    height: "30px"
                },
                children: !isLabelOutside && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                    style: {
                        position: "absolute",
                        top: 0,
                        left: BAR_LABEL_PADDING,
                        lineHeight: "30px",
                        color: color && getTextColor(colorScale(columnName))
                    },
                    children: label
                })
            }),
            isLabelOutside && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("span", {
                style: {
                    display: "inline-block",
                    verticalAlign: "middle",
                    paddingLeft: barWidth > 0 && BAR_LABEL_PADDING,
                    lineHeight: "30px"
                },
                children: label
            })
        ]
    });
};
_c78 = BarComponent;
;
var ReactCharts = {
    Bar: Bars_default,
    Lollipop,
    TimeBar: TimeBars_default,
    Line,
    Slope,
    ScatterPlot: ScatterPlots_default,
    GenericMap,
    ProjectedMap,
    SwissMap,
    Hemicycle: Hemicycle_default,
    Table: Table_default
};
var createRanges = ({ neutral, sequential, sequential3, opposite3, discrete })=>{
    const oppositeReversed = [].concat(opposite3).reverse();
    return {
        diverging1: [
            sequential3[1],
            opposite3[1]
        ],
        diverging1n: [
            sequential3[1],
            neutral[0],
            opposite3[1]
        ],
        diverging2: [
            ...sequential3.slice(0, 2),
            ...oppositeReversed.slice(0, 2)
        ],
        diverging3: [
            ...sequential3,
            ...oppositeReversed
        ],
        sequential3,
        sequential,
        discrete
    };
};
var styles17 = {
    h: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(sansSerifMedium19)), {
        lineHeight: pxToRem("25px"),
        [mUp]: __spreadValues({}, convertStyleToRem(sansSerifMedium22)),
        margin: 0,
        marginBottom: 15,
        "& + p": {
            marginTop: -15
        }
    })),
    p: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$glamor$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["css"])(__spreadProps(__spreadValues({}, convertStyleToRem(sansSerifRegular16)), {
        [mUp]: __spreadValues({}, convertStyleToRem(sansSerifRegular19)),
        margin: 0,
        marginBottom: 15
    }))
};
var ChartTitle = (_a)=>{
    _s50();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("h3", __spreadProps(__spreadValues(__spreadValues(__spreadValues({}, props), styles17.h), colorScheme.set("color", "text")), {
        children
    }));
};
_s50(ChartTitle, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c79 = ChartTitle;
var ChartLead = (_a)=>{
    _s51();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("p", __spreadProps(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, props), styles17.p), colorScheme.set("color", "text")), interactionFontRule), {
        children
    }));
};
_s51(ChartLead, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c80 = ChartLead;
var ChartLegend = (_a)=>{
    _s52();
    var _b = _a, { children } = _b, props = __objRest(_b, [
        "children"
    ]);
    const [colorScheme] = useColorContext();
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Note, __spreadProps(__spreadValues({}, colorScheme.set("color", "text")), {
        style: {
            marginTop: 15
        },
        children
    }));
};
_s52(ChartLegend, "aZnUQkyxUHcXyAljzTTH9nxjU60=", false, function() {
    return [
        useColorContext
    ];
});
_c81 = ChartLegend;
var ssrAttribute = "data-chart-ssr";
var Chart = (props)=>{
    _s53();
    const [colorScheme] = useColorContext();
    const isDomAvailable = typeof document !== "undefined";
    const [ssrMode, setSsrMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "Chart.useState6": ()=>!isDomAvailable || isDomAvailable && document.querySelectorAll(`[${ssrAttribute}]`).length > 0
    }["Chart.useState6"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Chart.useEffect6": ()=>{
            if (ssrMode) {
                setSsrMode(false);
            }
        }
    }["Chart.useEffect6"], [
        ssrMode
    ]);
    const [stateWidth, setWidth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(ssrMode ? 290 : void 0);
    const { width: fixedWidth, config, tLabel = (identity)=>identity, t, // allowCanvasRendering might be set to false when exporting SVGs
    allowCanvasRendering = true } = props;
    const width = fixedWidth || stateWidth;
    const ReactChart = ReactCharts[config.type];
    const colorRanges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Chart.useMemo7[colorRanges]": ()=>createRanges(colorScheme.ranges)
    }["Chart.useMemo7[colorRanges]"], [
        colorScheme
    ]);
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Chart.useEffect6": ()=>{
            if (fixedWidth) {
                return;
            }
            const measure = {
                "Chart.useEffect6.measure": ()=>{
                    if (ref.current) {
                        const { width: width2 } = ref.current.getBoundingClientRect();
                        setWidth(width2);
                    }
                }
            }["Chart.useEffect6.measure"];
            window.addEventListener("resize", measure);
            measure();
            return ({
                "Chart.useEffect6": ()=>{
                    window.removeEventListener("resize", measure);
                }
            })["Chart.useEffect6"];
        }
    }["Chart.useEffect6"], [
        fixedWidth
    ]);
    const colorContextExtension = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Chart.useMemo7[colorContextExtension]": ()=>{
            if (!config.colorDarkMapping) {
                return null;
            }
            const keys = Object.keys(config.colorDarkMapping);
            return {
                localColors: keys.reduce({
                    "Chart.useMemo7[colorContextExtension]": (localColors, key, i)=>{
                        localColors.dark[`charts${i}`] = config.colorDarkMapping[key];
                        localColors.light[`charts${i}`] = key;
                        return localColors;
                    }
                }["Chart.useMemo7[colorContextExtension]"], {
                    dark: {},
                    light: {}
                }),
                localMappings: keys.reduce({
                    "Chart.useMemo7[colorContextExtension]": (mappings, key, i)=>{
                        mappings.charts[key] = `charts${i}`;
                        return mappings;
                    }
                }["Chart.useMemo7[colorContextExtension]"], {
                    charts: {}
                })
            };
        }
    }["Chart.useMemo7[colorContextExtension]"], [
        config
    ]);
    const content = /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", __spreadProps(__spreadValues({}, ssrMode && {
        [ssrAttribute]: true
    }), {
        ref: fixedWidth ? void 0 : ref,
        style: {
            maxWidth: config.maxWidth
        },
        children: !!width && /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ChartContextProvider, __spreadProps(__spreadValues({
            width,
            values: props.values
        }, config), {
            tLabel,
            colorRanges,
            children: /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ReactChart, __spreadProps(__spreadValues({}, config), {
                allowCanvasRendering,
                colorScheme,
                tLabel,
                t,
                colorRanges,
                width,
                values: props.values,
                description: config.description
            }))
        }))
    }));
    if (colorContextExtension) {
        return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ColorContextLocalExtension, __spreadProps(__spreadValues({}, colorContextExtension), {
            children: content
        }));
    }
    return content;
};
_s53(Chart, "WRsBb2K2wHRLL7Qh18KO5lyhWwo=", false, function() {
    return [
        useColorContext,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]
    ];
});
_c82 = Chart;
Chart.propTypes = {
    values: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array.isRequired,
    config: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf(Object.keys(ReactCharts)).isRequired,
        description: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
        maxWidth: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
    }).isRequired,
    width: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    tLabel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func
};
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19, _c20, _c21, _c22, _c23, _c24, _c25, _c26, _c27, _c28, _c29, _c30, _c31, _c32, _c33, _c34, _c35, _c36, _c37, _c38, _c39, _c40, _c41, _c42, _c43, _c44, _c45, _c46, _c47, _c48, _c49, _c50, _c51, _c52, _c53, _c54, _c55, _c56, _c57, _c58, _c59, _c60, _c61, _c62, _c63, _c64, _c65, _c66, _c67, _c68, _c69, _c70, _c71, _c72, _c73, _c74, _c75, _c76, _c77, _c78, _c79, _c80, _c81, _c82;
__turbopack_context__.k.register(_c, "ColorContextLocalExtension");
__turbopack_context__.k.register(_c1, "RootColorVariables");
__turbopack_context__.k.register(_c2, "ColorContextProvider");
__turbopack_context__.k.register(_c3, "InvertedColorScheme");
__turbopack_context__.k.register(_c4, "ChartContextProvider");
__turbopack_context__.k.register(_c5, "ColorLegend");
__turbopack_context__.k.register(_c6, "BarChart");
__turbopack_context__.k.register(_c7, "Lollipop");
__turbopack_context__.k.register(_c8, "YAnnotation");
__turbopack_context__.k.register(_c9, "XAnnotation");
__turbopack_context__.k.register(_c10, "TimeBarGroup");
__turbopack_context__.k.register(_c11, "XAxis");
__turbopack_context__.k.register(_c12, "TimeBarChart");
__turbopack_context__.k.register(_c13, "LineGroup");
__turbopack_context__.k.register(_c14, "LineChart");
__turbopack_context__.k.register(_c15, "Line");
__turbopack_context__.k.register(_c16, "Slope");
__turbopack_context__.k.register(_c17, "UnorderedList");
__turbopack_context__.k.register(_c18, "OrderedList");
__turbopack_context__.k.register(_c19, "ListItem");
__turbopack_context__.k.register(_c20, "List");
__turbopack_context__.k.register(_c21, "Headline");
__turbopack_context__.k.register(_c22, "Subhead");
__turbopack_context__.k.register(_c23, "Lead");
__turbopack_context__.k.register(_c24, "Subject");
__turbopack_context__.k.register(_c25, "Credit");
__turbopack_context__.k.register(_c26, "Format");
__turbopack_context__.k.register(_c27, "P");
__turbopack_context__.k.register(_c28, "Question");
__turbopack_context__.k.register(_c29, "Emphasis");
__turbopack_context__.k.register(_c30, "Cursive");
__turbopack_context__.k.register(_c31, "StrikeThrough");
__turbopack_context__.k.register(_c32, "A$React12.forwardRef");
__turbopack_context__.k.register(_c33, "A");
__turbopack_context__.k.register(_c34, "Note");
__turbopack_context__.k.register(_c35, "Headline2");
__turbopack_context__.k.register(_c36, "H1");
__turbopack_context__.k.register(_c37, "H2");
__turbopack_context__.k.register(_c38, "H3");
__turbopack_context__.k.register(_c39, "P2");
__turbopack_context__.k.register(_c40, "Emphasis2");
__turbopack_context__.k.register(_c41, "Cursive2");
__turbopack_context__.k.register(_c42, "Headline3");
__turbopack_context__.k.register(_c43, "Subhead2");
__turbopack_context__.k.register(_c44, "P3");
__turbopack_context__.k.register(_c45, "Lead2");
__turbopack_context__.k.register(_c46, "Headline4");
__turbopack_context__.k.register(_c47, "A2$React13.forwardRef");
__turbopack_context__.k.register(_c48, "A2");
__turbopack_context__.k.register(_c49, "H12");
__turbopack_context__.k.register(_c50, "H22");
__turbopack_context__.k.register(_c51, "Lead3");
__turbopack_context__.k.register(_c52, "P4");
__turbopack_context__.k.register(_c53, "Label");
__turbopack_context__.k.register(_c54, "Sub");
__turbopack_context__.k.register(_c55, "Sup");
__turbopack_context__.k.register(_c56, "HR");
__turbopack_context__.k.register(_c57, "ContextBoxValue");
__turbopack_context__.k.register(_c58, "ContextBox");
__turbopack_context__.k.register(_c59, "Box");
__turbopack_context__.k.register(_c60, "InlineLabel");
__turbopack_context__.k.register(_c61, "ScatterPlotCanvas");
__turbopack_context__.k.register(_c62, "ScatterPlotGroup");
__turbopack_context__.k.register(_c63, "ScatterPlot");
__turbopack_context__.k.register(_c64, "ScatterPlotWithDefaultProps");
__turbopack_context__.k.register(_c65, "Spinner");
__turbopack_context__.k.register(_c66, "InlineSpinner");
__turbopack_context__.k.register(_c67, "Spacer");
__turbopack_context__.k.register(_c68, "Loader");
__turbopack_context__.k.register(_c69, "Points");
__turbopack_context__.k.register(_c70, "ProjectedMap");
__turbopack_context__.k.register(_c71, "SwissMap");
__turbopack_context__.k.register(_c72, "Hemicycle");
__turbopack_context__.k.register(_c73, "Center");
__turbopack_context__.k.register(_c74, "Breakout");
__turbopack_context__.k.register(_c75, "Collapsable");
__turbopack_context__.k.register(_c76, "Table");
__turbopack_context__.k.register(_c77, "Cell");
__turbopack_context__.k.register(_c78, "BarComponent");
__turbopack_context__.k.register(_c79, "ChartTitle");
__turbopack_context__.k.register(_c80, "ChartLead");
__turbopack_context__.k.register(_c81, "ChartLegend");
__turbopack_context__.k.register(_c82, "Chart");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# debugId=3cc8590c-89fe-cd86-15d5-cca63a632df8
//# sourceMappingURL=packages_styleguide_dist_chunk-QCYBJGVP_mjs_04.trkc._.js.map