(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_@sanity_0pzzdm.._.js","static/chunks/apps_www_src_018x73x._.js","static/chunks/packages_styleguide_dist_chunk-QCYBJGVP_mjs_04.trkc._.js","static/chunks/packages_styleguide_dist_lib_mjs_0gdfbmx._.js","static/chunks/packages_theme___generated___recipes_0~fea3.._.js","static/chunks/node_modules_lodash_0ooj84.._.js","static/chunks/node_modules_d3-geo_src_12gpvo6._.js","static/chunks/node_modules_react-color_es_0c8ljej._.js","static/chunks/node_modules_lodash-es_0blk6tf._.js","static/chunks/node_modules_@sanity_client_dist_index_browser_12ct2ya.js","static/chunks/_13v_fr~._.js"],
    source: "dynamic"
});
