(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/0_lp_modules_@apollo_client-react-streaming_dist_SimulatePreloadedQuery_cc_002t3qr.js","static/chunks/apps_www_0_8fz~p._.js","static/chunks/node_modules_@apollo_client_0xnvr7y._.js","static/chunks/node_modules_graphql_10d.~60._.js","static/chunks/node_modules_next_0fdyddw._.js","static/chunks/12mb_zod_lib_index_mjs_0_gdg_h._.js","static/chunks/node_modules_0wo7dcw._.js","static/chunks/packages_theme_08471n~._.css"],
    source: "dynamic"
});
