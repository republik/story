;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="6b2dc941-1dfb-a87c-3ff6-f3b9d98b903f")}catch(e){}}();
(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/www/src/instrumentation-client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// This file configures the initialization of Sentry on the client.
// The config you add here will be used whenever a users loads a page in their browser.
// https://docs.sentry.io/platforms/javascript/guides/nextjs/
__turbopack_context__.s([
    "onRouterTransitionStart",
    ()=>onRouterTransitionStart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$nextjs$2f$build$2f$esm$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@sentry/nextjs/build/esm/client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$browser$2f$build$2f$npm$2f$esm$2f$dev$2f$integrations$2f$graphqlClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sentry/browser/build/npm/esm/dev/integrations/graphqlClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$core$2f$build$2f$esm$2f$integrations$2f$extraerrordata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sentry/core/build/esm/integrations/extraerrordata.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$nextjs$2f$build$2f$esm$2f$client$2f$routing$2f$appRouterRoutingInstrumentation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@sentry/nextjs/build/esm/client/routing/appRouterRoutingInstrumentation.js [app-client] (ecmascript)");
globalThis["_sentryRouteManifest"] = "{\"dynamicRoutes\":[{\"path\":\"/articles/:path*\",\"regex\":\"^/articles/(.+)$\",\"paramNames\":[\"path\"],\"hasOptionalPrefix\":false},{\"path\":\"/pages/:path*\",\"regex\":\"^/pages/(.+)$\",\"paramNames\":[\"path\"],\"hasOptionalPrefix\":false},{\"path\":\"/challenge-accepted/person/:slug\",\"regex\":\"^/challenge-accepted/person/([^/]+)$\",\"paramNames\":[\"slug\"],\"hasOptionalPrefix\":false},{\"path\":\"/kurse/:slug\",\"regex\":\"^/kurse/([^/]+)$\",\"paramNames\":[\"slug\"],\"hasOptionalPrefix\":false},{\"path\":\"/veranstaltungen/:slug\",\"regex\":\"^/veranstaltungen/([^/]+)$\",\"paramNames\":[\"slug\"],\"hasOptionalPrefix\":false}],\"staticRoutes\":[{\"path\":\"/articles\"},{\"path\":\"/articles/feed\"},{\"path\":\"/challenge-accepted\"},{\"path\":\"/challenge-accepted/2023\"},{\"path\":\"/challenge-accepted/person\"},{\"path\":\"/einrichten\"},{\"path\":\"/einrichten/folgen\"},{\"path\":\"/einrichten/willkommen\"},{\"path\":\"/faq\"},{\"path\":\"/format/challenge-accepted\"},{\"path\":\"/kampagne/2000-mitglieder-3-versprechen\"},{\"path\":\"/kurse\"},{\"path\":\"/newsletters/confirm\"},{\"path\":\"/veranstaltungen\"}],\"isrRoutes\":[]}";
globalThis["_sentryNextJsVersion"] = "16.2.6";
globalThis["_sentryRewritesTunnelPath"] = "/monitoring";
;
if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_SENTRY_DISABLED !== 'true') {
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$nextjs$2f$build$2f$esm$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["init"]({
        dsn: ("TURBOPACK compile-time value", "https://d5cb23b28e4638200c760ebeb2117d3e@o4507101684105216.ingest.de.sentry.io/4507101768908880"),
        ignoreErrors: [
            'Script error.',
            'Error: aborted',
            /Failed to load/i,
            /Failed to fetch/i,
            /Load failed/i,
            /fetch failed/i,
            /NetworkError when attempting to fetch resource/i,
            /Invariant: attempted to hard navigate to the same URL/i,
            /Sie müssen sich zuerst anmelden/i,
            /__firefox__/i
        ],
        denyUrls: [
            /https?:\/\/datawrapper\.dwcdn\.net\//
        ],
        integrations: [
            // Include GraphQL queries in error spans
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$browser$2f$build$2f$npm$2f$esm$2f$dev$2f$integrations$2f$graphqlClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["graphqlClientIntegration"]({
                endpoints: [
                    '/graphql'
                ]
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$core$2f$build$2f$esm$2f$integrations$2f$extraerrordata$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extraErrorDataIntegration"]({
                depth: 5
            })
        ]
    });
}
const onRouterTransitionStart = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$sentry$2f$nextjs$2f$build$2f$esm$2f$client$2f$routing$2f$appRouterRoutingInstrumentation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureRouterTransitionStart"];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# debugId=6b2dc941-1dfb-a87c-3ff6-f3b9d98b903f
//# sourceMappingURL=apps_www_src_instrumentation-client_ts_0jvn.ey._.js.map